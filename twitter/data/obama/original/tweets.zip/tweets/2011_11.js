Grailbird.data.tweets_2011_11 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "142061612327649280",
  "text" : "If Rs in Congress fail to extend the payroll tax cut, taxes will go up on millions of people when families are struggling to make ends meet.",
  "id" : 142061612327649280,
  "created_at" : "2011-12-01 02:05:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AtTheWH",
      "indices" : [ 33, 41 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/xGVKX32j",
      "expanded_url" : "http:\/\/ow.ly\/7KxyQ",
      "display_url" : "ow.ly\/7KxyQ"
    } ]
  },
  "geo" : { },
  "id_str" : "142036452929314816",
  "text" : "This year's holidays decorations #AtTheWH include quite a few renderings of the first pup. Take a look the littlest Bo: http:\/\/t.co\/xGVKX32j",
  "id" : 142036452929314816,
  "created_at" : "2011-12-01 00:25:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/142021941673459712\/photo\/1",
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/hxyk2WGu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AfiQNBgCAAEcfw_.jpg",
      "id_str" : "142021941677654017",
      "id" : 142021941677654017,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AfiQNBgCAAEcfw_.jpg",
      "sizes" : [ {
        "h" : 315,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 315,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 315,
        "resize" : "fit",
        "w" : 560
      } ],
      "display_url" : "pic.twitter.com\/hxyk2WGu"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http:\/\/t.co\/KEFzfp4E",
      "expanded_url" : "http:\/\/1.usa.gov\/sylc0W",
      "display_url" : "1.usa.gov\/sylc0W"
    } ]
  },
  "geo" : { },
  "id_str" : "142021941673459712",
  "text" : "By the Numbers: $1,500: http:\/\/t.co\/KEFzfp4E Obama\u2019s tax cut puts an extra $1.5k in the pockets of American families: http:\/\/t.co\/hxyk2WGu",
  "id" : 142021941673459712,
  "created_at" : "2011-11-30 23:27:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PEPFAR",
      "screen_name" : "PEPFAR",
      "indices" : [ 3, 10 ],
      "id_str" : "69091913",
      "id" : 69091913
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WorldAIDSDay",
      "indices" : [ 12, 25 ]
    }, {
      "text" : "EndofAIDS",
      "indices" : [ 95, 105 ]
    }, {
      "text" : "WAD11",
      "indices" : [ 123, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "142003521213050880",
  "text" : "RT @PEPFAR: #WorldAIDSDay is tomorrow! Make sure to change your profile picture to support the #EndofAIDS. Use this image. #WAD11 http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.crowdbooster.com\" rel=\"nofollow\"\u003ECrowdbooster\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PEPFAR\/status\/141632713743536128\/photo\/1",
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/UbLvhQ8M",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AfcuM-eCEAIekyi.png",
        "id_str" : "141632713747730434",
        "id" : 141632713747730434,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AfcuM-eCEAIekyi.png",
        "sizes" : [ {
          "h" : 128,
          "resize" : "fit",
          "w" : 128
        }, {
          "h" : 128,
          "resize" : "fit",
          "w" : 128
        }, {
          "h" : 128,
          "resize" : "fit",
          "w" : 128
        }, {
          "h" : 128,
          "resize" : "crop",
          "w" : 128
        }, {
          "h" : 128,
          "resize" : "fit",
          "w" : 128
        } ],
        "display_url" : "pic.twitter.com\/UbLvhQ8M"
      } ],
      "hashtags" : [ {
        "text" : "WorldAIDSDay",
        "indices" : [ 0, 13 ]
      }, {
        "text" : "EndofAIDS",
        "indices" : [ 83, 93 ]
      }, {
        "text" : "WAD11",
        "indices" : [ 111, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "141922653949800448",
    "text" : "#WorldAIDSDay is tomorrow! Make sure to change your profile picture to support the #EndofAIDS. Use this image. #WAD11 http:\/\/t.co\/UbLvhQ8M",
    "id" : 141922653949800448,
    "created_at" : "2011-11-30 16:52:52 +0000",
    "user" : {
      "name" : "PEPFAR",
      "screen_name" : "PEPFAR",
      "protected" : false,
      "id_str" : "69091913",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719590176289193984\/r0UMCuIN_normal.jpg",
      "id" : 69091913,
      "verified" : true
    }
  },
  "id" : 142003521213050880,
  "created_at" : "2011-11-30 22:14:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EndOfAIDS",
      "indices" : [ 50, 60 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 66, 73 ]
    }, {
      "text" : "WorldAIDSDay",
      "indices" : [ 106, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/E9nHOqF7",
      "expanded_url" : "http:\/\/ow.ly\/7KoNB",
      "display_url" : "ow.ly\/7KoNB"
    } ]
  },
  "geo" : { },
  "id_str" : "141996283253637120",
  "text" : "Open for questions tomorrow: The Beginning of the #EndOfAIDS. Use #WHChat to ask Qs: http:\/\/t.co\/E9nHOqF7 #WorldAIDSDay",
  "id" : 141996283253637120,
  "created_at" : "2011-11-30 21:45:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141969189966581761",
  "text" : "RT @jesseclee44: Obama: GOP \"may have voted No on these tax cuts once. But I\u2019m already filled w\/ the Christmas spirit...we're gonna give ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "141968969551720448",
    "text" : "Obama: GOP \"may have voted No on these tax cuts once. But I\u2019m already filled w\/ the Christmas spirit...we're gonna give them another chance\"",
    "id" : 141968969551720448,
    "created_at" : "2011-11-30 19:56:54 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 141969189966581761,
  "created_at" : "2011-11-30 19:57:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141968470505041920",
  "text" : "RT @WHLive: Obama: This can not be about who wins or loses in Washington. This is about delivering a win for the American people.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "141968417564524545",
    "text" : "Obama: This can not be about who wins or loses in Washington. This is about delivering a win for the American people.",
    "id" : 141968417564524545,
    "created_at" : "2011-11-30 19:54:43 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 141968470505041920,
  "created_at" : "2011-11-30 19:54:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141967733997830144",
  "text" : "RT @WHLive: Obama: If Congress doesn\u2019t extend this tax cut \u2013 the typical middle-class family is going to see its taxes go up by $1,000",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "141967686291832834",
    "text" : "Obama: If Congress doesn\u2019t extend this tax cut \u2013 the typical middle-class family is going to see its taxes go up by $1,000",
    "id" : 141967686291832834,
    "created_at" : "2011-11-30 19:51:48 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 141967733997830144,
  "created_at" : "2011-11-30 19:52:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141967535418523648",
  "text" : "RT @WHLive: Obama to middle class families: Your taxes are lower today, not higher, than the day I took office",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "141967481219715075",
    "text" : "Obama to middle class families: Your taxes are lower today, not higher, than the day I took office",
    "id" : 141967481219715075,
    "created_at" : "2011-11-30 19:50:59 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 141967535418523648,
  "created_at" : "2011-11-30 19:51:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141966136588767232",
  "text" : "RT @jesseclee44: Obama on Scranton, America: \"We don\u2019t give up, we get back up\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "141965863577337856",
    "text" : "Obama on Scranton, America: \"We don\u2019t give up, we get back up\"",
    "id" : 141965863577337856,
    "created_at" : "2011-11-30 19:44:34 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 141966136588767232,
  "created_at" : "2011-11-30 19:45:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141965554754920448",
  "text" : "RT @WHLive: Obama: This holiday season is going to be a season of homecomings across America \u2013 by the end of Dec all of our troops will  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "141965498727411712",
    "text" : "Obama: This holiday season is going to be a season of homecomings across America \u2013 by the end of Dec all of our troops will be out of Iraq",
    "id" : 141965498727411712,
    "created_at" : "2011-11-30 19:43:07 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 141965554754920448,
  "created_at" : "2011-11-30 19:43:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "141965271995924482",
  "text" : "Happening now: Pres Obama speaks @ Scranton HS, urging Congress to act to extend & expand the payroll tax cut. Watch: http:\/\/t.co\/u95y7hhB",
  "id" : 141965271995924482,
  "created_at" : "2011-11-30 19:42:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 65, 76 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "141946076033851392",
  "text" : "Watch @ 1:30ET: The First Lady welcomes military families to the @WhiteHouse for a 1st look @ 2011 holiday decorations: http:\/\/t.co\/u95y7hhB",
  "id" : 141946076033851392,
  "created_at" : "2011-11-30 18:25:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141921734851964928",
  "text" : "RT @jesseclee44: 11.4M people in TX alone get $ in their pockets from payroll tax cut. New Treas report breaks out by state http:\/\/t.co\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 127 ],
        "url" : "http:\/\/t.co\/hfgaKo0K",
        "expanded_url" : "http:\/\/1.usa.gov\/tT0ajp",
        "display_url" : "1.usa.gov\/tT0ajp"
      } ]
    },
    "geo" : { },
    "id_str" : "141913480759488513",
    "text" : "11.4M people in TX alone get $ in their pockets from payroll tax cut. New Treas report breaks out by state http:\/\/t.co\/hfgaKo0K",
    "id" : 141913480759488513,
    "created_at" : "2011-11-30 16:16:25 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 141921734851964928,
  "created_at" : "2011-11-30 16:49:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141653842705133570",
  "text" : "RT @VP: PHOTO: VP arrives @ Baghdad Int'l Airport today; greeted by US Amb to Iraq James Jeffrey and General Lloyd Austin http:\/\/t.co\/ap ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/141642928610222080\/photo\/1",
        "indices" : [ 114, 134 ],
        "url" : "http:\/\/t.co\/apLcZ0lZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Afc3fj1CIAANCcJ.jpg",
        "id_str" : "141642928618610688",
        "id" : 141642928618610688,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Afc3fj1CIAANCcJ.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1333,
          "resize" : "fit",
          "w" : 2000
        } ],
        "display_url" : "pic.twitter.com\/apLcZ0lZ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "141642928610222080",
    "text" : "PHOTO: VP arrives @ Baghdad Int'l Airport today; greeted by US Amb to Iraq James Jeffrey and General Lloyd Austin http:\/\/t.co\/apLcZ0lZ",
    "id" : 141642928610222080,
    "created_at" : "2011-11-29 22:21:21 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 141653842705133570,
  "created_at" : "2011-11-29 23:04:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141649919789379585",
  "text" : "RT @arneduncan: We need to start a nat'l conversation on how to improve college completion rates while keeping tuition under control. ht ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/DfMlbF54",
        "expanded_url" : "http:\/\/nyti.ms\/sxzki3",
        "display_url" : "nyti.ms\/sxzki3"
      } ]
    },
    "geo" : { },
    "id_str" : "141648393406652418",
    "text" : "We need to start a nat'l conversation on how to improve college completion rates while keeping tuition under control. http:\/\/t.co\/DfMlbF54",
    "id" : 141648393406652418,
    "created_at" : "2011-11-29 22:43:03 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 141649919789379585,
  "created_at" : "2011-11-29 22:49:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 35, 46 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/zS7RvfeW",
      "expanded_url" : "http:\/\/ow.ly\/7J30F",
      "display_url" : "ow.ly\/7J30F"
    }, {
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/WSJoHZX4",
      "expanded_url" : "http:\/\/ow.ly\/7J2Mv",
      "display_url" : "ow.ly\/7J2Mv"
    } ]
  },
  "geo" : { },
  "id_str" : "141627270635859968",
  "text" : "From the Archives: Holidays at the @WhiteHouse: http:\/\/t.co\/zS7RvfeW Watch more videos from last year: http:\/\/t.co\/WSJoHZX4",
  "id" : 141627270635859968,
  "created_at" : "2011-11-29 21:19:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    }, {
      "name" : "Greg Sargent",
      "screen_name" : "ThePlumLineGS",
      "indices" : [ 20, 34 ],
      "id_str" : "20508720",
      "id" : 20508720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/2HJCefJe",
      "expanded_url" : "http:\/\/wapo.st\/vfwxuY",
      "display_url" : "wapo.st\/vfwxuY"
    } ]
  },
  "geo" : { },
  "id_str" : "141585060234149888",
  "text" : "RT @pfeiffer44: Via @ThePlumlineGS \"Financial analyst: Consequences of failure to extend payroll tax cut would be dire\" http:\/\/t.co\/2HJCefJe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Greg Sargent",
        "screen_name" : "ThePlumLineGS",
        "indices" : [ 4, 18 ],
        "id_str" : "20508720",
        "id" : 20508720
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 124 ],
        "url" : "http:\/\/t.co\/2HJCefJe",
        "expanded_url" : "http:\/\/wapo.st\/vfwxuY",
        "display_url" : "wapo.st\/vfwxuY"
      } ]
    },
    "geo" : { },
    "id_str" : "141576117499858944",
    "text" : "Via @ThePlumlineGS \"Financial analyst: Consequences of failure to extend payroll tax cut would be dire\" http:\/\/t.co\/2HJCefJe",
    "id" : 141576117499858944,
    "created_at" : "2011-11-29 17:55:51 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 141585060234149888,
  "created_at" : "2011-11-29 18:31:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141562608762368000",
  "text" : "RT @VP: VP has arrived in Baghdad, Iraq; will co-chair mtg of US-Iraq Higher Coordinating Cmte & meet w\/PM Maliki, Pres Talabani, Speake ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "141561611927302144",
    "text" : "VP has arrived in Baghdad, Iraq; will co-chair mtg of US-Iraq Higher Coordinating Cmte & meet w\/PM Maliki, Pres Talabani, Speaker al-Nujaifi",
    "id" : 141561611927302144,
    "created_at" : "2011-11-29 16:58:13 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 141562608762368000,
  "created_at" : "2011-11-29 17:02:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/141304799458107392\/photo\/1",
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/O5xRP0QS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AfYD92lCIAEMCnE.jpg",
      "id_str" : "141304799466496001",
      "id" : 141304799466496001,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AfYD92lCIAEMCnE.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      } ],
      "display_url" : "pic.twitter.com\/O5xRP0QS"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http:\/\/t.co\/KGWNkIpV",
      "expanded_url" : "http:\/\/1.usa.gov\/virYCs",
      "display_url" : "1.usa.gov\/virYCs"
    } ]
  },
  "geo" : { },
  "id_str" : "141304799458107392",
  "text" : "By the Numbers: 475 Million. http:\/\/t.co\/KGWNkIpV Federal Government creates 475 million pages of records a year: http:\/\/t.co\/O5xRP0QS",
  "id" : 141304799458107392,
  "created_at" : "2011-11-28 23:57:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 3, 13 ],
      "id_str" : "9624742",
      "id" : 9624742
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 29, 40 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EU",
      "indices" : [ 50, 53 ]
    }, {
      "text" : "USEUsummit",
      "indices" : [ 101, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/ENtcdfIi",
      "expanded_url" : "http:\/\/go.usa.gov\/5ay",
      "display_url" : "go.usa.gov\/5ay"
    } ]
  },
  "geo" : { },
  "id_str" : "141301527246675969",
  "text" : "RT @StateDept: Latest on the @WhiteHouse Blog: An #EU Summit at the White House http:\/\/t.co\/ENtcdfIi #USEUsummit",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 14, 25 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EU",
        "indices" : [ 35, 38 ]
      }, {
        "text" : "USEUsummit",
        "indices" : [ 86, 97 ]
      } ],
      "urls" : [ {
        "indices" : [ 65, 85 ],
        "url" : "http:\/\/t.co\/ENtcdfIi",
        "expanded_url" : "http:\/\/go.usa.gov\/5ay",
        "display_url" : "go.usa.gov\/5ay"
      } ]
    },
    "geo" : { },
    "id_str" : "141299955980705793",
    "text" : "Latest on the @WhiteHouse Blog: An #EU Summit at the White House http:\/\/t.co\/ENtcdfIi #USEUsummit",
    "id" : 141299955980705793,
    "created_at" : "2011-11-28 23:38:29 +0000",
    "user" : {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "protected" : false,
      "id_str" : "9624742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724612605185282048\/1rEfkXDZ_normal.jpg",
      "id" : 9624742,
      "verified" : true
    }
  },
  "id" : 141301527246675969,
  "created_at" : "2011-11-28 23:44:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/kgsJk0VP",
      "expanded_url" : "http:\/\/ow.ly\/7HNGV",
      "display_url" : "ow.ly\/7HNGV"
    } ]
  },
  "geo" : { },
  "id_str" : "141290130500632576",
  "text" : "So far this year, more than 2.2 million people with Medicare have saved more than $1.2 billion on their prescriptions: http:\/\/t.co\/kgsJk0VP",
  "id" : 141290130500632576,
  "created_at" : "2011-11-28 22:59:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CyberMonday",
      "indices" : [ 0, 12 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/0eHOHQqK",
      "expanded_url" : "http:\/\/ow.ly\/7HLvq",
      "display_url" : "ow.ly\/7HLvq"
    } ]
  },
  "geo" : { },
  "id_str" : "141280710353891328",
  "text" : "#CyberMonday: Providing Americans the online protection they deserve: http:\/\/t.co\/0eHOHQqK",
  "id" : 141280710353891328,
  "created_at" : "2011-11-28 22:22:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 21, 32 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "Barack Obama",
      "screen_name" : "BarackObama",
      "indices" : [ 40, 52 ],
      "id_str" : "813286",
      "id" : 813286
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AffordableCareAct",
      "indices" : [ 98, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141280111583440896",
  "text" : "RT @1_And_Only_Gurl: @whitehouse Thanks @BarackObama for taking care of my grandparents under the #AffordableCareAct by saving them cash ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "Barack Obama",
        "screen_name" : "BarackObama",
        "indices" : [ 19, 31 ],
        "id_str" : "813286",
        "id" : 813286
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AffordableCareAct",
        "indices" : [ 77, 95 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "141255507502571520",
    "geo" : { },
    "id_str" : "141256600223612929",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse Thanks @BarackObama for taking care of my grandparents under the #AffordableCareAct by saving them cash on perscription drugs.",
    "id" : 141256600223612929,
    "in_reply_to_status_id" : 141255507502571520,
    "created_at" : "2011-11-28 20:46:12 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "#TrumpsNotMyPrez",
      "screen_name" : "musicinmyveinz",
      "protected" : false,
      "id_str" : "371997295",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/795497160804421632\/XGUIsqe__normal.jpg",
      "id" : 371997295,
      "verified" : false
    }
  },
  "id" : 141280111583440896,
  "created_at" : "2011-11-28 22:19:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joni Dickerson",
      "screen_name" : "jonidickerson",
      "indices" : [ 3, 17 ],
      "id_str" : "30945834",
      "id" : 30945834
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 55, 66 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141280045447659520",
  "text" : "RT @jonidickerson: My last antibiotics were free!  RT: @whitehouse Millions are saving money on rx drugs under Affordable Care Act: http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 36, 47 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 133 ],
        "url" : "http:\/\/t.co\/RcJjivjz",
        "expanded_url" : "http:\/\/ow.ly\/7HDQi",
        "display_url" : "ow.ly\/7HDQi"
      } ]
    },
    "in_reply_to_status_id_str" : "141255507502571520",
    "geo" : { },
    "id_str" : "141256940075487233",
    "in_reply_to_user_id" : 30313925,
    "text" : "My last antibiotics were free!  RT: @whitehouse Millions are saving money on rx drugs under Affordable Care Act: http:\/\/t.co\/RcJjivjz",
    "id" : 141256940075487233,
    "in_reply_to_status_id" : 141255507502571520,
    "created_at" : "2011-11-28 20:47:33 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Joni Dickerson",
      "screen_name" : "jonidickerson",
      "protected" : false,
      "id_str" : "30945834",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1807646838\/champrings_normal.jpg",
      "id" : 30945834,
      "verified" : false
    }
  },
  "id" : 141280045447659520,
  "created_at" : "2011-11-28 22:19:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HCR",
      "indices" : [ 115, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/8u4AE2qM",
      "expanded_url" : "http:\/\/ow.ly\/7HDQi",
      "display_url" : "ow.ly\/7HDQi"
    } ]
  },
  "geo" : { },
  "id_str" : "141255507502571520",
  "text" : "Millions of seniors are saving money on prescription drugs thanks to the Affordable Care Act: http:\/\/t.co\/8u4AE2qM #HCR",
  "id" : 141255507502571520,
  "created_at" : "2011-11-28 20:41:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aneesh Chopra",
      "screen_name" : "aneeshchopra",
      "indices" : [ 3, 16 ],
      "id_str" : "121539516",
      "id" : 121539516
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BlackFriday",
      "indices" : [ 59, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/mraYWYhr",
      "expanded_url" : "http:\/\/1.usa.gov\/v0SwGs",
      "display_url" : "1.usa.gov\/v0SwGs"
    } ]
  },
  "geo" : { },
  "id_str" : "141239708075298816",
  "text" : "RT @aneeshchopra: Joined millions of Americans shopping on #BlackFriday...spent most of it on my smartphone. http:\/\/t.co\/mraYWYhr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BlackFriday",
        "indices" : [ 41, 53 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 111 ],
        "url" : "http:\/\/t.co\/mraYWYhr",
        "expanded_url" : "http:\/\/1.usa.gov\/v0SwGs",
        "display_url" : "1.usa.gov\/v0SwGs"
      } ]
    },
    "geo" : { },
    "id_str" : "140470647640956930",
    "text" : "Joined millions of Americans shopping on #BlackFriday...spent most of it on my smartphone. http:\/\/t.co\/mraYWYhr",
    "id" : 140470647640956930,
    "created_at" : "2011-11-26 16:43:06 +0000",
    "user" : {
      "name" : "Aneesh Chopra",
      "screen_name" : "aneeshchopra",
      "protected" : false,
      "id_str" : "121539516",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000040581867\/a0962f4551be12d095b281f8afa81a95_normal.jpeg",
      "id" : 121539516,
      "verified" : true
    }
  },
  "id" : 141239708075298816,
  "created_at" : "2011-11-28 19:39:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Homeland Security",
      "screen_name" : "DHSgov",
      "indices" : [ 3, 10 ],
      "id_str" : "15647676",
      "id" : 15647676
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CyberMonday",
      "indices" : [ 26, 38 ]
    }, {
      "text" : "cybersecurity",
      "indices" : [ 56, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/YMkNPFfL",
      "expanded_url" : "http:\/\/blog.dhs.gov\/2011\/11\/on-cyber-monday-dont-let-cyber-grinch.html",
      "display_url" : "blog.dhs.gov\/2011\/11\/on-cyb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "141218848484507648",
  "text" : "RT @DHSgov: Shopping this #CyberMonday? Check out these #cybersecurity tips from Stop. Think. Connect. first: http:\/\/t.co\/YMkNPFfL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CyberMonday",
        "indices" : [ 14, 26 ]
      }, {
        "text" : "cybersecurity",
        "indices" : [ 44, 58 ]
      } ],
      "urls" : [ {
        "indices" : [ 98, 118 ],
        "url" : "http:\/\/t.co\/YMkNPFfL",
        "expanded_url" : "http:\/\/blog.dhs.gov\/2011\/11\/on-cyber-monday-dont-let-cyber-grinch.html",
        "display_url" : "blog.dhs.gov\/2011\/11\/on-cyb\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "141168245548916736",
    "text" : "Shopping this #CyberMonday? Check out these #cybersecurity tips from Stop. Think. Connect. first: http:\/\/t.co\/YMkNPFfL",
    "id" : 141168245548916736,
    "created_at" : "2011-11-28 14:55:07 +0000",
    "user" : {
      "name" : "Homeland Security",
      "screen_name" : "DHSgov",
      "protected" : false,
      "id_str" : "15647676",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/936215926\/dhs-twitter-300_normal.jpg",
      "id" : 15647676,
      "verified" : true
    }
  },
  "id" : 141218848484507648,
  "created_at" : "2011-11-28 18:16:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141218316852281344",
  "text" : "RT @pfeiffer44: Funny thing abt Sen Kyl's opposition to payroll tax cut extension is that in '09 on CNBC he called for a payroll tax cut ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "141208447977930752",
    "text" : "Funny thing abt Sen Kyl's opposition to payroll tax cut extension is that in '09 on CNBC he called for a payroll tax cut bc it created jobs",
    "id" : 141208447977930752,
    "created_at" : "2011-11-28 17:34:52 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 141218316852281344,
  "created_at" : "2011-11-28 18:14:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 31, 42 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/euHvR\/status\/141196933090918400\/photo\/1",
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/9T5ElUx1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AfWh3QzCQAA3-U2.jpg",
      "id_str" : "141196934105939968",
      "id" : 141196934105939968,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AfWh3QzCQAA3-U2.jpg",
      "sizes" : [ {
        "h" : 356,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1216,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 608,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 202,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/9T5ElUx1"
    } ],
    "hashtags" : [ {
      "text" : "USEUSummit",
      "indices" : [ 44, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141202994871025665",
  "text" : "RT @euHvR: Just arrived at the @WhiteHouse. #USEUSummit about to start http:\/\/t.co\/9T5ElUx1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 20, 31 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/euHvR\/status\/141196933090918400\/photo\/1",
        "indices" : [ 60, 80 ],
        "url" : "http:\/\/t.co\/9T5ElUx1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AfWh3QzCQAA3-U2.jpg",
        "id_str" : "141196934105939968",
        "id" : 141196934105939968,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AfWh3QzCQAA3-U2.jpg",
        "sizes" : [ {
          "h" : 356,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1216,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 608,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 202,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/9T5ElUx1"
      } ],
      "hashtags" : [ {
        "text" : "USEUSummit",
        "indices" : [ 33, 44 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "141196933090918400",
    "text" : "Just arrived at the @WhiteHouse. #USEUSummit about to start http:\/\/t.co\/9T5ElUx1",
    "id" : 141196933090918400,
    "created_at" : "2011-11-28 16:49:07 +0000",
    "user" : {
      "name" : "Donald Tusk",
      "screen_name" : "eucopresident",
      "protected" : false,
      "id_str" : "196994616",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539335261398646784\/ixECPqgQ_normal.jpeg",
      "id" : 196994616,
      "verified" : true
    }
  },
  "id" : 141202994871025665,
  "created_at" : "2011-11-28 17:13:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 3, 13 ],
      "id_str" : "9624742",
      "id" : 9624742
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 55, 66 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "US Mission to the EU",
      "screen_name" : "US2EU",
      "indices" : [ 103, 109 ],
      "id_str" : "412303032",
      "id" : 412303032
    }, {
      "name" : "Tony Gardner",
      "screen_name" : "USAmbEU",
      "indices" : [ 114, 122 ],
      "id_str" : "317650146",
      "id" : 317650146
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EU",
      "indices" : [ 40, 43 ]
    }, {
      "text" : "USEUsummit",
      "indices" : [ 83, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "141173536592113664",
  "text" : "RT @StateDept: President Obama welcomes #EU leaders to @WhiteHouse for November 28 #USEUsummit. Follow @US2EU and @USAmbEU for updates.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 40, 51 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "US Mission to the EU",
        "screen_name" : "US2EU",
        "indices" : [ 88, 94 ],
        "id_str" : "412303032",
        "id" : 412303032
      }, {
        "name" : "Tony Gardner",
        "screen_name" : "USAmbEU",
        "indices" : [ 99, 107 ],
        "id_str" : "317650146",
        "id" : 317650146
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EU",
        "indices" : [ 25, 28 ]
      }, {
        "text" : "USEUsummit",
        "indices" : [ 68, 79 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "141173051256602624",
    "text" : "President Obama welcomes #EU leaders to @WhiteHouse for November 28 #USEUsummit. Follow @US2EU and @USAmbEU for updates.",
    "id" : 141173051256602624,
    "created_at" : "2011-11-28 15:14:12 +0000",
    "user" : {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "protected" : false,
      "id_str" : "9624742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724612605185282048\/1rEfkXDZ_normal.jpg",
      "id" : 9624742,
      "verified" : true
    }
  },
  "id" : 141173536592113664,
  "created_at" : "2011-11-28 15:16:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SBA",
      "screen_name" : "SBAgov",
      "indices" : [ 3, 10 ],
      "id_str" : "153149305",
      "id" : 153149305
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SmallBizSat",
      "indices" : [ 102, 114 ]
    }, {
      "text" : "Shopsmall",
      "indices" : [ 115, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/h09sIabK",
      "expanded_url" : "http:\/\/owl.li\/7Gr25",
      "display_url" : "owl.li\/7Gr25"
    } ]
  },
  "geo" : { },
  "id_str" : "140954944198029312",
  "text" : "RT @SBAgov: Check out what President Obama purchased on Small Business Saturday: http:\/\/t.co\/h09sIabK #SmallBizSat #Shopsmall",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SmallBizSat",
        "indices" : [ 90, 102 ]
      }, {
        "text" : "Shopsmall",
        "indices" : [ 103, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 69, 89 ],
        "url" : "http:\/\/t.co\/h09sIabK",
        "expanded_url" : "http:\/\/owl.li\/7Gr25",
        "display_url" : "owl.li\/7Gr25"
      } ]
    },
    "geo" : { },
    "id_str" : "140920371355467776",
    "text" : "Check out what President Obama purchased on Small Business Saturday: http:\/\/t.co\/h09sIabK #SmallBizSat #Shopsmall",
    "id" : 140920371355467776,
    "created_at" : "2011-11-27 22:30:09 +0000",
    "user" : {
      "name" : "SBA",
      "screen_name" : "SBAgov",
      "protected" : false,
      "id_str" : "153149305",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/637366120236756992\/ky6enEIv_normal.png",
      "id" : 153149305,
      "verified" : true
    }
  },
  "id" : 140954944198029312,
  "created_at" : "2011-11-28 00:47:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kramerbooks",
      "screen_name" : "kramerbooks",
      "indices" : [ 71, 83 ],
      "id_str" : "84436630",
      "id" : 84436630
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/140616824021725185\/photo\/1",
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/4ZwqYF23",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AfOSQaXCMAAeO8y.jpg",
      "id_str" : "140616824030113792",
      "id" : 140616824030113792,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AfOSQaXCMAAeO8y.jpg",
      "sizes" : [ {
        "h" : 409,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 231,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1342,
        "resize" : "fit",
        "w" : 1971
      }, {
        "h" : 697,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/4ZwqYF23"
    } ],
    "hashtags" : [ {
      "text" : "ShopSmall",
      "indices" : [ 60, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140616824021725185",
  "text" : "Photo of the Day: President Obama & daughters Sasha & Malia #ShopSmall @kramerbooks on Small Business Saturday: http:\/\/t.co\/4ZwqYF23",
  "id" : 140616824021725185,
  "created_at" : "2011-11-27 02:23:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kramerbooks",
      "screen_name" : "kramerbooks",
      "indices" : [ 3, 15 ],
      "id_str" : "84436630",
      "id" : 84436630
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "indie",
      "indices" : [ 91, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140522833909530624",
  "text" : "RT @kramerbooks: Very exciting that President Obama has chosen to support local business & #indie bookstores by shopping w\/us today! #Sm ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "indie",
        "indices" : [ 74, 80 ]
      }, {
        "text" : "SmallBizSat",
        "indices" : [ 116, 128 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "140472284396797953",
    "text" : "Very exciting that President Obama has chosen to support local business & #indie bookstores by shopping w\/us today! #SmallBizSat",
    "id" : 140472284396797953,
    "created_at" : "2011-11-26 16:49:37 +0000",
    "user" : {
      "name" : "Kramerbooks",
      "screen_name" : "kramerbooks",
      "protected" : false,
      "id_str" : "84436630",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493764005752606720\/Jymz4Wty_normal.jpeg",
      "id" : 84436630,
      "verified" : false
    }
  },
  "id" : 140522833909530624,
  "created_at" : "2011-11-26 20:10:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kramerbooks",
      "screen_name" : "kramerbooks",
      "indices" : [ 3, 15 ],
      "id_str" : "84436630",
      "id" : 84436630
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SmallBizSat",
      "indices" : [ 78, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140522640174624768",
  "text" : "RT @kramerbooks: Thx to Pres. Obama, & Sasha & Malia for shopping w\/us today! #SmallBizSat Photo via \"AP Photo\" via Irish Independent ht ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SmallBizSat",
        "indices" : [ 61, 73 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 137 ],
        "url" : "http:\/\/t.co\/dyJru5Me",
        "expanded_url" : "http:\/\/bit.ly\/rw9hQY",
        "display_url" : "bit.ly\/rw9hQY"
      } ]
    },
    "geo" : { },
    "id_str" : "140485351134347264",
    "text" : "Thx to Pres. Obama, & Sasha & Malia for shopping w\/us today! #SmallBizSat Photo via \"AP Photo\" via Irish Independent http:\/\/t.co\/dyJru5Me",
    "id" : 140485351134347264,
    "created_at" : "2011-11-26 17:41:32 +0000",
    "user" : {
      "name" : "Kramerbooks",
      "screen_name" : "kramerbooks",
      "protected" : false,
      "id_str" : "84436630",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/493764005752606720\/Jymz4Wty_normal.jpeg",
      "id" : 84436630,
      "verified" : false
    }
  },
  "id" : 140522640174624768,
  "created_at" : "2011-11-26 20:09:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SBA",
      "screen_name" : "SBAgov",
      "indices" : [ 3, 10 ],
      "id_str" : "153149305",
      "id" : 153149305
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SmallBizSat",
      "indices" : [ 103, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/gkCtBheM",
      "expanded_url" : "http:\/\/owl.li\/7FjJT",
      "display_url" : "owl.li\/7FjJT"
    } ]
  },
  "geo" : { },
  "id_str" : "140522086048350208",
  "text" : "RT @SBAgov: Today is Small Business Saturday! Support your community, shop local: http:\/\/t.co\/gkCtBheM #SmallBizSat Please RT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SmallBizSat",
        "indices" : [ 91, 103 ]
      } ],
      "urls" : [ {
        "indices" : [ 70, 90 ],
        "url" : "http:\/\/t.co\/gkCtBheM",
        "expanded_url" : "http:\/\/owl.li\/7FjJT",
        "display_url" : "owl.li\/7FjJT"
      } ]
    },
    "geo" : { },
    "id_str" : "140422067928563712",
    "text" : "Today is Small Business Saturday! Support your community, shop local: http:\/\/t.co\/gkCtBheM #SmallBizSat Please RT",
    "id" : 140422067928563712,
    "created_at" : "2011-11-26 13:30:04 +0000",
    "user" : {
      "name" : "SBA",
      "screen_name" : "SBAgov",
      "protected" : false,
      "id_str" : "153149305",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/637366120236756992\/ky6enEIv_normal.png",
      "id" : 153149305,
      "verified" : true
    }
  },
  "id" : 140522086048350208,
  "created_at" : "2011-11-26 20:07:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SmallBizSaturday",
      "indices" : [ 28, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140521812550352896",
  "text" : "RT @arneduncan: Celebrating #SmallBizSaturday w\/ coffee & hot chocolate at the Java Shack, & a delicious lunch at the Italian Store.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SmallBizSaturday",
        "indices" : [ 12, 29 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "140510926293049344",
    "text" : "Celebrating #SmallBizSaturday w\/ coffee & hot chocolate at the Java Shack, & a delicious lunch at the Italian Store.",
    "id" : 140510926293049344,
    "created_at" : "2011-11-26 19:23:10 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 140521812550352896,
  "created_at" : "2011-11-26 20:06:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/SSHqkBiU",
      "expanded_url" : "http:\/\/ow.ly\/7FczG",
      "display_url" : "ow.ly\/7FczG"
    } ]
  },
  "geo" : { },
  "id_str" : "140175441829965826",
  "text" : "If Congress doesn't act, taxes for the middle class will go up on Jan 1. Find out how much more you'll pay: http:\/\/t.co\/SSHqkBiU",
  "id" : 140175441829965826,
  "created_at" : "2011-11-25 21:10:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/WZDKVSRJ",
      "expanded_url" : "http:\/\/ow.ly\/7Fb1H",
      "display_url" : "ow.ly\/7Fb1H"
    } ]
  },
  "geo" : { },
  "id_str" : "140157832183021568",
  "text" : "West Wing Week: \"Your Best You\": This wk, Obama signs legislation to put vets back to work, pardons turkeys & more: http:\/\/t.co\/WZDKVSRJ",
  "id" : 140157832183021568,
  "created_at" : "2011-11-25 20:00:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BlackFriday",
      "indices" : [ 0, 12 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/1aEe1fjj",
      "expanded_url" : "http:\/\/ow.ly\/7Faqy",
      "display_url" : "ow.ly\/7Faqy"
    } ]
  },
  "geo" : { },
  "id_str" : "140142725738659840",
  "text" : "#BlackFriday bargains on mobile devices: Example of how increasing access to wireless broadband helps drive innovation: http:\/\/t.co\/1aEe1fjj",
  "id" : 140142725738659840,
  "created_at" : "2011-11-25 19:00:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "140129874521235456",
  "text" : "RT @JoiningForces: The First Lady made a surprise phone call to thank a military spouse. Watch the video & join us to say thanks: http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 131 ],
        "url" : "http:\/\/t.co\/qsdOrdes",
        "expanded_url" : "http:\/\/ow.ly\/7FbBG",
        "display_url" : "ow.ly\/7FbBG"
      } ]
    },
    "geo" : { },
    "id_str" : "140129120637026304",
    "text" : "The First Lady made a surprise phone call to thank a military spouse. Watch the video & join us to say thanks: http:\/\/t.co\/qsdOrdes",
    "id" : 140129120637026304,
    "created_at" : "2011-11-25 18:06:00 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 140129874521235456,
  "created_at" : "2011-11-25 18:09:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/hnYtW8Ci",
      "expanded_url" : "http:\/\/ow.ly\/7Fa6h",
      "display_url" : "ow.ly\/7Fa6h"
    } ]
  },
  "geo" : { },
  "id_str" : "140119835450413056",
  "text" : "On Thanksgiving, we\u2019re especially grateful for the men & women who defend our country. Weekly Address: http:\/\/t.co\/hnYtW8Ci",
  "id" : 140119835450413056,
  "created_at" : "2011-11-25 17:29:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/yLBubQZH",
      "expanded_url" : "http:\/\/ow.ly\/7ElSJ",
      "display_url" : "ow.ly\/7ElSJ"
    } ]
  },
  "geo" : { },
  "id_str" : "139840737117343746",
  "text" : "Have you said thanks yet? Let our troops & their families know how grateful we are for everything that they do: http:\/\/t.co\/yLBubQZH",
  "id" : 139840737117343746,
  "created_at" : "2011-11-24 23:00:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/f0R0ceyh",
      "expanded_url" : "http:\/\/bit.ly\/vrp3X3",
      "display_url" : "bit.ly\/vrp3X3"
    } ]
  },
  "geo" : { },
  "id_str" : "139795662240882689",
  "text" : "RT @petesouza: Photo of President Obama making Thanksgiving Day calls to US troops: http:\/\/t.co\/f0R0ceyh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 89 ],
        "url" : "http:\/\/t.co\/f0R0ceyh",
        "expanded_url" : "http:\/\/bit.ly\/vrp3X3",
        "display_url" : "bit.ly\/vrp3X3"
      } ]
    },
    "geo" : { },
    "id_str" : "139732685412237312",
    "text" : "Photo of President Obama making Thanksgiving Day calls to US troops: http:\/\/t.co\/f0R0ceyh",
    "id" : 139732685412237312,
    "created_at" : "2011-11-24 15:50:42 +0000",
    "user" : {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "protected" : false,
      "id_str" : "18215973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771916869808844800\/7d_poH48_normal.jpg",
      "id" : 18215973,
      "verified" : true
    }
  },
  "id" : 139795662240882689,
  "created_at" : "2011-11-24 20:00:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CapitalAreaFoodBank",
      "screen_name" : "foodbankmetrodc",
      "indices" : [ 80, 96 ],
      "id_str" : "17626836",
      "id" : 17626836
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/139792455519309825\/photo\/1",
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/AQ5r6o5h",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AfCkf2YCEAA4WwX.jpg",
      "id_str" : "139792455527698432",
      "id" : 139792455527698432,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AfCkf2YCEAA4WwX.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/AQ5r6o5h"
    } ],
    "hashtags" : [ {
      "text" : "Thanksgiving",
      "indices" : [ 100, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "139792455519309825",
  "text" : "Photo of the Day: The President, First Lady & daughters Sasha & Malia volunteer @foodbankmetrodc on #Thanksgiving eve: http:\/\/t.co\/AQ5r6o5h",
  "id" : 139792455519309825,
  "created_at" : "2011-11-24 19:48:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CapitalAreaFoodBank",
      "screen_name" : "foodbankmetrodc",
      "indices" : [ 3, 19 ],
      "id_str" : "17626836",
      "id" : 17626836
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 107, 118 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hunger",
      "indices" : [ 119, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/MPzKO8GU",
      "expanded_url" : "http:\/\/bit.ly\/vVUjoG",
      "display_url" : "bit.ly\/vVUjoG"
    } ]
  },
  "geo" : { },
  "id_str" : "139789583964581888",
  "text" : "RT @foodbankmetrodc: President Obama and Family Volunteer at Capital Area Food Bank - http:\/\/t.co\/MPzKO8GU @whitehouse #hunger",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.bravenewcode.com\/products\/wordtwit\" rel=\"nofollow\"\u003EWordTwit Plugin\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 86, 97 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "hunger",
        "indices" : [ 98, 105 ]
      } ],
      "urls" : [ {
        "indices" : [ 65, 85 ],
        "url" : "http:\/\/t.co\/MPzKO8GU",
        "expanded_url" : "http:\/\/bit.ly\/vVUjoG",
        "display_url" : "bit.ly\/vVUjoG"
      } ]
    },
    "geo" : { },
    "id_str" : "139475950550269952",
    "text" : "President Obama and Family Volunteer at Capital Area Food Bank - http:\/\/t.co\/MPzKO8GU @whitehouse #hunger",
    "id" : 139475950550269952,
    "created_at" : "2011-11-23 22:50:32 +0000",
    "user" : {
      "name" : "CapitalAreaFoodBank",
      "screen_name" : "foodbankmetrodc",
      "protected" : false,
      "id_str" : "17626836",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618784428781912064\/UTylVgTB_normal.jpg",
      "id" : 17626836,
      "verified" : false
    }
  },
  "id" : 139789583964581888,
  "created_at" : "2011-11-24 19:36:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House History",
      "screen_name" : "WhiteHouseHstry",
      "indices" : [ 3, 19 ],
      "id_str" : "106448460",
      "id" : 106448460
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Thanksgiving",
      "indices" : [ 27, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "139787627300782081",
  "text" : "RT @WhiteHouseHstry: Happy #Thanksgiving! Enjoy this show of turkeys who made it safely through the day thanks to a presidential repriev ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Thanksgiving",
        "indices" : [ 6, 19 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 137 ],
        "url" : "http:\/\/t.co\/Rd7NW0bI",
        "expanded_url" : "http:\/\/ow.ly\/7fHiS",
        "display_url" : "ow.ly\/7fHiS"
      } ]
    },
    "geo" : { },
    "id_str" : "139782898080415745",
    "text" : "Happy #Thanksgiving! Enjoy this show of turkeys who made it safely through the day thanks to a presidential reprieve http:\/\/t.co\/Rd7NW0bI",
    "id" : 139782898080415745,
    "created_at" : "2011-11-24 19:10:14 +0000",
    "user" : {
      "name" : "White House History",
      "screen_name" : "WhiteHouseHstry",
      "protected" : false,
      "id_str" : "106448460",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1877740109\/twittericonenlarged_normal.jpg",
      "id" : 106448460,
      "verified" : true
    }
  },
  "id" : 139787627300782081,
  "created_at" : "2011-11-24 19:29:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "139705988000395264",
  "text" : "RT @JoiningForces: There\u2019s no better time to let our servicemembers know how grateful we are for everything that they do. Say thanks: ht ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 135 ],
        "url" : "http:\/\/t.co\/bxtovYlr",
        "expanded_url" : "http:\/\/ow.ly\/7E1An",
        "display_url" : "ow.ly\/7E1An"
      } ]
    },
    "geo" : { },
    "id_str" : "139705910976192512",
    "text" : "There\u2019s no better time to let our servicemembers know how grateful we are for everything that they do. Say thanks: http:\/\/t.co\/bxtovYlr",
    "id" : 139705910976192512,
    "created_at" : "2011-11-24 14:04:19 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 139705988000395264,
  "created_at" : "2011-11-24 14:04:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/zwI5CaYf",
      "expanded_url" : "http:\/\/ow.ly\/7E16s",
      "display_url" : "ow.ly\/7E16s"
    } ]
  },
  "geo" : { },
  "id_str" : "139704472044716033",
  "text" : "\"From my family to yours, I\u2019d like to wish you a happy Thanksgiving\" -President Obama. Watch his message: http:\/\/t.co\/zwI5CaYf",
  "id" : 139704472044716033,
  "created_at" : "2011-11-24 13:58:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 55, 66 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "PBS",
      "screen_name" : "PBS",
      "indices" : [ 110, 114 ],
      "id_str" : "12133382",
      "id" : 12133382
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PBSipwh",
      "indices" : [ 115, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/H1hDIYMt",
      "expanded_url" : "http:\/\/ow.ly\/7DDW8",
      "display_url" : "ow.ly\/7DDW8"
    } ]
  },
  "geo" : { },
  "id_str" : "139521594438598658",
  "text" : "Behind the scenes: Country music in performance at the @WhiteHouse: http:\/\/t.co\/H1hDIYMt Show airs tonight on @PBS #PBSipwh",
  "id" : 139521594438598658,
  "created_at" : "2011-11-24 01:51:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PBS",
      "screen_name" : "PBS",
      "indices" : [ 3, 7 ],
      "id_str" : "12133382",
      "id" : 12133382
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 53, 64 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PBSipwh",
      "indices" : [ 90, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "139518794321231872",
  "text" : "RT @PBS: Reminder for tonight -- watch country music @whitehouse  Tonight at 8\/7c on PBS. #PBSipwh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 44, 55 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PBSipwh",
        "indices" : [ 81, 89 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "139482117326376960",
    "text" : "Reminder for tonight -- watch country music @whitehouse  Tonight at 8\/7c on PBS. #PBSipwh",
    "id" : 139482117326376960,
    "created_at" : "2011-11-23 23:15:02 +0000",
    "user" : {
      "name" : "PBS",
      "screen_name" : "PBS",
      "protected" : false,
      "id_str" : "12133382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/701812252425322499\/hmTCz_yg_normal.png",
      "id" : 12133382,
      "verified" : true
    }
  },
  "id" : 139518794321231872,
  "created_at" : "2011-11-24 01:40:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Carson",
      "screen_name" : "JonCarson44",
      "indices" : [ 3, 15 ],
      "id_str" : "1287388789",
      "id" : 1287388789
    }, {
      "name" : "HelloGiggles.com",
      "screen_name" : "hellogiggles",
      "indices" : [ 58, 71 ],
      "id_str" : "219682445",
      "id" : 219682445
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http:\/\/t.co\/JA03v1Aa",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2011\/11\/23\/giving-thanks",
      "display_url" : "whitehouse.gov\/blog\/2011\/11\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "139518202769190912",
  "text" : "RT @JonCarson44: Special Turkey Day Edition of WWTDG with @hellogiggles! http:\/\/t.co\/JA03v1Aa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "HelloGiggles.com",
        "screen_name" : "hellogiggles",
        "indices" : [ 41, 54 ],
        "id_str" : "219682445",
        "id" : 219682445
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 76 ],
        "url" : "http:\/\/t.co\/JA03v1Aa",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2011\/11\/23\/giving-thanks",
        "display_url" : "whitehouse.gov\/blog\/2011\/11\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "139452579078881280",
    "text" : "Special Turkey Day Edition of WWTDG with @hellogiggles! http:\/\/t.co\/JA03v1Aa",
    "id" : 139452579078881280,
    "created_at" : "2011-11-23 21:17:40 +0000",
    "user" : {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "protected" : false,
      "id_str" : "369232105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623146355767140352\/58sqoVrw_normal.jpg",
      "id" : 369232105,
      "verified" : true
    }
  },
  "id" : 139518202769190912,
  "created_at" : "2011-11-24 01:38:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "139449812780199936",
  "text" : "RT @whitehouseostp: How about Skyrim for STEM? Nat'l Video Game Challenge Open for Middle School, HS, College Students, & Educators! htt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 133 ],
        "url" : "http:\/\/t.co\/8Pf91BUd",
        "expanded_url" : "http:\/\/go.ostp.gov\/rr25yG",
        "display_url" : "go.ostp.gov\/rr25yG"
      } ]
    },
    "geo" : { },
    "id_str" : "139424289580527616",
    "text" : "How about Skyrim for STEM? Nat'l Video Game Challenge Open for Middle School, HS, College Students, & Educators! http:\/\/t.co\/8Pf91BUd",
    "id" : 139424289580527616,
    "created_at" : "2011-11-23 19:25:15 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 139449812780199936,
  "created_at" : "2011-11-23 21:06:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John B",
      "screen_name" : "bigbatjohn",
      "indices" : [ 3, 14 ],
      "id_str" : "38363939",
      "id" : 38363939
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHAsks",
      "indices" : [ 16, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "139420150892998656",
  "text" : "RT @bigbatjohn: #WHAsks how are you serving in your community? Our Scout Troop collected food donations Martha's Pantry. http:\/\/t.co\/OV4 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHAsks",
        "indices" : [ 0, 7 ]
      } ],
      "urls" : [ {
        "indices" : [ 105, 125 ],
        "url" : "http:\/\/t.co\/OV4PIVo5",
        "expanded_url" : "http:\/\/twitpic.com\/7ihe33",
        "display_url" : "twitpic.com\/7ihe33"
      } ]
    },
    "geo" : { },
    "id_str" : "139418084854349824",
    "text" : "#WHAsks how are you serving in your community? Our Scout Troop collected food donations Martha's Pantry. http:\/\/t.co\/OV4PIVo5",
    "id" : 139418084854349824,
    "created_at" : "2011-11-23 19:00:36 +0000",
    "user" : {
      "name" : "John B",
      "screen_name" : "bigbatjohn",
      "protected" : false,
      "id_str" : "38363939",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2896304279\/0a56251f7a4aba6db7aeeed9513f04d5_normal.jpeg",
      "id" : 38363939,
      "verified" : false
    }
  },
  "id" : 139420150892998656,
  "created_at" : "2011-11-23 19:08:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SmallBizSat",
      "indices" : [ 81, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/WjUFmrla",
      "expanded_url" : "http:\/\/ow.ly\/7Dho4",
      "display_url" : "ow.ly\/7Dho4"
    } ]
  },
  "geo" : { },
  "id_str" : "139418682362314753",
  "text" : "Support your local businesses on \u201CSmall Business Saturday\u201D: http:\/\/t.co\/WjUFmrla #SmallBizSat",
  "id" : 139418682362314753,
  "created_at" : "2011-11-23 19:02:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHAsks",
      "indices" : [ 89, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "139414287415386112",
  "text" : "Later today, the First Family is participating in a service project @ a local food bank. #WHAsks how are you serving in your community?",
  "id" : 139414287415386112,
  "created_at" : "2011-11-23 18:45:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    }, {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/rr7QfAif",
      "expanded_url" : "http:\/\/ow.ly\/7CXjg",
      "display_url" : "ow.ly\/7CXjg"
    } ]
  },
  "geo" : { },
  "id_str" : "139363556780023808",
  "text" : "Today, President Obama pardons Natl Thanksgiving Turkey. Watch live @ 10:30ET: http:\/\/t.co\/u95y7hhB History of pardon: http:\/\/t.co\/rr7QfAif",
  "id" : 139363556780023808,
  "created_at" : "2011-11-23 15:23:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "139361922297507840",
  "text" : "RT @pfeiffer44: We Can't Wait: President Obama will once again use his executive authority today - in this case pardoning two turkeys fo ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "139319431699501056",
    "text" : "We Can't Wait: President Obama will once again use his executive authority today - in this case pardoning two turkeys for Thanksgiving.",
    "id" : 139319431699501056,
    "created_at" : "2011-11-23 12:28:35 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 139361922297507840,
  "created_at" : "2011-11-23 15:17:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/mTsMZVlt",
      "expanded_url" : "http:\/\/ow.ly\/7CfqP",
      "display_url" : "ow.ly\/7CfqP"
    } ]
  },
  "geo" : { },
  "id_str" : "139110591229984769",
  "text" : "In 40 days, your taxes will go up -- unless Congress steps in to change that. President Obama talks taxes: http:\/\/t.co\/mTsMZVlt",
  "id" : 139110591229984769,
  "created_at" : "2011-11-22 22:38:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    }, {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 24, 38 ],
      "id_str" : "26278266",
      "id" : 26278266
    }, {
      "name" : "USO",
      "screen_name" : "the_USO",
      "indices" : [ 41, 49 ],
      "id_str" : "36681590",
      "id" : 36681590
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "139106497530568706",
  "text" : "RT @JoiningForces: Join @JoiningForces & @the_USO to say thanks to our troops & their families. Take a moment to show your support: http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Joining Forces",
        "screen_name" : "JoiningForces",
        "indices" : [ 5, 19 ],
        "id_str" : "26278266",
        "id" : 26278266
      }, {
        "name" : "USO",
        "screen_name" : "the_USO",
        "indices" : [ 22, 30 ],
        "id_str" : "36681590",
        "id" : 36681590
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 133 ],
        "url" : "http:\/\/t.co\/W1AdnbB9",
        "expanded_url" : "http:\/\/ow.ly\/7CeHt",
        "display_url" : "ow.ly\/7CeHt"
      } ]
    },
    "geo" : { },
    "id_str" : "139106411077574657",
    "text" : "Join @JoiningForces & @the_USO to say thanks to our troops & their families. Take a moment to show your support: http:\/\/t.co\/W1AdnbB9",
    "id" : 139106411077574657,
    "created_at" : "2011-11-22 22:22:07 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 139106497530568706,
  "created_at" : "2011-11-22 22:22:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 33, 44 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/Yx8aY1Dd",
      "expanded_url" : "http:\/\/ow.ly\/7CdN8",
      "display_url" : "ow.ly\/7CdN8"
    } ]
  },
  "geo" : { },
  "id_str" : "139102338890731520",
  "text" : "From the archive: Preview of the @WhiteHouse Turkey Pardon: http:\/\/t.co\/Yx8aY1Dd",
  "id" : 139102338890731520,
  "created_at" : "2011-11-22 22:05:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "139036947548094464",
  "text" : "RT @WHLive: Obama: Tell them \"Don't be a Grinch.\"  Don't vote to raise taxes on working Americans during the holidays. Put #CountryBefor ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CountryBeforeParty",
        "indices" : [ 111, 130 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "139036905181429764",
    "text" : "Obama: Tell them \"Don't be a Grinch.\"  Don't vote to raise taxes on working Americans during the holidays. Put #CountryBeforeParty.",
    "id" : 139036905181429764,
    "created_at" : "2011-11-22 17:45:56 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 139036947548094464,
  "created_at" : "2011-11-22 17:46:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "139036509000056832",
  "text" : "RT @WHLive: Obama: [Congress] should be doing everything they can to protect the middle class from tax hikes - not hike your taxes.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "139036457984733185",
    "text" : "Obama: [Congress] should be doing everything they can to protect the middle class from tax hikes - not hike your taxes.",
    "id" : 139036457984733185,
    "created_at" : "2011-11-22 17:44:09 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 139036509000056832,
  "created_at" : "2011-11-22 17:44:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "139036324215791616",
  "text" : "RT @WHLive: Obama: When push comes to shove, are you willing to fight as hard for the middle class as you do for the wealthiest Americans?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "139036284202123264",
    "text" : "Obama: When push comes to shove, are you willing to fight as hard for the middle class as you do for the wealthiest Americans?",
    "id" : 139036284202123264,
    "created_at" : "2011-11-22 17:43:27 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 139036324215791616,
  "created_at" : "2011-11-22 17:43:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/mNlAsTJS",
      "expanded_url" : "http:\/\/whitehouse.gov",
      "display_url" : "whitehouse.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "139035563612311552",
  "text" : "RT @WHLive: Obama: we've set up a straightforward tax calculator on http:\/\/t.co\/mNlAsTJS so you can see what each vote would mean for yo ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 76 ],
        "url" : "http:\/\/t.co\/mNlAsTJS",
        "expanded_url" : "http:\/\/whitehouse.gov",
        "display_url" : "whitehouse.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "139035526215905281",
    "text" : "Obama: we've set up a straightforward tax calculator on http:\/\/t.co\/mNlAsTJS so you can see what each vote would mean for your bottom line.",
    "id" : 139035526215905281,
    "created_at" : "2011-11-22 17:40:27 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 139035563612311552,
  "created_at" : "2011-11-22 17:40:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "139033877632126977",
  "text" : "RT @WHLive: Obama: We refused to quit. I said I'd do everything in my power to act on behalf of the American people - with or without Co ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "139033818081411072",
    "text" : "Obama: We refused to quit. I said I'd do everything in my power to act on behalf of the American people - with or without Congress.",
    "id" : 139033818081411072,
    "created_at" : "2011-11-22 17:33:40 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 139033877632126977,
  "created_at" : "2011-11-22 17:33:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 133, 140 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/g5ih2w0F",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "139029955320348672",
  "text" : "RT @WHLive: Starting soon: President Obama speaks on the American Jobs Act from Manchester, NH. Listen: http:\/\/t.co\/g5ih2w0F Follow: @WHLive",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "White House Live",
        "screen_name" : "WHLive",
        "indices" : [ 121, 128 ],
        "id_str" : "369505837",
        "id" : 369505837
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 112 ],
        "url" : "http:\/\/t.co\/g5ih2w0F",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "139029902602145792",
    "text" : "Starting soon: President Obama speaks on the American Jobs Act from Manchester, NH. Listen: http:\/\/t.co\/g5ih2w0F Follow: @WHLive",
    "id" : 139029902602145792,
    "created_at" : "2011-11-22 17:18:06 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 139029955320348672,
  "created_at" : "2011-11-22 17:18:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "indices" : [ 3, 16 ],
      "id_str" : "78138151",
      "id" : 78138151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "139007216316452866",
  "text" : "RT @lacasablanca: Si el Congreso no actua, los impuestos de la clase media subir\u00E1n el 1ero de enero. Vea cuanto m\u00E1s le costar\u00E1: http:\/\/t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 130 ],
        "url" : "http:\/\/t.co\/SgPOJuwI",
        "expanded_url" : "http:\/\/ow.ly\/7BExa",
        "display_url" : "ow.ly\/7BExa"
      } ]
    },
    "geo" : { },
    "id_str" : "139001116410126337",
    "text" : "Si el Congreso no actua, los impuestos de la clase media subir\u00E1n el 1ero de enero. Vea cuanto m\u00E1s le costar\u00E1: http:\/\/t.co\/SgPOJuwI",
    "id" : 139001116410126337,
    "created_at" : "2011-11-22 15:23:43 +0000",
    "user" : {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "protected" : false,
      "id_str" : "78138151",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616360382911754241\/4Tfqcfie_normal.png",
      "id" : 78138151,
      "verified" : true
    }
  },
  "id" : 139007216316452866,
  "created_at" : "2011-11-22 15:47:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AmericanJobsAct",
      "indices" : [ 4, 20 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/9tteM2it",
      "expanded_url" : "http:\/\/ow.ly\/7BDTj",
      "display_url" : "ow.ly\/7BDTj"
    } ]
  },
  "geo" : { },
  "id_str" : "138999699955908608",
  "text" : "The #AmericanJobsAct would expand existing tax cuts & put more money in your pocket. Try the tax calculator: http:\/\/t.co\/9tteM2it",
  "id" : 138999699955908608,
  "created_at" : "2011-11-22 15:18:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "138996255526363136",
  "text" : "RT @pfeiffer44: Economists say that failure to extend the payroll tax cut could be very harmful to the economy; will the GOP allow a $10 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "138956407839006720",
    "text" : "Economists say that failure to extend the payroll tax cut could be very harmful to the economy; will the GOP allow a $1000 tax increase?",
    "id" : 138956407839006720,
    "created_at" : "2011-11-22 12:26:03 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 138996255526363136,
  "created_at" : "2011-11-22 15:04:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/v8aZCthr",
      "expanded_url" : "http:\/\/ow.ly\/7Ba9o",
      "display_url" : "ow.ly\/7Ba9o"
    } ]
  },
  "geo" : { },
  "id_str" : "138934781336485888",
  "text" : "If Congress doesn't act, taxes for the middle class will go up on Jan 1. Find out how much\nmore you'll pay: http:\/\/t.co\/v8aZCthr",
  "id" : 138934781336485888,
  "created_at" : "2011-11-22 11:00:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alison Krauss",
      "screen_name" : "AlisonKrauss",
      "indices" : [ 58, 71 ],
      "id_str" : "19024308",
      "id" : 19024308
    }, {
      "name" : "Darius Rucker",
      "screen_name" : "dariusrucker",
      "indices" : [ 72, 85 ],
      "id_str" : "17074822",
      "id" : 17074822
    }, {
      "name" : "The Band Perry",
      "screen_name" : "thebandperry",
      "indices" : [ 86, 99 ],
      "id_str" : "19602869",
      "id" : 19602869
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AtTheWH",
      "indices" : [ 47, 55 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "138771480438775809",
  "text" : "Tune in @ 7:15ET: Country Music In Performance #AtTheWH w @alisonkrauss @dariusrucker @thebandperry & more. Watch live: http:\/\/t.co\/u95y7hhB",
  "id" : 138771480438775809,
  "created_at" : "2011-11-22 00:11:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HireHeroes",
      "indices" : [ 49, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/jj7o5XPQ",
      "expanded_url" : "http:\/\/ow.ly\/7AZG4",
      "display_url" : "ow.ly\/7AZG4"
    } ]
  },
  "geo" : { },
  "id_str" : "138768055789551616",
  "text" : "This morning, President Obama signed the \"VOW to #HireHeroes Act\" into law: http:\/\/t.co\/jj7o5XPQ",
  "id" : 138768055789551616,
  "created_at" : "2011-11-21 23:57:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "138762538409140225",
  "text" : "RT @pfeiffer44: Facts: Democrats were willing to do tough things on entitlements; Republicans insisted on extending $800b of tax cuts fo ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "138759317439528960",
    "text" : "Facts: Democrats were willing to do tough things on entitlements; Republicans insisted on extending $800b of tax cuts for wealthiest 2%",
    "id" : 138759317439528960,
    "created_at" : "2011-11-21 23:22:53 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 138762538409140225,
  "created_at" : "2011-11-21 23:35:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "138751184335941633",
  "text" : "RT @WHLive: Obama: If we don\u2019t act, taxes will go up for every American starting next year. I\u2019m not about to let that happen.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "138751149732925440",
    "text" : "Obama: If we don\u2019t act, taxes will go up for every American starting next year. I\u2019m not about to let that happen.",
    "id" : 138751149732925440,
    "created_at" : "2011-11-21 22:50:26 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 138751184335941633,
  "created_at" : "2011-11-21 22:50:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "138750756839890944",
  "text" : "RT @WHLive: President Obama: I will veto of any effort to get rid of these automatic cuts to domestic & defense spending: http:\/\/t.co\/tO ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 130 ],
        "url" : "http:\/\/t.co\/tOVqQ5CT",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
        "display_url" : "whitehouse.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "138750711256199169",
    "text" : "President Obama: I will veto of any effort to get rid of these automatic cuts to domestic & defense spending: http:\/\/t.co\/tOVqQ5CT",
    "id" : 138750711256199169,
    "created_at" : "2011-11-21 22:48:42 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 138750756839890944,
  "created_at" : "2011-11-21 22:48:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/QDIpMRKE",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
      "display_url" : "whitehouse.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "138750162834178049",
  "text" : "Happening now: President Obama delivers a statement to the press. Watch now: http:\/\/t.co\/QDIpMRKE",
  "id" : 138750162834178049,
  "created_at" : "2011-11-21 22:46:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/hhNoX4fh",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "138746562816917504",
  "text" : "Happening @ 5:45ET: President Obama will deliver a statement to the press. Watch live: http:\/\/t.co\/hhNoX4fh",
  "id" : 138746562816917504,
  "created_at" : "2011-11-21 22:32:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "veteran",
      "indices" : [ 83, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/DCbEDxRc",
      "expanded_url" : "http:\/\/ow.ly\/7ATwG",
      "display_url" : "ow.ly\/7ATwG"
    } ]
  },
  "geo" : { },
  "id_str" : "138737376745885697",
  "text" : "\"Today, the message is simple: For businesses out there, if you are hiring, hire a #veteran\" -Pres Obama @ bill signing http:\/\/t.co\/DCbEDxRc",
  "id" : 138737376745885697,
  "created_at" : "2011-11-21 21:55:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SBA",
      "screen_name" : "SBAgov",
      "indices" : [ 3, 10 ],
      "id_str" : "153149305",
      "id" : 153149305
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 119, 130 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SmallBizSat",
      "indices" : [ 106, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/11FmlEBz",
      "expanded_url" : "http:\/\/owl.li\/7AMi7",
      "display_url" : "owl.li\/7AMi7"
    } ]
  },
  "geo" : { },
  "id_str" : "138719860866813952",
  "text" : "RT @SBAgov: November 26th is Small Business Saturday! Learn how you can participate: http:\/\/t.co\/11FmlEBz #SmallBizSat @whitehouse",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 107, 118 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SmallBizSat",
        "indices" : [ 94, 106 ]
      } ],
      "urls" : [ {
        "indices" : [ 73, 93 ],
        "url" : "http:\/\/t.co\/11FmlEBz",
        "expanded_url" : "http:\/\/owl.li\/7AMi7",
        "display_url" : "owl.li\/7AMi7"
      } ]
    },
    "geo" : { },
    "id_str" : "138715845441486849",
    "text" : "November 26th is Small Business Saturday! Learn how you can participate: http:\/\/t.co\/11FmlEBz #SmallBizSat @whitehouse",
    "id" : 138715845441486849,
    "created_at" : "2011-11-21 20:30:09 +0000",
    "user" : {
      "name" : "SBA",
      "screen_name" : "SBAgov",
      "protected" : false,
      "id_str" : "153149305",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/637366120236756992\/ky6enEIv_normal.png",
      "id" : 153149305,
      "verified" : true
    }
  },
  "id" : 138719860866813952,
  "created_at" : "2011-11-21 20:46:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/138700255742009347\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/7v5hMmbm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AezDJdJCIAAACoR.jpg",
      "id_str" : "138700255750397952",
      "id" : 138700255750397952,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AezDJdJCIAAACoR.jpg",
      "sizes" : [ {
        "h" : 315,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 315,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 315,
        "resize" : "fit",
        "w" : 560
      } ],
      "display_url" : "pic.twitter.com\/7v5hMmbm"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/4MtMcwiq",
      "expanded_url" : "http:\/\/ow.ly\/7AJbm",
      "display_url" : "ow.ly\/7AJbm"
    } ]
  },
  "geo" : { },
  "id_str" : "138700255742009347",
  "text" : "1 million. The # of service members transitioning back into civilian workforce over the next 5yrs: http:\/\/t.co\/4MtMcwiq http:\/\/t.co\/7v5hMmbm",
  "id" : 138700255742009347,
  "created_at" : "2011-11-21 19:28:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AtTheWH",
      "indices" : [ 57, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/hhNoX4fh",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "138696838126637056",
  "text" : "Happening now: County Music Workshop with local students #AtTheWH. Watch live: http:\/\/t.co\/hhNoX4fh",
  "id" : 138696838126637056,
  "created_at" : "2011-11-21 19:14:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "veterans",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "138651465702064128",
  "text" : "Happening now: President Obama speaks & signs legislation to help put #veterans back to work. Watch: http:\/\/t.co\/u95y7hhB",
  "id" : 138651465702064128,
  "created_at" : "2011-11-21 16:14:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/f5CaJ4pg",
      "expanded_url" : "http:\/\/go.usa.gov\/IsC",
      "display_url" : "go.usa.gov\/IsC"
    } ]
  },
  "geo" : { },
  "id_str" : "138633749809201152",
  "text" : "RT @arneduncan: Philly music teacher has $100 budget for 7 schools. Solution: bucket drumming. Watch here: http:\/\/t.co\/f5CaJ4pg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 111 ],
        "url" : "http:\/\/t.co\/f5CaJ4pg",
        "expanded_url" : "http:\/\/go.usa.gov\/IsC",
        "display_url" : "go.usa.gov\/IsC"
      } ]
    },
    "geo" : { },
    "id_str" : "138630205152575488",
    "text" : "Philly music teacher has $100 budget for 7 schools. Solution: bucket drumming. Watch here: http:\/\/t.co\/f5CaJ4pg",
    "id" : 138630205152575488,
    "created_at" : "2011-11-21 14:49:51 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 138633749809201152,
  "created_at" : "2011-11-21 15:03:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "veterans",
      "indices" : [ 80, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "138630060902068224",
  "text" : "Today, President Obama will sign legislation to provide tax credits to help put #veterans back to work. Watch @ 11ET: http:\/\/t.co\/u95y7hhB",
  "id" : 138630060902068224,
  "created_at" : "2011-11-21 14:49:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASCAR",
      "screen_name" : "NASCAR",
      "indices" : [ 3, 10 ],
      "id_str" : "49153854",
      "id" : 49153854
    }, {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 102, 116 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NASCAR",
      "indices" : [ 89, 96 ]
    }, {
      "text" : "USA",
      "indices" : [ 97, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/WO2TFJyz",
      "expanded_url" : "http:\/\/ow.ly\/7zFBN",
      "display_url" : "ow.ly\/7zFBN"
    } ]
  },
  "geo" : { },
  "id_str" : "138382200327516161",
  "text" : "MT @NASCAR The First Lady tells military families that the entire country is behind them #NASCAR #USA @joiningforces http:\/\/t.co\/WO2TFJyz",
  "id" : 138382200327516161,
  "created_at" : "2011-11-20 22:24:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/4s2LEq6J",
      "expanded_url" : "http:\/\/ow.ly\/7zF6I",
      "display_url" : "ow.ly\/7zF6I"
    } ]
  },
  "geo" : { },
  "id_str" : "138380626981175296",
  "text" : "WEEKLY ADDRESS: From Indonesia, the President talks about creating an economy that\u2019s built to last & built to compete: http:\/\/t.co\/4s2LEq6J",
  "id" : 138380626981175296,
  "created_at" : "2011-11-20 22:18:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House Blog",
      "screen_name" : "blog44",
      "indices" : [ 3, 10 ],
      "id_str" : "278776049",
      "id" : 278776049
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 32 ],
      "url" : "http:\/\/t.co\/HxTO58SB",
      "expanded_url" : "http:\/\/WH.gov",
      "display_url" : "WH.gov"
    }, {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/yMXuR84b",
      "expanded_url" : "http:\/\/goo.gl\/fb\/GBFDe",
      "display_url" : "goo.gl\/fb\/GBFDe"
    } ]
  },
  "geo" : { },
  "id_str" : "138062574662066177",
  "text" : "RT @blog44: http:\/\/t.co\/HxTO58SB: Weekly Address: Creating an Economy Built to Last http:\/\/t.co\/yMXuR84b",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 20 ],
        "url" : "http:\/\/t.co\/HxTO58SB",
        "expanded_url" : "http:\/\/WH.gov",
        "display_url" : "WH.gov"
      }, {
        "indices" : [ 72, 92 ],
        "url" : "http:\/\/t.co\/yMXuR84b",
        "expanded_url" : "http:\/\/goo.gl\/fb\/GBFDe",
        "display_url" : "goo.gl\/fb\/GBFDe"
      } ]
    },
    "geo" : { },
    "id_str" : "137877346802868224",
    "text" : "http:\/\/t.co\/HxTO58SB: Weekly Address: Creating an Economy Built to Last http:\/\/t.co\/yMXuR84b",
    "id" : 137877346802868224,
    "created_at" : "2011-11-19 12:58:15 +0000",
    "user" : {
      "name" : "The White House Blog",
      "screen_name" : "blog44",
      "protected" : false,
      "id_str" : "278776049",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1303743170\/Screen_shot_2011-04-07_at_7.54.18_PM_normal.png",
      "id" : 278776049,
      "verified" : true
    }
  },
  "id" : 138062574662066177,
  "created_at" : "2011-11-20 01:14:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 19, 22 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/0Ogz8DJ7",
      "expanded_url" : "http:\/\/ow.ly\/7yreq",
      "display_url" : "ow.ly\/7yreq"
    } ]
  },
  "geo" : { },
  "id_str" : "137647102758109184",
  "text" : "From the Archives: @VP Biden tells teens \"It Gets Better.\" Video: http:\/\/t.co\/0Ogz8DJ7",
  "id" : 137647102758109184,
  "created_at" : "2011-11-18 21:43:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 85, 95 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/hWsCmDBR",
      "expanded_url" : "http:\/\/ow.ly\/7yk9W",
      "display_url" : "ow.ly\/7yk9W"
    } ]
  },
  "geo" : { },
  "id_str" : "137621723897008128",
  "text" : "New WH photo gallery: President Obama's visit to Australia: http:\/\/t.co\/hWsCmDBR via @petesouza",
  "id" : 137621723897008128,
  "created_at" : "2011-11-18 20:02:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/2fzJfV5A",
      "expanded_url" : "http:\/\/ow.ly\/7yjDt",
      "display_url" : "ow.ly\/7yjDt"
    } ]
  },
  "geo" : { },
  "id_str" : "137619073214324737",
  "text" : "We'll be back next week w\/ a special edition of West Wing Week -- for now, check out a few clips from the road: http:\/\/t.co\/2fzJfV5A",
  "id" : 137619073214324737,
  "created_at" : "2011-11-18 19:51:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 3, 13 ],
      "id_str" : "9624742",
      "id" : 9624742
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SecClinton",
      "indices" : [ 43, 54 ]
    }, {
      "text" : "Burma",
      "indices" : [ 64, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "137580621705916416",
  "text" : "RT @StateDept: President Obama: I've asked #SecClinton to go to #Burma -- the first U.S. Secretary of State to travel there in over half ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SecClinton",
        "indices" : [ 28, 39 ]
      }, {
        "text" : "Burma",
        "indices" : [ 49, 55 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "137578002480508928",
    "text" : "President Obama: I've asked #SecClinton to go to #Burma -- the first U.S. Secretary of State to travel there in over half a century.",
    "id" : 137578002480508928,
    "created_at" : "2011-11-18 17:08:46 +0000",
    "user" : {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "protected" : false,
      "id_str" : "9624742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724612605185282048\/1rEfkXDZ_normal.jpg",
      "id" : 9624742,
      "verified" : true
    }
  },
  "id" : 137580621705916416,
  "created_at" : "2011-11-18 17:19:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 3, 13 ],
      "id_str" : "9624742",
      "id" : 9624742
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Burma",
      "indices" : [ 92, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/Y9jHwKMK",
      "expanded_url" : "http:\/\/go.usa.gov\/Ifp",
      "display_url" : "go.usa.gov\/Ifp"
    } ]
  },
  "geo" : { },
  "id_str" : "137580419297198080",
  "text" : "RT @StateDept: President Obama: After years of darkness, we've seen flickers of progress in #Burma. http:\/\/t.co\/Y9jHwKMK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Burma",
        "indices" : [ 77, 83 ]
      } ],
      "urls" : [ {
        "indices" : [ 85, 105 ],
        "url" : "http:\/\/t.co\/Y9jHwKMK",
        "expanded_url" : "http:\/\/go.usa.gov\/Ifp",
        "display_url" : "go.usa.gov\/Ifp"
      } ]
    },
    "geo" : { },
    "id_str" : "137576972858568704",
    "text" : "President Obama: After years of darkness, we've seen flickers of progress in #Burma. http:\/\/t.co\/Y9jHwKMK",
    "id" : 137576972858568704,
    "created_at" : "2011-11-18 17:04:41 +0000",
    "user" : {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "protected" : false,
      "id_str" : "9624742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724612605185282048\/1rEfkXDZ_normal.jpg",
      "id" : 9624742,
      "verified" : true
    }
  },
  "id" : 137580419297198080,
  "created_at" : "2011-11-18 17:18:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/137559579004379138\/photo\/1",
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/sos0UIp0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Aei1tVKCIAAPFbS.jpg",
      "id_str" : "137559579012767744",
      "id" : 137559579012767744,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Aei1tVKCIAAPFbS.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/sos0UIp0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "137559579004379138",
  "text" : "Photo of the Day: President Obama waves to people in the gallery after addressing Australian Parliament: http:\/\/t.co\/sos0UIp0",
  "id" : 137559579004379138,
  "created_at" : "2011-11-18 15:55:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Carson",
      "screen_name" : "JonCarson44",
      "indices" : [ 3, 15 ],
      "id_str" : "1287388789",
      "id" : 1287388789
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 59, 70 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "Immediate Capital",
      "screen_name" : "HildaSolisDOL",
      "indices" : [ 89, 103 ],
      "id_str" : "2187968017",
      "id" : 2187968017
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "137536681564844032",
  "text" : "RT @JonCarson44: Having a Women and the Economy forum here @Whitehouse today - thanks to @HildaSolisDOL for leading it!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 42, 53 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "Immediate Capital",
        "screen_name" : "HildaSolisDOL",
        "indices" : [ 72, 86 ],
        "id_str" : "2187968017",
        "id" : 2187968017
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "137535157530923008",
    "text" : "Having a Women and the Economy forum here @Whitehouse today - thanks to @HildaSolisDOL for leading it!",
    "id" : 137535157530923008,
    "created_at" : "2011-11-18 14:18:31 +0000",
    "user" : {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "protected" : false,
      "id_str" : "369232105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623146355767140352\/58sqoVrw_normal.jpg",
      "id" : 369232105,
      "verified" : true
    }
  },
  "id" : 137536681564844032,
  "created_at" : "2011-11-18 14:24:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/137305122031157248\/photo\/1",
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/SM9zm8Ip",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AefOR_ECQAA86ng.jpg",
      "id_str" : "137305122039545856",
      "id" : 137305122039545856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AefOR_ECQAA86ng.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      } ],
      "display_url" : "pic.twitter.com\/SM9zm8Ip"
    } ],
    "hashtags" : [ {
      "text" : "GASO2011",
      "indices" : [ 84, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/GQYAqBUh",
      "expanded_url" : "http:\/\/ow.ly\/7xeyy",
      "display_url" : "ow.ly\/7xeyy"
    } ]
  },
  "geo" : { },
  "id_str" : "137305122031157248",
  "text" : "43,000 people die each year as a result of smoking cigarettes. http:\/\/t.co\/GQYAqBUh #GASO2011 http:\/\/t.co\/SM9zm8Ip",
  "id" : 137305122031157248,
  "created_at" : "2011-11-17 23:04:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sierra Club Live",
      "screen_name" : "SierraClubLive",
      "indices" : [ 3, 18 ],
      "id_str" : "54309568",
      "id" : 54309568
    }, {
      "name" : "Jon Carson",
      "screen_name" : "JonCarson44",
      "indices" : [ 111, 123 ],
      "id_str" : "1287388789",
      "id" : 1287388789
    }, {
      "name" : "Speedy Cash",
      "screen_name" : "Sierra_Club",
      "indices" : [ 126, 138 ],
      "id_str" : "2212516765",
      "id" : 2212516765
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cleancars",
      "indices" : [ 87, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "137268573335846916",
  "text" : "RT @SierraClubLive: Live from the West Wing it's Thurs afternoon! Send your Q's on new #cleancars standards to @JonCarson44 & @Sierra_Club!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jon Carson",
        "screen_name" : "JonCarson44",
        "indices" : [ 91, 103 ],
        "id_str" : "1287388789",
        "id" : 1287388789
      }, {
        "name" : "Speedy Cash",
        "screen_name" : "Sierra_Club",
        "indices" : [ 106, 118 ],
        "id_str" : "2212516765",
        "id" : 2212516765
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "cleancars",
        "indices" : [ 67, 77 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "137267396271538176",
    "text" : "Live from the West Wing it's Thurs afternoon! Send your Q's on new #cleancars standards to @JonCarson44 & @Sierra_Club!",
    "id" : 137267396271538176,
    "created_at" : "2011-11-17 20:34:32 +0000",
    "user" : {
      "name" : "Sierra Club Live",
      "screen_name" : "SierraClubLive",
      "protected" : false,
      "id_str" : "54309568",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/707976578286755840\/Bborj_nC_normal.jpg",
      "id" : 54309568,
      "verified" : false
    }
  },
  "id" : 137268573335846916,
  "created_at" : "2011-11-17 20:39:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/137258150561726464\/photo\/1",
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/a4U8tRki",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Aeejj4sCQAE0KBX.jpg",
      "id_str" : "137258150565920769",
      "id" : 137258150565920769,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Aeejj4sCQAE0KBX.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/a4U8tRki"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/y78JXRZD",
      "expanded_url" : "http:\/\/1.usa.gov\/w1VboW",
      "display_url" : "1.usa.gov\/w1VboW"
    } ]
  },
  "geo" : { },
  "id_str" : "137258150561726464",
  "text" : "\"History is on the side of the free\" -President Obama addresses Australian Parliament: http:\/\/t.co\/y78JXRZD Pic: http:\/\/t.co\/a4U8tRki",
  "id" : 137258150561726464,
  "created_at" : "2011-11-17 19:57:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SAVEAward",
      "indices" : [ 27, 37 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/D2qCklxi",
      "expanded_url" : "http:\/\/wh.gov\/save-award",
      "display_url" : "wh.gov\/save-award"
    } ]
  },
  "geo" : { },
  "id_str" : "137193156843282432",
  "text" : "Vote now for your favorite #SAVEAward idea. Winner will meet the President to discuss. Voting closes @ 12ET: http:\/\/t.co\/D2qCklxi",
  "id" : 137193156843282432,
  "created_at" : "2011-11-17 15:39:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelly Wallace",
      "screen_name" : "kellywallacetv",
      "indices" : [ 3, 18 ],
      "id_str" : "21411381",
      "id" : 21411381
    }, {
      "name" : "iVillage",
      "screen_name" : "iVillage",
      "indices" : [ 37, 46 ],
      "id_str" : "39293968",
      "id" : 39293968
    }, {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "indices" : [ 59, 66 ],
      "id_str" : "44783853",
      "id" : 44783853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "137192306393624577",
  "text" : "RT @kellywallacetv: On train to DC 4 @iVillage live intv w\/@HHSGov at 1245p.  Any more suggested q's on smoking or other topics?   www.i ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "iVillage",
        "screen_name" : "iVillage",
        "indices" : [ 17, 26 ],
        "id_str" : "39293968",
        "id" : 39293968
      }, {
        "name" : "HHS.gov",
        "screen_name" : "HHSGov",
        "indices" : [ 39, 46 ],
        "id_str" : "44783853",
        "id" : 44783853
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "137180314144473088",
    "text" : "On train to DC 4 @iVillage live intv w\/@HHSGov at 1245p.  Any more suggested q's on smoking or other topics?   www.ivllage.com\/livechat",
    "id" : 137180314144473088,
    "created_at" : "2011-11-17 14:48:30 +0000",
    "user" : {
      "name" : "Kelly Wallace",
      "screen_name" : "kellywallacetv",
      "protected" : false,
      "id_str" : "21411381",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/223570280\/kwallace_normal.jpg",
      "id" : 21411381,
      "verified" : false
    }
  },
  "id" : 137192306393624577,
  "created_at" : "2011-11-17 15:36:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "indices" : [ 3, 12 ],
      "id_str" : "337742544",
      "id" : 337742544
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SAVEAward",
      "indices" : [ 42, 52 ]
    }, {
      "text" : "cuttingwaste",
      "indices" : [ 107, 120 ]
    }, {
      "text" : "Gov20",
      "indices" : [ 121, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/2wLWyAm5",
      "expanded_url" : "http:\/\/1.usa.gov\/92Yv8T",
      "display_url" : "1.usa.gov\/92Yv8T"
    } ]
  },
  "geo" : { },
  "id_str" : "137181221544407040",
  "text" : "RT @OMBPress: Last chance to vote for '11 #SAVEAward! Voting closes today at 12PM ET; http:\/\/t.co\/2wLWyAm5 #cuttingwaste #Gov20",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SAVEAward",
        "indices" : [ 28, 38 ]
      }, {
        "text" : "cuttingwaste",
        "indices" : [ 93, 106 ]
      }, {
        "text" : "Gov20",
        "indices" : [ 107, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 72, 92 ],
        "url" : "http:\/\/t.co\/2wLWyAm5",
        "expanded_url" : "http:\/\/1.usa.gov\/92Yv8T",
        "display_url" : "1.usa.gov\/92Yv8T"
      } ]
    },
    "geo" : { },
    "id_str" : "137178456394973184",
    "text" : "Last chance to vote for '11 #SAVEAward! Voting closes today at 12PM ET; http:\/\/t.co\/2wLWyAm5 #cuttingwaste #Gov20",
    "id" : 137178456394973184,
    "created_at" : "2011-11-17 14:41:07 +0000",
    "user" : {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "protected" : false,
      "id_str" : "337742544",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1449289379\/OMB_Seal_normal.jpg",
      "id" : 337742544,
      "verified" : true
    }
  },
  "id" : 137181221544407040,
  "created_at" : "2011-11-17 14:52:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GASO2011",
      "indices" : [ 128, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/UYTmxSHH",
      "expanded_url" : "http:\/\/youtu.be\/yd-gboZJYZ0",
      "display_url" : "youtu.be\/yd-gboZJYZ0"
    } ]
  },
  "geo" : { },
  "id_str" : "137175623465582592",
  "text" : "Congratulations to everyone taking part in today's Great American Smokeout. Watch the President's message: http:\/\/t.co\/UYTmxSHH #GASO2011",
  "id" : 137175623465582592,
  "created_at" : "2011-11-17 14:29:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "veterans",
      "indices" : [ 87, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/SBOts9Eg",
      "expanded_url" : "http:\/\/ow.ly\/7vVlh",
      "display_url" : "ow.ly\/7vVlh"
    } ]
  },
  "geo" : { },
  "id_str" : "136955412372127746",
  "text" : "\"This is a good first step\" -President Obama on the passage of tax credits to help get #veterans back to work: http:\/\/t.co\/SBOts9Eg",
  "id" : 136955412372127746,
  "created_at" : "2011-11-16 23:54:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "We the People",
      "screen_name" : "wethepeople",
      "indices" : [ 3, 15 ],
      "id_str" : "369507958",
      "id" : 369507958
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http:\/\/t.co\/6suinCPP",
      "expanded_url" : "http:\/\/ow.ly\/7w4Cd",
      "display_url" : "ow.ly\/7w4Cd"
    } ]
  },
  "geo" : { },
  "id_str" : "136949112837914626",
  "text" : "RT @wethepeople: NEW RESPONSE: Protecting the Air We Breathe: http:\/\/t.co\/6suinCPP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 65 ],
        "url" : "http:\/\/t.co\/6suinCPP",
        "expanded_url" : "http:\/\/ow.ly\/7w4Cd",
        "display_url" : "ow.ly\/7w4Cd"
      } ]
    },
    "geo" : { },
    "id_str" : "136949045489967104",
    "text" : "NEW RESPONSE: Protecting the Air We Breathe: http:\/\/t.co\/6suinCPP",
    "id" : 136949045489967104,
    "created_at" : "2011-11-16 23:29:31 +0000",
    "user" : {
      "name" : "We the People",
      "screen_name" : "wethepeople",
      "protected" : false,
      "id_str" : "369507958",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1608012795\/tw_share_normal.png",
      "id" : 369507958,
      "verified" : true
    }
  },
  "id" : 136949112837914626,
  "created_at" : "2011-11-16 23:29:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "136943538112958464",
  "text" : "Happening @ 6:15ET: President Obama addresses Australian Parliament in Canberra, Australia. Watch live: http:\/\/t.co\/u95y7hhB",
  "id" : 136943538112958464,
  "created_at" : "2011-11-16 23:07:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "indices" : [ 3, 10 ],
      "id_str" : "44783853",
      "id" : 44783853
    }, {
      "name" : "iVillage",
      "screen_name" : "iVillage",
      "indices" : [ 67, 76 ],
      "id_str" : "39293968",
      "id" : 39293968
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "136936546329837569",
  "text" : "RT @HHSGov: Submit your Q's for tmrw's LIVE chat w\/ Sec Sebelius & @iVillage in honor of the Great American Smokeout http:\/\/t.co\/hkPLTe1 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "iVillage",
        "screen_name" : "iVillage",
        "indices" : [ 55, 64 ],
        "id_str" : "39293968",
        "id" : 39293968
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "quitsmoking",
        "indices" : [ 126, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 105, 125 ],
        "url" : "http:\/\/t.co\/hkPLTe1O",
        "expanded_url" : "http:\/\/1.usa.gov\/tZgpKv",
        "display_url" : "1.usa.gov\/tZgpKv"
      } ]
    },
    "geo" : { },
    "id_str" : "136910976095227904",
    "text" : "Submit your Q's for tmrw's LIVE chat w\/ Sec Sebelius & @iVillage in honor of the Great American Smokeout http:\/\/t.co\/hkPLTe1O #quitsmoking",
    "id" : 136910976095227904,
    "created_at" : "2011-11-16 20:58:15 +0000",
    "user" : {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "protected" : false,
      "id_str" : "44783853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567350542326718464\/FXOsgyA7_normal.jpeg",
      "id" : 44783853,
      "verified" : true
    }
  },
  "id" : 136936546329837569,
  "created_at" : "2011-11-16 22:39:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "136888482634280960",
  "text" : "RT @pfeiffer44: Good News: the Veterans tax Credit from the President's Jobs Act appears headed for passage in the House today.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "136887813290467328",
    "text" : "Good News: the Veterans tax Credit from the President's Jobs Act appears headed for passage in the House today.",
    "id" : 136887813290467328,
    "created_at" : "2011-11-16 19:26:12 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 136888482634280960,
  "created_at" : "2011-11-16 19:28:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/cqhzs38e",
      "expanded_url" : "http:\/\/ow.ly\/7vL72",
      "display_url" : "ow.ly\/7vL72"
    } ]
  },
  "geo" : { },
  "id_str" : "136877146672087041",
  "text" : "We can\u2019t wait for an increasingly dysfunctional Congress to do its job, so Obama will continue to act where they won't: http:\/\/t.co\/cqhzs38e",
  "id" : 136877146672087041,
  "created_at" : "2011-11-16 18:43:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/KhI6Oazv",
      "expanded_url" : "http:\/\/ow.ly\/7vKYO",
      "display_url" : "ow.ly\/7vKYO"
    } ]
  },
  "geo" : { },
  "id_str" : "136876787635458049",
  "text" : "We Can\u2019t Wait: Historic fuel economy standards will reduce dependence on oil & save consumers $ at the pump: http:\/\/t.co\/KhI6Oazv",
  "id" : 136876787635458049,
  "created_at" : "2011-11-16 18:42:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brandon Routh",
      "screen_name" : "BrandonJRouth",
      "indices" : [ 3, 17 ],
      "id_str" : "204137620",
      "id" : 204137620
    }, {
      "name" : "CNCS",
      "screen_name" : "NationalService",
      "indices" : [ 43, 59 ],
      "id_str" : "17961886",
      "id" : 17961886
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "volunteering",
      "indices" : [ 62, 75 ]
    }, {
      "text" : "BrandonJRouthWH",
      "indices" : [ 112, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "136853894935478272",
  "text" : "RT @BrandonJRouth: Send your Q's now about @nationalservice & #volunteering & get the A's tomorrow. Tweet me or #BrandonJRouthWH or @Jon ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CNCS",
        "screen_name" : "NationalService",
        "indices" : [ 24, 40 ],
        "id_str" : "17961886",
        "id" : 17961886
      }, {
        "name" : "Jon Carson",
        "screen_name" : "JonCarson44",
        "indices" : [ 113, 125 ],
        "id_str" : "1287388789",
        "id" : 1287388789
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "volunteering",
        "indices" : [ 43, 56 ]
      }, {
        "text" : "BrandonJRouthWH",
        "indices" : [ 93, 109 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "136626519626878976",
    "text" : "Send your Q's now about @nationalservice & #volunteering & get the A's tomorrow. Tweet me or #BrandonJRouthWH or @JonCarson44 to take part.",
    "id" : 136626519626878976,
    "created_at" : "2011-11-16 02:07:55 +0000",
    "user" : {
      "name" : "Brandon Routh",
      "screen_name" : "BrandonJRouth",
      "protected" : false,
      "id_str" : "204137620",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/520065487586074624\/FkmCbpdo_normal.jpeg",
      "id" : 204137620,
      "verified" : true
    }
  },
  "id" : 136853894935478272,
  "created_at" : "2011-11-16 17:11:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "indices" : [ 3, 12 ],
      "id_str" : "337742544",
      "id" : 337742544
    }, {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "indices" : [ 14, 22 ],
      "id_str" : "807095",
      "id" : 807095
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "supercommittee",
      "indices" : [ 35, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "136850025698435072",
  "text" : "RT @OMBPress: @nytimes Friedman on #supercommittee \"does anyone know what Pres. Obama's preferred outcome is?\" Sure do. 80pgs of it. htt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The New York Times",
        "screen_name" : "nytimes",
        "indices" : [ 0, 8 ],
        "id_str" : "807095",
        "id" : 807095
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "supercommittee",
        "indices" : [ 21, 36 ]
      } ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/YC5Qj9rW",
        "expanded_url" : "http:\/\/ht.ly\/7vtEC",
        "display_url" : "ht.ly\/7vtEC"
      } ]
    },
    "geo" : { },
    "id_str" : "136829892858880000",
    "in_reply_to_user_id" : 807095,
    "text" : "@nytimes Friedman on #supercommittee \"does anyone know what Pres. Obama's preferred outcome is?\" Sure do. 80pgs of it. http:\/\/t.co\/YC5Qj9rW",
    "id" : 136829892858880000,
    "created_at" : "2011-11-16 15:36:03 +0000",
    "in_reply_to_screen_name" : "nytimes",
    "in_reply_to_user_id_str" : "807095",
    "user" : {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "protected" : false,
      "id_str" : "337742544",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1449289379\/OMB_Seal_normal.jpg",
      "id" : 337742544,
      "verified" : true
    }
  },
  "id" : 136850025698435072,
  "created_at" : "2011-11-16 16:56:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "indices" : [ 3, 12 ],
      "id_str" : "337742544",
      "id" : 337742544
    }, {
      "name" : "ThinkProgress",
      "screen_name" : "thinkprogress",
      "indices" : [ 112, 126 ],
      "id_str" : "55355654",
      "id" : 55355654
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/MZzaU5F4",
      "expanded_url" : "http:\/\/ygl.as\/uuNIeq",
      "display_url" : "ygl.as\/uuNIeq"
    } ]
  },
  "geo" : { },
  "id_str" : "136849917535715328",
  "text" : "RT @OMBPress: Uncovering Presidential Proposals By Using The World-Flattening Internet http:\/\/t.co\/MZzaU5F4 via @thinkprogress #googlewo ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ThinkProgress",
        "screen_name" : "thinkprogress",
        "indices" : [ 98, 112 ],
        "id_str" : "55355654",
        "id" : 55355654
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "googleworksinIndia",
        "indices" : [ 113, 132 ]
      } ],
      "urls" : [ {
        "indices" : [ 73, 93 ],
        "url" : "http:\/\/t.co\/MZzaU5F4",
        "expanded_url" : "http:\/\/ygl.as\/uuNIeq",
        "display_url" : "ygl.as\/uuNIeq"
      } ]
    },
    "geo" : { },
    "id_str" : "136836218360037376",
    "text" : "Uncovering Presidential Proposals By Using The World-Flattening Internet http:\/\/t.co\/MZzaU5F4 via @thinkprogress #googleworksinIndia",
    "id" : 136836218360037376,
    "created_at" : "2011-11-16 16:01:11 +0000",
    "user" : {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "protected" : false,
      "id_str" : "337742544",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1449289379\/OMB_Seal_normal.jpg",
      "id" : 337742544,
      "verified" : true
    }
  },
  "id" : 136849917535715328,
  "created_at" : "2011-11-16 16:55:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/PflXMGcM",
      "expanded_url" : "http:\/\/ow.ly\/7vwUy",
      "display_url" : "ow.ly\/7vwUy"
    } ]
  },
  "geo" : { },
  "id_str" : "136838702616940544",
  "text" : "Renewing ties in the Pacific: This afternoon, President Obama arrives in Canberra, Australia: http:\/\/t.co\/PflXMGcM",
  "id" : 136838702616940544,
  "created_at" : "2011-11-16 16:11:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "136579517090238465",
  "text" : "RT @pfeiffer44: To GOPers who say they haven't from POTUS re the supercommittee. Here is the 80 pg deficit plan released in September. h ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/eeebU31O",
        "expanded_url" : "http:\/\/1.usa.gov\/mV3CGx",
        "display_url" : "1.usa.gov\/mV3CGx"
      } ]
    },
    "geo" : { },
    "id_str" : "136531897898643456",
    "text" : "To GOPers who say they haven't from POTUS re the supercommittee. Here is the 80 pg deficit plan released in September. http:\/\/t.co\/eeebU31O",
    "id" : 136531897898643456,
    "created_at" : "2011-11-15 19:51:55 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 136579517090238465,
  "created_at" : "2011-11-15 23:01:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Education",
      "screen_name" : "usedgov",
      "indices" : [ 3, 11 ],
      "id_str" : "20437286",
      "id" : 20437286
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AskArne",
      "indices" : [ 70, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/I5ZDH31s",
      "expanded_url" : "http:\/\/go.usa.gov\/IR9",
      "display_url" : "go.usa.gov\/IR9"
    } ]
  },
  "geo" : { },
  "id_str" : "136568996270063616",
  "text" : "RT @usedgov: Town Hall: 140 Characters at a Time http:\/\/t.co\/I5ZDH31s #AskArne",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.exacttarget.com\/social\" rel=\"nofollow\"\u003ESocialEngage\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AskArne",
        "indices" : [ 57, 65 ]
      } ],
      "urls" : [ {
        "indices" : [ 36, 56 ],
        "url" : "http:\/\/t.co\/I5ZDH31s",
        "expanded_url" : "http:\/\/go.usa.gov\/IR9",
        "display_url" : "go.usa.gov\/IR9"
      } ]
    },
    "geo" : { },
    "id_str" : "136561833787146241",
    "text" : "Town Hall: 140 Characters at a Time http:\/\/t.co\/I5ZDH31s #AskArne",
    "id" : 136561833787146241,
    "created_at" : "2011-11-15 21:50:53 +0000",
    "user" : {
      "name" : "US Dept of Education",
      "screen_name" : "usedgov",
      "protected" : false,
      "id_str" : "20437286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749204008108261377\/93-TTeZl_normal.jpg",
      "id" : 20437286,
      "verified" : true
    }
  },
  "id" : 136568996270063616,
  "created_at" : "2011-11-15 22:19:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/VL8wVBMW",
      "expanded_url" : "http:\/\/ow.ly\/7uC0b",
      "display_url" : "ow.ly\/7uC0b"
    } ]
  },
  "geo" : { },
  "id_str" : "136555755540189186",
  "text" : "Today is America Recycles Day. Find out what you can do: http:\/\/t.co\/VL8wVBMW",
  "id" : 136555755540189186,
  "created_at" : "2011-11-15 21:26:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CNCS",
      "screen_name" : "NationalService",
      "indices" : [ 3, 19 ],
      "id_str" : "17961886",
      "id" : 17961886
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 47, 58 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "Brandon Routh",
      "screen_name" : "BrandonJRouth",
      "indices" : [ 84, 98 ],
      "id_str" : "204137620",
      "id" : 204137620
    }, {
      "name" : "Jon Carson",
      "screen_name" : "JonCarson44",
      "indices" : [ 101, 113 ],
      "id_str" : "1287388789",
      "id" : 1287388789
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "volunteering",
      "indices" : [ 67, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "136553416913727488",
  "text" : "RT @nationalservice: Tomorrow, we're headed to @whitehouse to talk #volunteering w\/ @BrandonJRouth & @JonCarson44. What questions would  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 26, 37 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "Brandon Routh",
        "screen_name" : "BrandonJRouth",
        "indices" : [ 63, 77 ],
        "id_str" : "204137620",
        "id" : 204137620
      }, {
        "name" : "Jon Carson",
        "screen_name" : "JonCarson44",
        "indices" : [ 80, 92 ],
        "id_str" : "1287388789",
        "id" : 1287388789
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "volunteering",
        "indices" : [ 46, 59 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "136542285004410882",
    "text" : "Tomorrow, we're headed to @whitehouse to talk #volunteering w\/ @BrandonJRouth & @JonCarson44. What questions would you like to see tackled?",
    "id" : 136542285004410882,
    "created_at" : "2011-11-15 20:33:12 +0000",
    "user" : {
      "name" : "CNCS",
      "screen_name" : "NationalService",
      "protected" : false,
      "id_str" : "17961886",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/695658719045160961\/04v_MrsK_normal.jpg",
      "id" : 17961886,
      "verified" : false
    }
  },
  "id" : 136553416913727488,
  "created_at" : "2011-11-15 21:17:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/mmGrkXcN",
      "expanded_url" : "http:\/\/ow.ly\/7uBhs",
      "display_url" : "ow.ly\/7uBhs"
    } ]
  },
  "geo" : { },
  "id_str" : "136552837474828290",
  "text" : "RT @JoiningForces: \"Each of us has the ability to make a difference in the life of a military family\" -Dr. Jill Biden: http:\/\/t.co\/mmGrkXcN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 120 ],
        "url" : "http:\/\/t.co\/mmGrkXcN",
        "expanded_url" : "http:\/\/ow.ly\/7uBhs",
        "display_url" : "ow.ly\/7uBhs"
      } ]
    },
    "geo" : { },
    "id_str" : "136552771276111872",
    "text" : "\"Each of us has the ability to make a difference in the life of a military family\" -Dr. Jill Biden: http:\/\/t.co\/mmGrkXcN",
    "id" : 136552771276111872,
    "created_at" : "2011-11-15 21:14:52 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 136552837474828290,
  "created_at" : "2011-11-15 21:15:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/YKJkOlOa",
      "expanded_url" : "http:\/\/ow.ly\/7uthx",
      "display_url" : "ow.ly\/7uthx"
    } ]
  },
  "geo" : { },
  "id_str" : "136523669638881280",
  "text" : "We Can\u2019t Wait: Agencies cut nearly $18 billion in improper payments & announce new steps to stop govt waste: http:\/\/t.co\/YKJkOlOa",
  "id" : 136523669638881280,
  "created_at" : "2011-11-15 19:19:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelly Wallace",
      "screen_name" : "kellywallacetv",
      "indices" : [ 3, 18 ],
      "id_str" : "21411381",
      "id" : 21411381
    }, {
      "name" : "iVillage",
      "screen_name" : "iVillage",
      "indices" : [ 81, 90 ],
      "id_str" : "39293968",
      "id" : 39293968
    }, {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "indices" : [ 103, 110 ],
      "id_str" : "44783853",
      "id" : 44783853
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KathleenSebelius",
      "indices" : [ 111, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "136505024552505344",
  "text" : "RT @kellywallacetv: We want YOUR questions for the WH about our kids & smoking.  @iVillage live chat w\/@HHSGov #KathleenSebelius Thursda ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "iVillage",
        "screen_name" : "iVillage",
        "indices" : [ 61, 70 ],
        "id_str" : "39293968",
        "id" : 39293968
      }, {
        "name" : "HHS.gov",
        "screen_name" : "HHSGov",
        "indices" : [ 83, 90 ],
        "id_str" : "44783853",
        "id" : 44783853
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "KathleenSebelius",
        "indices" : [ 91, 108 ]
      } ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/g6XGPZPk",
        "expanded_url" : "http:\/\/ow.ly\/7udyR",
        "display_url" : "ow.ly\/7udyR"
      } ]
    },
    "geo" : { },
    "id_str" : "136478713306025985",
    "text" : "We want YOUR questions for the WH about our kids & smoking.  @iVillage live chat w\/@HHSGov #KathleenSebelius Thursday. http:\/\/t.co\/g6XGPZPk",
    "id" : 136478713306025985,
    "created_at" : "2011-11-15 16:20:35 +0000",
    "user" : {
      "name" : "Kelly Wallace",
      "screen_name" : "kellywallacetv",
      "protected" : false,
      "id_str" : "21411381",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/223570280\/kwallace_normal.jpg",
      "id" : 21411381,
      "verified" : false
    }
  },
  "id" : 136505024552505344,
  "created_at" : "2011-11-15 18:05:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SBA",
      "screen_name" : "SBAgov",
      "indices" : [ 3, 10 ],
      "id_str" : "153149305",
      "id" : 153149305
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "app",
      "indices" : [ 19, 23 ]
    }, {
      "text" : "entrepreneurs",
      "indices" : [ 32, 46 ]
    }, {
      "text" : "Federal",
      "indices" : [ 67, 75 ]
    }, {
      "text" : "challenge",
      "indices" : [ 107, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/rvBrPfoe",
      "expanded_url" : "http:\/\/owl.li\/7tEHn",
      "display_url" : "owl.li\/7tEHn"
    } ]
  },
  "geo" : { },
  "id_str" : "136454457583091712",
  "text" : "RT @SBAgov: Got an #app to help #entrepreneurs better navigate the #Federal Gov? $ prize included for this #challenge: http:\/\/t.co\/rvBrPfoe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "app",
        "indices" : [ 7, 11 ]
      }, {
        "text" : "entrepreneurs",
        "indices" : [ 20, 34 ]
      }, {
        "text" : "Federal",
        "indices" : [ 55, 63 ]
      }, {
        "text" : "challenge",
        "indices" : [ 95, 105 ]
      } ],
      "urls" : [ {
        "indices" : [ 107, 127 ],
        "url" : "http:\/\/t.co\/rvBrPfoe",
        "expanded_url" : "http:\/\/owl.li\/7tEHn",
        "display_url" : "owl.li\/7tEHn"
      } ]
    },
    "geo" : { },
    "id_str" : "136450918681030656",
    "text" : "Got an #app to help #entrepreneurs better navigate the #Federal Gov? $ prize included for this #challenge: http:\/\/t.co\/rvBrPfoe",
    "id" : 136450918681030656,
    "created_at" : "2011-11-15 14:30:08 +0000",
    "user" : {
      "name" : "SBA",
      "screen_name" : "SBAgov",
      "protected" : false,
      "id_str" : "153149305",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/637366120236756992\/ky6enEIv_normal.png",
      "id" : 153149305,
      "verified" : true
    }
  },
  "id" : 136454457583091712,
  "created_at" : "2011-11-15 14:44:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SaveAward",
      "indices" : [ 73, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/D2qCklxi",
      "expanded_url" : "http:\/\/wh.gov\/save-award",
      "display_url" : "wh.gov\/save-award"
    } ]
  },
  "geo" : { },
  "id_str" : "136452853815451648",
  "text" : "Vote Now: Which money saving plan do you like best? http:\/\/t.co\/D2qCklxi #SaveAward",
  "id" : 136452853815451648,
  "created_at" : "2011-11-15 14:37:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WH.gov",
      "screen_name" : "WHWeb",
      "indices" : [ 3, 9 ],
      "id_str" : "390320946",
      "id" : 390320946
    }, {
      "name" : "Daniel Morgan",
      "screen_name" : "dsmorgan77",
      "indices" : [ 14, 25 ],
      "id_str" : "139942645",
      "id" : 139942645
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "s",
      "indices" : [ 39, 41 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/JEuR7QgL",
      "expanded_url" : "http:\/\/WH.gov",
      "display_url" : "WH.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "136236739231617024",
  "text" : "RT @WHWeb: MT @dsmorgan77 Including EO #s wld improve http:\/\/t.co\/JEuR7QgL utility \/\/ Good idea: Working to implement moving fwd, thnx f ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Daniel Morgan",
        "screen_name" : "dsmorgan77",
        "indices" : [ 3, 14 ],
        "id_str" : "139942645",
        "id" : 139942645
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "s",
        "indices" : [ 28, 30 ]
      }, {
        "text" : "whweb",
        "indices" : [ 128, 134 ]
      } ],
      "urls" : [ {
        "indices" : [ 43, 63 ],
        "url" : "http:\/\/t.co\/JEuR7QgL",
        "expanded_url" : "http:\/\/WH.gov",
        "display_url" : "WH.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "136235698146656257",
    "text" : "MT @dsmorgan77 Including EO #s wld improve http:\/\/t.co\/JEuR7QgL utility \/\/ Good idea: Working to implement moving fwd, thnx for #whweb fdbk",
    "id" : 136235698146656257,
    "created_at" : "2011-11-15 00:14:56 +0000",
    "user" : {
      "name" : "WH.gov",
      "screen_name" : "WHWeb",
      "protected" : false,
      "id_str" : "390320946",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618051538582310913\/0xcdHiQS_normal.jpg",
      "id" : 390320946,
      "verified" : true
    }
  },
  "id" : 136236739231617024,
  "created_at" : "2011-11-15 00:19:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USS Carl Vinson",
      "screen_name" : "CVN70",
      "indices" : [ 93, 99 ],
      "id_str" : "47503255",
      "id" : 47503255
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/136231962091339777\/photo\/1",
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/e8bscg3Q",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AeP-P2wCQAAs1Cc.jpg",
      "id_str" : "136231962099728384",
      "id" : 136231962099728384,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AeP-P2wCQAAs1Cc.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/e8bscg3Q"
    } ],
    "hashtags" : [ {
      "text" : "VeteransDay",
      "indices" : [ 103, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/xiCmSBQw",
      "expanded_url" : "http:\/\/ow.ly\/7tsei",
      "display_url" : "ow.ly\/7tsei"
    } ]
  },
  "geo" : { },
  "id_str" : "136231962091339777",
  "text" : "Veterans Day 2011 in Pictures: http:\/\/t.co\/xiCmSBQw Pic of the President & First Lady aboard @CVN70 on #VeteransDay: http:\/\/t.co\/e8bscg3Q",
  "id" : 136231962091339777,
  "created_at" : "2011-11-15 00:00:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "CommerceSec",
      "screen_name" : "CommerceSec",
      "indices" : [ 43, 55 ],
      "id_str" : "2319148561",
      "id" : 2319148561
    }, {
      "name" : "U.S. Commerce Dept.",
      "screen_name" : "CommerceGov",
      "indices" : [ 70, 82 ],
      "id_str" : "110541296",
      "id" : 110541296
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/VP\/status\/136226300259082240\/photo\/1",
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/tfo9eWFu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AeP5GSxCIAAXK8M.jpg",
      "id_str" : "136226300263276544",
      "id" : 136226300263276544,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AeP5GSxCIAAXK8M.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 667,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 667,
        "resize" : "fit",
        "w" : 1000
      } ],
      "display_url" : "pic.twitter.com\/tfo9eWFu"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "136229450722459648",
  "text" : "RT @VP: PHOTO: VP swears in John Bryson as @CommerceSec earlier today @CommerceGov http:\/\/t.co\/tfo9eWFu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CommerceSec",
        "screen_name" : "CommerceSec",
        "indices" : [ 35, 47 ],
        "id_str" : "2319148561",
        "id" : 2319148561
      }, {
        "name" : "U.S. Commerce Dept.",
        "screen_name" : "CommerceGov",
        "indices" : [ 62, 74 ],
        "id_str" : "110541296",
        "id" : 110541296
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/136226300259082240\/photo\/1",
        "indices" : [ 75, 95 ],
        "url" : "http:\/\/t.co\/tfo9eWFu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AeP5GSxCIAAXK8M.jpg",
        "id_str" : "136226300263276544",
        "id" : 136226300263276544,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AeP5GSxCIAAXK8M.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        } ],
        "display_url" : "pic.twitter.com\/tfo9eWFu"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "136226300259082240",
    "text" : "PHOTO: VP swears in John Bryson as @CommerceSec earlier today @CommerceGov http:\/\/t.co\/tfo9eWFu",
    "id" : 136226300259082240,
    "created_at" : "2011-11-14 23:37:36 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 136229450722459648,
  "created_at" : "2011-11-14 23:50:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/71puvhhV",
      "expanded_url" : "http:\/\/ow.ly\/7t6PD",
      "display_url" : "ow.ly\/7t6PD"
    } ]
  },
  "geo" : { },
  "id_str" : "136149647763836928",
  "text" : "We can't wait to make health care more affordable. President Obama launches Innovation Challenge. Send your ideas: http:\/\/t.co\/71puvhhV",
  "id" : 136149647763836928,
  "created_at" : "2011-11-14 18:33:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AskArne",
      "indices" : [ 82, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/tHDUa823",
      "expanded_url" : "http:\/\/go.usa.gov\/IKy",
      "display_url" : "go.usa.gov\/IKy"
    } ]
  },
  "geo" : { },
  "id_str" : "136109305010204672",
  "text" : "RT @arneduncan: Happy American Education Week! We're kicking off the week with an #AskArne Twitter Town Hall http:\/\/t.co\/tHDUa823",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AskArne",
        "indices" : [ 66, 74 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 113 ],
        "url" : "http:\/\/t.co\/tHDUa823",
        "expanded_url" : "http:\/\/go.usa.gov\/IKy",
        "display_url" : "go.usa.gov\/IKy"
      } ]
    },
    "geo" : { },
    "id_str" : "136108951040294912",
    "text" : "Happy American Education Week! We're kicking off the week with an #AskArne Twitter Town Hall http:\/\/t.co\/tHDUa823",
    "id" : 136108951040294912,
    "created_at" : "2011-11-14 15:51:17 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 136109305010204672,
  "created_at" : "2011-11-14 15:52:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 1, 12 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/QRurC8Cb",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/the-press-office\/2011\/11\/14\/statement-white-house-communications-director-dan-pfeiffer-supreme-court",
      "display_url" : "whitehouse.gov\/the-press-offi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "136108759243177984",
  "text" : ".@pfeiffer44: We know the Affordable Care Act is constitutional & are confident the Supreme Court will agree: http:\/\/t.co\/QRurC8Cb",
  "id" : 136108759243177984,
  "created_at" : "2011-11-14 15:50:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Washington Post",
      "screen_name" : "washingtonpost",
      "indices" : [ 123, 138 ],
      "id_str" : "2467791",
      "id" : 2467791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/LlJii8Cb",
      "expanded_url" : "http:\/\/www.washingtonpost.com\/national\/health-science\/obama-administration-to-announce-effort-to-expand-health-care-workforce\/2011\/11\/11\/gIQAxXfpIN_story.html?tid=sm_btn_twitter",
      "display_url" : "washingtonpost.com\/national\/healt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "136100640454750208",
  "text" : "We Can't Wait: Today, Obama administration announces efforts to expand the health-care workforce: http:\/\/t.co\/LlJii8Cb via @washingtonpost",
  "id" : 136100640454750208,
  "created_at" : "2011-11-14 15:18:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "veteran",
      "indices" : [ 14, 22 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/U5nYSk4A",
      "expanded_url" : "http:\/\/youtu.be\/--QxAtXZJpQ",
      "display_url" : "youtu.be\/--QxAtXZJpQ"
    } ]
  },
  "geo" : { },
  "id_str" : "135940376035983361",
  "text" : "\"I want every #veteran to know that America will always honor your service & your sacrifice\" -President Obama: Video: http:\/\/t.co\/U5nYSk4A",
  "id" : 135940376035983361,
  "created_at" : "2011-11-14 04:41:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arianna Huffington",
      "screen_name" : "ariannahuff",
      "indices" : [ 3, 15 ],
      "id_str" : "21982720",
      "id" : 21982720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "135856383227736064",
  "text" : "RT @ariannahuff: Valerie Jarrett blogs about the need to keep fighting for women's\rrights. 'When women succeed, America succeeds.\"\rhttp: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 134 ],
        "url" : "http:\/\/t.co\/YFHr9wwY",
        "expanded_url" : "http:\/\/huff.to\/sARZyX",
        "display_url" : "huff.to\/sARZyX"
      } ]
    },
    "geo" : { },
    "id_str" : "135824266796072962",
    "text" : "Valerie Jarrett blogs about the need to keep fighting for women's\rrights. 'When women succeed, America succeeds.\"\rhttp:\/\/t.co\/YFHr9wwY",
    "id" : 135824266796072962,
    "created_at" : "2011-11-13 21:00:03 +0000",
    "user" : {
      "name" : "Arianna Huffington",
      "screen_name" : "ariannahuff",
      "protected" : false,
      "id_str" : "21982720",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765947806582468608\/Ywa0eYRp_normal.jpg",
      "id" : 21982720,
      "verified" : true
    }
  },
  "id" : 135856383227736064,
  "created_at" : "2011-11-13 23:07:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 3, 11 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/h3qYtHm4",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=--QxAtXZJpQ&feature=share",
      "display_url" : "youtube.com\/watch?v=--QxAt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "135540630695849984",
  "text" : "RT @macon44: the coolest weekly address setting yet: http:\/\/t.co\/h3qYtHm4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 60 ],
        "url" : "http:\/\/t.co\/h3qYtHm4",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=--QxAtXZJpQ&feature=share",
        "display_url" : "youtube.com\/watch?v=--QxAt\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "135459764250484736",
    "text" : "the coolest weekly address setting yet: http:\/\/t.co\/h3qYtHm4",
    "id" : 135459764250484736,
    "created_at" : "2011-11-12 20:51:39 +0000",
    "user" : {
      "name" : "Macon Phillips",
      "screen_name" : "IIPCoordinator",
      "protected" : false,
      "id_str" : "110823581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000495374915\/f6a5ae048ab7f8f12c0386114df53203_normal.jpeg",
      "id" : 110823581,
      "verified" : true
    }
  },
  "id" : 135540630695849984,
  "created_at" : "2011-11-13 02:12:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House Blog",
      "screen_name" : "blog44",
      "indices" : [ 3, 10 ],
      "id_str" : "278776049",
      "id" : 278776049
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 32 ],
      "url" : "http:\/\/t.co\/HxTO58SB",
      "expanded_url" : "http:\/\/WH.gov",
      "display_url" : "WH.gov"
    }, {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/p5jsZxzg",
      "expanded_url" : "http:\/\/goo.gl\/fb\/e2rO0",
      "display_url" : "goo.gl\/fb\/e2rO0"
    } ]
  },
  "geo" : { },
  "id_str" : "135540317163225089",
  "text" : "RT @blog44: http:\/\/t.co\/HxTO58SB: President Obama Attends the Carrier Classic http:\/\/t.co\/p5jsZxzg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 20 ],
        "url" : "http:\/\/t.co\/HxTO58SB",
        "expanded_url" : "http:\/\/WH.gov",
        "display_url" : "WH.gov"
      }, {
        "indices" : [ 66, 86 ],
        "url" : "http:\/\/t.co\/p5jsZxzg",
        "expanded_url" : "http:\/\/goo.gl\/fb\/e2rO0",
        "display_url" : "goo.gl\/fb\/e2rO0"
      } ]
    },
    "geo" : { },
    "id_str" : "135466670570479616",
    "text" : "http:\/\/t.co\/HxTO58SB: President Obama Attends the Carrier Classic http:\/\/t.co\/p5jsZxzg",
    "id" : 135466670570479616,
    "created_at" : "2011-11-12 21:19:05 +0000",
    "user" : {
      "name" : "The White House Blog",
      "screen_name" : "blog44",
      "protected" : false,
      "id_str" : "278776049",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1303743170\/Screen_shot_2011-04-07_at_7.54.18_PM_normal.png",
      "id" : 278776049,
      "verified" : true
    }
  },
  "id" : 135540317163225089,
  "created_at" : "2011-11-13 02:11:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USS Carl Vinson",
      "screen_name" : "CVN70",
      "indices" : [ 3, 9 ],
      "id_str" : "47503255",
      "id" : 47503255
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CVN70\/status\/135153400030564352\/photo\/1",
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/oiMza5vA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AeApTR9CEAIeoL0.jpg",
      "id_str" : "135153400034758658",
      "id" : 135153400034758658,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AeApTR9CEAIeoL0.jpg",
      "sizes" : [ {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/oiMza5vA"
    } ],
    "hashtags" : [ {
      "text" : "carrierclassic",
      "indices" : [ 101, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "135165447875211264",
  "text" : "RT @CVN70: President Obama interacts with Sailors before game starts, gives kudos to the Carl Vinson #carrierclassic http:\/\/t.co\/oiMza5vA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CVN70\/status\/135153400030564352\/photo\/1",
        "indices" : [ 106, 126 ],
        "url" : "http:\/\/t.co\/oiMza5vA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AeApTR9CEAIeoL0.jpg",
        "id_str" : "135153400034758658",
        "id" : 135153400034758658,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AeApTR9CEAIeoL0.jpg",
        "sizes" : [ {
          "h" : 448,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 765,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 254,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 765,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/oiMza5vA"
      } ],
      "hashtags" : [ {
        "text" : "carrierclassic",
        "indices" : [ 90, 105 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "135153400030564352",
    "text" : "President Obama interacts with Sailors before game starts, gives kudos to the Carl Vinson #carrierclassic http:\/\/t.co\/oiMza5vA",
    "id" : 135153400030564352,
    "created_at" : "2011-11-12 00:34:17 +0000",
    "user" : {
      "name" : "USS Carl Vinson",
      "screen_name" : "CVN70",
      "protected" : false,
      "id_str" : "47503255",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2991811016\/e814de5a90c3656f87de621836c0fd87_normal.jpeg",
      "id" : 47503255,
      "verified" : false
    }
  },
  "id" : 135165447875211264,
  "created_at" : "2011-11-12 01:22:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CarrierClassic",
      "indices" : [ 63, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "135160901014790144",
  "text" : "Tonight, the President & First Lady are honoring US military @ #CarrierClassic basketball game on the deck of USS Carl Vinson in San Diego",
  "id" : 135160901014790144,
  "created_at" : "2011-11-12 01:04:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http:\/\/t.co\/cSqPcQAC",
      "expanded_url" : "http:\/\/ow.ly\/7qWBm",
      "display_url" : "ow.ly\/7qWBm"
    } ]
  },
  "geo" : { },
  "id_str" : "135107591767461888",
  "text" : "RT @JoiningForces: New Slideshow for Veterans Day: http:\/\/t.co\/cSqPcQAC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 32, 52 ],
        "url" : "http:\/\/t.co\/cSqPcQAC",
        "expanded_url" : "http:\/\/ow.ly\/7qWBm",
        "display_url" : "ow.ly\/7qWBm"
      } ]
    },
    "geo" : { },
    "id_str" : "135107528525742080",
    "text" : "New Slideshow for Veterans Day: http:\/\/t.co\/cSqPcQAC",
    "id" : 135107528525742080,
    "created_at" : "2011-11-11 21:31:59 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 135107591767461888,
  "created_at" : "2011-11-11 21:32:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "135067335915601920",
  "text" : "Obama to veterans: You are part of an unbroken chain of men & women who have served this country with honor & distinction...We thank you.",
  "id" : 135067335915601920,
  "created_at" : "2011-11-11 18:52:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "135033159686438913",
  "text" : "Happening now: President Obama delivers Veterans Day remarks @ Arlington National Cemetery. Watch live: http:\/\/t.co\/u95y7hhB",
  "id" : 135033159686438913,
  "created_at" : "2011-11-11 16:36:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    }, {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 122, 136 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "135020233445486592",
  "text" : "RT @JoiningForces: How are you celebrating Veterans Day? Tell us what you're doing to honor our veterans & their families @JoiningForces",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Joining Forces",
        "screen_name" : "JoiningForces",
        "indices" : [ 103, 117 ],
        "id_str" : "26278266",
        "id" : 26278266
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "135020040989851648",
    "text" : "How are you celebrating Veterans Day? Tell us what you're doing to honor our veterans & their families @JoiningForces",
    "id" : 135020040989851648,
    "created_at" : "2011-11-11 15:44:20 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 135020233445486592,
  "created_at" : "2011-11-11 15:45:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Veterans Affairs",
      "screen_name" : "DeptVetAffairs",
      "indices" : [ 3, 18 ],
      "id_str" : "78408666",
      "id" : 78408666
    }, {
      "name" : "Wall Street Journal",
      "screen_name" : "WSJ",
      "indices" : [ 121, 125 ],
      "id_str" : "3108351",
      "id" : 3108351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/q1uRXYp4",
      "expanded_url" : "http:\/\/online.wsj.com\/article\/SB10001424052970204224604577028422920213512.html?mod=googlenews_wsj",
      "display_url" : "online.wsj.com\/article\/SB1000\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "135016891952533504",
  "text" : "RT @DeptVetAffairs: Why Veterans Make Good Employees: Secretary Shinseki's Veterans Day message http:\/\/t.co\/q1uRXYp4 via @wsj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Wall Street Journal",
        "screen_name" : "WSJ",
        "indices" : [ 101, 105 ],
        "id_str" : "3108351",
        "id" : 3108351
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 96 ],
        "url" : "http:\/\/t.co\/q1uRXYp4",
        "expanded_url" : "http:\/\/online.wsj.com\/article\/SB10001424052970204224604577028422920213512.html?mod=googlenews_wsj",
        "display_url" : "online.wsj.com\/article\/SB1000\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "135015813311758336",
    "text" : "Why Veterans Make Good Employees: Secretary Shinseki's Veterans Day message http:\/\/t.co\/q1uRXYp4 via @wsj",
    "id" : 135015813311758336,
    "created_at" : "2011-11-11 15:27:33 +0000",
    "user" : {
      "name" : "Veterans Affairs",
      "screen_name" : "DeptVetAffairs",
      "protected" : false,
      "id_str" : "78408666",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/344513261565984455\/a9fcce7feb947b2ec498491c6c6d6985_normal.png",
      "id" : 78408666,
      "verified" : true
    }
  },
  "id" : 135016891952533504,
  "created_at" : "2011-11-11 15:31:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 9, 12 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "The Union-Tribune",
      "screen_name" : "sdut",
      "indices" : [ 81, 86 ],
      "id_str" : "14148802",
      "id" : 14148802
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/obzSNYcr",
      "expanded_url" : "http:\/\/www.signonsandiego.com\/news\/2011\/nov\/11\/veterans-day-2011-the-battle-veterans-face-after\/",
      "display_url" : "signonsandiego.com\/news\/2011\/nov\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "135016263641595904",
  "text" : "Op-ed by @VP Biden & Dr. Jill Biden: The battle veterans face after the war (via @sdut) http:\/\/t.co\/obzSNYcr",
  "id" : 135016263641595904,
  "created_at" : "2011-11-11 15:29:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/4LM44FTh",
      "expanded_url" : "http:\/\/ow.ly\/7qpy1",
      "display_url" : "ow.ly\/7qpy1"
    } ]
  },
  "geo" : { },
  "id_str" : "135004549093138433",
  "text" : "\"On Veterans Day, we pay tribute to our veterans, to the fallen & to their families\" -President Obama. Proclamation: http:\/\/t.co\/4LM44FTh",
  "id" : 135004549093138433,
  "created_at" : "2011-11-11 14:42:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jobs",
      "indices" : [ 31, 36 ]
    }, {
      "text" : "veterans",
      "indices" : [ 41, 50 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/gUltQqFh",
      "expanded_url" : "http:\/\/ow.ly\/7pUfB",
      "display_url" : "ow.ly\/7pUfB"
    } ]
  },
  "geo" : { },
  "id_str" : "134801233742544896",
  "text" : "RT @JoiningForces: 100,000 new #jobs for #veterans & military families: http:\/\/t.co\/gUltQqFh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "jobs",
        "indices" : [ 12, 17 ]
      }, {
        "text" : "veterans",
        "indices" : [ 22, 31 ]
      } ],
      "urls" : [ {
        "indices" : [ 53, 73 ],
        "url" : "http:\/\/t.co\/gUltQqFh",
        "expanded_url" : "http:\/\/ow.ly\/7pUfB",
        "display_url" : "ow.ly\/7pUfB"
      } ]
    },
    "geo" : { },
    "id_str" : "134801184379764736",
    "text" : "100,000 new #jobs for #veterans & military families: http:\/\/t.co\/gUltQqFh",
    "id" : 134801184379764736,
    "created_at" : "2011-11-11 01:14:41 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 134801233742544896,
  "created_at" : "2011-11-11 01:14:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Storify",
      "screen_name" : "Storify",
      "indices" : [ 94, 102 ],
      "id_str" : "17814938",
      "id" : 17814938
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "veterans",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/wwZx1Fgk",
      "expanded_url" : "http:\/\/ow.ly\/7pTM2",
      "display_url" : "ow.ly\/7pTM2"
    } ]
  },
  "geo" : { },
  "id_str" : "134799353612206082",
  "text" : "RT @WHLive: Missed today's Office Hours with Matt Flavin? See the Q&A on #veterans issues via @Storify: http:\/\/t.co\/wwZx1Fgk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Storify",
        "screen_name" : "Storify",
        "indices" : [ 82, 90 ],
        "id_str" : "17814938",
        "id" : 17814938
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "veterans",
        "indices" : [ 61, 70 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 112 ],
        "url" : "http:\/\/t.co\/wwZx1Fgk",
        "expanded_url" : "http:\/\/ow.ly\/7pTM2",
        "display_url" : "ow.ly\/7pTM2"
      } ]
    },
    "geo" : { },
    "id_str" : "134799079136960515",
    "text" : "Missed today's Office Hours with Matt Flavin? See the Q&A on #veterans issues via @Storify: http:\/\/t.co\/wwZx1Fgk",
    "id" : 134799079136960515,
    "created_at" : "2011-11-11 01:06:19 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 134799353612206082,
  "created_at" : "2011-11-11 01:07:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "The American Legion",
      "screen_name" : "AmericanLegion",
      "indices" : [ 67, 82 ],
      "id_str" : "27048645",
      "id" : 27048645
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "134776928619085825",
  "text" : "RT @VP: PHOTO: Vice President Joe Biden talks with veterans at the @AmericanLegion Post 2, in Manchester, New Hampshire. http:\/\/t.co\/iCb ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The American Legion",
        "screen_name" : "AmericanLegion",
        "indices" : [ 59, 74 ],
        "id_str" : "27048645",
        "id" : 27048645
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/134755776093880320\/photo\/1",
        "indices" : [ 113, 133 ],
        "url" : "http:\/\/t.co\/iCb0gYpF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ad6_qhXCAAIGiKc.jpg",
        "id_str" : "134755776098074626",
        "id" : 134755776098074626,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ad6_qhXCAAIGiKc.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        } ],
        "display_url" : "pic.twitter.com\/iCb0gYpF"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "134755776093880320",
    "text" : "PHOTO: Vice President Joe Biden talks with veterans at the @AmericanLegion Post 2, in Manchester, New Hampshire. http:\/\/t.co\/iCb0gYpF",
    "id" : 134755776093880320,
    "created_at" : "2011-11-10 22:14:15 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 134776928619085825,
  "created_at" : "2011-11-10 23:38:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Nonya",
      "screen_name" : "jasin_orr",
      "indices" : [ 13, 23 ],
      "id_str" : "331375989",
      "id" : 331375989
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "134763021116510208",
  "text" : "RT @WHLive: .@jasin_orr  Many vets eligible for post-9\/11 GI Bill and can use it for vocational training now. POTUS fully funded & imple ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nonya",
        "screen_name" : "jasin_orr",
        "indices" : [ 1, 11 ],
        "id_str" : "331375989",
        "id" : 331375989
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 132, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "134762474225414144",
    "text" : ".@jasin_orr  Many vets eligible for post-9\/11 GI Bill and can use it for vocational training now. POTUS fully funded & implemented. #WHChat",
    "id" : 134762474225414144,
    "created_at" : "2011-11-10 22:40:52 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 134763021116510208,
  "created_at" : "2011-11-10 22:43:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nonya",
      "screen_name" : "jasin_orr",
      "indices" : [ 3, 13 ],
      "id_str" : "331375989",
      "id" : 331375989
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 15, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "134763006759415808",
  "text" : "RT @jasin_orr: #WHChat how can you get veterans back to work when the President makes it impossible for veterans to get an education?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 0, 7 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "134727642170658816",
    "text" : "#WHChat how can you get veterans back to work when the President makes it impossible for veterans to get an education?",
    "id" : 134727642170658816,
    "created_at" : "2011-11-10 20:22:27 +0000",
    "user" : {
      "name" : "Nonya",
      "screen_name" : "jasin_orr",
      "protected" : false,
      "id_str" : "331375989",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/641680291925372928\/tnqRydb2_normal.jpg",
      "id" : 331375989,
      "verified" : false
    }
  },
  "id" : 134763006759415808,
  "created_at" : "2011-11-10 22:42:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Christie Cordes",
      "screen_name" : "Ad_Recruiter",
      "indices" : [ 13, 26 ],
      "id_str" : "14074102",
      "id" : 14074102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/HsIJwb4y",
      "expanded_url" : "http:\/\/NRD.gov",
      "display_url" : "NRD.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "134755338317598720",
  "text" : "RT @WHLive: .@Ad_Recruiter Great Q New VeteransJobBank on http:\/\/t.co\/HsIJwb4y lets vets search for jobs from employers committed to hir ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Christie Cordes",
        "screen_name" : "Ad_Recruiter",
        "indices" : [ 1, 14 ],
        "id_str" : "14074102",
        "id" : 14074102
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 133, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 46, 66 ],
        "url" : "http:\/\/t.co\/HsIJwb4y",
        "expanded_url" : "http:\/\/NRD.gov",
        "display_url" : "NRD.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "134755016421556224",
    "text" : ".@Ad_Recruiter Great Q New VeteransJobBank on http:\/\/t.co\/HsIJwb4y lets vets search for jobs from employers committed to hiring vets #WHChat",
    "id" : 134755016421556224,
    "created_at" : "2011-11-10 22:11:14 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 134755338317598720,
  "created_at" : "2011-11-10 22:12:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christie Cordes",
      "screen_name" : "Ad_Recruiter",
      "indices" : [ 3, 16 ],
      "id_str" : "14074102",
      "id" : 14074102
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 31, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "134755314066141184",
  "text" : "RT @Ad_Recruiter: Question for #WHChat: Job Search has changed drastically in the new Social Media Era, are Veterans getting training on ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 13, 20 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "134741819132084224",
    "text" : "Question for #WHChat: Job Search has changed drastically in the new Social Media Era, are Veterans getting training on this?",
    "id" : 134741819132084224,
    "created_at" : "2011-11-10 21:18:47 +0000",
    "user" : {
      "name" : "Christie Cordes",
      "screen_name" : "Ad_Recruiter",
      "protected" : false,
      "id_str" : "14074102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/732767728919031809\/UGPXUtPp_normal.jpg",
      "id" : 14074102,
      "verified" : false
    }
  },
  "id" : 134755314066141184,
  "created_at" : "2011-11-10 22:12:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "134752317042991106",
  "text" : "RT @WHLive: Hey everyone, this is Matt Flavin, Director of Veterans and Wounded Warrior Policy at the WH. Looking forward to your questi ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHCHAT",
        "indices" : [ 128, 135 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "134752090869338114",
    "text" : "Hey everyone, this is Matt Flavin, Director of Veterans and Wounded Warrior Policy at the WH. Looking forward to your questions #WHCHAT.",
    "id" : 134752090869338114,
    "created_at" : "2011-11-10 21:59:36 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 134752317042991106,
  "created_at" : "2011-11-10 22:00:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "veterans",
      "indices" : [ 126, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "134743237213687808",
  "text" : "Obama: Today, Rs & Ds in the Senate did the right thing & passed tax credits that will encourage businesses to hire America\u2019s #veterans",
  "id" : 134743237213687808,
  "created_at" : "2011-11-10 21:24:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 128, 135 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "veterans",
      "indices" : [ 46, 55 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 83, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "134725794894319617",
  "text" : "RT @WHLive: Have Qs on new initiatives to get #veterans back to work? Ask now with #WHChat. WH veterans policy director will be @WHLive  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "White House Live",
        "screen_name" : "WHLive",
        "indices" : [ 116, 123 ],
        "id_str" : "369505837",
        "id" : 369505837
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "veterans",
        "indices" : [ 34, 43 ]
      }, {
        "text" : "WHChat",
        "indices" : [ 71, 78 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "134725669857923073",
    "text" : "Have Qs on new initiatives to get #veterans back to work? Ask now with #WHChat. WH veterans policy director will be @WHLive @ 5ET to A.",
    "id" : 134725669857923073,
    "created_at" : "2011-11-10 20:14:37 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 134725794894319617,
  "created_at" : "2011-11-10 20:15:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "netneutrality",
      "indices" : [ 101, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "134716892056256512",
  "text" : "The open internet is essential for American jobs & society. Glad to see the Senate reaffirm balanced #netneutrality rules. \u2013BO",
  "id" : 134716892056256512,
  "created_at" : "2011-11-10 19:39:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "veterans",
      "indices" : [ 50, 59 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 131, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/jZAmNerh",
      "expanded_url" : "http:\/\/ow.ly\/7ppey",
      "display_url" : "ow.ly\/7ppey"
    } ]
  },
  "geo" : { },
  "id_str" : "134689573203738625",
  "text" : "WH Office Hours @ 5ET w\/ Matt Flavin, director of #veterans policy, on getting vets back to work: http:\/\/t.co\/jZAmNerh Ask Qs now: #WHChat",
  "id" : 134689573203738625,
  "created_at" : "2011-11-10 17:51:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHFellows",
      "indices" : [ 79, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "134670304382427136",
  "text" : "Starting @ 12 pm: Open for Questions on the WH Fellows Program.  Ask a Q using #WHFellows & watch live at http:\/\/t.co\/u95y7hhB",
  "id" : 134670304382427136,
  "created_at" : "2011-11-10 16:34:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Homeland Security",
      "screen_name" : "DHSgov",
      "indices" : [ 25, 32 ],
      "id_str" : "15647676",
      "id" : 15647676
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "veterans",
      "indices" : [ 101, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/hoc19bmS",
      "expanded_url" : "http:\/\/ow.ly\/7pazr",
      "display_url" : "ow.ly\/7pazr"
    } ]
  },
  "geo" : { },
  "id_str" : "134650441488273408",
  "text" : "Veterans comprise 25% of @DHSgov civilian workforce. Department of Homeland Security's commitment to #veterans: http:\/\/t.co\/hoc19bmS",
  "id" : 134650441488273408,
  "created_at" : "2011-11-10 15:15:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHFellows",
      "indices" : [ 129, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http:\/\/t.co\/txentbKy",
      "expanded_url" : "http:\/\/ow.ly\/7oxlc",
      "display_url" : "ow.ly\/7oxlc"
    } ]
  },
  "geo" : { },
  "id_str" : "134419801354412032",
  "text" : "Open for Questions: WH Fellows Program: http:\/\/t.co\/txentbKy Have Qs on the fellowship for leadership & public service? Ask now: #WHFellows",
  "id" : 134419801354412032,
  "created_at" : "2011-11-09 23:59:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Carson",
      "screen_name" : "JonCarson44",
      "indices" : [ 3, 15 ],
      "id_str" : "1287388789",
      "id" : 1287388789
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 38, 49 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "HelloGiggles.com",
      "screen_name" : "hellogiggles",
      "indices" : [ 50, 63 ],
      "id_str" : "219682445",
      "id" : 219682445
    }, {
      "name" : "Art Cart NYC TM",
      "screen_name" : "ArtCartNYC",
      "indices" : [ 74, 85 ],
      "id_str" : "140496356",
      "id" : 140496356
    }, {
      "name" : "kellEY lonergan",
      "screen_name" : "EwhY",
      "indices" : [ 86, 91 ],
      "id_str" : "14081898",
      "id" : 14081898
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/hCSuLRIn",
      "expanded_url" : "http:\/\/1.usa.gov\/urRuvQ",
      "display_url" : "1.usa.gov\/urRuvQ"
    } ]
  },
  "geo" : { },
  "id_str" : "134405058426175490",
  "text" : "RT @JonCarson44: Check out the latest @whitehouse @hellogiggles blog! Thx @artcartnyc @ewhy http:\/\/t.co\/hCSuLRIn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 21, 32 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "HelloGiggles.com",
        "screen_name" : "hellogiggles",
        "indices" : [ 33, 46 ],
        "id_str" : "219682445",
        "id" : 219682445
      }, {
        "name" : "Art Cart NYC TM",
        "screen_name" : "ArtCartNYC",
        "indices" : [ 57, 68 ],
        "id_str" : "140496356",
        "id" : 140496356
      }, {
        "name" : "kellEY lonergan",
        "screen_name" : "EwhY",
        "indices" : [ 69, 74 ],
        "id_str" : "14081898",
        "id" : 14081898
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 95 ],
        "url" : "http:\/\/t.co\/hCSuLRIn",
        "expanded_url" : "http:\/\/1.usa.gov\/urRuvQ",
        "display_url" : "1.usa.gov\/urRuvQ"
      } ]
    },
    "geo" : { },
    "id_str" : "134393846099492865",
    "text" : "Check out the latest @whitehouse @hellogiggles blog! Thx @artcartnyc @ewhy http:\/\/t.co\/hCSuLRIn",
    "id" : 134393846099492865,
    "created_at" : "2011-11-09 22:16:04 +0000",
    "user" : {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "protected" : false,
      "id_str" : "369232105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623146355767140352\/58sqoVrw_normal.jpg",
      "id" : 369232105,
      "verified" : true
    }
  },
  "id" : 134405058426175490,
  "created_at" : "2011-11-09 23:00:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/134377757424619520\/photo\/1",
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/Fubq8k1A",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ad1n28FCEAEm9EC.jpg",
      "id_str" : "134377757428813825",
      "id" : 134377757428813825,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ad1n28FCEAEm9EC.jpg",
      "sizes" : [ {
        "h" : 315,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 315,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 315,
        "resize" : "fit",
        "w" : 560
      } ],
      "display_url" : "pic.twitter.com\/Fubq8k1A"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http:\/\/t.co\/NbRUbU3m",
      "expanded_url" : "http:\/\/1.usa.gov\/seJ6o3",
      "display_url" : "1.usa.gov\/seJ6o3"
    } ]
  },
  "geo" : { },
  "id_str" : "134377757424619520",
  "text" : "By the Numbers: $3.5 Billion: http:\/\/t.co\/NbRUbU3m Pic: http:\/\/t.co\/Fubq8k1A",
  "id" : 134377757424619520,
  "created_at" : "2011-11-09 21:12:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brandon Friedman",
      "screen_name" : "BFriedmanDC",
      "indices" : [ 3, 15 ],
      "id_str" : "15327996",
      "id" : 15327996
    }, {
      "name" : "At War",
      "screen_name" : "nytimesatwar",
      "indices" : [ 61, 74 ],
      "id_str" : "16954241",
      "id" : 16954241
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "134374452682166272",
  "text" : "RT @BFriedmanDC: My NYT piece on the end of the Iraq War. RT @NYTimesAtWar: For Soldiers, the End of the Mail Means the End of the War h ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "At War",
        "screen_name" : "nytimesatwar",
        "indices" : [ 44, 57 ],
        "id_str" : "16954241",
        "id" : 16954241
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/mjzeaUfl",
        "expanded_url" : "http:\/\/atwar.blogs.nytimes.com\/2011\/11\/09\/for-soldiers-the-end-of-the-mail-means-the-end-of-the-war\/",
        "display_url" : "atwar.blogs.nytimes.com\/2011\/11\/09\/for\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "134361842238750720",
    "text" : "My NYT piece on the end of the Iraq War. RT @NYTimesAtWar: For Soldiers, the End of the Mail Means the End of the War http:\/\/t.co\/mjzeaUfl",
    "id" : 134361842238750720,
    "created_at" : "2011-11-09 20:08:54 +0000",
    "user" : {
      "name" : "Brandon Friedman",
      "screen_name" : "BFriedmanDC",
      "protected" : false,
      "id_str" : "15327996",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/649427993161433088\/nzkLsEDl_normal.jpg",
      "id" : 15327996,
      "verified" : true
    }
  },
  "id" : 134374452682166272,
  "created_at" : "2011-11-09 20:59:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 19, 30 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHTweetup",
      "indices" : [ 84, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/n1Hl3nRv",
      "expanded_url" : "http:\/\/wh.gov\/tweetup",
      "display_url" : "wh.gov\/tweetup"
    } ]
  },
  "geo" : { },
  "id_str" : "134359110526316544",
  "text" : "Ever wanted to see @WhiteHouse all dressed up for the holidays? Announcing the next #WHTweetup on 12\/5. Apply now: http:\/\/t.co\/n1Hl3nRv",
  "id" : 134359110526316544,
  "created_at" : "2011-11-09 19:58:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The FCC",
      "screen_name" : "FCC",
      "indices" : [ 21, 25 ],
      "id_str" : "66369206",
      "id" : 66369206
    }, {
      "name" : "FEMA",
      "screen_name" : "fema",
      "indices" : [ 28, 33 ],
      "id_str" : "16669075",
      "id" : 16669075
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "134344968419545088",
  "text" : "This is just a test. @FCC & @FEMA nationwide test of the Emergency Alert System is happening now.",
  "id" : 134344968419545088,
  "created_at" : "2011-11-09 19:01:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The FCC",
      "screen_name" : "FCC",
      "indices" : [ 3, 7 ],
      "id_str" : "66369206",
      "id" : 66369206
    }, {
      "name" : "The FCC",
      "screen_name" : "FCC",
      "indices" : [ 23, 27 ],
      "id_str" : "66369206",
      "id" : 66369206
    }, {
      "name" : "FEMA",
      "screen_name" : "fema",
      "indices" : [ 32, 37 ],
      "id_str" : "16669075",
      "id" : 16669075
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "134344703096270849",
  "text" : "RT @FCC: Presently the @FCC and @FEMA are testing the national Emergency Alert System",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The FCC",
        "screen_name" : "FCC",
        "indices" : [ 14, 18 ],
        "id_str" : "66369206",
        "id" : 66369206
      }, {
        "name" : "FEMA",
        "screen_name" : "fema",
        "indices" : [ 23, 28 ],
        "id_str" : "16669075",
        "id" : 16669075
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "134344544887119872",
    "text" : "Presently the @FCC and @FEMA are testing the national Emergency Alert System",
    "id" : 134344544887119872,
    "created_at" : "2011-11-09 19:00:10 +0000",
    "user" : {
      "name" : "The FCC",
      "screen_name" : "FCC",
      "protected" : false,
      "id_str" : "66369206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1303190571\/twitter_fcc_icon_normal.png",
      "id" : 66369206,
      "verified" : true
    }
  },
  "id" : 134344703096270849,
  "created_at" : "2011-11-09 19:00:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThisIsATest",
      "indices" : [ 119, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "134338173496066048",
  "text" : "Today @ 2ET there will be a nationwide test of the Emergency Alert System via TV & radio. RT to help get the word out. #ThisIsATest",
  "id" : 134338173496066048,
  "created_at" : "2011-11-09 18:34:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 3, 11 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "134335316604616704",
  "text" : "RT @macon44: POPQUIZ: Who knows what nationwide thing is happening today @ 2pm Eastern?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "134334460245184512",
    "text" : "POPQUIZ: Who knows what nationwide thing is happening today @ 2pm Eastern?",
    "id" : 134334460245184512,
    "created_at" : "2011-11-09 18:20:05 +0000",
    "user" : {
      "name" : "Macon Phillips",
      "screen_name" : "IIPCoordinator",
      "protected" : false,
      "id_str" : "110823581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000495374915\/f6a5ae048ab7f8f12c0386114df53203_normal.jpeg",
      "id" : 110823581,
      "verified" : true
    }
  },
  "id" : 134335316604616704,
  "created_at" : "2011-11-09 18:23:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Carson",
      "screen_name" : "JonCarson44",
      "indices" : [ 3, 15 ],
      "id_str" : "1287388789",
      "id" : 1287388789
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 128, 131 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HOACrisis",
      "indices" : [ 51, 61 ]
    }, {
      "text" : "FWDatWH",
      "indices" : [ 119, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/qxePFsxR",
      "expanded_url" : "http:\/\/www.youtube.com\/usaidvideo?x=us_showcase_6_3",
      "display_url" : "youtube.com\/usaidvideo?x=u\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "134317173853270017",
  "text" : "RT @JonCarson44: Check out Dr. Biden's video about #HOACrisis - 1 child is dying every  6 minutes http:\/\/t.co\/qxePFsxR\n#FWDatWH @VP @Whi ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 111, 114 ],
        "id_str" : "325830217",
        "id" : 325830217
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 115, 126 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HOACrisis",
        "indices" : [ 34, 44 ]
      }, {
        "text" : "FWDatWH",
        "indices" : [ 102, 110 ]
      } ],
      "urls" : [ {
        "indices" : [ 81, 101 ],
        "url" : "http:\/\/t.co\/qxePFsxR",
        "expanded_url" : "http:\/\/www.youtube.com\/usaidvideo?x=us_showcase_6_3",
        "display_url" : "youtube.com\/usaidvideo?x=u\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "134312938487037952",
    "text" : "Check out Dr. Biden's video about #HOACrisis - 1 child is dying every  6 minutes http:\/\/t.co\/qxePFsxR\n#FWDatWH @VP @Whitehouse",
    "id" : 134312938487037952,
    "created_at" : "2011-11-09 16:54:34 +0000",
    "user" : {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "protected" : false,
      "id_str" : "369232105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623146355767140352\/58sqoVrw_normal.jpg",
      "id" : 369232105,
      "verified" : true
    }
  },
  "id" : 134317173853270017,
  "created_at" : "2011-11-09 17:11:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Carson",
      "screen_name" : "JonCarson44",
      "indices" : [ 3, 15 ],
      "id_str" : "1287388789",
      "id" : 1287388789
    }, {
      "name" : "GOOD",
      "screen_name" : "good",
      "indices" : [ 95, 100 ],
      "id_str" : "19621110",
      "id" : 19621110
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HOACrisis",
      "indices" : [ 58, 68 ]
    }, {
      "text" : "FWDatWH",
      "indices" : [ 122, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/2kzx6Sjg",
      "expanded_url" : "http:\/\/fwd.maker.good.is\/",
      "display_url" : "fwd.maker.good.is"
    } ]
  },
  "geo" : { },
  "id_str" : "134312885752045568",
  "text" : "RT @JonCarson44: What are you doing to raise awareness of #HOACrisis? check out this challenge @Good http:\/\/t.co\/2kzx6Sjg\n#FWDatWH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "GOOD",
        "screen_name" : "good",
        "indices" : [ 78, 83 ],
        "id_str" : "19621110",
        "id" : 19621110
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HOACrisis",
        "indices" : [ 41, 51 ]
      }, {
        "text" : "FWDatWH",
        "indices" : [ 105, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 104 ],
        "url" : "http:\/\/t.co\/2kzx6Sjg",
        "expanded_url" : "http:\/\/fwd.maker.good.is\/",
        "display_url" : "fwd.maker.good.is"
      } ]
    },
    "geo" : { },
    "id_str" : "134307496809607168",
    "text" : "What are you doing to raise awareness of #HOACrisis? check out this challenge @Good http:\/\/t.co\/2kzx6Sjg\n#FWDatWH",
    "id" : 134307496809607168,
    "created_at" : "2011-11-09 16:32:57 +0000",
    "user" : {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "protected" : false,
      "id_str" : "369232105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623146355767140352\/58sqoVrw_normal.jpg",
      "id" : 369232105,
      "verified" : true
    }
  },
  "id" : 134312885752045568,
  "created_at" : "2011-11-09 16:54:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The FCC",
      "screen_name" : "FCC",
      "indices" : [ 3, 7 ],
      "id_str" : "66369206",
      "id" : 66369206
    }, {
      "name" : "The FCC",
      "screen_name" : "FCC",
      "indices" : [ 20, 24 ],
      "id_str" : "66369206",
      "id" : 66369206
    }, {
      "name" : "FEMA",
      "screen_name" : "fema",
      "indices" : [ 29, 34 ],
      "id_str" : "16669075",
      "id" : 16669075
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "134309037473935360",
  "text" : "RT @FCC: Today, the @FCC and @FEMA will be conducting the nationwide test of the Emergency Alert System at 2:00PM EST",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The FCC",
        "screen_name" : "FCC",
        "indices" : [ 11, 15 ],
        "id_str" : "66369206",
        "id" : 66369206
      }, {
        "name" : "FEMA",
        "screen_name" : "fema",
        "indices" : [ 20, 25 ],
        "id_str" : "16669075",
        "id" : 16669075
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "134308603082448897",
    "text" : "Today, the @FCC and @FEMA will be conducting the nationwide test of the Emergency Alert System at 2:00PM EST",
    "id" : 134308603082448897,
    "created_at" : "2011-11-09 16:37:20 +0000",
    "user" : {
      "name" : "The FCC",
      "screen_name" : "FCC",
      "protected" : false,
      "id_str" : "66369206",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1303190571\/twitter_fcc_icon_normal.png",
      "id" : 66369206,
      "verified" : true
    }
  },
  "id" : 134309037473935360,
  "created_at" : "2011-11-09 16:39:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SAVEAward",
      "indices" : [ 21, 31 ]
    } ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http:\/\/t.co\/tr6M08O5",
      "expanded_url" : "http:\/\/wh.gov\/Save-Award",
      "display_url" : "wh.gov\/Save-Award"
    } ]
  },
  "geo" : { },
  "id_str" : "134308078001729538",
  "text" : "Help choose the 2011 #SAVEAward winner! Vote now: http:\/\/t.co\/tr6M08O5",
  "id" : 134308078001729538,
  "created_at" : "2011-11-09 16:35:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 1, 6 ],
      "id_str" : "11348282",
      "id" : 11348282
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SAVEAward",
      "indices" : [ 24, 34 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/9ctQL9Px",
      "expanded_url" : "http:\/\/wh.gov\/save-Award",
      "display_url" : "wh.gov\/save-Award"
    } ]
  },
  "geo" : { },
  "id_str" : "134306799116496896",
  "text" : ".@NASA's Matthew Ritsko #SAVEAward idea: a \u201Clending library\u201D to avoid duplicative purchases of expensive tools: http:\/\/t.co\/9ctQL9Px",
  "id" : 134306799116496896,
  "created_at" : "2011-11-09 16:30:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SAVEAward",
      "indices" : [ 95, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/tr6M08O5",
      "expanded_url" : "http:\/\/wh.gov\/Save-Award",
      "display_url" : "wh.gov\/Save-Award"
    } ]
  },
  "geo" : { },
  "id_str" : "134304535807148032",
  "text" : "Ever wonder what it's like to teleconference w\/ the President in the SitRoom? Happening now w\/ #SAVEAward final 4: http:\/\/t.co\/tr6M08O5",
  "id" : 134304535807148032,
  "created_at" : "2011-11-09 16:21:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SAVEAward",
      "indices" : [ 42, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/tr6M08O5",
      "expanded_url" : "http:\/\/wh.gov\/Save-Award",
      "display_url" : "wh.gov\/Save-Award"
    } ]
  },
  "geo" : { },
  "id_str" : "134304209188290561",
  "text" : "WATCH NOW: President Obama just surprised #SAVEAward finalists: http:\/\/t.co\/tr6M08O5",
  "id" : 134304209188290561,
  "created_at" : "2011-11-09 16:19:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SAVEAward",
      "indices" : [ 15, 25 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/tr6M08O5",
      "expanded_url" : "http:\/\/wh.gov\/Save-Award",
      "display_url" : "wh.gov\/Save-Award"
    } ]
  },
  "geo" : { },
  "id_str" : "134303992493785088",
  "text" : "Happening now: #SAVEAward finalists join WH officials for live video tele-conf: Watch: http:\/\/t.co\/tr6M08O5 (Obama will be there soon)",
  "id" : 134303992493785088,
  "created_at" : "2011-11-09 16:19:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SAVEAward",
      "indices" : [ 0, 10 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "134297623233441792",
  "text" : "#SAVEAward finalists are in for a surprise... The President is dropping by video conf. Don't miss the reaction @ 11ET http:\/\/t.co\/u95y7hhB",
  "id" : 134297623233441792,
  "created_at" : "2011-11-09 15:53:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "indices" : [ 3, 12 ],
      "id_str" : "337742544",
      "id" : 337742544
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "saveaward",
      "indices" : [ 18, 28 ]
    }, {
      "text" : "cuttingwaste",
      "indices" : [ 121, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/C3hn2svT",
      "expanded_url" : "http:\/\/1.usa.gov\/UT2FE",
      "display_url" : "1.usa.gov\/UT2FE"
    } ]
  },
  "geo" : { },
  "id_str" : "134293620718182401",
  "text" : "RT @OMBPress: '11 #saveaward final 4 to participate in live video-teleconf, 11am today; watch here: http:\/\/t.co\/C3hn2svT #cuttingwaste",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "saveaward",
        "indices" : [ 4, 14 ]
      }, {
        "text" : "cuttingwaste",
        "indices" : [ 107, 120 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 106 ],
        "url" : "http:\/\/t.co\/C3hn2svT",
        "expanded_url" : "http:\/\/1.usa.gov\/UT2FE",
        "display_url" : "1.usa.gov\/UT2FE"
      } ]
    },
    "geo" : { },
    "id_str" : "134287672310104065",
    "text" : "'11 #saveaward final 4 to participate in live video-teleconf, 11am today; watch here: http:\/\/t.co\/C3hn2svT #cuttingwaste",
    "id" : 134287672310104065,
    "created_at" : "2011-11-09 15:14:10 +0000",
    "user" : {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "protected" : false,
      "id_str" : "337742544",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1449289379\/OMB_Seal_normal.jpg",
      "id" : 337742544,
      "verified" : true
    }
  },
  "id" : 134293620718182401,
  "created_at" : "2011-11-09 15:37:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "134285087662538752",
  "text" : "Today, the President continues we can't wait campaign & signs Executive Order to cut waste & promote efficient spending across federal govt",
  "id" : 134285087662538752,
  "created_at" : "2011-11-09 15:03:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FEMA",
      "screen_name" : "fema",
      "indices" : [ 3, 8 ],
      "id_str" : "16669075",
      "id" : 16669075
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/Un8vbTGA",
      "expanded_url" : "http:\/\/fema.gov\/eastest",
      "display_url" : "fema.gov\/eastest"
    } ]
  },
  "geo" : { },
  "id_str" : "134085598347657218",
  "text" : "RT @fema: If you\u2019re watching TV or listening to radio tomorrow (Nov 9) at 2 pm EST, you\u2019ll hear \u201Cthis is a test\u201D http:\/\/t.co\/Un8vbTGA Pls RT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 123 ],
        "url" : "http:\/\/t.co\/Un8vbTGA",
        "expanded_url" : "http:\/\/fema.gov\/eastest",
        "display_url" : "fema.gov\/eastest"
      } ]
    },
    "geo" : { },
    "id_str" : "133891157234155521",
    "text" : "If you\u2019re watching TV or listening to radio tomorrow (Nov 9) at 2 pm EST, you\u2019ll hear \u201Cthis is a test\u201D http:\/\/t.co\/Un8vbTGA Pls RT",
    "id" : 133891157234155521,
    "created_at" : "2011-11-08 12:58:34 +0000",
    "user" : {
      "name" : "FEMA",
      "screen_name" : "fema",
      "protected" : false,
      "id_str" : "16669075",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2620163192\/j143q33k69loivqmp2dg_normal.gif",
      "id" : 16669075,
      "verified" : true
    }
  },
  "id" : 134085598347657218,
  "created_at" : "2011-11-09 01:51:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/4Nnz5af2",
      "expanded_url" : "http:\/\/go.usa.gov\/ICq",
      "display_url" : "go.usa.gov\/ICq"
    } ]
  },
  "geo" : { },
  "id_str" : "134046495455461376",
  "text" : "RT @arneduncan: Our Children Can\u2019t Wait: New Regulations Increase Accountability & Boost Quality in Head Start http:\/\/t.co\/4Nnz5af2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 115 ],
        "url" : "http:\/\/t.co\/4Nnz5af2",
        "expanded_url" : "http:\/\/go.usa.gov\/ICq",
        "display_url" : "go.usa.gov\/ICq"
      } ]
    },
    "geo" : { },
    "id_str" : "134034702028914688",
    "text" : "Our Children Can\u2019t Wait: New Regulations Increase Accountability & Boost Quality in Head Start http:\/\/t.co\/4Nnz5af2",
    "id" : 134034702028914688,
    "created_at" : "2011-11-08 22:28:57 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 134046495455461376,
  "created_at" : "2011-11-08 23:15:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/134004357879447552\/photo\/1",
      "indices" : [ 51, 71 ],
      "url" : "http:\/\/t.co\/cgEXzqoF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AdwUQOYCQAA880W.jpg",
      "id_str" : "134004357883641856",
      "id" : 134004357883641856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AdwUQOYCQAA880W.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      } ],
      "display_url" : "pic.twitter.com\/cgEXzqoF"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http:\/\/t.co\/OPu2koS0",
      "expanded_url" : "http:\/\/1.usa.gov\/t3oYDy",
      "display_url" : "1.usa.gov\/t3oYDy"
    } ]
  },
  "geo" : { },
  "id_str" : "134004357879447552",
  "text" : "By the Numbers: $500 Million: http:\/\/t.co\/OPu2koS0 http:\/\/t.co\/cgEXzqoF",
  "id" : 134004357879447552,
  "created_at" : "2011-11-08 20:28:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "netneutrality",
      "indices" : [ 62, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/VnqEfWb4",
      "expanded_url" : "http:\/\/1.usa.gov\/rsAkEv",
      "display_url" : "1.usa.gov\/rsAkEv"
    } ]
  },
  "geo" : { },
  "id_str" : "133957486939086848",
  "text" : "The President\u2019s Senior Advisers would recommend veto of anti- #netneutrality bill, need internet to stay free & open: http:\/\/t.co\/VnqEfWb4",
  "id" : 133957486939086848,
  "created_at" : "2011-11-08 17:22:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "133952900501217281",
  "text" : "\"Our future is at stake. Our children deserve action & we can\u2019t wait for Congress any longer\" -Pres Obama on actions to improve Head Start",
  "id" : 133952900501217281,
  "created_at" : "2011-11-08 17:03:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/hhNoX4fh",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "133950420811911168",
  "text" : "Happening now: President Obama speaks on education & next step in \"We Can\u2019t Wait\u201D campaign. Watch live: http:\/\/t.co\/hhNoX4fh",
  "id" : 133950420811911168,
  "created_at" : "2011-11-08 16:54:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "133937472911585280",
  "text" : "RT @pfeiffer44: Bc We Can't Wait for Congress to act on education, POTUS will announce today that he is mandating head start reforms htt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 137 ],
        "url" : "http:\/\/t.co\/mFQJkCK8",
        "expanded_url" : "http:\/\/usat.ly\/uHNHCu",
        "display_url" : "usat.ly\/uHNHCu"
      } ]
    },
    "geo" : { },
    "id_str" : "133883515589754881",
    "text" : "Bc We Can't Wait for Congress to act on education, POTUS will announce today that he is mandating head start reforms http:\/\/t.co\/mFQJkCK8",
    "id" : 133883515589754881,
    "created_at" : "2011-11-08 12:28:12 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 133937472911585280,
  "created_at" : "2011-11-08 16:02:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "veterans",
      "indices" : [ 22, 31 ]
    }, {
      "text" : "vets",
      "indices" : [ 70, 75 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/23gFxvOn",
      "expanded_url" : "http:\/\/youtu.be\/63_-hJNEoyA",
      "display_url" : "youtu.be\/63_-hJNEoyA"
    } ]
  },
  "geo" : { },
  "id_str" : "133708916252086273",
  "text" : "Video: How to use the #veterans job bank - a new tool to help connect #vets with employers: http:\/\/t.co\/23gFxvOn",
  "id" : 133708916252086273,
  "created_at" : "2011-11-08 00:54:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SBA",
      "screen_name" : "SBAgov",
      "indices" : [ 3, 10 ],
      "id_str" : "153149305",
      "id" : 153149305
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SBAyes",
      "indices" : [ 41, 48 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/ZFUbsDJ2",
      "expanded_url" : "http:\/\/owl.li\/7k6jM",
      "display_url" : "owl.li\/7k6jM"
    } ]
  },
  "geo" : { },
  "id_str" : "133666733549551616",
  "text" : "RT @SBAgov: We\u2019re in San Diego today for #SBAyes! Submit your questions on Twitter & watch it live at http:\/\/t.co\/ZFUbsDJ2 at 6:00 PM PST",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SBAyes",
        "indices" : [ 29, 36 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 110 ],
        "url" : "http:\/\/t.co\/ZFUbsDJ2",
        "expanded_url" : "http:\/\/owl.li\/7k6jM",
        "display_url" : "owl.li\/7k6jM"
      } ]
    },
    "geo" : { },
    "id_str" : "133665086215696385",
    "text" : "We\u2019re in San Diego today for #SBAyes! Submit your questions on Twitter & watch it live at http:\/\/t.co\/ZFUbsDJ2 at 6:00 PM PST",
    "id" : 133665086215696385,
    "created_at" : "2011-11-07 22:00:14 +0000",
    "user" : {
      "name" : "SBA",
      "screen_name" : "SBAgov",
      "protected" : false,
      "id_str" : "153149305",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/637366120236756992\/ky6enEIv_normal.png",
      "id" : 153149305,
      "verified" : true
    }
  },
  "id" : 133666733549551616,
  "created_at" : "2011-11-07 22:06:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Veterans",
      "indices" : [ 30, 39 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/2wdmmomi",
      "expanded_url" : "http:\/\/ow.ly\/7lPZv",
      "display_url" : "ow.ly\/7lPZv"
    } ]
  },
  "geo" : { },
  "id_str" : "133655484573032449",
  "text" : "Obama Administration launches #Veterans Job Bank: a new search tool designed to help connect veterans with employers: http:\/\/t.co\/2wdmmomi",
  "id" : 133655484573032449,
  "created_at" : "2011-11-07 21:22:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simply Hired",
      "screen_name" : "SimplyHired",
      "indices" : [ 3, 15 ],
      "id_str" : "8310782",
      "id" : 8310782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 37 ],
      "url" : "http:\/\/t.co\/B36NXSau",
      "expanded_url" : "http:\/\/SimplyHired.com",
      "display_url" : "SimplyHired.com"
    }, {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/26svijgq",
      "expanded_url" : "http:\/\/bit.ly\/uk1nDI",
      "display_url" : "bit.ly\/uk1nDI"
    } ]
  },
  "geo" : { },
  "id_str" : "133642077094424577",
  "text" : "RT @SimplyHired: http:\/\/t.co\/B36NXSau and the Veterans Job Bank Initiative - http:\/\/t.co\/26svijgq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 20 ],
        "url" : "http:\/\/t.co\/B36NXSau",
        "expanded_url" : "http:\/\/SimplyHired.com",
        "display_url" : "SimplyHired.com"
      }, {
        "indices" : [ 60, 80 ],
        "url" : "http:\/\/t.co\/26svijgq",
        "expanded_url" : "http:\/\/bit.ly\/uk1nDI",
        "display_url" : "bit.ly\/uk1nDI"
      } ]
    },
    "geo" : { },
    "id_str" : "133610371826196480",
    "text" : "http:\/\/t.co\/B36NXSau and the Veterans Job Bank Initiative - http:\/\/t.co\/26svijgq",
    "id" : 133610371826196480,
    "created_at" : "2011-11-07 18:22:51 +0000",
    "user" : {
      "name" : "Simply Hired",
      "screen_name" : "SimplyHired",
      "protected" : false,
      "id_str" : "8310782",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/344513261570733422\/e2808e041fafd0e27a1f961fc518e3fc_normal.png",
      "id" : 8310782,
      "verified" : false
    }
  },
  "id" : 133642077094424577,
  "created_at" : "2011-11-07 20:28:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LinkedIn",
      "screen_name" : "LinkedIn",
      "indices" : [ 3, 12 ],
      "id_str" : "13058772",
      "id" : 13058772
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "in",
      "indices" : [ 111, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/VSe4Esu0",
      "expanded_url" : "http:\/\/bit.ly\/vFFzZR",
      "display_url" : "bit.ly\/vFFzZR"
    } ]
  },
  "geo" : { },
  "id_str" : "133634540982906880",
  "text" : "RT @LinkedIn: new post: LinkedIn Joins Forces with White House to help America\u2019s Veterans http:\/\/t.co\/VSe4Esu0 #in",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "in",
        "indices" : [ 97, 100 ]
      } ],
      "urls" : [ {
        "indices" : [ 76, 96 ],
        "url" : "http:\/\/t.co\/VSe4Esu0",
        "expanded_url" : "http:\/\/bit.ly\/vFFzZR",
        "display_url" : "bit.ly\/vFFzZR"
      } ]
    },
    "geo" : { },
    "id_str" : "133590479500611584",
    "text" : "new post: LinkedIn Joins Forces with White House to help America\u2019s Veterans http:\/\/t.co\/VSe4Esu0 #in",
    "id" : 133590479500611584,
    "created_at" : "2011-11-07 17:03:46 +0000",
    "user" : {
      "name" : "LinkedIn",
      "screen_name" : "LinkedIn",
      "protected" : false,
      "id_str" : "13058772",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614583061448036352\/CBpFkPaz_normal.png",
      "id" : 13058772,
      "verified" : true
    }
  },
  "id" : 133634540982906880,
  "created_at" : "2011-11-07 19:58:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "veterans",
      "indices" : [ 5, 14 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/ZMRSeVv7",
      "expanded_url" : "http:\/\/ow.ly\/7lJjU",
      "display_url" : "ow.ly\/7lJjU"
    } ]
  },
  "geo" : { },
  "id_str" : "133633409955274753",
  "text" : "\"Our #veterans did their jobs. It\u2019s time for Congress to do theirs\" -Obama on new initiatives to get vets back to work: http:\/\/t.co\/ZMRSeVv7",
  "id" : 133633409955274753,
  "created_at" : "2011-11-07 19:54:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Carson",
      "screen_name" : "JonCarson44",
      "indices" : [ 3, 15 ],
      "id_str" : "1287388789",
      "id" : 1287388789
    }, {
      "name" : "craignewmark",
      "screen_name" : "craignewmark",
      "indices" : [ 68, 81 ],
      "id_str" : "14368074",
      "id" : 14368074
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 87, 98 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "Jon Carson",
      "screen_name" : "JonCarson44",
      "indices" : [ 124, 136 ],
      "id_str" : "1287388789",
      "id" : 1287388789
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "133627186384089088",
  "text" : "RT @JonCarson44: about to start our Twitter Q&A on vets issues with @craignewmark here @Whitehouse.  Send your questions to @JonCarson44 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "craignewmark",
        "screen_name" : "craignewmark",
        "indices" : [ 51, 64 ],
        "id_str" : "14368074",
        "id" : 14368074
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 70, 81 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "Jon Carson",
        "screen_name" : "JonCarson44",
        "indices" : [ 107, 119 ],
        "id_str" : "1287388789",
        "id" : 1287388789
      }, {
        "name" : "craignewmark",
        "screen_name" : "craignewmark",
        "indices" : [ 124, 137 ],
        "id_str" : "14368074",
        "id" : 14368074
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "133624760629346304",
    "text" : "about to start our Twitter Q&A on vets issues with @craignewmark here @Whitehouse.  Send your questions to @JonCarson44 and @craignewmark",
    "id" : 133624760629346304,
    "created_at" : "2011-11-07 19:20:00 +0000",
    "user" : {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "protected" : false,
      "id_str" : "369232105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623146355767140352\/58sqoVrw_normal.jpg",
      "id" : 369232105,
      "verified" : true
    }
  },
  "id" : 133627186384089088,
  "created_at" : "2011-11-07 19:29:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/133626568454053888\/photo\/1",
      "indices" : [ 73, 93 ],
      "url" : "http:\/\/t.co\/DNnL4nhY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Adq8p_GCIAA5rnm.jpg",
      "id_str" : "133626568458248192",
      "id" : 133626568458248192,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Adq8p_GCIAA5rnm.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      } ],
      "display_url" : "pic.twitter.com\/DNnL4nhY"
    } ],
    "hashtags" : [ {
      "text" : "veterans",
      "indices" : [ 41, 50 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/oGrlmYR6",
      "expanded_url" : "http:\/\/1.usa.gov\/rK4VCt",
      "display_url" : "1.usa.gov\/rK4VCt"
    } ]
  },
  "geo" : { },
  "id_str" : "133626568454053888",
  "text" : "By the Numbers: 500,000 job postings for #veterans: http:\/\/t.co\/oGrlmYR6 http:\/\/t.co\/DNnL4nhY",
  "id" : 133626568454053888,
  "created_at" : "2011-11-07 19:27:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "veterans",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/iNv18gEV",
      "expanded_url" : "http:\/\/ow.ly\/7lw5s",
      "display_url" : "ow.ly\/7lw5s"
    } ]
  },
  "geo" : { },
  "id_str" : "133595874088587264",
  "text" : "We Can't Wait: President Obama announces new executive actions to get #veterans back to work: http:\/\/t.co\/iNv18gEV",
  "id" : 133595874088587264,
  "created_at" : "2011-11-07 17:25:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "vets",
      "indices" : [ 34, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "133594713008775168",
  "text" : "RT @WHLive: Obama: Connecting our #vets to the jobs they deserve isn\u2019t just the right thing to do for our vets \u2013 it\u2019s the right thing to ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "vets",
        "indices" : [ 22, 27 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "133594669941661697",
    "text" : "Obama: Connecting our #vets to the jobs they deserve isn\u2019t just the right thing to do for our vets \u2013 it\u2019s the right thing to do for America",
    "id" : 133594669941661697,
    "created_at" : "2011-11-07 17:20:26 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 133594713008775168,
  "created_at" : "2011-11-07 17:20:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "veterans",
      "indices" : [ 99, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "133593438892457984",
  "text" : "RT @WHLive: Obama: As Commander-in-Chief, I won\u2019t...let politics get in the way of making sure our #veterans share in the opportunity th ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "veterans",
        "indices" : [ 87, 96 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "133593281295695872",
    "text" : "Obama: As Commander-in-Chief, I won\u2019t...let politics get in the way of making sure our #veterans share in the opportunity they defend.",
    "id" : 133593281295695872,
    "created_at" : "2011-11-07 17:14:54 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 133593438892457984,
  "created_at" : "2011-11-07 17:15:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "vets",
      "indices" : [ 39, 44 ]
    } ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "133588877830144000",
  "text" : "Happening @ 12ET: Pres Obama joined by #vets groups to speak on veterans, American Jobs Act & new exec actions. Watch: http:\/\/t.co\/u95y7hhB",
  "id" : 133588877830144000,
  "created_at" : "2011-11-07 16:57:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "133577403883728896",
  "text" : "RT @jesseclee44: Just one more reason on local level to support it - Charlotte Observer Editorial on Jobs Act & NC community colleges ht ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 137 ],
        "url" : "http:\/\/t.co\/oZxQc9Pq",
        "expanded_url" : "http:\/\/bit.ly\/sxUpIn",
        "display_url" : "bit.ly\/sxUpIn"
      } ]
    },
    "geo" : { },
    "id_str" : "133575135658643456",
    "text" : "Just one more reason on local level to support it - Charlotte Observer Editorial on Jobs Act & NC community colleges http:\/\/t.co\/oZxQc9Pq",
    "id" : 133575135658643456,
    "created_at" : "2011-11-07 16:02:48 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 133577403883728896,
  "created_at" : "2011-11-07 16:11:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/ueXqB2pT",
      "expanded_url" : "http:\/\/bit.ly\/w33I8H",
      "display_url" : "bit.ly\/w33I8H"
    } ]
  },
  "geo" : { },
  "id_str" : "133564017695404033",
  "text" : "RT @petesouza: Backstage photos of Pres Obama and Jay Leno, and more from October: http:\/\/t.co\/ueXqB2pT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 88 ],
        "url" : "http:\/\/t.co\/ueXqB2pT",
        "expanded_url" : "http:\/\/bit.ly\/w33I8H",
        "display_url" : "bit.ly\/w33I8H"
      } ]
    },
    "geo" : { },
    "id_str" : "133561639323713536",
    "text" : "Backstage photos of Pres Obama and Jay Leno, and more from October: http:\/\/t.co\/ueXqB2pT",
    "id" : 133561639323713536,
    "created_at" : "2011-11-07 15:09:10 +0000",
    "user" : {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "protected" : false,
      "id_str" : "18215973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771916869808844800\/7d_poH48_normal.jpg",
      "id" : 18215973,
      "verified" : true
    }
  },
  "id" : 133564017695404033,
  "created_at" : "2011-11-07 15:18:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "133549340693237760",
  "text" : "RT @pfeiffer44: Today:POTUS will announce We Cant Wait actions to help vets and push Congress on the vets tax credit in the jobs act htt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 137 ],
        "url" : "http:\/\/t.co\/dzzBb7L2",
        "expanded_url" : "http:\/\/wapo.st\/u7ydq2",
        "display_url" : "wapo.st\/u7ydq2"
      } ]
    },
    "geo" : { },
    "id_str" : "133532902699962369",
    "text" : "Today:POTUS will announce We Cant Wait actions to help vets and push Congress on the vets tax credit in the jobs act http:\/\/t.co\/dzzBb7L2",
    "id" : 133532902699962369,
    "created_at" : "2011-11-07 13:14:59 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 133549340693237760,
  "created_at" : "2011-11-07 14:20:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 32, 35 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/fEUvmnTT",
      "expanded_url" : "http:\/\/youtu.be\/dwlIEGxmSus",
      "display_url" : "youtu.be\/dwlIEGxmSus"
    } ]
  },
  "geo" : { },
  "id_str" : "133202617173155842",
  "text" : "\"We have to increase the pace\" -@VP Biden. Watch the Weekly Address: http:\/\/t.co\/fEUvmnTT",
  "id" : 133202617173155842,
  "created_at" : "2011-11-06 15:22:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/D58ThtMF",
      "expanded_url" : "http:\/\/wh.gov\/advise",
      "display_url" : "wh.gov\/advise"
    } ]
  },
  "geo" : { },
  "id_str" : "132586999201796097",
  "text" : "We can't wait to put Americans back to work & we know some of the best ideas come from outside Washington. Share yours: http:\/\/t.co\/D58ThtMF",
  "id" : 132586999201796097,
  "created_at" : "2011-11-04 22:36:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NETWORK IS!",
      "screen_name" : "Reconnecting",
      "indices" : [ 77, 90 ],
      "id_str" : "2445706279",
      "id" : 2445706279
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "infrastructure",
      "indices" : [ 31, 46 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/ARYkXW2J",
      "expanded_url" : "http:\/\/youtu.be\/eOWDbi929as",
      "display_url" : "youtu.be\/eOWDbi929as"
    } ]
  },
  "geo" : { },
  "id_str" : "132572356991393793",
  "text" : "We can't wait to invest in our #infrastructure: Former Repub Mayor & Pres of @reconnecting John Robert Smith on why: http:\/\/t.co\/ARYkXW2J",
  "id" : 132572356991393793,
  "created_at" : "2011-11-04 21:38:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "s",
      "indices" : [ 47, 49 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/v09QRIAV",
      "expanded_url" : "http:\/\/wh.gov\/bNz",
      "display_url" : "wh.gov\/bNz"
    } ]
  },
  "geo" : { },
  "id_str" : "132517920248041472",
  "text" : "RT @jesseclee44: New CEA Chair Krueger on jobs #s: +104K private sector in Oct but need Jobs Act http:\/\/t.co\/v09QRIAV New 3 yr chart: ht ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jesseclee44\/status\/132498559797956609\/photo\/1",
        "indices" : [ 117, 137 ],
        "url" : "http:\/\/t.co\/ytVwakz8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ada6vPaCEAA-oNr.jpg",
        "id_str" : "132498559806345216",
        "id" : 132498559806345216,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ada6vPaCEAA-oNr.jpg",
        "sizes" : [ {
          "h" : 336,
          "resize" : "fit",
          "w" : 430
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 336,
          "resize" : "fit",
          "w" : 430
        }, {
          "h" : 266,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 336,
          "resize" : "fit",
          "w" : 430
        } ],
        "display_url" : "pic.twitter.com\/ytVwakz8"
      } ],
      "hashtags" : [ {
        "text" : "s",
        "indices" : [ 30, 32 ]
      } ],
      "urls" : [ {
        "indices" : [ 80, 100 ],
        "url" : "http:\/\/t.co\/v09QRIAV",
        "expanded_url" : "http:\/\/wh.gov\/bNz",
        "display_url" : "wh.gov\/bNz"
      } ]
    },
    "geo" : { },
    "id_str" : "132498559797956609",
    "text" : "New CEA Chair Krueger on jobs #s: +104K private sector in Oct but need Jobs Act http:\/\/t.co\/v09QRIAV New 3 yr chart: http:\/\/t.co\/ytVwakz8",
    "id" : 132498559797956609,
    "created_at" : "2011-11-04 16:44:53 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 132517920248041472,
  "created_at" : "2011-11-04 18:01:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Carson",
      "screen_name" : "JonCarson44",
      "indices" : [ 3, 15 ],
      "id_str" : "1287388789",
      "id" : 1287388789
    }, {
      "name" : "CourageCampaign",
      "screen_name" : "CourageCampaign",
      "indices" : [ 57, 73 ],
      "id_str" : "16535694",
      "id" : 16535694
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CourageAtWH",
      "indices" : [ 119, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "132506621459959808",
  "text" : "RT @JonCarson44: looking forward to our Twitter Q&A with @CourageCampaign today at 2pm EST.  send us your questions at #CourageAtWH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CourageCampaign",
        "screen_name" : "CourageCampaign",
        "indices" : [ 40, 56 ],
        "id_str" : "16535694",
        "id" : 16535694
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CourageAtWH",
        "indices" : [ 102, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "132459300185575425",
    "text" : "looking forward to our Twitter Q&A with @CourageCampaign today at 2pm EST.  send us your questions at #CourageAtWH",
    "id" : 132459300185575425,
    "created_at" : "2011-11-04 14:08:52 +0000",
    "user" : {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "protected" : false,
      "id_str" : "369232105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623146355767140352\/58sqoVrw_normal.jpg",
      "id" : 369232105,
      "verified" : true
    }
  },
  "id" : 132506621459959808,
  "created_at" : "2011-11-04 17:16:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/132483789447376896\/photo\/1",
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/bpvflsK6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AdatTfjCMAAorVq.jpg",
      "id_str" : "132483789451571200",
      "id" : 132483789451571200,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AdatTfjCMAAorVq.jpg",
      "sizes" : [ {
        "h" : 315,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 315,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 315,
        "resize" : "fit",
        "w" : 560
      } ],
      "display_url" : "pic.twitter.com\/bpvflsK6"
    } ],
    "hashtags" : [ {
      "text" : "jobs",
      "indices" : [ 15, 20 ]
    } ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http:\/\/t.co\/OAkwRsZ1",
      "expanded_url" : "http:\/\/1.usa.gov\/tOOguk",
      "display_url" : "1.usa.gov\/tOOguk"
    } ]
  },
  "geo" : { },
  "id_str" : "132483789447376896",
  "text" : "44 million new #jobs. By the numbers: http:\/\/t.co\/OAkwRsZ1 http:\/\/t.co\/bpvflsK6",
  "id" : 132483789447376896,
  "created_at" : "2011-11-04 15:46:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "G20",
      "indices" : [ 67, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "132462202358743040",
  "text" : "Beginning shortly: President Obama holds a press conference on the #G20 Summit\nin Cannes, France. Watch live: http:\/\/t.co\/u95y7hhB",
  "id" : 132462202358743040,
  "created_at" : "2011-11-04 14:20:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/Jv0vaW2y",
      "expanded_url" : "http:\/\/youtu.be\/SZeb7YU5MaI",
      "display_url" : "youtu.be\/SZeb7YU5MaI"
    } ]
  },
  "geo" : { },
  "id_str" : "132449451376779264",
  "text" : "Fresh West Wing Week: Obama urges Congress to pass the Jobs Act & takes executive action to put folks back to work: http:\/\/t.co\/Jv0vaW2y",
  "id" : 132449451376779264,
  "created_at" : "2011-11-04 13:29:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 3, 11 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    }, {
      "name" : "We the People",
      "screen_name" : "wethepeople",
      "indices" : [ 29, 41 ],
      "id_str" : "369507958",
      "id" : 369507958
    }, {
      "name" : "WH.gov",
      "screen_name" : "WHWeb",
      "indices" : [ 88, 94 ],
      "id_str" : "390320946",
      "id" : 390320946
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/PZvwcOdG",
      "expanded_url" : "http:\/\/1.usa.gov\/skqHA5",
      "display_url" : "1.usa.gov\/skqHA5"
    } ]
  },
  "geo" : { },
  "id_str" : "132251996047687680",
  "text" : "RT @macon44: More updates re @WeThePeople - now averaging 20k users\/day - & introducing @WHWeb http:\/\/t.co\/PZvwcOdG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "We the People",
        "screen_name" : "wethepeople",
        "indices" : [ 16, 28 ],
        "id_str" : "369507958",
        "id" : 369507958
      }, {
        "name" : "WH.gov",
        "screen_name" : "WHWeb",
        "indices" : [ 75, 81 ],
        "id_str" : "390320946",
        "id" : 390320946
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 102 ],
        "url" : "http:\/\/t.co\/PZvwcOdG",
        "expanded_url" : "http:\/\/1.usa.gov\/skqHA5",
        "display_url" : "1.usa.gov\/skqHA5"
      } ]
    },
    "geo" : { },
    "id_str" : "132234944763277312",
    "text" : "More updates re @WeThePeople - now averaging 20k users\/day - & introducing @WHWeb http:\/\/t.co\/PZvwcOdG",
    "id" : 132234944763277312,
    "created_at" : "2011-11-03 23:17:22 +0000",
    "user" : {
      "name" : "Macon Phillips",
      "screen_name" : "IIPCoordinator",
      "protected" : false,
      "id_str" : "110823581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000495374915\/f6a5ae048ab7f8f12c0386114df53203_normal.jpeg",
      "id" : 110823581,
      "verified" : true
    }
  },
  "id" : 132251996047687680,
  "created_at" : "2011-11-04 00:25:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kori Schulman",
      "screen_name" : "ks44",
      "indices" : [ 3, 8 ],
      "id_str" : "369246180",
      "id" : 369246180
    }, {
      "name" : "Aaron Kinnari",
      "screen_name" : "aaronkinnari",
      "indices" : [ 10, 23 ],
      "id_str" : "47839461",
      "id" : 47839461
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "132245258305159169",
  "text" : "RT @ks44: @aaronkinnari great idea -- what Admin official(s) would you like to answer Qs?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Aaron Kinnari",
        "screen_name" : "aaronkinnari",
        "indices" : [ 0, 13 ],
        "id_str" : "47839461",
        "id" : 47839461
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "132219204379213824",
    "geo" : { },
    "id_str" : "132226096463757312",
    "in_reply_to_user_id" : 47839461,
    "text" : "@aaronkinnari great idea -- what Admin official(s) would you like to answer Qs?",
    "id" : 132226096463757312,
    "in_reply_to_status_id" : 132219204379213824,
    "created_at" : "2011-11-03 22:42:12 +0000",
    "in_reply_to_screen_name" : "aaronkinnari",
    "in_reply_to_user_id_str" : "47839461",
    "user" : {
      "name" : "Kori Schulman",
      "screen_name" : "ks44",
      "protected" : false,
      "id_str" : "369246180",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/667876153793859584\/DV7HzP-1_normal.jpg",
      "id" : 369246180,
      "verified" : true
    }
  },
  "id" : 132245258305159169,
  "created_at" : "2011-11-03 23:58:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Kinnari",
      "screen_name" : "aaronkinnari",
      "indices" : [ 3, 16 ],
      "id_str" : "47839461",
      "id" : 47839461
    }, {
      "name" : "Kori Schulman",
      "screen_name" : "ks44",
      "indices" : [ 22, 27 ],
      "id_str" : "369246180",
      "id" : 369246180
    }, {
      "name" : "Startup America",
      "screen_name" : "StartupAmerica",
      "indices" : [ 123, 138 ],
      "id_str" : "211921304",
      "id" : 211921304
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "entrepreneurship",
      "indices" : [ 42, 59 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 79, 86 ]
    }, {
      "text" : "startups",
      "indices" : [ 98, 107 ]
    }, {
      "text" : "jobsnow",
      "indices" : [ 110, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "132245234183700481",
  "text" : "RT @aaronkinnari: Hey @ks44 - November is #entrepreneurship month. How about a #WHChat focused on #startups & #jobsnow? CC @startupamerica",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kori Schulman",
        "screen_name" : "ks44",
        "indices" : [ 4, 9 ],
        "id_str" : "369246180",
        "id" : 369246180
      }, {
        "name" : "Startup America",
        "screen_name" : "StartupAmerica",
        "indices" : [ 105, 120 ],
        "id_str" : "211921304",
        "id" : 211921304
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "entrepreneurship",
        "indices" : [ 24, 41 ]
      }, {
        "text" : "WHChat",
        "indices" : [ 61, 68 ]
      }, {
        "text" : "startups",
        "indices" : [ 80, 89 ]
      }, {
        "text" : "jobsnow",
        "indices" : [ 92, 100 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "132215628873469952",
    "geo" : { },
    "id_str" : "132219204379213824",
    "in_reply_to_user_id" : 369246180,
    "text" : "Hey @ks44 - November is #entrepreneurship month. How about a #WHChat focused on #startups & #jobsnow? CC @startupamerica",
    "id" : 132219204379213824,
    "in_reply_to_status_id" : 132215628873469952,
    "created_at" : "2011-11-03 22:14:49 +0000",
    "in_reply_to_screen_name" : "ks44",
    "in_reply_to_user_id_str" : "369246180",
    "user" : {
      "name" : "Aaron Kinnari",
      "screen_name" : "aaronkinnari",
      "protected" : false,
      "id_str" : "47839461",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/781502435965669376\/qZVnznWB_normal.jpg",
      "id" : 47839461,
      "verified" : false
    }
  },
  "id" : 132245234183700481,
  "created_at" : "2011-11-03 23:58:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "consumerfinance.gov",
      "screen_name" : "CFPB",
      "indices" : [ 115, 120 ],
      "id_str" : "234826866",
      "id" : 234826866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/Kr8vqX2q",
      "expanded_url" : "http:\/\/ow.ly\/7itIw",
      "display_url" : "ow.ly\/7itIw"
    } ]
  },
  "geo" : { },
  "id_str" : "132242271390277632",
  "text" : "VP just emailed: \"Holly Petraeus gets it\" http:\/\/t.co\/Kr8vqX2q Find out why she was testifying @ Congress today re @CFPB",
  "id" : 132242271390277632,
  "created_at" : "2011-11-03 23:46:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "132195498537926656",
  "text" : "RT @PressSec: Today a Senate majority voted to put Americans to work building our roads, bridges & schools. But R's all voted no, & bloc ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "132183113597059072",
    "text" : "Today a Senate majority voted to put Americans to work building our roads, bridges & schools. But R's all voted no, & blocked the bill.",
    "id" : 132183113597059072,
    "created_at" : "2011-11-03 19:51:24 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 132195498537926656,
  "created_at" : "2011-11-03 20:40:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "indices" : [ 3, 12 ],
      "id_str" : "337742544",
      "id" : 337742544
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SAP44",
      "indices" : [ 14, 20 ]
    }, {
      "text" : "AJA",
      "indices" : [ 62, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "132178033065992192",
  "text" : "RT @OMBPress: #SAP44: Admin strongly supports S 1769; part of #AJA, puts construction workers back on the job, modernizes infra. http:\/\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SAP44",
        "indices" : [ 0, 6 ]
      }, {
        "text" : "AJA",
        "indices" : [ 48, 52 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 135 ],
        "url" : "http:\/\/t.co\/ZXnPC46Y",
        "expanded_url" : "http:\/\/1.usa.gov\/soRjkG",
        "display_url" : "1.usa.gov\/soRjkG"
      } ]
    },
    "geo" : { },
    "id_str" : "132162711508361217",
    "text" : "#SAP44: Admin strongly supports S 1769; part of #AJA, puts construction workers back on the job, modernizes infra. http:\/\/t.co\/ZXnPC46Y",
    "id" : 132162711508361217,
    "created_at" : "2011-11-03 18:30:20 +0000",
    "user" : {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "protected" : false,
      "id_str" : "337742544",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1449289379\/OMB_Seal_normal.jpg",
      "id" : 337742544,
      "verified" : true
    }
  },
  "id" : 132178033065992192,
  "created_at" : "2011-11-03 19:31:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/132144345515180033\/photo\/1",
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/m2h6GtKr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AdV4lQYCQAAzLg4.jpg",
      "id_str" : "132144345523568640",
      "id" : 132144345523568640,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AdV4lQYCQAAzLg4.jpg",
      "sizes" : [ {
        "h" : 988,
        "resize" : "fit",
        "w" : 1757
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/m2h6GtKr"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/4zAJk8Q9",
      "expanded_url" : "http:\/\/1.usa.gov\/t30kTz",
      "display_url" : "1.usa.gov\/t30kTz"
    } ]
  },
  "geo" : { },
  "id_str" : "132144345515180033",
  "text" : "5 facts about a national infrastructure bank: http:\/\/t.co\/4zAJk8Q9 Pic: President Obama @ Key Bridge: http:\/\/t.co\/m2h6GtKr",
  "id" : 132144345515180033,
  "created_at" : "2011-11-03 17:17:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USAID",
      "screen_name" : "USAID",
      "indices" : [ 3, 9 ],
      "id_str" : "36683668",
      "id" : 36683668
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "USAID50",
      "indices" : [ 112, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "132122153884725248",
  "text" : "RT @USAID: Thank you all the birthday wishes.  We are very honored for all the support and to work with you all #USAID50",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ubersocial.com\" rel=\"nofollow\"\u003EUberSocial for BlackBerry\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "USAID50",
        "indices" : [ 101, 109 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "132119800922116098",
    "text" : "Thank you all the birthday wishes.  We are very honored for all the support and to work with you all #USAID50",
    "id" : 132119800922116098,
    "created_at" : "2011-11-03 15:39:49 +0000",
    "user" : {
      "name" : "USAID",
      "screen_name" : "USAID",
      "protected" : false,
      "id_str" : "36683668",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/717410574523564032\/ExeUofTG_normal.jpg",
      "id" : 36683668,
      "verified" : true
    }
  },
  "id" : 132122153884725248,
  "created_at" : "2011-11-03 15:49:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "USAID",
      "screen_name" : "USAID",
      "indices" : [ 23, 29 ],
      "id_str" : "36683668",
      "id" : 36683668
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "USAID50",
      "indices" : [ 87, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/G4d208fP",
      "expanded_url" : "http:\/\/50.usaid.gov\/events\/november3rd\/",
      "display_url" : "50.usaid.gov\/events\/novembe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "132113052362489856",
  "text" : "RT @VP: VP speaking at @USAID 50th anniversary event; WATCH LIVE http:\/\/t.co\/G4d208fP  #USAID50",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "USAID",
        "screen_name" : "USAID",
        "indices" : [ 15, 21 ],
        "id_str" : "36683668",
        "id" : 36683668
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "USAID50",
        "indices" : [ 79, 87 ]
      } ],
      "urls" : [ {
        "indices" : [ 57, 77 ],
        "url" : "http:\/\/t.co\/G4d208fP",
        "expanded_url" : "http:\/\/50.usaid.gov\/events\/november3rd\/",
        "display_url" : "50.usaid.gov\/events\/novembe\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "132112426618458113",
    "text" : "VP speaking at @USAID 50th anniversary event; WATCH LIVE http:\/\/t.co\/G4d208fP  #USAID50",
    "id" : 132112426618458113,
    "created_at" : "2011-11-03 15:10:31 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 132113052362489856,
  "created_at" : "2011-11-03 15:13:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/KD83ghDU",
      "expanded_url" : "http:\/\/whitehouse.gov\/jobsact",
      "display_url" : "whitehouse.gov\/jobsact"
    } ]
  },
  "geo" : { },
  "id_str" : "132098173563961344",
  "text" : "Obama: The most urgent challenge that we face right now is getting our economy to grow faster & to create more jobs: http:\/\/t.co\/KD83ghDU",
  "id" : 132098173563961344,
  "created_at" : "2011-11-03 14:13:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Carson",
      "screen_name" : "JonCarson44",
      "indices" : [ 3, 15 ],
      "id_str" : "1287388789",
      "id" : 1287388789
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "132095947063832577",
  "text" : "RT @JonCarson44: we are honoring Champions of Change for Make it in America here at the WH today. Here's one of our Champions.. http:\/\/t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 131 ],
        "url" : "http:\/\/t.co\/gQk8KIsz",
        "expanded_url" : "http:\/\/www.baltimoresun.com\/explore\/baltimorecounty\/news\/ph-ms-manekin-1103-20111101,0,6732820.story",
        "display_url" : "baltimoresun.com\/explore\/baltim\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "132093518427586561",
    "text" : "we are honoring Champions of Change for Make it in America here at the WH today. Here's one of our Champions.. http:\/\/t.co\/gQk8KIsz",
    "id" : 132093518427586561,
    "created_at" : "2011-11-03 13:55:23 +0000",
    "user" : {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "protected" : false,
      "id_str" : "369232105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623146355767140352\/58sqoVrw_normal.jpg",
      "id" : 369232105,
      "verified" : true
    }
  },
  "id" : 132095947063832577,
  "created_at" : "2011-11-03 14:05:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ray LaHood",
      "screen_name" : "RayLaHood",
      "indices" : [ 3, 13 ],
      "id_str" : "1563604279",
      "id" : 1563604279
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Reagan",
      "indices" : [ 20, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "131837374303977472",
  "text" : "RT @RayLaHood: Pres #Reagan: the bridges we fail to repair today will have to be rebuilt tomorrow at many times the cost http:\/\/t.co\/IF8 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Reagan",
        "indices" : [ 5, 12 ]
      } ],
      "urls" : [ {
        "indices" : [ 106, 126 ],
        "url" : "http:\/\/t.co\/IF8PGmGA",
        "expanded_url" : "http:\/\/bit.ly\/uONX1o",
        "display_url" : "bit.ly\/uONX1o"
      } ]
    },
    "geo" : { },
    "id_str" : "131810771909885952",
    "text" : "Pres #Reagan: the bridges we fail to repair today will have to be rebuilt tomorrow at many times the cost http:\/\/t.co\/IF8PGmGA",
    "id" : 131810771909885952,
    "created_at" : "2011-11-02 19:11:51 +0000",
    "user" : {
      "name" : "Anthony Foxx",
      "screen_name" : "SecretaryFoxx",
      "protected" : false,
      "id_str" : "43920155",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746015409707622400\/clFVYNWs_normal.jpg",
      "id" : 43920155,
      "verified" : true
    }
  },
  "id" : 131837374303977472,
  "created_at" : "2011-11-02 20:57:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 1, 12 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "mtvU",
      "screen_name" : "mtvU",
      "indices" : [ 15, 20 ],
      "id_str" : "18333645",
      "id" : 18333645
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ChampsOfChange",
      "indices" : [ 41, 56 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/ZzFEPRDx",
      "expanded_url" : "http:\/\/1.usa.gov\/vabkrB",
      "display_url" : "1.usa.gov\/vabkrB"
    } ]
  },
  "geo" : { },
  "id_str" : "131813101954809857",
  "text" : ".@whitehouse & @mtvU announce the Campus #ChampsOfChange Challenge. Tell us how you're making an impact: http:\/\/t.co\/ZzFEPRDx",
  "id" : 131813101954809857,
  "created_at" : "2011-11-02 19:21:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MTV Issues",
      "screen_name" : "MTVAct",
      "indices" : [ 3, 10 ],
      "id_str" : "3028398526",
      "id" : 3028398526
    }, {
      "name" : "mtvU",
      "screen_name" : "mtvU",
      "indices" : [ 77, 82 ],
      "id_str" : "18333645",
      "id" : 18333645
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 85, 96 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/EcgaoHOu",
      "expanded_url" : "http:\/\/on.mtv.com\/vyGFeY",
      "display_url" : "on.mtv.com\/vyGFeY"
    } ]
  },
  "geo" : { },
  "id_str" : "131811032007061506",
  "text" : "RT @MTVact: Got an amazing, innovative project that's impacting your campus? @mtvU & @whitehouse want you! http:\/\/t.co\/EcgaoHOu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "mtvU",
        "screen_name" : "mtvU",
        "indices" : [ 65, 70 ],
        "id_str" : "18333645",
        "id" : 18333645
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 73, 84 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 115 ],
        "url" : "http:\/\/t.co\/EcgaoHOu",
        "expanded_url" : "http:\/\/on.mtv.com\/vyGFeY",
        "display_url" : "on.mtv.com\/vyGFeY"
      } ]
    },
    "geo" : { },
    "id_str" : "131801901145657344",
    "text" : "Got an amazing, innovative project that's impacting your campus? @mtvU & @whitehouse want you! http:\/\/t.co\/EcgaoHOu",
    "id" : 131801901145657344,
    "created_at" : "2011-11-02 18:36:36 +0000",
    "user" : {
      "name" : "MTV Politics",
      "screen_name" : "MTVPolitics",
      "protected" : false,
      "id_str" : "208697224",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/712634534743973890\/rv61pNvM_normal.jpg",
      "id" : 208697224,
      "verified" : true
    }
  },
  "id" : 131811032007061506,
  "created_at" : "2011-11-02 19:12:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "131809358324563968",
  "text" : "RT @pfeiffer44: The GOP was voting to repeal environmental regs instead of creating jobs, now they are focused on regs that don't exist  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/eoVjU4eo",
        "expanded_url" : "http:\/\/wapo.st\/vN2cbs",
        "display_url" : "wapo.st\/vN2cbs"
      } ]
    },
    "geo" : { },
    "id_str" : "131805313425866752",
    "text" : "The GOP was voting to repeal environmental regs instead of creating jobs, now they are focused on regs that don't exist http:\/\/t.co\/eoVjU4eo",
    "id" : 131805313425866752,
    "created_at" : "2011-11-02 18:50:10 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 131809358324563968,
  "created_at" : "2011-11-02 19:06:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Gregoire",
      "screen_name" : "GovGregoire",
      "indices" : [ 3, 15 ],
      "id_str" : "39348261",
      "id" : 39348261
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "131809158864441344",
  "text" : "RT @GovGregoire: We can\u2019t wait to invest in roads, highways, transit and bridges \u2013 it\u2019s necessary to support our economy and will create ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "passthebill",
        "indices" : [ 126, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "131798856366178304",
    "text" : "We can\u2019t wait to invest in roads, highways, transit and bridges \u2013 it\u2019s necessary to support our economy and will create jobs. #passthebill",
    "id" : 131798856366178304,
    "created_at" : "2011-11-02 18:24:30 +0000",
    "user" : {
      "name" : "Chris Gregoire",
      "screen_name" : "GovGregoire",
      "protected" : false,
      "id_str" : "39348261",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2409653703\/9zgjc23lt65mywp0bg96_normal.jpeg",
      "id" : 39348261,
      "verified" : false
    }
  },
  "id" : 131809158864441344,
  "created_at" : "2011-11-02 19:05:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jobs",
      "indices" : [ 8, 13 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/Q2CIJIc2",
      "expanded_url" : "http:\/\/wh.gov\/bDQ",
      "display_url" : "wh.gov\/bDQ"
    } ]
  },
  "geo" : { },
  "id_str" : "131762162476646400",
  "text" : "Is it a #jobs plan? See President Obama's plan & the Republican alternative side by side: http:\/\/t.co\/Q2CIJIc2",
  "id" : 131762162476646400,
  "created_at" : "2011-11-02 15:58:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Hickenlooper",
      "screen_name" : "hickforco",
      "indices" : [ 3, 13 ],
      "id_str" : "117839957",
      "id" : 117839957
    }, {
      "name" : "FOX31 Denver KDVR",
      "screen_name" : "KDVR",
      "indices" : [ 18, 23 ],
      "id_str" : "18777618",
      "id" : 18777618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "131759535294656512",
  "text" : "RT @hickforco: On @KDVR this a.m.: Congress must compromise on Obama\u2019s jobs act. Investments in infrastructure will lift the economy. #j ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "FOX31 Denver KDVR",
        "screen_name" : "KDVR",
        "indices" : [ 3, 8 ],
        "id_str" : "18777618",
        "id" : 18777618
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "jobsnow",
        "indices" : [ 119, 127 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "131740509508079617",
    "text" : "On @KDVR this a.m.: Congress must compromise on Obama\u2019s jobs act. Investments in infrastructure will lift the economy. #jobsnow",
    "id" : 131740509508079617,
    "created_at" : "2011-11-02 14:32:39 +0000",
    "user" : {
      "name" : "John Hickenlooper",
      "screen_name" : "hickforco",
      "protected" : false,
      "id_str" : "117839957",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/715213549950386176\/gWaNxlRA_normal.jpg",
      "id" : 117839957,
      "verified" : true
    }
  },
  "id" : 131759535294656512,
  "created_at" : "2011-11-02 15:48:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/jesseclee44\/status\/131721170012733440\/photo\/1",
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/HgTh9AKO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AdP3tMyCAAEcnD3.jpg",
      "id_str" : "131721170021122049",
      "id" : 131721170021122049,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AdP3tMyCAAEcnD3.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 325
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 555
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 555
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 184
      } ],
      "display_url" : "pic.twitter.com\/HgTh9AKO"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/lkncg21y",
      "expanded_url" : "http:\/\/wh.gov\/bDQ",
      "display_url" : "wh.gov\/bDQ"
    } ]
  },
  "geo" : { },
  "id_str" : "131731515674595328",
  "text" : "RT @jesseclee44: Infographic: What a Jobs Plan Looks Like - Obama & GOP side by side: http:\/\/t.co\/lkncg21y Twit-size: http:\/\/t.co\/HgTh9AKO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jesseclee44\/status\/131721170012733440\/photo\/1",
        "indices" : [ 101, 121 ],
        "url" : "http:\/\/t.co\/HgTh9AKO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AdP3tMyCAAEcnD3.jpg",
        "id_str" : "131721170021122049",
        "id" : 131721170021122049,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AdP3tMyCAAEcnD3.jpg",
        "sizes" : [ {
          "h" : 1200,
          "resize" : "fit",
          "w" : 325
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 555
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 555
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 184
        } ],
        "display_url" : "pic.twitter.com\/HgTh9AKO"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 89 ],
        "url" : "http:\/\/t.co\/lkncg21y",
        "expanded_url" : "http:\/\/wh.gov\/bDQ",
        "display_url" : "wh.gov\/bDQ"
      } ]
    },
    "geo" : { },
    "id_str" : "131721170012733440",
    "text" : "Infographic: What a Jobs Plan Looks Like - Obama & GOP side by side: http:\/\/t.co\/lkncg21y Twit-size: http:\/\/t.co\/HgTh9AKO",
    "id" : 131721170012733440,
    "created_at" : "2011-11-02 13:15:49 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 131731515674595328,
  "created_at" : "2011-11-02 13:56:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "131731483277795330",
  "text" : "RT @pfeiffer44: POTUS will call on Congressional R's to join with D's to vote to put construction workers back to work at DC's Key Bridg ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "131694533196005378",
    "text" : "POTUS will call on Congressional R's to join with D's to vote to put construction workers back to work at DC's Key Bridge today",
    "id" : 131694533196005378,
    "created_at" : "2011-11-02 11:29:58 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 131731483277795330,
  "created_at" : "2011-11-02 13:56:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 3, 11 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    }, {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 13, 24 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    }, {
      "name" : "Scott Forstall",
      "screen_name" : "forstall",
      "indices" : [ 73, 82 ],
      "id_str" : "166369152",
      "id" : 166369152
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iphone",
      "indices" : [ 65, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/JAzdZi3A",
      "expanded_url" : "http:\/\/ow.ly\/7fDhG",
      "display_url" : "ow.ly\/7fDhG"
    } ]
  },
  "geo" : { },
  "id_str" : "131423703669018626",
  "text" : "RT @macon44: @pfeiffer44 don't forget Siri! http:\/\/t.co\/JAzdZi3A #iphone @forstall",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "pu iezov uf",
        "screen_name" : "pfeiffer44",
        "indices" : [ 0, 11 ],
        "id_str" : "3187888216",
        "id" : 3187888216
      }, {
        "name" : "Scott Forstall",
        "screen_name" : "forstall",
        "indices" : [ 60, 69 ],
        "id_str" : "166369152",
        "id" : 166369152
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "iphone",
        "indices" : [ 52, 59 ]
      } ],
      "urls" : [ {
        "indices" : [ 31, 51 ],
        "url" : "http:\/\/t.co\/JAzdZi3A",
        "expanded_url" : "http:\/\/ow.ly\/7fDhG",
        "display_url" : "ow.ly\/7fDhG"
      } ]
    },
    "in_reply_to_status_id_str" : "131413182752362496",
    "geo" : { },
    "id_str" : "131419589371375616",
    "in_reply_to_user_id" : 131144091,
    "text" : "@pfeiffer44 don't forget Siri! http:\/\/t.co\/JAzdZi3A #iphone @forstall",
    "id" : 131419589371375616,
    "in_reply_to_status_id" : 131413182752362496,
    "created_at" : "2011-11-01 17:17:26 +0000",
    "in_reply_to_screen_name" : "Goldman44",
    "in_reply_to_user_id_str" : "131144091",
    "user" : {
      "name" : "Macon Phillips",
      "screen_name" : "IIPCoordinator",
      "protected" : false,
      "id_str" : "110823581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000495374915\/f6a5ae048ab7f8f12c0386114df53203_normal.jpeg",
      "id" : 110823581,
      "verified" : true
    }
  },
  "id" : 131423703669018626,
  "created_at" : "2011-11-01 17:33:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "131423688460480513",
  "text" : "RT @pfeiffer44: CNN has a great article abt the benefits of govt investing in new technologies. Led to invention of Internet, GPS, Wii h ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/Y5icNoyl",
        "expanded_url" : "http:\/\/cnnmon.ie\/osZIsu",
        "display_url" : "cnnmon.ie\/osZIsu"
      } ]
    },
    "geo" : { },
    "id_str" : "131413182752362496",
    "text" : "CNN has a great article abt the benefits of govt investing in new technologies. Led to invention of Internet, GPS, Wii http:\/\/t.co\/Y5icNoyl",
    "id" : 131413182752362496,
    "created_at" : "2011-11-01 16:51:58 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 131423688460480513,
  "created_at" : "2011-11-01 17:33:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Ferguson",
      "screen_name" : "Astro_Ferg",
      "indices" : [ 3, 14 ],
      "id_str" : "274151347",
      "id" : 274151347
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "131418200163352576",
  "text" : "RT @Astro_Ferg: Just before meeting with President Obama today. Great opportunity to share experiences with the chief executive. http:\/\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Astro_Ferg\/status\/131412867600756736\/photo\/1",
        "indices" : [ 113, 133 ],
        "url" : "http:\/\/t.co\/zrZl6MSg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AdLfToyCMAAqbir.jpg",
        "id_str" : "131412867604951040",
        "id" : 131412867604951040,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AdLfToyCMAAqbir.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/zrZl6MSg"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 38.8996138, -77.0394273663 ]
    },
    "id_str" : "131412867600756736",
    "text" : "Just before meeting with President Obama today. Great opportunity to share experiences with the chief executive. http:\/\/t.co\/zrZl6MSg",
    "id" : 131412867600756736,
    "created_at" : "2011-11-01 16:50:44 +0000",
    "user" : {
      "name" : "Christopher Ferguson",
      "screen_name" : "Astro_Ferg",
      "protected" : false,
      "id_str" : "274151347",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1291867805\/jsc2003e55802_cropped_normal.jpg",
      "id" : 274151347,
      "verified" : true
    }
  },
  "id" : 131418200163352576,
  "created_at" : "2011-11-01 17:11:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/i1jcUrdA",
      "expanded_url" : "http:\/\/ow.ly\/7fxvD",
      "display_url" : "ow.ly\/7fxvD"
    } ]
  },
  "geo" : { },
  "id_str" : "131405043600605184",
  "text" : "Obama signed executive order to reduce drug shortages & protect consumers. Video: Why cancer patients can't wait: http:\/\/t.co\/i1jcUrdA",
  "id" : 131405043600605184,
  "created_at" : "2011-11-01 16:19:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MotherNatureNetwork",
      "screen_name" : "MotherNatureNet",
      "indices" : [ 21, 37 ],
      "id_str" : "16550480",
      "id" : 16550480
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 40, 51 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "greengov2011",
      "indices" : [ 52, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/iyR7kc6x",
      "expanded_url" : "http:\/\/mnn.com\/live",
      "display_url" : "mnn.com\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "131396913567244289",
  "text" : "Happening @ 12:15ET: @MotherNatureNet & @WhiteHouse #greengov2011 panel on green energy, clean tech & more. Watch live: http:\/\/t.co\/iyR7kc6x",
  "id" : 131396913567244289,
  "created_at" : "2011-11-01 15:47:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
} ]