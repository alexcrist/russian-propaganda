Grailbird.data.tweets_2015_04 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeSigningDay",
      "indices" : [ 111, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "593904867208474625",
  "text" : "RT @FLOTUS: Did you go to a university, a community college, or a technical school? Wear your shirt Friday for #CollegeSigningDay http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/FLOTUS\/status\/593903630446559232\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/6Hacpe6ftQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CD34HtHW8AAMYHM.jpg",
        "id_str" : "593903537136005120",
        "id" : 593903537136005120,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CD34HtHW8AAMYHM.jpg",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 733,
          "resize" : "fit",
          "w" : 1100
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/6Hacpe6ftQ"
      } ],
      "hashtags" : [ {
        "text" : "CollegeSigningDay",
        "indices" : [ 99, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "593903630446559232",
    "text" : "Did you go to a university, a community college, or a technical school? Wear your shirt Friday for #CollegeSigningDay http:\/\/t.co\/6Hacpe6ftQ",
    "id" : 593903630446559232,
    "created_at" : "2015-04-30 22:23:54 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 593904867208474625,
  "created_at" : "2015-04-30 22:28:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USAID",
      "screen_name" : "USAID",
      "indices" : [ 71, 77 ],
      "id_str" : "36683668",
      "id" : 36683668
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/593882587661107201\/photo\/1",
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/grYtVXlemg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CD3gW6cWoAATgH_.jpg",
      "id_str" : "593877410132697088",
      "id" : 593877410132697088,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CD3gW6cWoAATgH_.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/grYtVXlemg"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/KHE9mjibLa",
      "expanded_url" : "http:\/\/go.wh.gov\/RhZhAZ",
      "display_url" : "go.wh.gov\/RhZhAZ"
    } ]
  },
  "geo" : { },
  "id_str" : "593882587661107201",
  "text" : "President Obama is nominating Gayle Smith as the next Administrator of @USAID \u2192 http:\/\/t.co\/KHE9mjibLa http:\/\/t.co\/grYtVXlemg",
  "id" : 593882587661107201,
  "created_at" : "2015-04-30 21:00:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/593875822685102080\/photo\/1",
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/K02HRbNvwU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CD3epEzWMAQj7w1.png",
      "id_str" : "593875523127881732",
      "id" : 593875523127881732,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CD3epEzWMAQj7w1.png",
      "sizes" : [ {
        "h" : 325,
        "resize" : "fit",
        "w" : 583
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 190,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 325,
        "resize" : "fit",
        "w" : 583
      }, {
        "h" : 325,
        "resize" : "fit",
        "w" : 583
      } ],
      "display_url" : "pic.twitter.com\/K02HRbNvwU"
    } ],
    "hashtags" : [ {
      "text" : "ThankATeacher",
      "indices" : [ 88, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/FmL4CumWgv",
      "expanded_url" : "http:\/\/tak.pt\/i\/CUzCVaRC",
      "display_url" : "tak.pt\/i\/CUzCVaRC"
    } ]
  },
  "geo" : { },
  "id_str" : "593875822685102080",
  "text" : "\"Let me tell you a little bit about that teacher, Barack Obama.\" http:\/\/t.co\/FmL4CumWgv #ThankATeacher http:\/\/t.co\/K02HRbNvwU",
  "id" : 593875822685102080,
  "created_at" : "2015-04-30 20:33:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "indices" : [ 3, 13 ],
      "id_str" : "1613223313",
      "id" : 1613223313
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 45, 56 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "593871155397660672",
  "text" : "RT @Cecilia44: Where do you hang out online? @WhiteHouse Conference on Aging is coming up &amp; now my mother-in-law has an ipad! Let us know w\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 30, 41 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "seniorsonline",
        "indices" : [ 130, 144 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "593849478144077825",
    "text" : "Where do you hang out online? @WhiteHouse Conference on Aging is coming up &amp; now my mother-in-law has an ipad! Let us know w\/ #seniorsonline",
    "id" : 593849478144077825,
    "created_at" : "2015-04-30 18:48:43 +0000",
    "user" : {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "protected" : false,
      "id_str" : "1613223313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000172019215\/ed65eda76f51213f91b33edbaa62054c_normal.jpeg",
      "id" : 1613223313,
      "verified" : true
    }
  },
  "id" : 593871155397660672,
  "created_at" : "2015-04-30 20:14:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BooksForAll",
      "indices" : [ 104, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/EX3vTuxmwm",
      "expanded_url" : "http:\/\/snpy.tv\/1zuX83c",
      "display_url" : "snpy.tv\/1zuX83c"
    } ]
  },
  "geo" : { },
  "id_str" : "593859337573036032",
  "text" : "\"I want boys and girls studying all the subjects and getting good at all the subjects\" \u2014President Obama #BooksForAll http:\/\/t.co\/EX3vTuxmwm",
  "id" : 593859337573036032,
  "created_at" : "2015-04-30 19:27:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/593828512399691776\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/UhqBIXUG1O",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CD2zaAHWIAAjbdp.jpg",
      "id_str" : "593827985171554304",
      "id" : 593827985171554304,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CD2zaAHWIAAjbdp.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/UhqBIXUG1O"
    } ],
    "hashtags" : [ {
      "text" : "BooksForAll",
      "indices" : [ 77, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/NtgsA6vfS0",
      "expanded_url" : "http:\/\/go.wh.gov\/BooksForAll",
      "display_url" : "go.wh.gov\/BooksForAll"
    } ]
  },
  "geo" : { },
  "id_str" : "593828512399691776",
  "text" : "President Obama's a Dr. Seuss fan.\nShare what books you read growing up with #BooksForAll: http:\/\/t.co\/NtgsA6vfS0 http:\/\/t.co\/UhqBIXUG1O",
  "id" : 593828512399691776,
  "created_at" : "2015-04-30 17:25:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/VP\/status\/593825717730684929\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/YcfvTfeYIl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CD2xV4QVAAA-SxN.jpg",
      "id_str" : "593825715319013376",
      "id" : 593825715319013376,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CD2xV4QVAAA-SxN.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 2000,
        "resize" : "fit",
        "w" : 3000
      } ],
      "display_url" : "pic.twitter.com\/YcfvTfeYIl"
    } ],
    "hashtags" : [ {
      "text" : "BooksForAll",
      "indices" : [ 105, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "593825889965744128",
  "text" : "RT @VP: Pick up a book. Read it. And then share or donate it. Every kid deserves a lifetime of learning. #BooksForAll http:\/\/t.co\/YcfvTfeYIl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/593825717730684929\/photo\/1",
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/YcfvTfeYIl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CD2xV4QVAAA-SxN.jpg",
        "id_str" : "593825715319013376",
        "id" : 593825715319013376,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CD2xV4QVAAA-SxN.jpg",
        "sizes" : [ {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 2000,
          "resize" : "fit",
          "w" : 3000
        } ],
        "display_url" : "pic.twitter.com\/YcfvTfeYIl"
      } ],
      "hashtags" : [ {
        "text" : "BooksForAll",
        "indices" : [ 97, 109 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "593825717730684929",
    "text" : "Pick up a book. Read it. And then share or donate it. Every kid deserves a lifetime of learning. #BooksForAll http:\/\/t.co\/YcfvTfeYIl",
    "id" : 593825717730684929,
    "created_at" : "2015-04-30 17:14:18 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 593825889965744128,
  "created_at" : "2015-04-30 17:14:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BooksForAll",
      "indices" : [ 105, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/DJ0LKczRH5",
      "expanded_url" : "http:\/\/snpy.tv\/1Gz8VdK",
      "display_url" : "snpy.tv\/1Gz8VdK"
    } ]
  },
  "geo" : { },
  "id_str" : "593813498452250624",
  "text" : "\"I'm still a big Dr. Seuss fan. You know...the Sneetches and Horton and all that stuff\" \u2014President Obama #BooksForAll http:\/\/t.co\/DJ0LKczRH5",
  "id" : 593813498452250624,
  "created_at" : "2015-04-30 16:25:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BooksForAll",
      "indices" : [ 103, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/w5dkLn3dN2",
      "expanded_url" : "http:\/\/snpy.tv\/1AlBfON",
      "display_url" : "snpy.tv\/1AlBfON"
    } ]
  },
  "geo" : { },
  "id_str" : "593807429751558145",
  "text" : "Young student: \u201CWhat kind of technology did you have when you were in school?\u201D\nObama: \u201CWe had pencils\u201D\n#BooksForAll http:\/\/t.co\/w5dkLn3dN2",
  "id" : 593807429751558145,
  "created_at" : "2015-04-30 16:01:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/593804666934140929\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/rtwPbJedoj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CD2dz6TWoAAh9Qn.png",
      "id_str" : "593804241032093696",
      "id" : 593804241032093696,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CD2dz6TWoAAh9Qn.png",
      "sizes" : [ {
        "h" : 530,
        "resize" : "fit",
        "w" : 946
      }, {
        "h" : 530,
        "resize" : "fit",
        "w" : 946
      }, {
        "h" : 190,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 336,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/rtwPbJedoj"
    } ],
    "hashtags" : [ {
      "text" : "STEM",
      "indices" : [ 94, 99 ]
    }, {
      "text" : "BooksForAll",
      "indices" : [ 100, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/NtgsA6vfS0",
      "expanded_url" : "http:\/\/go.wh.gov\/BooksForAll",
      "display_url" : "go.wh.gov\/BooksForAll"
    } ]
  },
  "geo" : { },
  "id_str" : "593804666934140929",
  "text" : "\u201CWhen I was your age, I was actually best at math and science\" \u2014Obama: http:\/\/t.co\/NtgsA6vfS0 #STEM #BooksForAll http:\/\/t.co\/rtwPbJedoj",
  "id" : 593804666934140929,
  "created_at" : "2015-04-30 15:50:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BooksForAll",
      "indices" : [ 96, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/sOgAoVTugu",
      "expanded_url" : "http:\/\/snpy.tv\/1I0SAV3",
      "display_url" : "snpy.tv\/1I0SAV3"
    } ]
  },
  "geo" : { },
  "id_str" : "593800680063787008",
  "text" : "RT if you're excited about President Obama's new commitment to expand access to books for kids. #BooksForAll http:\/\/t.co\/sOgAoVTugu",
  "id" : 593800680063787008,
  "created_at" : "2015-04-30 15:34:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/593800003069575169\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/nqzOjdpaKr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CD2Z675WoAAG8KR.png",
      "id_str" : "593799963672485888",
      "id" : 593799963672485888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CD2Z675WoAAG8KR.png",
      "sizes" : [ {
        "h" : 528,
        "resize" : "fit",
        "w" : 944
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 190,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 528,
        "resize" : "fit",
        "w" : 944
      }, {
        "h" : 336,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/nqzOjdpaKr"
    } ],
    "hashtags" : [ {
      "text" : "BooksForAll",
      "indices" : [ 102, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/NtgsA6dF0s",
      "expanded_url" : "http:\/\/go.wh.gov\/BooksForAll",
      "display_url" : "go.wh.gov\/BooksForAll"
    } ]
  },
  "geo" : { },
  "id_str" : "593800003069575169",
  "text" : "\u201CThe most powerful engine for learning is between your ears\u201D \u2014President Obama: http:\/\/t.co\/NtgsA6dF0s #BooksForAll http:\/\/t.co\/nqzOjdpaKr",
  "id" : 593800003069575169,
  "created_at" : "2015-04-30 15:32:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/DJ0LKcRt5F",
      "expanded_url" : "http:\/\/snpy.tv\/1Gz8VdK",
      "display_url" : "snpy.tv\/1Gz8VdK"
    } ]
  },
  "geo" : { },
  "id_str" : "593799243112001536",
  "text" : "\u201CThe Harry Potter books were pretty cool too. I started reading those to Malia starting when she was around 5\u201D \u2014Obama http:\/\/t.co\/DJ0LKcRt5F",
  "id" : 593799243112001536,
  "created_at" : "2015-04-30 15:29:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/593798396621688832\/photo\/1",
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/WKrZmdqjoJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CD2YPgIW8AE6RjK.png",
      "id_str" : "593798117973225473",
      "id" : 593798117973225473,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CD2YPgIW8AE6RjK.png",
      "sizes" : [ {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 529,
        "resize" : "fit",
        "w" : 942
      }, {
        "h" : 529,
        "resize" : "fit",
        "w" : 942
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/WKrZmdqjoJ"
    } ],
    "hashtags" : [ {
      "text" : "BooksForAll",
      "indices" : [ 108, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/NtgsA6vfS0",
      "expanded_url" : "http:\/\/go.wh.gov\/BooksForAll",
      "display_url" : "go.wh.gov\/BooksForAll"
    } ]
  },
  "geo" : { },
  "id_str" : "593798396621688832",
  "text" : "\u201CLater on I was getting into things like Lord of the Rings &amp; The Hobbit\u201D \u2014Obama: http:\/\/t.co\/NtgsA6vfS0 #BooksForAll http:\/\/t.co\/WKrZmdqjoJ",
  "id" : 593798396621688832,
  "created_at" : "2015-04-30 15:25:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BooksForAll",
      "indices" : [ 120, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "593797902486474752",
  "text" : "\u201CI was a big Dr. Seuss fan, you\u2019ve got Horton...and all that good stuff\u201D \u2014Obama on what he liked to read as a young kid #BooksForAll",
  "id" : 593797902486474752,
  "created_at" : "2015-04-30 15:23:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BooksForAll",
      "indices" : [ 121, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/NtgsA6vfS0",
      "expanded_url" : "http:\/\/go.wh.gov\/BooksForAll",
      "display_url" : "go.wh.gov\/BooksForAll"
    } ]
  },
  "geo" : { },
  "id_str" : "593796929433120769",
  "text" : "\u201CWorking with book publishers, we\u2019re going to provide\u2026eBooks to kids around the country.\u201D \u2014Obama: http:\/\/t.co\/NtgsA6vfS0 #BooksForAll",
  "id" : 593796929433120769,
  "created_at" : "2015-04-30 15:19:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/593796033144041473\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/1BXt3Nw9a7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CD2WTA2WMAAQ73i.png",
      "id_str" : "593795979272400896",
      "id" : 593795979272400896,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CD2WTA2WMAAQ73i.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 190,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 528,
        "resize" : "fit",
        "w" : 945
      }, {
        "h" : 528,
        "resize" : "fit",
        "w" : 945
      }, {
        "h" : 335,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/1BXt3Nw9a7"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "593796033144041473",
  "text" : "\u201CWe need to make sure that in all the schools in America, everybody\u2019s got a great Internet connection.\u201D \u2014Obama http:\/\/t.co\/1BXt3Nw9a7",
  "id" : 593796033144041473,
  "created_at" : "2015-04-30 15:16:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BooksForAll",
      "indices" : [ 120, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/NtgsA6dF0s",
      "expanded_url" : "http:\/\/go.wh.gov\/BooksForAll",
      "display_url" : "go.wh.gov\/BooksForAll"
    } ]
  },
  "geo" : { },
  "id_str" : "593794939596763136",
  "text" : "Watch live: President Obama announces a new commitment to help expand access to books for kids \u2192 http:\/\/t.co\/NtgsA6dF0s #BooksForAll",
  "id" : 593794939596763136,
  "created_at" : "2015-04-30 15:12:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BooksForAll",
      "indices" : [ 117, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/NtgsA6vfS0",
      "expanded_url" : "http:\/\/go.wh.gov\/BooksForAll",
      "display_url" : "go.wh.gov\/BooksForAll"
    } ]
  },
  "geo" : { },
  "id_str" : "593788446231035904",
  "text" : "Watch President Obama's \"Virtual Field Trip\" with students around the country at 10:50am ET \u2192 http:\/\/t.co\/NtgsA6vfS0 #BooksForAll",
  "id" : 593788446231035904,
  "created_at" : "2015-04-30 14:46:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/593781182577266688\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/SHjSncaWFl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CD2INqKWAAE5JGG.jpg",
      "id_str" : "593780494120124417",
      "id" : 593780494120124417,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CD2INqKWAAE5JGG.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/SHjSncaWFl"
    } ],
    "hashtags" : [ {
      "text" : "BooksForAll",
      "indices" : [ 79, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/NtgsA6vfS0",
      "expanded_url" : "http:\/\/go.wh.gov\/BooksForAll",
      "display_url" : "go.wh.gov\/BooksForAll"
    } ]
  },
  "geo" : { },
  "id_str" : "593781182577266688",
  "text" : "Love books? President Obama does.\nShare what book inspired you growing up with #BooksForAll: http:\/\/t.co\/NtgsA6vfS0 http:\/\/t.co\/SHjSncaWFl",
  "id" : 593781182577266688,
  "created_at" : "2015-04-30 14:17:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Discovery Education",
      "screen_name" : "DiscoveryEd",
      "indices" : [ 3, 15 ],
      "id_str" : "1665531",
      "id" : 1665531
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/DiscoveryEd\/status\/593744299927404544\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/Sa5vfNOydQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CD1nS2yWIAAyIoJ.jpg",
      "id_str" : "593744299524759552",
      "id" : 593744299524759552,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CD1nS2yWIAAyIoJ.jpg",
      "sizes" : [ {
        "h" : 375,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/Sa5vfNOydQ"
    } ],
    "hashtags" : [ {
      "text" : "virtualfieldtrip",
      "indices" : [ 59, 76 ]
    }, {
      "text" : "booksforall",
      "indices" : [ 77, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/HlbUuHxgKU",
      "expanded_url" : "http:\/\/dlc.com\/1DTg7jj",
      "display_url" : "dlc.com\/1DTg7jj"
    } ]
  },
  "geo" : { },
  "id_str" : "593773266491158530",
  "text" : "RT @DiscoveryEd: LIVE at 10:40 AM ET with President Obama! #virtualfieldtrip #booksforall http:\/\/t.co\/HlbUuHxgKU http:\/\/t.co\/Sa5vfNOydQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DiscoveryEd\/status\/593744299927404544\/photo\/1",
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/Sa5vfNOydQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CD1nS2yWIAAyIoJ.jpg",
        "id_str" : "593744299524759552",
        "id" : 593744299524759552,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CD1nS2yWIAAyIoJ.jpg",
        "sizes" : [ {
          "h" : 375,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 375,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 375,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/Sa5vfNOydQ"
      } ],
      "hashtags" : [ {
        "text" : "virtualfieldtrip",
        "indices" : [ 42, 59 ]
      }, {
        "text" : "booksforall",
        "indices" : [ 60, 72 ]
      } ],
      "urls" : [ {
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/HlbUuHxgKU",
        "expanded_url" : "http:\/\/dlc.com\/1DTg7jj",
        "display_url" : "dlc.com\/1DTg7jj"
      } ]
    },
    "geo" : { },
    "id_str" : "593744299927404544",
    "text" : "LIVE at 10:40 AM ET with President Obama! #virtualfieldtrip #booksforall http:\/\/t.co\/HlbUuHxgKU http:\/\/t.co\/Sa5vfNOydQ",
    "id" : 593744299927404544,
    "created_at" : "2015-04-30 11:50:46 +0000",
    "user" : {
      "name" : "Discovery Education",
      "screen_name" : "DiscoveryEd",
      "protected" : false,
      "id_str" : "1665531",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/605812969688043521\/aKoqrKWQ_normal.jpg",
      "id" : 1665531,
      "verified" : false
    }
  },
  "id" : 593773266491158530,
  "created_at" : "2015-04-30 13:45:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/petesouza\/status\/593549050282176512\/photo\/1",
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/NxlQ9s7YBA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDy1SewUgAAkOYh.jpg",
      "id_str" : "593548580004069376",
      "id" : 593548580004069376,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDy1SewUgAAkOYh.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/NxlQ9s7YBA"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/StTJwilC8a",
      "expanded_url" : "http:\/\/on.fb.me\/1JBWtjF",
      "display_url" : "on.fb.me\/1JBWtjF"
    } ]
  },
  "geo" : { },
  "id_str" : "593559616350367745",
  "text" : "\"You can't eat me for lunch. Then there'd be no President!\" \u2014President Obama: http:\/\/t.co\/StTJwilC8a http:\/\/t.co\/NxlQ9s7YBA",
  "id" : 593559616350367745,
  "created_at" : "2015-04-29 23:36:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/593525806061629442\/photo\/1",
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/XOXQsTxd04",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDyfO-wUkAAFQeo.jpg",
      "id_str" : "593524330618720256",
      "id" : 593524330618720256,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDyfO-wUkAAFQeo.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1866,
        "resize" : "fit",
        "w" : 2800
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/XOXQsTxd04"
    } ],
    "hashtags" : [ {
      "text" : "ThankATeacher",
      "indices" : [ 87, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/ezVzVMI5I0",
      "expanded_url" : "http:\/\/go.wh.gov\/ThankATeacher",
      "display_url" : "go.wh.gov\/ThankATeacher"
    } ]
  },
  "geo" : { },
  "id_str" : "593525806061629442",
  "text" : "Here's to the 2015 National Teacher of the Year, @TexasTOY2015! http:\/\/t.co\/ezVzVMI5I0 #ThankATeacher http:\/\/t.co\/XOXQsTxd04",
  "id" : 593525806061629442,
  "created_at" : "2015-04-29 21:22:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThankATeacher",
      "indices" : [ 91, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/AUVzoqVMhM",
      "expanded_url" : "http:\/\/snpy.tv\/1JB8dTA",
      "display_url" : "snpy.tv\/1JB8dTA"
    } ]
  },
  "geo" : { },
  "id_str" : "593510858812035074",
  "text" : "RT if you agree: We all depend on teachers, and they deserve our appreciation and support. #ThankATeacher http:\/\/t.co\/AUVzoqVMhM",
  "id" : 593510858812035074,
  "created_at" : "2015-04-29 20:23:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Google For Education",
      "screen_name" : "GoogleForEdu",
      "indices" : [ 3, 16 ],
      "id_str" : "254218142",
      "id" : 254218142
    }, {
      "name" : "LeVar Burton",
      "screen_name" : "levarburton",
      "indices" : [ 21, 33 ],
      "id_str" : "18396070",
      "id" : 18396070
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThankaTeacher",
      "indices" : [ 115, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/QOiMG6GZng",
      "expanded_url" : "http:\/\/goo.gl\/7Gwte6",
      "display_url" : "goo.gl\/7Gwte6"
    } ]
  },
  "geo" : { },
  "id_str" : "593507482787401730",
  "text" : "RT @GoogleForEdu: If @levarburton made us love reading who made him love reading? Find out: http:\/\/t.co\/QOiMG6GZng #ThankaTeacher http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "LeVar Burton",
        "screen_name" : "levarburton",
        "indices" : [ 3, 15 ],
        "id_str" : "18396070",
        "id" : 18396070
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/GoogleForEdu\/status\/593495800673632256\/photo\/1",
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/qkiuyQ1dFh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CDyFSS1WgAARkdt.png",
        "id_str" : "593495800245813248",
        "id" : 593495800245813248,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDyFSS1WgAARkdt.png",
        "sizes" : [ {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/qkiuyQ1dFh"
      } ],
      "hashtags" : [ {
        "text" : "ThankaTeacher",
        "indices" : [ 97, 111 ]
      } ],
      "urls" : [ {
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/QOiMG6GZng",
        "expanded_url" : "http:\/\/goo.gl\/7Gwte6",
        "display_url" : "goo.gl\/7Gwte6"
      } ]
    },
    "geo" : { },
    "id_str" : "593495800673632256",
    "text" : "If @levarburton made us love reading who made him love reading? Find out: http:\/\/t.co\/QOiMG6GZng #ThankaTeacher http:\/\/t.co\/qkiuyQ1dFh",
    "id" : 593495800673632256,
    "created_at" : "2015-04-29 19:23:20 +0000",
    "user" : {
      "name" : "Google For Education",
      "screen_name" : "GoogleForEdu",
      "protected" : false,
      "id_str" : "254218142",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/638744309345288192\/Daix6KET_normal.png",
      "id" : 254218142,
      "verified" : true
    }
  },
  "id" : 593507482787401730,
  "created_at" : "2015-04-29 20:09:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kori Schulman",
      "screen_name" : "ks44",
      "indices" : [ 3, 8 ],
      "id_str" : "369246180",
      "id" : 369246180
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThankATeacher",
      "indices" : [ 104, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "593504529171107841",
  "text" : "RT @ks44: In first grade, I learned to love learning. Thanks Mrs. P for making vocabulary and math fun. #ThankATeacher http:\/\/t.co\/CmQ4vkNb\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ks44\/status\/593501945232363520\/photo\/1",
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/CmQ4vkNb8b",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CDyK38MUsAEOzfJ.jpg",
        "id_str" : "593501944561315841",
        "id" : 593501944561315841,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDyK38MUsAEOzfJ.jpg",
        "sizes" : [ {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/CmQ4vkNb8b"
      } ],
      "hashtags" : [ {
        "text" : "ThankATeacher",
        "indices" : [ 94, 108 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "593501945232363520",
    "text" : "In first grade, I learned to love learning. Thanks Mrs. P for making vocabulary and math fun. #ThankATeacher http:\/\/t.co\/CmQ4vkNb8b",
    "id" : 593501945232363520,
    "created_at" : "2015-04-29 19:47:45 +0000",
    "user" : {
      "name" : "Kori Schulman",
      "screen_name" : "ks44",
      "protected" : false,
      "id_str" : "369246180",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/667876153793859584\/DV7HzP-1_normal.jpg",
      "id" : 369246180,
      "verified" : true
    }
  },
  "id" : 593504529171107841,
  "created_at" : "2015-04-29 19:58:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/PunahouSchool\/status\/593489304770498561\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/k7U96AjcuQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDx_YBKWYAA7d3o.png",
      "id_str" : "593489301511495680",
      "id" : 593489301511495680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDx_YBKWYAA7d3o.png",
      "sizes" : [ {
        "h" : 217,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1108,
        "resize" : "fit",
        "w" : 1738
      }, {
        "h" : 653,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/k7U96AjcuQ"
    } ],
    "hashtags" : [ {
      "text" : "ThankATeacher",
      "indices" : [ 103, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/lM493EeWeh",
      "expanded_url" : "https:\/\/medium.com\/@PresidentObama\/my-fifth-grade-teacher-fedc4a20191d",
      "display_url" : "medium.com\/@PresidentObam\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "593499214430113794",
  "text" : "Ms. Mabel Hefty helped shape the education of a 5th-grader named Barack Obama: https:\/\/t.co\/lM493EeWeh #ThankATeacher http:\/\/t.co\/k7U96AjcuQ",
  "id" : 593499214430113794,
  "created_at" : "2015-04-29 19:36:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThankATeacher",
      "indices" : [ 108, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "593489088147234818",
  "text" : "RT @VP: When I was a kid, nuns were my first teachers. They taught me the importance of decency and virtue. #ThankATeacher http:\/\/t.co\/iDlT\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/VP\/status\/593485931715424256\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/iDlTzsMlW0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CDx8TdEWMAAwV99.jpg",
        "id_str" : "593485924568281088",
        "id" : 593485924568281088,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDx8TdEWMAAwV99.jpg",
        "sizes" : [ {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1333,
          "resize" : "fit",
          "w" : 2000
        } ],
        "display_url" : "pic.twitter.com\/iDlTzsMlW0"
      } ],
      "hashtags" : [ {
        "text" : "ThankATeacher",
        "indices" : [ 100, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "593485931715424256",
    "text" : "When I was a kid, nuns were my first teachers. They taught me the importance of decency and virtue. #ThankATeacher http:\/\/t.co\/iDlTzsMlW0",
    "id" : 593485931715424256,
    "created_at" : "2015-04-29 18:44:07 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 593489088147234818,
  "created_at" : "2015-04-29 18:56:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "indices" : [ 3, 13 ],
      "id_str" : "1613223313",
      "id" : 1613223313
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThankATeacher",
      "indices" : [ 121, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "593476328470540288",
  "text" : "RT @Cecilia44: Thx Mr Fenchel who taught us in the 70s about excellence, respect &amp; that govt can be a force for good #ThankATeacher http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Cecilia44\/status\/593474509258301440\/photo\/1",
        "indices" : [ 121, 143 ],
        "url" : "http:\/\/t.co\/oRoxQLspln",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CDxx68_WoAAVpr5.jpg",
        "id_str" : "593474508524265472",
        "id" : 593474508524265472,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDxx68_WoAAVpr5.jpg",
        "sizes" : [ {
          "h" : 207,
          "resize" : "fit",
          "w" : 495
        }, {
          "h" : 207,
          "resize" : "fit",
          "w" : 495
        }, {
          "h" : 207,
          "resize" : "fit",
          "w" : 495
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 142,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/oRoxQLspln"
      } ],
      "hashtags" : [ {
        "text" : "ThankATeacher",
        "indices" : [ 106, 120 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "593474509258301440",
    "text" : "Thx Mr Fenchel who taught us in the 70s about excellence, respect &amp; that govt can be a force for good #ThankATeacher http:\/\/t.co\/oRoxQLspln",
    "id" : 593474509258301440,
    "created_at" : "2015-04-29 17:58:43 +0000",
    "user" : {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "protected" : false,
      "id_str" : "1613223313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000172019215\/ed65eda76f51213f91b33edbaa62054c_normal.jpeg",
      "id" : 1613223313,
      "verified" : true
    }
  },
  "id" : 593476328470540288,
  "created_at" : "2015-04-29 18:05:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sylvia S. Estrada",
      "screen_name" : "Estradasrnp",
      "indices" : [ 3, 15 ],
      "id_str" : "48517050",
      "id" : 48517050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "593462830654988288",
  "text" : "RT @Estradasrnp: Today President Obama honored school teachers.Thks to Ms Keller, my fourth grade teacher who inspired me to the written wo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ThankATeacher",
        "indices" : [ 126, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 34.0768902150651, -118.3792911564158 ]
    },
    "id_str" : "593447750991089665",
    "text" : "Today President Obama honored school teachers.Thks to Ms Keller, my fourth grade teacher who inspired me to the written word. #ThankATeacher",
    "id" : 593447750991089665,
    "created_at" : "2015-04-29 16:12:24 +0000",
    "user" : {
      "name" : "Sylvia S. Estrada",
      "screen_name" : "Estradasrnp",
      "protected" : false,
      "id_str" : "48517050",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/582251590729351168\/Q7ktifz-_normal.png",
      "id" : 48517050,
      "verified" : false
    }
  },
  "id" : 593462830654988288,
  "created_at" : "2015-04-29 17:12:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heather Bucurel",
      "screen_name" : "hmbucurel",
      "indices" : [ 3, 13 ],
      "id_str" : "1227146066",
      "id" : 1227146066
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThankATeacher",
      "indices" : [ 124, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "593459634297409536",
  "text" : "RT @hmbucurel: Without their influence, knowledge, and effort I would not be where I am today:  preparing to be a teacher!  #ThankATeacher",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ThankATeacher",
        "indices" : [ 109, 123 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 35.89667332869291, -78.81112832146592 ]
    },
    "id_str" : "593445086043705345",
    "text" : "Without their influence, knowledge, and effort I would not be where I am today:  preparing to be a teacher!  #ThankATeacher",
    "id" : 593445086043705345,
    "created_at" : "2015-04-29 16:01:48 +0000",
    "user" : {
      "name" : "Heather Bucurel",
      "screen_name" : "hmbucurel",
      "protected" : false,
      "id_str" : "1227146066",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/733808223883558912\/b9weYMsc_normal.jpg",
      "id" : 1227146066,
      "verified" : false
    }
  },
  "id" : 593459634297409536,
  "created_at" : "2015-04-29 16:59:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "indices" : [ 3, 13 ],
      "id_str" : "131144091",
      "id" : 131144091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "593458003711373313",
  "text" : "RT @Goldman44: Thank you to Mom, a public school principal and my first, best teacher. And to Mrs. Kolar who taught me how to write #ThankA\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ThankATeacher",
        "indices" : [ 117, 131 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "593457097796235264",
    "text" : "Thank you to Mom, a public school principal and my first, best teacher. And to Mrs. Kolar who taught me how to write #ThankATeacher",
    "id" : 593457097796235264,
    "created_at" : "2015-04-29 16:49:32 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 593458003711373313,
  "created_at" : "2015-04-29 16:53:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Gersen",
      "screen_name" : "joegersen",
      "indices" : [ 3, 13 ],
      "id_str" : "59666440",
      "id" : 59666440
    }, {
      "name" : "Alison Perez",
      "screen_name" : "MrsAliPerez",
      "indices" : [ 25, 37 ],
      "id_str" : "2163915231",
      "id" : 2163915231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "593452062547058689",
  "text" : "RT @joegersen: Thank you @MrsAliPerez! She is my role model! Every day I hope to match a portion of her dedication to community change #Tha\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Alison Perez",
        "screen_name" : "MrsAliPerez",
        "indices" : [ 10, 22 ],
        "id_str" : "2163915231",
        "id" : 2163915231
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ThankATeacher",
        "indices" : [ 120, 134 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "593446608299102208",
    "text" : "Thank you @MrsAliPerez! She is my role model! Every day I hope to match a portion of her dedication to community change #ThankATeacher",
    "id" : 593446608299102208,
    "created_at" : "2015-04-29 16:07:51 +0000",
    "user" : {
      "name" : "Joe Gersen",
      "screen_name" : "joegersen",
      "protected" : false,
      "id_str" : "59666440",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/672913812899676160\/sD1zCJGa_normal.jpg",
      "id" : 59666440,
      "verified" : false
    }
  },
  "id" : 593452062547058689,
  "created_at" : "2015-04-29 16:29:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Johnson & Johnson",
      "screen_name" : "JNJNews",
      "indices" : [ 13, 21 ],
      "id_str" : "20457806",
      "id" : 20457806
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/593446111311958017\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/it5HK26x5x",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDxX92ZW8AA6gPM.jpg",
      "id_str" : "593445970991575040",
      "id" : 593445970991575040,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDxX92ZW8AA6gPM.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/it5HK26x5x"
    } ],
    "hashtags" : [ {
      "text" : "LeadOnLeave",
      "indices" : [ 80, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/Pl8iwTrYMd",
      "expanded_url" : "https:\/\/shar.es\/1pwRfO",
      "display_url" : "shar.es\/1pwRfO"
    } ]
  },
  "geo" : { },
  "id_str" : "593446111311958017",
  "text" : "Great to see @JNJNews expand paid leave benefits.\nNow it's time for Congress to #LeadOnLeave: https:\/\/t.co\/Pl8iwTrYMd http:\/\/t.co\/it5HK26x5x",
  "id" : 593446111311958017,
  "created_at" : "2015-04-29 16:05:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/593440051645829121\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/nCh2BmzvUJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDxSc9KWYAAUAJz.jpg",
      "id_str" : "593439908313849856",
      "id" : 593439908313849856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDxSc9KWYAAUAJz.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/nCh2BmzvUJ"
    } ],
    "hashtags" : [ {
      "text" : "ThankATeacher",
      "indices" : [ 100, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "593440051645829121",
  "text" : "\"They teach students to challenge themselves and dream beyond their circumstances\" \u2014President Obama #ThankATeacher http:\/\/t.co\/nCh2BmzvUJ",
  "id" : 593440051645829121,
  "created_at" : "2015-04-29 15:41:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThankATeacher",
      "indices" : [ 119, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "593439761269956608",
  "text" : "\"They teach far more than formulas or phonetics. They\u2019re selling hope, sparking imaginations, opening up minds\u201D \u2014Obama #ThankATeacher",
  "id" : 593439761269956608,
  "created_at" : "2015-04-29 15:40:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThankATeacher",
      "indices" : [ 126, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "593438292634312704",
  "text" : "\"We all depend on our teachers, whether we have kids in school or not. They deserve our support and our appreciation.\" \u2014Obama #ThankATeacher",
  "id" : 593438292634312704,
  "created_at" : "2015-04-29 15:34:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/593438134823559169\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/XjvxST6yVD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDxQ0H8WYAAhTdi.jpg",
      "id_str" : "593438107321655296",
      "id" : 593438107321655296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDxQ0H8WYAAhTdi.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/XjvxST6yVD"
    } ],
    "hashtags" : [ {
      "text" : "ThankATeacher",
      "indices" : [ 90, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/ezVzVMI5I0",
      "expanded_url" : "http:\/\/go.wh.gov\/ThankATeacher",
      "display_url" : "go.wh.gov\/ThankATeacher"
    } ]
  },
  "geo" : { },
  "id_str" : "593438134823559169",
  "text" : "\"America\u2019s future is written in our classrooms.\" \u2014President Obama: http:\/\/t.co\/ezVzVMI5I0 #ThankATeacher http:\/\/t.co\/XjvxST6yVD",
  "id" : 593438134823559169,
  "created_at" : "2015-04-29 15:34:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/o6PuzWJYeq",
      "expanded_url" : "http:\/\/go.wh.gov\/ThankATeacher",
      "display_url" : "go.wh.gov\/ThankATeacher"
    } ]
  },
  "geo" : { },
  "id_str" : "593437764001075200",
  "text" : "RT @WHLive: \"Today\u2019s also a chance to reaffirm how important teachers are to our nation\" \u2014President Obama: http:\/\/t.co\/o6PuzWJYeq #ThankATe\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ThankATeacher",
        "indices" : [ 118, 132 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/o6PuzWJYeq",
        "expanded_url" : "http:\/\/go.wh.gov\/ThankATeacher",
        "display_url" : "go.wh.gov\/ThankATeacher"
      } ]
    },
    "geo" : { },
    "id_str" : "593437738629726208",
    "text" : "\"Today\u2019s also a chance to reaffirm how important teachers are to our nation\" \u2014President Obama: http:\/\/t.co\/o6PuzWJYeq #ThankATeacher",
    "id" : 593437738629726208,
    "created_at" : "2015-04-29 15:32:37 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 593437764001075200,
  "created_at" : "2015-04-29 15:32:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThankATeacher",
      "indices" : [ 122, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "593437568257110016",
  "text" : "\"The teachers behind me\u2026give their students their all\u2014their knowledge, their creativity, their focused attention.\" \u2014Obama #ThankATeacher",
  "id" : 593437568257110016,
  "created_at" : "2015-04-29 15:31:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThankATeacher",
      "indices" : [ 93, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/ezVzVMZH6A",
      "expanded_url" : "http:\/\/go.wh.gov\/ThankATeacher",
      "display_url" : "go.wh.gov\/ThankATeacher"
    } ]
  },
  "geo" : { },
  "id_str" : "593437510455394304",
  "text" : "Watch live: President Obama honors the National Teacher of the Year \u2192 http:\/\/t.co\/ezVzVMZH6A #ThankATeacher",
  "id" : 593437510455394304,
  "created_at" : "2015-04-29 15:31:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/593428625317203968\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/rpis3qFsfl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDxIFT7W0AAIXtu.jpg",
      "id_str" : "593428506991841280",
      "id" : 593428506991841280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDxIFT7W0AAIXtu.jpg",
      "sizes" : [ {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/rpis3qFsfl"
    } ],
    "hashtags" : [ {
      "text" : "ThankATeacher",
      "indices" : [ 72, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/ezVzVMI5I0",
      "expanded_url" : "http:\/\/go.wh.gov\/ThankATeacher",
      "display_url" : "go.wh.gov\/ThankATeacher"
    } ]
  },
  "geo" : { },
  "id_str" : "593428625317203968",
  "text" : "Love teachers? Share how a teacher made a difference in your life using #ThankATeacher \u2192 http:\/\/t.co\/ezVzVMI5I0 http:\/\/t.co\/rpis3qFsfl",
  "id" : 593428625317203968,
  "created_at" : "2015-04-29 14:56:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elijah E. Cummings",
      "screen_name" : "RepCummings",
      "indices" : [ 3, 15 ],
      "id_str" : "787373558",
      "id" : 787373558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "593421732456697856",
  "text" : "RT @RepCummings: We can't allow violence to distract from our purpose. We must continue with peaceful calls for justice to honor the memory\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FreddieGray",
        "indices" : [ 126, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "593412574949068800",
    "text" : "We can't allow violence to distract from our purpose. We must continue with peaceful calls for justice to honor the memory of #FreddieGray",
    "id" : 593412574949068800,
    "created_at" : "2015-04-29 13:52:37 +0000",
    "user" : {
      "name" : "Elijah E. Cummings",
      "screen_name" : "RepCummings",
      "protected" : false,
      "id_str" : "787373558",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/512259394520637440\/iqJCC7YI_normal.jpeg",
      "id" : 787373558,
      "verified" : true
    }
  },
  "id" : 593421732456697856,
  "created_at" : "2015-04-29 14:29:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Washington Post",
      "screen_name" : "washingtonpost",
      "indices" : [ 3, 18 ],
      "id_str" : "2467791",
      "id" : 2467791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/G3v1QsO6qt",
      "expanded_url" : "http:\/\/wapo.st\/1ds3k1Z",
      "display_url" : "wapo.st\/1ds3k1Z"
    } ]
  },
  "geo" : { },
  "id_str" : "593414539271491585",
  "text" : "RT @washingtonpost: Pope Francis: It\u2019s \"pure scandal\" that women earn less than men for the same work http:\/\/t.co\/G3v1QsO6qt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/G3v1QsO6qt",
        "expanded_url" : "http:\/\/wapo.st\/1ds3k1Z",
        "display_url" : "wapo.st\/1ds3k1Z"
      } ]
    },
    "geo" : { },
    "id_str" : "593390807350128640",
    "text" : "Pope Francis: It\u2019s \"pure scandal\" that women earn less than men for the same work http:\/\/t.co\/G3v1QsO6qt",
    "id" : 593390807350128640,
    "created_at" : "2015-04-29 12:26:07 +0000",
    "user" : {
      "name" : "Washington Post",
      "screen_name" : "washingtonpost",
      "protected" : false,
      "id_str" : "2467791",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/753656134565785600\/iQ1GX-ov_normal.jpg",
      "id" : 2467791,
      "verified" : true
    }
  },
  "id" : 593414539271491585,
  "created_at" : "2015-04-29 14:00:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wall Street Journal",
      "screen_name" : "WSJ",
      "indices" : [ 23, 27 ],
      "id_str" : "3108351",
      "id" : 3108351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LeadOnTrade",
      "indices" : [ 85, 97 ]
    }, {
      "text" : "TPP",
      "indices" : [ 98, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/r9BhubwxDk",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/c1df44b8-f202-4dbe-bbf0-1bdde4ba8e8e",
      "display_url" : "amp.twimg.com\/v\/c1df44b8-f20\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "593186355288481792",
  "text" : "President Obama to the @WSJ on how he's ensuring transparency in trade negotiations. #LeadOnTrade #TPP\nhttps:\/\/t.co\/r9BhubwxDk",
  "id" : 593186355288481792,
  "created_at" : "2015-04-28 22:53:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/593166969332957185\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/7hNpMmm15e",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDtaGbCWIAA0j7a.jpg",
      "id_str" : "593166842312663040",
      "id" : 593166842312663040,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDtaGbCWIAA0j7a.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/7hNpMmm15e"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/VsWH3lD3A4",
      "expanded_url" : "http:\/\/go.wh.gov\/fcuTfS",
      "display_url" : "go.wh.gov\/fcuTfS"
    } ]
  },
  "geo" : { },
  "id_str" : "593166969332957185",
  "text" : "\"This is not new and we shouldn\u2019t pretend that it\u2019s new\" \u2014Obama on the situation in Baltimore: http:\/\/t.co\/VsWH3lD3A4 http:\/\/t.co\/7hNpMmm15e",
  "id" : 593166969332957185,
  "created_at" : "2015-04-28 21:36:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/s729g7gl7O",
      "expanded_url" : "http:\/\/snpy.tv\/1JPqNUK",
      "display_url" : "snpy.tv\/1JPqNUK"
    } ]
  },
  "geo" : { },
  "id_str" : "593144416027578368",
  "text" : "\"The thousands of demonstrators who did it the right way...have been lost in the discussion\" \u2014Obama on Baltimore http:\/\/t.co\/s729g7gl7O",
  "id" : 593144416027578368,
  "created_at" : "2015-04-28 20:07:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "593121519238152192",
  "text" : "RT @vj44: To the Baltimore citizens volunteering to clean up the debris from last night\u2019s violence \u2013 thank you. It\u2019s your spirit that gives\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "593119972513153024",
    "text" : "To the Baltimore citizens volunteering to clean up the debris from last night\u2019s violence \u2013 thank you. It\u2019s your spirit that gives us hope.",
    "id" : 593119972513153024,
    "created_at" : "2015-04-28 18:29:55 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 593121519238152192,
  "created_at" : "2015-04-28 18:36:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/T3t6ptxmaZ",
      "expanded_url" : "http:\/\/snpy.tv\/1EjDi9V",
      "display_url" : "snpy.tv\/1EjDi9V"
    } ]
  },
  "geo" : { },
  "id_str" : "593110124249513984",
  "text" : "Watch President Obama speak on the situation in Baltimore. http:\/\/t.co\/T3t6ptxmaZ",
  "id" : 593110124249513984,
  "created_at" : "2015-04-28 17:50:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/08a4vtoXe1",
      "expanded_url" : "http:\/\/snpy.tv\/1P37zga",
      "display_url" : "snpy.tv\/1P37zga"
    } ]
  },
  "geo" : { },
  "id_str" : "593106073785114624",
  "text" : "\u201CDon\u2019t just pay attention to these communities when a CVS burns\u201D \u2014President Obama on the situation in Baltimore http:\/\/t.co\/08a4vtoXe1",
  "id" : 593106073785114624,
  "created_at" : "2015-04-28 17:34:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/Fr3Aa6ZrrP",
      "expanded_url" : "http:\/\/snpy.tv\/1ENJLNG",
      "display_url" : "snpy.tv\/1ENJLNG"
    } ]
  },
  "geo" : { },
  "id_str" : "593100372861825026",
  "text" : "\u201CThis is not new, and we shouldn\u2019t pretend that it\u2019s new.\u201D \u2014President Obama addressing the situation in Baltimore http:\/\/t.co\/Fr3Aa6ZrrP",
  "id" : 593100372861825026,
  "created_at" : "2015-04-28 17:12:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "593096555856580608",
  "text" : "\"We as a country have to do some soul-searching. This is not new. This has been going on for decades.\" \u2014Obama on the situation in Baltimore",
  "id" : 593096555856580608,
  "created_at" : "2015-04-28 16:56:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LeadOnTrade",
      "indices" : [ 96, 108 ]
    }, {
      "text" : "TPP",
      "indices" : [ 109, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/r72AcEpHjw",
      "expanded_url" : "http:\/\/snpy.tv\/1OzUzDH",
      "display_url" : "snpy.tv\/1OzUzDH"
    } ]
  },
  "geo" : { },
  "id_str" : "593090313926877185",
  "text" : "There are many Japanese cars in America.\nLet's make sure there are more American cars in Japan. #LeadOnTrade #TPP http:\/\/t.co\/r72AcEpHjw",
  "id" : 593090313926877185,
  "created_at" : "2015-04-28 16:32:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/ZApxAEUcw4",
      "expanded_url" : "http:\/\/snpy.tv\/1bPUSsU",
      "display_url" : "snpy.tv\/1bPUSsU"
    } ]
  },
  "geo" : { },
  "id_str" : "593087801140203521",
  "text" : "RT @WHLive: Watch President Obama's opening remarks at a press conference with Prime Minister Abe of Japan. http:\/\/t.co\/ZApxAEUcw4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/ZApxAEUcw4",
        "expanded_url" : "http:\/\/snpy.tv\/1bPUSsU",
        "display_url" : "snpy.tv\/1bPUSsU"
      } ]
    },
    "geo" : { },
    "id_str" : "593087772191236096",
    "text" : "Watch President Obama's opening remarks at a press conference with Prime Minister Abe of Japan. http:\/\/t.co\/ZApxAEUcw4",
    "id" : 593087772191236096,
    "created_at" : "2015-04-28 16:21:58 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 593087801140203521,
  "created_at" : "2015-04-28 16:22:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/593086801851482112\/photo\/1",
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/nmDve8Gkhz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDsROueWMAAxin4.jpg",
      "id_str" : "593086720620507136",
      "id" : 593086720620507136,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDsROueWMAAxin4.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/nmDve8Gkhz"
    } ],
    "hashtags" : [ {
      "text" : "LetGirlsLearn",
      "indices" : [ 51, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "593086801851482112",
  "text" : "Obama: The U.S. &amp; Japan \"are helping to lead...#LetGirlsLearn to give more young women and girls access to education\" http:\/\/t.co\/nmDve8Gkhz",
  "id" : 593086801851482112,
  "created_at" : "2015-04-28 16:18:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LeadOnTrade",
      "indices" : [ 125, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "593086189902680066",
  "text" : "\"There are many Japanese cars in America. I want to see more American cars in Japan\" \u2014Obama on why it's time to pass the TPP #LeadOnTrade",
  "id" : 593086189902680066,
  "created_at" : "2015-04-28 16:15:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/e03QHxQj8J",
      "expanded_url" : "http:\/\/go.wh.gov\/4XNi23",
      "display_url" : "go.wh.gov\/4XNi23"
    } ]
  },
  "geo" : { },
  "id_str" : "593085716155867136",
  "text" : "RT @WHLive: \"Our nations have become, not just allies, but true partners and friends.\" \u2014Obama on the U.S. and Japan: http:\/\/t.co\/e03QHxQj8J",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/e03QHxQj8J",
        "expanded_url" : "http:\/\/go.wh.gov\/4XNi23",
        "display_url" : "go.wh.gov\/4XNi23"
      } ]
    },
    "geo" : { },
    "id_str" : "593085549218369537",
    "text" : "\"Our nations have become, not just allies, but true partners and friends.\" \u2014Obama on the U.S. and Japan: http:\/\/t.co\/e03QHxQj8J",
    "id" : 593085549218369537,
    "created_at" : "2015-04-28 16:13:08 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 593085716155867136,
  "created_at" : "2015-04-28 16:13:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/593085478531796992\/photo\/1",
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/qcrUMzhyJw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDsPmsCWEAARmlS.jpg",
      "id_str" : "593084933259792384",
      "id" : 593084933259792384,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDsPmsCWEAARmlS.jpg",
      "sizes" : [ {
        "h" : 2280,
        "resize" : "fit",
        "w" : 3420
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/qcrUMzhyJw"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "593085478531796992",
  "text" : "\"The past can be overcome, former adversaries can become the closest of allies\" \u2014President Obama on the U.S. &amp; Japan http:\/\/t.co\/qcrUMzhyJw",
  "id" : 593085478531796992,
  "created_at" : "2015-04-28 16:12:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/mS5UTjoSbv",
      "expanded_url" : "http:\/\/go.wh.gov\/KeM2xZ",
      "display_url" : "go.wh.gov\/KeM2xZ"
    } ]
  },
  "geo" : { },
  "id_str" : "593084836618731520",
  "text" : "Watch live: President Obama holds a press conference with Prime Minister Abe of Japan \u2192 http:\/\/t.co\/mS5UTjoSbv",
  "id" : 593084836618731520,
  "created_at" : "2015-04-28 16:10:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USAID",
      "screen_name" : "USAID",
      "indices" : [ 3, 9 ],
      "id_str" : "36683668",
      "id" : 36683668
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NepalQuake",
      "indices" : [ 74, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/Zxf93LR2fT",
      "expanded_url" : "http:\/\/go.usa.gov\/3BgMR",
      "display_url" : "go.usa.gov\/3BgMR"
    } ]
  },
  "geo" : { },
  "id_str" : "593059364434354178",
  "text" : "RT @USAID: We're providing an additional $9 million in assistance for the #NepalQuake emergency response: http:\/\/t.co\/Zxf93LR2fT http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/USAID\/status\/592775842406735873\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/S2r8qzRmdJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CDn2fLWW8AIoS7q.jpg",
        "id_str" : "592775841458876418",
        "id" : 592775841458876418,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDn2fLWW8AIoS7q.jpg",
        "sizes" : [ {
          "h" : 447,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 158,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 447,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 279,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/S2r8qzRmdJ"
      } ],
      "hashtags" : [ {
        "text" : "NepalQuake",
        "indices" : [ 63, 74 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/Zxf93LR2fT",
        "expanded_url" : "http:\/\/go.usa.gov\/3BgMR",
        "display_url" : "go.usa.gov\/3BgMR"
      } ]
    },
    "geo" : { },
    "id_str" : "592775842406735873",
    "text" : "We're providing an additional $9 million in assistance for the #NepalQuake emergency response: http:\/\/t.co\/Zxf93LR2fT http:\/\/t.co\/S2r8qzRmdJ",
    "id" : 592775842406735873,
    "created_at" : "2015-04-27 19:42:28 +0000",
    "user" : {
      "name" : "USAID",
      "screen_name" : "USAID",
      "protected" : false,
      "id_str" : "36683668",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/717410574523564032\/ExeUofTG_normal.jpg",
      "id" : 36683668,
      "verified" : true
    }
  },
  "id" : 593059364434354178,
  "created_at" : "2015-04-28 14:29:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/592847043477041152\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/Yg5KVytiDf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDo3DUEW8AA8b8i.jpg",
      "id_str" : "592846831018766336",
      "id" : 592846831018766336,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDo3DUEW8AA8b8i.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1867,
        "resize" : "fit",
        "w" : 2800
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/Yg5KVytiDf"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/hzTFrWd3lo",
      "expanded_url" : "http:\/\/go.wh.gov\/1h66Xo",
      "display_url" : "go.wh.gov\/1h66Xo"
    } ]
  },
  "geo" : { },
  "id_str" : "592847043477041152",
  "text" : "President Obama meets with Attorney General Loretta Lynch on the situation in Baltimore: http:\/\/t.co\/hzTFrWd3lo http:\/\/t.co\/Yg5KVytiDf",
  "id" : 592847043477041152,
  "created_at" : "2015-04-28 00:25:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/592823026082828288\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/mhz4q3lQAO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDohXHbWYAEZcVm.png",
      "id_str" : "592822981967110145",
      "id" : 592822981967110145,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDohXHbWYAEZcVm.png",
      "sizes" : [ {
        "h" : 117,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 345,
        "resize" : "fit",
        "w" : 1004
      }, {
        "h" : 345,
        "resize" : "fit",
        "w" : 1004
      }, {
        "h" : 206,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/mhz4q3lQAO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "592823026082828288",
  "text" : "Attorney General Lynch just updated the President on the situation in Baltimore related to the death of Freddie Gray. http:\/\/t.co\/mhz4q3lQAO",
  "id" : 592823026082828288,
  "created_at" : "2015-04-27 22:49:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/592777878317748225\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/WXRjO0quiW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDn4TpcWgAMJZI4.jpg",
      "id_str" : "592777842401902595",
      "id" : 592777842401902595,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDn4TpcWgAMJZI4.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/WXRjO0quiW"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/2GRM1HHX96",
      "expanded_url" : "http:\/\/on.wsj.com\/1DuuutR",
      "display_url" : "on.wsj.com\/1DuuutR"
    } ]
  },
  "geo" : { },
  "id_str" : "592777878317748225",
  "text" : "We can't let China write the rules for trade.\nIt's time to pass President Obama's trade deal \u2192 http:\/\/t.co\/2GRM1HHX96 http:\/\/t.co\/WXRjO0quiW",
  "id" : 592777878317748225,
  "created_at" : "2015-04-27 19:50:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wall Street Journal",
      "screen_name" : "WSJ",
      "indices" : [ 3, 7 ],
      "id_str" : "3108351",
      "id" : 3108351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/ZzTrE8zLoA",
      "expanded_url" : "http:\/\/on.wsj.com\/1JLiPMr",
      "display_url" : "on.wsj.com\/1JLiPMr"
    } ]
  },
  "geo" : { },
  "id_str" : "592768704804495360",
  "text" : "RT @WSJ: In Wall Street Journal interview, Obama warns failure to complete Asia trade pact would benefit China: http:\/\/t.co\/ZzTrE8zLoA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/ZzTrE8zLoA",
        "expanded_url" : "http:\/\/on.wsj.com\/1JLiPMr",
        "display_url" : "on.wsj.com\/1JLiPMr"
      } ]
    },
    "geo" : { },
    "id_str" : "592762435511136257",
    "text" : "In Wall Street Journal interview, Obama warns failure to complete Asia trade pact would benefit China: http:\/\/t.co\/ZzTrE8zLoA",
    "id" : 592762435511136257,
    "created_at" : "2015-04-27 18:49:12 +0000",
    "user" : {
      "name" : "Wall Street Journal",
      "screen_name" : "WSJ",
      "protected" : false,
      "id_str" : "3108351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/685113343204585473\/jV72Zljq_normal.jpg",
      "id" : 3108351,
      "verified" : true
    }
  },
  "id" : 592768704804495360,
  "created_at" : "2015-04-27 19:14:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JapanStateDinner",
      "indices" : [ 87, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/9P18hdifnD",
      "expanded_url" : "http:\/\/go.wh.gov\/1uao1W",
      "display_url" : "go.wh.gov\/1uao1W"
    } ]
  },
  "geo" : { },
  "id_str" : "592766846585196545",
  "text" : "RT @FLOTUS: The new \"Kailua Blue\" Obama China will be served for the first time at the #JapanStateDinner: http:\/\/t.co\/9P18hdifnD http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/FLOTUS\/status\/592757653756981248\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/sojhYpXR46",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CDncFp2WEAAdVWu.jpg",
        "id_str" : "592746815667179520",
        "id" : 592746815667179520,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDncFp2WEAAdVWu.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/sojhYpXR46"
      } ],
      "hashtags" : [ {
        "text" : "JapanStateDinner",
        "indices" : [ 75, 92 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/9P18hdifnD",
        "expanded_url" : "http:\/\/go.wh.gov\/1uao1W",
        "display_url" : "go.wh.gov\/1uao1W"
      } ]
    },
    "geo" : { },
    "id_str" : "592757653756981248",
    "text" : "The new \"Kailua Blue\" Obama China will be served for the first time at the #JapanStateDinner: http:\/\/t.co\/9P18hdifnD http:\/\/t.co\/sojhYpXR46",
    "id" : 592757653756981248,
    "created_at" : "2015-04-27 18:30:12 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 592766846585196545,
  "created_at" : "2015-04-27 19:06:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "592744638622085120",
  "text" : "RT @VP: First-rate. Fair-minded. Independent &amp; strong. Today, Loretta Lynch is our new Attorney General of the United States. http:\/\/t.co\/G\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/VP\/status\/592744466613678080\/photo\/1",
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/GQBDDRCuaF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CDnZ81JWIAAebF3.jpg",
        "id_str" : "592744465057587200",
        "id" : 592744465057587200,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDnZ81JWIAAebF3.jpg",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2000,
          "resize" : "fit",
          "w" : 3000
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/GQBDDRCuaF"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "592744466613678080",
    "text" : "First-rate. Fair-minded. Independent &amp; strong. Today, Loretta Lynch is our new Attorney General of the United States. http:\/\/t.co\/GQBDDRCuaF",
    "id" : 592744466613678080,
    "created_at" : "2015-04-27 17:37:48 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 592744638622085120,
  "created_at" : "2015-04-27 17:38:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    }, {
      "name" : "Ron Wyden",
      "screen_name" : "RonWyden",
      "indices" : [ 94, 103 ],
      "id_str" : "250188760",
      "id" : 250188760
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "592720274841296900",
  "text" : "RT @Simas44: \"Trade done right.\" Great fact-based assessment by former OR AFL-CIO head on how @RonWyden improves US trade rules. http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ron Wyden",
        "screen_name" : "RonWyden",
        "indices" : [ 81, 90 ],
        "id_str" : "250188760",
        "id" : 250188760
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/A18wxt35fB",
        "expanded_url" : "http:\/\/bit.ly\/1EwoI09",
        "display_url" : "bit.ly\/1EwoI09"
      } ]
    },
    "geo" : { },
    "id_str" : "592719935031406593",
    "text" : "\"Trade done right.\" Great fact-based assessment by former OR AFL-CIO head on how @RonWyden improves US trade rules. http:\/\/t.co\/A18wxt35fB",
    "id" : 592719935031406593,
    "created_at" : "2015-04-27 16:00:19 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 592720274841296900,
  "created_at" : "2015-04-27 16:01:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 115, 118 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "592714937807568897",
  "text" : "RT @vj44: \"She excelled in everything she's done. A first rate, fair minded, independent lawyer &amp; prosecutor.\" @VP on AG Lynch http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 105, 108 ],
        "id_str" : "325830217",
        "id" : 325830217
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/vj44\/status\/592711541369212928\/photo\/1",
        "indices" : [ 121, 143 ],
        "url" : "http:\/\/t.co\/rulXmPSn4O",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CDm7_LgW8AMSD2A.jpg",
        "id_str" : "592711520070594563",
        "id" : 592711520070594563,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDm7_LgW8AMSD2A.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/rulXmPSn4O"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 38.89601135253905, -77.03431701660153 ]
    },
    "id_str" : "592711541369212928",
    "text" : "\"She excelled in everything she's done. A first rate, fair minded, independent lawyer &amp; prosecutor.\" @VP on AG Lynch http:\/\/t.co\/rulXmPSn4O",
    "id" : 592711541369212928,
    "created_at" : "2015-04-27 15:26:58 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 592714937807568897,
  "created_at" : "2015-04-27 15:40:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "592712197618401281",
  "text" : "RT @VP: \u201CI have absolute confidence that Loretta Lynch will exceed the high standards set for her.\u201D -VP Biden on Loretta Lynch",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "592710757294419969",
    "text" : "\u201CI have absolute confidence that Loretta Lynch will exceed the high standards set for her.\u201D -VP Biden on Loretta Lynch",
    "id" : 592710757294419969,
    "created_at" : "2015-04-27 15:23:51 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 592712197618401281,
  "created_at" : "2015-04-27 15:29:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 49, 52 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/P8raHgemIf",
      "expanded_url" : "http:\/\/go.wh.gov\/CGvR7y",
      "display_url" : "go.wh.gov\/CGvR7y"
    } ]
  },
  "geo" : { },
  "id_str" : "592711816993726464",
  "text" : "\u201CIt\u2019s about time this woman is being sworn in.\u201D \u2014@VP Biden on our next Attorney General, Loretta Lynch: http:\/\/t.co\/P8raHgemIf",
  "id" : 592711816993726464,
  "created_at" : "2015-04-27 15:28:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/wITKnz1R4i",
      "expanded_url" : "http:\/\/snpy.tv\/1bz8I2H",
      "display_url" : "snpy.tv\/1bz8I2H"
    } ]
  },
  "geo" : { },
  "id_str" : "592702112519331840",
  "text" : "\"My entire Presidency's been about helping working families\" \u2014President Obama on the most progressive trade deal ever http:\/\/t.co\/wITKnz1R4i",
  "id" : 592702112519331840,
  "created_at" : "2015-04-27 14:49:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 27, 30 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Bill Nye",
      "screen_name" : "BillNye",
      "indices" : [ 32, 40 ],
      "id_str" : "37710752",
      "id" : 37710752
    }, {
      "name" : "New England Patriots",
      "screen_name" : "Patriots",
      "indices" : [ 50, 59 ],
      "id_str" : "31126587",
      "id" : 31126587
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/29lNJaPteT",
      "expanded_url" : "https:\/\/youtu.be\/u5sWgcs4daM",
      "display_url" : "youtu.be\/u5sWgcs4daM"
    } ]
  },
  "geo" : { },
  "id_str" : "592467835349245953",
  "text" : "Watch President Obama, the @VP, @BillNye, and the @Patriots take you through last week at the White House \u2192 https:\/\/t.co\/29lNJaPteT",
  "id" : 592467835349245953,
  "created_at" : "2015-04-26 23:18:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 47, 50 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ItsOnUs",
      "indices" : [ 129, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/WvMovbCYS0",
      "expanded_url" : "https:\/\/youtu.be\/TynBBncmGpA",
      "display_url" : "youtu.be\/TynBBncmGpA"
    } ]
  },
  "geo" : { },
  "id_str" : "592455118190223360",
  "text" : "\"Enough is enough is enough. This must stop.\" \u2014@VP Biden on preventing sexual assault.\n\nRT if you agree. https:\/\/t.co\/WvMovbCYS0 #ItsOnUs",
  "id" : 592455118190223360,
  "created_at" : "2015-04-26 22:28:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LeadOnTrade",
      "indices" : [ 116, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/7QArLMvpK1",
      "expanded_url" : "http:\/\/go.wh.gov\/HW8bVz",
      "display_url" : "go.wh.gov\/HW8bVz"
    } ]
  },
  "geo" : { },
  "id_str" : "592395254642249729",
  "text" : "Watch President Obama on why he's fighting for trade deals that put American workers first \u2192 http:\/\/t.co\/7QArLMvpK1 #LeadOnTrade",
  "id" : 592395254642249729,
  "created_at" : "2015-04-26 18:30:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/7QArLMvpK1",
      "expanded_url" : "http:\/\/go.wh.gov\/HW8bVz",
      "display_url" : "go.wh.gov\/HW8bVz"
    } ]
  },
  "geo" : { },
  "id_str" : "592368803180257281",
  "text" : "\"America has to write the rules of the global economy, so...our workers can compete on a level playing field\" \u2014Obama: http:\/\/t.co\/7QArLMvpK1",
  "id" : 592368803180257281,
  "created_at" : "2015-04-26 16:45:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHCD",
      "indices" : [ 62, 67 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/5ShwiopHcq",
      "expanded_url" : "http:\/\/snpy.tv\/1JG7OvR",
      "display_url" : "snpy.tv\/1JG7OvR"
    } ]
  },
  "geo" : { },
  "id_str" : "592348529957478400",
  "text" : "President Obama and his anger translator, Luther.\nJust watch. #WHCD http:\/\/t.co\/5ShwiopHcq",
  "id" : 592348529957478400,
  "created_at" : "2015-04-26 15:24:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHCD",
      "indices" : [ 124, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "592168671251836929",
  "text" : "RT @WHLive: \"Thank you for your devotion to exercising our liberty, and to telling our American story.\" \u2014Obama to the press #WHCD http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHCD",
        "indices" : [ 112, 117 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/cr9ldYo0wz",
        "expanded_url" : "http:\/\/snpy.tv\/1JGcqlG",
        "display_url" : "snpy.tv\/1JGcqlG"
      } ]
    },
    "geo" : { },
    "id_str" : "592168637596704771",
    "text" : "\"Thank you for your devotion to exercising our liberty, and to telling our American story.\" \u2014Obama to the press #WHCD http:\/\/t.co\/cr9ldYo0wz",
    "id" : 592168637596704771,
    "created_at" : "2015-04-26 03:29:39 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 592168671251836929,
  "created_at" : "2015-04-26 03:29:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHCD",
      "indices" : [ 99, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/bRCjJGpQ0u",
      "expanded_url" : "http:\/\/snpy.tv\/1HFDUZT",
      "display_url" : "snpy.tv\/1HFDUZT"
    } ]
  },
  "geo" : { },
  "id_str" : "592163212717469698",
  "text" : "Full video: Watch President Obama's remarks at the White House Correspondents' Association Dinner. #WHCD http:\/\/t.co\/bRCjJGpQ0u",
  "id" : 592163212717469698,
  "created_at" : "2015-04-26 03:08:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHCD",
      "indices" : [ 57, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/5ShwiopHcq",
      "expanded_url" : "http:\/\/snpy.tv\/1JG7OvR",
      "display_url" : "snpy.tv\/1JG7OvR"
    } ]
  },
  "geo" : { },
  "id_str" : "592159085673455616",
  "text" : "Have you met Luther, President Obama's anger translator? #WHCD http:\/\/t.co\/5ShwiopHcq",
  "id" : 592159085673455616,
  "created_at" : "2015-04-26 02:51:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/592153221163917313\/photo\/1",
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/bL6M13pzSg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDfAFReWEAEyakZ.jpg",
      "id_str" : "592153072845066241",
      "id" : 592153072845066241,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDfAFReWEAEyakZ.jpg",
      "sizes" : [ {
        "h" : 333,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 569,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 189,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 569,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/bL6M13pzSg"
    } ],
    "hashtags" : [ {
      "text" : "WHCD",
      "indices" : [ 37, 42 ]
    } ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/bLXImBTejs",
      "expanded_url" : "http:\/\/go.wh.gov\/WHCD",
      "display_url" : "go.wh.gov\/WHCD"
    } ]
  },
  "geo" : { },
  "id_str" : "592153221163917313",
  "text" : "POTUS lounge. http:\/\/t.co\/bLXImBTejs #WHCD http:\/\/t.co\/bL6M13pzSg",
  "id" : 592153221163917313,
  "created_at" : "2015-04-26 02:28:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/592152122130440193\/photo\/1",
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/EViNkabkOG",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CDe_A8YWgAE3Poh.png",
      "id_str" : "592151898951680001",
      "id" : 592151898951680001,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CDe_A8YWgAE3Poh.png",
      "sizes" : [ {
        "h" : 375,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/EViNkabkOG"
    } ],
    "hashtags" : [ {
      "text" : "WHCD",
      "indices" : [ 40, 45 ]
    } ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/bLXImBTejs",
      "expanded_url" : "http:\/\/go.wh.gov\/WHCD",
      "display_url" : "go.wh.gov\/WHCD"
    } ]
  },
  "geo" : { },
  "id_str" : "592152122130440193",
  "text" : "Beats by Barack. http:\/\/t.co\/bLXImBTejs #WHCD http:\/\/t.co\/EViNkabkOG",
  "id" : 592152122130440193,
  "created_at" : "2015-04-26 02:24:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHCD",
      "indices" : [ 88, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/bLXImBTejs",
      "expanded_url" : "http:\/\/go.wh.gov\/WHCD",
      "display_url" : "go.wh.gov\/WHCD"
    }, {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/zTMjeXfA70",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/d20aed53-132b-4643-a451-0f7e07b420b8",
      "display_url" : "amp.twimg.com\/v\/d20aed53-132\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "592151458314723328",
  "text" : "\"Welcome to the 4th quarter of my presidency.\" \u2014President Obama: http:\/\/t.co\/bLXImBTejs #WHCD\nhttps:\/\/t.co\/zTMjeXfA70",
  "id" : 592151458314723328,
  "created_at" : "2015-04-26 02:21:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHCD",
      "indices" : [ 114, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/bLXImBTejs",
      "expanded_url" : "http:\/\/go.wh.gov\/WHCD",
      "display_url" : "go.wh.gov\/WHCD"
    } ]
  },
  "geo" : { },
  "id_str" : "592151243029544960",
  "text" : "Watch live: President Obama speaks at the White House Correspondents' Association Dinner \u2192 http:\/\/t.co\/bLXImBTejs #WHCD",
  "id" : 592151243029544960,
  "created_at" : "2015-04-26 02:20:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Nepal",
      "indices" : [ 84, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "592086151298682880",
  "text" : "RT @NSCPress: The United States stands ready to assist the Government and people of #Nepal and the region further in this time of need",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Nepal",
        "indices" : [ 70, 76 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "592068476820414464",
    "text" : "The United States stands ready to assist the Government and people of #Nepal and the region further in this time of need",
    "id" : 592068476820414464,
    "created_at" : "2015-04-25 20:51:39 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 592086151298682880,
  "created_at" : "2015-04-25 22:01:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Nepal",
      "indices" : [ 73, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "592086111494766593",
  "text" : "RT @NSCPress: The US is deploying a team of disaster response experts to #Nepal and providing an initial $1 million in disaster relief assi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Nepal",
        "indices" : [ 59, 65 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "592068346797006849",
    "text" : "The US is deploying a team of disaster response experts to #Nepal and providing an initial $1 million in disaster relief assistance",
    "id" : 592068346797006849,
    "created_at" : "2015-04-25 20:51:08 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 592086111494766593,
  "created_at" : "2015-04-25 22:01:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TPP",
      "indices" : [ 135, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/7QArLMvpK1",
      "expanded_url" : "http:\/\/go.wh.gov\/HW8bVz",
      "display_url" : "go.wh.gov\/HW8bVz"
    } ]
  },
  "geo" : { },
  "id_str" : "592025334385545217",
  "text" : "\"If I didn\u2019t think this was the right thing to do for working families, I wouldn\u2019t be fighting for it.\" \u2014Obama: http:\/\/t.co\/7QArLMvpK1 #TPP",
  "id" : 592025334385545217,
  "created_at" : "2015-04-25 18:00:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    }, {
      "name" : "Hubble",
      "screen_name" : "NASA_Hubble",
      "indices" : [ 78, 90 ],
      "id_str" : "14091091",
      "id" : 14091091
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Hubble25",
      "indices" : [ 115, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/Uasgsri1SY",
      "expanded_url" : "http:\/\/go.nasa.gov\/1zZ83Nt",
      "display_url" : "go.nasa.gov\/1zZ83Nt"
    } ]
  },
  "geo" : { },
  "id_str" : "592010104272265216",
  "text" : "RT @NASA: President Obama congratulates the hard work of the men and women of @NASA_Hubble: http:\/\/t.co\/Uasgsri1SY #Hubble25 http:\/\/t.co\/1c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hubble",
        "screen_name" : "NASA_Hubble",
        "indices" : [ 68, 80 ],
        "id_str" : "14091091",
        "id" : 14091091
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/NASA\/status\/592006658232098816\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/1cz1PIfyaW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CDc66z_WMAApbvV.png",
        "id_str" : "592006658085236736",
        "id" : 592006658085236736,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDc66z_WMAApbvV.png",
        "sizes" : [ {
          "h" : 723,
          "resize" : "fit",
          "w" : 531
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 723,
          "resize" : "fit",
          "w" : 531
        }, {
          "h" : 723,
          "resize" : "fit",
          "w" : 531
        }, {
          "h" : 463,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/1cz1PIfyaW"
      } ],
      "hashtags" : [ {
        "text" : "Hubble25",
        "indices" : [ 105, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/Uasgsri1SY",
        "expanded_url" : "http:\/\/go.nasa.gov\/1zZ83Nt",
        "display_url" : "go.nasa.gov\/1zZ83Nt"
      } ]
    },
    "geo" : { },
    "id_str" : "592006658232098816",
    "text" : "President Obama congratulates the hard work of the men and women of @NASA_Hubble: http:\/\/t.co\/Uasgsri1SY #Hubble25 http:\/\/t.co\/1cz1PIfyaW",
    "id" : 592006658232098816,
    "created_at" : "2015-04-25 16:46:00 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 592010104272265216,
  "created_at" : "2015-04-25 16:59:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LeadOnTrade",
      "indices" : [ 126, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/7QArLMvpK1",
      "expanded_url" : "http:\/\/go.wh.gov\/HW8bVz",
      "display_url" : "go.wh.gov\/HW8bVz"
    } ]
  },
  "geo" : { },
  "id_str" : "592006430456090626",
  "text" : "\"When the playing field is level, nobody can beat us.\" \u2014Obama on why it's time to pass his trade deal: http:\/\/t.co\/7QArLMvpK1 #LeadOnTrade",
  "id" : 592006430456090626,
  "created_at" : "2015-04-25 16:45:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/7QArLMN18B",
      "expanded_url" : "http:\/\/go.wh.gov\/HW8bVz",
      "display_url" : "go.wh.gov\/HW8bVz"
    } ]
  },
  "geo" : { },
  "id_str" : "591988158348267520",
  "text" : "\"My entire presidency is about helping working families\" \u2014Obama on how his trade deal helps American workers: http:\/\/t.co\/7QArLMN18B",
  "id" : 591988158348267520,
  "created_at" : "2015-04-25 15:32:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "591740462874152960",
  "text" : "RT @vj44: Thank you, AG Holder. Because of you, the arc of the moral universe has been bent a little closer to justice. http:\/\/t.co\/up5vDSL\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TheJusticeDept\/status\/591730092222451712\/photo\/1",
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/up5vDSL3ui",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CDY_XgPWMAAUgzI.jpg",
        "id_str" : "591730074069643264",
        "id" : 591730074069643264,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDY_XgPWMAAUgzI.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 401,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 684,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1602,
          "resize" : "fit",
          "w" : 2400
        } ],
        "display_url" : "pic.twitter.com\/up5vDSL3ui"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "591738297749217280",
    "text" : "Thank you, AG Holder. Because of you, the arc of the moral universe has been bent a little closer to justice. http:\/\/t.co\/up5vDSL3ui",
    "id" : 591738297749217280,
    "created_at" : "2015-04-24 22:59:38 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 591740462874152960,
  "created_at" : "2015-04-24 23:08:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Nye",
      "screen_name" : "BillNye",
      "indices" : [ 47, 55 ],
      "id_str" : "37710752",
      "id" : 37710752
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/591709466548183041\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/Q318yffgpa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDYr5xcWgAIkDJt.jpg",
      "id_str" : "591708672570589186",
      "id" : 591708672570589186,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDYr5xcWgAIkDJt.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Q318yffgpa"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 100, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/WE2GJOQDbW",
      "expanded_url" : "https:\/\/youtu.be\/Xe5IiNCvFJA",
      "display_url" : "youtu.be\/Xe5IiNCvFJA"
    } ]
  },
  "geo" : { },
  "id_str" : "591709466548183041",
  "text" : "Don't miss President Obama's conversation with @BillNye on climate change \u2192 https:\/\/t.co\/WE2GJOQDbW #ActOnClimate http:\/\/t.co\/Q318yffgpa",
  "id" : 591709466548183041,
  "created_at" : "2015-04-24 21:05:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 100, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/RyN9RCpgtQ",
      "expanded_url" : "https:\/\/youtu.be\/3ujHZZSfnXY",
      "display_url" : "youtu.be\/3ujHZZSfnXY"
    } ]
  },
  "geo" : { },
  "id_str" : "591685883083886592",
  "text" : "RT if you agree: It's time to mobilize the world to combat climate change \u2192 https:\/\/t.co\/RyN9RCpgtQ #ActOnClimate",
  "id" : 591685883083886592,
  "created_at" : "2015-04-24 19:31:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HonoringVets",
      "indices" : [ 112, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/TVB6XvYoJ5",
      "expanded_url" : "http:\/\/bit.ly\/1Fkxq2h",
      "display_url" : "bit.ly\/1Fkxq2h"
    } ]
  },
  "geo" : { },
  "id_str" : "591677448938369024",
  "text" : "RT @FLOTUS: RT if you agree: Everyone who has served America deserves a home in America: http:\/\/t.co\/TVB6XvYoJ5 #HonoringVets",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HonoringVets",
        "indices" : [ 100, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/TVB6XvYoJ5",
        "expanded_url" : "http:\/\/bit.ly\/1Fkxq2h",
        "display_url" : "bit.ly\/1Fkxq2h"
      } ]
    },
    "geo" : { },
    "id_str" : "591673902310543360",
    "text" : "RT if you agree: Everyone who has served America deserves a home in America: http:\/\/t.co\/TVB6XvYoJ5 #HonoringVets",
    "id" : 591673902310543360,
    "created_at" : "2015-04-24 18:43:45 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 591677448938369024,
  "created_at" : "2015-04-24 18:57:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Nye",
      "screen_name" : "BillNye",
      "indices" : [ 3, 11 ],
      "id_str" : "37710752",
      "id" : 37710752
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 116, 127 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EarthDay",
      "indices" : [ 16, 25 ]
    }, {
      "text" : "ClimateChange",
      "indices" : [ 58, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "591673349266354176",
  "text" : "RT @BillNye: On #EarthDay The President &amp; I discussed #ClimateChange in Florida. See the full video here on the @WhiteHouse blog. https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 103, 114 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EarthDay",
        "indices" : [ 3, 12 ]
      }, {
        "text" : "ClimateChange",
        "indices" : [ 45, 59 ]
      } ],
      "urls" : [ {
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/a8bONtctfg",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/blog\/2015\/04\/22\/follow-along-earth-day-2015",
        "display_url" : "whitehouse.gov\/blog\/2015\/04\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "591669222276767745",
    "text" : "On #EarthDay The President &amp; I discussed #ClimateChange in Florida. See the full video here on the @WhiteHouse blog. https:\/\/t.co\/a8bONtctfg",
    "id" : 591669222276767745,
    "created_at" : "2015-04-24 18:25:09 +0000",
    "user" : {
      "name" : "Bill Nye",
      "screen_name" : "BillNye",
      "protected" : false,
      "id_str" : "37710752",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606232291438829568\/8liw3txV_normal.jpg",
      "id" : 37710752,
      "verified" : true
    }
  },
  "id" : 591673349266354176,
  "created_at" : "2015-04-24 18:41:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Nye",
      "screen_name" : "BillNye",
      "indices" : [ 20, 28 ],
      "id_str" : "37710752",
      "id" : 37710752
    }, {
      "name" : "Everglades Natl Park",
      "screen_name" : "EvergladesNPS",
      "indices" : [ 70, 84 ],
      "id_str" : "63966574",
      "id" : 63966574
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 117, 130 ]
    }, {
      "text" : "EarthDay",
      "indices" : [ 131, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/WE2GJOQDbW",
      "expanded_url" : "https:\/\/youtu.be\/Xe5IiNCvFJA",
      "display_url" : "youtu.be\/Xe5IiNCvFJA"
    } ]
  },
  "geo" : { },
  "id_str" : "591669134133501953",
  "text" : "President Obama and @BillNye.\nTalking science.\nAnd climate change.\nIn @EvergladesNPS.\nWatch: https:\/\/t.co\/WE2GJOQDbW\n#ActOnClimate #EarthDay",
  "id" : 591669134133501953,
  "created_at" : "2015-04-24 18:24:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "591660525265752064",
  "text" : "RT @VP: By the end of the decade, we need:\n\u2713 1.3 million IT jobs\n\u2713 600,000 nurses\n\u2713 100,000 high skilled manufacturing jobs\nhttps:\/\/t.co\/XL\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/XLno6ZfiS8",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/the-press-office\/2015\/04\/24\/fact-sheet-administration-announces-new-commitments-support-president--0",
        "display_url" : "whitehouse.gov\/the-press-offi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "591659168869777410",
    "text" : "By the end of the decade, we need:\n\u2713 1.3 million IT jobs\n\u2713 600,000 nurses\n\u2713 100,000 high skilled manufacturing jobs\nhttps:\/\/t.co\/XLno6ZfiS8",
    "id" : 591659168869777410,
    "created_at" : "2015-04-24 17:45:13 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 591660525265752064,
  "created_at" : "2015-04-24 17:50:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/591645191620206596\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/VBVEUWS6rk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDXyEY0WAAEOlme.jpg",
      "id_str" : "591645083264483329",
      "id" : 591645083264483329,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDXyEY0WAAEOlme.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/VBVEUWS6rk"
    } ],
    "hashtags" : [ {
      "text" : "LeadOnTrade",
      "indices" : [ 101, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "591645191620206596",
  "text" : "This isn't your mom's or dad's trade deal.\nPresident Obama's trade agreement would help our workers. #LeadOnTrade http:\/\/t.co\/VBVEUWS6rk",
  "id" : 591645191620206596,
  "created_at" : "2015-04-24 16:49:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hubble",
      "screen_name" : "NASA_Hubble",
      "indices" : [ 3, 15 ],
      "id_str" : "14091091",
      "id" : 14091091
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/NASA_Hubble\/status\/591602500769226753\/photo\/1",
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/xSUxTseANG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDHmchSUsAE4Hou.jpg",
      "id_str" : "590506403808194561",
      "id" : 590506403808194561,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDHmchSUsAE4Hou.jpg",
      "sizes" : [ {
        "h" : 710,
        "resize" : "fit",
        "w" : 946
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 710,
        "resize" : "fit",
        "w" : 946
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/xSUxTseANG"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "591634218377031680",
  "text" : "RT @NASA_Hubble: Happy Birthday Hubble! http:\/\/t.co\/xSUxTseANG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NASA_Hubble\/status\/591602500769226753\/photo\/1",
        "indices" : [ 23, 45 ],
        "url" : "http:\/\/t.co\/xSUxTseANG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CDHmchSUsAE4Hou.jpg",
        "id_str" : "590506403808194561",
        "id" : 590506403808194561,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDHmchSUsAE4Hou.jpg",
        "sizes" : [ {
          "h" : 710,
          "resize" : "fit",
          "w" : 946
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 710,
          "resize" : "fit",
          "w" : 946
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/xSUxTseANG"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "591602500769226753",
    "text" : "Happy Birthday Hubble! http:\/\/t.co\/xSUxTseANG",
    "id" : 591602500769226753,
    "created_at" : "2015-04-24 14:00:02 +0000",
    "user" : {
      "name" : "Hubble",
      "screen_name" : "NASA_Hubble",
      "protected" : false,
      "id_str" : "14091091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468011581\/efb985f24af0a814a722457a768f3cc5_normal.jpeg",
      "id" : 14091091,
      "verified" : true
    }
  },
  "id" : 591634218377031680,
  "created_at" : "2015-04-24 16:06:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "indices" : [ 3, 11 ],
      "id_str" : "2382117350",
      "id" : 2382117350
    }, {
      "name" : "Redwood N&S Parks",
      "screen_name" : "RedwoodNPS",
      "indices" : [ 75, 86 ],
      "id_str" : "117874971",
      "id" : 117874971
    }, {
      "name" : "Zion National Park",
      "screen_name" : "ZionNPS",
      "indices" : [ 98, 106 ],
      "id_str" : "44984439",
      "id" : 44984439
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FindYourPark",
      "indices" : [ 32, 45 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/sLoz2XsfiI",
      "expanded_url" : "https:\/\/www.whitehouse.gov\/blog\/2015\/04\/20\/forrest-gump-star-wars-10-national-parks-who-played-role-your-favorite-movies",
      "display_url" : "whitehouse.gov\/blog\/2015\/04\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "591629887695228930",
  "text" : "RT @Deese44: You may be able to #FindYourPark in your fav movie\u2014from Ewoks @RedwoodNPS to outlaws @ZionNPS\nhttps:\/\/t.co\/sLoz2XsfiI http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Redwood N&S Parks",
        "screen_name" : "RedwoodNPS",
        "indices" : [ 62, 73 ],
        "id_str" : "117874971",
        "id" : 117874971
      }, {
        "name" : "Zion National Park",
        "screen_name" : "ZionNPS",
        "indices" : [ 85, 93 ],
        "id_str" : "44984439",
        "id" : 44984439
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Deese44\/status\/591626338999480321\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/CtoopHxCmc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CDXgx-gWEAENcLh.png",
        "id_str" : "591626075265961985",
        "id" : 591626075265961985,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDXgx-gWEAENcLh.png",
        "sizes" : [ {
          "h" : 540,
          "resize" : "fit",
          "w" : 709
        }, {
          "h" : 259,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 540,
          "resize" : "fit",
          "w" : 709
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 457,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/CtoopHxCmc"
      } ],
      "hashtags" : [ {
        "text" : "FindYourPark",
        "indices" : [ 19, 32 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/sLoz2XsfiI",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/blog\/2015\/04\/20\/forrest-gump-star-wars-10-national-parks-who-played-role-your-favorite-movies",
        "display_url" : "whitehouse.gov\/blog\/2015\/04\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "591626338999480321",
    "text" : "You may be able to #FindYourPark in your fav movie\u2014from Ewoks @RedwoodNPS to outlaws @ZionNPS\nhttps:\/\/t.co\/sLoz2XsfiI http:\/\/t.co\/CtoopHxCmc",
    "id" : 591626338999480321,
    "created_at" : "2015-04-24 15:34:45 +0000",
    "user" : {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "protected" : false,
      "id_str" : "2382117350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656551411145027584\/ArrSlGUP_normal.jpg",
      "id" : 2382117350,
      "verified" : true
    }
  },
  "id" : 591629887695228930,
  "created_at" : "2015-04-24 15:48:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/3mObpyn9jP",
      "expanded_url" : "http:\/\/snpy.tv\/1HtNaSg",
      "display_url" : "snpy.tv\/1HtNaSg"
    } ]
  },
  "geo" : { },
  "id_str" : "591623630511071234",
  "text" : "\"The Chamber of Commerce didn\u2019t elect me twice, working folks did.\" \u2014Obama on how his trade deal benefits our workers http:\/\/t.co\/3mObpyn9jP",
  "id" : 591623630511071234,
  "created_at" : "2015-04-24 15:24:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/eWthiLLjEf",
      "expanded_url" : "http:\/\/snpy.tv\/1GnGIJA",
      "display_url" : "snpy.tv\/1GnGIJA"
    } ]
  },
  "geo" : { },
  "id_str" : "591613851650678785",
  "text" : "\"It is the most progressive trade agreement in our history\" \u2014Obama on why his trade deal is good for American workers http:\/\/t.co\/eWthiLLjEf",
  "id" : 591613851650678785,
  "created_at" : "2015-04-24 14:45:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "DC CFSA",
      "screen_name" : "DCCFSA",
      "indices" : [ 127, 134 ],
      "id_str" : "1598831328",
      "id" : 1598831328
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DaughtersAndSons",
      "indices" : [ 96, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "591609722924445696",
  "text" : "RT @PressSec: I expect great things from you, Leema &amp; Tyron! Thx for joining us on Take Our #DaughtersAndSons to Work Day! @DCCFSA http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "DC CFSA",
        "screen_name" : "DCCFSA",
        "indices" : [ 113, 120 ],
        "id_str" : "1598831328",
        "id" : 1598831328
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PressSec\/status\/591604155535396864\/photo\/1",
        "indices" : [ 121, 143 ],
        "url" : "http:\/\/t.co\/Y9RjEykEYD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CDXM19dUkAAs4Z8.png",
        "id_str" : "591604153471766528",
        "id" : 591604153471766528,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDXM19dUkAAs4Z8.png",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1632,
          "resize" : "fit",
          "w" : 1224
        } ],
        "display_url" : "pic.twitter.com\/Y9RjEykEYD"
      } ],
      "hashtags" : [ {
        "text" : "DaughtersAndSons",
        "indices" : [ 82, 99 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "591604155535396864",
    "text" : "I expect great things from you, Leema &amp; Tyron! Thx for joining us on Take Our #DaughtersAndSons to Work Day! @DCCFSA http:\/\/t.co\/Y9RjEykEYD",
    "id" : 591604155535396864,
    "created_at" : "2015-04-24 14:06:36 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 591609722924445696,
  "created_at" : "2015-04-24 14:28:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 115, 126 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DaughtersAndSons",
      "indices" : [ 27, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "591441792115019776",
  "text" : "RT @FLOTUS: Happy Take Our #DaughtersAndSons to Work Day! This young girl celebrated by learning about life at the @WhiteHouse. http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 103, 114 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/591426352244346880\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/q3aJM9cnkR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CDUl-fHWAAArZtD.jpg",
        "id_str" : "591420681503506432",
        "id" : 591420681503506432,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDUl-fHWAAArZtD.jpg",
        "sizes" : [ {
          "h" : 2253,
          "resize" : "fit",
          "w" : 2800
        }, {
          "h" : 824,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 274,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 483,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/q3aJM9cnkR"
      } ],
      "hashtags" : [ {
        "text" : "DaughtersAndSons",
        "indices" : [ 15, 32 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "591426352244346880",
    "text" : "Happy Take Our #DaughtersAndSons to Work Day! This young girl celebrated by learning about life at the @WhiteHouse. http:\/\/t.co\/q3aJM9cnkR",
    "id" : 591426352244346880,
    "created_at" : "2015-04-24 02:20:05 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 591441792115019776,
  "created_at" : "2015-04-24 03:21:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Nye",
      "screen_name" : "BillNye",
      "indices" : [ 3, 11 ],
      "id_str" : "37710752",
      "id" : 37710752
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 119, 130 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ClimateChange",
      "indices" : [ 67, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "591391681632579584",
  "text" : "RT @BillNye: The President &amp; I went to FL yesterday to discuss #ClimateChange. Get a sneak peek here thanks to the @WhiteHouse https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 106, 117 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ClimateChange",
        "indices" : [ 54, 68 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 141 ],
        "url" : "https:\/\/t.co\/4g11ySpOmJ",
        "expanded_url" : "https:\/\/www.facebook.com\/billnye",
        "display_url" : "facebook.com\/billnye"
      } ]
    },
    "geo" : { },
    "id_str" : "591391031993720832",
    "text" : "The President &amp; I went to FL yesterday to discuss #ClimateChange. Get a sneak peek here thanks to the @WhiteHouse https:\/\/t.co\/4g11ySpOmJ",
    "id" : 591391031993720832,
    "created_at" : "2015-04-23 23:59:44 +0000",
    "user" : {
      "name" : "Bill Nye",
      "screen_name" : "BillNye",
      "protected" : false,
      "id_str" : "37710752",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606232291438829568\/8liw3txV_normal.jpg",
      "id" : 37710752,
      "verified" : true
    }
  },
  "id" : 591391681632579584,
  "created_at" : "2015-04-24 00:02:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/591372052927479809\/photo\/1",
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/LIacXortsj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDT5pvdWYAA4Qal.jpg",
      "id_str" : "591371946601897984",
      "id" : 591371946601897984,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDT5pvdWYAA4Qal.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/LIacXortsj"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 43, 56 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/OhzHhafyzD",
      "expanded_url" : "http:\/\/go.wh.gov\/EUSU2s",
      "display_url" : "go.wh.gov\/EUSU2s"
    } ]
  },
  "geo" : { },
  "id_str" : "591372052927479809",
  "text" : "Here's how we're helping America's farmers #ActOnClimate \u2192 http:\/\/t.co\/OhzHhafyzD http:\/\/t.co\/LIacXortsj",
  "id" : 591372052927479809,
  "created_at" : "2015-04-23 22:44:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/591356138857353216\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/xv3CiMnkx3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDTrMUqWIAAqy-X.jpg",
      "id_str" : "591356048029655040",
      "id" : 591356048029655040,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDTrMUqWIAAqy-X.jpg",
      "sizes" : [ {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/xv3CiMnkx3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "591356138857353216",
  "text" : "\"I wanted to make sure my life attached itself to giving people a chance at opportunity.\" \u2014President Obama http:\/\/t.co\/xv3CiMnkx3",
  "id" : 591356138857353216,
  "created_at" : "2015-04-23 21:41:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LeadOnTrade",
      "indices" : [ 115, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "591353351473790976",
  "text" : "RT @WHLive: \"It\u2019s got strong provisions for workers, and strong provisions for the environment.\" \u2014Obama on the TPP #LeadOnTrade http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WHLive\/status\/591353160255418368\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/SknrkW1aLZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CDTojHaWYAIlXqG.jpg",
        "id_str" : "591353141075009538",
        "id" : 591353141075009538,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDTojHaWYAIlXqG.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/SknrkW1aLZ"
      } ],
      "hashtags" : [ {
        "text" : "LeadOnTrade",
        "indices" : [ 103, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "591353160255418368",
    "text" : "\"It\u2019s got strong provisions for workers, and strong provisions for the environment.\" \u2014Obama on the TPP #LeadOnTrade http:\/\/t.co\/SknrkW1aLZ",
    "id" : 591353160255418368,
    "created_at" : "2015-04-23 21:29:14 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 591353351473790976,
  "created_at" : "2015-04-23 21:30:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/591352882177249280\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/L9Hc2UrGAr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDToSSLWIAAhOkf.jpg",
      "id_str" : "591352851907092480",
      "id" : 591352851907092480,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDToSSLWIAAhOkf.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/L9Hc2UrGAr"
    } ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 95, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "591352882177249280",
  "text" : "\"When the playing field is level, nobody beats the United States of America.\" \u2014President Obama #MadeInAmerica http:\/\/t.co\/L9Hc2UrGAr",
  "id" : 591352882177249280,
  "created_at" : "2015-04-23 21:28:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/591352308161650689\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/nZDFHT1CNZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDTnw2rWMAADOai.jpg",
      "id_str" : "591352277589438464",
      "id" : 591352277589438464,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDTnw2rWMAADOai.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/nZDFHT1CNZ"
    } ],
    "hashtags" : [ {
      "text" : "LeadOnTrade",
      "indices" : [ 103, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "591352308161650689",
  "text" : "\"Jobs at businesses that export are good, middle-class jobs that on average pay more\" \u2014President Obama #LeadOnTrade http:\/\/t.co\/nZDFHT1CNZ",
  "id" : 591352308161650689,
  "created_at" : "2015-04-23 21:25:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/591352020478529536\/photo\/1",
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/FSEPHOmYjv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDTngIDWEAAu7IS.jpg",
      "id_str" : "591351990195720192",
      "id" : 591351990195720192,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDTngIDWEAAu7IS.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/FSEPHOmYjv"
    } ],
    "hashtags" : [ {
      "text" : "LeadOnTrade",
      "indices" : [ 73, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "591352020478529536",
  "text" : "\"95% of the world\u2019s consumers are outside our borders.\" \u2014President Obama #LeadOnTrade http:\/\/t.co\/FSEPHOmYjv",
  "id" : 591352020478529536,
  "created_at" : "2015-04-23 21:24:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LeadOnTrade",
      "indices" : [ 111, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "591351678659469312",
  "text" : "\u201CAmerica needs to write the rules of the global economy. We can\u2019t leave it to somebody else.\u201D \u2014President Obama #LeadOnTrade",
  "id" : 591351678659469312,
  "created_at" : "2015-04-23 21:23:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/591350876331237377\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/a5mZ7WSF6b",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDTmbXRW4AEwP8d.jpg",
      "id_str" : "591350808870051841",
      "id" : 591350808870051841,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDTmbXRW4AEwP8d.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/a5mZ7WSF6b"
    } ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 103, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "591350876331237377",
  "text" : "\"Today, more than 16 million Americans have gained the security of health insurance.\" \u2014President Obama #ACAWorks http:\/\/t.co\/a5mZ7WSF6b",
  "id" : 591350876331237377,
  "created_at" : "2015-04-23 21:20:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/591350427813289984\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/JFVnsrW2N6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDTmEfaW0AAIEhJ.jpg",
      "id_str" : "591350415918288896",
      "id" : 591350415918288896,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDTmEfaW0AAIEhJ.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/JFVnsrW2N6"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "591350427813289984",
  "text" : "\"Over the past five years, our businesses have created more than 12 million new jobs.\" \u2014President Obama http:\/\/t.co\/JFVnsrW2N6",
  "id" : 591350427813289984,
  "created_at" : "2015-04-23 21:18:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LorettaLynch",
      "indices" : [ 24, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "591349928087183360",
  "text" : "\u201CI am very pleased that #LorettaLynch has now been confirmed as America\u2019s next Attorney General.\u201D \u2014President Obama",
  "id" : 591349928087183360,
  "created_at" : "2015-04-23 21:16:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LeadOnTrade",
      "indices" : [ 117, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/qnilRtm8OM",
      "expanded_url" : "http:\/\/go.wh.gov\/4KX6xx",
      "display_url" : "go.wh.gov\/4KX6xx"
    } ]
  },
  "geo" : { },
  "id_str" : "591349237994094592",
  "text" : "Watch live: President Obama speaks on why his trade deal would be the most progressive ever \u2192 http:\/\/t.co\/qnilRtm8OM #LeadOnTrade",
  "id" : 591349237994094592,
  "created_at" : "2015-04-23 21:13:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ItsOnUs",
      "indices" : [ 114, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "591346058153709568",
  "text" : "RT @VP: RT if you agree: We all play a role in preventing sexual assault. Stand up. Speak out. Make a difference. #ItsOnUs http:\/\/t.co\/Wllf\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/591345190683725824\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/WllfYExBeO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CDThUGpUgAIzR_Z.jpg",
        "id_str" : "591345186589933570",
        "id" : 591345186589933570,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDThUGpUgAIzR_Z.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/WllfYExBeO"
      } ],
      "hashtags" : [ {
        "text" : "ItsOnUs",
        "indices" : [ 106, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "591345190683725824",
    "text" : "RT if you agree: We all play a role in preventing sexual assault. Stand up. Speak out. Make a difference. #ItsOnUs http:\/\/t.co\/WllfYExBeO",
    "id" : 591345190683725824,
    "created_at" : "2015-04-23 20:57:34 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 591346058153709568,
  "created_at" : "2015-04-23 21:01:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "indices" : [ 3, 11 ],
      "id_str" : "2382117350",
      "id" : 2382117350
    }, {
      "name" : "Medium",
      "screen_name" : "Medium",
      "indices" : [ 101, 108 ],
      "id_str" : "571202103",
      "id" : 571202103
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 44, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/Z9sbJFkrrh",
      "expanded_url" : "https:\/\/medium.com\/@Deese44\/here-s-how-we-re-helping-america-s-farmers-act-on-climate-e70b1e55d3b4",
      "display_url" : "medium.com\/@Deese44\/here-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "591328231103463424",
  "text" : "RT @Deese44: Ag sector stepping up today to #ActOnClimate = good for environment &amp; economy. Read @Medium https:\/\/t.co\/Z9sbJFkrrh http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Medium",
        "screen_name" : "Medium",
        "indices" : [ 88, 95 ],
        "id_str" : "571202103",
        "id" : 571202103
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Deese44\/status\/591314799201497089\/photo\/1",
        "indices" : [ 120, 142 ],
        "url" : "http:\/\/t.co\/n8OXanYB9g",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CDTFnOpWAAAh4XE.jpg",
        "id_str" : "591314728829452288",
        "id" : 591314728829452288,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDTFnOpWAAAh4XE.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/n8OXanYB9g"
      } ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 31, 44 ]
      } ],
      "urls" : [ {
        "indices" : [ 96, 119 ],
        "url" : "https:\/\/t.co\/Z9sbJFkrrh",
        "expanded_url" : "https:\/\/medium.com\/@Deese44\/here-s-how-we-re-helping-america-s-farmers-act-on-climate-e70b1e55d3b4",
        "display_url" : "medium.com\/@Deese44\/here-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "591314799201497089",
    "text" : "Ag sector stepping up today to #ActOnClimate = good for environment &amp; economy. Read @Medium https:\/\/t.co\/Z9sbJFkrrh http:\/\/t.co\/n8OXanYB9g",
    "id" : 591314799201497089,
    "created_at" : "2015-04-23 18:56:48 +0000",
    "user" : {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "protected" : false,
      "id_str" : "2382117350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656551411145027584\/ArrSlGUP_normal.jpg",
      "id" : 2382117350,
      "verified" : true
    }
  },
  "id" : 591328231103463424,
  "created_at" : "2015-04-23 19:50:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/591314437396688897\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/mTe4ic1Y8W",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDTFMx5XIAAdOCp.png",
      "id_str" : "591314274435407872",
      "id" : 591314274435407872,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDTFMx5XIAAdOCp.png",
      "sizes" : [ {
        "h" : 275,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 275,
        "resize" : "fit",
        "w" : 1025
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 91,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 161,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/mTe4ic1Y8W"
    } ],
    "hashtags" : [ {
      "text" : "LorettaLynch",
      "indices" : [ 37, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "591314437396688897",
  "text" : "\"Today, the Senate finally confirmed #LorettaLynch to be America\u2019s next Attorney General\" \u2014President Obama http:\/\/t.co\/mTe4ic1Y8W",
  "id" : 591314437396688897,
  "created_at" : "2015-04-23 18:55:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "New England Patriots",
      "screen_name" : "Patriots",
      "indices" : [ 64, 73 ],
      "id_str" : "31126587",
      "id" : 31126587
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/VN7QMSZsU0",
      "expanded_url" : "http:\/\/go.wh.gov\/bqjaRR",
      "display_url" : "go.wh.gov\/bqjaRR"
    } ]
  },
  "geo" : { },
  "id_str" : "591306898764345344",
  "text" : "RT @WHLive: \u201CGive it up for the Super Bowl Champion New England @Patriots!\" \u2014President Obama: http:\/\/t.co\/VN7QMSZsU0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "New England Patriots",
        "screen_name" : "Patriots",
        "indices" : [ 52, 61 ],
        "id_str" : "31126587",
        "id" : 31126587
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/VN7QMSZsU0",
        "expanded_url" : "http:\/\/go.wh.gov\/bqjaRR",
        "display_url" : "go.wh.gov\/bqjaRR"
      } ]
    },
    "geo" : { },
    "id_str" : "591306777515405314",
    "text" : "\u201CGive it up for the Super Bowl Champion New England @Patriots!\" \u2014President Obama: http:\/\/t.co\/VN7QMSZsU0",
    "id" : 591306777515405314,
    "created_at" : "2015-04-23 18:24:56 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 591306898764345344,
  "created_at" : "2015-04-23 18:25:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "New England Patriots",
      "screen_name" : "Patriots",
      "indices" : [ 71, 80 ],
      "id_str" : "31126587",
      "id" : 31126587
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/W5MF1lWIf4",
      "expanded_url" : "http:\/\/go.wh.gov\/bqjaRR",
      "display_url" : "go.wh.gov\/bqjaRR"
    } ]
  },
  "geo" : { },
  "id_str" : "591306513022636033",
  "text" : "Watch live: President Obama honors the Super Bowl Champion New England @Patriots \u2192 http:\/\/t.co\/W5MF1lWIf4",
  "id" : 591306513022636033,
  "created_at" : "2015-04-23 18:23:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Matt Hill",
      "screen_name" : "thematthill",
      "indices" : [ 9, 21 ],
      "id_str" : "235784044",
      "id" : 235784044
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ItsOnUs",
      "indices" : [ 118, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "591302491502948353",
  "text" : "RT @VP: .@TheMattHill You guys are awesome. And from one VP to another, let me just say you're doing a great job with #ItsOnUs. Keep it up!\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Matt Hill",
        "screen_name" : "thematthill",
        "indices" : [ 1, 13 ],
        "id_str" : "235784044",
        "id" : 235784044
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ItsOnUs",
        "indices" : [ 110, 118 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "591297301043351553",
    "geo" : { },
    "id_str" : "591302424431878145",
    "in_reply_to_user_id" : 235784044,
    "text" : ".@TheMattHill You guys are awesome. And from one VP to another, let me just say you're doing a great job with #ItsOnUs. Keep it up! \u2013VP",
    "id" : 591302424431878145,
    "in_reply_to_status_id" : 591297301043351553,
    "created_at" : "2015-04-23 18:07:38 +0000",
    "in_reply_to_screen_name" : "thematthill",
    "in_reply_to_user_id_str" : "235784044",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 591302491502948353,
  "created_at" : "2015-04-23 18:07:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kerry washington",
      "screen_name" : "kerrywashington",
      "indices" : [ 3, 19 ],
      "id_str" : "205302299",
      "id" : 205302299
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ItsOnUs",
      "indices" : [ 30, 38 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/CObiA2KEbX",
      "expanded_url" : "http:\/\/itsonus.org",
      "display_url" : "itsonus.org"
    } ]
  },
  "geo" : { },
  "id_str" : "591297630497550336",
  "text" : "RT @kerrywashington: Join the #ItsOnUs movement and sign up today! Let\u2019s act to prevent sexual assault. Visit http:\/\/t.co\/CObiA2KEbX http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/kerrywashington\/status\/591295870253019138\/photo\/1",
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/7mBjLrUKJm",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CDS0dOkWMAAuG9m.jpg",
        "id_str" : "591295865312129024",
        "id" : 591295865312129024,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDS0dOkWMAAuG9m.jpg",
        "sizes" : [ {
          "h" : 960,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/7mBjLrUKJm"
      } ],
      "hashtags" : [ {
        "text" : "ItsOnUs",
        "indices" : [ 9, 17 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/CObiA2KEbX",
        "expanded_url" : "http:\/\/itsonus.org",
        "display_url" : "itsonus.org"
      } ]
    },
    "geo" : { },
    "id_str" : "591295870253019138",
    "text" : "Join the #ItsOnUs movement and sign up today! Let\u2019s act to prevent sexual assault. Visit http:\/\/t.co\/CObiA2KEbX http:\/\/t.co\/7mBjLrUKJm",
    "id" : 591295870253019138,
    "created_at" : "2015-04-23 17:41:35 +0000",
    "user" : {
      "name" : "kerry washington",
      "screen_name" : "kerrywashington",
      "protected" : false,
      "id_str" : "205302299",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778641930536284160\/3-m-BwGQ_normal.jpg",
      "id" : 205302299,
      "verified" : true
    }
  },
  "id" : 591297630497550336,
  "created_at" : "2015-04-23 17:48:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Hawk",
      "screen_name" : "tonyhawk",
      "indices" : [ 3, 12 ],
      "id_str" : "21879024",
      "id" : 21879024
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 27, 30 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ItsOnUs",
      "indices" : [ 49, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "591291958242476032",
  "text" : "RT @tonyhawk: I stand with @VP in supporting the #ItsOnUs student-leaders across the country, helping end sexual assault. Pledge: http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 13, 16 ],
        "id_str" : "325830217",
        "id" : 325830217
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ItsOnUs",
        "indices" : [ 35, 43 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/p14VipOfAr",
        "expanded_url" : "http:\/\/itsonus.org",
        "display_url" : "itsonus.org"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 33.08282748168872, -117.2800224583061 ]
    },
    "id_str" : "591244111094493186",
    "text" : "I stand with @VP in supporting the #ItsOnUs student-leaders across the country, helping end sexual assault. Pledge: http:\/\/t.co\/p14VipOfAr",
    "id" : 591244111094493186,
    "created_at" : "2015-04-23 14:15:55 +0000",
    "user" : {
      "name" : "Tony Hawk",
      "screen_name" : "tonyhawk",
      "protected" : false,
      "id_str" : "21879024",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1325015260\/1979_driveway_fs_stink_normal.jpg",
      "id" : 21879024,
      "verified" : true
    }
  },
  "id" : 591291958242476032,
  "created_at" : "2015-04-23 17:26:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USTR",
      "screen_name" : "USTradeRep",
      "indices" : [ 3, 14 ],
      "id_str" : "44615672",
      "id" : 44615672
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/A1vrY5cr3J",
      "expanded_url" : "https:\/\/www.whitehouse.gov\/blog\/2015\/04\/22\/10-animals-president-s-trade-deal-will-help-protect-illegal-wildlife-trafficking",
      "display_url" : "whitehouse.gov\/blog\/2015\/04\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "591275240807763968",
  "text" : "RT @USTradeRep: 10 Animals the President\u2019s Trade Deal Will Help Protect from Illegal Wildlife Trafficking \u2192 https:\/\/t.co\/A1vrY5cr3J http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/USTradeRep\/status\/591270361519390720\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/9PEKToMl0k",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CDSImCcW4AEtEHU.png",
        "id_str" : "591247638164594689",
        "id" : 591247638164594689,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDSImCcW4AEtEHU.png",
        "sizes" : [ {
          "h" : 238,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 364,
          "resize" : "fit",
          "w" : 520
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 364,
          "resize" : "fit",
          "w" : 520
        }, {
          "h" : 364,
          "resize" : "fit",
          "w" : 520
        } ],
        "display_url" : "pic.twitter.com\/9PEKToMl0k"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/A1vrY5cr3J",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/blog\/2015\/04\/22\/10-animals-president-s-trade-deal-will-help-protect-illegal-wildlife-trafficking",
        "display_url" : "whitehouse.gov\/blog\/2015\/04\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "591270361519390720",
    "text" : "10 Animals the President\u2019s Trade Deal Will Help Protect from Illegal Wildlife Trafficking \u2192 https:\/\/t.co\/A1vrY5cr3J http:\/\/t.co\/9PEKToMl0k",
    "id" : 591270361519390720,
    "created_at" : "2015-04-23 16:00:14 +0000",
    "user" : {
      "name" : "USTR",
      "screen_name" : "USTradeRep",
      "protected" : false,
      "id_str" : "44615672",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662636758509596672\/O-ShXHZB_normal.png",
      "id" : 44615672,
      "verified" : true
    }
  },
  "id" : 591275240807763968,
  "created_at" : "2015-04-23 16:19:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ItsOnUs",
      "indices" : [ 37, 45 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/W5nDE72cu3",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=wNMZo31LziM",
      "display_url" : "youtube.com\/watch?v=wNMZo3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "591268899636776960",
  "text" : "RT @VP: Step up. Step in. Speak out. #ItsOnUs to help keep women and men safe from sexual assault. https:\/\/t.co\/W5nDE72cu3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ItsOnUs",
        "indices" : [ 29, 37 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/W5nDE72cu3",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=wNMZo31LziM",
        "display_url" : "youtube.com\/watch?v=wNMZo3\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "591259232047132672",
    "text" : "Step up. Step in. Speak out. #ItsOnUs to help keep women and men safe from sexual assault. https:\/\/t.co\/W5nDE72cu3",
    "id" : 591259232047132672,
    "created_at" : "2015-04-23 15:16:00 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 591268899636776960,
  "created_at" : "2015-04-23 15:54:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/Q45dNddEUs",
      "expanded_url" : "http:\/\/snpy.tv\/1Gmi1Qw",
      "display_url" : "snpy.tv\/1Gmi1Qw"
    } ]
  },
  "geo" : { },
  "id_str" : "591245575548338176",
  "text" : "Watch President Obama's statement on the deaths of Dr. Warren Weinstein and Giovanni Lo Porto. http:\/\/t.co\/Q45dNddEUs",
  "id" : 591245575548338176,
  "created_at" : "2015-04-23 14:21:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "591244523939889152",
  "text" : "\"We will continue to do everything we can to prevent the loss of innocent lives\u2026in our counterterrorism operations.\" \u2014President Obama",
  "id" : 591244523939889152,
  "created_at" : "2015-04-23 14:17:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/w0COl0TF29",
      "expanded_url" : "http:\/\/go.wh.gov\/b594XV",
      "display_url" : "go.wh.gov\/b594XV"
    } ]
  },
  "geo" : { },
  "id_str" : "591244285342789632",
  "text" : "\"We will identify the lessons that can be learned from this tragedy and any changes that should be made.\" \u2014Obama: http:\/\/t.co\/w0COl0TF29",
  "id" : 591244285342789632,
  "created_at" : "2015-04-23 14:16:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "591243950276542464",
  "text" : "\u201CI offer our deepest apologies to the families.\u201D \u2014President Obama to the families of Dr. Warren Weinstein and Giovanni Lo Porto",
  "id" : 591243950276542464,
  "created_at" : "2015-04-23 14:15:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/gOsq0AWf0I",
      "expanded_url" : "http:\/\/go.wh.gov\/1zLvvf",
      "display_url" : "go.wh.gov\/1zLvvf"
    } ]
  },
  "geo" : { },
  "id_str" : "591243844340953088",
  "text" : "\"As President and as Commander in Chief, I take full responsibility for our counterterrorism operations\" \u2014Obama: http:\/\/t.co\/gOsq0AWf0I",
  "id" : 591243844340953088,
  "created_at" : "2015-04-23 14:14:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/gOsq0AEE9a",
      "expanded_url" : "http:\/\/go.wh.gov\/1zLvvf",
      "display_url" : "go.wh.gov\/1zLvvf"
    } ]
  },
  "geo" : { },
  "id_str" : "591243199945039872",
  "text" : "Watch live: President Obama delivers a statement from the Briefing Room \u2192 http:\/\/t.co\/gOsq0AEE9a",
  "id" : 591243199945039872,
  "created_at" : "2015-04-23 14:12:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 17, 26 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/591236327699546113\/photo\/1",
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/aBLUm0lKE5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDR-Nd3WEAAkE4d.png",
      "id_str" : "591236220912537600",
      "id" : 591236220912537600,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDR-Nd3WEAAkE4d.png",
      "sizes" : [ {
        "h" : 176,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 311,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 545,
        "resize" : "fit",
        "w" : 1053
      }, {
        "h" : 530,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/aBLUm0lKE5"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/w0COl0TF29",
      "expanded_url" : "http:\/\/go.wh.gov\/b594XV",
      "display_url" : "go.wh.gov\/b594XV"
    } ]
  },
  "geo" : { },
  "id_str" : "591236327699546113",
  "text" : "Statement by the @PressSec on Dr. Warren Weinstein and Giovanni Lo Porto: http:\/\/t.co\/w0COl0TF29 http:\/\/t.co\/aBLUm0lKE5",
  "id" : 591236327699546113,
  "created_at" : "2015-04-23 13:44:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/gOsq0AWf0I",
      "expanded_url" : "http:\/\/go.wh.gov\/1zLvvf",
      "display_url" : "go.wh.gov\/1zLvvf"
    } ]
  },
  "geo" : { },
  "id_str" : "591234212935565313",
  "text" : "President Obama will deliver a statement from the White House Briefing Room at 10am ET. Watch here \u2192 http:\/\/t.co\/gOsq0AWf0I",
  "id" : 591234212935565313,
  "created_at" : "2015-04-23 13:36:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/591018899115745280\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/QFvFoPcvmy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDO4I0tWEAAsVkW.jpg",
      "id_str" : "591018437842964480",
      "id" : 591018437842964480,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDO4I0tWEAAsVkW.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/QFvFoPcvmy"
    } ],
    "hashtags" : [ {
      "text" : "EarthDay",
      "indices" : [ 92, 101 ]
    }, {
      "text" : "ActOnClimate",
      "indices" : [ 102, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "591018899115745280",
  "text" : "\"Protecting the one planet we\u2019ve got is what we have to do for the next generation.\" \u2014Obama #EarthDay #ActOnClimate http:\/\/t.co\/QFvFoPcvmy",
  "id" : 591018899115745280,
  "created_at" : "2015-04-22 23:21:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beth Cobert",
      "screen_name" : "OPMDirector",
      "indices" : [ 3, 15 ],
      "id_str" : "1736601720",
      "id" : 1736601720
    }, {
      "name" : "RockyNPS",
      "screen_name" : "RockyNPS",
      "indices" : [ 65, 74 ],
      "id_str" : "96783382",
      "id" : 96783382
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 111, 124 ]
    }, {
      "text" : "EarthDay",
      "indices" : [ 125, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/SqXZIXNAG8",
      "expanded_url" : "http:\/\/go.usa.gov\/3ZQG5",
      "display_url" : "go.usa.gov\/3ZQG5"
    } ]
  },
  "geo" : { },
  "id_str" : "591003848203960320",
  "text" : "RT @OPMDirector: A national park I'd fight to protect? Has to be @RockyNPS in Colorado: http:\/\/t.co\/SqXZIXNAG8 #ActOnClimate #EarthDay http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "RockyNPS",
        "screen_name" : "RockyNPS",
        "indices" : [ 48, 57 ],
        "id_str" : "96783382",
        "id" : 96783382
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/OPMDirector\/status\/591000497282228224\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/xVDUlVbDRF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CDOn0g9W0AEAQSw.jpg",
        "id_str" : "591000496757985281",
        "id" : 591000496757985281,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDOn0g9W0AEAQSw.jpg",
        "sizes" : [ {
          "h" : 398,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 530,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 225,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 530,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/xVDUlVbDRF"
      } ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 94, 107 ]
      }, {
        "text" : "EarthDay",
        "indices" : [ 108, 117 ]
      } ],
      "urls" : [ {
        "indices" : [ 71, 93 ],
        "url" : "http:\/\/t.co\/SqXZIXNAG8",
        "expanded_url" : "http:\/\/go.usa.gov\/3ZQG5",
        "display_url" : "go.usa.gov\/3ZQG5"
      } ]
    },
    "geo" : { },
    "id_str" : "591000497282228224",
    "text" : "A national park I'd fight to protect? Has to be @RockyNPS in Colorado: http:\/\/t.co\/SqXZIXNAG8 #ActOnClimate #EarthDay http:\/\/t.co\/xVDUlVbDRF",
    "id" : 591000497282228224,
    "created_at" : "2015-04-22 22:07:53 +0000",
    "user" : {
      "name" : "Beth Cobert",
      "screen_name" : "OPMDirector",
      "protected" : false,
      "id_str" : "1736601720",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/624273119298093056\/4dVQJJrr_normal.png",
      "id" : 1736601720,
      "verified" : true
    }
  },
  "id" : 591003848203960320,
  "created_at" : "2015-04-22 22:21:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Debbie Stabenow",
      "screen_name" : "stabenow",
      "indices" : [ 3, 12 ],
      "id_str" : "20113797",
      "id" : 20113797
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GreatLakes",
      "indices" : [ 54, 65 ]
    }, {
      "text" : "EarthDay",
      "indices" : [ 101, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "590996153438732288",
  "text" : "RT @stabenow: We need to work together to protect our #GreatLakes and our great Michigan outdoors on #EarthDay and every day http:\/\/t.co\/2b\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/stabenow\/status\/590926718522806272\/photo\/1",
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/2bUh3taNPI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CDNkuAmWMAEvYyc.jpg",
        "id_str" : "590926717713264641",
        "id" : 590926717713264641,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDNkuAmWMAEvYyc.jpg",
        "sizes" : [ {
          "h" : 250,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 441,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1058,
          "resize" : "fit",
          "w" : 1440
        }, {
          "h" : 752,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/2bUh3taNPI"
      } ],
      "hashtags" : [ {
        "text" : "GreatLakes",
        "indices" : [ 40, 51 ]
      }, {
        "text" : "EarthDay",
        "indices" : [ 87, 96 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "590926718522806272",
    "text" : "We need to work together to protect our #GreatLakes and our great Michigan outdoors on #EarthDay and every day http:\/\/t.co\/2bUh3taNPI",
    "id" : 590926718522806272,
    "created_at" : "2015-04-22 17:14:43 +0000",
    "user" : {
      "name" : "Debbie Stabenow",
      "screen_name" : "stabenow",
      "protected" : false,
      "id_str" : "20113797",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729686030484418561\/XC1VA0vM_normal.jpg",
      "id" : 20113797,
      "verified" : true
    }
  },
  "id" : 590996153438732288,
  "created_at" : "2015-04-22 21:50:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 66, 75 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/590989014557188096\/photo\/1",
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/j6hoDCB9Ak",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDOdU5rWMAA9wVJ.jpg",
      "id_str" : "590988958521241600",
      "id" : 590988958521241600,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDOdU5rWMAA9wVJ.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 842,
        "resize" : "fit",
        "w" : 748
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 842,
        "resize" : "fit",
        "w" : 748
      } ],
      "display_url" : "pic.twitter.com\/j6hoDCB9Ak"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/590989014557188096\/photo\/1",
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/j6hoDCB9Ak",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDOdU56WYAEMM3I.jpg",
      "id_str" : "590988958584168449",
      "id" : 590988958584168449,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDOdU56WYAEMM3I.jpg",
      "sizes" : [ {
        "h" : 850,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 850,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 385,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/j6hoDCB9Ak"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/590989014557188096\/photo\/1",
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/j6hoDCB9Ak",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDOdU6EWYAAZ8X1.jpg",
      "id_str" : "590988958626111488",
      "id" : 590988958626111488,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDOdU6EWYAAZ8X1.jpg",
      "sizes" : [ {
        "h" : 353,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 623,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 779,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 779,
        "resize" : "fit",
        "w" : 750
      } ],
      "display_url" : "pic.twitter.com\/j6hoDCB9Ak"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/590989014557188096\/photo\/1",
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/j6hoDCB9Ak",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDOdU6WWEAMUXFX.jpg",
      "id_str" : "590988958701588483",
      "id" : 590988958701588483,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDOdU6WWEAMUXFX.jpg",
      "sizes" : [ {
        "h" : 842,
        "resize" : "fit",
        "w" : 749
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 382,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 674,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 842,
        "resize" : "fit",
        "w" : 749
      } ],
      "display_url" : "pic.twitter.com\/j6hoDCB9Ak"
    } ],
    "hashtags" : [ {
      "text" : "EarthDay",
      "indices" : [ 38, 47 ]
    }, {
      "text" : "ActOnClimate",
      "indices" : [ 48, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "590991255984799744",
  "text" : "RT @vj44: These made me smile. Enjoy! #EarthDay #ActOnClimate cc: @Interior http:\/\/t.co\/j6hoDCB9Ak",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "US Dept of Interior",
        "screen_name" : "Interior",
        "indices" : [ 56, 65 ],
        "id_str" : "76348185",
        "id" : 76348185
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/590989014557188096\/photo\/1",
        "indices" : [ 66, 88 ],
        "url" : "http:\/\/t.co\/j6hoDCB9Ak",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CDOdU5rWMAA9wVJ.jpg",
        "id_str" : "590988958521241600",
        "id" : 590988958521241600,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDOdU5rWMAA9wVJ.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 842,
          "resize" : "fit",
          "w" : 748
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 842,
          "resize" : "fit",
          "w" : 748
        } ],
        "display_url" : "pic.twitter.com\/j6hoDCB9Ak"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/590989014557188096\/photo\/1",
        "indices" : [ 66, 88 ],
        "url" : "http:\/\/t.co\/j6hoDCB9Ak",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CDOdU56WYAEMM3I.jpg",
        "id_str" : "590988958584168449",
        "id" : 590988958584168449,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDOdU56WYAEMM3I.jpg",
        "sizes" : [ {
          "h" : 850,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 850,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 385,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/j6hoDCB9Ak"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/590989014557188096\/photo\/1",
        "indices" : [ 66, 88 ],
        "url" : "http:\/\/t.co\/j6hoDCB9Ak",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CDOdU6EWYAAZ8X1.jpg",
        "id_str" : "590988958626111488",
        "id" : 590988958626111488,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDOdU6EWYAAZ8X1.jpg",
        "sizes" : [ {
          "h" : 353,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 623,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 779,
          "resize" : "fit",
          "w" : 750
        }, {
          "h" : 779,
          "resize" : "fit",
          "w" : 750
        } ],
        "display_url" : "pic.twitter.com\/j6hoDCB9Ak"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/590989014557188096\/photo\/1",
        "indices" : [ 66, 88 ],
        "url" : "http:\/\/t.co\/j6hoDCB9Ak",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CDOdU6WWEAMUXFX.jpg",
        "id_str" : "590988958701588483",
        "id" : 590988958701588483,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDOdU6WWEAMUXFX.jpg",
        "sizes" : [ {
          "h" : 842,
          "resize" : "fit",
          "w" : 749
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 382,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 674,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 842,
          "resize" : "fit",
          "w" : 749
        } ],
        "display_url" : "pic.twitter.com\/j6hoDCB9Ak"
      } ],
      "hashtags" : [ {
        "text" : "EarthDay",
        "indices" : [ 28, 37 ]
      }, {
        "text" : "ActOnClimate",
        "indices" : [ 38, 51 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "590989014557188096",
    "text" : "These made me smile. Enjoy! #EarthDay #ActOnClimate cc: @Interior http:\/\/t.co\/j6hoDCB9Ak",
    "id" : 590989014557188096,
    "created_at" : "2015-04-22 21:22:15 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 590991255984799744,
  "created_at" : "2015-04-22 21:31:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "indices" : [ 3, 11 ],
      "id_str" : "2382117350",
      "id" : 2382117350
    }, {
      "name" : "McDonald's",
      "screen_name" : "McDonalds",
      "indices" : [ 64, 74 ],
      "id_str" : "71026122",
      "id" : 71026122
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 50, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "590981404290375680",
  "text" : "RT @Deese44: US companies continue stepping up to #ActOnClimate\u2014@McDonalds announces global supply-chain deforestation commitment: http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "McDonald's",
        "screen_name" : "McDonalds",
        "indices" : [ 51, 61 ],
        "id_str" : "71026122",
        "id" : 71026122
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Deese44\/status\/590969084990259201\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/iwonwDR96F",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CDN9iV5WYAAbs1v.png",
        "id_str" : "590954005062377472",
        "id" : 590954005062377472,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDN9iV5WYAAbs1v.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 252,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 439,
          "resize" : "fit",
          "w" : 592
        }, {
          "h" : 439,
          "resize" : "fit",
          "w" : 592
        }, {
          "h" : 439,
          "resize" : "fit",
          "w" : 592
        } ],
        "display_url" : "pic.twitter.com\/iwonwDR96F"
      } ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 37, 50 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "590969084990259201",
    "text" : "US companies continue stepping up to #ActOnClimate\u2014@McDonalds announces global supply-chain deforestation commitment: http:\/\/t.co\/iwonwDR96F",
    "id" : 590969084990259201,
    "created_at" : "2015-04-22 20:03:04 +0000",
    "user" : {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "protected" : false,
      "id_str" : "2382117350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656551411145027584\/ArrSlGUP_normal.jpg",
      "id" : 2382117350,
      "verified" : true
    }
  },
  "id" : 590981404290375680,
  "created_at" : "2015-04-22 20:52:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christy Goldfuss",
      "screen_name" : "Goldfuss44",
      "indices" : [ 3, 14 ],
      "id_str" : "2377561969",
      "id" : 2377561969
    }, {
      "name" : "Everglades Natl Park",
      "screen_name" : "EvergladesNPS",
      "indices" : [ 61, 75 ],
      "id_str" : "63966574",
      "id" : 63966574
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Goldfuss44\/status\/590960411240968192\/photo\/1",
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/dPDUGKKnIV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDODXKzVAAAqOLQ.jpg",
      "id_str" : "590960410175537152",
      "id" : 590960410175537152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDODXKzVAAAqOLQ.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/dPDUGKKnIV"
    } ],
    "hashtags" : [ {
      "text" : "EarthDay",
      "indices" : [ 19, 28 ]
    }, {
      "text" : "ActOnClimate",
      "indices" : [ 76, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "590976719189893120",
  "text" : "RT @Goldfuss44: On #EarthDay, President Obama greets kids at @EvergladesNPS #ActOnClimate http:\/\/t.co\/dPDUGKKnIV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Everglades Natl Park",
        "screen_name" : "EvergladesNPS",
        "indices" : [ 45, 59 ],
        "id_str" : "63966574",
        "id" : 63966574
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Goldfuss44\/status\/590960411240968192\/photo\/1",
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/dPDUGKKnIV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CDODXKzVAAAqOLQ.jpg",
        "id_str" : "590960410175537152",
        "id" : 590960410175537152,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDODXKzVAAAqOLQ.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/dPDUGKKnIV"
      } ],
      "hashtags" : [ {
        "text" : "EarthDay",
        "indices" : [ 3, 12 ]
      }, {
        "text" : "ActOnClimate",
        "indices" : [ 60, 73 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "590960411240968192",
    "text" : "On #EarthDay, President Obama greets kids at @EvergladesNPS #ActOnClimate http:\/\/t.co\/dPDUGKKnIV",
    "id" : 590960411240968192,
    "created_at" : "2015-04-22 19:28:36 +0000",
    "user" : {
      "name" : "Christy Goldfuss",
      "screen_name" : "Goldfuss44",
      "protected" : false,
      "id_str" : "2377561969",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/668926989940727809\/WeMBK__c_normal.jpg",
      "id" : 2377561969,
      "verified" : true
    }
  },
  "id" : 590976719189893120,
  "created_at" : "2015-04-22 20:33:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 63, 76 ]
    }, {
      "text" : "EarthDay",
      "indices" : [ 99, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/BEzMVn5oZ0",
      "expanded_url" : "http:\/\/snpy.tv\/1G88o2d",
      "display_url" : "snpy.tv\/1G88o2d"
    } ]
  },
  "geo" : { },
  "id_str" : "590964599727509505",
  "text" : "RT if you agree with President Obama: We owe it to our kids to #ActOnClimate before it's too late. #EarthDay http:\/\/t.co\/BEzMVn5oZ0",
  "id" : 590964599727509505,
  "created_at" : "2015-04-22 19:45:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/590961717653467136\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/JZyXzzYFHb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDOEe_LWgAIizaP.jpg",
      "id_str" : "590961644005654530",
      "id" : 590961644005654530,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDOEe_LWgAIizaP.jpg",
      "sizes" : [ {
        "h" : 1041,
        "resize" : "fit",
        "w" : 1041
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/JZyXzzYFHb"
    } ],
    "hashtags" : [ {
      "text" : "EarthDay",
      "indices" : [ 92, 101 ]
    }, {
      "text" : "ActOnClimate",
      "indices" : [ 102, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "590961717653467136",
  "text" : "\u201CProtecting the one planet we\u2019ve got is what we have to do for the next generation.\u201D \u2014Obama #EarthDay #ActOnClimate http:\/\/t.co\/JZyXzzYFHb",
  "id" : 590961717653467136,
  "created_at" : "2015-04-22 19:33:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/590961436689596419\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/9N2mshtx4n",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDOERlgWMAAVd0N.jpg",
      "id_str" : "590961413776093184",
      "id" : 590961413776093184,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDOERlgWMAAVd0N.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/9N2mshtx4n"
    } ],
    "hashtags" : [ {
      "text" : "EarthDay",
      "indices" : [ 90, 99 ]
    }, {
      "text" : "ActOnClimate",
      "indices" : [ 100, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "590961436689596419",
  "text" : "\"Refusing to say the words 'climate change' doesn\u2019t mean that it\u2019s not happening.\" \u2014Obama #EarthDay #ActOnClimate http:\/\/t.co\/9N2mshtx4n",
  "id" : 590961436689596419,
  "created_at" : "2015-04-22 19:32:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/590960889714647040\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/44Pt1EddoX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDODyI2WAAEkyJc.jpg",
      "id_str" : "590960873507782657",
      "id" : 590960873507782657,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDODyI2WAAEkyJc.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/44Pt1EddoX"
    } ],
    "hashtags" : [ {
      "text" : "EarthDay",
      "indices" : [ 105, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "590960889714647040",
  "text" : "\"We\u2019ll give every 4th-grader in America...a pass good for free admission to all our public lands\" \u2014Obama #EarthDay http:\/\/t.co\/44Pt1EddoX",
  "id" : 590960889714647040,
  "created_at" : "2015-04-22 19:30:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/590960084840230912\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/ltlpIY5NcQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDODDX8W0AAQI2a.jpg",
      "id_str" : "590960070105681920",
      "id" : 590960070105681920,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDODDX8W0AAQI2a.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/ltlpIY5NcQ"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 90, 103 ]
    }, {
      "text" : "EarthDay",
      "indices" : [ 104, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "590960084840230912",
  "text" : "\"We generated 20 times more electricity from sunlight than we did in all of 2008.\" \u2014Obama #ActOnClimate #EarthDay http:\/\/t.co\/ltlpIY5NcQ",
  "id" : 590960084840230912,
  "created_at" : "2015-04-22 19:27:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/590959841700671489\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/8ns5L6fNC5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDOCzxjWMAA46LL.jpg",
      "id_str" : "590959802102198272",
      "id" : 590959802102198272,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDOCzxjWMAA46LL.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/8ns5L6fNC5"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 94, 107 ]
    }, {
      "text" : "EarthDay",
      "indices" : [ 108, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "590959841700671489",
  "text" : "\"We\u2019re using more clean energy than ever before. America is number one in wind power.\" \u2014Obama #ActOnClimate #EarthDay http:\/\/t.co\/8ns5L6fNC5",
  "id" : 590959841700671489,
  "created_at" : "2015-04-22 19:26:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ks44\/status\/590958819158597633\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/H50MOTIRns",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDOB6gzVAAATP4S.png",
      "id_str" : "590958818353283072",
      "id" : 590958818353283072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDOB6gzVAAATP4S.png",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 477,
        "resize" : "fit",
        "w" : 851
      }, {
        "h" : 336,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 477,
        "resize" : "fit",
        "w" : 851
      } ],
      "display_url" : "pic.twitter.com\/H50MOTIRns"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 94, 107 ]
    }, {
      "text" : "EarthDay",
      "indices" : [ 108, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "590959620262404096",
  "text" : "\"Climate change can no longer be denied\u2026and action can no longer be delayed\" \u2014President Obama #ActOnClimate #EarthDay http:\/\/t.co\/H50MOTIRns",
  "id" : 590959620262404096,
  "created_at" : "2015-04-22 19:25:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WHLive\/status\/590959104425861121\/photo\/1",
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/y697H3FDgB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDOCJfeW0AAJBUx.jpg",
      "id_str" : "590959075694923776",
      "id" : 590959075694923776,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDOCJfeW0AAJBUx.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/y697H3FDgB"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 77, 90 ]
    }, {
      "text" : "EarthDay",
      "indices" : [ 91, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "590959140819832832",
  "text" : "RT @WHLive: \"2014 was the planet\u2019s warmest year on record.\" \u2014President Obama #ActOnClimate #EarthDay http:\/\/t.co\/y697H3FDgB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WHLive\/status\/590959104425861121\/photo\/1",
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/y697H3FDgB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CDOCJfeW0AAJBUx.jpg",
        "id_str" : "590959075694923776",
        "id" : 590959075694923776,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDOCJfeW0AAJBUx.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/y697H3FDgB"
      } ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 65, 78 ]
      }, {
        "text" : "EarthDay",
        "indices" : [ 79, 88 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "590959104425861121",
    "text" : "\"2014 was the planet\u2019s warmest year on record.\" \u2014President Obama #ActOnClimate #EarthDay http:\/\/t.co\/y697H3FDgB",
    "id" : 590959104425861121,
    "created_at" : "2015-04-22 19:23:24 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 590959140819832832,
  "created_at" : "2015-04-22 19:23:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/590958956673105920\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/GlKoXWYRXs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDOCBFzWIAEyyoN.jpg",
      "id_str" : "590958931364683777",
      "id" : 590958931364683777,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDOCBFzWIAEyyoN.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/GlKoXWYRXs"
    } ],
    "hashtags" : [ {
      "text" : "EarthDay",
      "indices" : [ 82, 91 ]
    }, {
      "text" : "ActOnClimate",
      "indices" : [ 92, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "590958956673105920",
  "text" : "\u201CIf we don\u2019t act, there may not be an Everglades as we know it.\u201D \u2014President Obama #EarthDay #ActOnClimate http:\/\/t.co\/GlKoXWYRXs",
  "id" : 590958956673105920,
  "created_at" : "2015-04-22 19:22:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Everglades Natl Park",
      "screen_name" : "EvergladesNPS",
      "indices" : [ 65, 79 ],
      "id_str" : "63966574",
      "id" : 63966574
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/590958586077061120\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/KlvDvEscHh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDOBcXmW0AEIdcH.jpg",
      "id_str" : "590958300486881281",
      "id" : 590958300486881281,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDOBcXmW0AEIdcH.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 900
      } ],
      "display_url" : "pic.twitter.com\/KlvDvEscHh"
    } ],
    "hashtags" : [ {
      "text" : "EarthDay",
      "indices" : [ 104, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/DK9rdyKUQ4",
      "expanded_url" : "http:\/\/go.wh.gov\/EarthDay",
      "display_url" : "go.wh.gov\/EarthDay"
    } ]
  },
  "geo" : { },
  "id_str" : "590958586077061120",
  "text" : "\"This 1.5 million acres is unlike any place on Earth.\" \u2014Obama in @EvergladesNPS: http:\/\/t.co\/DK9rdyKUQ4 #EarthDay http:\/\/t.co\/KlvDvEscHh",
  "id" : 590958586077061120,
  "created_at" : "2015-04-22 19:21:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Everglades Natl Park",
      "screen_name" : "EvergladesNPS",
      "indices" : [ 106, 120 ],
      "id_str" : "63966574",
      "id" : 63966574
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EarthDay",
      "indices" : [ 40, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "590958073872781314",
  "text" : "\"I can\u2019t think of a better way to spend #EarthDay than in one of our nation\u2019s greatest natural treasures, @EvergladesNPS.\" \u2014President Obama",
  "id" : 590958073872781314,
  "created_at" : "2015-04-22 19:19:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Everglades Natl Park",
      "screen_name" : "EvergladesNPS",
      "indices" : [ 38, 52 ],
      "id_str" : "63966574",
      "id" : 63966574
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Goldman44\/status\/590942477865066496\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/ffhCb0NiDs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDNzCmLVEAAZzAX.jpg",
      "id_str" : "590942464560664576",
      "id" : 590942464560664576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDNzCmLVEAAZzAX.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/ffhCb0NiDs"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 68, 81 ]
    }, {
      "text" : "EarthDay",
      "indices" : [ 107, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/DK9rdyKUQ4",
      "expanded_url" : "http:\/\/go.wh.gov\/EarthDay",
      "display_url" : "go.wh.gov\/EarthDay"
    } ]
  },
  "geo" : { },
  "id_str" : "590957972009963520",
  "text" : "Watch live: President Obama speaks in @EvergladesNPS on the need to #ActOnClimate \u2192 http:\/\/t.co\/DK9rdyKUQ4 #EarthDay http:\/\/t.co\/ffhCb0NiDs",
  "id" : 590957972009963520,
  "created_at" : "2015-04-22 19:18:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Nye",
      "screen_name" : "BillNye",
      "indices" : [ 3, 11 ],
      "id_str" : "37710752",
      "id" : 37710752
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EarthDay",
      "indices" : [ 86, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "590956931575111681",
  "text" : "RT @BillNye: 14 of the 15 hottest yrs on record all occurred in this century. On this #EarthDay, and every day, let\u2019s remember that #Climat\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EarthDay",
        "indices" : [ 73, 82 ]
      }, {
        "text" : "ClimateChangeIsReal",
        "indices" : [ 119, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "590952385092198400",
    "text" : "14 of the 15 hottest yrs on record all occurred in this century. On this #EarthDay, and every day, let\u2019s remember that #ClimateChangeIsReal.",
    "id" : 590952385092198400,
    "created_at" : "2015-04-22 18:56:42 +0000",
    "user" : {
      "name" : "Bill Nye",
      "screen_name" : "BillNye",
      "protected" : false,
      "id_str" : "37710752",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606232291438829568\/8liw3txV_normal.jpg",
      "id" : 37710752,
      "verified" : true
    }
  },
  "id" : 590956931575111681,
  "created_at" : "2015-04-22 19:14:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NationalParkService",
      "screen_name" : "NatlParkService",
      "indices" : [ 3, 19 ],
      "id_str" : "36771809",
      "id" : 36771809
    }, {
      "name" : "Bill Nye",
      "screen_name" : "BillNye",
      "indices" : [ 43, 51 ],
      "id_str" : "37710752",
      "id" : 37710752
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ClimateChange",
      "indices" : [ 100, 114 ]
    }, {
      "text" : "EarthDay",
      "indices" : [ 127, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "590948670322909187",
  "text" : "RT @NatlParkService: President Obama &amp; @BillNye meeting w\/ 4th graders from Miami to talk about #ClimateChange in honor of #EarthDay! http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bill Nye",
        "screen_name" : "BillNye",
        "indices" : [ 22, 30 ],
        "id_str" : "37710752",
        "id" : 37710752
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NatlParkService\/status\/590946836862599169\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/tVE0SY3suV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CDN3BB8UIAAVyun.jpg",
        "id_str" : "590946835700654080",
        "id" : 590946835700654080,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDN3BB8UIAAVyun.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2322,
          "resize" : "fit",
          "w" : 4128
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/tVE0SY3suV"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/NatlParkService\/status\/590946836862599169\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/tVE0SY3suV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CDN2-_JVAAAGvfD.jpg",
        "id_str" : "590946800590192640",
        "id" : 590946800590192640,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDN2-_JVAAAGvfD.jpg",
        "sizes" : [ {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1632,
          "resize" : "fit",
          "w" : 1224
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/tVE0SY3suV"
      } ],
      "hashtags" : [ {
        "text" : "ClimateChange",
        "indices" : [ 79, 93 ]
      }, {
        "text" : "EarthDay",
        "indices" : [ 106, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "590946836862599169",
    "text" : "President Obama &amp; @BillNye meeting w\/ 4th graders from Miami to talk about #ClimateChange in honor of #EarthDay! http:\/\/t.co\/tVE0SY3suV",
    "id" : 590946836862599169,
    "created_at" : "2015-04-22 18:34:39 +0000",
    "user" : {
      "name" : "NationalParkService",
      "screen_name" : "NatlParkService",
      "protected" : false,
      "id_str" : "36771809",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2179200522\/NPS_SocialMediaProfilePic_Blue_normal.png",
      "id" : 36771809,
      "verified" : true
    }
  },
  "id" : 590948670322909187,
  "created_at" : "2015-04-22 18:41:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "indices" : [ 3, 13 ],
      "id_str" : "131144091",
      "id" : 131144091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "590943268680163329",
  "text" : "RT @Goldman44: Starting in Sept, every 4th grader gets free admission to our national parks. POTUS making his pitch in person. http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Goldman44\/status\/590942477865066496\/photo\/1",
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/AXrN8gOdg5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CDNzCmLVEAAZzAX.jpg",
        "id_str" : "590942464560664576",
        "id" : 590942464560664576,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDNzCmLVEAAZzAX.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/AXrN8gOdg5"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "590942477865066496",
    "text" : "Starting in Sept, every 4th grader gets free admission to our national parks. POTUS making his pitch in person. http:\/\/t.co\/AXrN8gOdg5",
    "id" : 590942477865066496,
    "created_at" : "2015-04-22 18:17:20 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 590943268680163329,
  "created_at" : "2015-04-22 18:20:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/590939383861248001\/photo\/1",
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/jQnq1YF07x",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDNwI4EW0AAKZhZ.jpg",
      "id_str" : "590939273907589120",
      "id" : 590939273907589120,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDNwI4EW0AAKZhZ.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/jQnq1YF07x"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 30, 43 ]
    }, {
      "text" : "EarthDay",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/aPWTyh38xF",
      "expanded_url" : "http:\/\/go.wh.gov\/climate-goal",
      "display_url" : "go.wh.gov\/climate-goal"
    } ]
  },
  "geo" : { },
  "id_str" : "590939383861248001",
  "text" : "RT if you agree: It's time to #ActOnClimate \u2192 http:\/\/t.co\/aPWTyh38xF #EarthDay http:\/\/t.co\/jQnq1YF07x",
  "id" : 590939383861248001,
  "created_at" : "2015-04-22 18:05:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Macy",
      "screen_name" : "DMacy2388",
      "indices" : [ 3, 13 ],
      "id_str" : "984154244",
      "id" : 984154244
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EarthDay2015",
      "indices" : [ 78, 91 ]
    }, {
      "text" : "protectnatureandwildlife",
      "indices" : [ 92, 117 ]
    }, {
      "text" : "ActOnClimate",
      "indices" : [ 118, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "590935440103989248",
  "text" : "RT @DMacy2388: Do whatever you can to help this beautiful world we call home. #EarthDay2015 #protectnatureandwildlife #ActOnClimate http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DMacy2388\/status\/590933872822525952\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/gi1qaUSsgu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CDNrOdkUMAAWLd9.jpg",
        "id_str" : "590933872314953728",
        "id" : 590933872314953728,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDNrOdkUMAAWLd9.jpg",
        "sizes" : [ {
          "h" : 1050,
          "resize" : "fit",
          "w" : 1680
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 213,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 375,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/gi1qaUSsgu"
      } ],
      "hashtags" : [ {
        "text" : "EarthDay2015",
        "indices" : [ 63, 76 ]
      }, {
        "text" : "protectnatureandwildlife",
        "indices" : [ 77, 102 ]
      }, {
        "text" : "ActOnClimate",
        "indices" : [ 103, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "590933872822525952",
    "text" : "Do whatever you can to help this beautiful world we call home. #EarthDay2015 #protectnatureandwildlife #ActOnClimate http:\/\/t.co\/gi1qaUSsgu",
    "id" : 590933872822525952,
    "created_at" : "2015-04-22 17:43:08 +0000",
    "user" : {
      "name" : "Daniel Macy",
      "screen_name" : "DMacy2388",
      "protected" : false,
      "id_str" : "984154244",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/675173333017739264\/0niVDCew_normal.jpg",
      "id" : 984154244,
      "verified" : false
    }
  },
  "id" : 590935440103989248,
  "created_at" : "2015-04-22 17:49:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouseostp\/status\/590933962760933377\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/2Pu7YivCC0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDNrTpbUMAAK5w3.png",
      "id_str" : "590933961397776384",
      "id" : 590933961397776384,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDNrTpbUMAAK5w3.png",
      "sizes" : [ {
        "h" : 514,
        "resize" : "fit",
        "w" : 995
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 310,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 514,
        "resize" : "fit",
        "w" : 995
      }, {
        "h" : 176,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/2Pu7YivCC0"
    } ],
    "hashtags" : [ {
      "text" : "EarthDay",
      "indices" : [ 26, 35 ]
    }, {
      "text" : "NASA",
      "indices" : [ 37, 42 ]
    }, {
      "text" : "WebbyAward",
      "indices" : [ 78, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/176txrYwcX",
      "expanded_url" : "http:\/\/bit.ly\/1ygcWpU",
      "display_url" : "bit.ly\/1ygcWpU"
    } ]
  },
  "geo" : { },
  "id_str" : "590934173633871872",
  "text" : "RT @whitehouseostp: Happy #EarthDay! #NASA's climate site is up for a \"green\" #WebbyAward! http:\/\/t.co\/176txrYwcX http:\/\/t.co\/2Pu7YivCC0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/whitehouseostp\/status\/590933962760933377\/photo\/1",
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/2Pu7YivCC0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CDNrTpbUMAAK5w3.png",
        "id_str" : "590933961397776384",
        "id" : 590933961397776384,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDNrTpbUMAAK5w3.png",
        "sizes" : [ {
          "h" : 514,
          "resize" : "fit",
          "w" : 995
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 310,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 514,
          "resize" : "fit",
          "w" : 995
        }, {
          "h" : 176,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/2Pu7YivCC0"
      } ],
      "hashtags" : [ {
        "text" : "EarthDay",
        "indices" : [ 6, 15 ]
      }, {
        "text" : "NASA",
        "indices" : [ 17, 22 ]
      }, {
        "text" : "WebbyAward",
        "indices" : [ 58, 69 ]
      } ],
      "urls" : [ {
        "indices" : [ 71, 93 ],
        "url" : "http:\/\/t.co\/176txrYwcX",
        "expanded_url" : "http:\/\/bit.ly\/1ygcWpU",
        "display_url" : "bit.ly\/1ygcWpU"
      } ]
    },
    "geo" : { },
    "id_str" : "590933962760933377",
    "text" : "Happy #EarthDay! #NASA's climate site is up for a \"green\" #WebbyAward! http:\/\/t.co\/176txrYwcX http:\/\/t.co\/2Pu7YivCC0",
    "id" : 590933962760933377,
    "created_at" : "2015-04-22 17:43:30 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 590934173633871872,
  "created_at" : "2015-04-22 17:44:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    }, {
      "name" : "NationalParkService",
      "screen_name" : "NatlParkService",
      "indices" : [ 39, 55 ],
      "id_str" : "36771809",
      "id" : 36771809
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Interior\/status\/590924434598453248\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/fYnNPzBv5g",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDNipFdWMAAlQxG.jpg",
      "id_str" : "590924434095091712",
      "id" : 590924434095091712,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDNipFdWMAAlQxG.jpg",
      "sizes" : [ {
        "h" : 993,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 678,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 397,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/fYnNPzBv5g"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "590926006967521280",
  "text" : "RT @Interior: Every dollar invested in @NatlParkService returns $10 to US economy. RT to spread the word! http:\/\/t.co\/fYnNPzBv5g",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NationalParkService",
        "screen_name" : "NatlParkService",
        "indices" : [ 25, 41 ],
        "id_str" : "36771809",
        "id" : 36771809
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Interior\/status\/590924434598453248\/photo\/1",
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/fYnNPzBv5g",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CDNipFdWMAAlQxG.jpg",
        "id_str" : "590924434095091712",
        "id" : 590924434095091712,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDNipFdWMAAlQxG.jpg",
        "sizes" : [ {
          "h" : 993,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 678,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 225,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 397,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/fYnNPzBv5g"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "590924434598453248",
    "text" : "Every dollar invested in @NatlParkService returns $10 to US economy. RT to spread the word! http:\/\/t.co\/fYnNPzBv5g",
    "id" : 590924434598453248,
    "created_at" : "2015-04-22 17:05:38 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 590926006967521280,
  "created_at" : "2015-04-22 17:11:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "indices" : [ 3, 10 ],
      "id_str" : "166252256",
      "id" : 166252256
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ENERGY\/status\/590913409757093888\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/5U4se1jQ3U",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDNYnYOW4AAOJUs.jpg",
      "id_str" : "590913409656479744",
      "id" : 590913409656479744,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDNYnYOW4AAOJUs.jpg",
      "sizes" : [ {
        "h" : 295,
        "resize" : "fit",
        "w" : 590
      }, {
        "h" : 295,
        "resize" : "fit",
        "w" : 590
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 295,
        "resize" : "fit",
        "w" : 590
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/5U4se1jQ3U"
    } ],
    "hashtags" : [ {
      "text" : "energy",
      "indices" : [ 43, 50 ]
    }, {
      "text" : "EarthDay",
      "indices" : [ 54, 63 ]
    }, {
      "text" : "MySmallAct",
      "indices" : [ 101, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/tUUwYiicZv",
      "expanded_url" : "http:\/\/bit.ly\/1HUVmtK",
      "display_url" : "bit.ly\/1HUVmtK"
    } ]
  },
  "geo" : { },
  "id_str" : "590924029604798464",
  "text" : "RT @ENERGY: WATCH: The importance of clean #energy on #EarthDay and every day http:\/\/t.co\/tUUwYiicZv #MySmallAct http:\/\/t.co\/5U4se1jQ3U",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/measuredvoice.com\/\" rel=\"nofollow\"\u003EMeasured Voice\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ENERGY\/status\/590913409757093888\/photo\/1",
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/5U4se1jQ3U",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CDNYnYOW4AAOJUs.jpg",
        "id_str" : "590913409656479744",
        "id" : 590913409656479744,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDNYnYOW4AAOJUs.jpg",
        "sizes" : [ {
          "h" : 295,
          "resize" : "fit",
          "w" : 590
        }, {
          "h" : 295,
          "resize" : "fit",
          "w" : 590
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 295,
          "resize" : "fit",
          "w" : 590
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/5U4se1jQ3U"
      } ],
      "hashtags" : [ {
        "text" : "energy",
        "indices" : [ 31, 38 ]
      }, {
        "text" : "EarthDay",
        "indices" : [ 42, 51 ]
      }, {
        "text" : "MySmallAct",
        "indices" : [ 89, 100 ]
      } ],
      "urls" : [ {
        "indices" : [ 66, 88 ],
        "url" : "http:\/\/t.co\/tUUwYiicZv",
        "expanded_url" : "http:\/\/bit.ly\/1HUVmtK",
        "display_url" : "bit.ly\/1HUVmtK"
      } ]
    },
    "geo" : { },
    "id_str" : "590913409757093888",
    "text" : "WATCH: The importance of clean #energy on #EarthDay and every day http:\/\/t.co\/tUUwYiicZv #MySmallAct http:\/\/t.co\/5U4se1jQ3U",
    "id" : 590913409757093888,
    "created_at" : "2015-04-22 16:21:50 +0000",
    "user" : {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "protected" : false,
      "id_str" : "166252256",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793425839694155781\/HRS6sfn4_normal.jpg",
      "id" : 166252256,
      "verified" : true
    }
  },
  "id" : 590924029604798464,
  "created_at" : "2015-04-22 17:04:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EarthDay",
      "indices" : [ 120, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "590920089823793154",
  "text" : "RT @VP: Let's act to ensure that the world we leave behind for our kids &amp; grandkids is better than how we found it. #EarthDay http:\/\/t.co\/H\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/590910277912109057\/photo\/1",
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/HejNMXNibF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CDNVxAZVEAAjL8J.jpg",
        "id_str" : "590910276523855872",
        "id" : 590910276523855872,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDNVxAZVEAAjL8J.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 2651,
          "resize" : "fit",
          "w" : 3977
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/HejNMXNibF"
      } ],
      "hashtags" : [ {
        "text" : "EarthDay",
        "indices" : [ 112, 121 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "590910277912109057",
    "text" : "Let's act to ensure that the world we leave behind for our kids &amp; grandkids is better than how we found it. #EarthDay http:\/\/t.co\/HejNMXNibF",
    "id" : 590910277912109057,
    "created_at" : "2015-04-22 16:09:23 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 590920089823793154,
  "created_at" : "2015-04-22 16:48:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Everglades Natl Park",
      "screen_name" : "EvergladesNPS",
      "indices" : [ 26, 40 ],
      "id_str" : "63966574",
      "id" : 63966574
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/590915580808466432\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/oUrprDmt90",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDNXc33W0AE2cc4.jpg",
      "id_str" : "590912129659752449",
      "id" : 590912129659752449,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDNXc33W0AE2cc4.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1466,
        "resize" : "fit",
        "w" : 2200
      } ],
      "display_url" : "pic.twitter.com\/oUrprDmt90"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 70, 83 ]
    }, {
      "text" : "EarthDay",
      "indices" : [ 108, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/DK9rdytjru",
      "expanded_url" : "http:\/\/go.wh.gov\/EarthDay",
      "display_url" : "go.wh.gov\/EarthDay"
    } ]
  },
  "geo" : { },
  "id_str" : "590915580808466432",
  "text" : "President Obama is in the @EvergladesNPS today to discuss the need to #ActOnClimate: http:\/\/t.co\/DK9rdytjru #EarthDay http:\/\/t.co\/oUrprDmt90",
  "id" : 590915580808466432,
  "created_at" : "2015-04-22 16:30:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "indices" : [ 3, 15 ],
      "id_str" : "369232105",
      "id" : 369232105
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EarthDay",
      "indices" : [ 22, 31 ]
    }, {
      "text" : "ActonClimate",
      "indices" : [ 44, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "590911194917134337",
  "text" : "RT @PAniskoff44: This #EarthDay I'm going 2 #ActonClimate so I can enjoy beautiful parks like this with my litte one for years to come http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PAniskoff44\/status\/590910405897158656\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/lGUX7rsuYh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CDNV4X6UMAANqFx.jpg",
        "id_str" : "590910403095310336",
        "id" : 590910403095310336,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDNV4X6UMAANqFx.jpg",
        "sizes" : [ {
          "h" : 639,
          "resize" : "fit",
          "w" : 636
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 603,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 342,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 639,
          "resize" : "fit",
          "w" : 636
        } ],
        "display_url" : "pic.twitter.com\/lGUX7rsuYh"
      } ],
      "hashtags" : [ {
        "text" : "EarthDay",
        "indices" : [ 5, 14 ]
      }, {
        "text" : "ActonClimate",
        "indices" : [ 27, 40 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "590910405897158656",
    "text" : "This #EarthDay I'm going 2 #ActonClimate so I can enjoy beautiful parks like this with my litte one for years to come http:\/\/t.co\/lGUX7rsuYh",
    "id" : 590910405897158656,
    "created_at" : "2015-04-22 16:09:54 +0000",
    "user" : {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "protected" : false,
      "id_str" : "369232105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623146355767140352\/58sqoVrw_normal.jpg",
      "id" : 369232105,
      "verified" : true
    }
  },
  "id" : 590911194917134337,
  "created_at" : "2015-04-22 16:13:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "acraftyone",
      "screen_name" : "ajcraft",
      "indices" : [ 3, 11 ],
      "id_str" : "83147551",
      "id" : 83147551
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ajcraft\/status\/590905761246498816\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/vJ2EHTDWlF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDNRpt9UkAElt2f.jpg",
      "id_str" : "590905753268948993",
      "id" : 590905753268948993,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDNRpt9UkAElt2f.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/vJ2EHTDWlF"
    } ],
    "hashtags" : [ {
      "text" : "EarthDay",
      "indices" : [ 19, 28 ]
    }, {
      "text" : "MountShasta",
      "indices" : [ 44, 56 ]
    }, {
      "text" : "ActOnClimate",
      "indices" : [ 90, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "590906900289433601",
  "text" : "RT @ajcraft: Happy #EarthDay! Let's protect #MountShasta and all of mama's other wonders. #ActOnClimate http:\/\/t.co\/vJ2EHTDWlF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ajcraft\/status\/590905761246498816\/photo\/1",
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/vJ2EHTDWlF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CDNRpt9UkAElt2f.jpg",
        "id_str" : "590905753268948993",
        "id" : 590905753268948993,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDNRpt9UkAElt2f.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/vJ2EHTDWlF"
      } ],
      "hashtags" : [ {
        "text" : "EarthDay",
        "indices" : [ 6, 15 ]
      }, {
        "text" : "MountShasta",
        "indices" : [ 31, 43 ]
      }, {
        "text" : "ActOnClimate",
        "indices" : [ 77, 90 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "590905761246498816",
    "text" : "Happy #EarthDay! Let's protect #MountShasta and all of mama's other wonders. #ActOnClimate http:\/\/t.co\/vJ2EHTDWlF",
    "id" : 590905761246498816,
    "created_at" : "2015-04-22 15:51:26 +0000",
    "user" : {
      "name" : "acraftyone",
      "screen_name" : "ajcraft",
      "protected" : false,
      "id_str" : "83147551",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797245613221900288\/EimOdtAc_normal.jpg",
      "id" : 83147551,
      "verified" : false
    }
  },
  "id" : 590906900289433601,
  "created_at" : "2015-04-22 15:55:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    }, {
      "name" : "Joshua Tree NP",
      "screen_name" : "joshuatreenp",
      "indices" : [ 114, 127 ],
      "id_str" : "3825684196",
      "id" : 3825684196
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EarthDay",
      "indices" : [ 20, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "590904019327049729",
  "text" : "RT @Interior: Happy #EarthDay! We celebrate our earth every day by protecting America's amazing public lands like @JoshuaTreeNP http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Joshua Tree NP",
        "screen_name" : "joshuatreenp",
        "indices" : [ 100, 113 ],
        "id_str" : "3825684196",
        "id" : 3825684196
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/590893114186948608\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/DzVGZgOyPZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CDNGJ_PW0AEmk0T.jpg",
        "id_str" : "590893113524277249",
        "id" : 590893113524277249,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDNGJ_PW0AEmk0T.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1205,
          "resize" : "fit",
          "w" : 1805
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 401,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 684,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/DzVGZgOyPZ"
      } ],
      "hashtags" : [ {
        "text" : "EarthDay",
        "indices" : [ 6, 15 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "590893114186948608",
    "text" : "Happy #EarthDay! We celebrate our earth every day by protecting America's amazing public lands like @JoshuaTreeNP http:\/\/t.co\/DzVGZgOyPZ",
    "id" : 590893114186948608,
    "created_at" : "2015-04-22 15:01:11 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 590904019327049729,
  "created_at" : "2015-04-22 15:44:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/590898252003860481\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/KIMefwhENf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDNKwIZWEAAu8kn.jpg",
      "id_str" : "590898166863630336",
      "id" : 590898166863630336,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDNKwIZWEAAu8kn.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2000,
        "resize" : "fit",
        "w" : 3000
      } ],
      "display_url" : "pic.twitter.com\/KIMefwhENf"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 56, 69 ]
    }, {
      "text" : "EarthDay",
      "indices" : [ 95, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/DK9rdyKUQ4",
      "expanded_url" : "http:\/\/go.wh.gov\/EarthDay",
      "display_url" : "go.wh.gov\/EarthDay"
    } ]
  },
  "geo" : { },
  "id_str" : "590898252003860481",
  "text" : "What park would you fight to protect? Let us know using #ActOnClimate \u2192 http:\/\/t.co\/DK9rdyKUQ4 #EarthDay http:\/\/t.co\/KIMefwhENf",
  "id" : 590898252003860481,
  "created_at" : "2015-04-22 15:21:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/590891469222846464\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/OvTK4lOFhN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDNBNOVWYAARYBQ.jpg",
      "id_str" : "590887671557414912",
      "id" : 590887671557414912,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDNBNOVWYAARYBQ.jpg",
      "sizes" : [ {
        "h" : 1041,
        "resize" : "fit",
        "w" : 1041
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/OvTK4lOFhN"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 87, 100 ]
    }, {
      "text" : "EarthDay",
      "indices" : [ 101, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/DK9rdyKUQ4",
      "expanded_url" : "http:\/\/go.wh.gov\/EarthDay",
      "display_url" : "go.wh.gov\/EarthDay"
    } ]
  },
  "geo" : { },
  "id_str" : "590891469222846464",
  "text" : "This is the only planet we've got.\n\nLet's fight to protect it.\n\nhttp:\/\/t.co\/DK9rdyKUQ4 #ActOnClimate #EarthDay http:\/\/t.co\/OvTK4lOFhN",
  "id" : 590891469222846464,
  "created_at" : "2015-04-22 14:54:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. EPA",
      "screen_name" : "EPA",
      "indices" : [ 3, 7 ],
      "id_str" : "14615871",
      "id" : 14615871
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/EPA\/status\/590881924249296896\/video\/1",
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/UNz6X7wjzR",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/590881824370470912\/pu\/img\/HTHBSMd2xH4CyboX.jpg",
      "id_str" : "590881824370470912",
      "id" : 590881824370470912,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/590881824370470912\/pu\/img\/HTHBSMd2xH4CyboX.jpg",
      "sizes" : [ {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/UNz6X7wjzR"
    } ],
    "hashtags" : [ {
      "text" : "EarthDayEveryDay",
      "indices" : [ 67, 84 ]
    }, {
      "text" : "EarthDay",
      "indices" : [ 85, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "590890089644830721",
  "text" : "RT @EPA: The bald eagle, our national bird, once faced extinction. #EarthDayEveryDay #EarthDay http:\/\/t.co\/UNz6X7wjzR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/EPA\/status\/590881924249296896\/video\/1",
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/UNz6X7wjzR",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/590881824370470912\/pu\/img\/HTHBSMd2xH4CyboX.jpg",
        "id_str" : "590881824370470912",
        "id" : 590881824370470912,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/590881824370470912\/pu\/img\/HTHBSMd2xH4CyboX.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/UNz6X7wjzR"
      } ],
      "hashtags" : [ {
        "text" : "EarthDayEveryDay",
        "indices" : [ 58, 75 ]
      }, {
        "text" : "EarthDay",
        "indices" : [ 76, 85 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "590881924249296896",
    "text" : "The bald eagle, our national bird, once faced extinction. #EarthDayEveryDay #EarthDay http:\/\/t.co\/UNz6X7wjzR",
    "id" : 590881924249296896,
    "created_at" : "2015-04-22 14:16:43 +0000",
    "user" : {
      "name" : "U.S. EPA",
      "screen_name" : "EPA",
      "protected" : false,
      "id_str" : "14615871",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/632228259879628800\/-gvVhzPn_normal.png",
      "id" : 14615871,
      "verified" : true
    }
  },
  "id" : 590890089644830721,
  "created_at" : "2015-04-22 14:49:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "indices" : [ 3, 13 ],
      "id_str" : "15007149",
      "id" : 15007149
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EarthDay",
      "indices" : [ 20, 29 ]
    }, {
      "text" : "ActOnClimate",
      "indices" : [ 122, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "590884733128585216",
  "text" : "RT @JohnKerry: This #EarthDay, I\u2019m calling on Americans &amp; concerned citizens everywhere to crank up the volume: let\u2019s #ActOnClimate: http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EarthDay",
        "indices" : [ 5, 14 ]
      }, {
        "text" : "ActOnClimate",
        "indices" : [ 107, 120 ]
      } ],
      "urls" : [ {
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/6R2aibW3nR",
        "expanded_url" : "http:\/\/goo.gl\/Yq3Klc",
        "display_url" : "goo.gl\/Yq3Klc"
      } ]
    },
    "geo" : { },
    "id_str" : "590866770216497153",
    "text" : "This #EarthDay, I\u2019m calling on Americans &amp; concerned citizens everywhere to crank up the volume: let\u2019s #ActOnClimate: http:\/\/t.co\/6R2aibW3nR",
    "id" : 590866770216497153,
    "created_at" : "2015-04-22 13:16:30 +0000",
    "user" : {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "protected" : false,
      "id_str" : "15007149",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/482149339842617346\/l6b7LXjb_normal.jpeg",
      "id" : 15007149,
      "verified" : true
    }
  },
  "id" : 590884733128585216,
  "created_at" : "2015-04-22 14:27:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Terry Virts",
      "screen_name" : "AstroTerry",
      "indices" : [ 3, 14 ],
      "id_str" : "1115148079",
      "id" : 1115148079
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/AstroTerry\/status\/590866110980861952\/photo\/1",
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/sedd5Cd8Ir",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDMtk2XUMAAwv_X.jpg",
      "id_str" : "590866087207514112",
      "id" : 590866087207514112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDMtk2XUMAAwv_X.jpg",
      "sizes" : [ {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/sedd5Cd8Ir"
    } ],
    "hashtags" : [ {
      "text" : "EarthDay",
      "indices" : [ 22, 31 ]
    }, {
      "text" : "NoPlaceLikeHome",
      "indices" : [ 77, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "590876924257259521",
  "text" : "RT @AstroTerry: Happy #EarthDay! Earth is indeed a beautiful place. There is #NoPlaceLikeHome. http:\/\/t.co\/sedd5Cd8Ir",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/AstroTerry\/status\/590866110980861952\/photo\/1",
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/sedd5Cd8Ir",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CDMtk2XUMAAwv_X.jpg",
        "id_str" : "590866087207514112",
        "id" : 590866087207514112,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDMtk2XUMAAwv_X.jpg",
        "sizes" : [ {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/sedd5Cd8Ir"
      } ],
      "hashtags" : [ {
        "text" : "EarthDay",
        "indices" : [ 6, 15 ]
      }, {
        "text" : "NoPlaceLikeHome",
        "indices" : [ 61, 77 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "590866110980861952",
    "text" : "Happy #EarthDay! Earth is indeed a beautiful place. There is #NoPlaceLikeHome. http:\/\/t.co\/sedd5Cd8Ir",
    "id" : 590866110980861952,
    "created_at" : "2015-04-22 13:13:53 +0000",
    "user" : {
      "name" : "Terry Virts",
      "screen_name" : "AstroTerry",
      "protected" : false,
      "id_str" : "1115148079",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/471931731063631873\/vhDEMGRo_normal.jpeg",
      "id" : 1115148079,
      "verified" : true
    }
  },
  "id" : 590876924257259521,
  "created_at" : "2015-04-22 13:56:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/590872266075869186\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/YR1ugRDVyO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDMzEy0W8AAS4WF.jpg",
      "id_str" : "590872133569540096",
      "id" : 590872133569540096,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDMzEy0W8AAS4WF.jpg",
      "sizes" : [ {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/YR1ugRDVyO"
    } ],
    "hashtags" : [ {
      "text" : "EarthDay",
      "indices" : [ 6, 15 ]
    }, {
      "text" : "ActOnClimate",
      "indices" : [ 72, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/k8fbW7HGUM",
      "expanded_url" : "http:\/\/go.wh.gov\/S984Qb",
      "display_url" : "go.wh.gov\/S984Qb"
    } ]
  },
  "geo" : { },
  "id_str" : "590872266075869186",
  "text" : "Happy #EarthDay! Share the place you're concerned about protecting with #ActOnClimate \u2192 http:\/\/t.co\/k8fbW7HGUM http:\/\/t.co\/YR1ugRDVyO",
  "id" : 590872266075869186,
  "created_at" : "2015-04-22 13:38:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Nye",
      "screen_name" : "BillNye",
      "indices" : [ 3, 11 ],
      "id_str" : "37710752",
      "id" : 37710752
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EarthDay",
      "indices" : [ 44, 53 ]
    }, {
      "text" : "ActOnClimate",
      "indices" : [ 122, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "590663932622331904",
  "text" : "RT @BillNye: Heading down to DC to catch an #EarthDay flight on Air Force One tomorrow with the President. We're going to #ActOnClimate.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EarthDay",
        "indices" : [ 31, 40 ]
      }, {
        "text" : "ActOnClimate",
        "indices" : [ 109, 122 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "590661734102409217",
    "text" : "Heading down to DC to catch an #EarthDay flight on Air Force One tomorrow with the President. We're going to #ActOnClimate.",
    "id" : 590661734102409217,
    "created_at" : "2015-04-21 23:41:46 +0000",
    "user" : {
      "name" : "Bill Nye",
      "screen_name" : "BillNye",
      "protected" : false,
      "id_str" : "37710752",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606232291438829568\/8liw3txV_normal.jpg",
      "id" : 37710752,
      "verified" : true
    }
  },
  "id" : 590663932622331904,
  "created_at" : "2015-04-21 23:50:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    }, {
      "name" : "Sequoia & Kings Cyn",
      "screen_name" : "SequoiaKingsNPS",
      "indices" : [ 79, 95 ],
      "id_str" : "45854669",
      "id" : 45854669
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Interior\/status\/590647090583318529\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/mDEjuhrRZY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDJmXc9XIAA_uFt.jpg",
      "id_str" : "590647054235541504",
      "id" : 590647054235541504,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDJmXc9XIAA_uFt.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/mDEjuhrRZY"
    } ],
    "hashtags" : [ {
      "text" : "JohnMuir",
      "indices" : [ 62, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "590659766000713729",
  "text" : "RT @Interior: Happy birthday to the Father of National Parks, #JohnMuir! Photo @SequoiaKingsNPS by Jeff Sambur http:\/\/t.co\/mDEjuhrRZY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sequoia & Kings Cyn",
        "screen_name" : "SequoiaKingsNPS",
        "indices" : [ 65, 81 ],
        "id_str" : "45854669",
        "id" : 45854669
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Interior\/status\/590647090583318529\/photo\/1",
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/mDEjuhrRZY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CDJmXc9XIAA_uFt.jpg",
        "id_str" : "590647054235541504",
        "id" : 590647054235541504,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDJmXc9XIAA_uFt.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/mDEjuhrRZY"
      } ],
      "hashtags" : [ {
        "text" : "JohnMuir",
        "indices" : [ 48, 57 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "590647090583318529",
    "text" : "Happy birthday to the Father of National Parks, #JohnMuir! Photo @SequoiaKingsNPS by Jeff Sambur http:\/\/t.co\/mDEjuhrRZY",
    "id" : 590647090583318529,
    "created_at" : "2015-04-21 22:43:34 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 590659766000713729,
  "created_at" : "2015-04-21 23:33:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "indices" : [ 3, 11 ],
      "id_str" : "2382117350",
      "id" : 2382117350
    }, {
      "name" : "ShenandoahNPS",
      "screen_name" : "ShenandoahNPS",
      "indices" : [ 62, 76 ],
      "id_str" : "45854335",
      "id" : 45854335
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EarthWeek",
      "indices" : [ 82, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/hp4qyydEML",
      "expanded_url" : "https:\/\/www.whitehouse.gov\/webform\/you-tell-us-which-natural-space-will-you-fight?utm_source=email&utm_medium=email&utm_content=email455-text3&utm_campaign=climatechange",
      "display_url" : "whitehouse.gov\/webform\/you-te\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "590622283628163073",
  "text" : "RT @Deese44: Thx Shannon T for telling us you want to protect @ShenandoahNPS this #EarthWeek\u2014share yr spot https:\/\/t.co\/hp4qyydEML http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ShenandoahNPS",
        "screen_name" : "ShenandoahNPS",
        "indices" : [ 49, 63 ],
        "id_str" : "45854335",
        "id" : 45854335
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Deese44\/status\/590621984721076224\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/tTUvp1Lj82",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CDJPjveW4AIRz2x.png",
        "id_str" : "590621976596766722",
        "id" : 590621976596766722,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDJPjveW4AIRz2x.png",
        "sizes" : [ {
          "h" : 564,
          "resize" : "fit",
          "w" : 850
        }, {
          "h" : 564,
          "resize" : "fit",
          "w" : 850
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 398,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/tTUvp1Lj82"
      } ],
      "hashtags" : [ {
        "text" : "EarthWeek",
        "indices" : [ 69, 79 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/hp4qyydEML",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/webform\/you-tell-us-which-natural-space-will-you-fight?utm_source=email&utm_medium=email&utm_content=email455-text3&utm_campaign=climatechange",
        "display_url" : "whitehouse.gov\/webform\/you-te\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "590621984721076224",
    "text" : "Thx Shannon T for telling us you want to protect @ShenandoahNPS this #EarthWeek\u2014share yr spot https:\/\/t.co\/hp4qyydEML http:\/\/t.co\/tTUvp1Lj82",
    "id" : 590621984721076224,
    "created_at" : "2015-04-21 21:03:49 +0000",
    "user" : {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "protected" : false,
      "id_str" : "2382117350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656551411145027584\/ArrSlGUP_normal.jpg",
      "id" : 2382117350,
      "verified" : true
    }
  },
  "id" : 590622283628163073,
  "created_at" : "2015-04-21 21:05:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "590596798584070144",
  "text" : "RT @VP: \"We\u2019ve dramatically increased production &amp; reduced the cost of renewable energy like solar and wind.\" -VP Biden http:\/\/t.co\/uSHBf9A\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/590594361370533891\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/uSHBf9AYmZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CDI2cLEWgAElt72.jpg",
        "id_str" : "590594358774235137",
        "id" : 590594358774235137,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDI2cLEWgAElt72.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/uSHBf9AYmZ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "590594361370533891",
    "text" : "\"We\u2019ve dramatically increased production &amp; reduced the cost of renewable energy like solar and wind.\" -VP Biden http:\/\/t.co\/uSHBf9AYmZ",
    "id" : 590594361370533891,
    "created_at" : "2015-04-21 19:14:03 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 590596798584070144,
  "created_at" : "2015-04-21 19:23:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "NASCAR",
      "screen_name" : "NASCAR",
      "indices" : [ 56, 63 ],
      "id_str" : "49153854",
      "id" : 49153854
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "590590675768467456",
  "text" : "RT @WHLive: \"Congratulations to Kevin Harvick, the 2014 @NASCAR Sprint Cup champion.\" \u2014President Obama",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NASCAR",
        "screen_name" : "NASCAR",
        "indices" : [ 44, 51 ],
        "id_str" : "49153854",
        "id" : 49153854
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "590590603181871105",
    "text" : "\"Congratulations to Kevin Harvick, the 2014 @NASCAR Sprint Cup champion.\" \u2014President Obama",
    "id" : 590590603181871105,
    "created_at" : "2015-04-21 18:59:07 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 590590675768467456,
  "created_at" : "2015-04-21 18:59:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "NASCAR",
      "screen_name" : "NASCAR",
      "indices" : [ 47, 54 ],
      "id_str" : "49153854",
      "id" : 49153854
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/HBlKinhqYM",
      "expanded_url" : "http:\/\/go.wh.gov\/vcKm31",
      "display_url" : "go.wh.gov\/vcKm31"
    } ]
  },
  "geo" : { },
  "id_str" : "590589641239220224",
  "text" : "RT @WHLive: Watch live: President Obama honors @NASCAR Sprint Cup Champion Kevin Harvick \u2192 http:\/\/t.co\/HBlKinhqYM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NASCAR",
        "screen_name" : "NASCAR",
        "indices" : [ 35, 42 ],
        "id_str" : "49153854",
        "id" : 49153854
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/HBlKinhqYM",
        "expanded_url" : "http:\/\/go.wh.gov\/vcKm31",
        "display_url" : "go.wh.gov\/vcKm31"
      } ]
    },
    "geo" : { },
    "id_str" : "590589522339061761",
    "text" : "Watch live: President Obama honors @NASCAR Sprint Cup Champion Kevin Harvick \u2192 http:\/\/t.co\/HBlKinhqYM",
    "id" : 590589522339061761,
    "created_at" : "2015-04-21 18:54:49 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 590589641239220224,
  "created_at" : "2015-04-21 18:55:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASCAR",
      "screen_name" : "NASCAR",
      "indices" : [ 3, 10 ],
      "id_str" : "49153854",
      "id" : 49153854
    }, {
      "name" : "Kevin Harvick",
      "screen_name" : "KevinHarvick",
      "indices" : [ 22, 35 ],
      "id_str" : "22450947",
      "id" : 22450947
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 47, 58 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/NASCAR\/status\/590569882288312321\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/o7bNZNkbvp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDIgLbGWAAAaPP9.jpg",
      "id_str" : "590569881763971072",
      "id" : 590569881763971072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDIgLbGWAAAaPP9.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 667,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 667,
        "resize" : "fit",
        "w" : 1000
      } ],
      "display_url" : "pic.twitter.com\/o7bNZNkbvp"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/MRjoFugZvk",
      "expanded_url" : "http:\/\/nas.cr\/1HykUfZ",
      "display_url" : "nas.cr\/1HykUfZ"
    } ]
  },
  "geo" : { },
  "id_str" : "590587476584071169",
  "text" : "RT @NASCAR: The Champ @KevinHarvick visits The @WhiteHouse. \n\nWatch live at 2:45 PM: http:\/\/t.co\/MRjoFugZvk http:\/\/t.co\/o7bNZNkbvp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kevin Harvick",
        "screen_name" : "KevinHarvick",
        "indices" : [ 10, 23 ],
        "id_str" : "22450947",
        "id" : 22450947
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 35, 46 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NASCAR\/status\/590569882288312321\/photo\/1",
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/o7bNZNkbvp",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CDIgLbGWAAAaPP9.jpg",
        "id_str" : "590569881763971072",
        "id" : 590569881763971072,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDIgLbGWAAAaPP9.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        } ],
        "display_url" : "pic.twitter.com\/o7bNZNkbvp"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/MRjoFugZvk",
        "expanded_url" : "http:\/\/nas.cr\/1HykUfZ",
        "display_url" : "nas.cr\/1HykUfZ"
      } ]
    },
    "geo" : { },
    "id_str" : "590569882288312321",
    "text" : "The Champ @KevinHarvick visits The @WhiteHouse. \n\nWatch live at 2:45 PM: http:\/\/t.co\/MRjoFugZvk http:\/\/t.co\/o7bNZNkbvp",
    "id" : 590569882288312321,
    "created_at" : "2015-04-21 17:36:46 +0000",
    "user" : {
      "name" : "NASCAR",
      "screen_name" : "NASCAR",
      "protected" : false,
      "id_str" : "49153854",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/774244072068411393\/BVjoul2w_normal.jpg",
      "id" : 49153854,
      "verified" : true
    }
  },
  "id" : 590587476584071169,
  "created_at" : "2015-04-21 18:46:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LeadOnLeave",
      "indices" : [ 115, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "590584745521770497",
  "text" : "RT @vj44: In 23 yrs of restaurant work, Jason has never received a day of paid sick leave. Philly is changing that #LeadOnLeave http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/590584005671710721\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/FCrMRP0ZqP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CDIs_eFW0AAgvAf.jpg",
        "id_str" : "590583970057867264",
        "id" : 590583970057867264,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDIs_eFW0AAgvAf.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        } ],
        "display_url" : "pic.twitter.com\/FCrMRP0ZqP"
      } ],
      "hashtags" : [ {
        "text" : "LeadOnLeave",
        "indices" : [ 105, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "590584005671710721",
    "text" : "In 23 yrs of restaurant work, Jason has never received a day of paid sick leave. Philly is changing that #LeadOnLeave http:\/\/t.co\/FCrMRP0ZqP",
    "id" : 590584005671710721,
    "created_at" : "2015-04-21 18:32:54 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 590584745521770497,
  "created_at" : "2015-04-21 18:35:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. EPA",
      "screen_name" : "EPA",
      "indices" : [ 3, 7 ],
      "id_str" : "14615871",
      "id" : 14615871
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/EPA\/status\/590519043762876417\/video\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/0vRwqoMFR6",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/590518757853794305\/pu\/img\/nzf8CTv_FNg3c8kR.jpg",
      "id_str" : "590518757853794305",
      "id" : 590518757853794305,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/590518757853794305\/pu\/img\/nzf8CTv_FNg3c8kR.jpg",
      "sizes" : [ {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/0vRwqoMFR6"
    } ],
    "hashtags" : [ {
      "text" : "EarthDayEveryDay",
      "indices" : [ 86, 103 ]
    }, {
      "text" : "EarthDay",
      "indices" : [ 104, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "590568279887994880",
  "text" : "RT @EPA: Since 1990, we\u2019ve helped reduce acid rain to protect our forests and waters. #EarthDayEveryDay #EarthDay http:\/\/t.co\/0vRwqoMFR6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/EPA\/status\/590519043762876417\/video\/1",
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/0vRwqoMFR6",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/590518757853794305\/pu\/img\/nzf8CTv_FNg3c8kR.jpg",
        "id_str" : "590518757853794305",
        "id" : 590518757853794305,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/590518757853794305\/pu\/img\/nzf8CTv_FNg3c8kR.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/0vRwqoMFR6"
      } ],
      "hashtags" : [ {
        "text" : "EarthDayEveryDay",
        "indices" : [ 77, 94 ]
      }, {
        "text" : "EarthDay",
        "indices" : [ 95, 104 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "590519043762876417",
    "text" : "Since 1990, we\u2019ve helped reduce acid rain to protect our forests and waters. #EarthDayEveryDay #EarthDay http:\/\/t.co\/0vRwqoMFR6",
    "id" : 590519043762876417,
    "created_at" : "2015-04-21 14:14:46 +0000",
    "user" : {
      "name" : "U.S. EPA",
      "screen_name" : "EPA",
      "protected" : false,
      "id_str" : "14615871",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/632228259879628800\/-gvVhzPn_normal.png",
      "id" : 14615871,
      "verified" : true
    }
  },
  "id" : 590568279887994880,
  "created_at" : "2015-04-21 17:30:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "indices" : [ 3, 11 ],
      "id_str" : "1530850933",
      "id" : 1530850933
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 40, 53 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/vTkwihFp9H",
      "expanded_url" : "http:\/\/grist.org\/article\/here-are-4-big-pollution-problems-epa-has-mostly-fixed-already\/",
      "display_url" : "grist.org\/article\/here-a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "590555555812474880",
  "text" : "RT @GinaEPA: We face a big challenge to #ActOnClimate, but history shows we can solve big challenges. http:\/\/t.co\/vTkwihFp9H #EarthDayEvery\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 27, 40 ]
      }, {
        "text" : "EarthDayEveryDay",
        "indices" : [ 112, 129 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/vTkwihFp9H",
        "expanded_url" : "http:\/\/grist.org\/article\/here-are-4-big-pollution-problems-epa-has-mostly-fixed-already\/",
        "display_url" : "grist.org\/article\/here-a\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "590524813526978561",
    "text" : "We face a big challenge to #ActOnClimate, but history shows we can solve big challenges. http:\/\/t.co\/vTkwihFp9H #EarthDayEveryDay",
    "id" : 590524813526978561,
    "created_at" : "2015-04-21 14:37:41 +0000",
    "user" : {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "protected" : false,
      "id_str" : "1530850933",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/632229333130604548\/Bb4I34DU_normal.jpg",
      "id" : 1530850933,
      "verified" : true
    }
  },
  "id" : 590555555812474880,
  "created_at" : "2015-04-21 16:39:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "indices" : [ 3, 11 ],
      "id_str" : "2382117350",
      "id" : 2382117350
    }, {
      "name" : "NOAA",
      "screen_name" : "NOAA",
      "indices" : [ 55, 60 ],
      "id_str" : "14342564",
      "id" : 14342564
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EarthWeek",
      "indices" : [ 42, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/2Svd0fsnvO",
      "expanded_url" : "http:\/\/www.noaanews.noaa.gov\/stories2015\/images\/humpbackwhale_noaa_large.jpg",
      "display_url" : "noaanews.noaa.gov\/stories2015\/im\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "590551205925019648",
  "text" : "RT @Deese44: Reasons to jump for joy this #EarthWeek : @NOAA taking humpback whale pops off endangered list http:\/\/t.co\/2Svd0fsnvO http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NOAA",
        "screen_name" : "NOAA",
        "indices" : [ 42, 47 ],
        "id_str" : "14342564",
        "id" : 14342564
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Deese44\/status\/590532053910716417\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/Oq6k2p5zco",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CDH9s-wUEAEw_k2.jpg",
        "id_str" : "590531975363956737",
        "id" : 590531975363956737,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDH9s-wUEAEw_k2.jpg",
        "sizes" : [ {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/Oq6k2p5zco"
      } ],
      "hashtags" : [ {
        "text" : "EarthWeek",
        "indices" : [ 29, 39 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/2Svd0fsnvO",
        "expanded_url" : "http:\/\/www.noaanews.noaa.gov\/stories2015\/images\/humpbackwhale_noaa_large.jpg",
        "display_url" : "noaanews.noaa.gov\/stories2015\/im\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "590532053910716417",
    "text" : "Reasons to jump for joy this #EarthWeek : @NOAA taking humpback whale pops off endangered list http:\/\/t.co\/2Svd0fsnvO http:\/\/t.co\/Oq6k2p5zco",
    "id" : 590532053910716417,
    "created_at" : "2015-04-21 15:06:27 +0000",
    "user" : {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "protected" : false,
      "id_str" : "2382117350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656551411145027584\/ArrSlGUP_normal.jpg",
      "id" : 2382117350,
      "verified" : true
    }
  },
  "id" : 590551205925019648,
  "created_at" : "2015-04-21 16:22:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/590544250942713856\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/F7ae9eIYss",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDII0lnWMAAGWIp.jpg",
      "id_str" : "590544200682319872",
      "id" : 590544200682319872,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDII0lnWMAAGWIp.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/F7ae9eIYss"
    } ],
    "hashtags" : [ {
      "text" : "BetterWithObamacare",
      "indices" : [ 95, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/Oyh5JkHBSE",
      "expanded_url" : "http:\/\/cbsn.ws\/1HQWbno",
      "display_url" : "cbsn.ws\/1HQWbno"
    } ]
  },
  "geo" : { },
  "id_str" : "590544250942713856",
  "text" : "New poll: Support for the Affordable Care Act reaches a two-year high \u2192 http:\/\/t.co\/Oyh5JkHBSE #BetterWithObamacare http:\/\/t.co\/F7ae9eIYss",
  "id" : 590544250942713856,
  "created_at" : "2015-04-21 15:54:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/590529507691343872\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/zOahdtLxrl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDH69uuUUAAyIqA.jpg",
      "id_str" : "590528964583510016",
      "id" : 590528964583510016,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDH69uuUUAAyIqA.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/zOahdtLxrl"
    } ],
    "hashtags" : [ {
      "text" : "FindYourPark",
      "indices" : [ 101, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/MfXGu91k9C",
      "expanded_url" : "http:\/\/FindYourPark.com",
      "display_url" : "FindYourPark.com"
    } ]
  },
  "geo" : { },
  "id_str" : "590529507691343872",
  "text" : "\"Chances are, there is a National Park closer to you than you think.\" \u2014Obama: http:\/\/t.co\/MfXGu91k9C #FindYourPark http:\/\/t.co\/zOahdtLxrl",
  "id" : 590529507691343872,
  "created_at" : "2015-04-21 14:56:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "590506405410410496",
  "text" : "RT @vj44: A team member shot a beautiful moment while working late last night. Love the photo, but next time stay inside, Zaid! http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/590492104754917376\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/WFaKytP6Il",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CDHZby9UgAAxs-L.jpg",
        "id_str" : "590492097720909824",
        "id" : 590492097720909824,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDHZby9UgAAxs-L.jpg",
        "sizes" : [ {
          "h" : 449,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 719,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 719,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/WFaKytP6Il"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "590492104754917376",
    "text" : "A team member shot a beautiful moment while working late last night. Love the photo, but next time stay inside, Zaid! http:\/\/t.co\/WFaKytP6Il",
    "id" : 590492104754917376,
    "created_at" : "2015-04-21 12:27:43 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 590506405410410496,
  "created_at" : "2015-04-21 13:24:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    }, {
      "name" : "Medium",
      "screen_name" : "Medium",
      "indices" : [ 28, 35 ],
      "id_str" : "571202103",
      "id" : 571202103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/2ccS8ksRRq",
      "expanded_url" : "http:\/\/bit.ly\/1JZg0YK",
      "display_url" : "bit.ly\/1JZg0YK"
    } ]
  },
  "geo" : { },
  "id_str" : "590304639980961793",
  "text" : "RT @arneduncan: I've joined @Medium. Read my first article, \"What Can Technology Do for Tomorrow's Children?\" http:\/\/t.co\/2ccS8ksRRq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Medium",
        "screen_name" : "Medium",
        "indices" : [ 12, 19 ],
        "id_str" : "571202103",
        "id" : 571202103
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/2ccS8ksRRq",
        "expanded_url" : "http:\/\/bit.ly\/1JZg0YK",
        "display_url" : "bit.ly\/1JZg0YK"
      } ]
    },
    "geo" : { },
    "id_str" : "590298905797009408",
    "text" : "I've joined @Medium. Read my first article, \"What Can Technology Do for Tomorrow's Children?\" http:\/\/t.co\/2ccS8ksRRq",
    "id" : 590298905797009408,
    "created_at" : "2015-04-20 23:40:01 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 590304639980961793,
  "created_at" : "2015-04-21 00:02:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Michael A. Nutter",
      "screen_name" : "Michael_Nutter",
      "indices" : [ 19, 34 ],
      "id_str" : "202790178",
      "id" : 202790178
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LeadOnLeave",
      "indices" : [ 95, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "590286652091666435",
  "text" : "RT @vj44: Philly\u2019s @Michael_Nutter is charging ahead for working families. Excited to take our #LeadOnLeave tour there tomorrow http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Michael A. Nutter",
        "screen_name" : "Michael_Nutter",
        "indices" : [ 9, 24 ],
        "id_str" : "202790178",
        "id" : 202790178
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LeadOnLeave",
        "indices" : [ 85, 97 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/hCknoAZwTh",
        "expanded_url" : "http:\/\/po.st\/0C7sor",
        "display_url" : "po.st\/0C7sor"
      } ]
    },
    "geo" : { },
    "id_str" : "590283921180348416",
    "text" : "Philly\u2019s @Michael_Nutter is charging ahead for working families. Excited to take our #LeadOnLeave tour there tomorrow http:\/\/t.co\/hCknoAZwTh",
    "id" : 590283921180348416,
    "created_at" : "2015-04-20 22:40:28 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 590286652091666435,
  "created_at" : "2015-04-20 22:51:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "espnW",
      "screen_name" : "espnW",
      "indices" : [ 3, 9 ],
      "id_str" : "57333521",
      "id" : 57333521
    }, {
      "name" : "Boston Marathon",
      "screen_name" : "bostonmarathon",
      "indices" : [ 23, 38 ],
      "id_str" : "111037335",
      "id" : 111037335
    }, {
      "name" : "Rebekah Gregory",
      "screen_name" : "rebekahmgregory",
      "indices" : [ 56, 72 ],
      "id_str" : "1514652660",
      "id" : 1514652660
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/espnW\/status\/590252234610446336\/photo\/1",
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/EEZcmtjkob",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDD_R4dW8AAS-UH.jpg",
      "id_str" : "590252233863917568",
      "id" : 590252233863917568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDD_R4dW8AAS-UH.jpg",
      "sizes" : [ {
        "h" : 2448,
        "resize" : "fit",
        "w" : 3264
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/EEZcmtjkob"
    } ],
    "hashtags" : [ {
      "text" : "RebekahStrong",
      "indices" : [ 85, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "590271987072675841",
  "text" : "RT @espnW: She did it! @bostonmarathon bombing survivor @rebekahmgregory runs again. #RebekahStrong http:\/\/t.co\/EEZcmtjkob",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Boston Marathon",
        "screen_name" : "bostonmarathon",
        "indices" : [ 12, 27 ],
        "id_str" : "111037335",
        "id" : 111037335
      }, {
        "name" : "Rebekah Gregory",
        "screen_name" : "rebekahmgregory",
        "indices" : [ 45, 61 ],
        "id_str" : "1514652660",
        "id" : 1514652660
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/espnW\/status\/590252234610446336\/photo\/1",
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/EEZcmtjkob",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CDD_R4dW8AAS-UH.jpg",
        "id_str" : "590252233863917568",
        "id" : 590252233863917568,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDD_R4dW8AAS-UH.jpg",
        "sizes" : [ {
          "h" : 2448,
          "resize" : "fit",
          "w" : 3264
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/EEZcmtjkob"
      } ],
      "hashtags" : [ {
        "text" : "RebekahStrong",
        "indices" : [ 74, 88 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "590252234610446336",
    "text" : "She did it! @bostonmarathon bombing survivor @rebekahmgregory runs again. #RebekahStrong http:\/\/t.co\/EEZcmtjkob",
    "id" : 590252234610446336,
    "created_at" : "2015-04-20 20:34:33 +0000",
    "user" : {
      "name" : "espnW",
      "screen_name" : "espnW",
      "protected" : false,
      "id_str" : "57333521",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/697410823048818688\/XTbUxqQK_normal.jpg",
      "id" : 57333521,
      "verified" : true
    }
  },
  "id" : 590271987072675841,
  "created_at" : "2015-04-20 21:53:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/590240435924172800\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/kQcTbEjo5s",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDD0ZngUsAAeGO3.jpg",
      "id_str" : "590240272123998208",
      "id" : 590240272123998208,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDD0ZngUsAAeGO3.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/kQcTbEjo5s"
    } ],
    "hashtags" : [ {
      "text" : "FindYourPark",
      "indices" : [ 101, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/MfXGu91k9C",
      "expanded_url" : "http:\/\/FindYourPark.com",
      "display_url" : "FindYourPark.com"
    } ]
  },
  "geo" : { },
  "id_str" : "590240435924172800",
  "text" : "RT if you agree: Every kid should be able to enjoy America's great outdoors \u2192 http:\/\/t.co\/MfXGu91k9C #FindYourPark http:\/\/t.co\/kQcTbEjo5s",
  "id" : 590240435924172800,
  "created_at" : "2015-04-20 19:47:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "indices" : [ 3, 11 ],
      "id_str" : "2382117350",
      "id" : 2382117350
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Deese44\/status\/590225110738407424\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/FvpwVdcEvH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDDmhrSUUAEmkD_.jpg",
      "id_str" : "590225017415159809",
      "id" : 590225017415159809,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDDmhrSUUAEmkD_.jpg",
      "sizes" : [ {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1332,
        "resize" : "fit",
        "w" : 2000
      } ],
      "display_url" : "pic.twitter.com\/FvpwVdcEvH"
    } ],
    "hashtags" : [ {
      "text" : "EarthWeek",
      "indices" : [ 55, 65 ]
    }, {
      "text" : "ActOnClimate",
      "indices" : [ 66, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/Zy6G127pdr",
      "expanded_url" : "https:\/\/medium.com\/@Deese44\/tell-us-what-would-you-fight-to-protect-aac043fedd2",
      "display_url" : "medium.com\/@Deese44\/tell-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "590237807882305536",
  "text" : "RT @Deese44: Tell us: What would you fight to protect? #EarthWeek #ActOnClimate https:\/\/t.co\/Zy6G127pdr http:\/\/t.co\/FvpwVdcEvH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Deese44\/status\/590225110738407424\/photo\/1",
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/FvpwVdcEvH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CDDmhrSUUAEmkD_.jpg",
        "id_str" : "590225017415159809",
        "id" : 590225017415159809,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDDmhrSUUAEmkD_.jpg",
        "sizes" : [ {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1332,
          "resize" : "fit",
          "w" : 2000
        } ],
        "display_url" : "pic.twitter.com\/FvpwVdcEvH"
      } ],
      "hashtags" : [ {
        "text" : "EarthWeek",
        "indices" : [ 42, 52 ]
      }, {
        "text" : "ActOnClimate",
        "indices" : [ 53, 66 ]
      } ],
      "urls" : [ {
        "indices" : [ 67, 90 ],
        "url" : "https:\/\/t.co\/Zy6G127pdr",
        "expanded_url" : "https:\/\/medium.com\/@Deese44\/tell-us-what-would-you-fight-to-protect-aac043fedd2",
        "display_url" : "medium.com\/@Deese44\/tell-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "590225110738407424",
    "text" : "Tell us: What would you fight to protect? #EarthWeek #ActOnClimate https:\/\/t.co\/Zy6G127pdr http:\/\/t.co\/FvpwVdcEvH",
    "id" : 590225110738407424,
    "created_at" : "2015-04-20 18:46:46 +0000",
    "user" : {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "protected" : false,
      "id_str" : "2382117350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656551411145027584\/ArrSlGUP_normal.jpg",
      "id" : 2382117350,
      "verified" : true
    }
  },
  "id" : 590237807882305536,
  "created_at" : "2015-04-20 19:37:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ohio State",
      "screen_name" : "OhioState",
      "indices" : [ 66, 76 ],
      "id_str" : "18846918",
      "id" : 18846918
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/mksXWhBOFe",
      "expanded_url" : "http:\/\/go.wh.gov\/GSixkE",
      "display_url" : "go.wh.gov\/GSixkE"
    } ]
  },
  "geo" : { },
  "id_str" : "590226744046583808",
  "text" : "\"Give it up for the 2014 College Football National Champions, The @OhioState Buckeyes!\" \u2014President Obama: http:\/\/t.co\/mksXWhBOFe",
  "id" : 590226744046583808,
  "created_at" : "2015-04-20 18:53:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ohio State",
      "screen_name" : "OhioState",
      "indices" : [ 82, 92 ],
      "id_str" : "18846918",
      "id" : 18846918
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/mksXWhBOFe",
      "expanded_url" : "http:\/\/go.wh.gov\/GSixkE",
      "display_url" : "go.wh.gov\/GSixkE"
    } ]
  },
  "geo" : { },
  "id_str" : "590226400507891712",
  "text" : "Happening now: President Obama honors the 2014 College Football National Champion @OhioState Buckeyes \u2192 http:\/\/t.co\/mksXWhBOFe",
  "id" : 590226400507891712,
  "created_at" : "2015-04-20 18:51:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Reckmeyer",
      "screen_name" : "timreckmeyer",
      "indices" : [ 3, 16 ],
      "id_str" : "17907315",
      "id" : 17907315
    }, {
      "name" : "GlacierNationalPark",
      "screen_name" : "GlacierNPS",
      "indices" : [ 18, 29 ],
      "id_str" : "32887168",
      "id" : 32887168
    }, {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "indices" : [ 131, 139 ],
      "id_str" : "2382117350",
      "id" : 2382117350
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 41, 54 ]
    }, {
      "text" : "FindYourPark",
      "indices" : [ 117, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "590209314041692160",
  "text" : "RT @timreckmeyer: @glaciernps is my fav. #ActOnClimate 2 preserve glaciers for us, our kids &amp; future generations #FindYourPark @Deese44 htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "GlacierNationalPark",
        "screen_name" : "GlacierNPS",
        "indices" : [ 0, 11 ],
        "id_str" : "32887168",
        "id" : 32887168
      }, {
        "name" : "Brian Deese",
        "screen_name" : "Deese44",
        "indices" : [ 113, 121 ],
        "id_str" : "2382117350",
        "id" : 2382117350
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/timreckmeyer\/status\/590204054195687424\/photo\/1",
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/pR041ITzjl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CDC3_bpUIAAa6Wd.jpg",
        "id_str" : "590173851566219264",
        "id" : 590173851566219264,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDC3_bpUIAAa6Wd.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/pR041ITzjl"
      } ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 23, 36 ]
      }, {
        "text" : "FindYourPark",
        "indices" : [ 99, 112 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "590204054195687424",
    "in_reply_to_user_id" : 32887168,
    "text" : "@glaciernps is my fav. #ActOnClimate 2 preserve glaciers for us, our kids &amp; future generations #FindYourPark @Deese44 http:\/\/t.co\/pR041ITzjl",
    "id" : 590204054195687424,
    "created_at" : "2015-04-20 17:23:06 +0000",
    "in_reply_to_screen_name" : "GlacierNPS",
    "in_reply_to_user_id_str" : "32887168",
    "user" : {
      "name" : "Tim Reckmeyer",
      "screen_name" : "timreckmeyer",
      "protected" : false,
      "id_str" : "17907315",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/667039667280175107\/lG0YBzyX_normal.jpg",
      "id" : 17907315,
      "verified" : false
    }
  },
  "id" : 590209314041692160,
  "created_at" : "2015-04-20 17:44:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Everglades Natl Park",
      "screen_name" : "EvergladesNPS",
      "indices" : [ 29, 43 ],
      "id_str" : "63966574",
      "id" : 63966574
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/590194648196362240\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/sNfDvBi9WM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDDK1LyUEAApU7x.jpg",
      "id_str" : "590194566231232512",
      "id" : 590194566231232512,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDDK1LyUEAApU7x.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 900
      } ],
      "display_url" : "pic.twitter.com\/sNfDvBi9WM"
    } ],
    "hashtags" : [ {
      "text" : "EarthDay",
      "indices" : [ 47, 56 ]
    }, {
      "text" : "ActOnClimate",
      "indices" : [ 80, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/k8fbW7HGUM",
      "expanded_url" : "http:\/\/go.wh.gov\/S984Qb",
      "display_url" : "go.wh.gov\/S984Qb"
    } ]
  },
  "geo" : { },
  "id_str" : "590194648196362240",
  "text" : "President Obama is headed to @EvergladesNPS on #EarthDay to discuss the need to #ActOnClimate: http:\/\/t.co\/k8fbW7HGUM http:\/\/t.co\/sNfDvBi9WM",
  "id" : 590194648196362240,
  "created_at" : "2015-04-20 16:45:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/590180448749293568\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/CrgT6bN0Gj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDC9zYgUIAAWq15.jpg",
      "id_str" : "590180241634500608",
      "id" : 590180241634500608,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDC9zYgUIAAWq15.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1466,
        "resize" : "fit",
        "w" : 2200
      } ],
      "display_url" : "pic.twitter.com\/CrgT6bN0Gj"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/zmVeYuxdJ7",
      "expanded_url" : "http:\/\/go.wh.gov\/xcrpiG",
      "display_url" : "go.wh.gov\/xcrpiG"
    } ]
  },
  "geo" : { },
  "id_str" : "590180448749293568",
  "text" : "\"We are blessed with the most beautiful landscapes and waterscapes in the world\" \u2014Obama: http:\/\/t.co\/zmVeYuxdJ7 http:\/\/t.co\/CrgT6bN0Gj",
  "id" : 590180448749293568,
  "created_at" : "2015-04-20 15:49:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/590163393614467072\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/jk5PmSIUfJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDCuHhIUMAAdEcJ.jpg",
      "id_str" : "590162995361099776",
      "id" : 590162995361099776,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDCuHhIUMAAdEcJ.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/jk5PmSIUfJ"
    } ],
    "hashtags" : [ {
      "text" : "FindYourPark",
      "indices" : [ 95, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/MfXGu91k9C",
      "expanded_url" : "http:\/\/FindYourPark.com",
      "display_url" : "FindYourPark.com"
    } ]
  },
  "geo" : { },
  "id_str" : "590163393614467072",
  "text" : "Happy National Park Week!\nCelebrate by heading out to a park near you \u2192 http:\/\/t.co\/MfXGu91k9C #FindYourPark http:\/\/t.co\/jk5PmSIUfJ",
  "id" : 590163393614467072,
  "created_at" : "2015-04-20 14:41:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/590151885903896577\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/g9009kn956",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CDCiaAJVEAAP4R1.jpg",
      "id_str" : "590150118784962560",
      "id" : 590150118784962560,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CDCiaAJVEAAP4R1.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/g9009kn956"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 64, 77 ]
    }, {
      "text" : "EarthDay",
      "indices" : [ 102, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/P8euWqL61m",
      "expanded_url" : "http:\/\/pbpo.st\/1P4UOmX",
      "display_url" : "pbpo.st\/1P4UOmX"
    } ]
  },
  "geo" : { },
  "id_str" : "590151885903896577",
  "text" : "\"This is the only planet we\u2019ve got.\" \u2014Obama on why it's time to #ActOnClimate: http:\/\/t.co\/P8euWqL61m #EarthDay http:\/\/t.co\/g9009kn956",
  "id" : 590151885903896577,
  "created_at" : "2015-04-20 13:55:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/589941581588795392\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/xyhhAIhqXr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CC9oxYBUsAArWGo.jpg",
      "id_str" : "589805273679704064",
      "id" : 589805273679704064,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CC9oxYBUsAArWGo.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/xyhhAIhqXr"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/ftxXQAUdvV",
      "expanded_url" : "http:\/\/go.wh.gov\/Pk4j7N",
      "display_url" : "go.wh.gov\/Pk4j7N"
    } ]
  },
  "geo" : { },
  "id_str" : "589941581588795392",
  "text" : "\"Every three weeks, we bring online as much solar power as we did in all of 2008.\" \u2014Obama: http:\/\/t.co\/ftxXQAUdvV http:\/\/t.co\/xyhhAIhqXr",
  "id" : 589941581588795392,
  "created_at" : "2015-04-20 00:00:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/589897291345068033\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/iUdOHTUHOd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CC-8YQ0UsAAnime.png",
      "id_str" : "589897201226133504",
      "id" : 589897201226133504,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CC-8YQ0UsAAnime.png",
      "sizes" : [ {
        "h" : 316,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 371,
        "resize" : "fit",
        "w" : 705
      }, {
        "h" : 371,
        "resize" : "fit",
        "w" : 705
      }, {
        "h" : 179,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/iUdOHTUHOd"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "589897291345068033",
  "text" : "\"We will never forget the men and women who lost their lives.\" \u2014Obama on the anniversary of the Oklahoma City bombing http:\/\/t.co\/iUdOHTUHOd",
  "id" : 589897291345068033,
  "created_at" : "2015-04-19 21:04:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 126, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/ftxXQAUdvV",
      "expanded_url" : "http:\/\/go.wh.gov\/Pk4j7N",
      "display_url" : "go.wh.gov\/Pk4j7N"
    } ]
  },
  "geo" : { },
  "id_str" : "589850988716032001",
  "text" : "\"Our carbon pollution has fallen by 10% since 2007, even as we\u2019ve grown our economy\" \u2014President Obama: http:\/\/t.co\/ftxXQAUdvV #ActOnClimate",
  "id" : 589850988716032001,
  "created_at" : "2015-04-19 18:00:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/589835925833650176\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/6cgEUOVBmV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CC91bEjUMAEH4SV.jpg",
      "id_str" : "589819184147607553",
      "id" : 589819184147607553,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CC91bEjUMAEH4SV.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/6cgEUOVBmV"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 102, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/ftxXQAUdvV",
      "expanded_url" : "http:\/\/go.wh.gov\/Pk4j7N",
      "display_url" : "go.wh.gov\/Pk4j7N"
    } ]
  },
  "geo" : { },
  "id_str" : "589835925833650176",
  "text" : "\"America is number one in wind power.\" \u2014President Obama in his weekly address: http:\/\/t.co\/ftxXQAUdvV #ActOnClimate http:\/\/t.co\/6cgEUOVBmV",
  "id" : 589835925833650176,
  "created_at" : "2015-04-19 17:00:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "indices" : [ 3, 11 ],
      "id_str" : "2382117350",
      "id" : 2382117350
    }, {
      "name" : "Acadia National Park",
      "screen_name" : "AcadiaNPS",
      "indices" : [ 37, 47 ],
      "id_str" : "185874758",
      "id" : 185874758
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 107, 120 ]
    }, {
      "text" : "FindYourPark",
      "indices" : [ 121, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "589825152499744768",
  "text" : "RT @Deese44: 1 of my favorite parks: @AcadiaNPS. Will fight so my daughter &amp; her kids can enjoy it too #ActOnClimate #FindYourPark http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Acadia National Park",
        "screen_name" : "AcadiaNPS",
        "indices" : [ 24, 34 ],
        "id_str" : "185874758",
        "id" : 185874758
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Deese44\/status\/589822571299872768\/photo\/1",
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/vDG71FWxR8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CC94QG5UkAAdOJ1.jpg",
        "id_str" : "589822294333100032",
        "id" : 589822294333100032,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CC94QG5UkAAdOJ1.jpg",
        "sizes" : [ {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 543,
          "resize" : "fit",
          "w" : 966
        }, {
          "h" : 543,
          "resize" : "fit",
          "w" : 966
        } ],
        "display_url" : "pic.twitter.com\/vDG71FWxR8"
      } ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 94, 107 ]
      }, {
        "text" : "FindYourPark",
        "indices" : [ 108, 121 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "589822571299872768",
    "text" : "1 of my favorite parks: @AcadiaNPS. Will fight so my daughter &amp; her kids can enjoy it too #ActOnClimate #FindYourPark http:\/\/t.co\/vDG71FWxR8",
    "id" : 589822571299872768,
    "created_at" : "2015-04-19 16:07:14 +0000",
    "user" : {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "protected" : false,
      "id_str" : "2382117350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656551411145027584\/ArrSlGUP_normal.jpg",
      "id" : 2382117350,
      "verified" : true
    }
  },
  "id" : 589825152499744768,
  "created_at" : "2015-04-19 16:17:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/589818801434324993\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/RTjlhhGjse",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CC90sbJVIAEjQna.jpg",
      "id_str" : "589818382758780929",
      "id" : 589818382758780929,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CC90sbJVIAEjQna.jpg",
      "sizes" : [ {
        "h" : 401,
        "resize" : "fit",
        "w" : 801
      }, {
        "h" : 401,
        "resize" : "fit",
        "w" : 801
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/RTjlhhGjse"
    } ],
    "hashtags" : [ {
      "text" : "WHGarden",
      "indices" : [ 47, 56 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/UrVmOYp6va",
      "expanded_url" : "http:\/\/go.wh.gov\/oZYxD9",
      "display_url" : "go.wh.gov\/oZYxD9"
    } ]
  },
  "geo" : { },
  "id_str" : "589818801434324993",
  "text" : "You're invited!\nApply to attend next weekend's #WHGarden Social at the White House \u2192 http:\/\/t.co\/UrVmOYp6va http:\/\/t.co\/RTjlhhGjse",
  "id" : 589818801434324993,
  "created_at" : "2015-04-19 15:52:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EarthDay",
      "indices" : [ 57, 66 ]
    }, {
      "text" : "ActOnClimate",
      "indices" : [ 92, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/ftxXQBbOUv",
      "expanded_url" : "http:\/\/go.wh.gov\/Pk4j7N",
      "display_url" : "go.wh.gov\/Pk4j7N"
    } ]
  },
  "geo" : { },
  "id_str" : "589803501921968128",
  "text" : "\"This is the only planet we\u2019ve got.\" \u2014President Obama on #EarthDay and steps he's taking to #ActOnClimate: http:\/\/t.co\/ftxXQBbOUv",
  "id" : 589803501921968128,
  "created_at" : "2015-04-19 14:51:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/ftxXQAUdvV",
      "expanded_url" : "http:\/\/go.wh.gov\/Pk4j7N",
      "display_url" : "go.wh.gov\/Pk4j7N"
    } ]
  },
  "geo" : { },
  "id_str" : "589518867749179392",
  "text" : "\"Climate change can no longer be denied\u2014or ignored. The world is looking to the United States...to lead.\" \u2014Obama: http:\/\/t.co\/ftxXQAUdvV",
  "id" : 589518867749179392,
  "created_at" : "2015-04-18 20:00:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 126, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/ftxXQAUdvV",
      "expanded_url" : "http:\/\/go.wh.gov\/Pk4j7N",
      "display_url" : "go.wh.gov\/Pk4j7N"
    } ]
  },
  "geo" : { },
  "id_str" : "589488660501831680",
  "text" : "\"The fact that the climate is changing has very serious implications for the way we live now.\" \u2014Obama: http:\/\/t.co\/ftxXQAUdvV #ActOnClimate",
  "id" : 589488660501831680,
  "created_at" : "2015-04-18 18:00:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EarthDay",
      "indices" : [ 68, 77 ]
    }, {
      "text" : "ActOnClimate",
      "indices" : [ 103, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/ftxXQAUdvV",
      "expanded_url" : "http:\/\/go.wh.gov\/Pk4j7N",
      "display_url" : "go.wh.gov\/Pk4j7N"
    } ]
  },
  "geo" : { },
  "id_str" : "589465946982469632",
  "text" : "\"2014 was the planet\u2019s warmest year on record.\" \u2014President Obama on #EarthDay and steps he's taking to #ActOnClimate: http:\/\/t.co\/ftxXQAUdvV",
  "id" : 589465946982469632,
  "created_at" : "2015-04-18 16:30:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 100, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/ftxXQAUdvV",
      "expanded_url" : "http:\/\/go.wh.gov\/Pk4j7N",
      "display_url" : "go.wh.gov\/Pk4j7N"
    } ]
  },
  "geo" : { },
  "id_str" : "589454641240219651",
  "text" : "\"There\u2019s no greater threat to our planet than climate change.\" \u2014President Obama on why it's time to #ActOnClimate: http:\/\/t.co\/ftxXQAUdvV",
  "id" : 589454641240219651,
  "created_at" : "2015-04-18 15:45:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EarthDay",
      "indices" : [ 45, 54 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/ftxXQBbOUv",
      "expanded_url" : "http:\/\/go.wh.gov\/Pk4j7N",
      "display_url" : "go.wh.gov\/Pk4j7N"
    } ]
  },
  "geo" : { },
  "id_str" : "589439718653349888",
  "text" : "President Obama will visit the Everglades on #EarthDay to talk about how climate change threatens our economy: http:\/\/t.co\/ftxXQBbOUv",
  "id" : 589439718653349888,
  "created_at" : "2015-04-18 14:45:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/589220603376218112\/photo\/1",
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/tpuSBwD3Mp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CC1UzVbWAAMZoQH.jpg",
      "id_str" : "589220367157297155",
      "id" : 589220367157297155,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CC1UzVbWAAMZoQH.jpg",
      "sizes" : [ {
        "h" : 252,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 2076,
        "resize" : "fit",
        "w" : 2800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 445,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 759,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/tpuSBwD3Mp"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/O0xrENfHZy",
      "expanded_url" : "https:\/\/youtu.be\/0wb-RNn-kKY",
      "display_url" : "youtu.be\/0wb-RNn-kKY"
    } ]
  },
  "geo" : { },
  "id_str" : "589220603376218112",
  "text" : "\"A good poem can make hard times a little easier to survive &amp; make good times a lot sweeter.\" https:\/\/t.co\/O0xrENfHZy http:\/\/t.co\/tpuSBwD3Mp",
  "id" : 589220603376218112,
  "created_at" : "2015-04-18 00:15:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/588514295329198080\/photo\/1",
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/fgf6i8Rk7G",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCrSndwXIAAMjUy.jpg",
      "id_str" : "588514276769472512",
      "id" : 588514276769472512,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCrSndwXIAAMjUy.jpg",
      "sizes" : [ {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/fgf6i8Rk7G"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "589193560597078018",
  "text" : "RT @Interior: This weekend entrance fees for all national parks will be waived. RT to spread the word! http:\/\/t.co\/fgf6i8Rk7G",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/588514295329198080\/photo\/1",
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/fgf6i8Rk7G",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CCrSndwXIAAMjUy.jpg",
        "id_str" : "588514276769472512",
        "id" : 588514276769472512,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCrSndwXIAAMjUy.jpg",
        "sizes" : [ {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/fgf6i8Rk7G"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "588514295329198080",
    "text" : "This weekend entrance fees for all national parks will be waived. RT to spread the word! http:\/\/t.co\/fgf6i8Rk7G",
    "id" : 588514295329198080,
    "created_at" : "2015-04-16 01:28:36 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 589193560597078018,
  "created_at" : "2015-04-17 22:27:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph Gordon-Levitt",
      "screen_name" : "hitRECordJoe",
      "indices" : [ 3, 16 ],
      "id_str" : "24807616",
      "id" : 24807616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/pk9wH07OUG",
      "expanded_url" : "http:\/\/bit.ly\/1DJLUrb",
      "display_url" : "bit.ly\/1DJLUrb"
    } ]
  },
  "geo" : { },
  "id_str" : "589170076701556736",
  "text" : "RT @hitRECordJoe: ATTN America!  All nat'l parks are free this weekend.  You can visit one &amp; make art about it: http:\/\/t.co\/pk9wH07OUG  #Fi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FindYourPark",
        "indices" : [ 122, 135 ]
      } ],
      "urls" : [ {
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/pk9wH07OUG",
        "expanded_url" : "http:\/\/bit.ly\/1DJLUrb",
        "display_url" : "bit.ly\/1DJLUrb"
      } ]
    },
    "geo" : { },
    "id_str" : "589049964229189632",
    "text" : "ATTN America!  All nat'l parks are free this weekend.  You can visit one &amp; make art about it: http:\/\/t.co\/pk9wH07OUG  #FindYourPark",
    "id" : 589049964229189632,
    "created_at" : "2015-04-17 12:57:10 +0000",
    "user" : {
      "name" : "Joseph Gordon-Levitt",
      "screen_name" : "hitRECordJoe",
      "protected" : false,
      "id_str" : "24807616",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/486193442687438848\/9e0qmdxf_normal.png",
      "id" : 24807616,
      "verified" : true
    }
  },
  "id" : 589170076701556736,
  "created_at" : "2015-04-17 20:54:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 44, 51 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 81, 92 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/e11093Nvkj",
      "expanded_url" : "http:\/\/go.wh.gov\/w2JeGN",
      "display_url" : "go.wh.gov\/w2JeGN"
    } ]
  },
  "geo" : { },
  "id_str" : "589157483626782721",
  "text" : "RT @WHLive: Watch live: President Obama and @FLOTUS host a poetry reading at the @WhiteHouse \u2192 http:\/\/t.co\/e11093Nvkj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The First Lady",
        "screen_name" : "FLOTUS",
        "indices" : [ 32, 39 ],
        "id_str" : "1093090866",
        "id" : 1093090866
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 69, 80 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/e11093Nvkj",
        "expanded_url" : "http:\/\/go.wh.gov\/w2JeGN",
        "display_url" : "go.wh.gov\/w2JeGN"
      } ]
    },
    "geo" : { },
    "id_str" : "589157444003176449",
    "text" : "Watch live: President Obama and @FLOTUS host a poetry reading at the @WhiteHouse \u2192 http:\/\/t.co\/e11093Nvkj",
    "id" : 589157444003176449,
    "created_at" : "2015-04-17 20:04:15 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 589157483626782721,
  "created_at" : "2015-04-17 20:04:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Utech",
      "screen_name" : "Utech44",
      "indices" : [ 3, 11 ],
      "id_str" : "2283772130",
      "id" : 2283772130
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Utech44\/status\/589140095262941184\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/XHP01Umm62",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CC0Ly2lVAAApAXT.jpg",
      "id_str" : "589140094528847872",
      "id" : 589140094528847872,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CC0Ly2lVAAApAXT.jpg",
      "sizes" : [ {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/XHP01Umm62"
    } ],
    "hashtags" : [ {
      "text" : "DidYouKnow",
      "indices" : [ 13, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "589140292768501760",
  "text" : "RT @Utech44: #DidYouKnow: This weekend you can visit all national parks for free. RT to spread the word! http:\/\/t.co\/XHP01Umm62",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Utech44\/status\/589140095262941184\/photo\/1",
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/XHP01Umm62",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CC0Ly2lVAAApAXT.jpg",
        "id_str" : "589140094528847872",
        "id" : 589140094528847872,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CC0Ly2lVAAApAXT.jpg",
        "sizes" : [ {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/XHP01Umm62"
      } ],
      "hashtags" : [ {
        "text" : "DidYouKnow",
        "indices" : [ 0, 11 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "589140095262941184",
    "text" : "#DidYouKnow: This weekend you can visit all national parks for free. RT to spread the word! http:\/\/t.co\/XHP01Umm62",
    "id" : 589140095262941184,
    "created_at" : "2015-04-17 18:55:19 +0000",
    "user" : {
      "name" : "Dan Utech",
      "screen_name" : "Utech44",
      "protected" : false,
      "id_str" : "2283772130",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705138779221135360\/UcDKamCq_normal.jpg",
      "id" : 2283772130,
      "verified" : true
    }
  },
  "id" : 589140292768501760,
  "created_at" : "2015-04-17 18:56:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "Justin Sink",
      "screen_name" : "justinsink",
      "indices" : [ 15, 26 ],
      "id_str" : "346197350",
      "id" : 346197350
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "askpresssec",
      "indices" : [ 102, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "589135258399875072",
  "text" : "RT @PressSec: .@justinsink Serious tip: stay tuned for some actual news in tomorrow's weekly address. #askpresssec",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Justin Sink",
        "screen_name" : "justinsink",
        "indices" : [ 1, 12 ],
        "id_str" : "346197350",
        "id" : 346197350
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "askpresssec",
        "indices" : [ 88, 100 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "589133296119996416",
    "geo" : { },
    "id_str" : "589134334000373760",
    "in_reply_to_user_id" : 346197350,
    "text" : ".@justinsink Serious tip: stay tuned for some actual news in tomorrow's weekly address. #askpresssec",
    "id" : 589134334000373760,
    "in_reply_to_status_id" : 589133296119996416,
    "created_at" : "2015-04-17 18:32:25 +0000",
    "in_reply_to_screen_name" : "justinsink",
    "in_reply_to_user_id_str" : "346197350",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 589135258399875072,
  "created_at" : "2015-04-17 18:36:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "askpresssec",
      "indices" : [ 124, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "589125159354769408",
  "text" : "RT @PressSec: Just watched POTUS presser w Italy's PM which meant there was no briefing. So, now is as good a time as any 4 #askpresssec. W\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "askpresssec",
        "indices" : [ 110, 122 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "589125074688413697",
    "text" : "Just watched POTUS presser w Italy's PM which meant there was no briefing. So, now is as good a time as any 4 #askpresssec. Will start soon!",
    "id" : 589125074688413697,
    "created_at" : "2015-04-17 17:55:37 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 589125159354769408,
  "created_at" : "2015-04-17 17:55:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ConfirmLynch",
      "indices" : [ 96, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/iqkLBdhFhQ",
      "expanded_url" : "http:\/\/snpy.tv\/1aDIlHo",
      "display_url" : "snpy.tv\/1aDIlHo"
    } ]
  },
  "geo" : { },
  "id_str" : "589115055377092608",
  "text" : "Enough is enough.\nIt\u2019s time for Senate Republicans to call a vote for AG nominee Loretta Lynch. #ConfirmLynch http:\/\/t.co\/iqkLBdhFhQ",
  "id" : 589115055377092608,
  "created_at" : "2015-04-17 17:15:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/JSncm3W7dc",
      "expanded_url" : "http:\/\/snpy.tv\/1Df4L9d",
      "display_url" : "snpy.tv\/1Df4L9d"
    } ]
  },
  "geo" : { },
  "id_str" : "589108183043416064",
  "text" : "RT if you agree with President Obama: It\u2019s time to create jobs and grow our economy by rebuilding our infrastructure. http:\/\/t.co\/JSncm3W7dc",
  "id" : 589108183043416064,
  "created_at" : "2015-04-17 16:48:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "589106515111497728",
  "text" : "RT @WHLive: \u201CWe\u2019ve now seen 5 straight years of job growth. We\u2019ve seen the unemployment rate go from 10% to 5.5%.\u201D \u2014Obama http:\/\/t.co\/4QYIp\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WHLive\/status\/589106485759766528\/photo\/1",
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/4QYIpcJOY5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CCzs0vWW4AAyx4C.jpg",
        "id_str" : "589106042086285312",
        "id" : 589106042086285312,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCzs0vWW4AAyx4C.jpg",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 700,
          "resize" : "fit",
          "w" : 1400
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/4QYIpcJOY5"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "589106485759766528",
    "text" : "\u201CWe\u2019ve now seen 5 straight years of job growth. We\u2019ve seen the unemployment rate go from 10% to 5.5%.\u201D \u2014Obama http:\/\/t.co\/4QYIpcJOY5",
    "id" : 589106485759766528,
    "created_at" : "2015-04-17 16:41:45 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 589106515111497728,
  "created_at" : "2015-04-17 16:41:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TPA",
      "indices" : [ 95, 99 ]
    }, {
      "text" : "LeadOnTrade",
      "indices" : [ 100, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/ysEfAXC6wJ",
      "expanded_url" : "http:\/\/snpy.tv\/1DeYVV9",
      "display_url" : "snpy.tv\/1DeYVV9"
    } ]
  },
  "geo" : { },
  "id_str" : "589104966242992128",
  "text" : "\u201CThis is absolutely good for\u2014not just American businesses\u2014but for American workers.\u201D \u2014Obama on #TPA #LeadOnTrade http:\/\/t.co\/ysEfAXC6wJ",
  "id" : 589104966242992128,
  "created_at" : "2015-04-17 16:35:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/a2bfGP7p0P",
      "expanded_url" : "http:\/\/go.wh.gov\/nT7RKr",
      "display_url" : "go.wh.gov\/nT7RKr"
    } ]
  },
  "geo" : { },
  "id_str" : "589099088509009920",
  "text" : "Watch live: President Obama holds a press conference with Italian Prime Minister Matteo Renzi \u2192 http:\/\/t.co\/a2bfGP7p0P",
  "id" : 589099088509009920,
  "created_at" : "2015-04-17 16:12:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/588827878491586560\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/e7FCKcgYTn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCvvzo_UsAAAEjf.png",
      "id_str" : "588827846757363712",
      "id" : 588827846757363712,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCvvzo_UsAAAEjf.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 774
      }, {
        "h" : 397,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 774
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/e7FCKcgYTn"
    } ],
    "hashtags" : [ {
      "text" : "LeadOnTrade",
      "indices" : [ 102, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "589084225913098240",
  "text" : "\"My top priority in any trade negotiation is expanding opportunity for hardworking Americans.\" \u2014Obama #LeadOnTrade http:\/\/t.co\/e7FCKcgYTn",
  "id" : 589084225913098240,
  "created_at" : "2015-04-17 15:13:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Megan Smith",
      "screen_name" : "USCTO",
      "indices" : [ 3, 9 ],
      "id_str" : "2888895350",
      "id" : 2888895350
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/USCTO\/status\/589075481732849664\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/doWTzU4RsO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCzRB1AVAAIC3Sy.png",
      "id_str" : "589075480617222146",
      "id" : 589075480617222146,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCzRB1AVAAIC3Sy.png",
      "sizes" : [ {
        "h" : 365,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 839,
        "resize" : "fit",
        "w" : 782
      }, {
        "h" : 644,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 839,
        "resize" : "fit",
        "w" : 782
      } ],
      "display_url" : "pic.twitter.com\/doWTzU4RsO"
    } ],
    "hashtags" : [ {
      "text" : "WHMeetup",
      "indices" : [ 105, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/ZpNChdB77s",
      "expanded_url" : "http:\/\/WhiteHouse.gov\/live",
      "display_url" : "WhiteHouse.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "589076547182538752",
  "text" : "RT @USCTO: Join us for the 1st-ever White House Tech Meetup! Participate at http:\/\/t.co\/ZpNChdB77s &amp; #WHMeetup http:\/\/t.co\/doWTzU4RsO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/USCTO\/status\/589075481732849664\/photo\/1",
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/doWTzU4RsO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CCzRB1AVAAIC3Sy.png",
        "id_str" : "589075480617222146",
        "id" : 589075480617222146,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCzRB1AVAAIC3Sy.png",
        "sizes" : [ {
          "h" : 365,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 839,
          "resize" : "fit",
          "w" : 782
        }, {
          "h" : 644,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 839,
          "resize" : "fit",
          "w" : 782
        } ],
        "display_url" : "pic.twitter.com\/doWTzU4RsO"
      } ],
      "hashtags" : [ {
        "text" : "WHMeetup",
        "indices" : [ 94, 103 ]
      } ],
      "urls" : [ {
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/ZpNChdB77s",
        "expanded_url" : "http:\/\/WhiteHouse.gov\/live",
        "display_url" : "WhiteHouse.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "589075481732849664",
    "text" : "Join us for the 1st-ever White House Tech Meetup! Participate at http:\/\/t.co\/ZpNChdB77s &amp; #WHMeetup http:\/\/t.co\/doWTzU4RsO",
    "id" : 589075481732849664,
    "created_at" : "2015-04-17 14:38:33 +0000",
    "user" : {
      "name" : "Megan Smith",
      "screen_name" : "USCTO",
      "protected" : false,
      "id_str" : "2888895350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/534373591228219392\/Ewzw--q6_normal.jpeg",
      "id" : 2888895350,
      "verified" : true
    }
  },
  "id" : 589076547182538752,
  "created_at" : "2015-04-17 14:42:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "veterans",
      "indices" : [ 57, 66 ]
    }, {
      "text" : "ChangeMentalHealth",
      "indices" : [ 91, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "589074682789416961",
  "text" : "RT @JoiningForces: Questions about mental health for our #veterans? Ask by 3:30pm ET using #ChangeMentalHealth and we'll answer a bunch: ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "veterans",
        "indices" : [ 38, 47 ]
      }, {
        "text" : "ChangeMentalHealth",
        "indices" : [ 72, 91 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/p0zY2Y9O3I",
        "expanded_url" : "http:\/\/go.wh.gov\/4Basbz",
        "display_url" : "go.wh.gov\/4Basbz"
      } ]
    },
    "geo" : { },
    "id_str" : "589073414645620736",
    "text" : "Questions about mental health for our #veterans? Ask by 3:30pm ET using #ChangeMentalHealth and we'll answer a bunch: http:\/\/t.co\/p0zY2Y9O3I",
    "id" : 589073414645620736,
    "created_at" : "2015-04-17 14:30:21 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 589074682789416961,
  "created_at" : "2015-04-17 14:35:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/2mSnvl7Fln",
      "expanded_url" : "http:\/\/WhiteHouse.gov\/live",
      "display_url" : "WhiteHouse.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "589058786637139968",
  "text" : "RT @whitehouseostp: STARTING NOW: the 1st-ever White House Tech Meetup! Follow along at http:\/\/t.co\/2mSnvl7Fln and share your thoughts at #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHMeetup",
        "indices" : [ 118, 127 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/2mSnvl7Fln",
        "expanded_url" : "http:\/\/WhiteHouse.gov\/live",
        "display_url" : "WhiteHouse.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "589057259013038080",
    "text" : "STARTING NOW: the 1st-ever White House Tech Meetup! Follow along at http:\/\/t.co\/2mSnvl7Fln and share your thoughts at #WHMeetup",
    "id" : 589057259013038080,
    "created_at" : "2015-04-17 13:26:09 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 589058786637139968,
  "created_at" : "2015-04-17 13:32:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Surgeon General",
      "screen_name" : "Surgeon_General",
      "indices" : [ 3, 19 ],
      "id_str" : "455024343",
      "id" : 455024343
    }, {
      "name" : "Elmo",
      "screen_name" : "elmo",
      "indices" : [ 55, 60 ],
      "id_str" : "962197608",
      "id" : 962197608
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gettingvaccinated",
      "indices" : [ 35, 53 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/2cC4siSPnq",
      "expanded_url" : "http:\/\/on.fb.me\/1E7zN9G",
      "display_url" : "on.fb.me\/1E7zN9G"
    } ]
  },
  "geo" : { },
  "id_str" : "589053884821286912",
  "text" : "RT @Surgeon_General: Nervous about #gettingvaccinated? @Elmo &amp; I can walk you through it easy-peasy! http:\/\/t.co\/2cC4siSPnq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Elmo",
        "screen_name" : "elmo",
        "indices" : [ 34, 39 ],
        "id_str" : "962197608",
        "id" : 962197608
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "gettingvaccinated",
        "indices" : [ 14, 32 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/2cC4siSPnq",
        "expanded_url" : "http:\/\/on.fb.me\/1E7zN9G",
        "display_url" : "on.fb.me\/1E7zN9G"
      } ]
    },
    "geo" : { },
    "id_str" : "589051200391217152",
    "text" : "Nervous about #gettingvaccinated? @Elmo &amp; I can walk you through it easy-peasy! http:\/\/t.co\/2cC4siSPnq",
    "id" : 589051200391217152,
    "created_at" : "2015-04-17 13:02:04 +0000",
    "user" : {
      "name" : "U.S. Surgeon General",
      "screen_name" : "Surgeon_General",
      "protected" : false,
      "id_str" : "455024343",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/768080246314717185\/2csUW4il_normal.jpg",
      "id" : 455024343,
      "verified" : true
    }
  },
  "id" : 589053884821286912,
  "created_at" : "2015-04-17 13:12:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ChangeMentalHealth",
      "indices" : [ 52, 71 ]
    }, {
      "text" : "Vets",
      "indices" : [ 93, 98 ]
    }, {
      "text" : "MilFam",
      "indices" : [ 106, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588883010793119745",
  "text" : "RT @JoiningForces: Ask your questions on working to #ChangeMentalHealth for service members, #Vets, &amp; #MilFam by tomorrow at 3:30pm ET: htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ChangeMentalHealth",
        "indices" : [ 33, 52 ]
      }, {
        "text" : "Vets",
        "indices" : [ 74, 79 ]
      }, {
        "text" : "MilFam",
        "indices" : [ 87, 94 ]
      } ],
      "urls" : [ {
        "indices" : [ 121, 143 ],
        "url" : "http:\/\/t.co\/p0zY2XSdca",
        "expanded_url" : "http:\/\/go.wh.gov\/4Basbz",
        "display_url" : "go.wh.gov\/4Basbz"
      } ]
    },
    "geo" : { },
    "id_str" : "588859851050262528",
    "text" : "Ask your questions on working to #ChangeMentalHealth for service members, #Vets, &amp; #MilFam by tomorrow at 3:30pm ET: http:\/\/t.co\/p0zY2XSdca",
    "id" : 588859851050262528,
    "created_at" : "2015-04-17 00:21:43 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 588883010793119745,
  "created_at" : "2015-04-17 01:53:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "indices" : [ 3, 13 ],
      "id_str" : "1613223313",
      "id" : 1613223313
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Cecilia44\/status\/588775349296594944\/photo\/1",
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/1MOHtLl9z6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCvADwwW4AIQiL0.jpg",
      "id_str" : "588775347161849858",
      "id" : 588775347161849858,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCvADwwW4AIQiL0.jpg",
      "sizes" : [ {
        "h" : 527,
        "resize" : "fit",
        "w" : 747
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 423,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 527,
        "resize" : "fit",
        "w" : 747
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/1MOHtLl9z6"
    } ],
    "hashtags" : [ {
      "text" : "TBT",
      "indices" : [ 15, 19 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588865096052539393",
  "text" : "RT @Cecilia44: #TBT to my immigrant family - I\u2019m the one on my abuelo\u2019s lap. http:\/\/t.co\/1MOHtLl9z6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Cecilia44\/status\/588775349296594944\/photo\/1",
        "indices" : [ 62, 84 ],
        "url" : "http:\/\/t.co\/1MOHtLl9z6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CCvADwwW4AIQiL0.jpg",
        "id_str" : "588775347161849858",
        "id" : 588775347161849858,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCvADwwW4AIQiL0.jpg",
        "sizes" : [ {
          "h" : 527,
          "resize" : "fit",
          "w" : 747
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 423,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 527,
          "resize" : "fit",
          "w" : 747
        }, {
          "h" : 240,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/1MOHtLl9z6"
      } ],
      "hashtags" : [ {
        "text" : "TBT",
        "indices" : [ 0, 4 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "588775349296594944",
    "text" : "#TBT to my immigrant family - I\u2019m the one on my abuelo\u2019s lap. http:\/\/t.co\/1MOHtLl9z6",
    "id" : 588775349296594944,
    "created_at" : "2015-04-16 18:45:56 +0000",
    "user" : {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "protected" : false,
      "id_str" : "1613223313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000172019215\/ed65eda76f51213f91b33edbaa62054c_normal.jpeg",
      "id" : 1613223313,
      "verified" : true
    }
  },
  "id" : 588865096052539393,
  "created_at" : "2015-04-17 00:42:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/588827878491586560\/photo\/1",
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/e7FCKcgYTn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCvvzo_UsAAAEjf.png",
      "id_str" : "588827846757363712",
      "id" : 588827846757363712,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCvvzo_UsAAAEjf.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 774
      }, {
        "h" : 397,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 774
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/e7FCKcgYTn"
    } ],
    "hashtags" : [ {
      "text" : "TPA",
      "indices" : [ 83, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588827878491586560",
  "text" : "\"Our exports support more than 11 million good American jobs.\" \u2014President Obama on #TPA: http:\/\/t.co\/e7FCKcgYTn",
  "id" : 588827878491586560,
  "created_at" : "2015-04-16 22:14:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "indices" : [ 3, 12 ],
      "id_str" : "1604366701",
      "id" : 1604366701
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TBT",
      "indices" : [ 14, 18 ]
    }, {
      "text" : "NewAmericans",
      "indices" : [ 53, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/55rWqrToZj",
      "expanded_url" : "https:\/\/www.whitehouse.gov\/issues\/immigration\/new-americans",
      "display_url" : "whitehouse.gov\/issues\/immigra\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "588821809081913344",
  "text" : "RT @LaborSec: #TBT to my Dominican roots \u2013 Celebrate #NewAmericans by sharing your immigrant roots story https:\/\/t.co\/55rWqrToZj http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/LaborSec\/status\/588793704699289600\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/CAwjIuFKFA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CCvQwPsUkAAbrZJ.png",
        "id_str" : "588793703566708736",
        "id" : 588793703566708736,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCvQwPsUkAAbrZJ.png",
        "sizes" : [ {
          "h" : 544,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 2400,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1638,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/CAwjIuFKFA"
      } ],
      "hashtags" : [ {
        "text" : "TBT",
        "indices" : [ 0, 4 ]
      }, {
        "text" : "NewAmericans",
        "indices" : [ 39, 52 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/55rWqrToZj",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/issues\/immigration\/new-americans",
        "display_url" : "whitehouse.gov\/issues\/immigra\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "588793704699289600",
    "text" : "#TBT to my Dominican roots \u2013 Celebrate #NewAmericans by sharing your immigrant roots story https:\/\/t.co\/55rWqrToZj http:\/\/t.co\/CAwjIuFKFA",
    "id" : 588793704699289600,
    "created_at" : "2015-04-16 19:58:53 +0000",
    "user" : {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "protected" : false,
      "id_str" : "1604366701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744887280666611712\/eEeyFjs6_normal.jpg",
      "id" : 1604366701,
      "verified" : true
    }
  },
  "id" : 588821809081913344,
  "created_at" : "2015-04-16 21:50:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/588814083702394880\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/n2e3WgVTwB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCvi4mKUgAA4DEK.png",
      "id_str" : "588813638246367232",
      "id" : 588813638246367232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCvi4mKUgAA4DEK.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 774
      }, {
        "h" : 397,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 774
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/n2e3WgVTwB"
    } ],
    "hashtags" : [ {
      "text" : "TPA",
      "indices" : [ 105, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588814083702394880",
  "text" : "\"My top priority in any trade negotiation is expanding opportunity for hardworking Americans.\" \u2014Obama on #TPA: http:\/\/t.co\/n2e3WgVTwB",
  "id" : 588814083702394880,
  "created_at" : "2015-04-16 21:19:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/snappytv.com\" rel=\"nofollow\"\u003ESnappyTV.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 6, 15 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/Tn5pPJjpeE",
      "expanded_url" : "http:\/\/snpy.tv\/1b7rXQM",
      "display_url" : "snpy.tv\/1b7rXQM"
    } ]
  },
  "geo" : { },
  "id_str" : "588785642831642624",
  "text" : "Watch @PressSec on the historic delay by the U.S. Senate in confirming Loretta Lynch as the next Attorney General: http:\/\/t.co\/Tn5pPJjpeE",
  "id" : 588785642831642624,
  "created_at" : "2015-04-16 19:26:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588771312450998272",
  "text" : "\"These companies are making the business case for supporting working families, showing that it's good for the bottom line.\" \u2014President Obama",
  "id" : 588771312450998272,
  "created_at" : "2015-04-16 18:29:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588769930998190081",
  "text" : "\"America deserves a Congress that doesn\u2019t just talk about supporting working families, but actually supports working families.\" \u2014Obama",
  "id" : 588769930998190081,
  "created_at" : "2015-04-16 18:24:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WomenSucceed",
      "indices" : [ 6, 19 ]
    }, {
      "text" : "WorkingFamilyChamps",
      "indices" : [ 57, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588769763318308864",
  "text" : "\"When #WomenSucceed, America succeeds.\" \u2014President Obama #WorkingFamilyChamps",
  "id" : 588769763318308864,
  "created_at" : "2015-04-16 18:23:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/588769323516211201\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/bmAGL5jPUv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCu6bgiVIAEUXBG.jpg",
      "id_str" : "588769158055141377",
      "id" : 588769158055141377,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCu6bgiVIAEUXBG.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/bmAGL5jPUv"
    } ],
    "hashtags" : [ {
      "text" : "WorkingFamilyChamps",
      "indices" : [ 91, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588769323516211201",
  "text" : "\"Ensuring equal pay for women is a no-brainer...As a dad, this is personal for me.\" \u2014Obama #WorkingFamilyChamps http:\/\/t.co\/bmAGL5jPUv",
  "id" : 588769323516211201,
  "created_at" : "2015-04-16 18:22:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/588768840588242944\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/Qc1VuQUjgx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCu6ICUUIAAAMaB.jpg",
      "id_str" : "588768823525777408",
      "id" : 588768823525777408,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCu6ICUUIAAAMaB.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/Qc1VuQUjgx"
    } ],
    "hashtags" : [ {
      "text" : "WorkingFamilyChamps",
      "indices" : [ 87, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588768840588242944",
  "text" : "\"We are still the only advanced country on Earth without paid leave.\" \u2014President Obama #WorkingFamilyChamps http:\/\/t.co\/Qc1VuQUjgx",
  "id" : 588768840588242944,
  "created_at" : "2015-04-16 18:20:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588768506272854016",
  "text" : "RT @WHLive: \"The country does best when everyone gets their fair shot, and everybody is doing their fair share.\" \u2014President Obama #WorkingF\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WorkingFamilyChamps",
        "indices" : [ 118, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "588768433476476928",
    "text" : "\"The country does best when everyone gets their fair shot, and everybody is doing their fair share.\" \u2014President Obama #WorkingFamilyChamps",
    "id" : 588768433476476928,
    "created_at" : "2015-04-16 18:18:27 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 588768506272854016,
  "created_at" : "2015-04-16 18:18:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 85, 96 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/cwx3X92AzY",
      "expanded_url" : "http:\/\/go.wh.gov\/cGAp3R",
      "display_url" : "go.wh.gov\/cGAp3R"
    } ]
  },
  "geo" : { },
  "id_str" : "588765809339535362",
  "text" : "RT @WHLive: Tune in at 2:10pm ET: President Obama celebrates working families at the @WhiteHouse: http:\/\/t.co\/cwx3X92AzY #WorkingFamilyCham\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 73, 84 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WorkingFamilyChamps",
        "indices" : [ 109, 129 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/cwx3X92AzY",
        "expanded_url" : "http:\/\/go.wh.gov\/cGAp3R",
        "display_url" : "go.wh.gov\/cGAp3R"
      } ]
    },
    "geo" : { },
    "id_str" : "588765789999616001",
    "text" : "Tune in at 2:10pm ET: President Obama celebrates working families at the @WhiteHouse: http:\/\/t.co\/cwx3X92AzY #WorkingFamilyChamps",
    "id" : 588765789999616001,
    "created_at" : "2015-04-16 18:07:57 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 588765809339535362,
  "created_at" : "2015-04-16 18:08:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "ChuckGrassley",
      "screen_name" : "ChuckGrassley",
      "indices" : [ 50, 64 ],
      "id_str" : "10615232",
      "id" : 10615232
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588735778949238787",
  "text" : "RT @PressSec: Req'd reading for today's briefing: @ChuckGrassley urging POTUS not to confirm the next AG in the lame duck Senate. http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ChuckGrassley",
        "screen_name" : "ChuckGrassley",
        "indices" : [ 36, 50 ],
        "id_str" : "10615232",
        "id" : 10615232
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/dsyHyPjNQD",
        "expanded_url" : "http:\/\/bit.ly\/1DLXu5m",
        "display_url" : "bit.ly\/1DLXu5m"
      } ]
    },
    "geo" : { },
    "id_str" : "588734695111847936",
    "text" : "Req'd reading for today's briefing: @ChuckGrassley urging POTUS not to confirm the next AG in the lame duck Senate. http:\/\/t.co\/dsyHyPjNQD",
    "id" : 588734695111847936,
    "created_at" : "2015-04-16 16:04:24 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 588735778949238787,
  "created_at" : "2015-04-16 16:08:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SoldierRideDC",
      "indices" : [ 121, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588727421748125698",
  "text" : "RT @JoiningForces: \"You, and all the men and women our Armed Forces, represent America at its best.\" \u2014President Obama to #SoldierRideDC htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JoiningForces\/status\/588727229867102209\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/uasekgUT4X",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CCuUQ8HUEAA5l-P.png",
        "id_str" : "588727195037601792",
        "id" : 588727195037601792,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCuUQ8HUEAA5l-P.png",
        "sizes" : [ {
          "h" : 337,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 526,
          "resize" : "fit",
          "w" : 936
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 526,
          "resize" : "fit",
          "w" : 936
        } ],
        "display_url" : "pic.twitter.com\/uasekgUT4X"
      } ],
      "hashtags" : [ {
        "text" : "SoldierRideDC",
        "indices" : [ 102, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "588727229867102209",
    "text" : "\"You, and all the men and women our Armed Forces, represent America at its best.\" \u2014President Obama to #SoldierRideDC http:\/\/t.co\/uasekgUT4X",
    "id" : 588727229867102209,
    "created_at" : "2015-04-16 15:34:44 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 588727421748125698,
  "created_at" : "2015-04-16 15:35:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 97, 108 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SoldierRideDC",
      "indices" : [ 75, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588725106068688898",
  "text" : "RT @JoiningForces: \"We are truly among heroes.\" \u2014President Obama welcoming #SoldierRideDC to the @WhiteHouse",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 78, 89 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SoldierRideDC",
        "indices" : [ 56, 70 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "588725049311367168",
    "text" : "\"We are truly among heroes.\" \u2014President Obama welcoming #SoldierRideDC to the @WhiteHouse",
    "id" : 588725049311367168,
    "created_at" : "2015-04-16 15:26:04 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 588725106068688898,
  "created_at" : "2015-04-16 15:26:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 103, 114 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SoldierRideDC",
      "indices" : [ 81, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588722965623148546",
  "text" : "RT @JoiningForces: Today, we're honored to welcome the Wounded Warrior Project\u2019s #SoldierRideDC to the @WhiteHouse. Watch at 11:30am ET: ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 84, 95 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SoldierRideDC",
        "indices" : [ 62, 76 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/HGHmAA4d7Z",
        "expanded_url" : "http:\/\/go.wh.gov\/tRqbxg",
        "display_url" : "go.wh.gov\/tRqbxg"
      } ]
    },
    "geo" : { },
    "id_str" : "588718947115016194",
    "text" : "Today, we're honored to welcome the Wounded Warrior Project\u2019s #SoldierRideDC to the @WhiteHouse. Watch at 11:30am ET: http:\/\/t.co\/HGHmAA4d7Z",
    "id" : 588718947115016194,
    "created_at" : "2015-04-16 15:01:49 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 588722965623148546,
  "created_at" : "2015-04-16 15:17:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/588499373945827328\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/17M8h57and",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCrEsSDUIAE6TK8.jpg",
      "id_str" : "588498966364299265",
      "id" : 588498966364299265,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCrEsSDUIAE6TK8.jpg",
      "sizes" : [ {
        "h" : 1867,
        "resize" : "fit",
        "w" : 2800
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/17M8h57and"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/WxbrGcfK1J",
      "expanded_url" : "http:\/\/go.wh.gov\/ZLAQb6",
      "display_url" : "go.wh.gov\/ZLAQb6"
    } ]
  },
  "geo" : { },
  "id_str" : "588499373945827328",
  "text" : "\"I\u2019ve got two daughters. I expect them to be treated the same as somebody else\u2019s sons\" \u2014Obama: http:\/\/t.co\/WxbrGcfK1J http:\/\/t.co\/17M8h57and",
  "id" : 588499373945827328,
  "created_at" : "2015-04-16 00:29:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/588447828843737088\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/HM4C9u1XHU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCqV-kiUUAAqqNK.jpg",
      "id_str" : "588447603517313024",
      "id" : 588447603517313024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCqV-kiUUAAqqNK.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/HM4C9u1XHU"
    } ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 107, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588447828843737088",
  "text" : "On average, women who work full-time make just $0.78 for every $1 men earn.\n\nRT if you agree it's time for #EqualPay. http:\/\/t.co\/HM4C9u1XHU",
  "id" : 588447828843737088,
  "created_at" : "2015-04-15 21:04:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamaTownHall",
      "indices" : [ 123, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588432637166882817",
  "text" : "RT @vj44: President Obama's message to America's daughters: The world is wide open to you. There is nothing you can't do.\n\n#ObamaTownHall #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ObamaTownHall",
        "indices" : [ 113, 127 ]
      }, {
        "text" : "womenslives",
        "indices" : [ 128, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "588430680272441344",
    "text" : "President Obama's message to America's daughters: The world is wide open to you. There is nothing you can't do.\n\n#ObamaTownHall #womenslives",
    "id" : 588430680272441344,
    "created_at" : "2015-04-15 19:56:21 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 588432637166882817,
  "created_at" : "2015-04-15 20:04:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamaTownHall",
      "indices" : [ 103, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/XWQ2I8GmrF",
      "expanded_url" : "http:\/\/snpy.tv\/1axe5hi",
      "display_url" : "snpy.tv\/1axe5hi"
    } ]
  },
  "geo" : { },
  "id_str" : "588431270612316160",
  "text" : "\"That's part of the power of the internet, making sure people don't feel alone on these issues\" \u2014Obama #ObamaTownHall http:\/\/t.co\/XWQ2I8GmrF",
  "id" : 588431270612316160,
  "created_at" : "2015-04-15 19:58:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin Kotecki Vest",
      "screen_name" : "QueenofSpain",
      "indices" : [ 3, 16 ],
      "id_str" : "7234682",
      "id" : 7234682
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamaTownHall",
      "indices" : [ 84, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588428736309006336",
  "text" : "RT @QueenofSpain: Whole heartedly agreeing with POTUS on ACA as it saved my family  #ObamaTownHall",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ObamaTownHall",
        "indices" : [ 66, 80 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 34.25253985296374, -118.4721279407531 ]
    },
    "id_str" : "588427171162497025",
    "text" : "Whole heartedly agreeing with POTUS on ACA as it saved my family  #ObamaTownHall",
    "id" : 588427171162497025,
    "created_at" : "2015-04-15 19:42:24 +0000",
    "user" : {
      "name" : "Erin Kotecki Vest",
      "screen_name" : "QueenofSpain",
      "protected" : false,
      "id_str" : "7234682",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724705724169740288\/G4IfMkr-_normal.jpg",
      "id" : 7234682,
      "verified" : true
    }
  },
  "id" : 588428736309006336,
  "created_at" : "2015-04-15 19:48:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Kerman",
      "screen_name" : "smkscribe",
      "indices" : [ 3, 13 ],
      "id_str" : "478304869",
      "id" : 478304869
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588428117191987200",
  "text" : "RT @smkscribe: \"I've always said the most important office in a democracy is the office of the citizen. Community participation is critical\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "POTUS",
        "indices" : [ 128, 134 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "588427457172271105",
    "text" : "\"I've always said the most important office in a democracy is the office of the citizen. Community participation is critical.\" -#POTUS",
    "id" : 588427457172271105,
    "created_at" : "2015-04-15 19:43:32 +0000",
    "user" : {
      "name" : "Sarah Kerman",
      "screen_name" : "smkscribe",
      "protected" : false,
      "id_str" : "478304869",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711584669356191744\/CVx72uIu_normal.jpg",
      "id" : 478304869,
      "verified" : false
    }
  },
  "id" : 588428117191987200,
  "created_at" : "2015-04-15 19:46:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/588426874755289088\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/rUj62Xy3gY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCqDBY3VEAAb0MB.jpg",
      "id_str" : "588426761202896896",
      "id" : 588426761202896896,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCqDBY3VEAAb0MB.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/rUj62Xy3gY"
    } ],
    "hashtags" : [ {
      "text" : "ObamaTownHall",
      "indices" : [ 103, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588426874755289088",
  "text" : "\u201CHealth care can\u2019t be a privilege, it\u2019s got to be a right\u201D \u2014President Obama on the Affordable Care Act #ObamaTownHall http:\/\/t.co\/rUj62Xy3gY",
  "id" : 588426874755289088,
  "created_at" : "2015-04-15 19:41:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamaTownHall",
      "indices" : [ 112, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588424751275618306",
  "text" : "RT @WHLive: Watch President Obama respond to a question from a single mom about expanding access to child care. #ObamaTownHall http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ObamaTownHall",
        "indices" : [ 100, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/oNRfnO4wzA",
        "expanded_url" : "http:\/\/snpy.tv\/1FTm9qO",
        "display_url" : "snpy.tv\/1FTm9qO"
      } ]
    },
    "geo" : { },
    "id_str" : "588424699488538624",
    "text" : "Watch President Obama respond to a question from a single mom about expanding access to child care. #ObamaTownHall http:\/\/t.co\/oNRfnO4wzA",
    "id" : 588424699488538624,
    "created_at" : "2015-04-15 19:32:35 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 588424751275618306,
  "created_at" : "2015-04-15 19:32:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/588423627558662144\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/bbQa29CITX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCp_-dmUkAAYxc-.jpg",
      "id_str" : "588423412399247360",
      "id" : 588423412399247360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCp_-dmUkAAYxc-.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/bbQa29CITX"
    } ],
    "hashtags" : [ {
      "text" : "WomenInSTEM",
      "indices" : [ 83, 95 ]
    }, {
      "text" : "ObamaTownHall",
      "indices" : [ 97, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588423627558662144",
  "text" : "\u201CYou wouldn\u2019t field a team with just half the players.\u201D \u2014Obama on why we need more #WomenInSTEM. #ObamaTownHall http:\/\/t.co\/bbQa29CITX",
  "id" : 588423627558662144,
  "created_at" : "2015-04-15 19:28:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/588422258873348096\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/sjrA9H9Dy0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCp-wARUMAALEfq.jpg",
      "id_str" : "588422064496717824",
      "id" : 588422064496717824,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCp-wARUMAALEfq.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1250,
        "resize" : "fit",
        "w" : 2500
      } ],
      "display_url" : "pic.twitter.com\/sjrA9H9Dy0"
    } ],
    "hashtags" : [ {
      "text" : "ObamaTownHall",
      "indices" : [ 95, 109 ]
    }, {
      "text" : "TaxDay",
      "indices" : [ 110, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588422258873348096",
  "text" : "\u201CThat\u2019s going to make a big difference\u201D \u2014Obama on his plan to triple the child care tax credit #ObamaTownHall #TaxDay http:\/\/t.co\/sjrA9H9Dy0",
  "id" : 588422258873348096,
  "created_at" : "2015-04-15 19:22:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nerdy Wonka",
      "screen_name" : "NerdyWonka",
      "indices" : [ 3, 14 ],
      "id_str" : "325265073",
      "id" : 325265073
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588421172632530944",
  "text" : "RT @NerdyWonka: President Obama points out that investing in childcare and early education is a no brainer. For every $1 put in, we gain $7\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ObamaTownHall",
        "indices" : [ 125, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "588420817509163009",
    "text" : "President Obama points out that investing in childcare and early education is a no brainer. For every $1 put in, we gain $7. #ObamaTownHall",
    "id" : 588420817509163009,
    "created_at" : "2015-04-15 19:17:09 +0000",
    "user" : {
      "name" : "Nerdy Wonka",
      "screen_name" : "NerdyWonka",
      "protected" : false,
      "id_str" : "325265073",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3321150452\/91262959f936ac25c801242c6304d269_normal.jpeg",
      "id" : 325265073,
      "verified" : false
    }
  },
  "id" : 588421172632530944,
  "created_at" : "2015-04-15 19:18:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 101, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/sFutFX0MsE",
      "expanded_url" : "http:\/\/snpy.tv\/1EHkC5P",
      "display_url" : "snpy.tv\/1EHkC5P"
    } ]
  },
  "geo" : { },
  "id_str" : "588420308324917248",
  "text" : "\u201CThe reason we haven\u2019t gotten it done is because Republicans in Congress have blocked it.\u201D \u2014Obama on #EqualPay http:\/\/t.co\/sFutFX0MsE",
  "id" : 588420308324917248,
  "created_at" : "2015-04-15 19:15:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamaTownHall",
      "indices" : [ 97, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/rmh9s0JonQ",
      "expanded_url" : "http:\/\/snpy.tv\/1ax3naA",
      "display_url" : "snpy.tv\/1ax3naA"
    } ]
  },
  "geo" : { },
  "id_str" : "588419824218288128",
  "text" : "President Obama wants to hear from you: What can we do to make a difference for your family? Use #ObamaTownHall. http:\/\/t.co\/rmh9s0JonQ",
  "id" : 588419824218288128,
  "created_at" : "2015-04-15 19:13:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/588418845062234113\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/TjjmYgkVQF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCp7xQ5VIAEaf88.jpg",
      "id_str" : "588418787604504577",
      "id" : 588418787604504577,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCp7xQ5VIAEaf88.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/TjjmYgkVQF"
    } ],
    "hashtags" : [ {
      "text" : "ObamaTownHall",
      "indices" : [ 99, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588418845062234113",
  "text" : "\u201CThis should be a no-brainer\u2026two people doing the same job. They should get paid the same.\u201D \u2014Obama #ObamaTownHall http:\/\/t.co\/TjjmYgkVQF",
  "id" : 588418845062234113,
  "created_at" : "2015-04-15 19:09:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamaTownHall",
      "indices" : [ 90, 104 ]
    }, {
      "text" : "TaxDay",
      "indices" : [ 105, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/KT5RzeTMAI",
      "expanded_url" : "http:\/\/snpy.tv\/1EHh4QT",
      "display_url" : "snpy.tv\/1EHh4QT"
    } ]
  },
  "geo" : { },
  "id_str" : "588418260044943360",
  "text" : "President Obama on how his tax plan would cut taxes for 44 million middle-class families. #ObamaTownHall #TaxDay http:\/\/t.co\/KT5RzeTMAI",
  "id" : 588418260044943360,
  "created_at" : "2015-04-15 19:07:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamaTownHall",
      "indices" : [ 121, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588417341089648640",
  "text" : "\u201CWhat do you think would actually make a difference in the lives of middle-class families?\u201D \u2014President Obama\n\nShare with #ObamaTownHall.",
  "id" : 588417341089648640,
  "created_at" : "2015-04-15 19:03:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/588417087040688128\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/idpKeoYCr4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCp6HsXVAAAD71k.jpg",
      "id_str" : "588416973911949312",
      "id" : 588416973911949312,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCp6HsXVAAAD71k.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/idpKeoYCr4"
    } ],
    "hashtags" : [ {
      "text" : "TaxDay",
      "indices" : [ 90, 97 ]
    }, {
      "text" : "ObamaTownHall",
      "indices" : [ 98, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588417087040688128",
  "text" : "The GOP is \"pushing a new $270 billion tax cut for the top fraction of the top 1%\" \u2014Obama #TaxDay #ObamaTownHall http:\/\/t.co\/idpKeoYCr4",
  "id" : 588417087040688128,
  "created_at" : "2015-04-15 19:02:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamaTownHall",
      "indices" : [ 121, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588416327464853505",
  "text" : "RT @WHLive: \"That\u2019s who our tax code should benefit\u2014working Americans trying to get a leg up in the new economy.\" \u2014Obama #ObamaTownHall #Ta\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ObamaTownHall",
        "indices" : [ 109, 123 ]
      }, {
        "text" : "TaxDay",
        "indices" : [ 124, 131 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "588416302072467457",
    "text" : "\"That\u2019s who our tax code should benefit\u2014working Americans trying to get a leg up in the new economy.\" \u2014Obama #ObamaTownHall #TaxDay",
    "id" : 588416302072467457,
    "created_at" : "2015-04-15 18:59:13 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 588416327464853505,
  "created_at" : "2015-04-15 18:59:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/588416143552970752\/photo\/1",
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/LLaVGiloNM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCp5WSkUwAIHPSh.jpg",
      "id_str" : "588416125173547010",
      "id" : 588416125173547010,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCp5WSkUwAIHPSh.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/LLaVGiloNM"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 74, 87 ]
    }, {
      "text" : "ObamaTownHall",
      "indices" : [ 88, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588416143552970752",
  "text" : "\u201CIt\u2019s time we made it happen. America deserves a raise.\u201D \u2014President Obama #RaiseTheWage #ObamaTownHall http:\/\/t.co\/LLaVGiloNM",
  "id" : 588416143552970752,
  "created_at" : "2015-04-15 18:58:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/588415838400593920\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/Z4gjhecMeJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCp5ESrVEAAiUUm.jpg",
      "id_str" : "588415815965282304",
      "id" : 588415815965282304,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCp5ESrVEAAiUUm.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Z4gjhecMeJ"
    } ],
    "hashtags" : [ {
      "text" : "FreeCommunityCollege",
      "indices" : [ 94, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588415838400593920",
  "text" : "\"I want to bring down the cost of community college for responsible students to zero.\" \u2014Obama #FreeCommunityCollege http:\/\/t.co\/Z4gjhecMeJ",
  "id" : 588415838400593920,
  "created_at" : "2015-04-15 18:57:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamaTownHall",
      "indices" : [ 103, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588415693533552641",
  "text" : "\"I have always believed that when women succeed in this country, everybody succeeds.\" \u2014President Obama #ObamaTownHall",
  "id" : 588415693533552641,
  "created_at" : "2015-04-15 18:56:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/588415430772989953\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/zgX234wf50",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCp4rpUUMAMDX_H.jpg",
      "id_str" : "588415392546041859",
      "id" : 588415392546041859,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCp4rpUUMAMDX_H.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/zgX234wf50"
    } ],
    "hashtags" : [ {
      "text" : "ObamaTownHall",
      "indices" : [ 95, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588415430772989953",
  "text" : "\"More Americans know the security of health care because of...the Affordable Care Act.\" \u2014Obama #ObamaTownHall http:\/\/t.co\/zgX234wf50",
  "id" : 588415430772989953,
  "created_at" : "2015-04-15 18:55:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/588415049036775424\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/4jQJ2ue3Rz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCp4WS_UgAAswXX.jpg",
      "id_str" : "588415025775149056",
      "id" : 588415025775149056,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCp4WS_UgAAswXX.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/4jQJ2ue3Rz"
    } ],
    "hashtags" : [ {
      "text" : "ObamaTownHall",
      "indices" : [ 103, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588415049036775424",
  "text" : "\"Our businesses have created more than 12 million new jobs over the past five years.\" \u2014President Obama #ObamaTownHall http:\/\/t.co\/4jQJ2ue3Rz",
  "id" : 588415049036775424,
  "created_at" : "2015-04-15 18:54:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BlogHer",
      "screen_name" : "BlogHer",
      "indices" : [ 71, 79 ],
      "id_str" : "6753582",
      "id" : 6753582
    }, {
      "name" : "SheKnows",
      "screen_name" : "SheKnows",
      "indices" : [ 86, 95 ],
      "id_str" : "14297868",
      "id" : 14297868
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ks44\/status\/588406366735183872\/photo\/1",
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/OaHGA80gIO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCpwWYZUwAADNVB.jpg",
      "id_str" : "588406231133372416",
      "id" : 588406231133372416,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCpwWYZUwAADNVB.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/OaHGA80gIO"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/0tckXmtbXz",
      "expanded_url" : "http:\/\/go.wh.gov\/ObamaTownHall",
      "display_url" : "go.wh.gov\/ObamaTownHall"
    } ]
  },
  "geo" : { },
  "id_str" : "588414509577994240",
  "text" : "Watch live: President Obama hosts a town hall on working families with @BlogHer &amp; @SheKnows \u2192 http:\/\/t.co\/0tckXmtbXz http:\/\/t.co\/OaHGA80gIO",
  "id" : 588414509577994240,
  "created_at" : "2015-04-15 18:52:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/588404213501198337\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/PuHvAEvy2n",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCpuWQaUgAARfMM.jpg",
      "id_str" : "588404029966811136",
      "id" : 588404029966811136,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCpuWQaUgAARfMM.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/PuHvAEvy2n"
    } ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 16, 25 ]
    }, {
      "text" : "ObamaTownHall",
      "indices" : [ 41, 55 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/0tckXmtbXz",
      "expanded_url" : "http:\/\/go.wh.gov\/ObamaTownHall",
      "display_url" : "go.wh.gov\/ObamaTownHall"
    } ]
  },
  "geo" : { },
  "id_str" : "588404213501198337",
  "text" : "Questions about #EqualPay?\nWatch today's #ObamaTownHall and join the discussion at 2:35pm ET \u2192 http:\/\/t.co\/0tckXmtbXz http:\/\/t.co\/PuHvAEvy2n",
  "id" : 588404213501198337,
  "created_at" : "2015-04-15 18:11:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/588398525089583104\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/8SjfzG7mxI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCpo7JhUsAEHSBk.jpg",
      "id_str" : "588398066702528513",
      "id" : 588398066702528513,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCpo7JhUsAEHSBk.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/8SjfzG7mxI"
    } ],
    "hashtags" : [ {
      "text" : "OneBostonDay",
      "indices" : [ 104, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588398525089583104",
  "text" : "Two years later, Boston keeps showing us that in the face of evil, Americans will lift up what is good. #OneBostonDay http:\/\/t.co\/8SjfzG7mxI",
  "id" : 588398525089583104,
  "created_at" : "2015-04-15 17:48:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LisaStone",
      "screen_name" : "LisaStone",
      "indices" : [ 3, 13 ],
      "id_str" : "14178312",
      "id" : 14178312
    }, {
      "name" : "Monique",
      "screen_name" : "divascancook",
      "indices" : [ 53, 66 ],
      "id_str" : "29289234",
      "id" : 29289234
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "obamatownhall",
      "indices" : [ 101, 115 ]
    }, {
      "text" : "womenslives",
      "indices" : [ 116, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588396112777613313",
  "text" : "RT @LisaStone: One of the best food bloggers I know: @divascancook getting ready to ask questions at #obamatownhall #womenslives http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Monique",
        "screen_name" : "divascancook",
        "indices" : [ 38, 51 ],
        "id_str" : "29289234",
        "id" : 29289234
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/LisaStone\/status\/588393489135579137\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/kwQsx4VUDi",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CCpkXBsWIAAc3z7.jpg",
        "id_str" : "588393048079474688",
        "id" : 588393048079474688,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCpkXBsWIAAc3z7.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/kwQsx4VUDi"
      } ],
      "hashtags" : [ {
        "text" : "obamatownhall",
        "indices" : [ 86, 100 ]
      }, {
        "text" : "womenslives",
        "indices" : [ 101, 113 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "588393489135579137",
    "text" : "One of the best food bloggers I know: @divascancook getting ready to ask questions at #obamatownhall #womenslives http:\/\/t.co\/kwQsx4VUDi",
    "id" : 588393489135579137,
    "created_at" : "2015-04-15 17:28:34 +0000",
    "user" : {
      "name" : "LisaStone",
      "screen_name" : "LisaStone",
      "protected" : false,
      "id_str" : "14178312",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/514831859646074880\/ryATRfiS_normal.jpeg",
      "id" : 14178312,
      "verified" : true
    }
  },
  "id" : 588396112777613313,
  "created_at" : "2015-04-15 17:38:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BlogHer",
      "screen_name" : "BlogHer",
      "indices" : [ 3, 11 ],
      "id_str" : "6753582",
      "id" : 6753582
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 112, 121 ]
    }, {
      "text" : "ObamaTownHall",
      "indices" : [ 122, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/h6zw2uRI8g",
      "expanded_url" : "http:\/\/ow.ly\/LEulk",
      "display_url" : "ow.ly\/LEulk"
    } ]
  },
  "geo" : { },
  "id_str" : "588387018888974336",
  "text" : "RT @BlogHer: Tune In To Watch Lisa Stone Ask President Obama Your Questions Today! http:\/\/t.co\/h6zw2uRI8g -Momo #EqualPay #ObamaTownHall",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EqualPay",
        "indices" : [ 99, 108 ]
      }, {
        "text" : "ObamaTownHall",
        "indices" : [ 109, 123 ]
      } ],
      "urls" : [ {
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/h6zw2uRI8g",
        "expanded_url" : "http:\/\/ow.ly\/LEulk",
        "display_url" : "ow.ly\/LEulk"
      } ]
    },
    "geo" : { },
    "id_str" : "588380669245394946",
    "text" : "Tune In To Watch Lisa Stone Ask President Obama Your Questions Today! http:\/\/t.co\/h6zw2uRI8g -Momo #EqualPay #ObamaTownHall",
    "id" : 588380669245394946,
    "created_at" : "2015-04-15 16:37:37 +0000",
    "user" : {
      "name" : "BlogHer",
      "screen_name" : "BlogHer",
      "protected" : false,
      "id_str" : "6753582",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778931829957013504\/iYHtXHLJ_normal.jpg",
      "id" : 6753582,
      "verified" : true
    }
  },
  "id" : 588387018888974336,
  "created_at" : "2015-04-15 17:02:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jezebel",
      "screen_name" : "Jezebel",
      "indices" : [ 3, 11 ],
      "id_str" : "8192222",
      "id" : 8192222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/fhW02bNDNM",
      "expanded_url" : "http:\/\/bit.ly\/1DI1cgg",
      "display_url" : "bit.ly\/1DI1cgg"
    } ]
  },
  "geo" : { },
  "id_str" : "588372520056844288",
  "text" : "RT @Jezebel: President Obama will talk to BlogHer bloggers about equal pay and more http:\/\/t.co\/fhW02bNDNM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 93 ],
        "url" : "http:\/\/t.co\/fhW02bNDNM",
        "expanded_url" : "http:\/\/bit.ly\/1DI1cgg",
        "display_url" : "bit.ly\/1DI1cgg"
      } ]
    },
    "geo" : { },
    "id_str" : "588369253830631424",
    "text" : "President Obama will talk to BlogHer bloggers about equal pay and more http:\/\/t.co\/fhW02bNDNM",
    "id" : 588369253830631424,
    "created_at" : "2015-04-15 15:52:16 +0000",
    "user" : {
      "name" : "Jezebel",
      "screen_name" : "Jezebel",
      "protected" : false,
      "id_str" : "8192222",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/590580350532845568\/rLGWqV5a_normal.png",
      "id" : 8192222,
      "verified" : true
    }
  },
  "id" : 588372520056844288,
  "created_at" : "2015-04-15 16:05:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Ochsner",
      "screen_name" : "NickOchsnerWBTV",
      "indices" : [ 3, 19 ],
      "id_str" : "88822794",
      "id" : 88822794
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamaTownHall",
      "indices" : [ 87, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/6FRKj2kSZt",
      "expanded_url" : "http:\/\/bit.ly\/1CNAk9q",
      "display_url" : "bit.ly\/1CNAk9q"
    } ]
  },
  "geo" : { },
  "id_str" : "588369620932820992",
  "text" : "RT @NickOchsnerWBTV: So what's Obama doing in Charlotte today? Here's a preview of the #ObamaTownHall http:\/\/t.co\/6FRKj2kSZt.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ObamaTownHall",
        "indices" : [ 66, 80 ]
      } ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/6FRKj2kSZt",
        "expanded_url" : "http:\/\/bit.ly\/1CNAk9q",
        "display_url" : "bit.ly\/1CNAk9q"
      } ]
    },
    "geo" : { },
    "id_str" : "588357984373313536",
    "text" : "So what's Obama doing in Charlotte today? Here's a preview of the #ObamaTownHall http:\/\/t.co\/6FRKj2kSZt.",
    "id" : 588357984373313536,
    "created_at" : "2015-04-15 15:07:29 +0000",
    "user" : {
      "name" : "Nick Ochsner",
      "screen_name" : "NickOchsnerWBTV",
      "protected" : false,
      "id_str" : "88822794",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/591616432401555458\/h158tCGf_normal.jpg",
      "id" : 88822794,
      "verified" : true
    }
  },
  "id" : 588369620932820992,
  "created_at" : "2015-04-15 15:53:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/588363506946285568\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/dOXXGUQPkt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCpJbooUEAEeADL.jpg",
      "id_str" : "588363440437071873",
      "id" : 588363440437071873,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCpJbooUEAEeADL.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/dOXXGUQPkt"
    } ],
    "hashtags" : [ {
      "text" : "ObamaTownHall",
      "indices" : [ 95, 109 ]
    }, {
      "text" : "TaxDay",
      "indices" : [ 110, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588363506946285568",
  "text" : "Doing your taxes? The President's budget would cut taxes for 44 million middle-class families. #ObamaTownHall #TaxDay http:\/\/t.co\/dOXXGUQPkt",
  "id" : 588363506946285568,
  "created_at" : "2015-04-15 15:29:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mayor Marty Walsh",
      "screen_name" : "marty_walsh",
      "indices" : [ 3, 15 ],
      "id_str" : "77764733",
      "id" : 77764733
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/marty_walsh\/status\/588317258063224832\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/9hE1lvFrqQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCofbdEW4AAdv0I.jpg",
      "id_str" : "588317257845104640",
      "id" : 588317257845104640,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCofbdEW4AAdv0I.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/9hE1lvFrqQ"
    } ],
    "hashtags" : [ {
      "text" : "OneBostonDay",
      "indices" : [ 54, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588353327110295552",
  "text" : "RT @marty_walsh: We appreciate the strong support for #OneBostonDay - together, we are a stronger City. http:\/\/t.co\/9hE1lvFrqQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/marty_walsh\/status\/588317258063224832\/photo\/1",
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/9hE1lvFrqQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CCofbdEW4AAdv0I.jpg",
        "id_str" : "588317257845104640",
        "id" : 588317257845104640,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCofbdEW4AAdv0I.jpg",
        "sizes" : [ {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/9hE1lvFrqQ"
      } ],
      "hashtags" : [ {
        "text" : "OneBostonDay",
        "indices" : [ 37, 50 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "588317258063224832",
    "text" : "We appreciate the strong support for #OneBostonDay - together, we are a stronger City. http:\/\/t.co\/9hE1lvFrqQ",
    "id" : 588317258063224832,
    "created_at" : "2015-04-15 12:25:39 +0000",
    "user" : {
      "name" : "Mayor Marty Walsh",
      "screen_name" : "marty_walsh",
      "protected" : false,
      "id_str" : "77764733",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616696311857844224\/JFuutOER_normal.jpg",
      "id" : 77764733,
      "verified" : true
    }
  },
  "id" : 588353327110295552,
  "created_at" : "2015-04-15 14:48:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kori Schulman",
      "screen_name" : "ks44",
      "indices" : [ 3, 8 ],
      "id_str" : "369246180",
      "id" : 369246180
    }, {
      "name" : "SheKnows",
      "screen_name" : "SheKnows",
      "indices" : [ 56, 65 ],
      "id_str" : "14297868",
      "id" : 14297868
    }, {
      "name" : "BlogHer",
      "screen_name" : "BlogHer",
      "indices" : [ 72, 80 ],
      "id_str" : "6753582",
      "id" : 6753582
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ks44\/status\/588350116735549441\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/C8xkEATOAh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCo9TY9UEAA3awk.jpg",
      "id_str" : "588350104651698176",
      "id" : 588350104651698176,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCo9TY9UEAA3awk.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/C8xkEATOAh"
    } ],
    "hashtags" : [ {
      "text" : "ObamaTownHall",
      "indices" : [ 36, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588350268611239936",
  "text" : "RT @ks44: Getting ready for today's #ObamaTownHall with @SheKnows &amp; @BlogHer in Charlotte, NC. http:\/\/t.co\/C8xkEATOAh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "SheKnows",
        "screen_name" : "SheKnows",
        "indices" : [ 46, 55 ],
        "id_str" : "14297868",
        "id" : 14297868
      }, {
        "name" : "BlogHer",
        "screen_name" : "BlogHer",
        "indices" : [ 62, 70 ],
        "id_str" : "6753582",
        "id" : 6753582
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ks44\/status\/588350116735549441\/photo\/1",
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/C8xkEATOAh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CCo9TY9UEAA3awk.jpg",
        "id_str" : "588350104651698176",
        "id" : 588350104651698176,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCo9TY9UEAA3awk.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/C8xkEATOAh"
      } ],
      "hashtags" : [ {
        "text" : "ObamaTownHall",
        "indices" : [ 26, 40 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "588350116735549441",
    "text" : "Getting ready for today's #ObamaTownHall with @SheKnows &amp; @BlogHer in Charlotte, NC. http:\/\/t.co\/C8xkEATOAh",
    "id" : 588350116735549441,
    "created_at" : "2015-04-15 14:36:13 +0000",
    "user" : {
      "name" : "Kori Schulman",
      "screen_name" : "ks44",
      "protected" : false,
      "id_str" : "369246180",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/667876153793859584\/DV7HzP-1_normal.jpg",
      "id" : 369246180,
      "verified" : true
    }
  },
  "id" : 588350268611239936,
  "created_at" : "2015-04-15 14:36:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/588341548426854400\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/mSGtY5KAn6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCo1ZtcVIAAysSo.jpg",
      "id_str" : "588341417136693248",
      "id" : 588341417136693248,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCo1ZtcVIAAysSo.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/mSGtY5KAn6"
    } ],
    "hashtags" : [ {
      "text" : "ObamaTownHall",
      "indices" : [ 95, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/hBUwaPmOlG",
      "expanded_url" : "http:\/\/go.wh.gov\/EqualPayDay",
      "display_url" : "go.wh.gov\/EqualPayDay"
    } ]
  },
  "geo" : { },
  "id_str" : "588341548426854400",
  "text" : "RT if you agree: Our daughters should be treated the same as our sons \u2192 http:\/\/t.co\/hBUwaPmOlG #ObamaTownHall http:\/\/t.co\/mSGtY5KAn6",
  "id" : 588341548426854400,
  "created_at" : "2015-04-15 14:02:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 18, 27 ]
    }, {
      "text" : "ObamaTownHall",
      "indices" : [ 90, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/vvTZ1M5eId",
      "expanded_url" : "http:\/\/bher.co\/Iho4",
      "display_url" : "bher.co\/Iho4"
    } ]
  },
  "geo" : { },
  "id_str" : "588322008628330497",
  "text" : "Do you care about #EqualPay?\nPaid leave?\nChild care?\nYou're going to want to join today's #ObamaTownHall discussion \u2192 http:\/\/t.co\/vvTZ1M5eId",
  "id" : 588322008628330497,
  "created_at" : "2015-04-15 12:44:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/xi7y84G2Ua",
      "expanded_url" : "http:\/\/go.wh.gov\/GospelMusic",
      "display_url" : "go.wh.gov\/GospelMusic"
    } ]
  },
  "geo" : { },
  "id_str" : "588126932493082624",
  "text" : "\"Gospel songs are the songs of hope. Hope that we might rise above our failures &amp; disappointments.\" \u2014Obama\nListen in: http:\/\/t.co\/xi7y84G2Ua",
  "id" : 588126932493082624,
  "created_at" : "2015-04-14 23:49:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588126369441312771",
  "text" : "\"It still has an unmatched power to strike the deepest chord in all of us, touching people of all faiths and no faith.\" \u2014Obama on Gospel",
  "id" : 588126369441312771,
  "created_at" : "2015-04-14 23:47:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588126198217187328",
  "text" : "RT @WHLive: \"They sang songs of liberation, if not for their bodies in this world, then for their souls in the next.\" \u2014Obama on Gospel sung\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "588126177279270912",
    "text" : "\"They sang songs of liberation, if not for their bodies in this world, then for their souls in the next.\" \u2014Obama on Gospel sung by slaves",
    "id" : 588126177279270912,
    "created_at" : "2015-04-14 23:46:22 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 588126198217187328,
  "created_at" : "2015-04-14 23:46:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588126049030033408",
  "text" : "\u201CThe most beautiful expression of human experience born this side of the seas.\u201D \u2014Obama quoting W.E.B. Du Bois on slaves singing Gospel",
  "id" : 588126049030033408,
  "created_at" : "2015-04-14 23:45:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/588117459317739520\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/GDU3j7OsHW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CClpkzIWYAAR2EP.jpg",
      "id_str" : "588117307269996544",
      "id" : 588117307269996544,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CClpkzIWYAAR2EP.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1867,
        "resize" : "fit",
        "w" : 2800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/GDU3j7OsHW"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/xi7y84G2Ua",
      "expanded_url" : "http:\/\/go.wh.gov\/GospelMusic",
      "display_url" : "go.wh.gov\/GospelMusic"
    } ]
  },
  "geo" : { },
  "id_str" : "588125254012264448",
  "text" : "Watch live: President Obama hosts a Gospel music \"In Performance at the White House\" \u2192 http:\/\/t.co\/xi7y84G2Ua http:\/\/t.co\/GDU3j7OsHW",
  "id" : 588125254012264448,
  "created_at" : "2015-04-14 23:42:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/588119093284380672\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/r2jjiDMUqd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CClpupQW0AA1dK3.jpg",
      "id_str" : "588117476417916928",
      "id" : 588117476417916928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CClpupQW0AA1dK3.jpg",
      "sizes" : [ {
        "h" : 471,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1385,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1385,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 831,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/r2jjiDMUqd"
    } ],
    "hashtags" : [ {
      "text" : "EqualPayDay",
      "indices" : [ 103, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/x2v6fVmI5R",
      "expanded_url" : "https:\/\/medium.com\/@WhiteHouse\/asked-and-answered-sage-and-kerry-s-letter-on-equal-pay-2d7ed0baeb6d",
      "display_url" : "medium.com\/@WhiteHouse\/as\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "588119093284380672",
  "text" : "\"It is just not fair that women get paid less than men for the same job\" \u2014Sage\nhttps:\/\/t.co\/x2v6fVmI5R #EqualPayDay http:\/\/t.co\/r2jjiDMUqd",
  "id" : 588119093284380672,
  "created_at" : "2015-04-14 23:18:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPayDay",
      "indices" : [ 87, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/Av245pD3UP",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/9c33204c-cf0c-4e3b-8f24-034ba0611e18",
      "display_url" : "amp.twimg.com\/v\/9c33204c-cf0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "588104310577205248",
  "text" : "\"My bill was just an important first step in the fight for fair pay.\" \u2014Lilly Ledbetter #EqualPayDay\nhttps:\/\/t.co\/Av245pD3UP",
  "id" : 588104310577205248,
  "created_at" : "2015-04-14 22:19:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "indices" : [ 3, 13 ],
      "id_str" : "131144091",
      "id" : 131144091
    }, {
      "name" : "BlogHer",
      "screen_name" : "BlogHer",
      "indices" : [ 75, 83 ],
      "id_str" : "6753582",
      "id" : 6753582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/rCsbwiWKp5",
      "expanded_url" : "https:\/\/www.whitehouse.gov\/blog\/2015\/04\/14\/join-conversation-president-obama-s-town-hall-blogher-and-sheknows",
      "display_url" : "whitehouse.gov\/blog\/2015\/04\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "588082855676358657",
  "text" : "RT @Goldman44: Tomorrow you can join a conversation with the President and @blogher. We need your feedback here: https:\/\/t.co\/rCsbwiWKp5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BlogHer",
        "screen_name" : "BlogHer",
        "indices" : [ 60, 68 ],
        "id_str" : "6753582",
        "id" : 6753582
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 121 ],
        "url" : "https:\/\/t.co\/rCsbwiWKp5",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/blog\/2015\/04\/14\/join-conversation-president-obama-s-town-hall-blogher-and-sheknows",
        "display_url" : "whitehouse.gov\/blog\/2015\/04\/1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "588082337088479232",
    "text" : "Tomorrow you can join a conversation with the President and @blogher. We need your feedback here: https:\/\/t.co\/rCsbwiWKp5",
    "id" : 588082337088479232,
    "created_at" : "2015-04-14 20:52:09 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 588082855676358657,
  "created_at" : "2015-04-14 20:54:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/588079312168820736\/photo\/1",
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/kseIYPbv9V",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CClC6gpWgAI3Cqh.jpg",
      "id_str" : "588074799311781890",
      "id" : 588074799311781890,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CClC6gpWgAI3Cqh.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/kseIYPbv9V"
    } ],
    "hashtags" : [ {
      "text" : "EqualPayDay",
      "indices" : [ 84, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/SV33JH5eJI",
      "expanded_url" : "http:\/\/go.wh.gov\/pSq7mF",
      "display_url" : "go.wh.gov\/pSq7mF"
    } ]
  },
  "geo" : { },
  "id_str" : "588079312168820736",
  "text" : "Worth a read: 5 facts that help explain the gender pay gap \u2192 http:\/\/t.co\/SV33JH5eJI #EqualPayDay http:\/\/t.co\/kseIYPbv9V",
  "id" : 588079312168820736,
  "created_at" : "2015-04-14 20:40:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/588071841144696833\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/Hha4wEpkaP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCk-Q26WYAIdHwe.jpg",
      "id_str" : "588069685687640066",
      "id" : 588069685687640066,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCk-Q26WYAIdHwe.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1867,
        "resize" : "fit",
        "w" : 2800
      } ],
      "display_url" : "pic.twitter.com\/Hha4wEpkaP"
    } ],
    "hashtags" : [ {
      "text" : "EqualPayDay",
      "indices" : [ 92, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/hBUwaPmOlG",
      "expanded_url" : "http:\/\/go.wh.gov\/EqualPayDay",
      "display_url" : "go.wh.gov\/EqualPayDay"
    } ]
  },
  "geo" : { },
  "id_str" : "588071841144696833",
  "text" : "Happy Birthday, Lilly Ledbetter!\nThanks for fighting for equal pay \u2192 http:\/\/t.co\/hBUwaPmOlG #EqualPayDay http:\/\/t.co\/Hha4wEpkaP",
  "id" : 588071841144696833,
  "created_at" : "2015-04-14 20:10:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "indices" : [ 3, 11 ],
      "id_str" : "2382117350",
      "id" : 2382117350
    }, {
      "name" : "U.S. Surgeon General",
      "screen_name" : "Surgeon_General",
      "indices" : [ 67, 83 ],
      "id_str" : "455024343",
      "id" : 455024343
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 90, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588065269131653120",
  "text" : "RT @Deese44: Powerful conversation last week with President Obama, @Surgeon_General about #ActOnClimate and public health: https:\/\/t.co\/7bI\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "U.S. Surgeon General",
        "screen_name" : "Surgeon_General",
        "indices" : [ 54, 70 ],
        "id_str" : "455024343",
        "id" : 455024343
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 77, 90 ]
      } ],
      "urls" : [ {
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/7bIVgLQadz",
        "expanded_url" : "https:\/\/youtu.be\/Ml6-YepUY1A",
        "display_url" : "youtu.be\/Ml6-YepUY1A"
      } ]
    },
    "geo" : { },
    "id_str" : "588060660765888512",
    "text" : "Powerful conversation last week with President Obama, @Surgeon_General about #ActOnClimate and public health: https:\/\/t.co\/7bIVgLQadz",
    "id" : 588060660765888512,
    "created_at" : "2015-04-14 19:26:01 +0000",
    "user" : {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "protected" : false,
      "id_str" : "2382117350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656551411145027584\/ArrSlGUP_normal.jpg",
      "id" : 2382117350,
      "verified" : true
    }
  },
  "id" : 588065269131653120,
  "created_at" : "2015-04-14 19:44:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "indices" : [ 3, 12 ],
      "id_str" : "249722522",
      "id" : 249722522
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Cuba",
      "indices" : [ 52, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588061954801082368",
  "text" : "RT @rhodes44: Put simply, POTUS is acting to remove #Cuba from the State Sponsor of Terrorism list because Cuba is not a State Sponsor of T\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Cuba",
        "indices" : [ 38, 43 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "588058882938904579",
    "text" : "Put simply, POTUS is acting to remove #Cuba from the State Sponsor of Terrorism list because Cuba is not a State Sponsor of Terrorism",
    "id" : 588058882938904579,
    "created_at" : "2015-04-14 19:18:57 +0000",
    "user" : {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "protected" : false,
      "id_str" : "249722522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/700766726644850688\/1lytmnAl_normal.jpg",
      "id" : 249722522,
      "verified" : true
    }
  },
  "id" : 588061954801082368,
  "created_at" : "2015-04-14 19:31:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/588059204814053380\/photo\/1",
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/vTvscDvdjU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCk0qa1WAAAN8jm.jpg",
      "id_str" : "588059129710772224",
      "id" : 588059129710772224,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCk0qa1WAAAN8jm.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/vTvscDvdjU"
    } ],
    "hashtags" : [ {
      "text" : "EqualPayDay",
      "indices" : [ 87, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588059204814053380",
  "text" : "It's time for Republicans in Congress to help close the pay gap between men and women. #EqualPayDay http:\/\/t.co\/vTvscDvdjU",
  "id" : 588059204814053380,
  "created_at" : "2015-04-14 19:20:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth Warren",
      "screen_name" : "SenWarren",
      "indices" : [ 3, 13 ],
      "id_str" : "970207298",
      "id" : 970207298
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPayNow",
      "indices" : [ 108, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588045155036504064",
  "text" : "RT @SenWarren: Last year every GOP senator voted against the Paycheck Fairness Act. It's long past time for #EqualPayNow. http:\/\/t.co\/nabrm\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SenWarren\/status\/588042638009487361\/photo\/1",
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/nabrmFVbIg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CCklqcTUEAAWWhR.jpg",
        "id_str" : "588042637430493184",
        "id" : 588042637430493184,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCklqcTUEAAWWhR.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/nabrmFVbIg"
      } ],
      "hashtags" : [ {
        "text" : "EqualPayNow",
        "indices" : [ 93, 105 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "588042638009487361",
    "text" : "Last year every GOP senator voted against the Paycheck Fairness Act. It's long past time for #EqualPayNow. http:\/\/t.co\/nabrmFVbIg",
    "id" : 588042638009487361,
    "created_at" : "2015-04-14 18:14:24 +0000",
    "user" : {
      "name" : "Elizabeth Warren",
      "screen_name" : "SenWarren",
      "protected" : false,
      "id_str" : "970207298",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/722044174799777792\/bXaodRhx_normal.jpg",
      "id" : 970207298,
      "verified" : true
    }
  },
  "id" : 588045155036504064,
  "created_at" : "2015-04-14 18:24:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/TZYrXaBgQB",
      "expanded_url" : "http:\/\/go.wh.gov\/EqualPayDay",
      "display_url" : "go.wh.gov\/EqualPayDay"
    } ]
  },
  "geo" : { },
  "id_str" : "588042840627933185",
  "text" : "RT @vj44: It's 2015. Women should earn the same pay as men for the same work.  \n\nPeriod. \n\nRT if you agree: http:\/\/t.co\/TZYrXaBgQB\n\n#equalp\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "equalpayday",
        "indices" : [ 122, 134 ]
      } ],
      "urls" : [ {
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/TZYrXaBgQB",
        "expanded_url" : "http:\/\/go.wh.gov\/EqualPayDay",
        "display_url" : "go.wh.gov\/EqualPayDay"
      } ]
    },
    "geo" : { },
    "id_str" : "588042284756762624",
    "text" : "It's 2015. Women should earn the same pay as men for the same work.  \n\nPeriod. \n\nRT if you agree: http:\/\/t.co\/TZYrXaBgQB\n\n#equalpayday",
    "id" : 588042284756762624,
    "created_at" : "2015-04-14 18:13:00 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 588042840627933185,
  "created_at" : "2015-04-14 18:15:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kerry washington",
      "screen_name" : "kerrywashington",
      "indices" : [ 3, 19 ],
      "id_str" : "205302299",
      "id" : 205302299
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/kerrywashington\/status\/588022854060531715\/photo\/1",
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/E1LkcQWcil",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCkTqmsWEAMcF7j.jpg",
      "id_str" : "588022849010536451",
      "id" : 588022849010536451,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCkTqmsWEAMcF7j.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 900
      } ],
      "display_url" : "pic.twitter.com\/E1LkcQWcil"
    } ],
    "hashtags" : [ {
      "text" : "Ask4More",
      "indices" : [ 21, 30 ]
    }, {
      "text" : "EqualPayDay",
      "indices" : [ 81, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/E42qv4rjoJ",
      "expanded_url" : "http:\/\/levo.im\/levo4equalpay",
      "display_url" : "levo.im\/levo4equalpay"
    } ]
  },
  "geo" : { },
  "id_str" : "588040293624193024",
  "text" : "RT @kerrywashington: #Ask4More. Equal Pay for equal work. http:\/\/t.co\/E42qv4rjoJ #EqualPayDay http:\/\/t.co\/E1LkcQWcil",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/kerrywashington\/status\/588022854060531715\/photo\/1",
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/E1LkcQWcil",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CCkTqmsWEAMcF7j.jpg",
        "id_str" : "588022849010536451",
        "id" : 588022849010536451,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCkTqmsWEAMcF7j.jpg",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 900
        } ],
        "display_url" : "pic.twitter.com\/E1LkcQWcil"
      } ],
      "hashtags" : [ {
        "text" : "Ask4More",
        "indices" : [ 0, 9 ]
      }, {
        "text" : "EqualPayDay",
        "indices" : [ 60, 72 ]
      } ],
      "urls" : [ {
        "indices" : [ 37, 59 ],
        "url" : "http:\/\/t.co\/E42qv4rjoJ",
        "expanded_url" : "http:\/\/levo.im\/levo4equalpay",
        "display_url" : "levo.im\/levo4equalpay"
      } ]
    },
    "geo" : { },
    "id_str" : "588022854060531715",
    "text" : "#Ask4More. Equal Pay for equal work. http:\/\/t.co\/E42qv4rjoJ #EqualPayDay http:\/\/t.co\/E1LkcQWcil",
    "id" : 588022854060531715,
    "created_at" : "2015-04-14 16:55:48 +0000",
    "user" : {
      "name" : "kerry washington",
      "screen_name" : "kerrywashington",
      "protected" : false,
      "id_str" : "205302299",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778641930536284160\/3-m-BwGQ_normal.jpg",
      "id" : 205302299,
      "verified" : true
    }
  },
  "id" : 588040293624193024,
  "created_at" : "2015-04-14 18:05:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mashable",
      "screen_name" : "mashable",
      "indices" : [ 3, 12 ],
      "id_str" : "972651",
      "id" : 972651
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPayDay",
      "indices" : [ 107, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/5g9DgP94IV",
      "expanded_url" : "http:\/\/on.mash.to\/1aOEkjI",
      "display_url" : "on.mash.to\/1aOEkjI"
    } ]
  },
  "geo" : { },
  "id_str" : "588031594440589313",
  "text" : "RT @mashable: Women still make less than men, and it costs them billions every year http:\/\/t.co\/5g9DgP94IV #EqualPayDay http:\/\/t.co\/YoFmUOq\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/mashable\/status\/587992234768912385\/photo\/1",
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/YoFmUOq0do",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CCj30ngW4AAz_ma.jpg",
        "id_str" : "587992234701807616",
        "id" : 587992234701807616,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCj30ngW4AAz_ma.jpg",
        "sizes" : [ {
          "h" : 500,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/YoFmUOq0do"
      } ],
      "hashtags" : [ {
        "text" : "EqualPayDay",
        "indices" : [ 93, 105 ]
      } ],
      "urls" : [ {
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/5g9DgP94IV",
        "expanded_url" : "http:\/\/on.mash.to\/1aOEkjI",
        "display_url" : "on.mash.to\/1aOEkjI"
      } ]
    },
    "geo" : { },
    "id_str" : "587992234768912385",
    "text" : "Women still make less than men, and it costs them billions every year http:\/\/t.co\/5g9DgP94IV #EqualPayDay http:\/\/t.co\/YoFmUOq0do",
    "id" : 587992234768912385,
    "created_at" : "2015-04-14 14:54:07 +0000",
    "user" : {
      "name" : "Mashable",
      "screen_name" : "mashable",
      "protected" : false,
      "id_str" : "972651",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/760998040949841922\/XT79xzRT_normal.jpg",
      "id" : 972651,
      "verified" : true
    }
  },
  "id" : 588031594440589313,
  "created_at" : "2015-04-14 17:30:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "indices" : [ 3, 13 ],
      "id_str" : "1613223313",
      "id" : 1613223313
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPayDay",
      "indices" : [ 114, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588028170437324800",
  "text" : "RT @Cecilia44: Women make less than men in almost every field 4 years after graduation. It's time to change that. #EqualPayDay http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Cecilia44\/status\/588027483787788288\/photo\/1",
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/G6CyyxOfHn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CCkX4V6WIAEplAI.jpg",
        "id_str" : "588027483070537729",
        "id" : 588027483070537729,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCkX4V6WIAEplAI.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/G6CyyxOfHn"
      } ],
      "hashtags" : [ {
        "text" : "EqualPayDay",
        "indices" : [ 99, 111 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "588027483787788288",
    "text" : "Women make less than men in almost every field 4 years after graduation. It's time to change that. #EqualPayDay http:\/\/t.co\/G6CyyxOfHn",
    "id" : 588027483787788288,
    "created_at" : "2015-04-14 17:14:11 +0000",
    "user" : {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "protected" : false,
      "id_str" : "1613223313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000172019215\/ed65eda76f51213f91b33edbaa62054c_normal.jpeg",
      "id" : 1613223313,
      "verified" : true
    }
  },
  "id" : 588028170437324800,
  "created_at" : "2015-04-14 17:16:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPayDay",
      "indices" : [ 115, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588023834407739392",
  "text" : "RT @VP: Equal pay for equal work. It's common sense. It's also overdue. Let's close the gap &amp; let's do it now. #EqualPayDay http:\/\/t.co\/BEs\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/VP\/status\/588022956812533760\/photo\/1",
        "indices" : [ 120, 142 ],
        "url" : "http:\/\/t.co\/BEsIsVV3eB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CCkTw2GWMAAozRu.jpg",
        "id_str" : "588022956225343488",
        "id" : 588022956225343488,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCkTw2GWMAAozRu.jpg",
        "sizes" : [ {
          "h" : 500,
          "resize" : "fit",
          "w" : 499
        }, {
          "h" : 341,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 499
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 499
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/BEsIsVV3eB"
      } ],
      "hashtags" : [ {
        "text" : "EqualPayDay",
        "indices" : [ 107, 119 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "588022956812533760",
    "text" : "Equal pay for equal work. It's common sense. It's also overdue. Let's close the gap &amp; let's do it now. #EqualPayDay http:\/\/t.co\/BEsIsVV3eB",
    "id" : 588022956812533760,
    "created_at" : "2015-04-14 16:56:12 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 588023834407739392,
  "created_at" : "2015-04-14 16:59:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "indices" : [ 3, 15 ],
      "id_str" : "369232105",
      "id" : 369232105
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPayDay",
      "indices" : [ 121, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588019181595033600",
  "text" : "RT @PAniskoff44: On avg women who work full-time earn just $0.78 for every $1 dollar men earn. It's time to change that. #EqualPayDay http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PAniskoff44\/status\/588018066488958978\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/tytiLndBSI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CCkPIAcW0AMqcTc.jpg",
        "id_str" : "588017856580866051",
        "id" : 588017856580866051,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCkPIAcW0AMqcTc.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 614,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 614,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 326,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/tytiLndBSI"
      } ],
      "hashtags" : [ {
        "text" : "EqualPayDay",
        "indices" : [ 104, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "588018066488958978",
    "text" : "On avg women who work full-time earn just $0.78 for every $1 dollar men earn. It's time to change that. #EqualPayDay http:\/\/t.co\/tytiLndBSI",
    "id" : 588018066488958978,
    "created_at" : "2015-04-14 16:36:46 +0000",
    "user" : {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "protected" : false,
      "id_str" : "369232105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623146355767140352\/58sqoVrw_normal.jpg",
      "id" : 369232105,
      "verified" : true
    }
  },
  "id" : 588019181595033600,
  "created_at" : "2015-04-14 16:41:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 37, 46 ]
    }, {
      "text" : "EqualPayDay",
      "indices" : [ 82, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/hBUwaPEpde",
      "expanded_url" : "http:\/\/go.wh.gov\/EqualPayDay",
      "display_url" : "go.wh.gov\/EqualPayDay"
    } ]
  },
  "geo" : { },
  "id_str" : "588015629950590976",
  "text" : "RT if you agree: It's time to ensure #EqualPay for women \u2192 http:\/\/t.co\/hBUwaPEpde #EqualPayDay",
  "id" : 588015629950590976,
  "created_at" : "2015-04-14 16:27:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/588007639344226304\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/XrgzlMgdkE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCkFgjaWAAAB1Ru.jpg",
      "id_str" : "588007283168247808",
      "id" : 588007283168247808,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCkFgjaWAAAB1Ru.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/XrgzlMgdkE"
    } ],
    "hashtags" : [ {
      "text" : "EqualPayDay",
      "indices" : [ 103, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588007639344226304",
  "text" : "On average, women who work full-time earn just $0.78 for every $1 men earn.\n\nIt's time to change that. #EqualPayDay http:\/\/t.co\/XrgzlMgdkE",
  "id" : 588007639344226304,
  "created_at" : "2015-04-14 15:55:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/588001967047184384\/photo\/1",
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/CishGOr942",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCkAjgXWEAEsIkv.jpg",
      "id_str" : "588001836331831297",
      "id" : 588001836331831297,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCkAjgXWEAEsIkv.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/CishGOr942"
    } ],
    "hashtags" : [ {
      "text" : "EqualPayDay",
      "indices" : [ 82, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "588001967047184384",
  "text" : "It's 2015.\nWomen should earn the same pay as men for doing the same work.\nPeriod.\n#EqualPayDay http:\/\/t.co\/CishGOr942",
  "id" : 588001967047184384,
  "created_at" : "2015-04-14 15:32:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "George Takei",
      "screen_name" : "GeorgeTakei",
      "indices" : [ 3, 15 ],
      "id_str" : "237845487",
      "id" : 237845487
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPayDay",
      "indices" : [ 26, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "587996876680601600",
  "text" : "RT @GeorgeTakei: Today is #EqualPayDay. Equal pay is essential. Guys, imagine if you'd worked since Jan 1 but are only now starting to get \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ads.twitter.com\" rel=\"nofollow\"\u003ETwitter Ads\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EqualPayDay",
        "indices" : [ 9, 21 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "587995481692704769",
    "text" : "Today is #EqualPayDay. Equal pay is essential. Guys, imagine if you'd worked since Jan 1 but are only now starting to get paid for it",
    "id" : 587995481692704769,
    "created_at" : "2015-04-14 15:07:01 +0000",
    "user" : {
      "name" : "George Takei",
      "screen_name" : "GeorgeTakei",
      "protected" : false,
      "id_str" : "237845487",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/700355030117937152\/3uW9IKHD_normal.png",
      "id" : 237845487,
      "verified" : true
    }
  },
  "id" : 587996876680601600,
  "created_at" : "2015-04-14 15:12:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "indices" : [ 3, 15 ],
      "id_str" : "15764644",
      "id" : 15764644
    }, {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "indices" : [ 47, 56 ],
      "id_str" : "1604366701",
      "id" : 1604366701
    }, {
      "name" : "Rosa DeLauro",
      "screen_name" : "rosadelauro",
      "indices" : [ 58, 70 ],
      "id_str" : "140519774",
      "id" : 140519774
    }, {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 77, 82 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPayDay",
      "indices" : [ 23, 35 ]
    }, {
      "text" : "EqualPayNow",
      "indices" : [ 103, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "587994655083597825",
  "text" : "RT @NancyPelosi: Happy #EqualPayDay! Will join @LaborSec, @rosadelauro &amp; @VJ44 to discuss need for #EqualPayNow. Tune in at 11:00 AM \u2192 http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tom Perez",
        "screen_name" : "LaborSec",
        "indices" : [ 30, 39 ],
        "id_str" : "1604366701",
        "id" : 1604366701
      }, {
        "name" : "Rosa DeLauro",
        "screen_name" : "rosadelauro",
        "indices" : [ 41, 53 ],
        "id_str" : "140519774",
        "id" : 140519774
      }, {
        "name" : "Valerie Jarrett",
        "screen_name" : "vj44",
        "indices" : [ 60, 65 ],
        "id_str" : "595515713",
        "id" : 595515713
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EqualPayDay",
        "indices" : [ 6, 18 ]
      }, {
        "text" : "EqualPayNow",
        "indices" : [ 86, 98 ]
      } ],
      "urls" : [ {
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/4nGTklWxfx",
        "expanded_url" : "http:\/\/www.dol.gov\/live",
        "display_url" : "dol.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "587993652904996865",
    "text" : "Happy #EqualPayDay! Will join @LaborSec, @rosadelauro &amp; @VJ44 to discuss need for #EqualPayNow. Tune in at 11:00 AM \u2192 http:\/\/t.co\/4nGTklWxfx",
    "id" : 587993652904996865,
    "created_at" : "2015-04-14 14:59:45 +0000",
    "user" : {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "protected" : false,
      "id_str" : "15764644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571313158510223360\/wnSl3yXF_normal.jpeg",
      "id" : 15764644,
      "verified" : true
    }
  },
  "id" : 587994655083597825,
  "created_at" : "2015-04-14 15:03:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPayDay",
      "indices" : [ 82, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "587988684835790848",
  "text" : "RT @vj44: Happy birthday to my friend Lilly Ledbetter! Coincidence that it's also #EqualPayDay. She's our inspiration to keep pushing. #wom\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EqualPayDay",
        "indices" : [ 72, 84 ]
      }, {
        "text" : "womensucceed",
        "indices" : [ 125, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "587981965120315393",
    "text" : "Happy birthday to my friend Lilly Ledbetter! Coincidence that it's also #EqualPayDay. She's our inspiration to keep pushing. #womensucceed",
    "id" : 587981965120315393,
    "created_at" : "2015-04-14 14:13:19 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 587988684835790848,
  "created_at" : "2015-04-14 14:40:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    }, {
      "name" : "The Plain Dealer",
      "screen_name" : "ThePlainDealer",
      "indices" : [ 14, 29 ],
      "id_str" : "83894904",
      "id" : 83894904
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FairTrade",
      "indices" : [ 108, 118 ]
    }, {
      "text" : "FixNAFTA",
      "indices" : [ 119, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/YYr5RpEhgz",
      "expanded_url" : "http:\/\/bit.ly\/1I7xt00",
      "display_url" : "bit.ly\/1I7xt00"
    } ]
  },
  "geo" : { },
  "id_str" : "587982499898388480",
  "text" : "RT @Simas44: .@ThePlainDealer on how Obama trade agreements fix problems with NAFTA. http:\/\/t.co\/YYr5RpEhgz #FairTrade #FixNAFTA #WorkersFi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Plain Dealer",
        "screen_name" : "ThePlainDealer",
        "indices" : [ 1, 16 ],
        "id_str" : "83894904",
        "id" : 83894904
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FairTrade",
        "indices" : [ 95, 105 ]
      }, {
        "text" : "FixNAFTA",
        "indices" : [ 106, 115 ]
      }, {
        "text" : "WorkersFirst",
        "indices" : [ 116, 129 ]
      } ],
      "urls" : [ {
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/YYr5RpEhgz",
        "expanded_url" : "http:\/\/bit.ly\/1I7xt00",
        "display_url" : "bit.ly\/1I7xt00"
      } ]
    },
    "geo" : { },
    "id_str" : "587978979274989572",
    "text" : ".@ThePlainDealer on how Obama trade agreements fix problems with NAFTA. http:\/\/t.co\/YYr5RpEhgz #FairTrade #FixNAFTA #WorkersFirst",
    "id" : 587978979274989572,
    "created_at" : "2015-04-14 14:01:27 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 587982499898388480,
  "created_at" : "2015-04-14 14:15:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/587973927206522880\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/WDfzp0Q15o",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCjnJbkW8AA-ZVF.jpg",
      "id_str" : "587973900576944128",
      "id" : 587973900576944128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCjnJbkW8AA-ZVF.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/WDfzp0Q15o"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/WURIWZlecu",
      "expanded_url" : "http:\/\/go.wh.gov\/VsZ2Xw",
      "display_url" : "go.wh.gov\/VsZ2Xw"
    } ]
  },
  "geo" : { },
  "id_str" : "587973927206522880",
  "text" : "It's almost Tax Day: See how the President's budget would cut taxes for millions of families: http:\/\/t.co\/WURIWZlecu http:\/\/t.co\/WDfzp0Q15o",
  "id" : 587973927206522880,
  "created_at" : "2015-04-14 13:41:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DC",
      "indices" : [ 105, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "587796013760536578",
  "text" : "RT @Interior: Ending the day with this gorgeous pic of cherry blossoms next to the Jefferson Memorial in #DC by Andrew Geraci http:\/\/t.co\/2\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/587789043762655232\/photo\/1",
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/2VTKi1ZEgB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CCg_AMZUAAMkl8E.jpg",
        "id_str" : "587789023931793411",
        "id" : 587789023931793411,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCg_AMZUAAMkl8E.jpg",
        "sizes" : [ {
          "h" : 536,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 178,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 314,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 536,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/2VTKi1ZEgB"
      } ],
      "hashtags" : [ {
        "text" : "DC",
        "indices" : [ 91, 94 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "587789043762655232",
    "text" : "Ending the day with this gorgeous pic of cherry blossoms next to the Jefferson Memorial in #DC by Andrew Geraci http:\/\/t.co\/2VTKi1ZEgB",
    "id" : 587789043762655232,
    "created_at" : "2015-04-14 01:26:43 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 587796013760536578,
  "created_at" : "2015-04-14 01:54:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "587790675711668224",
  "text" : "RT @Simas44: ACA repealers response to historic drop in uninsured? \"But what about costs?\" What's the response to this chart? http:\/\/t.co\/k\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Simas44\/status\/587778684464996352\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/knFLlGKb5y",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CCg1mSxUkAEztRt.png",
        "id_str" : "587778683361857537",
        "id" : 587778683361857537,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCg1mSxUkAEztRt.png",
        "sizes" : [ {
          "h" : 369,
          "resize" : "fit",
          "w" : 637
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 197,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 348,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 369,
          "resize" : "fit",
          "w" : 637
        } ],
        "display_url" : "pic.twitter.com\/knFLlGKb5y"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "587778684464996352",
    "text" : "ACA repealers response to historic drop in uninsured? \"But what about costs?\" What's the response to this chart? http:\/\/t.co\/knFLlGKb5y",
    "id" : 587778684464996352,
    "created_at" : "2015-04-14 00:45:33 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 587790675711668224,
  "created_at" : "2015-04-14 01:33:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/587777198465150976\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/eL7yQdLjIx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCgy83AW8AAcAT9.jpg",
      "id_str" : "587775772510842880",
      "id" : 587775772510842880,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCgy83AW8AAcAT9.jpg",
      "sizes" : [ {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      } ],
      "display_url" : "pic.twitter.com\/eL7yQdLjIx"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/8oMBTRN6Zh",
      "expanded_url" : "http:\/\/go.wh.gov\/in-photos",
      "display_url" : "go.wh.gov\/in-photos"
    } ]
  },
  "geo" : { },
  "id_str" : "587777198465150976",
  "text" : "\u201CNobody\u2019s ever been faster than this guy. Ever.\u201D \u2014President Obama on Usain Bolt: http:\/\/t.co\/8oMBTRN6Zh http:\/\/t.co\/eL7yQdLjIx",
  "id" : 587777198465150976,
  "created_at" : "2015-04-14 00:39:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "587767922178723841",
  "text" : "RT @Simas44: Next time someone proposes repealing the ACA, can someone ask them whether this chart supports their argument? http:\/\/t.co\/Lxe\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Simas44\/status\/587767563792224257\/photo\/1",
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/Lxez10Ud2p",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CCgre_YWEAE8lAM.png",
        "id_str" : "587767562781462529",
        "id" : 587767562781462529,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCgre_YWEAE8lAM.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 278,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 404,
          "resize" : "fit",
          "w" : 494
        }, {
          "h" : 404,
          "resize" : "fit",
          "w" : 494
        }, {
          "h" : 404,
          "resize" : "fit",
          "w" : 494
        } ],
        "display_url" : "pic.twitter.com\/Lxez10Ud2p"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "587767563792224257",
    "text" : "Next time someone proposes repealing the ACA, can someone ask them whether this chart supports their argument? http:\/\/t.co\/Lxez10Ud2p",
    "id" : 587767563792224257,
    "created_at" : "2015-04-14 00:01:22 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 587767922178723841,
  "created_at" : "2015-04-14 00:02:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "indices" : [ 3, 13 ],
      "id_str" : "131144091",
      "id" : 131144091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "587763121571282945",
  "text" : "RT @Goldman44: Hello Pfeiffer pfollowers and welcome! I just started as White House Chief Digital Officer. And I'm excited to hang out with\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "587762910216253440",
    "text" : "Hello Pfeiffer pfollowers and welcome! I just started as White House Chief Digital Officer. And I'm excited to hang out with y'all here.",
    "id" : 587762910216253440,
    "created_at" : "2015-04-13 23:42:52 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 587763121571282945,
  "created_at" : "2015-04-13 23:43:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/587752015570296833\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/IQhteQyQxt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCgcj9jWAAAohul.jpg",
      "id_str" : "587751155515654144",
      "id" : 587751155515654144,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCgcj9jWAAAohul.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/IQhteQyQxt"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/WURIWZlecu",
      "expanded_url" : "http:\/\/go.wh.gov\/VsZ2Xw",
      "display_url" : "go.wh.gov\/VsZ2Xw"
    } ]
  },
  "geo" : { },
  "id_str" : "587752015570296833",
  "text" : "Doing your taxes?\nThe President's budget would cut taxes for 44 million middle-class families: http:\/\/t.co\/WURIWZlecu http:\/\/t.co\/IQhteQyQxt",
  "id" : 587752015570296833,
  "created_at" : "2015-04-13 22:59:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Bob Inglis",
      "screen_name" : "bobinglis",
      "indices" : [ 52, 62 ],
      "id_str" : "16721061",
      "id" : 16721061
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ProfileInCourage",
      "indices" : [ 20, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "587738473404194816",
  "text" : "RT @VP: This year\u2019s #ProfileInCourage award goes to @bobinglis, who confronted climate deniers and showed us how politics could work. @JFKL\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bob Inglis",
        "screen_name" : "bobinglis",
        "indices" : [ 44, 54 ],
        "id_str" : "16721061",
        "id" : 16721061
      }, {
        "name" : "JFK Library",
        "screen_name" : "JFKLibrary",
        "indices" : [ 126, 137 ],
        "id_str" : "32520240",
        "id" : 32520240
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ProfileInCourage",
        "indices" : [ 12, 29 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "587737224113885184",
    "text" : "This year\u2019s #ProfileInCourage award goes to @bobinglis, who confronted climate deniers and showed us how politics could work. @JFKLibrary",
    "id" : 587737224113885184,
    "created_at" : "2015-04-13 22:00:48 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 587738473404194816,
  "created_at" : "2015-04-13 22:05:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dept. of Agriculture",
      "screen_name" : "USDA",
      "indices" : [ 3, 8 ],
      "id_str" : "61853389",
      "id" : 61853389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/8hsnJAz0Iz",
      "expanded_url" : "http:\/\/ow.ly\/Ly18u",
      "display_url" : "ow.ly\/Ly18u"
    } ]
  },
  "geo" : { },
  "id_str" : "587712047908958208",
  "text" : "RT @USDA: We believe that all children -- no matter where they live -- should have an opportunity to succeed. http:\/\/t.co\/8hsnJAz0Iz #Serve\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ServeRural",
        "indices" : [ 123, 134 ]
      } ],
      "urls" : [ {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/8hsnJAz0Iz",
        "expanded_url" : "http:\/\/ow.ly\/Ly18u",
        "display_url" : "ow.ly\/Ly18u"
      } ]
    },
    "geo" : { },
    "id_str" : "587662841878028289",
    "text" : "We believe that all children -- no matter where they live -- should have an opportunity to succeed. http:\/\/t.co\/8hsnJAz0Iz #ServeRural",
    "id" : 587662841878028289,
    "created_at" : "2015-04-13 17:05:14 +0000",
    "user" : {
      "name" : "Dept. of Agriculture",
      "screen_name" : "USDA",
      "protected" : false,
      "id_str" : "61853389",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3475696751\/bf524afc612e7aa534d6c543a3d3e144_normal.jpeg",
      "id" : 61853389,
      "verified" : true
    }
  },
  "id" : 587712047908958208,
  "created_at" : "2015-04-13 20:20:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chuck Schumer",
      "screen_name" : "SenSchumer",
      "indices" : [ 3, 14 ],
      "id_str" : "17494010",
      "id" : 17494010
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MiddleClassEconomics",
      "indices" : [ 107, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "587706476413657088",
  "text" : "RT @SenSchumer: With Tax Day approaching, I'm fighting to put money back in the hands of working families. #MiddleClassEconomics http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SenSchumer\/status\/587692270973014016\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/P4sYDIeyj6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CCfnAFKUkAAfcJb.png",
        "id_str" : "587692264966623232",
        "id" : 587692264966623232,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCfnAFKUkAAfcJb.png",
        "sizes" : [ {
          "h" : 473,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 666,
          "resize" : "fit",
          "w" : 844
        }, {
          "h" : 666,
          "resize" : "fit",
          "w" : 844
        }, {
          "h" : 268,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/P4sYDIeyj6"
      } ],
      "hashtags" : [ {
        "text" : "MiddleClassEconomics",
        "indices" : [ 91, 112 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "587692270973014016",
    "text" : "With Tax Day approaching, I'm fighting to put money back in the hands of working families. #MiddleClassEconomics http:\/\/t.co\/P4sYDIeyj6",
    "id" : 587692270973014016,
    "created_at" : "2015-04-13 19:02:10 +0000",
    "user" : {
      "name" : "Chuck Schumer",
      "screen_name" : "SenSchumer",
      "protected" : false,
      "id_str" : "17494010",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623955176131575808\/zWzgRP4C_normal.jpg",
      "id" : 17494010,
      "verified" : true
    }
  },
  "id" : 587706476413657088,
  "created_at" : "2015-04-13 19:58:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USTR",
      "screen_name" : "USTradeRep",
      "indices" : [ 3, 14 ],
      "id_str" : "44615672",
      "id" : 44615672
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UnitedStatesofTrade",
      "indices" : [ 16, 36 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/8QnIHXQHO1",
      "expanded_url" : "http:\/\/ustr.gov\/unitedstatesoftrade",
      "display_url" : "ustr.gov\/unitedstatesof\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "587688691902058496",
  "text" : "RT @USTradeRep: #UnitedStatesofTrade 50 stories in 50 states that show the impact of trade across the nation \u2192 http:\/\/t.co\/8QnIHXQHO1 http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/USTradeRep\/status\/586162916853841920\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/p2JirIFtSQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CCHj8uwWIAAxzRx.png",
        "id_str" : "586000059017338880",
        "id" : 586000059017338880,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCHj8uwWIAAxzRx.png",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/p2JirIFtSQ"
      } ],
      "hashtags" : [ {
        "text" : "UnitedStatesofTrade",
        "indices" : [ 0, 20 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/8QnIHXQHO1",
        "expanded_url" : "http:\/\/ustr.gov\/unitedstatesoftrade",
        "display_url" : "ustr.gov\/unitedstatesof\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "586162916853841920",
    "text" : "#UnitedStatesofTrade 50 stories in 50 states that show the impact of trade across the nation \u2192 http:\/\/t.co\/8QnIHXQHO1 http:\/\/t.co\/p2JirIFtSQ",
    "id" : 586162916853841920,
    "created_at" : "2015-04-09 13:45:04 +0000",
    "user" : {
      "name" : "USTR",
      "screen_name" : "USTradeRep",
      "protected" : false,
      "id_str" : "44615672",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662636758509596672\/O-ShXHZB_normal.png",
      "id" : 44615672,
      "verified" : true
    }
  },
  "id" : 587688691902058496,
  "created_at" : "2015-04-13 18:47:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LeelahsLaw",
      "indices" : [ 79, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/vmYIyLnqhf",
      "expanded_url" : "https:\/\/youtu.be\/mv2N0hYPAwY",
      "display_url" : "youtu.be\/mv2N0hYPAwY"
    } ]
  },
  "geo" : { },
  "id_str" : "587682288239906816",
  "text" : "RT if you agree: It's time to ban conversion therapy \u2192 https:\/\/t.co\/vmYIyLnqhf #LeelahsLaw",
  "id" : 587682288239906816,
  "created_at" : "2015-04-13 18:22:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/VP\/status\/587660865505140737\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/RdJAHMUdCy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCfKcVvVEAIan9m.jpg",
      "id_str" : "587660864615944194",
      "id" : 587660864615944194,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCfKcVvVEAIan9m.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/RdJAHMUdCy"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "587663672966836224",
  "text" : "RT @VP: \"We have increased production in renewable energy\u2014in solar and wind\u2014here at home.\" -VP Biden speaking now http:\/\/t.co\/RdJAHMUdCy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/587660865505140737\/photo\/1",
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/RdJAHMUdCy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CCfKcVvVEAIan9m.jpg",
        "id_str" : "587660864615944194",
        "id" : 587660864615944194,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCfKcVvVEAIan9m.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/RdJAHMUdCy"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "587660865505140737",
    "text" : "\"We have increased production in renewable energy\u2014in solar and wind\u2014here at home.\" -VP Biden speaking now http:\/\/t.co\/RdJAHMUdCy",
    "id" : 587660865505140737,
    "created_at" : "2015-04-13 16:57:23 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 587663672966836224,
  "created_at" : "2015-04-13 17:08:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 45, 55 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/587651575872499712\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/5wXJMZhVPB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCfBA1HW0AA_LQ7.jpg",
      "id_str" : "587650496397234176",
      "id" : 587650496397234176,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCfBA1HW0AA_LQ7.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1867,
        "resize" : "fit",
        "w" : 2800
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/5wXJMZhVPB"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/10jcsv3ZlQ",
      "expanded_url" : "https:\/\/medium.com\/@WhiteHouse\/behind-the-lens-somewhere-under-the-rainbow-c61928816cfd",
      "display_url" : "medium.com\/@WhiteHouse\/be\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "587651575872499712",
  "text" : "Why are there so many photos about rainbows?\n@PeteSouza takes you behind the lens \u2192 https:\/\/t.co\/10jcsv3ZlQ http:\/\/t.co\/5wXJMZhVPB",
  "id" : 587651575872499712,
  "created_at" : "2015-04-13 16:20:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BetterWithObamacare",
      "indices" : [ 101, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/YAeE4mjoUL",
      "expanded_url" : "http:\/\/huff.to\/1NwKbfn",
      "display_url" : "huff.to\/1NwKbfn"
    } ]
  },
  "geo" : { },
  "id_str" : "587643918306693120",
  "text" : "The uninsured rate is getting lower and lower under the Affordable Care Act \u2192 http:\/\/t.co\/YAeE4mjoUL #BetterWithObamacare",
  "id" : 587643918306693120,
  "created_at" : "2015-04-13 15:50:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LisaStone",
      "screen_name" : "LisaStone",
      "indices" : [ 3, 13 ],
      "id_str" : "14178312",
      "id" : 14178312
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPayDay",
      "indices" : [ 56, 68 ]
    }, {
      "text" : "TaxDay",
      "indices" : [ 70, 77 ]
    }, {
      "text" : "ObamaTownHall",
      "indices" : [ 100, 114 ]
    }, {
      "text" : "womenslives",
      "indices" : [ 115, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "587614025778929664",
  "text" : "RT @LisaStone: What would you ask President Obama about #EqualPayDay, #TaxDay? Ask me, I'll ask him #ObamaTownHall #womenslives http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EqualPayDay",
        "indices" : [ 41, 53 ]
      }, {
        "text" : "TaxDay",
        "indices" : [ 55, 62 ]
      }, {
        "text" : "ObamaTownHall",
        "indices" : [ 85, 99 ]
      }, {
        "text" : "womenslives",
        "indices" : [ 100, 112 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/ARmIjCZTFL",
        "expanded_url" : "http:\/\/m.blogher.com\/what-question-would-you-ask-president-obama-about-your-paycheck-your-job-andor-your-future",
        "display_url" : "m.blogher.com\/what-question-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "587461953083158528",
    "text" : "What would you ask President Obama about #EqualPayDay, #TaxDay? Ask me, I'll ask him #ObamaTownHall #womenslives http:\/\/t.co\/ARmIjCZTFL \u2026",
    "id" : 587461953083158528,
    "created_at" : "2015-04-13 03:46:58 +0000",
    "user" : {
      "name" : "LisaStone",
      "screen_name" : "LisaStone",
      "protected" : false,
      "id_str" : "14178312",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/514831859646074880\/ryATRfiS_normal.jpeg",
      "id" : 14178312,
      "verified" : true
    }
  },
  "id" : 587614025778929664,
  "created_at" : "2015-04-13 13:51:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BlogHer",
      "screen_name" : "BlogHer",
      "indices" : [ 3, 11 ],
      "id_str" : "6753582",
      "id" : 6753582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/WmAUf84HTV",
      "expanded_url" : "http:\/\/ow.ly\/2Xi9E8",
      "display_url" : "ow.ly\/2Xi9E8"
    } ]
  },
  "geo" : { },
  "id_str" : "587444028456710144",
  "text" : "RT @BlogHer: What Question Would You Ask President Obama About Your Paycheck, Your Job, and Your Future? http:\/\/t.co\/WmAUf84HTV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/WmAUf84HTV",
        "expanded_url" : "http:\/\/ow.ly\/2Xi9E8",
        "display_url" : "ow.ly\/2Xi9E8"
      } ]
    },
    "geo" : { },
    "id_str" : "587435571137613824",
    "text" : "What Question Would You Ask President Obama About Your Paycheck, Your Job, and Your Future? http:\/\/t.co\/WmAUf84HTV",
    "id" : 587435571137613824,
    "created_at" : "2015-04-13 02:02:08 +0000",
    "user" : {
      "name" : "BlogHer",
      "screen_name" : "BlogHer",
      "protected" : false,
      "id_str" : "6753582",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778931829957013504\/iYHtXHLJ_normal.jpg",
      "id" : 6753582,
      "verified" : true
    }
  },
  "id" : 587444028456710144,
  "created_at" : "2015-04-13 02:35:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 98, 101 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/5JlQuxGYo5",
      "expanded_url" : "http:\/\/go.wh.gov\/u1eAWa",
      "display_url" : "go.wh.gov\/u1eAWa"
    } ]
  },
  "geo" : { },
  "id_str" : "587374716383469569",
  "text" : "\"Two years of community college should become as free and as universal as high school is today.\" \u2014@VP: http:\/\/t.co\/5JlQuxGYo5",
  "id" : 587374716383469569,
  "created_at" : "2015-04-12 22:00:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 111, 114 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/5JlQuxGYo5",
      "expanded_url" : "http:\/\/go.wh.gov\/u1eAWa",
      "display_url" : "go.wh.gov\/u1eAWa"
    } ]
  },
  "geo" : { },
  "id_str" : "587329401542455297",
  "text" : "\"Making community colleges free is good for workers, it\u2019s good for companies, and it\u2019s good for our economy.\" \u2014@VP: http:\/\/t.co\/5JlQuxGYo5",
  "id" : 587329401542455297,
  "created_at" : "2015-04-12 19:00:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 95, 98 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FreeCommunityCollege",
      "indices" : [ 123, 144 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/5JlQuxGYo5",
      "expanded_url" : "http:\/\/go.wh.gov\/u1eAWa",
      "display_url" : "go.wh.gov\/u1eAWa"
    } ]
  },
  "geo" : { },
  "id_str" : "587303762198274049",
  "text" : "\"Our plan is no giveaway. Students must keep up their grades &amp; stay on track to graduate\" \u2014@VP: http:\/\/t.co\/5JlQuxGYo5 #FreeCommunityCollege",
  "id" : 587303762198274049,
  "created_at" : "2015-04-12 17:18:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/snappytv.com\" rel=\"nofollow\"\u003ESnappyTV.com\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John McCain",
      "screen_name" : "SenJohnMcCain",
      "indices" : [ 63, 77 ],
      "id_str" : "19394188",
      "id" : 19394188
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranTalks",
      "indices" : [ 96, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/2ze3P9GmPa",
      "expanded_url" : "http:\/\/snpy.tv\/1aUqGfD",
      "display_url" : "snpy.tv\/1aUqGfD"
    } ]
  },
  "geo" : { },
  "id_str" : "587049147359830016",
  "text" : "\"Partisanship has crossed all boundaries.\" \u2014President Obama on @SenJohnMcCain's comments on the #IranTalks: http:\/\/t.co\/2ze3P9GmPa",
  "id" : 587049147359830016,
  "created_at" : "2015-04-12 00:26:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jen Psaki",
      "screen_name" : "Psaki44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135388684",
      "id" : 1135388684
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 42, 53 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Psaki44\/status\/586988018814320640\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/apiBlfhOqq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCVmQAEXIAIPYsF.jpg",
      "id_str" : "586987751523950594",
      "id" : 586987751523950594,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCVmQAEXIAIPYsF.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/apiBlfhOqq"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "587030001092059136",
  "text" : "RT @Psaki44: First tweet from my new role @WhiteHouse, first meeting between a US &amp; Cuban President in decades http:\/\/t.co\/apiBlfhOqq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 29, 40 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Psaki44\/status\/586988018814320640\/photo\/1",
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/apiBlfhOqq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CCVmQAEXIAIPYsF.jpg",
        "id_str" : "586987751523950594",
        "id" : 586987751523950594,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCVmQAEXIAIPYsF.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/apiBlfhOqq"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 8.989391831976315, -79.50061711768834 ]
    },
    "id_str" : "586988018814320640",
    "text" : "First tweet from my new role @WhiteHouse, first meeting between a US &amp; Cuban President in decades http:\/\/t.co\/apiBlfhOqq",
    "id" : 586988018814320640,
    "created_at" : "2015-04-11 20:23:44 +0000",
    "user" : {
      "name" : "Jen Psaki",
      "screen_name" : "Psaki44",
      "protected" : false,
      "id_str" : "1135388684",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/586965962370355200\/4NJkSnJN_normal.jpg",
      "id" : 1135388684,
      "verified" : true
    }
  },
  "id" : 587030001092059136,
  "created_at" : "2015-04-11 23:10:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/587020976619069440\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/7VjNbRFc0A",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCWEcfUWMAAFIyp.jpg",
      "id_str" : "587020951419760640",
      "id" : 587020951419760640,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCWEcfUWMAAFIyp.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1867,
        "resize" : "fit",
        "w" : 2800
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/7VjNbRFc0A"
    } ],
    "hashtags" : [ {
      "text" : "CubaPolicy",
      "indices" : [ 106, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "587020976619069440",
  "text" : "\"If you keep on doing something for 50 years and it doesn't work, you should try something new\" \u2014Obama on #CubaPolicy http:\/\/t.co\/7VjNbRFc0A",
  "id" : 587020976619069440,
  "created_at" : "2015-04-11 22:34:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "587020544576331777",
  "text" : "\"Our engagement with the countries and peoples of the Americas is going to continue throughout my presidency.\" \u2014President Obama",
  "id" : 587020544576331777,
  "created_at" : "2015-04-11 22:32:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "587019290236190720",
  "text" : "\"We continue to stand up strongly for democracy and human rights.\" \u2014President Obama at the Summit of the Americas",
  "id" : 587019290236190720,
  "created_at" : "2015-04-11 22:27:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/Zowx77eGvC",
      "expanded_url" : "http:\/\/go.wh.gov\/JknHsW",
      "display_url" : "go.wh.gov\/JknHsW"
    } ]
  },
  "geo" : { },
  "id_str" : "587018961956417536",
  "text" : "Happening now: President Obama participates in a press conference at the Summit of the Americas \u2192 http:\/\/t.co\/Zowx77eGvC",
  "id" : 587018961956417536,
  "created_at" : "2015-04-11 22:26:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/587001446782013441\/photo\/1",
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/mrJP1MsuG4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCVyrOOWMAA4cWU.jpg",
      "id_str" : "587001413319929856",
      "id" : 587001413319929856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCVyrOOWMAA4cWU.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1867,
        "resize" : "fit",
        "w" : 2800
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/mrJP1MsuG4"
    } ],
    "hashtags" : [ {
      "text" : "CubaPolicy",
      "indices" : [ 85, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "587001446782013441",
  "text" : "\"We are now in a position to move on a path towards the future.\" \u2014President Obama on #CubaPolicy http:\/\/t.co\/mrJP1MsuG4",
  "id" : 587001446782013441,
  "created_at" : "2015-04-11 21:17:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 104, 107 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/5JlQuxGYo5",
      "expanded_url" : "http:\/\/go.wh.gov\/u1eAWa",
      "display_url" : "go.wh.gov\/u1eAWa"
    } ]
  },
  "geo" : { },
  "id_str" : "586959420409561088",
  "text" : "\"By the end of the decade, two out of three of all jobs will require an education beyond high school.\" \u2014@VP: http:\/\/t.co\/5JlQuxGYo5",
  "id" : 586959420409561088,
  "created_at" : "2015-04-11 18:30:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 65, 68 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/5JlQuxYzMF",
      "expanded_url" : "http:\/\/go.wh.gov\/u1eAWa",
      "display_url" : "go.wh.gov\/u1eAWa"
    } ]
  },
  "geo" : { },
  "id_str" : "586944567108358145",
  "text" : "\"I\u2019m here with a simple message: middle-class economics works.\" \u2014@VP: http:\/\/t.co\/5JlQuxYzMF",
  "id" : 586944567108358145,
  "created_at" : "2015-04-11 17:31:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 35, 38 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FreeCommunityCollege",
      "indices" : [ 42, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/5JlQuxYzMF",
      "expanded_url" : "http:\/\/go.wh.gov\/u1eAWa",
      "display_url" : "go.wh.gov\/u1eAWa"
    } ]
  },
  "geo" : { },
  "id_str" : "586906163146575872",
  "text" : "Watch this week's address from the @VP on #FreeCommunityCollege: http:\/\/t.co\/5JlQuxYzMF",
  "id" : 586906163146575872,
  "created_at" : "2015-04-11 14:58:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "586646747352588288",
  "text" : "\"As you work for change, the United States will stand with you every step of the way.\" \u2014Obama to leaders at the Summit of the Americas",
  "id" : 586646747352588288,
  "created_at" : "2015-04-10 21:47:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "586646196711587841",
  "text" : "\"We know that our societies are more likely to succeed when all our people...are free to live and pray and love as they choose.\" \u2014Obama",
  "id" : 586646196711587841,
  "created_at" : "2015-04-10 21:45:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/586645219984171009\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/VsjWkRd37h",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCQurF4WMAArIdJ.jpg",
      "id_str" : "586645169312772096",
      "id" : 586645169312772096,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCQurF4WMAArIdJ.jpg",
      "sizes" : [ {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/VsjWkRd37h"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "586645219984171009",
  "text" : "\"Strong nations don\u2019t fear active citizens\u2014strong nations embrace and support and empower active citizens.\" \u2014Obama http:\/\/t.co\/VsjWkRd37h",
  "id" : 586645219984171009,
  "created_at" : "2015-04-10 21:41:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "586645065176633344",
  "text" : "\"Civil society is the conscience of our countries. It\u2019s the catalyst of change.\" \u2014President Obama at the Summit of the Americas",
  "id" : 586645065176633344,
  "created_at" : "2015-04-10 21:40:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/586644501676105729\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/rvMClukjs9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCQuCZ7WMAAYmLR.jpg",
      "id_str" : "586644470319427584",
      "id" : 586644470319427584,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCQuCZ7WMAAYmLR.jpg",
      "sizes" : [ {
        "h" : 281,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 159,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/rvMClukjs9"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "586644501676105729",
  "text" : "\"Their efforts bent\u2026the arc of the moral universe towards justice.\" \u2014Obama on those who marched in Selma 50 years ago http:\/\/t.co\/rvMClukjs9",
  "id" : 586644501676105729,
  "created_at" : "2015-04-10 21:38:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "586644217746874368",
  "text" : "\"Throughout our history, human progress has been propelled\u2026by ordinary men and women who believe that change is possible\" \u2014President Obama",
  "id" : 586644217746874368,
  "created_at" : "2015-04-10 21:37:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "586643786945527808",
  "text" : "\"I\u2019m pleased to have Cuba represented with us at this summit for the very first time.\" \u2014President Obama at the Summit of the Americas",
  "id" : 586643786945527808,
  "created_at" : "2015-04-10 21:35:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/SC68wle0D3",
      "expanded_url" : "http:\/\/go.wh.gov\/FaDyAw",
      "display_url" : "go.wh.gov\/FaDyAw"
    } ]
  },
  "geo" : { },
  "id_str" : "586643491591041026",
  "text" : "Watch live: President Obama speaks at a civil society forum in Panama at the Summit of the Americas \u2192 http:\/\/t.co\/SC68wle0D3",
  "id" : 586643491591041026,
  "created_at" : "2015-04-10 21:34:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/586625842706415616\/photo\/1",
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/Ild69Rokxa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCQc4F5WgAAaC97.jpg",
      "id_str" : "586625601445986304",
      "id" : 586625601445986304,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCQc4F5WgAAaC97.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1867,
        "resize" : "fit",
        "w" : 2800
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/Ild69Rokxa"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/yWMlWPbgCf",
      "expanded_url" : "http:\/\/go.wh.gov\/z6NMQ3",
      "display_url" : "go.wh.gov\/z6NMQ3"
    } ]
  },
  "geo" : { },
  "id_str" : "586625842706415616",
  "text" : "\"With hard work and hope, change is always within our reach.\" \u2014President Obama: http:\/\/t.co\/yWMlWPbgCf http:\/\/t.co\/Ild69Rokxa",
  "id" : 586625842706415616,
  "created_at" : "2015-04-10 20:24:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/NBp33KsYdb",
      "expanded_url" : "http:\/\/go.wh.gov\/DGBC37",
      "display_url" : "go.wh.gov\/DGBC37"
    } ]
  },
  "geo" : { },
  "id_str" : "586617420699148288",
  "text" : "Watch live: President Obama participates in a panel discussion at the CEO Summit of the Americas \u2192 http:\/\/t.co\/NBp33KsYdb",
  "id" : 586617420699148288,
  "created_at" : "2015-04-10 19:51:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Tumblr",
      "screen_name" : "tumblr",
      "indices" : [ 107, 114 ],
      "id_str" : "52484614",
      "id" : 52484614
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LGBTQ",
      "indices" : [ 23, 29 ]
    }, {
      "text" : "LeelahsLaw",
      "indices" : [ 116, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "586607216737693696",
  "text" : "RT @vj44: To the brave #LGBTQ youth who are fighting for a more perfect union - thank you. Until next time @tumblr! #LeelahsLaw http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tumblr",
        "screen_name" : "tumblr",
        "indices" : [ 97, 104 ],
        "id_str" : "52484614",
        "id" : 52484614
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/586605972447166464\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/ypySORuyW1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CCQK9fBWEAAOLYj.jpg",
        "id_str" : "586605902880444416",
        "id" : 586605902880444416,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCQK9fBWEAAOLYj.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/ypySORuyW1"
      } ],
      "hashtags" : [ {
        "text" : "LGBTQ",
        "indices" : [ 13, 19 ]
      }, {
        "text" : "LeelahsLaw",
        "indices" : [ 106, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "586605972447166464",
    "text" : "To the brave #LGBTQ youth who are fighting for a more perfect union - thank you. Until next time @tumblr! #LeelahsLaw http:\/\/t.co\/ypySORuyW1",
    "id" : 586605972447166464,
    "created_at" : "2015-04-10 19:05:37 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 586607216737693696,
  "created_at" : "2015-04-10 19:10:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "John McCain",
      "screen_name" : "SenJohnMcCain",
      "indices" : [ 37, 51 ],
      "id_str" : "19394188",
      "id" : 19394188
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "586605049314312192",
  "text" : "RT @PressSec: Na\u00EFve and reckless for @SenJohnMcCain to believe every word of the Supreme Leader's political speech. He shouldn't.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John McCain",
        "screen_name" : "SenJohnMcCain",
        "indices" : [ 23, 37 ],
        "id_str" : "19394188",
        "id" : 19394188
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "586604499638169600",
    "text" : "Na\u00EFve and reckless for @SenJohnMcCain to believe every word of the Supreme Leader's political speech. He shouldn't.",
    "id" : 586604499638169600,
    "created_at" : "2015-04-10 18:59:45 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 586605049314312192,
  "created_at" : "2015-04-10 19:01:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/vmYIyLnqhf",
      "expanded_url" : "https:\/\/youtu.be\/mv2N0hYPAwY",
      "display_url" : "youtu.be\/mv2N0hYPAwY"
    } ]
  },
  "geo" : { },
  "id_str" : "586592948269088769",
  "text" : "Young people should be valued for who they are, no matter what gender they identify with, or who they love.\nWatch \u2192 https:\/\/t.co\/vmYIyLnqhf",
  "id" : 586592948269088769,
  "created_at" : "2015-04-10 18:13:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 51, 56 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "U.S. Surgeon General",
      "screen_name" : "Surgeon_General",
      "indices" : [ 65, 81 ],
      "id_str" : "455024343",
      "id" : 455024343
    }, {
      "name" : "Tumblr",
      "screen_name" : "tumblr",
      "indices" : [ 102, 109 ],
      "id_str" : "52484614",
      "id" : 52484614
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LeelahsLaw",
      "indices" : [ 17, 28 ]
    }, {
      "text" : "LGBT",
      "indices" : [ 33, 38 ]
    } ],
    "urls" : [ {
      "indices" : [ 119, 141 ],
      "url" : "http:\/\/t.co\/GDeXAtQzPH",
      "expanded_url" : "http:\/\/whitehouse.tumblr.com\/ask",
      "display_url" : "whitehouse.tumblr.com\/ask"
    } ]
  },
  "geo" : { },
  "id_str" : "586568295094099969",
  "text" : "Got questions on #LeelahsLaw and #LGBT issues?\nAsk @VJ44 and the @Surgeon_General before their 2pm ET @Tumblr Q&amp;A: http:\/\/t.co\/GDeXAtQzPH",
  "id" : 586568295094099969,
  "created_at" : "2015-04-10 16:35:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Surgeon General",
      "screen_name" : "Surgeon_General",
      "indices" : [ 3, 19 ],
      "id_str" : "455024343",
      "id" : 455024343
    }, {
      "name" : "Ninjas for Health",
      "screen_name" : "ninjasforhealth",
      "indices" : [ 22, 38 ],
      "id_str" : "885190436",
      "id" : 885190436
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AskTheSurgeonGeneral",
      "indices" : [ 104, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "586557290372800512",
  "text" : "RT @Surgeon_General: .@NinjasForHealth Good question, and I like your Twitter handle! Here's my advice. #AskTheSurgeonGeneral \u2013VM http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ninjas for Health",
        "screen_name" : "ninjasforhealth",
        "indices" : [ 1, 17 ],
        "id_str" : "885190436",
        "id" : 885190436
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AskTheSurgeonGeneral",
        "indices" : [ 83, 104 ]
      } ],
      "urls" : [ {
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/fWo0FYV3yw",
        "expanded_url" : "http:\/\/snpy.tv\/1HZvMkY",
        "display_url" : "snpy.tv\/1HZvMkY"
      } ]
    },
    "in_reply_to_status_id_str" : "586011478559326209",
    "geo" : { },
    "id_str" : "586554980208783360",
    "in_reply_to_user_id" : 885190436,
    "text" : ".@NinjasForHealth Good question, and I like your Twitter handle! Here's my advice. #AskTheSurgeonGeneral \u2013VM http:\/\/t.co\/fWo0FYV3yw",
    "id" : 586554980208783360,
    "in_reply_to_status_id" : 586011478559326209,
    "created_at" : "2015-04-10 15:42:59 +0000",
    "in_reply_to_screen_name" : "ninjasforhealth",
    "in_reply_to_user_id_str" : "885190436",
    "user" : {
      "name" : "U.S. Surgeon General",
      "screen_name" : "Surgeon_General",
      "protected" : false,
      "id_str" : "455024343",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/768080246314717185\/2csUW4il_normal.jpg",
      "id" : 455024343,
      "verified" : true
    }
  },
  "id" : 586557290372800512,
  "created_at" : "2015-04-10 15:52:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "U.S. Surgeon General",
      "screen_name" : "Surgeon_General",
      "indices" : [ 11, 27 ],
      "id_str" : "455024343",
      "id" : 455024343
    }, {
      "name" : "Tumblr",
      "screen_name" : "tumblr",
      "indices" : [ 52, 59 ],
      "id_str" : "52484614",
      "id" : 52484614
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LeelahsLaw",
      "indices" : [ 68, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "586528381136539649",
  "text" : "RT @vj44: .@Surgeon_General and I will be hosting a @tumblr chat on #LeelahsLaw at 2 pm EST. All views and questions are welcome, so spread\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "U.S. Surgeon General",
        "screen_name" : "Surgeon_General",
        "indices" : [ 1, 17 ],
        "id_str" : "455024343",
        "id" : 455024343
      }, {
        "name" : "Tumblr",
        "screen_name" : "tumblr",
        "indices" : [ 42, 49 ],
        "id_str" : "52484614",
        "id" : 52484614
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LeelahsLaw",
        "indices" : [ 58, 69 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "586524891727396865",
    "text" : ".@Surgeon_General and I will be hosting a @tumblr chat on #LeelahsLaw at 2 pm EST. All views and questions are welcome, so spread the word!",
    "id" : 586524891727396865,
    "created_at" : "2015-04-10 13:43:25 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 586528381136539649,
  "created_at" : "2015-04-10 13:57:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 3, 13 ],
      "id_str" : "9624742",
      "id" : 9624742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/eaGms8Js8O",
      "expanded_url" : "http:\/\/go.usa.gov\/3DVZY",
      "display_url" : "go.usa.gov\/3DVZY"
    } ]
  },
  "geo" : { },
  "id_str" : "586309161601916928",
  "text" : "RT @StateDept: President Obama announced the Young Leaders of the Americas Initiative today: Fact Sheet: http:\/\/t.co\/eaGms8Js8O . http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/StateDept\/status\/586289751117922305\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/IRDujJseip",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CCLrbAIXIAEMyzX.jpg",
        "id_str" : "586289750635651073",
        "id" : 586289750635651073,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCLrbAIXIAEMyzX.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/IRDujJseip"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/eaGms8Js8O",
        "expanded_url" : "http:\/\/go.usa.gov\/3DVZY",
        "display_url" : "go.usa.gov\/3DVZY"
      } ]
    },
    "geo" : { },
    "id_str" : "586289751117922305",
    "text" : "President Obama announced the Young Leaders of the Americas Initiative today: Fact Sheet: http:\/\/t.co\/eaGms8Js8O . http:\/\/t.co\/IRDujJseip",
    "id" : 586289751117922305,
    "created_at" : "2015-04-09 22:09:04 +0000",
    "user" : {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "protected" : false,
      "id_str" : "9624742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724612605185282048\/1rEfkXDZ_normal.jpg",
      "id" : 9624742,
      "verified" : true
    }
  },
  "id" : 586309161601916928,
  "created_at" : "2015-04-09 23:26:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Surgeon General",
      "screen_name" : "Surgeon_General",
      "indices" : [ 3, 19 ],
      "id_str" : "455024343",
      "id" : 455024343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "586288458970308609",
  "text" : "RT @Surgeon_General: .@jg13145: I've treated many patients with asthma, so this issue is very important to me. #AskTheSurgeonGeneral -VM ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AskTheSurgeonGeneral",
        "indices" : [ 90, 111 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/gEXRm97mH2",
        "expanded_url" : "http:\/\/snpy.tv\/1GQkl0y",
        "display_url" : "snpy.tv\/1GQkl0y"
      } ]
    },
    "in_reply_to_status_id_str" : "585988102038003712",
    "geo" : { },
    "id_str" : "586275951610351616",
    "in_reply_to_user_id" : 56827481,
    "text" : ".@jg13145: I've treated many patients with asthma, so this issue is very important to me. #AskTheSurgeonGeneral -VM http:\/\/t.co\/gEXRm97mH2",
    "id" : 586275951610351616,
    "in_reply_to_status_id" : 585988102038003712,
    "created_at" : "2015-04-09 21:14:14 +0000",
    "in_reply_to_screen_name" : "jgarciajordan",
    "in_reply_to_user_id_str" : "56827481",
    "user" : {
      "name" : "U.S. Surgeon General",
      "screen_name" : "Surgeon_General",
      "protected" : false,
      "id_str" : "455024343",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/768080246314717185\/2csUW4il_normal.jpg",
      "id" : 455024343,
      "verified" : true
    }
  },
  "id" : 586288458970308609,
  "created_at" : "2015-04-09 22:03:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Surgeon General",
      "screen_name" : "Surgeon_General",
      "indices" : [ 3, 19 ],
      "id_str" : "455024343",
      "id" : 455024343
    }, {
      "name" : "Bob Doherty",
      "screen_name" : "BobDohertyACP",
      "indices" : [ 22, 36 ],
      "id_str" : "167486422",
      "id" : 167486422
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AskTheSurgeonGeneral",
      "indices" : [ 113, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/4M5IP54eGc",
      "expanded_url" : "http:\/\/Vaccines.gov",
      "display_url" : "Vaccines.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "586282532242644993",
  "text" : "RT @Surgeon_General: .@BobDohertyACP Vaccines are key to stopping the spread of disease: http:\/\/t.co\/4M5IP54eGc. #AskTheSurgeonGeneral \u2013VM \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bob Doherty",
        "screen_name" : "BobDohertyACP",
        "indices" : [ 1, 15 ],
        "id_str" : "167486422",
        "id" : 167486422
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AskTheSurgeonGeneral",
        "indices" : [ 92, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/4M5IP54eGc",
        "expanded_url" : "http:\/\/Vaccines.gov",
        "display_url" : "Vaccines.gov"
      }, {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/ILQEw0YjFN",
        "expanded_url" : "http:\/\/snpy.tv\/1GQnuNT",
        "display_url" : "snpy.tv\/1GQnuNT"
      } ]
    },
    "in_reply_to_status_id_str" : "586140450618286081",
    "geo" : { },
    "id_str" : "586282123797131264",
    "in_reply_to_user_id" : 167486422,
    "text" : ".@BobDohertyACP Vaccines are key to stopping the spread of disease: http:\/\/t.co\/4M5IP54eGc. #AskTheSurgeonGeneral \u2013VM http:\/\/t.co\/ILQEw0YjFN",
    "id" : 586282123797131264,
    "in_reply_to_status_id" : 586140450618286081,
    "created_at" : "2015-04-09 21:38:45 +0000",
    "in_reply_to_screen_name" : "BobDohertyACP",
    "in_reply_to_user_id_str" : "167486422",
    "user" : {
      "name" : "U.S. Surgeon General",
      "screen_name" : "Surgeon_General",
      "protected" : false,
      "id_str" : "455024343",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/768080246314717185\/2csUW4il_normal.jpg",
      "id" : 455024343,
      "verified" : true
    }
  },
  "id" : 586282532242644993,
  "created_at" : "2015-04-09 21:40:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/586274233195622400\/photo\/1",
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/IBDdfRf23q",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCLdRpgW4AA84C_.jpg",
      "id_str" : "586274196780670976",
      "id" : 586274196780670976,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCLdRpgW4AA84C_.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/IBDdfRf23q"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "586274233195622400",
  "text" : "\"Thank you, Jamaica.\" \u2014President Obama http:\/\/t.co\/IBDdfRf23q",
  "id" : 586274233195622400,
  "created_at" : "2015-04-09 21:07:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "586259420910379010",
  "text" : "\"If there\u2019s one thing I know from my own life, it\u2019s that with hard work and hope, change is always within our reach.\" \u2014Obama in Jamaica",
  "id" : 586259420910379010,
  "created_at" : "2015-04-09 20:08:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "586258714618945536",
  "text" : "RT @WHLive: \"I want you to have every chance and every tool you need to make this world better.\" \u2014Obama on investing in Latin American &amp; Ca\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "586258641365442560",
    "text" : "\"I want you to have every chance and every tool you need to make this world better.\" \u2014Obama on investing in Latin American &amp; Caribbean youth",
    "id" : 586258641365442560,
    "created_at" : "2015-04-09 20:05:26 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 586258714618945536,
  "created_at" : "2015-04-09 20:05:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/586258462268588032\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/wlM4jG9agQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCLOyp1WYAA_AMQ.jpg",
      "id_str" : "586258271129985024",
      "id" : 586258271129985024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCLOyp1WYAA_AMQ.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1867,
        "resize" : "fit",
        "w" : 2800
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/wlM4jG9agQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "586258462268588032",
  "text" : "\"People who are trying to make this world worse are not taking the day off. Why should I?\" \u2014Obama quoting Bob Marley http:\/\/t.co\/wlM4jG9agQ",
  "id" : 586258462268588032,
  "created_at" : "2015-04-09 20:04:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "586257551278354434",
  "text" : "\"You care less about the world as it is, and more about the world as it should be.\" \u2014President Obama to young leaders in Jamaica",
  "id" : 586257551278354434,
  "created_at" : "2015-04-09 20:01:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/586257333891821568\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/Q2aTIRGhIp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCLN5ssWAAA08kY.jpg",
      "id_str" : "586257292644974592",
      "id" : 586257292644974592,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCLN5ssWAAA08kY.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Q2aTIRGhIp"
    } ],
    "hashtags" : [ {
      "text" : "CubaPolicy",
      "indices" : [ 94, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "586257333891821568",
  "text" : "\"I believe that engagement is a more powerful force than isolation.\" \u2014President Obama on Cuba #CubaPolicy http:\/\/t.co\/Q2aTIRGhIp",
  "id" : 586257333891821568,
  "created_at" : "2015-04-09 20:00:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/ULwVXkhDqf",
      "expanded_url" : "http:\/\/go.wh.gov\/ishdYQ",
      "display_url" : "go.wh.gov\/ishdYQ"
    } ]
  },
  "geo" : { },
  "id_str" : "586246610184757251",
  "text" : "Watch at 3:30pm ET: President Obama holds a town hall with young leaders in Jamaica \u2192 http:\/\/t.co\/ULwVXkhDqf",
  "id" : 586246610184757251,
  "created_at" : "2015-04-09 19:17:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/586220369033441280\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/d7RbTQw2Ji",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCKrx_YWMAIQOeD.jpg",
      "id_str" : "586219776827076610",
      "id" : 586219776827076610,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCKrx_YWMAIQOeD.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/d7RbTQw2Ji"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 4, 26 ],
      "url" : "http:\/\/t.co\/FRL2YYm4rF",
      "expanded_url" : "http:\/\/WhiteHouse.gov",
      "display_url" : "WhiteHouse.gov"
    }, {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/H58bJSv8Jq",
      "expanded_url" : "http:\/\/go.wh.gov\/new-homepage",
      "display_url" : "go.wh.gov\/new-homepage"
    } ]
  },
  "geo" : { },
  "id_str" : "586220369033441280",
  "text" : "The http:\/\/t.co\/FRL2YYm4rF redesign is live.\nCheck out our first-ever responsive homepage \u2192 http:\/\/t.co\/H58bJSv8Jq http:\/\/t.co\/d7RbTQw2Ji",
  "id" : 586220369033441280,
  "created_at" : "2015-04-09 17:33:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 17, 22 ],
      "id_str" : "11348282",
      "id" : 11348282
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/ks44\/status\/586211654884401152\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/BiGQDEncGD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCKkNNVWMAIo67G.jpg",
      "id_str" : "586211448336035842",
      "id" : 586211448336035842,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCKkNNVWMAIo67G.jpg",
      "sizes" : [ {
        "h" : 871,
        "resize" : "fit",
        "w" : 673
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 777,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 440,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 871,
        "resize" : "fit",
        "w" : 673
      } ],
      "display_url" : "pic.twitter.com\/BiGQDEncGD"
    } ],
    "hashtags" : [ {
      "text" : "WeTheGeeks",
      "indices" : [ 52, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/pJ5PHF6VSf",
      "expanded_url" : "http:\/\/wh.gov\/we-the-geeks",
      "display_url" : "wh.gov\/we-the-geeks"
    } ]
  },
  "geo" : { },
  "id_str" : "586212985099649024",
  "text" : "Got questions on @NASA's journey to Pluto?\nAsk with #WeTheGeeks and join our hangout now \u2192 http:\/\/t.co\/pJ5PHF6VSf http:\/\/t.co\/BiGQDEncGD",
  "id" : 586212985099649024,
  "created_at" : "2015-04-09 17:04:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AskTheSurgeonGeneral",
      "indices" : [ 84, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "586194427045093378",
  "text" : "RT @FLOTUS: We're celebrating National Public Health Week! If you've got questions, #AskTheSurgeonGeneral before 2:30pm ET: http:\/\/t.co\/8WV\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AskTheSurgeonGeneral",
        "indices" : [ 72, 93 ]
      }, {
        "text" : "NPHW",
        "indices" : [ 135, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/8WVM0mdK38",
        "expanded_url" : "http:\/\/go.wh.gov\/hNWpQq",
        "display_url" : "go.wh.gov\/hNWpQq"
      } ]
    },
    "geo" : { },
    "id_str" : "586193579405615104",
    "text" : "We're celebrating National Public Health Week! If you've got questions, #AskTheSurgeonGeneral before 2:30pm ET: http:\/\/t.co\/8WVM0mdK38 #NPHW",
    "id" : 586193579405615104,
    "created_at" : "2015-04-09 15:46:54 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 586194427045093378,
  "created_at" : "2015-04-09 15:50:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    }, {
      "name" : "Appomattox CH NHP",
      "screen_name" : "AppomattoxNPS",
      "indices" : [ 77, 91 ],
      "id_str" : "3056802046",
      "id" : 3056802046
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OTDH",
      "indices" : [ 14, 19 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "586190453998911488",
  "text" : "RT @Interior: #OTDH 1865: General Lee surrendered at Appomattox Court House (@AppomattoxNPS), effectively ending the Civil War http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Appomattox CH NHP",
        "screen_name" : "AppomattoxNPS",
        "indices" : [ 63, 77 ],
        "id_str" : "3056802046",
        "id" : 3056802046
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/586187298544480257\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/B4uXqJ2byz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CCKOPbxUIAAkZ9p.jpg",
        "id_str" : "586187297315364864",
        "id" : 586187297315364864,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCKOPbxUIAAkZ9p.jpg",
        "sizes" : [ {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1331,
          "resize" : "fit",
          "w" : 2000
        }, {
          "h" : 681,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/B4uXqJ2byz"
      } ],
      "hashtags" : [ {
        "text" : "OTDH",
        "indices" : [ 0, 5 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "586187298544480257",
    "text" : "#OTDH 1865: General Lee surrendered at Appomattox Court House (@AppomattoxNPS), effectively ending the Civil War http:\/\/t.co\/B4uXqJ2byz",
    "id" : 586187298544480257,
    "created_at" : "2015-04-09 15:21:57 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 586190453998911488,
  "created_at" : "2015-04-09 15:34:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Surgeon General",
      "screen_name" : "Surgeon_General",
      "indices" : [ 3, 19 ],
      "id_str" : "455024343",
      "id" : 455024343
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NPHW",
      "indices" : [ 90, 95 ]
    }, {
      "text" : "AskTheSurgeonGeneral",
      "indices" : [ 116, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "586183970749976578",
  "text" : "RT @Surgeon_General: Send your public health questions by 2:30 PM ET tomorrow to keep the #NPHW conversation going. #AskTheSurgeonGeneral h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Surgeon_General\/status\/585948030899265537\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/HfEL3KS6ia",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CCG0oPjWYAAMvtt.jpg",
        "id_str" : "585948029997441024",
        "id" : 585948029997441024,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCG0oPjWYAAMvtt.jpg",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/HfEL3KS6ia"
      } ],
      "hashtags" : [ {
        "text" : "NPHW",
        "indices" : [ 69, 74 ]
      }, {
        "text" : "AskTheSurgeonGeneral",
        "indices" : [ 95, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "585948030899265537",
    "text" : "Send your public health questions by 2:30 PM ET tomorrow to keep the #NPHW conversation going. #AskTheSurgeonGeneral http:\/\/t.co\/HfEL3KS6ia",
    "id" : 585948030899265537,
    "created_at" : "2015-04-08 23:31:11 +0000",
    "user" : {
      "name" : "U.S. Surgeon General",
      "screen_name" : "Surgeon_General",
      "protected" : false,
      "id_str" : "455024343",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/768080246314717185\/2csUW4il_normal.jpg",
      "id" : 455024343,
      "verified" : true
    }
  },
  "id" : 586183970749976578,
  "created_at" : "2015-04-09 15:08:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/586179705339908096\/photo\/1",
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/Aj5uL3Gabu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCKG81KWAAA2IIy.jpg",
      "id_str" : "586179281132322816",
      "id" : 586179281132322816,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCKG81KWAAA2IIy.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1867,
        "resize" : "fit",
        "w" : 2800
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Aj5uL3Gabu"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 43 ],
      "url" : "https:\/\/t.co\/xOw1MnJDlz",
      "expanded_url" : "https:\/\/instagram.com\/p\/1QXkvItNHZ\/",
      "display_url" : "instagram.com\/p\/1QXkvItNHZ\/"
    } ]
  },
  "geo" : { },
  "id_str" : "586179705339908096",
  "text" : "Barack and Jamrock. https:\/\/t.co\/xOw1MnJDlz http:\/\/t.co\/Aj5uL3Gabu",
  "id" : 586179705339908096,
  "created_at" : "2015-04-09 14:51:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    }, {
      "name" : "NASA New Horizons",
      "screen_name" : "NASANewHorizons",
      "indices" : [ 36, 52 ],
      "id_str" : "2734713482",
      "id" : 2734713482
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WeTheGeeks",
      "indices" : [ 129, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/xNBoUH3WdQ",
      "expanded_url" : "http:\/\/wh.gov\/iZw0C",
      "display_url" : "wh.gov\/iZw0C"
    } ]
  },
  "geo" : { },
  "id_str" : "586176357299650560",
  "text" : "RT @whitehouseostp: In &lt;100 days @NASANewHorizons will reach Pluto for 1st close-up. Learn more @ 1PM! http:\/\/t.co\/xNBoUH3WdQ #WeTheGeeks h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NASA New Horizons",
        "screen_name" : "NASANewHorizons",
        "indices" : [ 16, 32 ],
        "id_str" : "2734713482",
        "id" : 2734713482
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/whitehouseostp\/status\/586171097827024896\/photo\/1",
        "indices" : [ 121, 143 ],
        "url" : "http:\/\/t.co\/H7ICXhJLa3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CCJ_gc-UoAAFnEN.png",
        "id_str" : "586171097021718528",
        "id" : 586171097021718528,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCJ_gc-UoAAFnEN.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 488,
          "resize" : "fit",
          "w" : 327
        }, {
          "h" : 488,
          "resize" : "fit",
          "w" : 327
        }, {
          "h" : 488,
          "resize" : "fit",
          "w" : 327
        }, {
          "h" : 488,
          "resize" : "fit",
          "w" : 327
        } ],
        "display_url" : "pic.twitter.com\/H7ICXhJLa3"
      } ],
      "hashtags" : [ {
        "text" : "WeTheGeeks",
        "indices" : [ 109, 120 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/xNBoUH3WdQ",
        "expanded_url" : "http:\/\/wh.gov\/iZw0C",
        "display_url" : "wh.gov\/iZw0C"
      } ]
    },
    "geo" : { },
    "id_str" : "586171097827024896",
    "text" : "In &lt;100 days @NASANewHorizons will reach Pluto for 1st close-up. Learn more @ 1PM! http:\/\/t.co\/xNBoUH3WdQ #WeTheGeeks http:\/\/t.co\/H7ICXhJLa3",
    "id" : 586171097827024896,
    "created_at" : "2015-04-09 14:17:34 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 586176357299650560,
  "created_at" : "2015-04-09 14:38:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill de Blasio",
      "screen_name" : "BilldeBlasio",
      "indices" : [ 3, 16 ],
      "id_str" : "476193064",
      "id" : 476193064
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StandUp4Transportation",
      "indices" : [ 92, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/TrY3V55cQR",
      "expanded_url" : "http:\/\/amny.com\/opinion\/congress-do-the-right-thing-by-nyc-1.10224738",
      "display_url" : "amny.com\/opinion\/congre\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "586167759698034689",
  "text" : "RT @BilldeBlasio: Congress must invest in our subways, buses, roads, and bridges. Today, we #StandUp4Transportation. http:\/\/t.co\/TrY3V55cQR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "StandUp4Transportation",
        "indices" : [ 74, 97 ]
      } ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/TrY3V55cQR",
        "expanded_url" : "http:\/\/amny.com\/opinion\/congress-do-the-right-thing-by-nyc-1.10224738",
        "display_url" : "amny.com\/opinion\/congre\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "586123657971367937",
    "text" : "Congress must invest in our subways, buses, roads, and bridges. Today, we #StandUp4Transportation. http:\/\/t.co\/TrY3V55cQR",
    "id" : 586123657971367937,
    "created_at" : "2015-04-09 11:09:04 +0000",
    "user" : {
      "name" : "Bill de Blasio",
      "screen_name" : "NYCMayor",
      "protected" : false,
      "id_str" : "19834403",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797104781974192128\/xv2CMcBu_normal.jpg",
      "id" : 19834403,
      "verified" : true
    }
  },
  "id" : 586167759698034689,
  "created_at" : "2015-04-09 14:04:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "stephanie taylor",
      "screen_name" : "brophelia",
      "indices" : [ 3, 13 ],
      "id_str" : "331879062",
      "id" : 331879062
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LeelahsLaw",
      "indices" : [ 110, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "586162889385345024",
  "text" : "RT @brophelia: This is so, so important. I'm so overwhelmed and elated. Progress is slow, but it's beautiful. #LeelahsLaw  https:\/\/t.co\/1E7\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LeelahsLaw",
        "indices" : [ 95, 106 ]
      } ],
      "urls" : [ {
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/1E7tBE35Yj",
        "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/585958167466483712",
        "display_url" : "twitter.com\/WhiteHouse\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "586050768031080448",
    "text" : "This is so, so important. I'm so overwhelmed and elated. Progress is slow, but it's beautiful. #LeelahsLaw  https:\/\/t.co\/1E7tBE35Yj",
    "id" : 586050768031080448,
    "created_at" : "2015-04-09 06:19:26 +0000",
    "user" : {
      "name" : "stephanie taylor",
      "screen_name" : "brophelia",
      "protected" : false,
      "id_str" : "331879062",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/786075415580467200\/tqNv_cEE_normal.jpg",
      "id" : 331879062,
      "verified" : false
    }
  },
  "id" : 586162889385345024,
  "created_at" : "2015-04-09 13:44:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennell Jaquays",
      "screen_name" : "JennellAllyn",
      "indices" : [ 3, 16 ],
      "id_str" : "414995116",
      "id" : 414995116
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LeelahsLaw",
      "indices" : [ 112, 123 ]
    }, {
      "text" : "FixSociety",
      "indices" : [ 125, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/tvzaBnDTOt",
      "expanded_url" : "https:\/\/petitions.whitehouse.gov\/response\/response-your-petition-conversion-therapy",
      "display_url" : "petitions.whitehouse.gov\/response\/respo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "586161596134772736",
  "text" : "RT @JennellAllyn: The White House wholeheartedly responds to the Leelah's Law petition. https:\/\/t.co\/tvzaBnDTOt #LeelahsLaw  #FixSociety",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LeelahsLaw",
        "indices" : [ 94, 105 ]
      }, {
        "text" : "FixSociety",
        "indices" : [ 107, 118 ]
      } ],
      "urls" : [ {
        "indices" : [ 70, 93 ],
        "url" : "https:\/\/t.co\/tvzaBnDTOt",
        "expanded_url" : "https:\/\/petitions.whitehouse.gov\/response\/response-your-petition-conversion-therapy",
        "display_url" : "petitions.whitehouse.gov\/response\/respo\u2026"
      } ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 47.61530110002752, -122.3242080721619 ]
    },
    "id_str" : "585974136339439616",
    "text" : "The White House wholeheartedly responds to the Leelah's Law petition. https:\/\/t.co\/tvzaBnDTOt #LeelahsLaw  #FixSociety",
    "id" : 585974136339439616,
    "created_at" : "2015-04-09 01:14:55 +0000",
    "user" : {
      "name" : "Jennell Jaquays",
      "screen_name" : "JennellAllyn",
      "protected" : false,
      "id_str" : "414995116",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/517939021587034112\/9dpjSmah_normal.jpeg",
      "id" : 414995116,
      "verified" : false
    }
  },
  "id" : 586161596134772736,
  "created_at" : "2015-04-09 13:39:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "585964361031802880",
  "text" : "RT @vj44: We fully support efforts to ban the use of conversion therapy for minors-it's neither ethically\/medically appropriate http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/R7IV528kDW",
        "expanded_url" : "http:\/\/go.wh.gov\/QrBQrW",
        "display_url" : "go.wh.gov\/QrBQrW"
      } ]
    },
    "geo" : { },
    "id_str" : "585959886397243392",
    "text" : "We fully support efforts to ban the use of conversion therapy for minors-it's neither ethically\/medically appropriate http:\/\/t.co\/R7IV528kDW",
    "id" : 585959886397243392,
    "created_at" : "2015-04-09 00:18:18 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 585964361031802880,
  "created_at" : "2015-04-09 00:36:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "We the People",
      "screen_name" : "wethepeople",
      "indices" : [ 27, 39 ],
      "id_str" : "369507958",
      "id" : 369507958
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/TAZqqDP7BJ",
      "expanded_url" : "http:\/\/go.wh.gov\/QrBQrW",
      "display_url" : "go.wh.gov\/QrBQrW"
    } ]
  },
  "geo" : { },
  "id_str" : "585959337107001344",
  "text" : "120,915 Americans signed a @WeThePeople petition calling for a ban on conversion therapy for minors.\nWe agree \u2192 http:\/\/t.co\/TAZqqDP7BJ",
  "id" : 585959337107001344,
  "created_at" : "2015-04-09 00:16:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LeelahsLaw",
      "indices" : [ 116, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/TAZqqDxwd9",
      "expanded_url" : "http:\/\/go.wh.gov\/QrBQrW",
      "display_url" : "go.wh.gov\/QrBQrW"
    } ]
  },
  "geo" : { },
  "id_str" : "585958167466483712",
  "text" : "BREAKING: President Obama supports efforts to ban the use of conversion therapy for minors \u2192 http:\/\/t.co\/TAZqqDxwd9 #LeelahsLaw",
  "id" : 585958167466483712,
  "created_at" : "2015-04-09 00:11:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/585940076045041664\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/pETXvvrk7N",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCGsb9jUoAA4XmN.jpg",
      "id_str" : "585939022914035712",
      "id" : 585939022914035712,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCGsb9jUoAA4XmN.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/pETXvvrk7N"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 103, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/rIecvtdJef",
      "expanded_url" : "http:\/\/nbcnews.to\/1IJaDf3",
      "display_url" : "nbcnews.to\/1IJaDf3"
    } ]
  },
  "geo" : { },
  "id_str" : "585940076045041664",
  "text" : "Watch President Obama explain why climate change is a threat to public health \u2192 http:\/\/t.co\/rIecvtdJef #ActOnClimate http:\/\/t.co\/pETXvvrk7N",
  "id" : 585940076045041664,
  "created_at" : "2015-04-08 22:59:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Surgeon General",
      "screen_name" : "Surgeon_General",
      "indices" : [ 3, 19 ],
      "id_str" : "455024343",
      "id" : 455024343
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AskTheSurgeonGeneral",
      "indices" : [ 99, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "585934088554426368",
  "text" : "RT @Surgeon_General: Check back later on 4\/9 in to watch my video responses to your questions.-VM  #AskTheSurgeonGeneral  http:\/\/t.co\/OMRZn\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AskTheSurgeonGeneral",
        "indices" : [ 78, 99 ]
      }, {
        "text" : "NPHW",
        "indices" : [ 124, 129 ]
      } ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/OMRZnp8KYd",
        "expanded_url" : "http:\/\/go.usa.gov\/3DXGJ",
        "display_url" : "go.usa.gov\/3DXGJ"
      } ]
    },
    "geo" : { },
    "id_str" : "585932751876030464",
    "text" : "Check back later on 4\/9 in to watch my video responses to your questions.-VM  #AskTheSurgeonGeneral  http:\/\/t.co\/OMRZnp8KYd #NPHW",
    "id" : 585932751876030464,
    "created_at" : "2015-04-08 22:30:28 +0000",
    "user" : {
      "name" : "U.S. Surgeon General",
      "screen_name" : "Surgeon_General",
      "protected" : false,
      "id_str" : "455024343",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/768080246314717185\/2csUW4il_normal.jpg",
      "id" : 455024343,
      "verified" : true
    }
  },
  "id" : 585934088554426368,
  "created_at" : "2015-04-08 22:35:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Surgeon General",
      "screen_name" : "Surgeon_General",
      "indices" : [ 3, 19 ],
      "id_str" : "455024343",
      "id" : 455024343
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NPHW",
      "indices" : [ 34, 39 ]
    }, {
      "text" : "AskTheSurgeonGeneral",
      "indices" : [ 115, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "585933994144866305",
  "text" : "RT @Surgeon_General: Continue the #NPHW conversation! Send your questions to me here until 2:30 PM ET on 4\/9 using #AskTheSurgeonGeneral ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NPHW",
        "indices" : [ 13, 18 ]
      }, {
        "text" : "AskTheSurgeonGeneral",
        "indices" : [ 94, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/OMRZnp8KYd",
        "expanded_url" : "http:\/\/go.usa.gov\/3DXGJ",
        "display_url" : "go.usa.gov\/3DXGJ"
      } ]
    },
    "geo" : { },
    "id_str" : "585931927389081600",
    "text" : "Continue the #NPHW conversation! Send your questions to me here until 2:30 PM ET on 4\/9 using #AskTheSurgeonGeneral http:\/\/t.co\/OMRZnp8KYd",
    "id" : 585931927389081600,
    "created_at" : "2015-04-08 22:27:12 +0000",
    "user" : {
      "name" : "U.S. Surgeon General",
      "screen_name" : "Surgeon_General",
      "protected" : false,
      "id_str" : "455024343",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/768080246314717185\/2csUW4il_normal.jpg",
      "id" : 455024343,
      "verified" : true
    }
  },
  "id" : 585933994144866305,
  "created_at" : "2015-04-08 22:35:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Jennifer L Lopez",
      "screen_name" : "jlopez255",
      "indices" : [ 11, 21 ],
      "id_str" : "5580502",
      "id" : 5580502
    }, {
      "name" : "Debi Jackson",
      "screen_name" : "transgirl_mom",
      "indices" : [ 22, 36 ],
      "id_str" : "2485526592",
      "id" : 2485526592
    }, {
      "name" : "John Clark",
      "screen_name" : "HendersonClark",
      "indices" : [ 37, 52 ],
      "id_str" : "711137371",
      "id" : 711137371
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "585930825541091328",
  "text" : "RT @vj44: .@jlopez255 @transgirl_mom @HendersonClark @idamaecampbell @burgerbecky @fallonfox @JennellAllyn We can do big things together. #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jennifer L Lopez",
        "screen_name" : "jlopez255",
        "indices" : [ 1, 11 ],
        "id_str" : "5580502",
        "id" : 5580502
      }, {
        "name" : "Debi Jackson",
        "screen_name" : "transgirl_mom",
        "indices" : [ 12, 26 ],
        "id_str" : "2485526592",
        "id" : 2485526592
      }, {
        "name" : "John Clark",
        "screen_name" : "HendersonClark",
        "indices" : [ 27, 42 ],
        "id_str" : "711137371",
        "id" : 711137371
      }, {
        "name" : "Rebecca Heineman",
        "screen_name" : "burgerbecky",
        "indices" : [ 59, 71 ],
        "id_str" : "17081863",
        "id" : 17081863
      }, {
        "name" : "Fallon Fox",
        "screen_name" : "FallonFox",
        "indices" : [ 72, 82 ],
        "id_str" : "175940138",
        "id" : 175940138
      }, {
        "name" : "Jennell Jaquays",
        "screen_name" : "JennellAllyn",
        "indices" : [ 83, 96 ],
        "id_str" : "414995116",
        "id" : 414995116
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WeThePeople",
        "indices" : [ 128, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "585930212962992128",
    "text" : ".@jlopez255 @transgirl_mom @HendersonClark @idamaecampbell @burgerbecky @fallonfox @JennellAllyn We can do big things together. #WeThePeople",
    "id" : 585930212962992128,
    "created_at" : "2015-04-08 22:20:23 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 585930825541091328,
  "created_at" : "2015-04-08 22:22:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LGBTQ",
      "indices" : [ 72, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "585926346901069824",
  "text" : "RT @vj44: Talking to petitioners who organized 120K+ ppl calling to ban #LGBTQ conversion therapy. Stay tuned for our response! http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/vj44\/status\/585924795512020992\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/FjgyPTe4mt",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CCGffEQUEAM2OHj.jpg",
        "id_str" : "585924782601801731",
        "id" : 585924782601801731,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCGffEQUEAM2OHj.jpg",
        "sizes" : [ {
          "h" : 914,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 672
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 672
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 518,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/FjgyPTe4mt"
      } ],
      "hashtags" : [ {
        "text" : "LGBTQ",
        "indices" : [ 62, 68 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "585924795512020992",
    "text" : "Talking to petitioners who organized 120K+ ppl calling to ban #LGBTQ conversion therapy. Stay tuned for our response! http:\/\/t.co\/FjgyPTe4mt",
    "id" : 585924795512020992,
    "created_at" : "2015-04-08 21:58:51 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 585926346901069824,
  "created_at" : "2015-04-08 22:05:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/585885964930834432\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/1gLbS4uVLy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCF8FJoUAAEpM96.jpg",
      "id_str" : "585885854461067265",
      "id" : 585885854461067265,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCF8FJoUAAEpM96.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/1gLbS4uVLy"
    } ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 64, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/BWuabs0TNz",
      "expanded_url" : "http:\/\/go.wh.gov\/Iran-deal",
      "display_url" : "go.wh.gov\/Iran-deal"
    } ]
  },
  "geo" : { },
  "id_str" : "585885964930834432",
  "text" : "Get the facts on the international community's framework for an #IranDeal \u2192 http:\/\/t.co\/BWuabs0TNz http:\/\/t.co\/1gLbS4uVLy",
  "id" : 585885964930834432,
  "created_at" : "2015-04-08 19:24:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/585879181520728064\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/8aYQi2KEgq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCF18IHW4AIqCC7.jpg",
      "id_str" : "585879102365818882",
      "id" : 585879102365818882,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCF18IHW4AIqCC7.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/8aYQi2KEgq"
    } ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 30, 39 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/BWuabs0TNz",
      "expanded_url" : "http:\/\/go.wh.gov\/Iran-deal",
      "display_url" : "go.wh.gov\/Iran-deal"
    } ]
  },
  "geo" : { },
  "id_str" : "585879181520728064",
  "text" : "Worth sharing: Here's how the #IranDeal would shut down Iran's pathway to a nuclear weapon \u2192 http:\/\/t.co\/BWuabs0TNz http:\/\/t.co\/8aYQi2KEgq",
  "id" : 585879181520728064,
  "created_at" : "2015-04-08 18:57:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Surgeon General",
      "screen_name" : "Surgeon_General",
      "indices" : [ 3, 19 ],
      "id_str" : "455024343",
      "id" : 455024343
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NPHWchat",
      "indices" : [ 25, 34 ]
    }, {
      "text" : "NPHW",
      "indices" : [ 49, 54 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "585864294664773632",
  "text" : "RT @Surgeon_General: Use #NPHWchat to follow the #NPHW Twitter Chat today 2-3pm ET. Let\u2019s make America the healthiest nation in one generat\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NPHWchat",
        "indices" : [ 4, 13 ]
      }, {
        "text" : "NPHW",
        "indices" : [ 28, 33 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "585788434049970177",
    "text" : "Use #NPHWchat to follow the #NPHW Twitter Chat today 2-3pm ET. Let\u2019s make America the healthiest nation in one generation!",
    "id" : 585788434049970177,
    "created_at" : "2015-04-08 12:57:00 +0000",
    "user" : {
      "name" : "U.S. Surgeon General",
      "screen_name" : "Surgeon_General",
      "protected" : false,
      "id_str" : "455024343",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/768080246314717185\/2csUW4il_normal.jpg",
      "id" : 455024343,
      "verified" : true
    }
  },
  "id" : 585864294664773632,
  "created_at" : "2015-04-08 17:58:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/585858007281573888\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/bVD5AbqrZc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCFiecbWAAELInn.jpg",
      "id_str" : "585857701701353473",
      "id" : 585857701701353473,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCFiecbWAAELInn.jpg",
      "sizes" : [ {
        "h" : 413,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 234,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1376,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 705,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/bVD5AbqrZc"
    } ],
    "hashtags" : [ {
      "text" : "LGBT",
      "indices" : [ 78, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/R5Pg4F1rW7",
      "expanded_url" : "http:\/\/go.wh.gov\/ff5ci9",
      "display_url" : "go.wh.gov\/ff5ci9"
    } ]
  },
  "geo" : { },
  "id_str" : "585858007281573888",
  "text" : "We're taking a big step toward workplace equality by protecting the rights of #LGBT workers \u2192 http:\/\/t.co\/R5Pg4F1rW7 http:\/\/t.co\/bVD5AbqrZc",
  "id" : 585858007281573888,
  "created_at" : "2015-04-08 17:33:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 14, 19 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/585840670998306816\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/iVjZGLCPcp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCFSn32WMAAXY-_.jpg",
      "id_str" : "585840271495147520",
      "id" : 585840271495147520,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCFSn32WMAAXY-_.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/iVjZGLCPcp"
    } ],
    "hashtags" : [ {
      "text" : "LGBT",
      "indices" : [ 71, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/R5Pg4EJQxx",
      "expanded_url" : "http:\/\/go.wh.gov\/ff5ci9",
      "display_url" : "go.wh.gov\/ff5ci9"
    } ]
  },
  "geo" : { },
  "id_str" : "585840670998306816",
  "text" : "Worth a read: @VJ44 on how President Obama is protecting the rights of #LGBT workers \u2192 http:\/\/t.co\/R5Pg4EJQxx http:\/\/t.co\/iVjZGLCPcp",
  "id" : 585840670998306816,
  "created_at" : "2015-04-08 16:24:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    }, {
      "name" : "NASA New Horizons",
      "screen_name" : "NASANewHorizons",
      "indices" : [ 121, 137 ],
      "id_str" : "2734713482",
      "id" : 2734713482
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WeTheGeeks",
      "indices" : [ 30, 41 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/xNBoUGMlmi",
      "expanded_url" : "http:\/\/wh.gov\/iZw0C",
      "display_url" : "wh.gov\/iZw0C"
    } ]
  },
  "geo" : { },
  "id_str" : "585838505361711104",
  "text" : "RT @whitehouseostp: TMRW 1pm: #WeTheGeeks Journey to Pluto! 3 billion miles, 9 yrs in the making\u2192 http:\/\/t.co\/xNBoUGMlmi @NASANewHorizons h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NASA New Horizons",
        "screen_name" : "NASANewHorizons",
        "indices" : [ 101, 117 ],
        "id_str" : "2734713482",
        "id" : 2734713482
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/whitehouseostp\/status\/585826359714406400\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/ujlsUzQk0Y",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CCFF9zLUkAIF64_.jpg",
        "id_str" : "585826354546905090",
        "id" : 585826354546905090,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCFF9zLUkAIF64_.jpg",
        "sizes" : [ {
          "h" : 500,
          "resize" : "fit",
          "w" : 333
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 333
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 333
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 333
        } ],
        "display_url" : "pic.twitter.com\/ujlsUzQk0Y"
      } ],
      "hashtags" : [ {
        "text" : "WeTheGeeks",
        "indices" : [ 10, 21 ]
      } ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/xNBoUGMlmi",
        "expanded_url" : "http:\/\/wh.gov\/iZw0C",
        "display_url" : "wh.gov\/iZw0C"
      } ]
    },
    "geo" : { },
    "id_str" : "585826359714406400",
    "text" : "TMRW 1pm: #WeTheGeeks Journey to Pluto! 3 billion miles, 9 yrs in the making\u2192 http:\/\/t.co\/xNBoUGMlmi @NASANewHorizons http:\/\/t.co\/ujlsUzQk0Y",
    "id" : 585826359714406400,
    "created_at" : "2015-04-08 15:27:42 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 585838505361711104,
  "created_at" : "2015-04-08 16:15:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 108, 113 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "equality",
      "indices" : [ 46, 55 ]
    }, {
      "text" : "LGBT",
      "indices" : [ 78, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/R5Pg4EJQxx",
      "expanded_url" : "http:\/\/go.wh.gov\/ff5ci9",
      "display_url" : "go.wh.gov\/ff5ci9"
    } ]
  },
  "geo" : { },
  "id_str" : "585826448348282881",
  "text" : "\"Today, we take another important step toward #equality and fairness with our #LGBT brothers and sisters.\" \u2014@VJ44: http:\/\/t.co\/R5Pg4EJQxx",
  "id" : 585826448348282881,
  "created_at" : "2015-04-08 15:28:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LGBT",
      "indices" : [ 44, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "585811847594377216",
  "text" : "RT @vj44: Today, Pres Obama\u2019s EO protecting #LGBT workers becomes law, and we take one step closer to a more perfect union: http:\/\/t.co\/r9w\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LGBT",
        "indices" : [ 34, 39 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/r9w0hOCS3Q",
        "expanded_url" : "http:\/\/www.advocate.com\/commentary\/2015\/04\/08\/op-ed-protecting-lgbt-workers-means-protecting-all-workers",
        "display_url" : "advocate.com\/commentary\/201\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "585799959729045504",
    "text" : "Today, Pres Obama\u2019s EO protecting #LGBT workers becomes law, and we take one step closer to a more perfect union: http:\/\/t.co\/r9w0hOCS3Q",
    "id" : 585799959729045504,
    "created_at" : "2015-04-08 13:42:48 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 585811847594377216,
  "created_at" : "2015-04-08 14:30:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/585604900018597888\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/elVLsG467M",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCB8OJ9W8AADo9-.jpg",
      "id_str" : "585604534191452160",
      "id" : 585604534191452160,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCB8OJ9W8AADo9-.jpg",
      "sizes" : [ {
        "h" : 1882,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 565,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 964,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 320,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/elVLsG467M"
    } ],
    "hashtags" : [ {
      "text" : "EasterEggRoll",
      "indices" : [ 52, 66 ]
    }, {
      "text" : "GimmeFive",
      "indices" : [ 93, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 92 ],
      "url" : "https:\/\/t.co\/EPiiT4vVZR",
      "expanded_url" : "https:\/\/medium.com\/@FLOTUS\/in-pictures-the-white-house-easter-egg-roll-1683f1a48a46",
      "display_url" : "medium.com\/@FLOTUS\/in-pic\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "585604900018597888",
  "text" : "Check out 21 egg-citing photos from the White House #EasterEggRoll \u2192 https:\/\/t.co\/EPiiT4vVZR #GimmeFive http:\/\/t.co\/elVLsG467M",
  "id" : 585604900018597888,
  "created_at" : "2015-04-08 00:47:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 47, 56 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/YID10K3hwF",
      "expanded_url" : "http:\/\/nyti.ms\/1C7rsvr",
      "display_url" : "nyti.ms\/1C7rsvr"
    }, {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/mtq0pozhnC",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/f9d0f318-3fda-423d-ae5d-557a79964d79",
      "display_url" : "amp.twimg.com\/v\/f9d0f318-3fd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "585593867568721920",
  "text" : "President Obama shares how we can negotiate an #IranDeal while maintaining our security \u2192 http:\/\/t.co\/YID10K3hwF\nhttps:\/\/t.co\/mtq0pozhnC",
  "id" : 585593867568721920,
  "created_at" : "2015-04-08 00:03:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/UoLfPgqXps",
      "expanded_url" : "http:\/\/snpy.tv\/1BSGoNI",
      "display_url" : "snpy.tv\/1BSGoNI"
    } ]
  },
  "geo" : { },
  "id_str" : "585557168881008642",
  "text" : "Watch President Obama explain how the #IranDeal would prevent Iran from developing a nuclear weapon. http:\/\/t.co\/UoLfPgqXps",
  "id" : 585557168881008642,
  "created_at" : "2015-04-07 21:38:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Schultz",
      "screen_name" : "Schultz44",
      "indices" : [ 3, 13 ],
      "id_str" : "1603419038",
      "id" : 1603419038
    }, {
      "name" : "U.S. Surgeon General",
      "screen_name" : "Surgeon_General",
      "indices" : [ 25, 41 ],
      "id_str" : "455024343",
      "id" : 455024343
    }, {
      "name" : "Howard University",
      "screen_name" : "HowardU",
      "indices" : [ 99, 107 ],
      "id_str" : "27147528",
      "id" : 27147528
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Schultz44\/status\/585527545279426561\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/XeObLTCv06",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCA2IzUW8AAlawd.jpg",
      "id_str" : "585527476400615424",
      "id" : 585527476400615424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCA2IzUW8AAlawd.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/XeObLTCv06"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "585528090769678338",
  "text" : "RT @Schultz44: POTUS and @Surgeon_General spotlight the public health impacts of climate change at @HowardU http:\/\/t.co\/XeObLTCv06",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "U.S. Surgeon General",
        "screen_name" : "Surgeon_General",
        "indices" : [ 10, 26 ],
        "id_str" : "455024343",
        "id" : 455024343
      }, {
        "name" : "Howard University",
        "screen_name" : "HowardU",
        "indices" : [ 84, 92 ],
        "id_str" : "27147528",
        "id" : 27147528
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Schultz44\/status\/585527545279426561\/photo\/1",
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/XeObLTCv06",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CCA2IzUW8AAlawd.jpg",
        "id_str" : "585527476400615424",
        "id" : 585527476400615424,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCA2IzUW8AAlawd.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/XeObLTCv06"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 38.91775142430376, -77.02132050120234 ]
    },
    "id_str" : "585527545279426561",
    "text" : "POTUS and @Surgeon_General spotlight the public health impacts of climate change at @HowardU http:\/\/t.co\/XeObLTCv06",
    "id" : 585527545279426561,
    "created_at" : "2015-04-07 19:40:20 +0000",
    "user" : {
      "name" : "Eric Schultz",
      "screen_name" : "Schultz44",
      "protected" : false,
      "id_str" : "1603419038",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/491941155815161856\/u0IdexM6_normal.jpeg",
      "id" : 1603419038,
      "verified" : true
    }
  },
  "id" : 585528090769678338,
  "created_at" : "2015-04-07 19:42:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/585521497667670016\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/gMmtxyvpds",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CCAu_hiW8AERO21.jpg",
      "id_str" : "585519620427280385",
      "id" : 585519620427280385,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCAu_hiW8AERO21.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/gMmtxyvpds"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 102, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/xKq4J57Jqd",
      "expanded_url" : "http:\/\/go.wh.gov\/jAX9Qa",
      "display_url" : "go.wh.gov\/jAX9Qa"
    } ]
  },
  "geo" : { },
  "id_str" : "585521497667670016",
  "text" : "RT to share how we're expanding our use of solar power under President Obama \u2192 http:\/\/t.co\/xKq4J57Jqd #ActOnClimate http:\/\/t.co\/gMmtxyvpds",
  "id" : 585521497667670016,
  "created_at" : "2015-04-07 19:16:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 33, 40 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Sarah Jessica Parker",
      "screen_name" : "SJP",
      "indices" : [ 42, 46 ],
      "id_str" : "278072240",
      "id" : 278072240
    }, {
      "name" : "kerry washington",
      "screen_name" : "kerrywashington",
      "indices" : [ 53, 69 ],
      "id_str" : "205302299",
      "id" : 205302299
    }, {
      "name" : "Glamour",
      "screen_name" : "glamourmag",
      "indices" : [ 105, 116 ],
      "id_str" : "19247844",
      "id" : 19247844
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "vets",
      "indices" : [ 77, 82 ]
    }, {
      "text" : "JoiningForces",
      "indices" : [ 87, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/YBI8rquND6",
      "expanded_url" : "http:\/\/glmr.me\/1y97sNN",
      "display_url" : "glmr.me\/1y97sNN"
    } ]
  },
  "geo" : { },
  "id_str" : "585504105747054593",
  "text" : "RT @JoiningForces: Worth a read: @FLOTUS, @SJP &amp; @KerryWashington on our #vets and #JoiningForces in @GlamourMag: http:\/\/t.co\/YBI8rquND6 ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The First Lady",
        "screen_name" : "FLOTUS",
        "indices" : [ 14, 21 ],
        "id_str" : "1093090866",
        "id" : 1093090866
      }, {
        "name" : "Sarah Jessica Parker",
        "screen_name" : "SJP",
        "indices" : [ 23, 27 ],
        "id_str" : "278072240",
        "id" : 278072240
      }, {
        "name" : "kerry washington",
        "screen_name" : "kerrywashington",
        "indices" : [ 34, 50 ],
        "id_str" : "205302299",
        "id" : 205302299
      }, {
        "name" : "Glamour",
        "screen_name" : "glamourmag",
        "indices" : [ 86, 97 ],
        "id_str" : "19247844",
        "id" : 19247844
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JoiningForces\/status\/585501153942724608\/photo\/1",
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/ZI87U12RFh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CCAeL5YW0AA2GeE.jpg",
        "id_str" : "585501141288538112",
        "id" : 585501141288538112,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CCAeL5YW0AA2GeE.jpg",
        "sizes" : [ {
          "h" : 724,
          "resize" : "fit",
          "w" : 532
        }, {
          "h" : 724,
          "resize" : "fit",
          "w" : 532
        }, {
          "h" : 724,
          "resize" : "fit",
          "w" : 532
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 463,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/ZI87U12RFh"
      } ],
      "hashtags" : [ {
        "text" : "vets",
        "indices" : [ 58, 63 ]
      }, {
        "text" : "JoiningForces",
        "indices" : [ 68, 82 ]
      } ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/YBI8rquND6",
        "expanded_url" : "http:\/\/glmr.me\/1y97sNN",
        "display_url" : "glmr.me\/1y97sNN"
      } ]
    },
    "geo" : { },
    "id_str" : "585501153942724608",
    "text" : "Worth a read: @FLOTUS, @SJP &amp; @KerryWashington on our #vets and #JoiningForces in @GlamourMag: http:\/\/t.co\/YBI8rquND6 http:\/\/t.co\/ZI87U12RFh",
    "id" : 585501153942724608,
    "created_at" : "2015-04-07 17:55:27 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 585504105747054593,
  "created_at" : "2015-04-07 18:07:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "climate",
      "indices" : [ 49, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/CMihPFUCOr",
      "expanded_url" : "http:\/\/wh.gov\/iZdG8",
      "display_url" : "wh.gov\/iZdG8"
    } ]
  },
  "geo" : { },
  "id_str" : "585478218037207040",
  "text" : "RT @whitehouseostp: New steps to unleash data on #climate and health \u2192 http:\/\/t.co\/CMihPFUCOr Learn more LIVE at 1:30p ET, http:\/\/t.co\/YvEX\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "climate",
        "indices" : [ 29, 37 ]
      }, {
        "text" : "ActOnClimate",
        "indices" : [ 126, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 51, 73 ],
        "url" : "http:\/\/t.co\/CMihPFUCOr",
        "expanded_url" : "http:\/\/wh.gov\/iZdG8",
        "display_url" : "wh.gov\/iZdG8"
      }, {
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/YvEXGFQJvb",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "585477674182844416",
    "text" : "New steps to unleash data on #climate and health \u2192 http:\/\/t.co\/CMihPFUCOr Learn more LIVE at 1:30p ET, http:\/\/t.co\/YvEXGFQJvb #ActOnClimate",
    "id" : 585477674182844416,
    "created_at" : "2015-04-07 16:22:09 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 585478218037207040,
  "created_at" : "2015-04-07 16:24:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USTR",
      "screen_name" : "USTradeRep",
      "indices" : [ 3, 14 ],
      "id_str" : "44615672",
      "id" : 44615672
    }, {
      "name" : "Stash Tea",
      "screen_name" : "stashtea",
      "indices" : [ 47, 56 ],
      "id_str" : "24911887",
      "id" : 24911887
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/Q3jq74I5UE",
      "expanded_url" : "http:\/\/wh.gov\/iZRHo",
      "display_url" : "wh.gov\/iZRHo"
    } ]
  },
  "geo" : { },
  "id_str" : "585468982079008768",
  "text" : "RT @USTradeRep: A Cup of Tea w\/ the President: @stashtea is one of many small businesses depending on exports http:\/\/t.co\/Q3jq74I5UE http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stash Tea",
        "screen_name" : "stashtea",
        "indices" : [ 31, 40 ],
        "id_str" : "24911887",
        "id" : 24911887
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/USTradeRep\/status\/585466990183239680\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/deF7Eeazhu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CB__H2oW4AAFLe0.jpg",
        "id_str" : "585466986970406912",
        "id" : 585466986970406912,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CB__H2oW4AAFLe0.jpg",
        "sizes" : [ {
          "h" : 355,
          "resize" : "fit",
          "w" : 520
        }, {
          "h" : 232,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 355,
          "resize" : "fit",
          "w" : 520
        }, {
          "h" : 355,
          "resize" : "fit",
          "w" : 520
        } ],
        "display_url" : "pic.twitter.com\/deF7Eeazhu"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/Q3jq74I5UE",
        "expanded_url" : "http:\/\/wh.gov\/iZRHo",
        "display_url" : "wh.gov\/iZRHo"
      } ]
    },
    "geo" : { },
    "id_str" : "585466990183239680",
    "text" : "A Cup of Tea w\/ the President: @stashtea is one of many small businesses depending on exports http:\/\/t.co\/Q3jq74I5UE http:\/\/t.co\/deF7Eeazhu",
    "id" : 585466990183239680,
    "created_at" : "2015-04-07 15:39:42 +0000",
    "user" : {
      "name" : "USTR",
      "screen_name" : "USTradeRep",
      "protected" : false,
      "id_str" : "44615672",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662636758509596672\/O-ShXHZB_normal.png",
      "id" : 44615672,
      "verified" : true
    }
  },
  "id" : 585468982079008768,
  "created_at" : "2015-04-07 15:47:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/585449627723276288\/photo\/1",
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/vxxI8XLvdL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CB_ujrYUsAEZvIt.png",
      "id_str" : "585448773289029633",
      "id" : 585448773289029633,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CB_ujrYUsAEZvIt.png",
      "sizes" : [ {
        "h" : 326,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 108,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 331,
        "resize" : "fit",
        "w" : 1041
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/vxxI8XLvdL"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "585449627723276288",
  "text" : "President Obama on the 21st anniversary of the genocide in Rwanda. http:\/\/t.co\/vxxI8XLvdL",
  "id" : 585449627723276288,
  "created_at" : "2015-04-07 14:30:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "585439706738860032",
  "text" : "\"Where there is injustice, we defend the oppressed. Where there is disagreement, we treat each other with compassion and respect.\" \u2014Obama",
  "id" : 585439706738860032,
  "created_at" : "2015-04-07 13:51:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "585438693734748161",
  "text" : "\"Embracing those who were different. Serving the marginalized...this is the example we are called to follow\" \u2014President Obama",
  "id" : 585438693734748161,
  "created_at" : "2015-04-07 13:47:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "585437981973970946",
  "text" : "RT @WHLive: \"Like millions of Americans, I\u2019m honored that we will be welcoming him to our country later this year.\" \u2014President Obama on @Po\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Pope Francis",
        "screen_name" : "Pontifex",
        "indices" : [ 124, 133 ],
        "id_str" : "500704345",
        "id" : 500704345
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "585437940890914816",
    "text" : "\"Like millions of Americans, I\u2019m honored that we will be welcoming him to our country later this year.\" \u2014President Obama on @Pontifex",
    "id" : 585437940890914816,
    "created_at" : "2015-04-07 13:44:16 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 585437981973970946,
  "created_at" : "2015-04-07 13:44:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/TXs5AtkR8N",
      "expanded_url" : "http:\/\/go.wh.gov\/Ateo59",
      "display_url" : "go.wh.gov\/Ateo59"
    } ]
  },
  "geo" : { },
  "id_str" : "585436470695108608",
  "text" : "Watch live: President Obama hosts an Easter Prayer Breakfast at the White House \u2192 http:\/\/t.co\/TXs5AtkR8N",
  "id" : 585436470695108608,
  "created_at" : "2015-04-07 13:38:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/585233889158799360\/photo\/1",
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/2k85RaG3cz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CB8q-jeUkAAVJQ5.jpg",
      "id_str" : "585233730744127488",
      "id" : 585233730744127488,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CB8q-jeUkAAVJQ5.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/2k85RaG3cz"
    } ],
    "hashtags" : [ {
      "text" : "GimmeFive",
      "indices" : [ 69, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/dospEZQUen",
      "expanded_url" : "https:\/\/instagram.com\/p\/1JzDSWvZEz\/",
      "display_url" : "instagram.com\/p\/1JzDSWvZEz\/"
    } ]
  },
  "geo" : { },
  "id_str" : "585236319141437441",
  "text" : "RT @FLOTUS: Earth.\nFire.\nWind.\nWater.\nHeart.\nhttps:\/\/t.co\/dospEZQUen\n#GimmeFive http:\/\/t.co\/2k85RaG3cz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/585233889158799360\/photo\/1",
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/2k85RaG3cz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CB8q-jeUkAAVJQ5.jpg",
        "id_str" : "585233730744127488",
        "id" : 585233730744127488,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CB8q-jeUkAAVJQ5.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/2k85RaG3cz"
      } ],
      "hashtags" : [ {
        "text" : "GimmeFive",
        "indices" : [ 57, 67 ]
      } ],
      "urls" : [ {
        "indices" : [ 33, 56 ],
        "url" : "https:\/\/t.co\/dospEZQUen",
        "expanded_url" : "https:\/\/instagram.com\/p\/1JzDSWvZEz\/",
        "display_url" : "instagram.com\/p\/1JzDSWvZEz\/"
      } ]
    },
    "geo" : { },
    "id_str" : "585233889158799360",
    "text" : "Earth.\nFire.\nWind.\nWater.\nHeart.\nhttps:\/\/t.co\/dospEZQUen\n#GimmeFive http:\/\/t.co\/2k85RaG3cz",
    "id" : 585233889158799360,
    "created_at" : "2015-04-07 00:13:26 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 585236319141437441,
  "created_at" : "2015-04-07 00:23:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/585182322238038016\/photo\/1",
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/DhYTeFItfx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CB78OIPUIAEOqGr.jpg",
      "id_str" : "585182321264828417",
      "id" : 585182321264828417,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CB78OIPUIAEOqGr.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/DhYTeFItfx"
    } ],
    "hashtags" : [ {
      "text" : "GimmeFive",
      "indices" : [ 37, 47 ]
    }, {
      "text" : "EasterEggRoll",
      "indices" : [ 72, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/Hynkg6VbNW",
      "expanded_url" : "http:\/\/wh.gov\/EasterEggRoll",
      "display_url" : "wh.gov\/EasterEggRoll"
    } ]
  },
  "geo" : { },
  "id_str" : "585192532277080065",
  "text" : "RT @FLOTUS: Clear Eyes. Full Hearts. #GimmeFive. http:\/\/t.co\/Hynkg6VbNW #EasterEggRoll http:\/\/t.co\/DhYTeFItfx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/585182322238038016\/photo\/1",
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/DhYTeFItfx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CB78OIPUIAEOqGr.jpg",
        "id_str" : "585182321264828417",
        "id" : 585182321264828417,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CB78OIPUIAEOqGr.jpg",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/DhYTeFItfx"
      } ],
      "hashtags" : [ {
        "text" : "GimmeFive",
        "indices" : [ 25, 35 ]
      }, {
        "text" : "EasterEggRoll",
        "indices" : [ 60, 74 ]
      } ],
      "urls" : [ {
        "indices" : [ 37, 59 ],
        "url" : "http:\/\/t.co\/Hynkg6VbNW",
        "expanded_url" : "http:\/\/wh.gov\/EasterEggRoll",
        "display_url" : "wh.gov\/EasterEggRoll"
      } ]
    },
    "geo" : { },
    "id_str" : "585182322238038016",
    "text" : "Clear Eyes. Full Hearts. #GimmeFive. http:\/\/t.co\/Hynkg6VbNW #EasterEggRoll http:\/\/t.co\/DhYTeFItfx",
    "id" : 585182322238038016,
    "created_at" : "2015-04-06 20:48:32 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 585192532277080065,
  "created_at" : "2015-04-06 21:29:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/585180766230970368\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/BCubJTMxWq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CB75s9HWMAMdKb1.jpg",
      "id_str" : "585179552319680515",
      "id" : 585179552319680515,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CB75s9HWMAMdKb1.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/BCubJTMxWq"
    } ],
    "hashtags" : [ {
      "text" : "GimmeFive",
      "indices" : [ 70, 80 ]
    }, {
      "text" : "WhereTheWildThingsAre",
      "indices" : [ 81, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/jeqH3zhlix",
      "expanded_url" : "http:\/\/wh.gov\/EasterEggRoll",
      "display_url" : "wh.gov\/EasterEggRoll"
    } ]
  },
  "geo" : { },
  "id_str" : "585180766230970368",
  "text" : "\"Let the wild rumpus start!\" \u2014President Obama: http:\/\/t.co\/jeqH3zhlix #GimmeFive #WhereTheWildThingsAre http:\/\/t.co\/BCubJTMxWq",
  "id" : 585180766230970368,
  "created_at" : "2015-04-06 20:42:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Snapchat",
      "screen_name" : "Snapchat",
      "indices" : [ 56, 65 ],
      "id_str" : "376502929",
      "id" : 376502929
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/585156842822701056\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/zovUyR56me",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CB7kudjUsAALOYO.jpg",
      "id_str" : "585156488462643200",
      "id" : 585156488462643200,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CB7kudjUsAALOYO.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 605,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      } ],
      "display_url" : "pic.twitter.com\/zovUyR56me"
    } ],
    "hashtags" : [ {
      "text" : "EasterEggRoll",
      "indices" : [ 26, 40 ]
    }, {
      "text" : "GimmeFive",
      "indices" : [ 96, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/jeqH3zhlix",
      "expanded_url" : "http:\/\/wh.gov\/EasterEggRoll",
      "display_url" : "wh.gov\/EasterEggRoll"
    } ]
  },
  "geo" : { },
  "id_str" : "585156842822701056",
  "text" : "Check out the White House #EasterEggRoll \"Our Story\" on @Snapchat today! http:\/\/t.co\/jeqH3zhlix #GimmeFive http:\/\/t.co\/zovUyR56me",
  "id" : 585156842822701056,
  "created_at" : "2015-04-06 19:07:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/585149043459784704\/photo\/1",
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/bUvNHUwYUV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CB7d5bgUMAArVFR.jpg",
      "id_str" : "585148980310323200",
      "id" : 585148980310323200,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CB7d5bgUMAArVFR.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/bUvNHUwYUV"
    } ],
    "hashtags" : [ {
      "text" : "GimmeFive",
      "indices" : [ 23, 33 ]
    }, {
      "text" : "EasterEggRoll",
      "indices" : [ 34, 48 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "585149496213909504",
  "text" : "RT @FLOTUS: Knockouts. #GimmeFive #EasterEggRoll http:\/\/t.co\/bUvNHUwYUV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/585149043459784704\/photo\/1",
        "indices" : [ 37, 59 ],
        "url" : "http:\/\/t.co\/bUvNHUwYUV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CB7d5bgUMAArVFR.jpg",
        "id_str" : "585148980310323200",
        "id" : 585148980310323200,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CB7d5bgUMAArVFR.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/bUvNHUwYUV"
      } ],
      "hashtags" : [ {
        "text" : "GimmeFive",
        "indices" : [ 11, 21 ]
      }, {
        "text" : "EasterEggRoll",
        "indices" : [ 22, 36 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "585149043459784704",
    "text" : "Knockouts. #GimmeFive #EasterEggRoll http:\/\/t.co\/bUvNHUwYUV",
    "id" : 585149043459784704,
    "created_at" : "2015-04-06 18:36:18 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 585149496213909504,
  "created_at" : "2015-04-06 18:38:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 17, 26 ],
      "id_str" : "36719281",
      "id" : 36719281
    }, {
      "name" : "Fifth Harmony",
      "screen_name" : "FifthHarmony",
      "indices" : [ 56, 69 ],
      "id_str" : "872374136",
      "id" : 872374136
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/FLOTUS\/status\/585129689653477376\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/jvvXIg6CdF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CB7L1IgUEAAUEea.jpg",
      "id_str" : "585129115281264640",
      "id" : 585129115281264640,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CB7L1IgUEAAUEea.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/jvvXIg6CdF"
    } ],
    "hashtags" : [ {
      "text" : "GimmeFive",
      "indices" : [ 94, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/Hynkg7cMFu",
      "expanded_url" : "http:\/\/wh.gov\/EasterEggRoll",
      "display_url" : "wh.gov\/EasterEggRoll"
    } ]
  },
  "geo" : { },
  "id_str" : "585129731713970176",
  "text" : "RT @FLOTUS: Dear @LetsMove,\n\nHappy 5th Birthday!\n\nFrom,\n@FifthHarmony\n\nhttp:\/\/t.co\/Hynkg7cMFu #GimmeFive http:\/\/t.co\/jvvXIg6CdF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Let's Move!",
        "screen_name" : "letsmove",
        "indices" : [ 5, 14 ],
        "id_str" : "36719281",
        "id" : 36719281
      }, {
        "name" : "Fifth Harmony",
        "screen_name" : "FifthHarmony",
        "indices" : [ 44, 57 ],
        "id_str" : "872374136",
        "id" : 872374136
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/FLOTUS\/status\/585129689653477376\/photo\/1",
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/jvvXIg6CdF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CB7L1IgUEAAUEea.jpg",
        "id_str" : "585129115281264640",
        "id" : 585129115281264640,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CB7L1IgUEAAUEea.jpg",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/jvvXIg6CdF"
      } ],
      "hashtags" : [ {
        "text" : "GimmeFive",
        "indices" : [ 82, 92 ]
      } ],
      "urls" : [ {
        "indices" : [ 59, 81 ],
        "url" : "http:\/\/t.co\/Hynkg7cMFu",
        "expanded_url" : "http:\/\/wh.gov\/EasterEggRoll",
        "display_url" : "wh.gov\/EasterEggRoll"
      } ]
    },
    "geo" : { },
    "id_str" : "585129689653477376",
    "text" : "Dear @LetsMove,\n\nHappy 5th Birthday!\n\nFrom,\n@FifthHarmony\n\nhttp:\/\/t.co\/Hynkg7cMFu #GimmeFive http:\/\/t.co\/jvvXIg6CdF",
    "id" : 585129689653477376,
    "created_at" : "2015-04-06 17:19:23 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 585129731713970176,
  "created_at" : "2015-04-06 17:19:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Caroline Wozniacki",
      "screen_name" : "CaroWozniacki",
      "indices" : [ 3, 17 ],
      "id_str" : "94166168",
      "id" : 94166168
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 33, 44 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "USTA",
      "screen_name" : "usta",
      "indices" : [ 80, 85 ],
      "id_str" : "14836219",
      "id" : 14836219
    }, {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 116, 125 ],
      "id_str" : "36719281",
      "id" : 36719281
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EasterEggRoll",
      "indices" : [ 53, 67 ]
    }, {
      "text" : "gimmefive",
      "indices" : [ 126, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "585113702896107520",
  "text" : "RT @CaroWozniacki: Excited to be @whitehouse for the #EasterEggRoll helping the @usta get kids active and on court. @letsmove #gimmefive ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 14, 25 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "USTA",
        "screen_name" : "usta",
        "indices" : [ 61, 66 ],
        "id_str" : "14836219",
        "id" : 14836219
      }, {
        "name" : "Let's Move!",
        "screen_name" : "letsmove",
        "indices" : [ 97, 106 ],
        "id_str" : "36719281",
        "id" : 36719281
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CaroWozniacki\/status\/585063397311512577\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/o1LUMpYbS4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CB6QCTGWEAAC30k.jpg",
        "id_str" : "585063370765766656",
        "id" : 585063370765766656,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CB6QCTGWEAAC30k.jpg",
        "sizes" : [ {
          "h" : 562,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 959,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 318,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 959,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/o1LUMpYbS4"
      } ],
      "hashtags" : [ {
        "text" : "EasterEggRoll",
        "indices" : [ 34, 48 ]
      }, {
        "text" : "gimmefive",
        "indices" : [ 107, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "585063397311512577",
    "text" : "Excited to be @whitehouse for the #EasterEggRoll helping the @usta get kids active and on court. @letsmove #gimmefive http:\/\/t.co\/o1LUMpYbS4",
    "id" : 585063397311512577,
    "created_at" : "2015-04-06 12:55:58 +0000",
    "user" : {
      "name" : "Caroline Wozniacki",
      "screen_name" : "CaroWozniacki",
      "protected" : false,
      "id_str" : "94166168",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/774741660613902336\/Fj4EpAMh_normal.jpg",
      "id" : 94166168,
      "verified" : true
    }
  },
  "id" : 585113702896107520,
  "created_at" : "2015-04-06 16:15:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GimmeFive",
      "indices" : [ 124, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/1HvSZftzpZ",
      "expanded_url" : "http:\/\/go.wh.gov\/GSoW2K",
      "display_url" : "go.wh.gov\/GSoW2K"
    } ]
  },
  "geo" : { },
  "id_str" : "585103677674913794",
  "text" : "RT @FLOTUS: The First Lady and the \"So You Think You Can Dance\u201D All-Stars take the stage! Watch now: http:\/\/t.co\/1HvSZftzpZ #GimmeFive",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GimmeFive",
        "indices" : [ 112, 122 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/1HvSZftzpZ",
        "expanded_url" : "http:\/\/go.wh.gov\/GSoW2K",
        "display_url" : "go.wh.gov\/GSoW2K"
      } ]
    },
    "geo" : { },
    "id_str" : "585103547408187392",
    "text" : "The First Lady and the \"So You Think You Can Dance\u201D All-Stars take the stage! Watch now: http:\/\/t.co\/1HvSZftzpZ #GimmeFive",
    "id" : 585103547408187392,
    "created_at" : "2015-04-06 15:35:31 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 585103677674913794,
  "created_at" : "2015-04-06 15:36:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GimmeFive",
      "indices" : [ 125, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/I9LbPyMXvb",
      "expanded_url" : "http:\/\/go.wh.gov\/DcUcoV",
      "display_url" : "go.wh.gov\/DcUcoV"
    } ]
  },
  "geo" : { },
  "id_str" : "585095712238673920",
  "text" : "Let the Easter Egg Rolling begin! Watch the President and First Lady join families on the South Lawn: http:\/\/t.co\/I9LbPyMXvb #GimmeFive",
  "id" : 585095712238673920,
  "created_at" : "2015-04-06 15:04:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GimmeFive",
      "indices" : [ 97, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/HZt9G6aGbj",
      "expanded_url" : "http:\/\/whitehouse.gov\/EasterEggRoll",
      "display_url" : "whitehouse.gov\/EasterEggRoll"
    } ]
  },
  "geo" : { },
  "id_str" : "585093409205047296",
  "text" : "Watch the President and First Lady welcome guests at the Easter Egg Roll: http:\/\/t.co\/HZt9G6aGbj #GimmeFive",
  "id" : 585093409205047296,
  "created_at" : "2015-04-06 14:55:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 36, 47 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GimmeFive",
      "indices" : [ 118, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/ewl0JO86XS",
      "expanded_url" : "http:\/\/wh.gov\/eastereggroll",
      "display_url" : "wh.gov\/eastereggroll"
    } ]
  },
  "geo" : { },
  "id_str" : "585077034185072640",
  "text" : "RT @FLOTUS: Who's egg-cited for the @WhiteHouse Easter Egg Roll?\nCatch all the action today at http:\/\/t.co\/ewl0JO86XS #GimmeFive http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 24, 35 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/585076882451738625\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/rxOwzzVID3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CB6cLnJUkAELKI6.jpg",
        "id_str" : "585076724905316353",
        "id" : 585076724905316353,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CB6cLnJUkAELKI6.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/rxOwzzVID3"
      } ],
      "hashtags" : [ {
        "text" : "GimmeFive",
        "indices" : [ 106, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/ewl0JO86XS",
        "expanded_url" : "http:\/\/wh.gov\/eastereggroll",
        "display_url" : "wh.gov\/eastereggroll"
      } ]
    },
    "geo" : { },
    "id_str" : "585076882451738625",
    "text" : "Who's egg-cited for the @WhiteHouse Easter Egg Roll?\nCatch all the action today at http:\/\/t.co\/ewl0JO86XS #GimmeFive http:\/\/t.co\/rxOwzzVID3",
    "id" : 585076882451738625,
    "created_at" : "2015-04-06 13:49:33 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 585077034185072640,
  "created_at" : "2015-04-06 13:50:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/584807127358648322\/photo\/1",
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/bpVYtx7zvi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CB2mUt_UkAITW8C.jpg",
      "id_str" : "584806401500811266",
      "id" : 584806401500811266,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CB2mUt_UkAITW8C.jpg",
      "sizes" : [ {
        "h" : 3500,
        "resize" : "fit",
        "w" : 2333
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/bpVYtx7zvi"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "584807127358648322",
  "text" : "Happy Easter! http:\/\/t.co\/bpVYtx7zvi",
  "id" : 584807127358648322,
  "created_at" : "2015-04-05 19:57:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/DHnWucPqYX",
      "expanded_url" : "http:\/\/go.wh.gov\/1XtGFH",
      "display_url" : "go.wh.gov\/1XtGFH"
    } ]
  },
  "geo" : { },
  "id_str" : "584740085079244800",
  "text" : "\"To all Christians celebrating\u2026Happy Easter.\" \u2014President Obama: http:\/\/t.co\/DHnWucPqYX",
  "id" : 584740085079244800,
  "created_at" : "2015-04-05 15:31:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/DHnWucPqYX",
      "expanded_url" : "http:\/\/go.wh.gov\/1XtGFH",
      "display_url" : "go.wh.gov\/1XtGFH"
    } ]
  },
  "geo" : { },
  "id_str" : "584718554622066688",
  "text" : "\"Easter is a day of hope, in a season of hope.\" \u2014President Obama: http:\/\/t.co\/DHnWucPqYX",
  "id" : 584718554622066688,
  "created_at" : "2015-04-05 14:05:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/DHnWucPqYX",
      "expanded_url" : "http:\/\/go.wh.gov\/1XtGFH",
      "display_url" : "go.wh.gov\/1XtGFH"
    } ]
  },
  "geo" : { },
  "id_str" : "584462723536195586",
  "text" : "President Obama wishes all those who celebrate a Happy Passover and a Happy Easter. Watch \u2192 http:\/\/t.co\/DHnWucPqYX",
  "id" : 584462723536195586,
  "created_at" : "2015-04-04 21:09:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/OeL6M1ZYIC",
      "expanded_url" : "http:\/\/go.wh.gov\/xjNQbW",
      "display_url" : "go.wh.gov\/xjNQbW"
    } ]
  },
  "geo" : { },
  "id_str" : "584445424829726723",
  "text" : "\"We have an historic opportunity to prevent the spread of nuclear weapons in Iran, and to do so peacefully.\" \u2014Obama: http:\/\/t.co\/OeL6M1ZYIC",
  "id" : 584445424829726723,
  "created_at" : "2015-04-04 20:00:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 101, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/OeL6M1ZYIC",
      "expanded_url" : "http:\/\/go.wh.gov\/xjNQbW",
      "display_url" : "go.wh.gov\/xjNQbW"
    } ]
  },
  "geo" : { },
  "id_str" : "584430330406273024",
  "text" : "\"This deal is not based on trust, it\u2019s based on unprecedented verification.\" \u2014President Obama on the #IranDeal: http:\/\/t.co\/OeL6M1ZYIC",
  "id" : 584430330406273024,
  "created_at" : "2015-04-04 19:00:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/DHnWucPqYX",
      "expanded_url" : "http:\/\/go.wh.gov\/1XtGFH",
      "display_url" : "go.wh.gov\/1XtGFH"
    } ]
  },
  "geo" : { },
  "id_str" : "584416926136270848",
  "text" : "\"It\u2019s a chance to spend time with family, to celebrate miracles from days gone by.\" \u2014Obama on Passover and Easter: http:\/\/t.co\/DHnWucPqYX",
  "id" : 584416926136270848,
  "created_at" : "2015-04-04 18:07:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/584190581796143104\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/PIQB1ZnIBE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CBt18SYUkAAYj3t.jpg",
      "id_str" : "584190255261061120",
      "id" : 584190255261061120,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBt18SYUkAAYj3t.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1500
      } ],
      "display_url" : "pic.twitter.com\/PIQB1ZnIBE"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/DHnWucPqYX",
      "expanded_url" : "http:\/\/go.wh.gov\/1XtGFH",
      "display_url" : "go.wh.gov\/1XtGFH"
    } ]
  },
  "geo" : { },
  "id_str" : "584392584455262208",
  "text" : "\"On Friday night, I hosted a Passover Seder at the White House.\" \u2014President Obama: http:\/\/t.co\/DHnWucPqYX http:\/\/t.co\/PIQB1ZnIBE",
  "id" : 584392584455262208,
  "created_at" : "2015-04-04 16:30:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Iran",
      "indices" : [ 89, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/OeL6M1ZYIC",
      "expanded_url" : "http:\/\/go.wh.gov\/xjNQbW",
      "display_url" : "go.wh.gov\/xjNQbW"
    } ]
  },
  "geo" : { },
  "id_str" : "584379699419185153",
  "text" : "Watch President Obama's weekly address on reaching a comprehensive and long-term deal on #Iran's nuclear program: http:\/\/t.co\/OeL6M1ZYIC",
  "id" : 584379699419185153,
  "created_at" : "2015-04-04 15:39:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/584190581796143104\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/PIQB1ZnIBE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CBt18SYUkAAYj3t.jpg",
      "id_str" : "584190255261061120",
      "id" : 584190255261061120,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBt18SYUkAAYj3t.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1500
      } ],
      "display_url" : "pic.twitter.com\/PIQB1ZnIBE"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/vz5Sce9T2n",
      "expanded_url" : "http:\/\/go.wh.gov\/VA3y1h",
      "display_url" : "go.wh.gov\/VA3y1h"
    } ]
  },
  "geo" : { },
  "id_str" : "584190581796143104",
  "text" : "Tonight, President Obama and the First Lady hosted a Passover Seder at the White House. http:\/\/t.co\/vz5Sce9T2n http:\/\/t.co\/PIQB1ZnIBE",
  "id" : 584190581796143104,
  "created_at" : "2015-04-04 03:07:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/584125857196740608\/photo\/1",
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/YeKGOzRZKA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CBs7WloUoAA8Oxx.png",
      "id_str" : "584125835919007744",
      "id" : 584125835919007744,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBs7WloUoAA8Oxx.png",
      "sizes" : [ {
        "h" : 506,
        "resize" : "fit",
        "w" : 946
      }, {
        "h" : 182,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 506,
        "resize" : "fit",
        "w" : 946
      }, {
        "h" : 321,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/YeKGOzRZKA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "584125857196740608",
  "text" : "\"From my family to yours, Chag Sameach.\" \u2014President Obama celebrating Passover: http:\/\/t.co\/YeKGOzRZKA",
  "id" : 584125857196740608,
  "created_at" : "2015-04-03 22:50:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/584108319658369024\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/E9T5T57zyv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CBsrLGPUIAIjsOp.png",
      "id_str" : "584108046328012802",
      "id" : 584108046328012802,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBsrLGPUIAIjsOp.png",
      "sizes" : [ {
        "h" : 437,
        "resize" : "fit",
        "w" : 643
      }, {
        "h" : 437,
        "resize" : "fit",
        "w" : 643
      }, {
        "h" : 408,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 231,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/E9T5T57zyv"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "584108319658369024",
  "text" : "\"Words cannot adequately condemn the terrorist atrocities that took place at Garissa University College.\" \u2014Obama: http:\/\/t.co\/E9T5T57zyv",
  "id" : 584108319658369024,
  "created_at" : "2015-04-03 21:40:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 115, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "584039716590379008",
  "text" : "RT @WHLive: \"Lead by example. Invest in the future...That\u2019s how we\u2019ll keep this economy growing.\" \u2014President Obama #ActOnClimate",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 103, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "584039574881570816",
    "text" : "\"Lead by example. Invest in the future...That\u2019s how we\u2019ll keep this economy growing.\" \u2014President Obama #ActOnClimate",
    "id" : 584039574881570816,
    "created_at" : "2015-04-03 17:07:40 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 584039716590379008,
  "created_at" : "2015-04-03 17:08:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "584039443729936384",
  "text" : "RT @JoiningForces: RT to share the news: 10 bases will work to train transitioning military personnel for clean-energy jobs \u2192 http:\/\/t.co\/N\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/Nyn6a8ljYn",
        "expanded_url" : "http:\/\/go.wh.gov\/GLVLir",
        "display_url" : "go.wh.gov\/GLVLir"
      } ]
    },
    "geo" : { },
    "id_str" : "584039415418355712",
    "text" : "RT to share the news: 10 bases will work to train transitioning military personnel for clean-energy jobs \u2192 http:\/\/t.co\/Nyn6a8ljYn",
    "id" : 584039415418355712,
    "created_at" : "2015-04-03 17:07:02 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 584039443729936384,
  "created_at" : "2015-04-03 17:07:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hill Air Force Base",
      "screen_name" : "HAFB",
      "indices" : [ 77, 82 ],
      "id_str" : "595898067",
      "id" : 595898067
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HireAVeteran",
      "indices" : [ 41, 54 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "584039299907223553",
  "text" : "\"If you really want to get the job done, #HireAVeteran.\" \u2014President Obama at @HAFB",
  "id" : 584039299907223553,
  "created_at" : "2015-04-03 17:06:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 106, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "584039025754902528",
  "text" : "\"I\u2019m announcing a new goal to train 75,000 workers to enter the solar industry by 2020.\" \u2014President Obama #ActOnClimate",
  "id" : 584039025754902528,
  "created_at" : "2015-04-03 17:05:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hill Air Force Base",
      "screen_name" : "HAFB",
      "indices" : [ 40, 45 ],
      "id_str" : "595898067",
      "id" : 595898067
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/584036561370615808\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/dftgLGTdcD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CBrp3pTVIAAHcab.jpg",
      "id_str" : "584036243886907392",
      "id" : 584036243886907392,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBrp3pTVIAAHcab.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/dftgLGTdcD"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 79, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/OPLbnkP83W",
      "expanded_url" : "http:\/\/go.wh.gov\/gnXEPL",
      "display_url" : "go.wh.gov\/gnXEPL"
    } ]
  },
  "geo" : { },
  "id_str" : "584036561370615808",
  "text" : "Watch at 1pm ET: The President talks at @HAFB about the progress we've made to #ActOnClimate: http:\/\/t.co\/OPLbnkP83W http:\/\/t.co\/dftgLGTdcD",
  "id" : 584036561370615808,
  "created_at" : "2015-04-03 16:55:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/584006557177782275\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/QsnWUhriHx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CBrOui8UoAAiVdV.jpg",
      "id_str" : "584006400747020288",
      "id" : 584006400747020288,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBrOui8UoAAiVdV.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/QsnWUhriHx"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "584018712119922689",
  "text" : "Our businesses have added 12.1 million jobs over 61 months of growth\u2014extending the longest streak on record. http:\/\/t.co\/QsnWUhriHx",
  "id" : 584018712119922689,
  "created_at" : "2015-04-03 15:44:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/584006557177782275\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/QsnWUhriHx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CBrOui8UoAAiVdV.jpg",
      "id_str" : "584006400747020288",
      "id" : 584006400747020288,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBrOui8UoAAiVdV.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/QsnWUhriHx"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/0wlDryXZVA",
      "expanded_url" : "http:\/\/go.wh.gov\/H3F9C5",
      "display_url" : "go.wh.gov\/H3F9C5"
    } ]
  },
  "geo" : { },
  "id_str" : "584006557177782275",
  "text" : "Our businesses added 129,000 jobs last month and 3.1 million over the last year \u2192 http:\/\/t.co\/0wlDryXZVA http:\/\/t.co\/QsnWUhriHx",
  "id" : 584006557177782275,
  "created_at" : "2015-04-03 14:56:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TechHire",
      "indices" : [ 108, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/OdcszqsvGs",
      "expanded_url" : "http:\/\/wh.gov\/techhire",
      "display_url" : "wh.gov\/techhire"
    } ]
  },
  "geo" : { },
  "id_str" : "583757316396191744",
  "text" : "President Obama's budget would expand access to high-quality job training programs \u2192 http:\/\/t.co\/OdcszqsvGs #TechHire",
  "id" : 583757316396191744,
  "created_at" : "2015-04-02 22:26:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/583745337413672960\/photo\/1",
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/d1nSm2t0lb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CBnhNfqUgAADxSn.jpg",
      "id_str" : "583745248674742272",
      "id" : 583745248674742272,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBnhNfqUgAADxSn.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/d1nSm2t0lb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "583756579742162944",
  "text" : "FACT: The House GOP budget would cut funding so 2.2 million fewer people receive job training &amp; employment services. http:\/\/t.co\/d1nSm2t0lb",
  "id" : 583756579742162944,
  "created_at" : "2015-04-02 22:23:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/IqhLmpQ77Z",
      "expanded_url" : "http:\/\/go.wh.gov\/xAwy1J",
      "display_url" : "go.wh.gov\/xAwy1J"
    } ]
  },
  "geo" : { },
  "id_str" : "583754514953474048",
  "text" : "RT @WHLive: Happening now: Watch President Obama speak on training more Americans for better jobs \u2192 http:\/\/t.co\/IqhLmpQ77Z http:\/\/t.co\/Hcvj\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/583745337413672960\/photo\/1",
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/Hcvjl0zOTQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CBnhNfqUgAADxSn.jpg",
        "id_str" : "583745248674742272",
        "id" : 583745248674742272,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBnhNfqUgAADxSn.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/Hcvjl0zOTQ"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/IqhLmpQ77Z",
        "expanded_url" : "http:\/\/go.wh.gov\/xAwy1J",
        "display_url" : "go.wh.gov\/xAwy1J"
      } ]
    },
    "geo" : { },
    "id_str" : "583754482992844800",
    "text" : "Happening now: Watch President Obama speak on training more Americans for better jobs \u2192 http:\/\/t.co\/IqhLmpQ77Z http:\/\/t.co\/Hcvjl0zOTQ",
    "id" : 583754482992844800,
    "created_at" : "2015-04-02 22:14:49 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 583754514953474048,
  "created_at" : "2015-04-02 22:14:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/583745337413672960\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/d1nSm2t0lb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CBnhNfqUgAADxSn.jpg",
      "id_str" : "583745248674742272",
      "id" : 583745248674742272,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBnhNfqUgAADxSn.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/d1nSm2t0lb"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/7ZKNa6XiwG",
      "expanded_url" : "http:\/\/go.wh.gov\/j45jno",
      "display_url" : "go.wh.gov\/j45jno"
    } ]
  },
  "geo" : { },
  "id_str" : "583745337413672960",
  "text" : "At 5:50pm ET, watch President Obama speak on training more Americans for better jobs \u2192 http:\/\/t.co\/7ZKNa6XiwG http:\/\/t.co\/d1nSm2t0lb",
  "id" : 583745337413672960,
  "created_at" : "2015-04-02 21:38:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranTalks",
      "indices" : [ 73, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/UmQ47rpHx0",
      "expanded_url" : "http:\/\/snpy.tv\/1MHfO5r",
      "display_url" : "snpy.tv\/1MHfO5r"
    } ]
  },
  "geo" : { },
  "id_str" : "583742000119156737",
  "text" : "\"The issues at stake here are bigger than politics.\" \u2014President Obama on #IranTalks: http:\/\/t.co\/UmQ47rpHx0",
  "id" : 583742000119156737,
  "created_at" : "2015-04-02 21:25:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/UoLfPg9m0S",
      "expanded_url" : "http:\/\/snpy.tv\/1BSGoNI",
      "display_url" : "snpy.tv\/1BSGoNI"
    } ]
  },
  "geo" : { },
  "id_str" : "583736187384303616",
  "text" : "Watch President Obama outline the framework to prevent Iran from acquiring a nuclear weapon: http:\/\/t.co\/UoLfPg9m0S",
  "id" : 583736187384303616,
  "created_at" : "2015-04-02 21:02:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranTalks",
      "indices" : [ 105, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/C50uPzhlU3",
      "expanded_url" : "http:\/\/snpy.tv\/1F70WUK",
      "display_url" : "snpy.tv\/1F70WUK"
    } ]
  },
  "geo" : { },
  "id_str" : "583724040902160386",
  "text" : "\"A diplomatic solution is the best way to get this done and offers a more...lasting solution.\" \u2014Obama on #IranTalks: http:\/\/t.co\/C50uPzhlU3",
  "id" : 583724040902160386,
  "created_at" : "2015-04-02 20:13:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Kenya",
      "indices" : [ 122, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "583713089310203904",
  "text" : "RT @PressSec: We extend our deep condolences to the families and loved ones of all those killed in this heinous attack in #Kenya http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PressSec\/status\/583710141679173635\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/hB39YF9oZe",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CBnBR8fUMAAvN2u.png",
        "id_str" : "583710140760600576",
        "id" : 583710140760600576,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBnBR8fUMAAvN2u.png",
        "sizes" : [ {
          "h" : 113,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 308,
          "resize" : "fit",
          "w" : 926
        }, {
          "h" : 308,
          "resize" : "fit",
          "w" : 926
        }, {
          "h" : 200,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/hB39YF9oZe"
      } ],
      "hashtags" : [ {
        "text" : "Kenya",
        "indices" : [ 108, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "583710141679173635",
    "text" : "We extend our deep condolences to the families and loved ones of all those killed in this heinous attack in #Kenya http:\/\/t.co\/hB39YF9oZe",
    "id" : 583710141679173635,
    "created_at" : "2015-04-02 19:18:37 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 583713089310203904,
  "created_at" : "2015-04-02 19:30:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranTalks",
      "indices" : [ 52, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/e94eTqLJNO",
      "expanded_url" : "http:\/\/snpy.tv\/1F6PR62",
      "display_url" : "snpy.tv\/1F6PR62"
    } ]
  },
  "geo" : { },
  "id_str" : "583705515126988800",
  "text" : "Full video: President Obama delivers a statement on #IranTalks: http:\/\/t.co\/e94eTqLJNO",
  "id" : 583705515126988800,
  "created_at" : "2015-04-02 19:00:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 125, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "583701611114962944",
  "text" : "\"We have an historic opportunity to prevent the spread of nuclear weapons in Iran and to do so peacefully.\" \u2014President Obama #IranDeal",
  "id" : 583701611114962944,
  "created_at" : "2015-04-02 18:44:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 112, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "583700687957045249",
  "text" : "\"The issues at stake are bigger than politics. These are matters of war and peace\" \u2014President Obama to Congress #IranDeal",
  "id" : 583700687957045249,
  "created_at" : "2015-04-02 18:41:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 131, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "583700417822920704",
  "text" : "\"If...Netanyahu is looking for the most effective way to ensure Iran doesn\u2019t get a nuclear weapon, this is the best option\" \u2014Obama #IranDeal",
  "id" : 583700417822920704,
  "created_at" : "2015-04-02 18:39:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 123, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "583699864455753729",
  "text" : "\"We are willing to engage you on the basis of mutual interests and mutual respect.\" \u2014President Obama to the Iranian people #IranDeal",
  "id" : 583699864455753729,
  "created_at" : "2015-04-02 18:37:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 128, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "583699668795699200",
  "text" : "\"A diplomatic solution is the best way to get this done, and offers a more comprehensive\u2014and lasting solution\" \u2014President Obama #IranDeal",
  "id" : 583699668795699200,
  "created_at" : "2015-04-02 18:37:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 126, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "583699540533911553",
  "text" : "\"I have always insisted that I will do what is necessary to prevent Iran from acquiring a nuclear weapon, and I will.\" \u2014Obama #IranDeal",
  "id" : 583699540533911553,
  "created_at" : "2015-04-02 18:36:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 127, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "583698902093705216",
  "text" : "\"If we can get this done...we will be able to resolve one of the gravest threats to our security peacefully.\" \u2014President Obama #IranDeal",
  "id" : 583698902093705216,
  "created_at" : "2015-04-02 18:33:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 96, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "583698733184876544",
  "text" : "\"Now, let me re-emphasize\u2014our work is not done. The deal has not been signed.\" \u2014President Obama #IranDeal",
  "id" : 583698733184876544,
  "created_at" : "2015-04-02 18:33:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 129, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "583698607984939009",
  "text" : "\"In return for Iran\u2019s actions, the international community has agreed to provide Iran with relief from certain sanctions\" \u2014Obama #IranDeal",
  "id" : 583698607984939009,
  "created_at" : "2015-04-02 18:32:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 111, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "583698380796239872",
  "text" : "\"If Iran cheats, the world will know it. If we see something suspicious, we will inspect it.\" \u2014President Obama #IranDeal",
  "id" : 583698380796239872,
  "created_at" : "2015-04-02 18:31:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 130, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "583698274034393088",
  "text" : "\"Third, this deal provides the best possible defense against Iran\u2019s ability to pursue a nuclear weapon covertly\" \u2014President Obama #IranDeal",
  "id" : 583698274034393088,
  "created_at" : "2015-04-02 18:31:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 119, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "583698164231770112",
  "text" : "\"Under this deal, Iran has agreed that it will not stockpile the materials needed to build a weapon.\" \u2014President Obama #IranDeal",
  "id" : 583698164231770112,
  "created_at" : "2015-04-02 18:31:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 97, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "583697877454585856",
  "text" : "\"Iran has agreed that its installed centrifuges will be reduced by two-thirds.\" \u2014President Obama #IranDeal",
  "id" : 583697877454585856,
  "created_at" : "2015-04-02 18:29:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 94, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "583697790376611840",
  "text" : "\"Second, this deal shuts down Iran\u2019s path to a bomb using enriched uranium.\" \u2014President Obama #IranDeal",
  "id" : 583697790376611840,
  "created_at" : "2015-04-02 18:29:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 124, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "583697666007117824",
  "text" : "\u201CFirst, Iran will not be able to pursue a bomb using plutonium because it will not develop weapons-grade plutonium.\u201D \u2014Obama #IranDeal",
  "id" : 583697666007117824,
  "created_at" : "2015-04-02 18:29:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 93, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "583697564312080384",
  "text" : "\"This deal is not based on trust\u2014it\u2019s based on unprecedented verification.\" \u2014President Obama #IranDeal",
  "id" : 583697564312080384,
  "created_at" : "2015-04-02 18:28:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "583697508783656960",
  "text" : "\"Iran has also agreed to the most robust and intrusive inspections and transparency regime ever negotiated for any nuclear program\" \u2014Obama",
  "id" : 583697508783656960,
  "created_at" : "2015-04-02 18:28:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 112, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "583697459613831168",
  "text" : "\"This framework would cut off every pathway that Iran could take to develop a nuclear weapon.\" \u2014President Obama #IranDeal",
  "id" : 583697459613831168,
  "created_at" : "2015-04-02 18:28:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 122, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "583697405847056385",
  "text" : "\"Today, after many months of tough, principled diplomacy, we have achieved the framework for that deal.\" \u2014President Obama #IranDeal",
  "id" : 583697405847056385,
  "created_at" : "2015-04-02 18:28:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 120, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "583697250200592384",
  "text" : "\"Sanctions alone could not stop Iran\u2019s nuclear program.  But they did help bring Iran to the negotiating table.\" \u2014Obama #IranDeal",
  "id" : 583697250200592384,
  "created_at" : "2015-04-02 18:27:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "583697146567790592",
  "text" : "\"I made clear that we were prepared to resolve this issue diplomatically\u2014but only if Iran came to the table in a serious way\" \u2014Obama",
  "id" : 583697146567790592,
  "created_at" : "2015-04-02 18:26:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 124, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "583697022521188352",
  "text" : "\"If this framework leads to a final, comprehensive deal, it will make our country, our allies, and our world safer.\" \u2014Obama #IranDeal",
  "id" : 583697022521188352,
  "created_at" : "2015-04-02 18:26:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 131, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "583696971573039104",
  "text" : "\"As President and Commander-in-Chief, I have no greater responsibility than the security of the American people.\" \u2014President Obama #IranDeal",
  "id" : 583696971573039104,
  "created_at" : "2015-04-02 18:26:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 21, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "583696916573069314",
  "text" : "President Obama: The #IranDeal, \"if fully implemented, will prevent it from obtaining a nuclear weapon.\"",
  "id" : 583696916573069314,
  "created_at" : "2015-04-02 18:26:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 120, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "583696863775236096",
  "text" : "\"Today, the United States\u2014together with our allies and partners\u2014has reached an historic understanding with Iran\" \u2014Obama #IranDeal",
  "id" : 583696863775236096,
  "created_at" : "2015-04-02 18:25:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 82, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/m5YgMIMrCD",
      "expanded_url" : "http:\/\/go.wh.gov\/t8gJX4",
      "display_url" : "go.wh.gov\/t8gJX4"
    } ]
  },
  "geo" : { },
  "id_str" : "583696724994035712",
  "text" : "Watch live: President Obama delivers a statement on Iran \u2192 http:\/\/t.co\/m5YgMIMrCD #IranDeal",
  "id" : 583696724994035712,
  "created_at" : "2015-04-02 18:25:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 97, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/m5YgMIMrCD",
      "expanded_url" : "http:\/\/go.wh.gov\/t8gJX4",
      "display_url" : "go.wh.gov\/t8gJX4"
    } ]
  },
  "geo" : { },
  "id_str" : "583689744082534400",
  "text" : "BREAKING: President Obama will deliver a statement on Iran at 2:15pm ET \u2192 http:\/\/t.co\/m5YgMIMrCD #IranDeal",
  "id" : 583689744082534400,
  "created_at" : "2015-04-02 17:57:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "indices" : [ 3, 13 ],
      "id_str" : "15007149",
      "id" : 15007149
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranTalks",
      "indices" : [ 99, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "583685669471432705",
  "text" : "RT @JohnKerry: HUGE thanks to our terrific team of U.S. diplomats and experts. Simply could not do #IranTalks without them.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IranTalks",
        "indices" : [ 84, 94 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "583684859484180480",
    "text" : "HUGE thanks to our terrific team of U.S. diplomats and experts. Simply could not do #IranTalks without them.",
    "id" : 583684859484180480,
    "created_at" : "2015-04-02 17:38:09 +0000",
    "user" : {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "protected" : false,
      "id_str" : "15007149",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/482149339842617346\/l6b7LXjb_normal.jpeg",
      "id" : 15007149,
      "verified" : true
    }
  },
  "id" : 583685669471432705,
  "created_at" : "2015-04-02 17:41:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "indices" : [ 3, 13 ],
      "id_str" : "15007149",
      "id" : 15007149
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EU",
      "indices" : [ 24, 27 ]
    }, {
      "text" : "Iran",
      "indices" : [ 39, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "583683800279883776",
  "text" : "RT @JohnKerry: Big day: #EU, P5+1, and #Iran now have parameters to resolve major issues on nuclear program. Back to work soon on a final d\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EU",
        "indices" : [ 9, 12 ]
      }, {
        "text" : "Iran",
        "indices" : [ 24, 29 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "583682960282558464",
    "text" : "Big day: #EU, P5+1, and #Iran now have parameters to resolve major issues on nuclear program. Back to work soon on a final deal.",
    "id" : 583682960282558464,
    "created_at" : "2015-04-02 17:30:36 +0000",
    "user" : {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "protected" : false,
      "id_str" : "15007149",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/482149339842617346\/l6b7LXjb_normal.jpeg",
      "id" : 15007149,
      "verified" : true
    }
  },
  "id" : 583683800279883776,
  "created_at" : "2015-04-02 17:33:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/583676387275341824\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/cYHO2vRY5y",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CBmiAwsUgAEbH5o.jpg",
      "id_str" : "583675760675684353",
      "id" : 583675760675684353,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBmiAwsUgAEbH5o.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/cYHO2vRY5y"
    } ],
    "hashtags" : [ {
      "text" : "BetterWithObamacare",
      "indices" : [ 96, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/yLJf2fGFdh",
      "expanded_url" : "http:\/\/go.wh.gov\/iHNc9D",
      "display_url" : "go.wh.gov\/iHNc9D"
    } ]
  },
  "geo" : { },
  "id_str" : "583676387275341824",
  "text" : "Get the facts on how the Affordable Care Act is benefiting our economy \u2192 http:\/\/t.co\/yLJf2fGFdh #BetterWithObamacare http:\/\/t.co\/cYHO2vRY5y",
  "id" : 583676387275341824,
  "created_at" : "2015-04-02 17:04:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Freida Pinto",
      "screen_name" : "BecauseImFreida",
      "indices" : [ 54, 70 ],
      "id_str" : "631232364",
      "id" : 631232364
    }, {
      "name" : "Glamour",
      "screen_name" : "glamourmag",
      "indices" : [ 74, 85 ],
      "id_str" : "19247844",
      "id" : 19247844
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LetGirlsLearn",
      "indices" : [ 110, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/eW8MoWAJbK",
      "expanded_url" : "http:\/\/glmr.me\/1MB458F",
      "display_url" : "glmr.me\/1MB458F"
    } ]
  },
  "geo" : { },
  "id_str" : "583671800178978817",
  "text" : "RT @FLOTUS: \"Girls deserve an education, full stop.\" \u2014@BecauseImFreida in @GlamourMag: http:\/\/t.co\/eW8MoWAJbK #LetGirlsLearn http:\/\/t.co\/pr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Freida Pinto",
        "screen_name" : "BecauseImFreida",
        "indices" : [ 42, 58 ],
        "id_str" : "631232364",
        "id" : 631232364
      }, {
        "name" : "Glamour",
        "screen_name" : "glamourmag",
        "indices" : [ 62, 73 ],
        "id_str" : "19247844",
        "id" : 19247844
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/583670875624316928\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/proxQqlg6Z",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CBmdcOFUgAAxzyt.jpg",
        "id_str" : "583670734863499264",
        "id" : 583670734863499264,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBmdcOFUgAAxzyt.jpg",
        "sizes" : [ {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/proxQqlg6Z"
      } ],
      "hashtags" : [ {
        "text" : "LetGirlsLearn",
        "indices" : [ 98, 112 ]
      } ],
      "urls" : [ {
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/eW8MoWAJbK",
        "expanded_url" : "http:\/\/glmr.me\/1MB458F",
        "display_url" : "glmr.me\/1MB458F"
      } ]
    },
    "geo" : { },
    "id_str" : "583670875624316928",
    "text" : "\"Girls deserve an education, full stop.\" \u2014@BecauseImFreida in @GlamourMag: http:\/\/t.co\/eW8MoWAJbK #LetGirlsLearn http:\/\/t.co\/proxQqlg6Z",
    "id" : 583670875624316928,
    "created_at" : "2015-04-02 16:42:35 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 583671800178978817,
  "created_at" : "2015-04-02 16:46:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WestWingWeek",
      "indices" : [ 19, 32 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/kopPwk6usM",
      "expanded_url" : "https:\/\/youtu.be\/hG1Nmy4gZIk",
      "display_url" : "youtu.be\/hG1Nmy4gZIk"
    } ]
  },
  "geo" : { },
  "id_str" : "583659962297004032",
  "text" : "Happy 5th Birthday #WestWingWeek!\nWatch President Obama and President Underwood take you behind the scenes \u2192 https:\/\/t.co\/kopPwk6usM",
  "id" : 583659962297004032,
  "created_at" : "2015-04-02 15:59:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sally Jewell",
      "screen_name" : "SecretaryJewell",
      "indices" : [ 3, 19 ],
      "id_str" : "1342861723",
      "id" : 1342861723
    }, {
      "name" : "NationalParkService",
      "screen_name" : "NatlParkService",
      "indices" : [ 92, 108 ],
      "id_str" : "36771809",
      "id" : 36771809
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FindYourPark",
      "indices" : [ 44, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/DOM7TNKsyJ",
      "expanded_url" : "http:\/\/FindYourPark.com",
      "display_url" : "FindYourPark.com"
    } ]
  },
  "geo" : { },
  "id_str" : "583644924400238593",
  "text" : "RT @SecretaryJewell: Excited to help launch #FindYourPark to inspire people to connect with @NatlParkService.SJ http:\/\/t.co\/DOM7TNKsyJ http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NationalParkService",
        "screen_name" : "NatlParkService",
        "indices" : [ 71, 87 ],
        "id_str" : "36771809",
        "id" : 36771809
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SecretaryJewell\/status\/583637244902150144\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/XvfJIuuMUN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CBl--xwVIAEBkdA.jpg",
        "id_str" : "583637243694227457",
        "id" : 583637243694227457,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBl--xwVIAEBkdA.jpg",
        "sizes" : [ {
          "h" : 1352,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2133,
          "resize" : "fit",
          "w" : 1615
        }, {
          "h" : 792,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 449,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/XvfJIuuMUN"
      } ],
      "hashtags" : [ {
        "text" : "FindYourPark",
        "indices" : [ 23, 36 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/DOM7TNKsyJ",
        "expanded_url" : "http:\/\/FindYourPark.com",
        "display_url" : "FindYourPark.com"
      } ]
    },
    "geo" : { },
    "id_str" : "583637244902150144",
    "text" : "Excited to help launch #FindYourPark to inspire people to connect with @NatlParkService.SJ http:\/\/t.co\/DOM7TNKsyJ http:\/\/t.co\/XvfJIuuMUN",
    "id" : 583637244902150144,
    "created_at" : "2015-04-02 14:28:57 +0000",
    "user" : {
      "name" : "Sally Jewell",
      "screen_name" : "SecretaryJewell",
      "protected" : false,
      "id_str" : "1342861723",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3525481506\/1ddf16c2cb47608803abe4dc7fc133fe_normal.jpeg",
      "id" : 1342861723,
      "verified" : true
    }
  },
  "id" : 583644924400238593,
  "created_at" : "2015-04-02 14:59:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Friedman",
      "screen_name" : "JFriedman44",
      "indices" : [ 3, 15 ],
      "id_str" : "596661417",
      "id" : 596661417
    }, {
      "name" : "Jason Furman",
      "screen_name" : "CEAChair",
      "indices" : [ 23, 32 ],
      "id_str" : "1861751828",
      "id" : 1861751828
    }, {
      "name" : "American Progress",
      "screen_name" : "amprog",
      "indices" : [ 36, 43 ],
      "id_str" : "17171111",
      "id" : 17171111
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "583630058469789696",
  "text" : "RT @JFriedman44: Watch @CEAChair at @amprog at 10AM: How the Affordable Care Act is reducing costs, improving quality\/ fiscal outlook http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jason Furman",
        "screen_name" : "CEAChair",
        "indices" : [ 6, 15 ],
        "id_str" : "1861751828",
        "id" : 1861751828
      }, {
        "name" : "American Progress",
        "screen_name" : "amprog",
        "indices" : [ 19, 26 ],
        "id_str" : "17171111",
        "id" : 17171111
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/XZPLquqoXq",
        "expanded_url" : "http:\/\/ampr.gs\/1CcbArb",
        "display_url" : "ampr.gs\/1CcbArb"
      } ]
    },
    "geo" : { },
    "id_str" : "583620166317023232",
    "text" : "Watch @CEAChair at @amprog at 10AM: How the Affordable Care Act is reducing costs, improving quality\/ fiscal outlook http:\/\/t.co\/XZPLquqoXq",
    "id" : 583620166317023232,
    "created_at" : "2015-04-02 13:21:05 +0000",
    "user" : {
      "name" : "Jennifer Friedman",
      "screen_name" : "JFriedman44",
      "protected" : false,
      "id_str" : "596661417",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563849150324695040\/vjoAfSjn_normal.jpeg",
      "id" : 596661417,
      "verified" : true
    }
  },
  "id" : 583630058469789696,
  "created_at" : "2015-04-02 14:00:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Medium",
      "screen_name" : "Medium",
      "indices" : [ 76, 83 ],
      "id_str" : "571202103",
      "id" : 571202103
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/583361870855299072\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/BkN1IVy4RP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CBiEgw6UwAAkuQg.jpg",
      "id_str" : "583361850164690944",
      "id" : 583361850164690944,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBiEgw6UwAAkuQg.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/BkN1IVy4RP"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/5ISaVdFxN0",
      "expanded_url" : "http:\/\/go.wh.gov\/cyber-sanctions",
      "display_url" : "go.wh.gov\/cyber-sanctions"
    } ]
  },
  "geo" : { },
  "id_str" : "583361870855299072",
  "text" : "Worth a read: President Obama on our new tool to counter cyber threats (via @Medium) \u2192 http:\/\/t.co\/5ISaVdFxN0 http:\/\/t.co\/BkN1IVy4RP",
  "id" : 583361870855299072,
  "created_at" : "2015-04-01 20:14:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Labor Department",
      "screen_name" : "USDOL",
      "indices" : [ 3, 9 ],
      "id_str" : "20179628",
      "id" : 20179628
    }, {
      "name" : "molly moon",
      "screen_name" : "mollymoon",
      "indices" : [ 98, 108 ],
      "id_str" : "1053901",
      "id" : 1053901
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LeadOnLeave",
      "indices" : [ 120, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "583351801350475776",
  "text" : "RT @USDOL: \"Paid leave is good for workers &amp; makes for healthy communities.\" \u2014Molly, owner of @MollyMoon in Seattle #LeadOnLeave http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "molly moon",
        "screen_name" : "mollymoon",
        "indices" : [ 87, 97 ],
        "id_str" : "1053901",
        "id" : 1053901
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/USDOL\/status\/583347544807309312\/photo\/1",
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/udeh3ZOWMf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CBh3dnKUUAAwFiU.jpg",
        "id_str" : "583347502356647936",
        "id" : 583347502356647936,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBh3dnKUUAAwFiU.jpg",
        "sizes" : [ {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/udeh3ZOWMf"
      } ],
      "hashtags" : [ {
        "text" : "LeadOnLeave",
        "indices" : [ 109, 121 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "583347544807309312",
    "text" : "\"Paid leave is good for workers &amp; makes for healthy communities.\" \u2014Molly, owner of @MollyMoon in Seattle #LeadOnLeave http:\/\/t.co\/udeh3ZOWMf",
    "id" : 583347544807309312,
    "created_at" : "2015-04-01 19:17:47 +0000",
    "user" : {
      "name" : "US Labor Department",
      "screen_name" : "USDOL",
      "protected" : false,
      "id_str" : "20179628",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655006480697978880\/Fom0f0nJ_normal.png",
      "id" : 20179628,
      "verified" : true
    }
  },
  "id" : 583351801350475776,
  "created_at" : "2015-04-01 19:34:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill de Blasio",
      "screen_name" : "BilldeBlasio",
      "indices" : [ 3, 16 ],
      "id_str" : "476193064",
      "id" : 476193064
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "583342246776340481",
  "text" : "RT @BilldeBlasio: For many New Yorkers, losing one day of pay can be a setback. Proud our city's leading the way on Paid Sick Leave. http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BilldeBlasio\/status\/583326398099652608\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/zcDvwphIpM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CBhkRJeW4AA3eiT.png",
        "id_str" : "583326397508280320",
        "id" : 583326397508280320,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBhkRJeW4AA3eiT.png",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/zcDvwphIpM"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "583326398099652608",
    "text" : "For many New Yorkers, losing one day of pay can be a setback. Proud our city's leading the way on Paid Sick Leave. http:\/\/t.co\/zcDvwphIpM",
    "id" : 583326398099652608,
    "created_at" : "2015-04-01 17:53:45 +0000",
    "user" : {
      "name" : "Bill de Blasio",
      "screen_name" : "NYCMayor",
      "protected" : false,
      "id_str" : "19834403",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797104781974192128\/xv2CMcBu_normal.jpg",
      "id" : 19834403,
      "verified" : true
    }
  },
  "id" : 583342246776340481,
  "created_at" : "2015-04-01 18:56:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FindYourPark",
      "indices" : [ 113, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/uyaHiQvsgP",
      "expanded_url" : "http:\/\/FindYourPark.com",
      "display_url" : "FindYourPark.com"
    } ]
  },
  "geo" : { },
  "id_str" : "583317245029326848",
  "text" : "RT @FLOTUS: RT if you agree: Every kid should be able to enjoy America's great outdoors \u2192 http:\/\/t.co\/uyaHiQvsgP #FindYourPark http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/583041154515488768\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/xwJ0tQsu8d",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CBdDMYCUsAAE4iR.jpg",
        "id_str" : "583008556657455104",
        "id" : 583008556657455104,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBdDMYCUsAAE4iR.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/xwJ0tQsu8d"
      } ],
      "hashtags" : [ {
        "text" : "FindYourPark",
        "indices" : [ 101, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/uyaHiQvsgP",
        "expanded_url" : "http:\/\/FindYourPark.com",
        "display_url" : "FindYourPark.com"
      } ]
    },
    "geo" : { },
    "id_str" : "583041154515488768",
    "text" : "RT if you agree: Every kid should be able to enjoy America's great outdoors \u2192 http:\/\/t.co\/uyaHiQvsgP #FindYourPark http:\/\/t.co\/xwJ0tQsu8d",
    "id" : 583041154515488768,
    "created_at" : "2015-03-31 23:00:18 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 583317245029326848,
  "created_at" : "2015-04-01 17:17:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HeadStartWorks",
      "indices" : [ 123, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "583306883399716864",
  "text" : "RT @vj44: Every single child should have access to quality early childhood education, regardless of their parents' income. #HeadStartWorks \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HeadStartWorks",
        "indices" : [ 113, 128 ]
      }, {
        "text" : "NHSA15",
        "indices" : [ 129, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "583271080950779905",
    "text" : "Every single child should have access to quality early childhood education, regardless of their parents' income. #HeadStartWorks #NHSA15",
    "id" : 583271080950779905,
    "created_at" : "2015-04-01 14:13:57 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 583306883399716864,
  "created_at" : "2015-04-01 16:36:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/583282016818368512\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/dYEDEQFN9K",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CBg7zyIXEAAq2mj.jpg",
      "id_str" : "583281912560685056",
      "id" : 583281912560685056,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBg7zyIXEAAq2mj.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/dYEDEQFN9K"
    } ],
    "hashtags" : [ {
      "text" : "CyberSanctions",
      "indices" : [ 100, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/HMhD67Ke9G",
      "expanded_url" : "http:\/\/go.wh.gov\/XYSyXs",
      "display_url" : "go.wh.gov\/XYSyXs"
    } ]
  },
  "geo" : { },
  "id_str" : "583282016818368512",
  "text" : "Here's what you need to know about our latest tool to combat cyber threats \u2192 http:\/\/t.co\/HMhD67Ke9G #CyberSanctions http:\/\/t.co\/dYEDEQFN9K",
  "id" : 583282016818368512,
  "created_at" : "2015-04-01 14:57:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/583267755987742720\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/itjQAgN56f",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CBgu5GPUkAAjA5G.jpg",
      "id_str" : "583267710206775296",
      "id" : 583267710206775296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBgu5GPUkAAjA5G.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/itjQAgN56f"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/5ISaVdFxN0",
      "expanded_url" : "http:\/\/go.wh.gov\/cyber-sanctions",
      "display_url" : "go.wh.gov\/cyber-sanctions"
    } ]
  },
  "geo" : { },
  "id_str" : "583267755987742720",
  "text" : "\"We\u2019re giving notice to those who pose significant threats to our security or economy\" \u2014Obama: http:\/\/t.co\/5ISaVdFxN0 http:\/\/t.co\/itjQAgN56f",
  "id" : 583267755987742720,
  "created_at" : "2015-04-01 14:00:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/583254939889090560\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/D924CkTWBH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CBgjKVxUUAA6iXh.jpg",
      "id_str" : "583254812294139904",
      "id" : 583254812294139904,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBgjKVxUUAA6iXh.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/D924CkTWBH"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/mu5xGcnw4G",
      "expanded_url" : "https:\/\/medium.com\/@PresidentObama\/a-new-tool-against-cyber-threats-1a30c188bc4",
      "display_url" : "medium.com\/@PresidentObam\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "583254939889090560",
  "text" : "Share the news: President Obama is creating a new tool to counter cyber threats \u2192 https:\/\/t.co\/mu5xGcnw4G http:\/\/t.co\/D924CkTWBH",
  "id" : 583254939889090560,
  "created_at" : "2015-04-01 13:09:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/583248452898799617\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/utred5jekO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CBgdWAXUkAA9_oi.png",
      "id_str" : "583248415636623360",
      "id" : 583248415636623360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CBgdWAXUkAA9_oi.png",
      "sizes" : [ {
        "h" : 456,
        "resize" : "fit",
        "w" : 1050
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 261,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 148,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 445,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/utred5jekO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "583248452898799617",
  "text" : "\"I extend congratulations to the people of Nigeria and to President-Elect Buhari\" \u2014Obama on the Nigerian elections http:\/\/t.co\/utred5jekO",
  "id" : 583248452898799617,
  "created_at" : "2015-04-01 12:44:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
} ]