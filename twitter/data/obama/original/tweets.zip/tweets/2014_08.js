Grailbird.data.tweets_2014_08 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WestWingWeek",
      "indices" : [ 70, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/4Ry3dkFzML",
      "expanded_url" : "http:\/\/youtu.be\/Q-uATxeJVNI",
      "display_url" : "youtu.be\/Q-uATxeJVNI"
    } ]
  },
  "geo" : { },
  "id_str" : "506245058102689792",
  "text" : "Presidents. Bison. And National Parks. Watch \u2192 http:\/\/t.co\/4Ry3dkFzML #WestWingWeek",
  "id" : 506245058102689792,
  "created_at" : "2014-09-01 01:00:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/VSVyPDFaNv",
      "expanded_url" : "http:\/\/go.wh.gov\/z4KMZn",
      "display_url" : "go.wh.gov\/z4KMZn"
    } ]
  },
  "geo" : { },
  "id_str" : "506097879060996100",
  "text" : "\"States where the minimum wage has gone up...have experienced higher job growth than the states that haven\u2019t\" \u2014Obama: http:\/\/t.co\/VSVyPDFaNv",
  "id" : 506097879060996100,
  "created_at" : "2014-08-31 15:15:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/VSVyPDFaNv",
      "expanded_url" : "http:\/\/go.wh.gov\/z4KMZn",
      "display_url" : "go.wh.gov\/z4KMZn"
    } ]
  },
  "geo" : { },
  "id_str" : "506082752915976193",
  "text" : "\"Until we\u2019ve got a Congress that cares about raising working folks\u2019 wages, it\u2019s up to the rest of us.\" \u2014Obama: http:\/\/t.co\/VSVyPDFaNv",
  "id" : 506082752915976193,
  "created_at" : "2014-08-31 14:15:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 97, 110 ]
    }, {
      "text" : "LaborDay",
      "indices" : [ 111, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/VSVyPDFaNv",
      "expanded_url" : "http:\/\/go.wh.gov\/z4KMZn",
      "display_url" : "go.wh.gov\/z4KMZn"
    } ]
  },
  "geo" : { },
  "id_str" : "505754385742176256",
  "text" : "Watch President Obama on why it\u2019s time to give working families a raise \u2192 http:\/\/t.co\/VSVyPDFaNv #RaiseTheWage #LaborDay",
  "id" : 505754385742176256,
  "created_at" : "2014-08-30 16:30:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 123, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/VSVyPDFaNv",
      "expanded_url" : "http:\/\/go.wh.gov\/z4KMZn",
      "display_url" : "go.wh.gov\/z4KMZn"
    } ]
  },
  "geo" : { },
  "id_str" : "505743009476911105",
  "text" : "\"Raising the minimum wage...would help around 28 million Americans from all walks of life.\" \u2014Obama: http:\/\/t.co\/VSVyPDFaNv #RaiseTheWage",
  "id" : 505743009476911105,
  "created_at" : "2014-08-30 15:45:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 122, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/VSVyPDFaNv",
      "expanded_url" : "http:\/\/go.wh.gov\/z4KMZn",
      "display_url" : "go.wh.gov\/z4KMZn"
    } ]
  },
  "geo" : { },
  "id_str" : "505731750404689921",
  "text" : "\"Over the past 53 months, our businesses have added nearly 10 million new jobs.\" \u2014President Obama: http:\/\/t.co\/VSVyPDFaNv #OpportunityForAll",
  "id" : 505731750404689921,
  "created_at" : "2014-08-30 15:00:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 126, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/GV43BIpXql",
      "expanded_url" : "http:\/\/go.wh.gov\/z4KMZn",
      "display_url" : "go.wh.gov\/z4KMZn"
    } ]
  },
  "geo" : { },
  "id_str" : "505720304761856000",
  "text" : "\"That\u2019s the bedrock this country is built on: Hard work. Responsibility. Sacrifice.\" \u2014President Obama: http:\/\/t.co\/GV43BIpXql #RaiseTheWage",
  "id" : 505720304761856000,
  "created_at" : "2014-08-30 14:14:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "indices" : [ 3, 12 ],
      "id_str" : "1604366701",
      "id" : 1604366701
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LaborDay",
      "indices" : [ 19, 28 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/sQimSRGU39",
      "expanded_url" : "http:\/\/huff.to\/1wOZ6cC",
      "display_url" : "huff.to\/1wOZ6cC"
    } ]
  },
  "geo" : { },
  "id_str" : "505450046868176896",
  "text" : "RT @LaborSec: This #LaborDay, let's remember the hardworking men &amp; women that are the backbone of our country. http:\/\/t.co\/sQimSRGU39 via @\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Huffington Post",
        "screen_name" : "HuffingtonPost",
        "indices" : [ 128, 143 ],
        "id_str" : "14511951",
        "id" : 14511951
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LaborDay",
        "indices" : [ 5, 14 ]
      } ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/sQimSRGU39",
        "expanded_url" : "http:\/\/huff.to\/1wOZ6cC",
        "display_url" : "huff.to\/1wOZ6cC"
      } ]
    },
    "geo" : { },
    "id_str" : "505449850402394112",
    "text" : "This #LaborDay, let's remember the hardworking men &amp; women that are the backbone of our country. http:\/\/t.co\/sQimSRGU39 via @HuffingtonPost",
    "id" : 505449850402394112,
    "created_at" : "2014-08-29 20:20:09 +0000",
    "user" : {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "protected" : false,
      "id_str" : "1604366701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744887280666611712\/eEeyFjs6_normal.jpg",
      "id" : 1604366701,
      "verified" : true
    }
  },
  "id" : 505450046868176896,
  "created_at" : "2014-08-29 20:20:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/505430311044673536\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/z6ldcnGfrS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BwOmMH4IgAAtxv7.jpg",
      "id_str" : "505430310398754816",
      "id" : 505430310398754816,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwOmMH4IgAAtxv7.jpg",
      "sizes" : [ {
        "h" : 729,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 729,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 427,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 242,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/z6ldcnGfrS"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505430311044673536",
  "text" : "President Obama reads briefing materials in the Oval Office before his first meeting this morning. http:\/\/t.co\/z6ldcnGfrS",
  "id" : 505430311044673536,
  "created_at" : "2014-08-29 19:02:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 121, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/ZnjE1eNCRW",
      "expanded_url" : "http:\/\/nyti.ms\/1mSuRrq",
      "display_url" : "nyti.ms\/1mSuRrq"
    } ]
  },
  "geo" : { },
  "id_str" : "505424705377927168",
  "text" : "FACT: In 2019, Medicare is estimated to cost $95 billion LESS than projections from 4 years ago \u2192 http:\/\/t.co\/ZnjE1eNCRW #ACAWorks",
  "id" : 505424705377927168,
  "created_at" : "2014-08-29 18:40:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 99, 110 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505419177751240704",
  "text" : "RT @Purse44: Excited to join the conv here where Dag left off-stay tuned for updates on all things @WhiteHouse broadcast + gloating about t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 86, 97 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "505418702532411392",
    "text" : "Excited to join the conv here where Dag left off-stay tuned for updates on all things @WhiteHouse broadcast + gloating about the Steelers",
    "id" : 505418702532411392,
    "created_at" : "2014-08-29 18:16:23 +0000",
    "user" : {
      "name" : "Rob O'Donnell",
      "screen_name" : "RODonnell44",
      "protected" : false,
      "id_str" : "1873091689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/664483086738952192\/UukL2zFT_normal.jpg",
      "id" : 1873091689,
      "verified" : true
    }
  },
  "id" : 505419177751240704,
  "created_at" : "2014-08-29 18:18:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 131, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/b9q7jMCANO",
      "expanded_url" : "http:\/\/nyti.ms\/1mSuRrq",
      "display_url" : "nyti.ms\/1mSuRrq"
    } ]
  },
  "geo" : { },
  "id_str" : "505393567909822464",
  "text" : "Thanks in part to the Affordable Care Act, Medicare is projected to cost much less than previous estimates: http:\/\/t.co\/b9q7jMCANO #ACAWorks",
  "id" : 505393567909822464,
  "created_at" : "2014-08-29 16:36:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 118, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/ZbhVQVkc9R",
      "expanded_url" : "http:\/\/go.wh.gov\/hQj2tT",
      "display_url" : "go.wh.gov\/hQj2tT"
    } ]
  },
  "geo" : { },
  "id_str" : "505387317667065856",
  "text" : "RT @vj44: Women entering the workforce after college earn less than men in almost every field: http:\/\/t.co\/ZbhVQVkc9R #EqualPay http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/505061006054522881\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/WZFPqsGDZC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BwJWTvOIYAAv9nk.jpg",
        "id_str" : "505061005312155648",
        "id" : 505061005312155648,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwJWTvOIYAAv9nk.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/WZFPqsGDZC"
      } ],
      "hashtags" : [ {
        "text" : "EqualPay",
        "indices" : [ 108, 117 ]
      } ],
      "urls" : [ {
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/ZbhVQVkc9R",
        "expanded_url" : "http:\/\/go.wh.gov\/hQj2tT",
        "display_url" : "go.wh.gov\/hQj2tT"
      } ]
    },
    "geo" : { },
    "id_str" : "505384007774007296",
    "text" : "Women entering the workforce after college earn less than men in almost every field: http:\/\/t.co\/ZbhVQVkc9R #EqualPay http:\/\/t.co\/WZFPqsGDZC",
    "id" : 505384007774007296,
    "created_at" : "2014-08-29 15:58:31 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 505387317667065856,
  "created_at" : "2014-08-29 16:11:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/505366811643084800\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/SGAlZWBNOK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BwNrxLvIgAA-ywl.jpg",
      "id_str" : "505366075903868928",
      "id" : 505366075903868928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwNrxLvIgAA-ywl.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/SGAlZWBNOK"
    } ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 102, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/NtUstzo8KB",
      "expanded_url" : "http:\/\/go.wh.gov\/hQj2tT",
      "display_url" : "go.wh.gov\/hQj2tT"
    } ]
  },
  "geo" : { },
  "id_str" : "505366811643084800",
  "text" : "Here's what the gender pay gap looks like for women 4 years after graduation \u2192 http:\/\/t.co\/NtUstzo8KB #EqualPay http:\/\/t.co\/SGAlZWBNOK",
  "id" : 505366811643084800,
  "created_at" : "2014-08-29 14:50:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/s4TeJxjbfZ",
      "expanded_url" : "http:\/\/go.wh.gov\/X5pwpD",
      "display_url" : "go.wh.gov\/X5pwpD"
    } ]
  },
  "geo" : { },
  "id_str" : "505361610035437568",
  "text" : "\"Rooting out a cancer like ISIL will not be quick or easy, but I\u2019m confident that we can, and we will.\" \u2014Obama: http:\/\/t.co\/s4TeJxjbfZ",
  "id" : 505361610035437568,
  "created_at" : "2014-08-29 14:29:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/505123560890044416\/photo\/1",
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/lzKNaBnq9D",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BwKPM5SIUAAMlPc.png",
      "id_str" : "505123559916982272",
      "id" : 505123559916982272,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwKPM5SIUAAMlPc.png",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 320,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 320,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/lzKNaBnq9D"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505123560890044416",
  "text" : "President Obama on protecting our people and supporting our partners who are taking the fight to ISIL: http:\/\/t.co\/lzKNaBnq9D",
  "id" : 505123560890044416,
  "created_at" : "2014-08-28 22:43:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 111, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505093317915594753",
  "text" : "\u201CIn the absence of Congressional action, I\u2019m going to do what I can to make the system work better.\u201D \u2014Obama on #ImmigrationReform",
  "id" : 505093317915594753,
  "created_at" : "2014-08-28 20:43:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505087272556167168",
  "text" : "\u201CISIL has come to represent the very worst elements in the region that we have to deal with collectively.\u201D \u2014President Obama",
  "id" : 505087272556167168,
  "created_at" : "2014-08-28 20:19:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505085813252960256",
  "text" : "\"This ongoing Russian incursion into Ukraine will only bring more costs and consequences for Russia.\" \u2014President Obama",
  "id" : 505085813252960256,
  "created_at" : "2014-08-28 20:13:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/b4tqL36eMn",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "505085619186700289",
  "text" : "\"Russia is responsible for the violence in eastern Ukraine.\" \u2014President Obama: http:\/\/t.co\/b4tqL36eMn",
  "id" : 505085619186700289,
  "created_at" : "2014-08-28 20:12:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505085477431808000",
  "text" : "\"Rooting out a cancer like ISIL will not be quick. But I\u2019m confident we can, and we will, working closely with our allies &amp; partners\" \u2014Obama",
  "id" : 505085477431808000,
  "created_at" : "2014-08-28 20:12:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505085200687464450",
  "text" : "RT @WHLive: \"We continue to be proud and grateful to our extraordinary personnel serving in this mission.\" \u2014President Obama on the situatio\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "505085161021906944",
    "text" : "\"We continue to be proud and grateful to our extraordinary personnel serving in this mission.\" \u2014President Obama on the situation in Iraq",
    "id" : 505085161021906944,
    "created_at" : "2014-08-28 20:11:01 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 505085200687464450,
  "created_at" : "2014-08-28 20:11:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505085058009796609",
  "text" : "\"Because of our strikes, the terrorists of ISIL are losing arms and equipment.\" \u2014President Obama on the situation in Iraq",
  "id" : 505085058009796609,
  "created_at" : "2014-08-28 20:10:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/505084965718327296\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/IHkH2Tn6wR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BwJsGX9IUAAK6hp.jpg",
      "id_str" : "505084964984344576",
      "id" : 505084964984344576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwJsGX9IUAAK6hp.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/IHkH2Tn6wR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505084965718327296",
  "text" : "\"Over the past 4 and a half years, our businesses have created nearly 10 million new jobs.\" \u2014President Obama http:\/\/t.co\/IHkH2Tn6wR",
  "id" : 505084965718327296,
  "created_at" : "2014-08-28 20:10:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505084812898869248",
  "text" : "RT @WHLive: \"This morning, we found out that our economy actually grew at a stronger clip in the 2nd quarter than we originally thought.\" \u2014\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "505084772348338178",
    "text" : "\"This morning, we found out that our economy actually grew at a stronger clip in the 2nd quarter than we originally thought.\" \u2014Obama",
    "id" : 505084772348338178,
    "created_at" : "2014-08-28 20:09:28 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 505084812898869248,
  "created_at" : "2014-08-28 20:09:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/b4tqL36eMn",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "505084678614036481",
  "text" : "Happening now: President Obama delivers a statement. Watch \u2192 http:\/\/t.co\/b4tqL36eMn",
  "id" : 505084678614036481,
  "created_at" : "2014-08-28 20:09:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/b4tqL36eMn",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "505075331548868608",
  "text" : "At 4pm ET, President Obama will deliver a statement from the Briefing Room. Watch here \u2192 http:\/\/t.co\/b4tqL36eMn",
  "id" : 505075331548868608,
  "created_at" : "2014-08-28 19:31:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/505072139448639489\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/AKXQ4tYNKP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BwJgbyeIYAIiHp4.jpg",
      "id_str" : "505072138739802114",
      "id" : 505072138739802114,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwJgbyeIYAIiHp4.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/AKXQ4tYNKP"
    } ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 98, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/dIVPxFEsmS",
      "expanded_url" : "http:\/\/go.wh.gov\/hQj2tT",
      "display_url" : "go.wh.gov\/hQj2tT"
    } ]
  },
  "geo" : { },
  "id_str" : "505072139448639489",
  "text" : "Let's keep fighting to give every woman the chance to realize her dreams \u2192 http:\/\/t.co\/dIVPxFEsmS #EqualPay http:\/\/t.co\/AKXQ4tYNKP",
  "id" : 505072139448639489,
  "created_at" : "2014-08-28 19:19:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/505061006054522881\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/IMJA3jyq6U",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BwJWTvOIYAAv9nk.jpg",
      "id_str" : "505061005312155648",
      "id" : 505061005312155648,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwJWTvOIYAAv9nk.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/IMJA3jyq6U"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505061006054522881",
  "text" : "Women make less than men in almost every field 4 years after graduation.\nRT if you agree it's time to change that. http:\/\/t.co\/IMJA3jyq6U",
  "id" : 505061006054522881,
  "created_at" : "2014-08-28 18:35:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephanie Young",
      "screen_name" : "Stephanie44",
      "indices" : [ 3, 15 ],
      "id_str" : "2750358085",
      "id" : 2750358085
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505036416951517184",
  "text" : "RT @Stephanie44: Thrilled to be officially back on Twitter &amp; honored to serve this President &amp; the American people! Follow for latest domes\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "505029491593584640",
    "text" : "Thrilled to be officially back on Twitter &amp; honored to serve this President &amp; the American people! Follow for latest domestic policy news.",
    "id" : 505029491593584640,
    "created_at" : "2014-08-28 16:29:48 +0000",
    "user" : {
      "name" : "Stephanie Young",
      "screen_name" : "Stephanie44",
      "protected" : false,
      "id_str" : "2750358085",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/505015747035140099\/NSAoTmbn_normal.jpeg",
      "id" : 2750358085,
      "verified" : true
    }
  },
  "id" : 505036416951517184,
  "created_at" : "2014-08-28 16:57:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/505015753574072322\/photo\/1",
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/QJXzudaFxs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BwIo4__IEAEmQxb.jpg",
      "id_str" : "505011067932905473",
      "id" : 505011067932905473,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwIo4__IEAEmQxb.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1050
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/QJXzudaFxs"
    } ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 86, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/Qb1U2HLAzS",
      "expanded_url" : "http:\/\/go.wh.gov\/oJzsBA",
      "display_url" : "go.wh.gov\/oJzsBA"
    } ]
  },
  "geo" : { },
  "id_str" : "505015753574072322",
  "text" : "FACT: American exports have grown by 3.7% over the last year \u2192 http:\/\/t.co\/Qb1U2HLAzS #MadeInAmerica http:\/\/t.co\/QJXzudaFxs",
  "id" : 505015753574072322,
  "created_at" : "2014-08-28 15:35:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/505008697115148289\/photo\/1",
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/Ie4k3Q7DZT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BwImu9_IYAAvoCy.jpg",
      "id_str" : "505008696574107648",
      "id" : 505008696574107648,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwImu9_IYAAvoCy.jpg",
      "sizes" : [ {
        "h" : 397,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 397,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 260,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 397,
        "resize" : "fit",
        "w" : 520
      } ],
      "display_url" : "pic.twitter.com\/Ie4k3Q7DZT"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/CmLhpoRyvY",
      "expanded_url" : "http:\/\/go.wh.gov\/oJzsBA",
      "display_url" : "go.wh.gov\/oJzsBA"
    } ]
  },
  "geo" : { },
  "id_str" : "505008697115148289",
  "text" : "Our economy grew at a 4.2% rate last quarter\u2014but there's more work to do \u2192 http:\/\/t.co\/CmLhpoRyvY http:\/\/t.co\/Ie4k3Q7DZT",
  "id" : 505008697115148289,
  "created_at" : "2014-08-28 15:07:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505002315804602368",
  "text" : "RT @Podesta44: The CA drought in 2 photos: Lake Oroville in 2011 and 2014. h\/t @Boots44 #ActOnClimate http:\/\/t.co\/9HTYy9ge5V http:\/\/t.co\/qI\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Podesta44\/status\/504998352648302594\/photo\/1",
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/qIPhDYg20d",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BwE0DRpIQAArNEB.png",
        "id_str" : "504741864122368000",
        "id" : 504741864122368000,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwE0DRpIQAArNEB.png",
        "sizes" : [ {
          "h" : 629,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 649
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 356,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 649
        } ],
        "display_url" : "pic.twitter.com\/qIPhDYg20d"
      } ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 73, 86 ]
      } ],
      "urls" : [ {
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/9HTYy9ge5V",
        "expanded_url" : "http:\/\/www.weather.com\/news\/science\/environment\/california-drought-devestating-photos-show-lakes-drying-20140825",
        "display_url" : "weather.com\/news\/science\/e\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "504998352648302594",
    "text" : "The CA drought in 2 photos: Lake Oroville in 2011 and 2014. h\/t @Boots44 #ActOnClimate http:\/\/t.co\/9HTYy9ge5V http:\/\/t.co\/qIPhDYg20d",
    "id" : 504998352648302594,
    "created_at" : "2014-08-28 14:26:04 +0000",
    "user" : {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "protected" : false,
      "id_str" : "2382117350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656551411145027584\/ArrSlGUP_normal.jpg",
      "id" : 2382117350,
      "verified" : true
    }
  },
  "id" : 505002315804602368,
  "created_at" : "2014-08-28 14:41:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/Qb1U2HLAzS",
      "expanded_url" : "http:\/\/go.wh.gov\/oJzsBA",
      "display_url" : "go.wh.gov\/oJzsBA"
    } ]
  },
  "geo" : { },
  "id_str" : "504995620801638400",
  "text" : "Over the last year:\nConsumer spending = \u2191 2.3%\nBusiness investment = \u2191 6.4%\nAmerican exports = \u2191 3.7%\nhttp:\/\/t.co\/Qb1U2HLAzS",
  "id" : 504995620801638400,
  "created_at" : "2014-08-28 14:15:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/CmLhpoRyvY",
      "expanded_url" : "http:\/\/go.wh.gov\/oJzsBA",
      "display_url" : "go.wh.gov\/oJzsBA"
    } ]
  },
  "geo" : { },
  "id_str" : "504987442697752576",
  "text" : "Good news: Our economy continues to grow.\n2nd-quarter GDP = \u2191 4.2%\nConsumer spending = \u2191\nBusiness investment = \u2191\nhttp:\/\/t.co\/CmLhpoRyvY",
  "id" : 504987442697752576,
  "created_at" : "2014-08-28 13:42:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/t01aCJMYPs",
      "expanded_url" : "http:\/\/53eig.ht\/1tAI5iq",
      "display_url" : "53eig.ht\/1tAI5iq"
    } ]
  },
  "geo" : { },
  "id_str" : "504743610295013376",
  "text" : "\"We're not going to stop until every veteran who defended America has a home in America.\" \u2014President Obama: http:\/\/t.co\/t01aCJMYPs",
  "id" : 504743610295013376,
  "created_at" : "2014-08-27 21:33:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/504715570089324545\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/wgpjyU0WrA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BwEcItbIYAALZAL.jpg",
      "id_str" : "504715569200128000",
      "id" : 504715569200128000,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwEcItbIYAALZAL.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/wgpjyU0WrA"
    } ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 101, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/uHRWXzTFwP",
      "expanded_url" : "http:\/\/tmblr.co\/ZW21es1PIAeXg",
      "display_url" : "tmblr.co\/ZW21es1PIAeXg"
    } ]
  },
  "geo" : { },
  "id_str" : "504715570089324545",
  "text" : "The gender pay gap still exists at all income levels. It's time to close it \u2192 http:\/\/t.co\/uHRWXzTFwP #EqualPay http:\/\/t.co\/wgpjyU0WrA",
  "id" : 504715570089324545,
  "created_at" : "2014-08-27 19:42:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/t01aCJMYPs",
      "expanded_url" : "http:\/\/53eig.ht\/1tAI5iq",
      "display_url" : "53eig.ht\/1tAI5iq"
    } ]
  },
  "geo" : { },
  "id_str" : "504705787957358593",
  "text" : "The number of homeless veterans has \u2193 33% since 2010.\nBut we can't stop until every U.S. veteran has a home \u2192 http:\/\/t.co\/t01aCJMYPs",
  "id" : 504705787957358593,
  "created_at" : "2014-08-27 19:03:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/504687392947994624\/photo\/1",
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/hBTsQTibqN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BwECgm8IYAAgQnS.jpg",
      "id_str" : "504687392474030080",
      "id" : 504687392474030080,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwECgm8IYAAgQnS.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/hBTsQTibqN"
    } ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 76, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/8EeBLQX7Cb",
      "expanded_url" : "http:\/\/wh.gov\/lh3Uv",
      "display_url" : "wh.gov\/lh3Uv"
    } ]
  },
  "geo" : { },
  "id_str" : "504687392947994624",
  "text" : "RT if you agree: It's long-past time to close the earnings gap &amp; ensure #EqualPay for women \u2192 http:\/\/t.co\/8EeBLQX7Cb http:\/\/t.co\/hBTsQTibqN",
  "id" : 504687392947994624,
  "created_at" : "2014-08-27 17:50:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/DU1368DsHp",
      "expanded_url" : "http:\/\/go.wh.gov\/5pWsFY",
      "display_url" : "go.wh.gov\/5pWsFY"
    } ]
  },
  "geo" : { },
  "id_str" : "504675327269158913",
  "text" : "President Obama announced a new financial partnership to help servicemembers lower their monthly mortgage payments \u2192 http:\/\/t.co\/DU1368DsHp",
  "id" : 504675327269158913,
  "created_at" : "2014-08-27 17:02:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "InsideTheWhiteHouse",
      "indices" : [ 68, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/fBalHkzVrN",
      "expanded_url" : "https:\/\/vine.co\/v\/MlpgP7L1YJa",
      "display_url" : "vine.co\/v\/MlpgP7L1YJa"
    } ]
  },
  "geo" : { },
  "id_str" : "504660317797093378",
  "text" : "Green Room. Red Room. Green Room. Red Room. https:\/\/t.co\/fBalHkzVrN #InsideTheWhiteHouse",
  "id" : 504660317797093378,
  "created_at" : "2014-08-27 16:02:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/SzpkKzQLQJ",
      "expanded_url" : "http:\/\/youtu.be\/DQe5P2k9Ius",
      "display_url" : "youtu.be\/DQe5P2k9Ius"
    } ]
  },
  "geo" : { },
  "id_str" : "504652610855768064",
  "text" : "\"If you\u2019re a medic in a warzone, you shouldn\u2019t have to go take nursing 101 to work in a hospital here.\" \u2014Obama: http:\/\/t.co\/SzpkKzQLQJ",
  "id" : 504652610855768064,
  "created_at" : "2014-08-27 15:32:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HonoringVets",
      "indices" : [ 120, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/h6rwY2ZOvn",
      "expanded_url" : "http:\/\/go.wh.gov\/dxSidB",
      "display_url" : "go.wh.gov\/dxSidB"
    } ]
  },
  "geo" : { },
  "id_str" : "504637024570068992",
  "text" : "Check out President Obama\u2019s 5 priorities to help fulfill our sacred obligation to our veterans \u2192 http:\/\/t.co\/h6rwY2ZOvn #HonoringVets",
  "id" : 504637024570068992,
  "created_at" : "2014-08-27 14:30:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/In20zUzNkq",
      "expanded_url" : "http:\/\/wh.gov\/veterans",
      "display_url" : "wh.gov\/veterans"
    } ]
  },
  "geo" : { },
  "id_str" : "504627258490097664",
  "text" : "\u201CUpholding our trust with our veterans is not just a matter of policy, it is a moral obligation.\u201D \u2014President Obama: http:\/\/t.co\/In20zUzNkq",
  "id" : 504627258490097664,
  "created_at" : "2014-08-27 13:51:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WomensEqualityDay",
      "indices" : [ 120, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/qgUrnfsXgh",
      "expanded_url" : "http:\/\/tmblr.co\/ZekEWy1PI8hFW",
      "display_url" : "tmblr.co\/ZekEWy1PI8hFW"
    } ]
  },
  "geo" : { },
  "id_str" : "504426318977835009",
  "text" : "The gender pay gap still exists at all income levels.\nRT if you agree it's time to change that \u2192 http:\/\/t.co\/qgUrnfsXgh #WomensEqualityDay",
  "id" : 504426318977835009,
  "created_at" : "2014-08-27 00:33:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WomensEqualityDay",
      "indices" : [ 109, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/kVbmadRix0",
      "expanded_url" : "http:\/\/go.wh.gov\/yoRgSA",
      "display_url" : "go.wh.gov\/yoRgSA"
    } ]
  },
  "geo" : { },
  "id_str" : "504409489161064448",
  "text" : "RT @FLOTUS: Let's keep working to give every woman the chance to realize her dreams \u2192 http:\/\/t.co\/kVbmadRix0 #WomensEqualityDay http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/FLOTUS\/status\/504408856039264256\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/vfBaTeFfeE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BwAFLoDIYAEfjcJ.jpg",
        "id_str" : "504408855552745473",
        "id" : 504408855552745473,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwAFLoDIYAEfjcJ.jpg",
        "sizes" : [ {
          "h" : 478,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 478,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 163,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 287,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/vfBaTeFfeE"
      } ],
      "hashtags" : [ {
        "text" : "WomensEqualityDay",
        "indices" : [ 97, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/kVbmadRix0",
        "expanded_url" : "http:\/\/go.wh.gov\/yoRgSA",
        "display_url" : "go.wh.gov\/yoRgSA"
      } ]
    },
    "geo" : { },
    "id_str" : "504408856039264256",
    "text" : "Let's keep working to give every woman the chance to realize her dreams \u2192 http:\/\/t.co\/kVbmadRix0 #WomensEqualityDay http:\/\/t.co\/vfBaTeFfeE",
    "id" : 504408856039264256,
    "created_at" : "2014-08-26 23:23:37 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 504409489161064448,
  "created_at" : "2014-08-26 23:26:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rep. John Yarmuth",
      "screen_name" : "RepJohnYarmuth",
      "indices" : [ 3, 18 ],
      "id_str" : "384913290",
      "id" : 384913290
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "equalpay",
      "indices" : [ 117, 126 ]
    }, {
      "text" : "WEmatter",
      "indices" : [ 128, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "504380598631550976",
  "text" : "RT @RepJohnYarmuth: By age 65, avg US woman will have lost $431K over her working life b\/c of pay gap. Past time for #equalpay. #WEmatter h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/RepJohnYarmuth\/status\/504312757983125504\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/2uXCJQDCWw",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bv-tx2wCcAAKiVP.jpg",
        "id_str" : "504312755310981120",
        "id" : 504312755310981120,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bv-tx2wCcAAKiVP.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/2uXCJQDCWw"
      } ],
      "hashtags" : [ {
        "text" : "equalpay",
        "indices" : [ 97, 106 ]
      }, {
        "text" : "WEmatter",
        "indices" : [ 108, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "504312757983125504",
    "text" : "By age 65, avg US woman will have lost $431K over her working life b\/c of pay gap. Past time for #equalpay. #WEmatter http:\/\/t.co\/2uXCJQDCWw",
    "id" : 504312757983125504,
    "created_at" : "2014-08-26 17:01:45 +0000",
    "user" : {
      "name" : "Rep. John Yarmuth",
      "screen_name" : "RepJohnYarmuth",
      "protected" : false,
      "id_str" : "384913290",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1572572408\/John_Yarmuth_-_twitter_portrait_normal.jpg",
      "id" : 384913290,
      "verified" : true
    }
  },
  "id" : 504380598631550976,
  "created_at" : "2014-08-26 21:31:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/504368255956684801\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/Kx6pi0TtAJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bv_gQYxIIAAwFAR.jpg",
      "id_str" : "504368255419817984",
      "id" : 504368255419817984,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bv_gQYxIIAAwFAR.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/Kx6pi0TtAJ"
    } ],
    "hashtags" : [ {
      "text" : "WomenSucceed",
      "indices" : [ 23, 36 ]
    }, {
      "text" : "RaiseTheWage",
      "indices" : [ 76, 89 ]
    }, {
      "text" : "WomensEqualityDay",
      "indices" : [ 90, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "504368255956684801",
  "text" : "Let's help millions of #WomenSucceed by raising the minimum wage to $10.10. #RaiseTheWage #WomensEqualityDay http:\/\/t.co\/Kx6pi0TtAJ",
  "id" : 504368255956684801,
  "created_at" : "2014-08-26 20:42:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Oberholtzer",
      "screen_name" : "ilovecharts",
      "indices" : [ 3, 15 ],
      "id_str" : "116498184",
      "id" : 116498184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "504360543353073664",
  "text" : "RT @ilovecharts: .@CEABetsey breaks down how women have been doing some serious glass-ceiling cracking since the 1960's: http:\/\/t.co\/gMLokd\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/gMLokdP4PW",
        "expanded_url" : "http:\/\/tmblr.co\/ZekEWy1PGuEjf",
        "display_url" : "tmblr.co\/ZekEWy1PGuEjf"
      } ]
    },
    "geo" : { },
    "id_str" : "504356367151665153",
    "text" : ".@CEABetsey breaks down how women have been doing some serious glass-ceiling cracking since the 1960's: http:\/\/t.co\/gMLokdP4PW",
    "id" : 504356367151665153,
    "created_at" : "2014-08-26 19:55:03 +0000",
    "user" : {
      "name" : "Jason Oberholtzer",
      "screen_name" : "ilovecharts",
      "protected" : false,
      "id_str" : "116498184",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/651058815098556416\/l6rzEtCO_normal.jpg",
      "id" : 116498184,
      "verified" : true
    }
  },
  "id" : 504360543353073664,
  "created_at" : "2014-08-26 20:11:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "indices" : [ 3, 15 ],
      "id_str" : "369232105",
      "id" : 369232105
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WomensEqualityDay",
      "indices" : [ 110, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/05fNmIUVQb",
      "expanded_url" : "http:\/\/go.wh.gov\/VVXBMx",
      "display_url" : "go.wh.gov\/VVXBMx"
    } ]
  },
  "geo" : { },
  "id_str" : "504357258776813568",
  "text" : "RT @PAniskoff44: It's time to end workplace policies that belong in a Mad Men episode: http:\/\/t.co\/05fNmIUVQb #WomensEqualityDay http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PAniskoff44\/status\/504355870265073664\/photo\/1",
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/k1shOW1rtG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bv_U_YzCQAAOulG.jpg",
        "id_str" : "504355868742139904",
        "id" : 504355868742139904,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bv_U_YzCQAAOulG.jpg",
        "sizes" : [ {
          "h" : 478,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 478,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 163,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 287,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/k1shOW1rtG"
      } ],
      "hashtags" : [ {
        "text" : "WomensEqualityDay",
        "indices" : [ 93, 111 ]
      } ],
      "urls" : [ {
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/05fNmIUVQb",
        "expanded_url" : "http:\/\/go.wh.gov\/VVXBMx",
        "display_url" : "go.wh.gov\/VVXBMx"
      } ]
    },
    "geo" : { },
    "id_str" : "504355870265073664",
    "text" : "It's time to end workplace policies that belong in a Mad Men episode: http:\/\/t.co\/05fNmIUVQb #WomensEqualityDay http:\/\/t.co\/k1shOW1rtG",
    "id" : 504355870265073664,
    "created_at" : "2014-08-26 19:53:04 +0000",
    "user" : {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "protected" : false,
      "id_str" : "369232105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623146355767140352\/58sqoVrw_normal.jpg",
      "id" : 369232105,
      "verified" : true
    }
  },
  "id" : 504357258776813568,
  "created_at" : "2014-08-26 19:58:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/504345057303228417\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/C8QvttmthF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bv_LKA9IIAI_KqH.jpg",
      "id_str" : "504345056204300290",
      "id" : 504345056204300290,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bv_LKA9IIAI_KqH.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/C8QvttmthF"
    } ],
    "hashtags" : [ {
      "text" : "WomensEqualityDay",
      "indices" : [ 88, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "504345057303228417",
  "text" : "RT if you agree: Women should earn the same pay as men for doing the same work. Period. #WomensEqualityDay http:\/\/t.co\/C8QvttmthF",
  "id" : 504345057303228417,
  "created_at" : "2014-08-26 19:10:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/504335052319100928\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/rLFcKo2hLf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bv--ouBIMAAmf3E.jpg",
      "id_str" : "504331290045591552",
      "id" : 504331290045591552,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bv--ouBIMAAmf3E.jpg",
      "sizes" : [ {
        "h" : 478,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 478,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 163,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 287,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/rLFcKo2hLf"
    } ],
    "hashtags" : [ {
      "text" : "WomensEqualityDay",
      "indices" : [ 97, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/zS5rzDpUDq",
      "expanded_url" : "http:\/\/go.wh.gov\/VVXBMx",
      "display_url" : "go.wh.gov\/VVXBMx"
    } ]
  },
  "geo" : { },
  "id_str" : "504335052319100928",
  "text" : "Let's keep working to give every woman the chance to realize her dreams \u2192 http:\/\/t.co\/zS5rzDpUDq #WomensEqualityDay http:\/\/t.co\/rLFcKo2hLf",
  "id" : 504335052319100928,
  "created_at" : "2014-08-26 18:30:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WomensEqualityDay",
      "indices" : [ 110, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "504330396583329793",
  "text" : "RT @VP: \"I will not rest until my granddaughters have every single right my son &amp; my grandsons have.\" -VP #WomensEqualityDay http:\/\/t.co\/Qy\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/504330225732575232\/photo\/1",
        "indices" : [ 121, 143 ],
        "url" : "http:\/\/t.co\/QyLQojYpTd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bv-9qqvIcAApYkK.jpg",
        "id_str" : "504330224012914688",
        "id" : 504330224012914688,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bv-9qqvIcAApYkK.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 436,
          "resize" : "fit",
          "w" : 654
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 436,
          "resize" : "fit",
          "w" : 654
        } ],
        "display_url" : "pic.twitter.com\/QyLQojYpTd"
      } ],
      "hashtags" : [ {
        "text" : "WomensEqualityDay",
        "indices" : [ 102, 120 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "504330225732575232",
    "text" : "\"I will not rest until my granddaughters have every single right my son &amp; my grandsons have.\" -VP #WomensEqualityDay http:\/\/t.co\/QyLQojYpTd",
    "id" : 504330225732575232,
    "created_at" : "2014-08-26 18:11:10 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 504330396583329793,
  "created_at" : "2014-08-26 18:11:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "indices" : [ 3, 15 ],
      "id_str" : "15764644",
      "id" : 15764644
    }, {
      "name" : "House Republicans",
      "screen_name" : "HouseGOP",
      "indices" : [ 18, 27 ],
      "id_str" : "15207668",
      "id" : 15207668
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "equalpay",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/SJlK9Mu7fv",
      "expanded_url" : "http:\/\/Dems.gov\/Jumpstart",
      "display_url" : "Dems.gov\/Jumpstart"
    } ]
  },
  "geo" : { },
  "id_str" : "504326788999573505",
  "text" : "RT @NancyPelosi: .@HouseGOP has refused to ensure #equalpay for equal work. RT if you support http:\/\/t.co\/SJlK9Mu7fv that levels the playin\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "House Republicans",
        "screen_name" : "HouseGOP",
        "indices" : [ 1, 10 ],
        "id_str" : "15207668",
        "id" : 15207668
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "equalpay",
        "indices" : [ 33, 42 ]
      }, {
        "text" : "WEmatter",
        "indices" : [ 131, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/SJlK9Mu7fv",
        "expanded_url" : "http:\/\/Dems.gov\/Jumpstart",
        "display_url" : "Dems.gov\/Jumpstart"
      } ]
    },
    "geo" : { },
    "id_str" : "504314544312057856",
    "text" : ".@HouseGOP has refused to ensure #equalpay for equal work. RT if you support http:\/\/t.co\/SJlK9Mu7fv that levels the playing field. #WEmatter",
    "id" : 504314544312057856,
    "created_at" : "2014-08-26 17:08:51 +0000",
    "user" : {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "protected" : false,
      "id_str" : "15764644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571313158510223360\/wnSl3yXF_normal.jpeg",
      "id" : 15764644,
      "verified" : true
    }
  },
  "id" : 504326788999573505,
  "created_at" : "2014-08-26 17:57:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Oberholtzer",
      "screen_name" : "ilovecharts",
      "indices" : [ 3, 15 ],
      "id_str" : "116498184",
      "id" : 116498184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "504317267606532096",
  "text" : "RT @ilovecharts: .@CEABetsey is taking over http:\/\/t.co\/vluQXWk9hN in honor of #WomensEqualityDay. Check out her first post: http:\/\/t.co\/wG\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WomensEqualityDay",
        "indices" : [ 62, 80 ]
      } ],
      "urls" : [ {
        "indices" : [ 27, 49 ],
        "url" : "http:\/\/t.co\/vluQXWk9hN",
        "expanded_url" : "http:\/\/ILoveCharts.Tumblr.com",
        "display_url" : "ILoveCharts.Tumblr.com"
      }, {
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/wGBx16wWfo",
        "expanded_url" : "http:\/\/tmblr.co\/ZekEWy1PG9N7R",
        "display_url" : "tmblr.co\/ZekEWy1PG9N7R"
      } ]
    },
    "geo" : { },
    "id_str" : "504309946566336512",
    "text" : ".@CEABetsey is taking over http:\/\/t.co\/vluQXWk9hN in honor of #WomensEqualityDay. Check out her first post: http:\/\/t.co\/wGBx16wWfo",
    "id" : 504309946566336512,
    "created_at" : "2014-08-26 16:50:35 +0000",
    "user" : {
      "name" : "Jason Oberholtzer",
      "screen_name" : "ilovecharts",
      "protected" : false,
      "id_str" : "116498184",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/651058815098556416\/l6rzEtCO_normal.jpg",
      "id" : 116498184,
      "verified" : true
    }
  },
  "id" : 504317267606532096,
  "created_at" : "2014-08-26 17:19:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnJobs",
      "indices" : [ 114, 124 ]
    }, {
      "text" : "ALConvention",
      "indices" : [ 125, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "504307083786067968",
  "text" : "\u201CIf you want somebody who knows how to get the job done, no matter the mission, hire a veteran.\u201D \u2014President Obama #ActOnJobs #ALConvention",
  "id" : 504307083786067968,
  "created_at" : "2014-08-26 16:39:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "504306101102190592",
  "text" : "\"We\u2019re not going to stop until every veteran who defended America has a home in America.\" \u2014President Obama on ending veteran homelessness",
  "id" : 504306101102190592,
  "created_at" : "2014-08-26 16:35:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ALConvention",
      "indices" : [ 122, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "504305407557652480",
  "text" : "\"They were there for America, now we need to be there for them.\" \u2014Obama on helping our veterans with mental health issues #ALConvention",
  "id" : 504305407557652480,
  "created_at" : "2014-08-26 16:32:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "504304867742326784",
  "text" : "RT @WHLive: \"I\u2019m announcing 19 new executive actions to help improve mental health care for...American heroes and their families.\" \u2014Obama #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ALConvention",
        "indices" : [ 126, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "504304825795084288",
    "text" : "\"I\u2019m announcing 19 new executive actions to help improve mental health care for...American heroes and their families.\" \u2014Obama #ALConvention",
    "id" : 504304825795084288,
    "created_at" : "2014-08-26 16:30:14 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 504304867742326784,
  "created_at" : "2014-08-26 16:30:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/504304544818675712\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/qvLrJwXGQ4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bv-mT47IEAAWi3h.png",
      "id_str" : "504304543916888064",
      "id" : 504304543916888064,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bv-mT47IEAAWi3h.png",
      "sizes" : [ {
        "h" : 335,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 356,
        "resize" : "fit",
        "w" : 637
      }, {
        "h" : 190,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 356,
        "resize" : "fit",
        "w" : 637
      } ],
      "display_url" : "pic.twitter.com\/qvLrJwXGQ4"
    } ],
    "hashtags" : [ {
      "text" : "ALConvention",
      "indices" : [ 103, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "504304544818675712",
  "text" : "\"We need to make sure veterans are actually getting the health care you need when you need it.\" \u2014Obama #ALConvention http:\/\/t.co\/qvLrJwXGQ4",
  "id" : 504304544818675712,
  "created_at" : "2014-08-26 16:29:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Veterans Affairs",
      "screen_name" : "DeptVetAffairs",
      "indices" : [ 131, 146 ],
      "id_str" : "78408666",
      "id" : 78408666
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "504303566472110080",
  "text" : "\"We\u2019re going to fix what\u2019s wrong &amp; we\u2019re going to do right by you &amp; your families. That is a solemn pledge.\" \u2014Obama on the @DeptVetAffairs",
  "id" : 504303566472110080,
  "created_at" : "2014-08-26 16:25:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HonoringVets",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "504302888144084993",
  "text" : "RT @WHLive: \"Upholding our trust with our veterans is not just a matter of policy; it is a moral obligation.\" \u2014President Obama #HonoringVets",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HonoringVets",
        "indices" : [ 115, 128 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "504302855738912768",
    "text" : "\"Upholding our trust with our veterans is not just a matter of policy; it is a moral obligation.\" \u2014President Obama #HonoringVets",
    "id" : 504302855738912768,
    "created_at" : "2014-08-26 16:22:24 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 504302888144084993,
  "created_at" : "2014-08-26 16:22:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "504301903539617792",
  "text" : "\"American combat troops will not be returning to fight in Iraq...ultimately it\u2019s up to Iraqis to bridge their differences.\" \u2014President Obama",
  "id" : 504301903539617792,
  "created_at" : "2014-08-26 16:18:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "504301501574311936",
  "text" : "RT @WHLive: \"We removed more than 140,000 troops from Iraq and welcomed our troops home\u2014it was the right thing to do.\" \u2014President Obama #AL\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ALConvention",
        "indices" : [ 124, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "504301456527458305",
    "text" : "\"We removed more than 140,000 troops from Iraq and welcomed our troops home\u2014it was the right thing to do.\" \u2014President Obama #ALConvention",
    "id" : 504301456527458305,
    "created_at" : "2014-08-26 16:16:51 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 504301501574311936,
  "created_at" : "2014-08-26 16:17:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ALConvention",
      "indices" : [ 120, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "504301316609695745",
  "text" : "\"We should never send America\u2019s sons and daughters into harm\u2019s way unless it is absolutely necessary.\" \u2014President Obama #ALConvention",
  "id" : 504301316609695745,
  "created_at" : "2014-08-26 16:16:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ALConvention",
      "indices" : [ 107, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "504300791239544832",
  "text" : "RT @WHLive: \"You know that cynicism is not the character of a great nation.\" \u2014Obama to our veterans at the #ALConvention: http:\/\/t.co\/AGvpb\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ALConvention",
        "indices" : [ 95, 108 ]
      } ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/AGvpbNmCcC",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "504300767625637889",
    "text" : "\"You know that cynicism is not the character of a great nation.\" \u2014Obama to our veterans at the #ALConvention: http:\/\/t.co\/AGvpbNmCcC",
    "id" : 504300767625637889,
    "created_at" : "2014-08-26 16:14:07 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 504300791239544832,
  "created_at" : "2014-08-26 16:14:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "504300474196312064",
  "text" : "\"Just as you defended America over there, you helped build America here at home\u2014as leaders &amp; role models in your communities\" \u2014Obama to vets",
  "id" : 504300474196312064,
  "created_at" : "2014-08-26 16:12:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ALConvention",
      "indices" : [ 129, 142 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "504299822703443968",
  "text" : "\"You put on that uniform &amp; earned the title you carry to this day. Soldier. Sailor. Airman.  Marine.\" \u2014Obama to our veterans #ALConvention",
  "id" : 504299822703443968,
  "created_at" : "2014-08-26 16:10:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "504299561066958848",
  "text" : "\"When your country needed you most, you stepped forward. You raised your right hand. You swore a solemn oath.\" \u2014Obama to our veterans",
  "id" : 504299561066958848,
  "created_at" : "2014-08-26 16:09:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "The American Legion",
      "screen_name" : "AmericanLegion",
      "indices" : [ 69, 84 ],
      "id_str" : "27048645",
      "id" : 27048645
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/AGvpbNmCcC",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "504298709954617345",
  "text" : "RT @WHLive: Happening now: President Obama speaks to veterans at the @AmericanLegion's 96th National Convention \u2192 http:\/\/t.co\/AGvpbNmCcC #H\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The American Legion",
        "screen_name" : "AmericanLegion",
        "indices" : [ 57, 72 ],
        "id_str" : "27048645",
        "id" : 27048645
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HonoringVets",
        "indices" : [ 125, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/AGvpbNmCcC",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "504298684461621248",
    "text" : "Happening now: President Obama speaks to veterans at the @AmericanLegion's 96th National Convention \u2192 http:\/\/t.co\/AGvpbNmCcC #HonoringVets",
    "id" : 504298684461621248,
    "created_at" : "2014-08-26 16:05:50 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 504298709954617345,
  "created_at" : "2014-08-26 16:05:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The American Legion",
      "screen_name" : "AmericanLegion",
      "indices" : [ 54, 69 ],
      "id_str" : "27048645",
      "id" : 27048645
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HonoringVets",
      "indices" : [ 124, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/b4tqL36eMn",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "504296225055973376",
  "text" : "At 12pm ET, President Obama speaks to veterans at the @AmericanLegion's National Convention. Watch \u2192 http:\/\/t.co\/b4tqL36eMn #HonoringVets",
  "id" : 504296225055973376,
  "created_at" : "2014-08-26 15:56:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/504289096488194048\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/8XIIUZPGGe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bv-YQs1IQAAhuUc.jpg",
      "id_str" : "504289095968112640",
      "id" : 504289095968112640,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bv-YQs1IQAAhuUc.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/8XIIUZPGGe"
    } ],
    "hashtags" : [ {
      "text" : "WomenSucceed",
      "indices" : [ 32, 45 ]
    }, {
      "text" : "RaiseTheWage",
      "indices" : [ 75, 88 ]
    }, {
      "text" : "WomensEqualityDay",
      "indices" : [ 89, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "504289096488194048",
  "text" : "Congress could help millions of #WomenSucceed by raising the minimum wage. #RaiseTheWage #WomensEqualityDay http:\/\/t.co\/8XIIUZPGGe",
  "id" : 504289096488194048,
  "created_at" : "2014-08-26 15:27:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Oberholtzer",
      "screen_name" : "ilovecharts",
      "indices" : [ 51, 63 ],
      "id_str" : "116498184",
      "id" : 116498184
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WomensEqualityDay",
      "indices" : [ 74, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "504285522291077121",
  "text" : "RT @CEABetsey: I am very excited to be taking over @ilovecharts today for #WomensEqualityDay. Check out our charts at: http:\/\/t.co\/NfyD774N\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jason Oberholtzer",
        "screen_name" : "ilovecharts",
        "indices" : [ 36, 48 ],
        "id_str" : "116498184",
        "id" : 116498184
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WomensEqualityDay",
        "indices" : [ 59, 77 ]
      } ],
      "urls" : [ {
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/NfyD774NAc",
        "expanded_url" : "http:\/\/ilovecharts.tumblr.com\/post\/95778401181\/crazy-thrilled-to-announce-that-tomorrow-august",
        "display_url" : "ilovecharts.tumblr.com\/post\/957784011\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "504284719950086144",
    "text" : "I am very excited to be taking over @ilovecharts today for #WomensEqualityDay. Check out our charts at: http:\/\/t.co\/NfyD774NAc",
    "id" : 504284719950086144,
    "created_at" : "2014-08-26 15:10:21 +0000",
    "user" : {
      "name" : "Sandy Black",
      "screen_name" : "CEASandy",
      "protected" : false,
      "id_str" : "1979039203",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/707608742498439169\/VDM-nQKG_normal.jpg",
      "id" : 1979039203,
      "verified" : true
    }
  },
  "id" : 504285522291077121,
  "created_at" : "2014-08-26 15:13:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/504278489202425856\/photo\/1",
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/LBld03iKOX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bv-OnPBIMAAGWqF.jpg",
      "id_str" : "504278487986089984",
      "id" : 504278487986089984,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bv-OnPBIMAAGWqF.jpg",
      "sizes" : [ {
        "h" : 478,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 478,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 163,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 287,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/LBld03iKOX"
    } ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 37, 46 ]
    }, {
      "text" : "WomensEqualityDay",
      "indices" : [ 82, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/Gl6KNF4mnc",
      "expanded_url" : "http:\/\/go.wh.gov\/dMN7yV",
      "display_url" : "go.wh.gov\/dMN7yV"
    } ]
  },
  "geo" : { },
  "id_str" : "504278489202425856",
  "text" : "RT if you agree: It's time to ensure #EqualPay for women \u2192 http:\/\/t.co\/Gl6KNF4mnc #WomensEqualityDay http:\/\/t.co\/LBld03iKOX",
  "id" : 504278489202425856,
  "created_at" : "2014-08-26 14:45:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WomensEqualityDay",
      "indices" : [ 4, 22 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/Gl6KNF4mnc",
      "expanded_url" : "http:\/\/go.wh.gov\/dMN7yV",
      "display_url" : "go.wh.gov\/dMN7yV"
    } ]
  },
  "geo" : { },
  "id_str" : "504268295688945664",
  "text" : "\"On #WomensEqualityDay, we continue the righteous work of building a society where women thrive.\" \u2014President Obama: http:\/\/t.co\/Gl6KNF4mnc",
  "id" : 504268295688945664,
  "created_at" : "2014-08-26 14:05:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 112, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "504030005157171200",
  "text" : "RT @VP: \"Nobody in America who works full-time should have to live in poverty.\" -VP Biden in Chicago on need to #RaiseTheWage http:\/\/t.co\/3\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/504027393598971904\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/3M8HMDLs1n",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bv6qPkxCIAAMlym.jpg",
        "id_str" : "504027392856170496",
        "id" : 504027392856170496,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bv6qPkxCIAAMlym.jpg",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/3M8HMDLs1n"
      } ],
      "hashtags" : [ {
        "text" : "RaiseTheWage",
        "indices" : [ 104, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "504027393598971904",
    "text" : "\"Nobody in America who works full-time should have to live in poverty.\" -VP Biden in Chicago on need to #RaiseTheWage http:\/\/t.co\/3M8HMDLs1n",
    "id" : 504027393598971904,
    "created_at" : "2014-08-25 22:07:49 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 504030005157171200,
  "created_at" : "2014-08-25 22:18:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Video",
      "screen_name" : "WHVideo",
      "indices" : [ 3, 11 ],
      "id_str" : "1378231782",
      "id" : 1378231782
    }, {
      "name" : "NationalParkService",
      "screen_name" : "NatlParkService",
      "indices" : [ 40, 56 ],
      "id_str" : "36771809",
      "id" : 36771809
    }, {
      "name" : "YellowstoneNPS",
      "screen_name" : "YellowstoneNPS",
      "indices" : [ 106, 121 ],
      "id_str" : "44992488",
      "id" : 44992488
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "504001184508948481",
  "text" : "RT @WHVideo: Happy 98th Birthday to the @NatlParkService! Entrance fees are waived today. See POTUS visit @YellowstoneNPS in '09 \u2192 http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NationalParkService",
        "screen_name" : "NatlParkService",
        "indices" : [ 27, 43 ],
        "id_str" : "36771809",
        "id" : 36771809
      }, {
        "name" : "YellowstoneNPS",
        "screen_name" : "YellowstoneNPS",
        "indices" : [ 93, 108 ],
        "id_str" : "44992488",
        "id" : 44992488
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/Gp8nPhKnS8",
        "expanded_url" : "http:\/\/youtu.be\/TX1IB3RCLzg",
        "display_url" : "youtu.be\/TX1IB3RCLzg"
      } ]
    },
    "geo" : { },
    "id_str" : "503959370393468928",
    "text" : "Happy 98th Birthday to the @NatlParkService! Entrance fees are waived today. See POTUS visit @YellowstoneNPS in '09 \u2192 http:\/\/t.co\/Gp8nPhKnS8",
    "id" : 503959370393468928,
    "created_at" : "2014-08-25 17:37:31 +0000",
    "user" : {
      "name" : "White House Video",
      "screen_name" : "WHVideo",
      "protected" : false,
      "id_str" : "1378231782",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3636216064\/e21f3204adfdbc85dafef197487218a0_normal.jpeg",
      "id" : 1378231782,
      "verified" : true
    }
  },
  "id" : 504001184508948481,
  "created_at" : "2014-08-25 20:23:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "503991127448752128",
  "text" : "RT @pfeiffer44: The House GOP won't allow workers to be paid $10.10\/hr but will pay attorneys $500\/hr of taxpayer money to sue Obama\nhttps:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/TUpR9hMV0L",
        "expanded_url" : "https:\/\/twitter.com\/frankthorpNBC\/status\/503974383698710528",
        "display_url" : "twitter.com\/frankthorpNBC\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "503987873331548163",
    "text" : "The House GOP won't allow workers to be paid $10.10\/hr but will pay attorneys $500\/hr of taxpayer money to sue Obama\nhttps:\/\/t.co\/TUpR9hMV0L",
    "id" : 503987873331548163,
    "created_at" : "2014-08-25 19:30:47 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 503991127448752128,
  "created_at" : "2014-08-25 19:43:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/503973883976761344\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/Vp4zsM7Zhu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bv53dFgIAAAO2XF.jpg",
      "id_str" : "503971549888905216",
      "id" : 503971549888905216,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bv53dFgIAAAO2XF.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Vp4zsM7Zhu"
    } ],
    "hashtags" : [ {
      "text" : "NationalParks",
      "indices" : [ 25, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "503973883976761344",
  "text" : "FACT: In 2013, America's #NationalParks supported 238,000 jobs and pumped more than $26 billion into local economies. http:\/\/t.co\/Vp4zsM7Zhu",
  "id" : 503973883976761344,
  "created_at" : "2014-08-25 18:35:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "indices" : [ 3, 15 ],
      "id_str" : "369232105",
      "id" : 369232105
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NationalParks",
      "indices" : [ 45, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/vAGGHKwF9q",
      "expanded_url" : "http:\/\/go.wh.gov\/EaX8gw",
      "display_url" : "go.wh.gov\/EaX8gw"
    } ]
  },
  "geo" : { },
  "id_str" : "503965621416366080",
  "text" : "RT @PAniskoff44: Last yr, people visited our #NationalParks more than 273 million times &amp; saw beauty like this: http:\/\/t.co\/vAGGHKwF9q http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/PAniskoff44\/status\/503963760189771777\/photo\/1",
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/rA8E5GHDEb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bv5wXlPIcAEq0kq.jpg",
        "id_str" : "503963758746955777",
        "id" : 503963758746955777,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bv5wXlPIcAEq0kq.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 421,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 719,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 719,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 239,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/rA8E5GHDEb"
      } ],
      "hashtags" : [ {
        "text" : "NationalParks",
        "indices" : [ 28, 42 ]
      } ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/vAGGHKwF9q",
        "expanded_url" : "http:\/\/go.wh.gov\/EaX8gw",
        "display_url" : "go.wh.gov\/EaX8gw"
      } ]
    },
    "geo" : { },
    "id_str" : "503963760189771777",
    "text" : "Last yr, people visited our #NationalParks more than 273 million times &amp; saw beauty like this: http:\/\/t.co\/vAGGHKwF9q http:\/\/t.co\/rA8E5GHDEb",
    "id" : 503963760189771777,
    "created_at" : "2014-08-25 17:54:58 +0000",
    "user" : {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "protected" : false,
      "id_str" : "369232105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623146355767140352\/58sqoVrw_normal.jpg",
      "id" : 369232105,
      "verified" : true
    }
  },
  "id" : 503965621416366080,
  "created_at" : "2014-08-25 18:02:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NationalParkService",
      "screen_name" : "NatlParkService",
      "indices" : [ 30, 46 ],
      "id_str" : "36771809",
      "id" : 36771809
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/QMKM91faJf",
      "expanded_url" : "http:\/\/www.nps.gov\/findapark\/feefreeparks.htm",
      "display_url" : "nps.gov\/findapark\/feef\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "503958000445698048",
  "text" : "RT @Podesta44: Happy birthday @NatlParkService! Today you can visit all 401 natl parks &amp; monuments for free: http:\/\/t.co\/QMKM91faJf http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NationalParkService",
        "screen_name" : "NatlParkService",
        "indices" : [ 15, 31 ],
        "id_str" : "36771809",
        "id" : 36771809
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Podesta44\/status\/503955451349049345\/photo\/1",
        "indices" : [ 121, 143 ],
        "url" : "http:\/\/t.co\/Wa4h8j0ByF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bv5oz-xIUAE7tmE.png",
        "id_str" : "503955450543755265",
        "id" : 503955450543755265,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bv5oz-xIUAE7tmE.png",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 599,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 760,
          "resize" : "fit",
          "w" : 761
        }, {
          "h" : 760,
          "resize" : "fit",
          "w" : 761
        } ],
        "display_url" : "pic.twitter.com\/Wa4h8j0ByF"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/QMKM91faJf",
        "expanded_url" : "http:\/\/www.nps.gov\/findapark\/feefreeparks.htm",
        "display_url" : "nps.gov\/findapark\/feef\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "503955451349049345",
    "text" : "Happy birthday @NatlParkService! Today you can visit all 401 natl parks &amp; monuments for free: http:\/\/t.co\/QMKM91faJf http:\/\/t.co\/Wa4h8j0ByF",
    "id" : 503955451349049345,
    "created_at" : "2014-08-25 17:21:57 +0000",
    "user" : {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "protected" : false,
      "id_str" : "2382117350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656551411145027584\/ArrSlGUP_normal.jpg",
      "id" : 2382117350,
      "verified" : true
    }
  },
  "id" : 503958000445698048,
  "created_at" : "2014-08-25 17:32:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/503941717411004416\/photo\/1",
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/X9gdCxgEG5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bv5cUkzIIAAQE1R.jpg",
      "id_str" : "503941716857331712",
      "id" : 503941716857331712,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bv5cUkzIIAAQE1R.jpg",
      "sizes" : [ {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/X9gdCxgEG5"
    } ],
    "hashtags" : [ {
      "text" : "NationalParks",
      "indices" : [ 36, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "503941717411004416",
  "text" : "FACT: For every $1 we invest in our #NationalParks, they return $10 to our economy. http:\/\/t.co\/X9gdCxgEG5",
  "id" : 503941717411004416,
  "created_at" : "2014-08-25 16:27:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NationalParkService",
      "screen_name" : "NatlParkService",
      "indices" : [ 27, 43 ],
      "id_str" : "36771809",
      "id" : 36771809
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/503926931726028800\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/I5d3oszcIr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bv5O358IUAAgdCk.jpg",
      "id_str" : "503926930664869888",
      "id" : 503926930664869888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bv5O358IUAAgdCk.jpg",
      "sizes" : [ {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/I5d3oszcIr"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "503926931726028800",
  "text" : "Happy 98th Birthday to the @NatlParkService! To celebrate, all entrance fees are waived today.\nRT to spread the word. http:\/\/t.co\/I5d3oszcIr",
  "id" : 503926931726028800,
  "created_at" : "2014-08-25 15:28:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LLWS",
      "indices" : [ 101, 106 ]
    }, {
      "text" : "GoTeamUSA",
      "indices" : [ 126, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "503619206244737024",
  "text" : "Congrats to Chicago's very own Jackie Robinson West! We're all so proud of you. Good luck in today's #LLWS Championship Game. #GoTeamUSA -bo",
  "id" : 503619206244737024,
  "created_at" : "2014-08-24 19:05:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/Pp3vLa5GX6",
      "expanded_url" : "http:\/\/go.wh.gov\/vQeZG5",
      "display_url" : "go.wh.gov\/vQeZG5"
    } ]
  },
  "geo" : { },
  "id_str" : "503572511104065536",
  "text" : "\"More small businesses are selling their goods abroad than ever before\u2014nearly 300,000 last year alone.\" \u2014Obama: http:\/\/t.co\/Pp3vLa5GX6",
  "id" : 503572511104065536,
  "created_at" : "2014-08-24 16:00:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/Pp3vLa5GX6",
      "expanded_url" : "http:\/\/go.wh.gov\/vQeZG5",
      "display_url" : "go.wh.gov\/vQeZG5"
    } ]
  },
  "geo" : { },
  "id_str" : "503549823551696896",
  "text" : "\"Last year...exports supported more than 11 million American jobs...1.6 million more than when I took office\" \u2014Obama: http:\/\/t.co\/Pp3vLa5GX6",
  "id" : 503549823551696896,
  "created_at" : "2014-08-24 14:30:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 26, 40 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/Pp3vLa5GX6",
      "expanded_url" : "http:\/\/go.wh.gov\/vQeZG5",
      "display_url" : "go.wh.gov\/vQeZG5"
    } ]
  },
  "geo" : { },
  "id_str" : "503225225710817280",
  "text" : "\"We\u2019re selling more goods #MadeInAmerica to the rest of the world than ever before.\" \u2014Obama in his weekly address: http:\/\/t.co\/Pp3vLa5GX6",
  "id" : 503225225710817280,
  "created_at" : "2014-08-23 17:00:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/501407106684448768\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/hyln9iRTp9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BvVbGxYIIAEq7Qc.jpg",
      "id_str" : "501407105413554177",
      "id" : 501407105413554177,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvVbGxYIIAEq7Qc.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/hyln9iRTp9"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/Pp3vLa5GX6",
      "expanded_url" : "http:\/\/go.wh.gov\/vQeZG5",
      "display_url" : "go.wh.gov\/vQeZG5"
    } ]
  },
  "geo" : { },
  "id_str" : "503202565035552768",
  "text" : "\"Our businesses have added nearly 10 million new jobs over the past 53 months.\" \u2014Obama: http:\/\/t.co\/Pp3vLa5GX6 http:\/\/t.co\/hyln9iRTp9",
  "id" : 503202565035552768,
  "created_at" : "2014-08-23 15:30:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 120, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/Pp3vLa5GX6",
      "expanded_url" : "http:\/\/go.wh.gov\/vQeZG5",
      "display_url" : "go.wh.gov\/vQeZG5"
    } ]
  },
  "geo" : { },
  "id_str" : "503179933326143488",
  "text" : "President Obama's weekly address: It's time for Congress to reauthorize the Export-Import Bank \u2192 http:\/\/t.co\/Pp3vLa5GX6 #MadeInAmerica",
  "id" : 503179933326143488,
  "created_at" : "2014-08-23 14:00:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WestWingWeek",
      "indices" : [ 123, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/wrYrkQglNp",
      "expanded_url" : "http:\/\/youtu.be\/w-pyJuaYfq0",
      "display_url" : "youtu.be\/w-pyJuaYfq0"
    } ]
  },
  "geo" : { },
  "id_str" : "502923266873229313",
  "text" : "\"Higher education is a necessity, and it should be something that's available to everyone.\" Watch \u2192 http:\/\/t.co\/wrYrkQglNp #WestWingWeek",
  "id" : 502923266873229313,
  "created_at" : "2014-08-22 21:00:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NationalParkService",
      "screen_name" : "NatlParkService",
      "indices" : [ 19, 35 ],
      "id_str" : "36771809",
      "id" : 36771809
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/QMKM91faJf",
      "expanded_url" : "http:\/\/www.nps.gov\/findapark\/feefreeparks.htm",
      "display_url" : "nps.gov\/findapark\/feef\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "502915890137288704",
  "text" : "RT @Podesta44: The @NatlParkService turns 98 on Monday. Celebrate by visiting a park near you\u2014for free. http:\/\/t.co\/QMKM91faJf http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NationalParkService",
        "screen_name" : "NatlParkService",
        "indices" : [ 4, 20 ],
        "id_str" : "36771809",
        "id" : 36771809
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Podesta44\/status\/502913715608776704\/photo\/1",
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/lyMw59RL9s",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bvq1W_zIEAAnkaZ.jpg",
        "id_str" : "502913715092852736",
        "id" : 502913715092852736,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bvq1W_zIEAAnkaZ.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 427,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 427,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/lyMw59RL9s"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/QMKM91faJf",
        "expanded_url" : "http:\/\/www.nps.gov\/findapark\/feefreeparks.htm",
        "display_url" : "nps.gov\/findapark\/feef\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "502913715608776704",
    "text" : "The @NatlParkService turns 98 on Monday. Celebrate by visiting a park near you\u2014for free. http:\/\/t.co\/QMKM91faJf http:\/\/t.co\/lyMw59RL9s",
    "id" : 502913715608776704,
    "created_at" : "2014-08-22 20:22:28 +0000",
    "user" : {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "protected" : false,
      "id_str" : "2382117350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656551411145027584\/ArrSlGUP_normal.jpg",
      "id" : 2382117350,
      "verified" : true
    }
  },
  "id" : 502915890137288704,
  "created_at" : "2014-08-22 20:31:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WestWingWeek",
      "indices" : [ 73, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/RWYPN2hKeC",
      "expanded_url" : "http:\/\/youtu.be\/w-pyJuaYfq0",
      "display_url" : "youtu.be\/w-pyJuaYfq0"
    } ]
  },
  "geo" : { },
  "id_str" : "502907985740697601",
  "text" : "You asked. We answered. Watch the summer social media mailbag edition of #WestWingWeek \u2192 http:\/\/t.co\/RWYPN2hKeC",
  "id" : 502907985740697601,
  "created_at" : "2014-08-22 19:59:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Russian",
      "indices" : [ 62, 70 ]
    }, {
      "text" : "Ukraine",
      "indices" : [ 81, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/KWk42Xh9C5",
      "expanded_url" : "http:\/\/wh.gov\/lSnqX",
      "display_url" : "wh.gov\/lSnqX"
    } ]
  },
  "geo" : { },
  "id_str" : "502895690671226881",
  "text" : "RT @NSCPress: Statement by NSC Spokesperson Caitlin Hayden on #Russian Convoy in #Ukraine: http:\/\/t.co\/KWk42Xh9C5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Russian",
        "indices" : [ 48, 56 ]
      }, {
        "text" : "Ukraine",
        "indices" : [ 67, 75 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/KWk42Xh9C5",
        "expanded_url" : "http:\/\/wh.gov\/lSnqX",
        "display_url" : "wh.gov\/lSnqX"
      } ]
    },
    "geo" : { },
    "id_str" : "502894581776535554",
    "text" : "Statement by NSC Spokesperson Caitlin Hayden on #Russian Convoy in #Ukraine: http:\/\/t.co\/KWk42Xh9C5",
    "id" : 502894581776535554,
    "created_at" : "2014-08-22 19:06:26 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 502895690671226881,
  "created_at" : "2014-08-22 19:10:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/502496649655382017\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/h0pgzv3Led",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bvk6CkPIUAEX7Sj.jpg",
      "id_str" : "502496649189806081",
      "id" : 502496649189806081,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bvk6CkPIUAEX7Sj.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/h0pgzv3Led"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/xlNii2qaew",
      "expanded_url" : "http:\/\/go.wh.gov\/m48Sm2",
      "display_url" : "go.wh.gov\/m48Sm2"
    } ]
  },
  "geo" : { },
  "id_str" : "502859018272919554",
  "text" : "FACT: The number of cars coming off our assembly lines is at its highest level in 12 years \u2192 http:\/\/t.co\/xlNii2qaew http:\/\/t.co\/h0pgzv3Led",
  "id" : 502859018272919554,
  "created_at" : "2014-08-22 16:45:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/QKcON6ELDJ",
      "expanded_url" : "https:\/\/vine.co\/v\/ML63APm0JK6",
      "display_url" : "vine.co\/v\/ML63APm0JK6"
    } ]
  },
  "geo" : { },
  "id_str" : "502848917919518721",
  "text" : "A \uD83D\uDC26's \uD83D\uDC40 view of the White House from the top of the Washington Monument. https:\/\/t.co\/QKcON6ELDJ",
  "id" : 502848917919518721,
  "created_at" : "2014-08-22 16:04:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "indices" : [ 3, 10 ],
      "id_str" : "166252256",
      "id" : 166252256
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ENERGY\/status\/502834337591885826\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/GI2FrT75sZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BvptKmaIMAAf1Oy.png",
      "id_str" : "502834337281486848",
      "id" : 502834337281486848,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvptKmaIMAAf1Oy.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 601,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 601,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 601,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 341,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/GI2FrT75sZ"
    } ],
    "hashtags" : [ {
      "text" : "windweek",
      "indices" : [ 104, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/ShjuKtYMKC",
      "expanded_url" : "http:\/\/go.usa.gov\/EvGz",
      "display_url" : "go.usa.gov\/EvGz"
    } ]
  },
  "geo" : { },
  "id_str" : "502844215202959361",
  "text" : "RT @ENERGY: FACT: Wind turbines in the US are soaring to new sizes. Learn more \u2192 http:\/\/t.co\/ShjuKtYMKC #windweek http:\/\/t.co\/GI2FrT75sZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/measuredvoice.com\/\" rel=\"nofollow\"\u003EMeasured Voice\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ENERGY\/status\/502834337591885826\/photo\/1",
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/GI2FrT75sZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BvptKmaIMAAf1Oy.png",
        "id_str" : "502834337281486848",
        "id" : 502834337281486848,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvptKmaIMAAf1Oy.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 601,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 601,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 601,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 341,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/GI2FrT75sZ"
      } ],
      "hashtags" : [ {
        "text" : "windweek",
        "indices" : [ 92, 101 ]
      } ],
      "urls" : [ {
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/ShjuKtYMKC",
        "expanded_url" : "http:\/\/go.usa.gov\/EvGz",
        "display_url" : "go.usa.gov\/EvGz"
      } ]
    },
    "geo" : { },
    "id_str" : "502834337591885826",
    "text" : "FACT: Wind turbines in the US are soaring to new sizes. Learn more \u2192 http:\/\/t.co\/ShjuKtYMKC #windweek http:\/\/t.co\/GI2FrT75sZ",
    "id" : 502834337591885826,
    "created_at" : "2014-08-22 15:07:02 +0000",
    "user" : {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "protected" : false,
      "id_str" : "166252256",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793425839694155781\/HRS6sfn4_normal.jpg",
      "id" : 166252256,
      "verified" : true
    }
  },
  "id" : 502844215202959361,
  "created_at" : "2014-08-22 15:46:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    }, {
      "name" : "NationalParkService",
      "screen_name" : "NatlParkService",
      "indices" : [ 24, 40 ],
      "id_str" : "36771809",
      "id" : 36771809
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "502826117116739585",
  "text" : "RT @Interior: Monday is @NatlParkService 98th birthday &amp; all entrance fees will be waived. Retweet to spread the word! http:\/\/t.co\/RhTcC6BB\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NationalParkService",
        "screen_name" : "NatlParkService",
        "indices" : [ 10, 26 ],
        "id_str" : "36771809",
        "id" : 36771809
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/502583119783157761\/photo\/1",
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/RhTcC6BB8f",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BvmIrxVIgAINOPo.jpg",
        "id_str" : "502583118986248194",
        "id" : 502583118986248194,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvmIrxVIgAINOPo.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/RhTcC6BB8f"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "502583119783157761",
    "text" : "Monday is @NatlParkService 98th birthday &amp; all entrance fees will be waived. Retweet to spread the word! http:\/\/t.co\/RhTcC6BB8f",
    "id" : 502583119783157761,
    "created_at" : "2014-08-21 22:28:48 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 502826117116739585,
  "created_at" : "2014-08-22 14:34:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/LurpvKt3UB",
      "expanded_url" : "http:\/\/youtu.be\/5l-7vmArLJY",
      "display_url" : "youtu.be\/5l-7vmArLJY"
    } ]
  },
  "geo" : { },
  "id_str" : "502559649615585281",
  "text" : "\"Interacting with the government shouldn't be a thing that you automatically dread.\"\nWatch \u2192 http:\/\/t.co\/LurpvKt3UB",
  "id" : 502559649615585281,
  "created_at" : "2014-08-21 20:55:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/502496649655382017\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/h0pgzv3Led",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bvk6CkPIUAEX7Sj.jpg",
      "id_str" : "502496649189806081",
      "id" : 502496649189806081,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bvk6CkPIUAEX7Sj.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/h0pgzv3Led"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/od7xURkGQl",
      "expanded_url" : "http:\/\/go.wh.gov\/m48Sm2",
      "display_url" : "go.wh.gov\/m48Sm2"
    } ]
  },
  "geo" : { },
  "id_str" : "502538855577583619",
  "text" : "President Obama acted to rescue the American auto industry\u2014saving more than 1 million jobs \u2192 http:\/\/t.co\/od7xURkGQl http:\/\/t.co\/h0pgzv3Led",
  "id" : 502538855577583619,
  "created_at" : "2014-08-21 19:32:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. EPA",
      "screen_name" : "EPA",
      "indices" : [ 3, 7 ],
      "id_str" : "14615871",
      "id" : 14615871
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "502525034834165762",
  "text" : "RT @EPA: Today, we're releasing Urban Air Toxics report. We've cut millions of tons of air pollutants while GDP has tripled. http:\/\/t.co\/Ya\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/Ya3ekP2Sxo",
        "expanded_url" : "http:\/\/www2.epa.gov\/urban-air-toxics",
        "display_url" : "www2.epa.gov\/urban-air-toxi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "502477952773529601",
    "text" : "Today, we're releasing Urban Air Toxics report. We've cut millions of tons of air pollutants while GDP has tripled. http:\/\/t.co\/Ya3ekP2Sxo",
    "id" : 502477952773529601,
    "created_at" : "2014-08-21 15:30:54 +0000",
    "user" : {
      "name" : "U.S. EPA",
      "screen_name" : "EPA",
      "protected" : false,
      "id_str" : "14615871",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/632228259879628800\/-gvVhzPn_normal.png",
      "id" : 14615871,
      "verified" : true
    }
  },
  "id" : 502525034834165762,
  "created_at" : "2014-08-21 18:37:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/8e3qDhqMNF",
      "expanded_url" : "http:\/\/go.wh.gov\/m48Sm2",
      "display_url" : "go.wh.gov\/m48Sm2"
    } ]
  },
  "geo" : { },
  "id_str" : "502518856712470528",
  "text" : "RT @VP: FACT: The number of cars coming off our assembly lines is at its highest level in 12 years \u2192 http:\/\/t.co\/8e3qDhqMNF http:\/\/t.co\/dSX\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/502510554104475650\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/dSXECGm5Gu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BvlGr1ACAAEnW8n.jpg",
        "id_str" : "502510552204050433",
        "id" : 502510552204050433,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvlGr1ACAAEnW8n.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/dSXECGm5Gu"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/8e3qDhqMNF",
        "expanded_url" : "http:\/\/go.wh.gov\/m48Sm2",
        "display_url" : "go.wh.gov\/m48Sm2"
      } ]
    },
    "geo" : { },
    "id_str" : "502510554104475650",
    "text" : "FACT: The number of cars coming off our assembly lines is at its highest level in 12 years \u2192 http:\/\/t.co\/8e3qDhqMNF http:\/\/t.co\/dSXECGm5Gu",
    "id" : 502510554104475650,
    "created_at" : "2014-08-21 17:40:26 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 502518856712470528,
  "created_at" : "2014-08-21 18:13:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/saFDv5fSeC",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/share\/only-takes-three-minutes-see-why-we-must-act-climate-change",
      "display_url" : "whitehouse.gov\/share\/only-tak\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "502511242339442688",
  "text" : "RT @Podesta44: Reminder: Climate change has been making the US wildfire season longer &amp; more intense on average http:\/\/t.co\/saFDv5fSeC #Act\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 124, 137 ]
      } ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/saFDv5fSeC",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/share\/only-takes-three-minutes-see-why-we-must-act-climate-change",
        "display_url" : "whitehouse.gov\/share\/only-tak\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "502478520610586624",
    "text" : "Reminder: Climate change has been making the US wildfire season longer &amp; more intense on average http:\/\/t.co\/saFDv5fSeC #ActOnClimate",
    "id" : 502478520610586624,
    "created_at" : "2014-08-21 15:33:09 +0000",
    "user" : {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "protected" : false,
      "id_str" : "2382117350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656551411145027584\/ArrSlGUP_normal.jpg",
      "id" : 2382117350,
      "verified" : true
    }
  },
  "id" : 502511242339442688,
  "created_at" : "2014-08-21 17:43:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/502496649655382017\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/h0pgzv3Led",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bvk6CkPIUAEX7Sj.jpg",
      "id_str" : "502496649189806081",
      "id" : 502496649189806081,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bvk6CkPIUAEX7Sj.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/h0pgzv3Led"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/od7xUR3DOl",
      "expanded_url" : "http:\/\/go.wh.gov\/m48Sm2",
      "display_url" : "go.wh.gov\/m48Sm2"
    } ]
  },
  "geo" : { },
  "id_str" : "502507603159969793",
  "text" : "Our auto industry is growing:\nU.S. manufacturing jobs: \u2191 more than 700,000 since early 2010 \u2192 http:\/\/t.co\/od7xUR3DOl http:\/\/t.co\/h0pgzv3Led",
  "id" : 502507603159969793,
  "created_at" : "2014-08-21 17:28:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/502496649655382017\/photo\/1",
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/h0pgzv3Led",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bvk6CkPIUAEX7Sj.jpg",
      "id_str" : "502496649189806081",
      "id" : 502496649189806081,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bvk6CkPIUAEX7Sj.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/h0pgzv3Led"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/od7xUR3DOl",
      "expanded_url" : "http:\/\/go.wh.gov\/m48Sm2",
      "display_url" : "go.wh.gov\/m48Sm2"
    } ]
  },
  "geo" : { },
  "id_str" : "502496649655382017",
  "text" : "RT to spread the word: U.S. auto production is at its highest rate since 2002 \u2192 http:\/\/t.co\/od7xUR3DOl http:\/\/t.co\/h0pgzv3Led",
  "id" : 502496649655382017,
  "created_at" : "2014-08-21 16:45:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/LurpvKLd8J",
      "expanded_url" : "http:\/\/youtu.be\/5l-7vmArLJY",
      "display_url" : "youtu.be\/5l-7vmArLJY"
    } ]
  },
  "geo" : { },
  "id_str" : "502479602582056960",
  "text" : "Go inside the new U.S. Digital Service to find out how they're working to improve digital government services: http:\/\/t.co\/LurpvKLd8J",
  "id" : 502479602582056960,
  "created_at" : "2014-08-21 15:37:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "indices" : [ 3, 12 ],
      "id_str" : "337742544",
      "id" : 337742544
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "502473832960360448",
  "text" : "RT @OMBPress: From setting Blackberry passwords to meeting with senior advisors, Mikey Dickerson\u2019s first day at the White House: http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/fhBLrVm65U",
        "expanded_url" : "http:\/\/1.usa.gov\/1BCUvdg",
        "display_url" : "1.usa.gov\/1BCUvdg"
      } ]
    },
    "geo" : { },
    "id_str" : "502162323814227968",
    "text" : "From setting Blackberry passwords to meeting with senior advisors, Mikey Dickerson\u2019s first day at the White House: http:\/\/t.co\/fhBLrVm65U",
    "id" : 502162323814227968,
    "created_at" : "2014-08-20 18:36:42 +0000",
    "user" : {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "protected" : false,
      "id_str" : "337742544",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1449289379\/OMB_Seal_normal.jpg",
      "id" : 337742544,
      "verified" : true
    }
  },
  "id" : 502473832960360448,
  "created_at" : "2014-08-21 15:14:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 37, 48 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/LurpvKLd8J",
      "expanded_url" : "http:\/\/youtu.be\/5l-7vmArLJY",
      "display_url" : "youtu.be\/5l-7vmArLJY"
    } ]
  },
  "geo" : { },
  "id_str" : "502464787805396992",
  "text" : "Mikey Dickerson's typical day at the @WhiteHouse:\nSuit \u2718\nTie \u2718\nImproving digital government services \u2713\nWatch \u2192 http:\/\/t.co\/LurpvKLd8J",
  "id" : 502464787805396992,
  "created_at" : "2014-08-21 14:38:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justice Department",
      "screen_name" : "TheJusticeDept",
      "indices" : [ 1, 16 ],
      "id_str" : "73181712",
      "id" : 73181712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/WyOt2AGSYd",
      "expanded_url" : "http:\/\/bit.ly\/1mlJnaS",
      "display_url" : "bit.ly\/1mlJnaS"
    } ]
  },
  "geo" : { },
  "id_str" : "502210672462409728",
  "text" : "\"@TheJusticeDept will defend the right of protesters to peacefully demonstrate\" \u2014Holder on the situation in Ferguson: http:\/\/t.co\/WyOt2AGSYd",
  "id" : 502210672462409728,
  "created_at" : "2014-08-20 21:48:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/39C6TkcaeO",
      "expanded_url" : "http:\/\/youtu.be\/VPl5qu_eAaQ",
      "display_url" : "youtu.be\/VPl5qu_eAaQ"
    } ]
  },
  "geo" : { },
  "id_str" : "502169323910492161",
  "text" : "\"The future is won by those who build and not destroy and the world is shaped by people like Jim Foley.\" \u2014Obama: http:\/\/t.co\/39C6TkcaeO",
  "id" : 502169323910492161,
  "created_at" : "2014-08-20 19:04:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "502137859634384896",
  "text" : "\"When people harm Americans anywhere, we do what is necessary to see that justice is done.\" \u2014President Obama",
  "id" : 502137859634384896,
  "created_at" : "2014-08-20 16:59:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "502137247173713920",
  "text" : "\"Today, the American people will say a prayer for those who loved Jim.\" \u2014President Obama on ISIL\u2019s murder of Jim Foley",
  "id" : 502137247173713920,
  "created_at" : "2014-08-20 16:57:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "502137161379250177",
  "text" : "\"One thing we can all agree on is that a group like ISIL has no place in the 21st century.\" \u2014President Obama",
  "id" : 502137161379250177,
  "created_at" : "2014-08-20 16:56:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Iraq",
      "indices" : [ 127, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "502136905367293952",
  "text" : "RT @WHLive: \"People like this fail\u2026because the future is always won by those who build, not destroy.\" \u2014President Obama on ISIL #Iraq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Iraq",
        "indices" : [ 115, 120 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "502136883213008896",
    "text" : "\"People like this fail\u2026because the future is always won by those who build, not destroy.\" \u2014President Obama on ISIL #Iraq",
    "id" : 502136883213008896,
    "created_at" : "2014-08-20 16:55:36 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 502136905367293952,
  "created_at" : "2014-08-20 16:55:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "502136765701160961",
  "text" : "\"No just God would stand for what they did yesterday, and what they do every single day.\" \u2014President Obama on ISIL's murder of Jim Foley",
  "id" : 502136765701160961,
  "created_at" : "2014-08-20 16:55:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "502136590601584641",
  "text" : "\"ISIL speaks for no religion. Their victims are overwhelmingly Muslim, and no faith teaches people to massacre innocents.\" \u2014President Obama",
  "id" : 502136590601584641,
  "created_at" : "2014-08-20 16:54:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "502136334635794433",
  "text" : "RT @WHLive: \"I spoke to the Foleys and told them that we are all heartbroken at their loss, and join with them in honoring Jim.\" \u2014President\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "502136299135184896",
    "text" : "\"I spoke to the Foleys and told them that we are all heartbroken at their loss, and join with them in honoring Jim.\" \u2014President Obama",
    "id" : 502136299135184896,
    "created_at" : "2014-08-20 16:53:17 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 502136334635794433,
  "created_at" : "2014-08-20 16:53:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "502136035816796160",
  "text" : "\"Today, the entire world is appalled by the brutal murder of Jim Foley by the terrorist group, ISIL.\" \u2014President Obama",
  "id" : 502136035816796160,
  "created_at" : "2014-08-20 16:52:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/b4tqL3oo0v",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "502135942720024578",
  "text" : "Happening now: President Obama delivers a statement. Watch \u2192 http:\/\/t.co\/b4tqL3oo0v",
  "id" : 502135942720024578,
  "created_at" : "2014-08-20 16:51:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/7QUc084BX3",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "502118611905810432",
  "text" : "At 12:45pm ET, President Obama will deliver a statement. Watch here \u2192 http:\/\/t.co\/7QUc084BX3",
  "id" : 502118611905810432,
  "created_at" : "2014-08-20 15:43:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/502116616830984192\/photo\/1",
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/hXydpGgLmA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BvfgZuFIUAAlLvp.png",
      "id_str" : "502116615945998336",
      "id" : 502116615945998336,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvfgZuFIUAAlLvp.png",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 320,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 320,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/hXydpGgLmA"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/WyOt2AGSYd",
      "expanded_url" : "http:\/\/bit.ly\/1mlJnaS",
      "display_url" : "bit.ly\/1mlJnaS"
    } ]
  },
  "geo" : { },
  "id_str" : "502116616830984192",
  "text" : "Read Attorney General Eric Holder's message to the people of Ferguson \u2192 http:\/\/t.co\/WyOt2AGSYd http:\/\/t.co\/hXydpGgLmA",
  "id" : 502116616830984192,
  "created_at" : "2014-08-20 15:35:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justice Department",
      "screen_name" : "TheJusticeDept",
      "indices" : [ 3, 18 ],
      "id_str" : "73181712",
      "id" : 73181712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/HXOseLZIXb",
      "expanded_url" : "http:\/\/go.usa.gov\/EMwe",
      "display_url" : "go.usa.gov\/EMwe"
    } ]
  },
  "geo" : { },
  "id_str" : "502104892316844032",
  "text" : "RT @TheJusticeDept: AG Holder is en route to Ferguson. See his most recent statement on the developments there.  http:\/\/t.co\/HXOseLZIXb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/HXOseLZIXb",
        "expanded_url" : "http:\/\/go.usa.gov\/EMwe",
        "display_url" : "go.usa.gov\/EMwe"
      } ]
    },
    "geo" : { },
    "id_str" : "502088961935048704",
    "text" : "AG Holder is en route to Ferguson. See his most recent statement on the developments there.  http:\/\/t.co\/HXOseLZIXb",
    "id" : 502088961935048704,
    "created_at" : "2014-08-20 13:45:11 +0000",
    "user" : {
      "name" : "Justice Department",
      "screen_name" : "TheJusticeDept",
      "protected" : false,
      "id_str" : "73181712",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/445550654\/twitter_logo_normal.png",
      "id" : 73181712,
      "verified" : true
    }
  },
  "id" : 502104892316844032,
  "created_at" : "2014-08-20 14:48:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/501779888261857280\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/YfyzWAf0sz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BvauJjvIgAEvXZE.jpg",
      "id_str" : "501779887733374977",
      "id" : 501779887733374977,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvauJjvIgAEvXZE.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      } ],
      "display_url" : "pic.twitter.com\/YfyzWAf0sz"
    } ],
    "hashtags" : [ {
      "text" : "Ferguson",
      "indices" : [ 74, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/9VQX2AiE5G",
      "expanded_url" : "http:\/\/go.wh.gov\/qABMrn",
      "display_url" : "go.wh.gov\/qABMrn"
    } ]
  },
  "geo" : { },
  "id_str" : "501779888261857280",
  "text" : "\"We've got to use this moment to seek out our shared humanity.\" \u2014Obama on #Ferguson: http:\/\/t.co\/9VQX2AiE5G http:\/\/t.co\/YfyzWAf0sz",
  "id" : 501779888261857280,
  "created_at" : "2014-08-19 17:17:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/501741427714691074\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/FVlN5aPJVZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BvaLK3VIIAAKkzx.jpg",
      "id_str" : "501741427265904640",
      "id" : 501741427265904640,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvaLK3VIIAAKkzx.jpg",
      "sizes" : [ {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/FVlN5aPJVZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/tKmNFvkYYj",
      "expanded_url" : "http:\/\/go.wh.gov\/AqMZv6",
      "display_url" : "go.wh.gov\/AqMZv6"
    } ]
  },
  "geo" : { },
  "id_str" : "501741427714691074",
  "text" : "In June, U.S. business owners posted 4.67 million job openings\u2014the most since February 2001 \u2192 http:\/\/t.co\/tKmNFvkYYj http:\/\/t.co\/FVlN5aPJVZ",
  "id" : 501741427714691074,
  "created_at" : "2014-08-19 14:44:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "indices" : [ 3, 12 ],
      "id_str" : "1604366701",
      "id" : 1604366701
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DayInTheLife",
      "indices" : [ 107, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/4x8s5fTQg7",
      "expanded_url" : "http:\/\/social.dol.gov\/blog\/?p=14262",
      "display_url" : "social.dol.gov\/blog\/?p=14262"
    } ]
  },
  "geo" : { },
  "id_str" : "501738532625719297",
  "text" : "RT @LaborSec: Today I'm meeting Austraberta, a janitor from Houston. Follow along: http:\/\/t.co\/4x8s5fTQg7  #DayInTheLife http:\/\/t.co\/gYwzuU\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/LaborSec\/status\/501720270609326081\/photo\/1",
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/gYwzuUaQWI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BvZ37XgIAAEjY35.png",
        "id_str" : "501720270303133697",
        "id" : 501720270303133697,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvZ37XgIAAEjY35.png",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/gYwzuUaQWI"
      } ],
      "hashtags" : [ {
        "text" : "DayInTheLife",
        "indices" : [ 93, 106 ]
      } ],
      "urls" : [ {
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/4x8s5fTQg7",
        "expanded_url" : "http:\/\/social.dol.gov\/blog\/?p=14262",
        "display_url" : "social.dol.gov\/blog\/?p=14262"
      } ]
    },
    "geo" : { },
    "id_str" : "501720270609326081",
    "text" : "Today I'm meeting Austraberta, a janitor from Houston. Follow along: http:\/\/t.co\/4x8s5fTQg7  #DayInTheLife http:\/\/t.co\/gYwzuUaQWI",
    "id" : 501720270609326081,
    "created_at" : "2014-08-19 13:20:08 +0000",
    "user" : {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "protected" : false,
      "id_str" : "1604366701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744887280666611712\/eEeyFjs6_normal.jpg",
      "id" : 1604366701,
      "verified" : true
    }
  },
  "id" : 501738532625719297,
  "created_at" : "2014-08-19 14:32:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 44, 47 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Juli\u00E1n Castro",
      "screen_name" : "SecretaryCastro",
      "indices" : [ 60, 76 ],
      "id_str" : "2695663285",
      "id" : 2695663285
    }, {
      "name" : "HUDgov",
      "screen_name" : "HUDgov",
      "indices" : [ 85, 92 ],
      "id_str" : "19948202",
      "id" : 19948202
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/501500094982520832\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/BPIr9Xl7bi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BvWrSjcIQAAt4xC.jpg",
      "id_str" : "501495268760895488",
      "id" : 501495268760895488,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvWrSjcIQAAt4xC.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/BPIr9Xl7bi"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/G5fBxrROcQ",
      "expanded_url" : "http:\/\/go.wh.gov\/4BZTFd",
      "display_url" : "go.wh.gov\/4BZTFd"
    } ]
  },
  "geo" : { },
  "id_str" : "501500094982520832",
  "text" : "\"A champion for safe, affordable housing.\" \u2014@VP swearing in @SecretaryCastro to lead @HUDGov: http:\/\/t.co\/G5fBxrROcQ http:\/\/t.co\/BPIr9Xl7bi",
  "id" : 501500094982520832,
  "created_at" : "2014-08-18 22:45:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/501492325957529601\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/nqbyTeKfSF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BvWonLAIMAEJZGC.png",
      "id_str" : "501492324443369473",
      "id" : 501492324443369473,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvWonLAIMAEJZGC.png",
      "sizes" : [ {
        "h" : 491,
        "resize" : "fit",
        "w" : 1239
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 406,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 135,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 238,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/nqbyTeKfSF"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/Ny4mp8oHdk",
      "expanded_url" : "http:\/\/go.wh.gov\/ZRP2X8",
      "display_url" : "go.wh.gov\/ZRP2X8"
    } ]
  },
  "geo" : { },
  "id_str" : "501492325957529601",
  "text" : "President Obama on eliminating the Syrian regime's \u201Cmost lethal declared chemical weapons\u201D \u2192 http:\/\/t.co\/Ny4mp8oHdk http:\/\/t.co\/nqbyTeKfSF",
  "id" : 501492325957529601,
  "created_at" : "2014-08-18 22:14:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "501472941465665537",
  "text" : "\"What we have to do is make sure that the cause of justice and fair administration of the law is being brought to bear in Ferguson.\" \u2014Obama",
  "id" : 501472941465665537,
  "created_at" : "2014-08-18 20:57:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "501470922738794496",
  "text" : "\"Part of the ongoing challenge of perfecting our union has involved dealing with communities that feel left behind.\" \u2014President Obama",
  "id" : 501470922738794496,
  "created_at" : "2014-08-18 20:49:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ferguson",
      "indices" : [ 128, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "501468136282284032",
  "text" : "\u201CIn too many communities around this country, young men of color are left behind and seen as objects of fear.\u201D \u2014President Obama #Ferguson",
  "id" : 501468136282284032,
  "created_at" : "2014-08-18 20:38:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ferguson",
      "indices" : [ 123, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "501467427314892800",
  "text" : "\"We\u2019ve got to use this moment to seek out the shared humanity that\u2019s laid bare by this moment.\" \u2014Obama on the situation in #Ferguson",
  "id" : 501467427314892800,
  "created_at" : "2014-08-18 20:35:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ferguson",
      "indices" : [ 124, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "501466943996452864",
  "text" : "\"Our constitutional rights to speak freely, to assemble, and to report in the press must be vigilantly safeguarded.\" \u2014Obama #Ferguson",
  "id" : 501466943996452864,
  "created_at" : "2014-08-18 20:33:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "501466561664647168",
  "text" : "\"The Department of Justice has opened an independent, federal civil rights investigation into the death of Michael Brown.\" \u2014President Obama",
  "id" : 501466561664647168,
  "created_at" : "2014-08-18 20:31:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "501466444853682178",
  "text" : "Obama: \"When it comes to the security of our people &amp; our efforts against a terrorist group like ISIL, we need to be united in our resolve.\"",
  "id" : 501466444853682178,
  "created_at" : "2014-08-18 20:31:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "501465971761352704",
  "text" : "RT @WHLive: \"We will continue to pursue a long-term strategy to turn the tide against ISIL by supporting the new Iraqi government.\" \u2014Presid\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "501465927213645825",
    "text" : "\"We will continue to pursue a long-term strategy to turn the tide against ISIL by supporting the new Iraqi government.\" \u2014President Obama",
    "id" : 501465927213645825,
    "created_at" : "2014-08-18 20:29:28 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 501465971761352704,
  "created_at" : "2014-08-18 20:29:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "501465655112396801",
  "text" : "Obama: \"Today\u2014with our support\u2014Iraqi forces took a major step forward in their operations to recapture the largest dam in Iraq.\"",
  "id" : 501465655112396801,
  "created_at" : "2014-08-18 20:28:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "501465601408516098",
  "text" : "RT @WHLive: \"American air strikes have stopped the ISIL advance around the city of Erbil, and pushed back the terrorists.\" \u2014President Obama\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Iraq",
        "indices" : [ 128, 133 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "501465513894350848",
    "text" : "\"American air strikes have stopped the ISIL advance around the city of Erbil, and pushed back the terrorists.\" \u2014President Obama #Iraq",
    "id" : 501465513894350848,
    "created_at" : "2014-08-18 20:27:49 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 501465601408516098,
  "created_at" : "2014-08-18 20:28:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "501465395258486784",
  "text" : "Obama: \"We continue to see important progress across different parts of our strategy to support the Iraqi government and combat...ISIL.\"",
  "id" : 501465395258486784,
  "created_at" : "2014-08-18 20:27:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/b4tqL3oo0v",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "501465259413356545",
  "text" : "Happening now: President Obama gives an update on Iraq and the situation in Ferguson, Missouri. Watch \u2192 http:\/\/t.co\/b4tqL3oo0v",
  "id" : 501465259413356545,
  "created_at" : "2014-08-18 20:26:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Juli\u00E1n Castro",
      "screen_name" : "SecretaryCastro",
      "indices" : [ 49, 65 ],
      "id_str" : "2695663285",
      "id" : 2695663285
    }, {
      "name" : "HUDgov",
      "screen_name" : "HUDgov",
      "indices" : [ 90, 97 ],
      "id_str" : "19948202",
      "id" : 19948202
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/VP\/status\/501454538378072064\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/523u1gFthF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BvWGPlKIcAAnK-p.png",
      "id_str" : "501454535752445952",
      "id" : 501454535752445952,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvWGPlKIcAAnK-p.png",
      "sizes" : [ {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/523u1gFthF"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "501455067816689664",
  "text" : "RT @VP: Check out VP Biden ceremonially swear in @SecretaryCastro as the new Secretary of @HUDgov earlier today \u2192 http:\/\/t.co\/523u1gFthF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Juli\u00E1n Castro",
        "screen_name" : "SecretaryCastro",
        "indices" : [ 41, 57 ],
        "id_str" : "2695663285",
        "id" : 2695663285
      }, {
        "name" : "HUDgov",
        "screen_name" : "HUDgov",
        "indices" : [ 82, 89 ],
        "id_str" : "19948202",
        "id" : 19948202
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/VP\/status\/501454538378072064\/photo\/1",
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/523u1gFthF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BvWGPlKIcAAnK-p.png",
        "id_str" : "501454535752445952",
        "id" : 501454535752445952,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvWGPlKIcAAnK-p.png",
        "sizes" : [ {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/523u1gFthF"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "501454538378072064",
    "text" : "Check out VP Biden ceremonially swear in @SecretaryCastro as the new Secretary of @HUDgov earlier today \u2192 http:\/\/t.co\/523u1gFthF",
    "id" : 501454538378072064,
    "created_at" : "2014-08-18 19:44:13 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 501455067816689664,
  "created_at" : "2014-08-18 19:46:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/b4tqL3oo0v",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "501444566281912320",
  "text" : "At 4pm ET, President Obama will give an update on Iraq and the situation in Ferguson, Missouri. Watch here \u2192 http:\/\/t.co\/b4tqL3oo0v",
  "id" : 501444566281912320,
  "created_at" : "2014-08-18 19:04:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/501407106684448768\/photo\/1",
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/hyln9iRTp9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BvVbGxYIIAEq7Qc.jpg",
      "id_str" : "501407105413554177",
      "id" : 501407105413554177,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvVbGxYIIAEq7Qc.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/hyln9iRTp9"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/y9PthPaDkD",
      "expanded_url" : "http:\/\/go.wh.gov\/1usRCd",
      "display_url" : "go.wh.gov\/1usRCd"
    } ]
  },
  "geo" : { },
  "id_str" : "501407106684448768",
  "text" : "FACT: Our businesses have added nearly 10 million jobs since early 2010 \u2192 http:\/\/t.co\/y9PthPaDkD http:\/\/t.co\/hyln9iRTp9",
  "id" : 501407106684448768,
  "created_at" : "2014-08-18 16:35:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/Pc556mmQ7W",
      "expanded_url" : "http:\/\/go.wh.gov\/1usRCd",
      "display_url" : "go.wh.gov\/1usRCd"
    } ]
  },
  "geo" : { },
  "id_str" : "501392579230179328",
  "text" : "RT @pfeiffer44: This summer, the number of available jobs rose to the highest level in more than 13 years \u2192 http:\/\/t.co\/Pc556mmQ7W http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/501370432847900673\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/bTjZFVxh9O",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BvU5wGTIEAAr8K3.jpg",
        "id_str" : "501370432009015296",
        "id" : 501370432009015296,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvU5wGTIEAAr8K3.jpg",
        "sizes" : [ {
          "h" : 513,
          "resize" : "fit",
          "w" : 581
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 513,
          "resize" : "fit",
          "w" : 581
        }, {
          "h" : 513,
          "resize" : "fit",
          "w" : 581
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/bTjZFVxh9O"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/Pc556mmQ7W",
        "expanded_url" : "http:\/\/go.wh.gov\/1usRCd",
        "display_url" : "go.wh.gov\/1usRCd"
      } ]
    },
    "geo" : { },
    "id_str" : "501375898067939328",
    "text" : "This summer, the number of available jobs rose to the highest level in more than 13 years \u2192 http:\/\/t.co\/Pc556mmQ7W http:\/\/t.co\/bTjZFVxh9O",
    "id" : 501375898067939328,
    "created_at" : "2014-08-18 14:31:43 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 501392579230179328,
  "created_at" : "2014-08-18 15:38:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/bjFa3kdPuC",
      "expanded_url" : "http:\/\/go.wh.gov\/1usRCd",
      "display_url" : "go.wh.gov\/1usRCd"
    } ]
  },
  "geo" : { },
  "id_str" : "501379253649154048",
  "text" : "FACT: U.S. business owners advertised 4.67 million jobs in June\u2014the highest number of openings since February 2001 \u2192 http:\/\/t.co\/bjFa3kdPuC",
  "id" : 501379253649154048,
  "created_at" : "2014-08-18 14:45:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/501370432847900673\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/QKl4dDAeYP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BvU5wGTIEAAr8K3.jpg",
      "id_str" : "501370432009015296",
      "id" : 501370432009015296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvU5wGTIEAAr8K3.jpg",
      "sizes" : [ {
        "h" : 513,
        "resize" : "fit",
        "w" : 581
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 513,
        "resize" : "fit",
        "w" : 581
      }, {
        "h" : 513,
        "resize" : "fit",
        "w" : 581
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/QKl4dDAeYP"
    } ],
    "hashtags" : [ {
      "text" : "ActOnJobs",
      "indices" : [ 96, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/y9PthPaDkD",
      "expanded_url" : "http:\/\/go.wh.gov\/1usRCd",
      "display_url" : "go.wh.gov\/1usRCd"
    } ]
  },
  "geo" : { },
  "id_str" : "501370432847900673",
  "text" : "RT to share the news: U.S. job openings hit a 13-year high this summer \u2192 http:\/\/t.co\/y9PthPaDkD #ActOnJobs http:\/\/t.co\/QKl4dDAeYP",
  "id" : 501370432847900673,
  "created_at" : "2014-08-18 14:10:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/0cSpxU4JAG",
      "expanded_url" : "http:\/\/go.wh.gov\/eZhNRa",
      "display_url" : "go.wh.gov\/eZhNRa"
    } ]
  },
  "geo" : { },
  "id_str" : "501050858545479680",
  "text" : "\"Interacting with the government shouldn't be a thing that you automatically dread.\" \u2014Mikey Dickerson. Watch: http:\/\/t.co\/0cSpxU4JAG",
  "id" : 501050858545479680,
  "created_at" : "2014-08-17 17:00:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/qNgVc7bFAG",
      "expanded_url" : "http:\/\/go.wh.gov\/in4TF9",
      "display_url" : "go.wh.gov\/in4TF9"
    } ]
  },
  "geo" : { },
  "id_str" : "501028234763313154",
  "text" : "\"We took action to offer millions of students a chance to cap...student loan payments at 10% of their income.\" \u2014Obama http:\/\/t.co\/qNgVc7bFAG",
  "id" : 501028234763313154,
  "created_at" : "2014-08-17 15:30:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 113, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/qNgVc7bFAG",
      "expanded_url" : "http:\/\/go.wh.gov\/in4TF9",
      "display_url" : "go.wh.gov\/in4TF9"
    } ]
  },
  "geo" : { },
  "id_str" : "501013127006142467",
  "text" : "\"Set your sights on college in the years ahead. Your country is counting on you.\" \u2014Obama: http:\/\/t.co\/qNgVc7bFAG #CollegeOpportunity",
  "id" : 501013127006142467,
  "created_at" : "2014-08-17 14:30:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 113, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/qNgVc7bFAG",
      "expanded_url" : "http:\/\/go.wh.gov\/in4TF9",
      "display_url" : "go.wh.gov\/in4TF9"
    } ]
  },
  "geo" : { },
  "id_str" : "500718734521016320",
  "text" : "\"We expanded grants and college tax credits for students and families.\" \u2014President Obama: http:\/\/t.co\/qNgVc7bFAG #CollegeOpportunity",
  "id" : 500718734521016320,
  "created_at" : "2014-08-16 19:00:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ReachHigher",
      "indices" : [ 88, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/qNgVc7bFAG",
      "expanded_url" : "http:\/\/go.wh.gov\/in4TF9",
      "display_url" : "go.wh.gov\/in4TF9"
    } ]
  },
  "geo" : { },
  "id_str" : "500696069156507648",
  "text" : "\"When you\u2019re thinking hard, you\u2019re getting smarter. So this year, challenge yourself to #ReachHigher.\" \u2014Obama: http:\/\/t.co\/qNgVc7bFAG",
  "id" : 500696069156507648,
  "created_at" : "2014-08-16 17:30:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/qNgVc7bFAG",
      "expanded_url" : "http:\/\/go.wh.gov\/in4TF9",
      "display_url" : "go.wh.gov\/in4TF9"
    } ]
  },
  "geo" : { },
  "id_str" : "500673431927390208",
  "text" : "\"We reformed a student loan system so that more money goes to students instead of big banks.\" \u2014President Obama: http:\/\/t.co\/qNgVc7bFAG",
  "id" : 500673431927390208,
  "created_at" : "2014-08-16 16:00:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 102, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/lAtk6pcsiC",
      "expanded_url" : "http:\/\/go.wh.gov\/in4TF9",
      "display_url" : "go.wh.gov\/in4TF9"
    } ]
  },
  "geo" : { },
  "id_str" : "500653931861913600",
  "text" : "\"Higher education is the surest ticket to the middle class.\" \u2014President Obama: http:\/\/t.co\/lAtk6pcsiC #CollegeOpportunity",
  "id" : 500653931861913600,
  "created_at" : "2014-08-16 14:42:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnJobs",
      "indices" : [ 123, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/8b8qHBvPlu",
      "expanded_url" : "http:\/\/go.wh.gov\/4genrj",
      "display_url" : "go.wh.gov\/4genrj"
    } ]
  },
  "geo" : { },
  "id_str" : "500371784601190401",
  "text" : "FACT: Last year's U.S. travel and tourism sector had a $78 billion trade surplus\u2014the largest ever \u2192 http:\/\/t.co\/8b8qHBvPlu #ActOnJobs",
  "id" : 500371784601190401,
  "created_at" : "2014-08-15 20:01:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 18, 29 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/500341793872179200\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/dnwYenCBU9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BvGSNcfIEAA7z7B.jpg",
      "id_str" : "500341793297534976",
      "id" : 500341793297534976,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvGSNcfIEAA7z7B.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      } ],
      "display_url" : "pic.twitter.com\/dnwYenCBU9"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/aTZy9sGa2p",
      "expanded_url" : "http:\/\/go.wh.gov\/kWgm7w",
      "display_url" : "go.wh.gov\/kWgm7w"
    } ]
  },
  "geo" : { },
  "id_str" : "500341793872179200",
  "text" : "Thanks to 114,000 @WhiteHouse petition signers, it's now legal to unlock your cell phone \u2192 http:\/\/t.co\/aTZy9sGa2p http:\/\/t.co\/dnwYenCBU9",
  "id" : 500341793872179200,
  "created_at" : "2014-08-15 18:02:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/ClZFz48TVi",
      "expanded_url" : "http:\/\/wh.gov\/lJbeP",
      "display_url" : "wh.gov\/lJbeP"
    } ]
  },
  "geo" : { },
  "id_str" : "500341051677503489",
  "text" : "RT @Lubin44: Cell phone unlocking was a win for consumers, but also for digital advocacy. How it happened \u2192 http:\/\/t.co\/ClZFz48TVi http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Lubin44\/status\/500338138737569792\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/bPZO0XQ1RO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BvGO4sjIYAAuZxu.jpg",
        "id_str" : "500338138297163776",
        "id" : 500338138297163776,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvGO4sjIYAAuZxu.jpg",
        "sizes" : [ {
          "h" : 901,
          "resize" : "fit",
          "w" : 610
        }, {
          "h" : 886,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 901,
          "resize" : "fit",
          "w" : 610
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 502,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/bPZO0XQ1RO"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/ClZFz48TVi",
        "expanded_url" : "http:\/\/wh.gov\/lJbeP",
        "display_url" : "wh.gov\/lJbeP"
      } ]
    },
    "geo" : { },
    "id_str" : "500338138737569792",
    "text" : "Cell phone unlocking was a win for consumers, but also for digital advocacy. How it happened \u2192 http:\/\/t.co\/ClZFz48TVi http:\/\/t.co\/bPZO0XQ1RO",
    "id" : 500338138737569792,
    "created_at" : "2014-08-15 17:48:02 +0000",
    "user" : {
      "name" : "Lindsay Holst",
      "screen_name" : "Holst44",
      "protected" : false,
      "id_str" : "1563426390",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615987325261082625\/QxtC65p2_normal.jpg",
      "id" : 1563426390,
      "verified" : true
    }
  },
  "id" : 500341051677503489,
  "created_at" : "2014-08-15 17:59:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnJobs",
      "indices" : [ 134, 144 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/pqmRam7pi0",
      "expanded_url" : "http:\/\/go.wh.gov\/4genrj",
      "display_url" : "go.wh.gov\/4genrj"
    } ]
  },
  "geo" : { },
  "id_str" : "500322305352814592",
  "text" : "FACT: U.S. travel &amp; tourism-related employment increased to 7.6 million jobs in 2013\u2014up 146,000 from 2012. http:\/\/t.co\/pqmRam7pi0 #ActOnJobs",
  "id" : 500322305352814592,
  "created_at" : "2014-08-15 16:45:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnJobs",
      "indices" : [ 109, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/8b8qHBvPlu",
      "expanded_url" : "http:\/\/go.wh.gov\/4genrj",
      "display_url" : "go.wh.gov\/4genrj"
    } ]
  },
  "geo" : { },
  "id_str" : "500311525165637634",
  "text" : "Get the latest on how U.S. travel and tourism is growing and creating American jobs \u2192 http:\/\/t.co\/8b8qHBvPlu #ActOnJobs",
  "id" : 500311525165637634,
  "created_at" : "2014-08-15 16:02:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Education",
      "screen_name" : "usedgov",
      "indices" : [ 1, 9 ],
      "id_str" : "20437286",
      "id" : 20437286
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PreK4All",
      "indices" : [ 131, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/LndGF6RHoT",
      "expanded_url" : "http:\/\/go.wh.gov\/Pts556",
      "display_url" : "go.wh.gov\/Pts556"
    } ]
  },
  "geo" : { },
  "id_str" : "500306508283142146",
  "text" : ".@USEdGov just introduced a new competition that will expand access to high-quality preschool to more kids: http:\/\/t.co\/LndGF6RHoT #PreK4All",
  "id" : 500306508283142146,
  "created_at" : "2014-08-15 15:42:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "indices" : [ 75, 90 ],
      "id_str" : "19674502",
      "id" : 19674502
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/500051292522577920\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/84hXYrCLYb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BvCKABfIgAABL5_.png",
      "id_str" : "500051291641774080",
      "id" : 500051291641774080,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvCKABfIgAABL5_.png",
      "sizes" : [ {
        "h" : 331,
        "resize" : "fit",
        "w" : 1071
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 316,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 185,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 105,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/84hXYrCLYb"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/zV6Tga29HM",
      "expanded_url" : "http:\/\/go.wh.gov\/EgMccB",
      "display_url" : "go.wh.gov\/EgMccB"
    } ]
  },
  "geo" : { },
  "id_str" : "500051292522577920",
  "text" : "\"Today, Iraqis took another major step forward in uniting their country.\" \u2014@AmbassadorRice: http:\/\/t.co\/zV6Tga29HM http:\/\/t.co\/84hXYrCLYb",
  "id" : 500051292522577920,
  "created_at" : "2014-08-14 22:48:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/qginFjmxhI",
      "expanded_url" : "http:\/\/youtu.be\/S6Sg5IJ_FSM",
      "display_url" : "youtu.be\/S6Sg5IJ_FSM"
    } ]
  },
  "geo" : { },
  "id_str" : "500045341916676096",
  "text" : "\"Now is the time for healing. Now is the time for peace and calm on the streets of Ferguson.\" \u2014President Obama: http:\/\/t.co\/qginFjmxhI",
  "id" : 500045341916676096,
  "created_at" : "2014-08-14 22:24:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ferguson",
      "indices" : [ 124, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/qginFjmxhI",
      "expanded_url" : "http:\/\/youtu.be\/S6Sg5IJ_FSM",
      "display_url" : "youtu.be\/S6Sg5IJ_FSM"
    } ]
  },
  "geo" : { },
  "id_str" : "500004529757495296",
  "text" : "\"There\u2019s...no excuse for police to use excessive force against peaceful protests.\" \u2014President Obama: http:\/\/t.co\/qginFjmxhI #Ferguson",
  "id" : 500004529757495296,
  "created_at" : "2014-08-14 19:42:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justice Department",
      "screen_name" : "TheJusticeDept",
      "indices" : [ 3, 18 ],
      "id_str" : "73181712",
      "id" : 73181712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/AZWKDD2LC6",
      "expanded_url" : "http:\/\/go.usa.gov\/E2ch",
      "display_url" : "go.usa.gov\/E2ch"
    } ]
  },
  "geo" : { },
  "id_str" : "499997442268753920",
  "text" : "RT @TheJusticeDept: Statement by Attorney General Eric Holder on Latest Developments in Ferguson, Missouri http:\/\/t.co\/AZWKDD2LC6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/AZWKDD2LC6",
        "expanded_url" : "http:\/\/go.usa.gov\/E2ch",
        "display_url" : "go.usa.gov\/E2ch"
      } ]
    },
    "geo" : { },
    "id_str" : "499989605866037249",
    "text" : "Statement by Attorney General Eric Holder on Latest Developments in Ferguson, Missouri http:\/\/t.co\/AZWKDD2LC6",
    "id" : 499989605866037249,
    "created_at" : "2014-08-14 18:43:06 +0000",
    "user" : {
      "name" : "Justice Department",
      "screen_name" : "TheJusticeDept",
      "protected" : false,
      "id_str" : "73181712",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/445550654\/twitter_logo_normal.png",
      "id" : 73181712,
      "verified" : true
    }
  },
  "id" : 499997442268753920,
  "created_at" : "2014-08-14 19:14:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Governor Jay Nixon",
      "screen_name" : "GovJayNixon",
      "indices" : [ 49, 61 ],
      "id_str" : "34308692",
      "id" : 34308692
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/499988910622392320\/photo\/1",
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/h8AMuQIbqI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BvBRQ8uIIAANyg6.jpg",
      "id_str" : "499988910257479680",
      "id" : 499988910257479680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvBRQ8uIIAANyg6.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 667,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 667,
        "resize" : "fit",
        "w" : 1000
      } ],
      "display_url" : "pic.twitter.com\/h8AMuQIbqI"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "499988910622392320",
  "text" : "President Obama talks on the phone with Missouri @GovJayNixon on the situation in Ferguson. http:\/\/t.co\/h8AMuQIbqI",
  "id" : 499988910622392320,
  "created_at" : "2014-08-14 18:40:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/499979570976919552\/photo\/1",
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/phm1Y6yBYZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BvBIxSoIMAExsTZ.jpg",
      "id_str" : "499979570289061889",
      "id" : 499979570289061889,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvBIxSoIMAExsTZ.jpg",
      "sizes" : [ {
        "h" : 231,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 407,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 695,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 987,
        "resize" : "fit",
        "w" : 1455
      } ],
      "display_url" : "pic.twitter.com\/phm1Y6yBYZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "499979570976919552",
  "text" : "\"Now is the time for an open &amp; transparent process to see that justice is done.\" \u2014Obama on the situation in Ferguson http:\/\/t.co\/phm1Y6yBYZ",
  "id" : 499979570976919552,
  "created_at" : "2014-08-14 18:03:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "499963359610277889",
  "text" : "\"Now\u2019s the time for healing. Now\u2019s the time for peace and calm on the streets of Ferguson.\u201D \u2014President Obama",
  "id" : 499963359610277889,
  "created_at" : "2014-08-14 16:58:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "499962949088591872",
  "text" : "\"In the United States of America, police should not be bullying or arresting journalists who are trying to do their jobs.\" \u2014President Obama",
  "id" : 499962949088591872,
  "created_at" : "2014-08-14 16:57:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ferguson",
      "indices" : [ 121, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "499962560180133888",
  "text" : "Obama: AG Holder \"should do what is necessary to help determine exactly what happened, and to see that justice is done.\" #Ferguson",
  "id" : 499962560180133888,
  "created_at" : "2014-08-14 16:55:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FBI",
      "screen_name" : "FBI",
      "indices" : [ 55, 59 ],
      "id_str" : "17629860",
      "id" : 17629860
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "499962435814846464",
  "text" : "\"I've already tasked the Department of Justice and the @FBI to investigate the death of Michael Brown.\" \u2014Obama on the situation in Ferguson",
  "id" : 499962435814846464,
  "created_at" : "2014-08-14 16:55:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "499962111188291584",
  "text" : "RT @WHLive: \"We are urging Iraqis to come together...by seizing the enormous opportunity of forming a new, inclusive government.\" \u2014Presiden\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "499962063566159872",
    "text" : "\"We are urging Iraqis to come together...by seizing the enormous opportunity of forming a new, inclusive government.\" \u2014President Obama",
    "id" : 499962063566159872,
    "created_at" : "2014-08-14 16:53:39 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 499962111188291584,
  "created_at" : "2014-08-14 16:53:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "499961880476418049",
  "text" : "\"I could not be prouder of the men and women of our military who carried out this humanitarian operation.\" \u2014Obama on the situation in Iraq",
  "id" : 499961880476418049,
  "created_at" : "2014-08-14 16:52:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "499961793683660801",
  "text" : "RT @WHLive: \"We broke the ISIL siege...we helped vulnerable people reach safety, and we helped save many innocent lives.\" \u2014Obama on Mount S\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "499961738646003712",
    "text" : "\"We broke the ISIL siege...we helped vulnerable people reach safety, and we helped save many innocent lives.\" \u2014Obama on Mount Sinjar",
    "id" : 499961738646003712,
    "created_at" : "2014-08-14 16:52:21 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 499961793683660801,
  "created_at" : "2014-08-14 16:52:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "499961339046293504",
  "text" : "RT @WHLive: \"The U.S. military conducted humanitarian air drops...delivering more than 114,000 meals &amp; 35,000 gallons of fresh water.\" \u2014Pre\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "499961295010267137",
    "text" : "\"The U.S. military conducted humanitarian air drops...delivering more than 114,000 meals &amp; 35,000 gallons of fresh water.\" \u2014President Obama",
    "id" : 499961295010267137,
    "created_at" : "2014-08-14 16:50:36 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 499961339046293504,
  "created_at" : "2014-08-14 16:50:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "499961049211486208",
  "text" : "\"We continue to make progress in carrying out our targeted military operations in Iraq.\" \u2014President Obama",
  "id" : 499961049211486208,
  "created_at" : "2014-08-14 16:49:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/b4tqL3oo0v",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "499960989010636800",
  "text" : "Happening now: President Obama delivers a statement on the latest developments in Iraq and the situation in Ferguson. http:\/\/t.co\/b4tqL3oo0v",
  "id" : 499960989010636800,
  "created_at" : "2014-08-14 16:49:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Schultz",
      "screen_name" : "Schultz44",
      "indices" : [ 3, 13 ],
      "id_str" : "1603419038",
      "id" : 1603419038
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "499941303019646977",
  "text" : "RT @Schultz44: Today at 12:15, the President will give an update on the latest developments in Iraq, and a statement on the situation in Fe\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "499941098165649408",
    "text" : "Today at 12:15, the President will give an update on the latest developments in Iraq, and a statement on the situation in Ferguson.",
    "id" : 499941098165649408,
    "created_at" : "2014-08-14 15:30:20 +0000",
    "user" : {
      "name" : "Eric Schultz",
      "screen_name" : "Schultz44",
      "protected" : false,
      "id_str" : "1603419038",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/491941155815161856\/u0IdexM6_normal.jpeg",
      "id" : 1603419038,
      "verified" : true
    }
  },
  "id" : 499941303019646977,
  "created_at" : "2014-08-14 15:31:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/b4tqL3oo0v",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "499939719170764800",
  "text" : "At 12:15pm ET, President Obama will deliver a statement. Tune in here \u2192 http:\/\/t.co\/b4tqL3oo0v",
  "id" : 499939719170764800,
  "created_at" : "2014-08-14 15:24:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "indices" : [ 78, 88 ],
      "id_str" : "1613223313",
      "id" : 1613223313
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 94, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/iKhY6rx1af",
      "expanded_url" : "http:\/\/go.wh.gov\/8Xfm1q",
      "display_url" : "go.wh.gov\/8Xfm1q"
    } ]
  },
  "geo" : { },
  "id_str" : "499678568084164608",
  "text" : "\"A college degree remains one of the surest pathways into the middle class.\" \u2014@Cecilia44 on \u2191 #CollegeOpportunity: http:\/\/t.co\/iKhY6rx1af",
  "id" : 499678568084164608,
  "created_at" : "2014-08-13 22:07:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/499656713193406464\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/XlvqxssyOM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bu8jIemIQAE2gHR.jpg",
      "id_str" : "499656712220327937",
      "id" : 499656712220327937,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bu8jIemIQAE2gHR.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/XlvqxssyOM"
    } ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 67, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/iKhY6rx1af",
      "expanded_url" : "http:\/\/go.wh.gov\/8Xfm1q",
      "display_url" : "go.wh.gov\/8Xfm1q"
    } ]
  },
  "geo" : { },
  "id_str" : "499656713193406464",
  "text" : "We're building on the progress we've made with new steps to expand #CollegeOpportunity: http:\/\/t.co\/iKhY6rx1af http:\/\/t.co\/XlvqxssyOM",
  "id" : 499656713193406464,
  "created_at" : "2014-08-13 20:40:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 3, 11 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/oAfts8AyeS",
      "expanded_url" : "http:\/\/go.wh.gov\/8Xfm1q",
      "display_url" : "go.wh.gov\/8Xfm1q"
    } ]
  },
  "geo" : { },
  "id_str" : "499641762244489217",
  "text" : "RT @DrBiden: Just announced: 14 new community college commitments to strengthen college readiness. http:\/\/t.co\/oAfts8AyeS #CollegeOpportuni\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CollegeOpportunity",
        "indices" : [ 109, 128 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/oAfts8AyeS",
        "expanded_url" : "http:\/\/go.wh.gov\/8Xfm1q",
        "display_url" : "go.wh.gov\/8Xfm1q"
      } ]
    },
    "geo" : { },
    "id_str" : "499627478261178368",
    "text" : "Just announced: 14 new community college commitments to strengthen college readiness. http:\/\/t.co\/oAfts8AyeS #CollegeOpportunity",
    "id" : 499627478261178368,
    "created_at" : "2014-08-13 18:44:08 +0000",
    "user" : {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "protected" : false,
      "id_str" : "1281405877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608687663034474496\/wvzVG_yt_normal.jpg",
      "id" : 1281405877,
      "verified" : true
    }
  },
  "id" : 499641762244489217,
  "created_at" : "2014-08-13 19:40:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 22, 41 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/iKhY6rx1af",
      "expanded_url" : "http:\/\/go.wh.gov\/8Xfm1q",
      "display_url" : "go.wh.gov\/8Xfm1q"
    } ]
  },
  "geo" : { },
  "id_str" : "499633196120956928",
  "text" : "We're hosting another #CollegeOpportunity Summit to build partnerships that help prepare more kids for college: http:\/\/t.co\/iKhY6rx1af",
  "id" : 499633196120956928,
  "created_at" : "2014-08-13 19:06:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 97, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "499625782814445568",
  "text" : "RT @VP: A college degree remains one of the surest pathways into the middle class. Check out new #CollegeOpportunity efforts: http:\/\/t.co\/n\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CollegeOpportunity",
        "indices" : [ 89, 108 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/naeikP7zAb",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2014\/08\/13\/new-commitments-improve-college-opportunity",
        "display_url" : "whitehouse.gov\/blog\/2014\/08\/1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "499614533225545728",
    "text" : "A college degree remains one of the surest pathways into the middle class. Check out new #CollegeOpportunity efforts: http:\/\/t.co\/naeikP7zAb",
    "id" : 499614533225545728,
    "created_at" : "2014-08-13 17:52:41 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 499625782814445568,
  "created_at" : "2014-08-13 18:37:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "499622860550582272",
  "text" : "RT @arneduncan: To make sure all students have access to rigorous courses, we are helping cover AP exam fees for low-income students http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/lvzZRTmmSR",
        "expanded_url" : "http:\/\/ow.ly\/AhzT6",
        "display_url" : "ow.ly\/AhzT6"
      } ]
    },
    "geo" : { },
    "id_str" : "499617695428788224",
    "text" : "To make sure all students have access to rigorous courses, we are helping cover AP exam fees for low-income students http:\/\/t.co\/lvzZRTmmSR",
    "id" : 499617695428788224,
    "created_at" : "2014-08-13 18:05:15 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 499622860550582272,
  "created_at" : "2014-08-13 18:25:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Maker Camp",
      "screen_name" : "MakerCamp",
      "indices" : [ 58, 68 ],
      "id_str" : "475501695",
      "id" : 475501695
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 76, 87 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MakerCamp",
      "indices" : [ 128, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/nkl94YRq4J",
      "expanded_url" : "http:\/\/go.wh.gov\/wkZdwz",
      "display_url" : "go.wh.gov\/wkZdwz"
    } ]
  },
  "geo" : { },
  "id_str" : "499617155609276417",
  "text" : "RT @FLOTUS: Happening now: Join a virtual field trip with @MakerCamp to the @WhiteHouse Kitchen Garden \u2192 http:\/\/t.co\/nkl94YRq4J #MakerCamp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Maker Camp",
        "screen_name" : "MakerCamp",
        "indices" : [ 46, 56 ],
        "id_str" : "475501695",
        "id" : 475501695
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 64, 75 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MakerCamp",
        "indices" : [ 116, 126 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/nkl94YRq4J",
        "expanded_url" : "http:\/\/go.wh.gov\/wkZdwz",
        "display_url" : "go.wh.gov\/wkZdwz"
      } ]
    },
    "geo" : { },
    "id_str" : "499617074638233601",
    "text" : "Happening now: Join a virtual field trip with @MakerCamp to the @WhiteHouse Kitchen Garden \u2192 http:\/\/t.co\/nkl94YRq4J #MakerCamp",
    "id" : 499617074638233601,
    "created_at" : "2014-08-13 18:02:47 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 499617155609276417,
  "created_at" : "2014-08-13 18:03:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 3, 11 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    }, {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 24, 38 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PCSchat",
      "indices" : [ 102, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/5vQ3LufZwN",
      "expanded_url" : "http:\/\/wh.gov\/lupxZ",
      "display_url" : "wh.gov\/lupxZ"
    } ]
  },
  "geo" : { },
  "id_str" : "499613806298152962",
  "text" : "RT @DrBiden: First-ever @JoiningForces Twitter Q&amp;A is about to start \u2192 http:\/\/t.co\/5vQ3LufZwN Use #PCSchat to ask Qs about Permanent Change\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Joining Forces",
        "screen_name" : "JoiningForces",
        "indices" : [ 11, 25 ],
        "id_str" : "26278266",
        "id" : 26278266
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PCSchat",
        "indices" : [ 89, 97 ]
      } ],
      "urls" : [ {
        "indices" : [ 62, 84 ],
        "url" : "http:\/\/t.co\/5vQ3LufZwN",
        "expanded_url" : "http:\/\/wh.gov\/lupxZ",
        "display_url" : "wh.gov\/lupxZ"
      } ]
    },
    "geo" : { },
    "id_str" : "499613473723392000",
    "text" : "First-ever @JoiningForces Twitter Q&amp;A is about to start \u2192 http:\/\/t.co\/5vQ3LufZwN Use #PCSchat to ask Qs about Permanent Change of Station.",
    "id" : 499613473723392000,
    "created_at" : "2014-08-13 17:48:29 +0000",
    "user" : {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "protected" : false,
      "id_str" : "1281405877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608687663034474496\/wvzVG_yt_normal.jpg",
      "id" : 1281405877,
      "verified" : true
    }
  },
  "id" : 499613806298152962,
  "created_at" : "2014-08-13 17:49:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/499606448671035393\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/vitLaUoU4J",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bu71auaIcAESnYJ.jpg",
      "id_str" : "499606448167743489",
      "id" : 499606448167743489,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bu71auaIcAESnYJ.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/vitLaUoU4J"
    } ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 50, 69 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/iKhY6rx1af",
      "expanded_url" : "http:\/\/go.wh.gov\/8Xfm1q",
      "display_url" : "go.wh.gov\/8Xfm1q"
    } ]
  },
  "geo" : { },
  "id_str" : "499606448671035393",
  "text" : "Get the latest on how President Obama's expanding #CollegeOpportunity for more Americans: http:\/\/t.co\/iKhY6rx1af http:\/\/t.co\/vitLaUoU4J",
  "id" : 499606448671035393,
  "created_at" : "2014-08-13 17:20:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Google",
      "screen_name" : "google",
      "indices" : [ 3, 10 ],
      "id_str" : "20536157",
      "id" : 20536157
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 65, 76 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MakerCamp",
      "indices" : [ 116, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/HGOm0ehtj4",
      "expanded_url" : "http:\/\/goo.gl\/cLXIdg",
      "display_url" : "goo.gl\/cLXIdg"
    } ]
  },
  "geo" : { },
  "id_str" : "499597281063346176",
  "text" : "RT @google: Makers! At 11am PT, take a virtual field trip to the @WhiteHouse Kitchen Garden: http:\/\/t.co\/HGOm0ehtj4 #MakerCamp http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 53, 64 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/google\/status\/499591174689026048\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/j0XHrUi2kQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bu7nho2CYAIb83Z.png",
        "id_str" : "499591173770469378",
        "id" : 499591173770469378,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bu7nho2CYAIb83Z.png",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/j0XHrUi2kQ"
      } ],
      "hashtags" : [ {
        "text" : "MakerCamp",
        "indices" : [ 104, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/HGOm0ehtj4",
        "expanded_url" : "http:\/\/goo.gl\/cLXIdg",
        "display_url" : "goo.gl\/cLXIdg"
      } ]
    },
    "geo" : { },
    "id_str" : "499591174689026048",
    "text" : "Makers! At 11am PT, take a virtual field trip to the @WhiteHouse Kitchen Garden: http:\/\/t.co\/HGOm0ehtj4 #MakerCamp http:\/\/t.co\/j0XHrUi2kQ",
    "id" : 499591174689026048,
    "created_at" : "2014-08-13 16:19:52 +0000",
    "user" : {
      "name" : "Google",
      "screen_name" : "google",
      "protected" : false,
      "id_str" : "20536157",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762369348300251136\/5Obhonwa_normal.jpg",
      "id" : 20536157,
      "verified" : true
    }
  },
  "id" : 499597281063346176,
  "created_at" : "2014-08-13 16:44:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Google For Education",
      "screen_name" : "GoogleForEdu",
      "indices" : [ 3, 16 ],
      "id_str" : "254218142",
      "id" : 254218142
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 54, 65 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "makercamp",
      "indices" : [ 95, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/HuEY52Mdej",
      "expanded_url" : "http:\/\/goo.gl\/cLXIdg",
      "display_url" : "goo.gl\/cLXIdg"
    } ]
  },
  "geo" : { },
  "id_str" : "499584501367201792",
  "text" : "RT @GoogleForEdu: Join us for a live Hangout from the @WhiteHouse Garden today at 2pm EST with #makercamp http:\/\/t.co\/HuEY52Mdej http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 36, 47 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/GoogleForEdu\/status\/499440890343985152\/photo\/1",
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/RH0f8bISDP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bu5e160CEAA6ZWK.png",
        "id_str" : "499440889098276864",
        "id" : 499440889098276864,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bu5e160CEAA6ZWK.png",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/RH0f8bISDP"
      } ],
      "hashtags" : [ {
        "text" : "makercamp",
        "indices" : [ 77, 87 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/HuEY52Mdej",
        "expanded_url" : "http:\/\/goo.gl\/cLXIdg",
        "display_url" : "goo.gl\/cLXIdg"
      } ]
    },
    "geo" : { },
    "id_str" : "499440890343985152",
    "text" : "Join us for a live Hangout from the @WhiteHouse Garden today at 2pm EST with #makercamp http:\/\/t.co\/HuEY52Mdej http:\/\/t.co\/RH0f8bISDP",
    "id" : 499440890343985152,
    "created_at" : "2014-08-13 06:22:42 +0000",
    "user" : {
      "name" : "Google For Education",
      "screen_name" : "GoogleForEdu",
      "protected" : false,
      "id_str" : "254218142",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/638744309345288192\/Daix6KET_normal.png",
      "id" : 254218142,
      "verified" : true
    }
  },
  "id" : 499584501367201792,
  "created_at" : "2014-08-13 15:53:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/499578676086706176\/photo\/1",
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/xuVRt9jFj4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bu7Y610IIAAyOrf.jpg",
      "id_str" : "499575114074431488",
      "id" : 499575114074431488,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bu7Y610IIAAyOrf.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/xuVRt9jFj4"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 13, 26 ]
    }, {
      "text" : "RaiseTheWage",
      "indices" : [ 89, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "499578676086706176",
  "text" : "It's time to #RaiseTheWage and help millions of families lift themselves out of poverty. #RaiseTheWage http:\/\/t.co\/xuVRt9jFj4",
  "id" : 499578676086706176,
  "created_at" : "2014-08-13 15:30:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/499568730889019392\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/JZiBeBzvsB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bu7THPiIMAEd1-V.jpg",
      "id_str" : "499568730066923521",
      "id" : 499568730066923521,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bu7THPiIMAEd1-V.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1328,
        "resize" : "fit",
        "w" : 1992
      } ],
      "display_url" : "pic.twitter.com\/JZiBeBzvsB"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/IeOHkrTpcD",
      "expanded_url" : "http:\/\/wapo.st\/1pL73ZS",
      "display_url" : "wapo.st\/1pL73ZS"
    } ]
  },
  "geo" : { },
  "id_str" : "499568730889019392",
  "text" : "President Obama's launching the U.S. Digital Service to improve government digital services \u2192 http:\/\/t.co\/IeOHkrTpcD http:\/\/t.co\/JZiBeBzvsB",
  "id" : 499568730889019392,
  "created_at" : "2014-08-13 14:50:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "indices" : [ 3, 11 ],
      "id_str" : "1530850933",
      "id" : 1530850933
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/GinaEPA\/status\/499287674440908800\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/xjAjm8TIfN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bu3TfeuCEAE9i58.jpg",
      "id_str" : "499287671483535361",
      "id" : 499287671483535361,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bu3TfeuCEAE9i58.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/xjAjm8TIfN"
    } ],
    "hashtags" : [ {
      "text" : "PEYA",
      "indices" : [ 79, 84 ]
    }, {
      "text" : "PIAEE",
      "indices" : [ 89, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "499552184003219456",
  "text" : "RT @GinaEPA: Congrats to the amazing students and teachers winning this year\u2019s #PEYA and #PIAEE awards. http:\/\/t.co\/xjAjm8TIfN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/GinaEPA\/status\/499287674440908800\/photo\/1",
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/xjAjm8TIfN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bu3TfeuCEAE9i58.jpg",
        "id_str" : "499287671483535361",
        "id" : 499287671483535361,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bu3TfeuCEAE9i58.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/xjAjm8TIfN"
      } ],
      "hashtags" : [ {
        "text" : "PEYA",
        "indices" : [ 66, 71 ]
      }, {
        "text" : "PIAEE",
        "indices" : [ 76, 82 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "499287674440908800",
    "text" : "Congrats to the amazing students and teachers winning this year\u2019s #PEYA and #PIAEE awards. http:\/\/t.co\/xjAjm8TIfN",
    "id" : 499287674440908800,
    "created_at" : "2014-08-12 20:13:52 +0000",
    "user" : {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "protected" : false,
      "id_str" : "1530850933",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/632229333130604548\/Bb4I34DU_normal.jpg",
      "id" : 1530850933,
      "verified" : true
    }
  },
  "id" : 499552184003219456,
  "created_at" : "2014-08-13 13:44:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/499334544722366464\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/vd2IN5kN0f",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bu3swtKIMAAyjH5.jpg",
      "id_str" : "499315455207944192",
      "id" : 499315455207944192,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bu3swtKIMAAyjH5.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/vd2IN5kN0f"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 72, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/aOsNk222m2",
      "expanded_url" : "http:\/\/wh.gov\/raise-the-wage",
      "display_url" : "wh.gov\/raise-the-wage"
    } ]
  },
  "geo" : { },
  "id_str" : "499334544722366464",
  "text" : "Nobody who works full-time should have to live in poverty. It's time to #RaiseTheWage \u2192 http:\/\/t.co\/aOsNk222m2 http:\/\/t.co\/vd2IN5kN0f",
  "id" : 499334544722366464,
  "created_at" : "2014-08-12 23:20:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/499324459845554176\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/uQecwOQuGh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bu3rsKNIIAAHfWa.jpg",
      "id_str" : "499314277594177536",
      "id" : 499314277594177536,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bu3rsKNIIAAHfWa.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/uQecwOQuGh"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/aOsNk222m2",
      "expanded_url" : "http:\/\/wh.gov\/raise-the-wage",
      "display_url" : "wh.gov\/raise-the-wage"
    } ]
  },
  "geo" : { },
  "id_str" : "499324459845554176",
  "text" : "FACT: Raising the minimum wage would benefit more than 28 million workers across the country. http:\/\/t.co\/aOsNk222m2 http:\/\/t.co\/uQecwOQuGh",
  "id" : 499324459845554176,
  "created_at" : "2014-08-12 22:40:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/499313294583549952\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/0lMqkjo7JR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bu3qy6XIcAAypM_.jpg",
      "id_str" : "499313294088630272",
      "id" : 499313294088630272,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bu3qy6XIcAAypM_.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/0lMqkjo7JR"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 101, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "499313294583549952",
  "text" : "Congress could help about 2 million families lift themselves out of poverty by raising the min wage. #RaiseTheWage http:\/\/t.co\/0lMqkjo7JR",
  "id" : 499313294583549952,
  "created_at" : "2014-08-12 21:55:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/499293773990744064\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/j9R08mf0Zq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bu3ZCquIEAEYooW.png",
      "id_str" : "499293773558714369",
      "id" : 499293773558714369,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bu3ZCquIEAEYooW.png",
      "sizes" : [ {
        "h" : 304,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 311,
        "resize" : "fit",
        "w" : 1047
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 101,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 178,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/j9R08mf0Zq"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "499293773990744064",
  "text" : "\"The death of Michael Brown is heartbreaking, and Michelle and I send our deepest condolences to his family.\" \u2014Obama http:\/\/t.co\/j9R08mf0Zq",
  "id" : 499293773990744064,
  "created_at" : "2014-08-12 20:38:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/499285857770422272\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/sHHyupzmY1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bu3R12SIAAA-2ze.jpg",
      "id_str" : "499285856742801408",
      "id" : 499285856742801408,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bu3R12SIAAA-2ze.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/sHHyupzmY1"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/fMEhvXfOhy",
      "expanded_url" : "http:\/\/wh.gov\/raise-the-wage",
      "display_url" : "wh.gov\/raise-the-wage"
    } ]
  },
  "geo" : { },
  "id_str" : "499292706854940672",
  "text" : "RT if you agree: It's time to raise the minimum wage for all hardworking Americans \u2192 http:\/\/t.co\/fMEhvXfOhy http:\/\/t.co\/sHHyupzmY1",
  "id" : 499292706854940672,
  "created_at" : "2014-08-12 20:33:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/499285857770422272\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/sHHyupzmY1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bu3R12SIAAA-2ze.jpg",
      "id_str" : "499285856742801408",
      "id" : 499285856742801408,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bu3R12SIAAA-2ze.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/sHHyupzmY1"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 58, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/fMEhvXfOhy",
      "expanded_url" : "http:\/\/wh.gov\/raise-the-wage",
      "display_url" : "wh.gov\/raise-the-wage"
    } ]
  },
  "geo" : { },
  "id_str" : "499285857770422272",
  "text" : "States are taking the lead, but it's time for Congress to #RaiseTheWage for all Americans \u2192 http:\/\/t.co\/fMEhvXfOhy http:\/\/t.co\/sHHyupzmY1",
  "id" : 499285857770422272,
  "created_at" : "2014-08-12 20:06:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/499265591312908288\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/ZOOlUhMOAX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bu2_aNcIIAAyqyN.jpg",
      "id_str" : "499265590713131008",
      "id" : 499265590713131008,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bu2_aNcIIAAyqyN.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1366,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/ZOOlUhMOAX"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/7xRtp2BErt",
      "expanded_url" : "http:\/\/go.wh.gov\/2yY2PN",
      "display_url" : "go.wh.gov\/2yY2PN"
    } ]
  },
  "geo" : { },
  "id_str" : "499265591312908288",
  "text" : "Here's a readout of President Obama's call with Canadian @PMHarper on the situation in Iraq \u2192 http:\/\/t.co\/7xRtp2BErt http:\/\/t.co\/ZOOlUhMOAX",
  "id" : 499265591312908288,
  "created_at" : "2014-08-12 18:46:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Schultz",
      "screen_name" : "Schultz44",
      "indices" : [ 3, 13 ],
      "id_str" : "1603419038",
      "id" : 1603419038
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "499241164919541760",
  "text" : "RT @Schultz44: This AM, Natl Sec Advisor Susan Rice briefed POTUS on latest national security developments - including updates on Iraq, Ukr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "499228217396695040",
    "text" : "This AM, Natl Sec Advisor Susan Rice briefed POTUS on latest national security developments - including updates on Iraq, Ukraine and Gaza.",
    "id" : 499228217396695040,
    "created_at" : "2014-08-12 16:17:36 +0000",
    "user" : {
      "name" : "Eric Schultz",
      "screen_name" : "Schultz44",
      "protected" : false,
      "id_str" : "1603419038",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/491941155815161856\/u0IdexM6_normal.jpeg",
      "id" : 1603419038,
      "verified" : true
    }
  },
  "id" : 499241164919541760,
  "created_at" : "2014-08-12 17:09:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    }, {
      "name" : "GlacierNationalPark",
      "screen_name" : "GlacierNPS",
      "indices" : [ 96, 107 ],
      "id_str" : "32887168",
      "id" : 32887168
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/498988716380418048\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/IUOUd0KhkC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BuzDl6TCIAAwMZ7.jpg",
      "id_str" : "498988714802946048",
      "id" : 498988714802946048,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BuzDl6TCIAAwMZ7.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1438,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 421,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 719,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 239,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/IUOUd0KhkC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "499215438249984000",
  "text" : "RT @Interior: \"If it isn't God's backyard, then he certainly lives nearby.\" - Robin Williams on @GlacierNPS. RIP http:\/\/t.co\/IUOUd0KhkC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "GlacierNationalPark",
        "screen_name" : "GlacierNPS",
        "indices" : [ 82, 93 ],
        "id_str" : "32887168",
        "id" : 32887168
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/498988716380418048\/photo\/1",
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/IUOUd0KhkC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BuzDl6TCIAAwMZ7.jpg",
        "id_str" : "498988714802946048",
        "id" : 498988714802946048,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BuzDl6TCIAAwMZ7.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1438,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 421,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 719,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 239,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/IUOUd0KhkC"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "498988716380418048",
    "text" : "\"If it isn't God's backyard, then he certainly lives nearby.\" - Robin Williams on @GlacierNPS. RIP http:\/\/t.co\/IUOUd0KhkC",
    "id" : 498988716380418048,
    "created_at" : "2014-08-12 00:25:55 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 499215438249984000,
  "created_at" : "2014-08-12 15:26:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill de Blasio",
      "screen_name" : "BilldeBlasio",
      "indices" : [ 3, 16 ],
      "id_str" : "476193064",
      "id" : 476193064
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/BilldeBlasio\/status\/498956648099352577\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/uPG5omrilR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BuymbWQIAAA2mq3.jpg",
      "id_str" : "498956647491174400",
      "id" : 498956647491174400,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BuymbWQIAAA2mq3.jpg",
      "sizes" : [ {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 799,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/uPG5omrilR"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/1mbmk1bEC6",
      "expanded_url" : "http:\/\/on.nyc.gov\/XY4Hh2",
      "display_url" : "on.nyc.gov\/XY4Hh2"
    } ]
  },
  "geo" : { },
  "id_str" : "499209448884555776",
  "text" : "RT @BilldeBlasio: It\u2019s up to cities to lead the way. We came up with a commitment to action: http:\/\/t.co\/1mbmk1bEC6 http:\/\/t.co\/uPG5omrilR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BilldeBlasio\/status\/498956648099352577\/photo\/1",
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/uPG5omrilR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BuymbWQIAAA2mq3.jpg",
        "id_str" : "498956647491174400",
        "id" : 498956647491174400,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BuymbWQIAAA2mq3.jpg",
        "sizes" : [ {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 799,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/uPG5omrilR"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/1mbmk1bEC6",
        "expanded_url" : "http:\/\/on.nyc.gov\/XY4Hh2",
        "display_url" : "on.nyc.gov\/XY4Hh2"
      } ]
    },
    "geo" : { },
    "id_str" : "498956648099352577",
    "text" : "It\u2019s up to cities to lead the way. We came up with a commitment to action: http:\/\/t.co\/1mbmk1bEC6 http:\/\/t.co\/uPG5omrilR",
    "id" : 498956648099352577,
    "created_at" : "2014-08-11 22:18:29 +0000",
    "user" : {
      "name" : "Bill de Blasio",
      "screen_name" : "NYCMayor",
      "protected" : false,
      "id_str" : "19834403",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797104781974192128\/xv2CMcBu_normal.jpg",
      "id" : 19834403,
      "verified" : true
    }
  },
  "id" : 499209448884555776,
  "created_at" : "2014-08-12 15:03:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/499201584077996032\/photo\/1",
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/WMEpJ9CG1W",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bu2FMf2IMAAqWIS.jpg",
      "id_str" : "499201583461445632",
      "id" : 499201583461445632,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bu2FMf2IMAAqWIS.jpg",
      "sizes" : [ {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 399,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1768,
        "resize" : "fit",
        "w" : 2658
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 681,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/WMEpJ9CG1W"
    } ],
    "hashtags" : [ {
      "text" : "RIPRobinWilliams",
      "indices" : [ 104, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "499201584077996032",
  "text" : "\"He gave his immeasurable talent freely &amp; generously to those who needed it most.\" \u2014President Obama #RIPRobinWilliams http:\/\/t.co\/WMEpJ9CG1W",
  "id" : 499201584077996032,
  "created_at" : "2014-08-12 14:31:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/498999298135437312\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/kbEq7OwPOf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BuzNN2EIUAAepXV.png",
      "id_str" : "498999296466112512",
      "id" : 498999296466112512,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BuzNN2EIUAAepXV.png",
      "sizes" : [ {
        "h" : 290,
        "resize" : "fit",
        "w" : 954
      }, {
        "h" : 290,
        "resize" : "fit",
        "w" : 954
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 182,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 103,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/kbEq7OwPOf"
    } ],
    "hashtags" : [ {
      "text" : "RIPRobinWilliams",
      "indices" : [ 90, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "499002336376029185",
  "text" : "He made us laugh. He made us cry. He ended up touching every element of the human spirit. #RIPRobinWilliams http:\/\/t.co\/kbEq7OwPOf",
  "id" : 499002336376029185,
  "created_at" : "2014-08-12 01:20:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/498999298135437312\/photo\/1",
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/kbEq7OwPOf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BuzNN2EIUAAepXV.png",
      "id_str" : "498999296466112512",
      "id" : 498999296466112512,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BuzNN2EIUAAepXV.png",
      "sizes" : [ {
        "h" : 290,
        "resize" : "fit",
        "w" : 954
      }, {
        "h" : 290,
        "resize" : "fit",
        "w" : 954
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 182,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 103,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/kbEq7OwPOf"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "498999298135437312",
  "text" : "\"He was one of a kind.\" \u2014President Obama on the passing of Robin Williams http:\/\/t.co\/kbEq7OwPOf",
  "id" : 498999298135437312,
  "created_at" : "2014-08-12 01:07:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/498957250523070465\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/JQN3kT4fOz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Buym-ZlIIAA6VLH.jpg",
      "id_str" : "498957249679990784",
      "id" : 498957249679990784,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Buym-ZlIIAA6VLH.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/JQN3kT4fOz"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/nHl5O47VLa",
      "expanded_url" : "http:\/\/go.wh.gov\/Jvd94s",
      "display_url" : "go.wh.gov\/Jvd94s"
    } ]
  },
  "geo" : { },
  "id_str" : "498957250523070465",
  "text" : "\"We stand ready to partner with Iraq in its fight against these terrorist forces.\" \u2014Obama: http:\/\/t.co\/nHl5O47VLa http:\/\/t.co\/JQN3kT4fOz",
  "id" : 498957250523070465,
  "created_at" : "2014-08-11 22:20:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "498939838406856705",
  "text" : "\"The United States stands ready to support a government that addresses the needs and grievances of all Iraqi people.\" \u2014President Obama",
  "id" : 498939838406856705,
  "created_at" : "2014-08-11 21:11:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "498939755904901120",
  "text" : "RT @WHLive: Obama: \"President Masum named a new Prime Minister designate, Dr. Haider al-Abadi...an important step towards forming a new gov\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "498939668667580418",
    "text" : "Obama: \"President Masum named a new Prime Minister designate, Dr. Haider al-Abadi...an important step towards forming a new government.\"",
    "id" : 498939668667580418,
    "created_at" : "2014-08-11 21:11:01 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 498939755904901120,
  "created_at" : "2014-08-11 21:11:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "498939543291432960",
  "text" : "President Obama: \"The only lasting solution is for Iraqis to come together and form an inclusive government.\"",
  "id" : 498939543291432960,
  "created_at" : "2014-08-11 21:10:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "498939222292963329",
  "text" : "RT @WHLive: \"We\u2019ve stepped up military advice and assistance to Iraqi and Kurdish forces as they wage the fight against ISIL.\" \u2014President O\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "498939194316955648",
    "text" : "\"We\u2019ve stepped up military advice and assistance to Iraqi and Kurdish forces as they wage the fight against ISIL.\" \u2014President Obama",
    "id" : 498939194316955648,
    "created_at" : "2014-08-11 21:09:08 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 498939222292963329,
  "created_at" : "2014-08-11 21:09:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "498939103875186689",
  "text" : "\"American forces have successfully conducted targeted airstrikes to prevent terrorist forces from advancing on the city of Erbil.\" \u2014Obama",
  "id" : 498939103875186689,
  "created_at" : "2014-08-11 21:08:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/b4tqL3oo0v",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "498938996727492609",
  "text" : "Happening now: President Obama delivers a statement on the latest political developments in Iraq. Watch \u2192 http:\/\/t.co\/b4tqL3oo0v",
  "id" : 498938996727492609,
  "created_at" : "2014-08-11 21:08:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/b4tqL3oo0v",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "498917408066007041",
  "text" : "At 4:45pm ET, President Obama will deliver a statement on the latest political developments in Iraq. Watch \u2192 http:\/\/t.co\/b4tqL3oo0v",
  "id" : 498917408066007041,
  "created_at" : "2014-08-11 19:42:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ukraine",
      "indices" : [ 75, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/82XeWfixe5",
      "expanded_url" : "http:\/\/wh.gov\/ludRM",
      "display_url" : "wh.gov\/ludRM"
    } ]
  },
  "geo" : { },
  "id_str" : "498913844891512833",
  "text" : "RT @NSCPress: Readout of the President\u2019s Call with President Poroshenko of #Ukraine: http:\/\/t.co\/82XeWfixe5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Ukraine",
        "indices" : [ 61, 69 ]
      } ],
      "urls" : [ {
        "indices" : [ 71, 93 ],
        "url" : "http:\/\/t.co\/82XeWfixe5",
        "expanded_url" : "http:\/\/wh.gov\/ludRM",
        "display_url" : "wh.gov\/ludRM"
      } ]
    },
    "geo" : { },
    "id_str" : "498898226997514240",
    "text" : "Readout of the President\u2019s Call with President Poroshenko of #Ukraine: http:\/\/t.co\/82XeWfixe5",
    "id" : 498898226997514240,
    "created_at" : "2014-08-11 18:26:21 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 498913844891512833,
  "created_at" : "2014-08-11 19:28:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HealthCare.gov",
      "screen_name" : "HealthCareGov",
      "indices" : [ 71, 85 ],
      "id_str" : "86697288",
      "id" : 86697288
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "498909646682591233",
  "text" : "RT @Santillo44: Top private-sector engineer Mikey Dickerson helped fix @HealthCareGov. Now he'll be improving digital gov services: http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "HealthCare.gov",
        "screen_name" : "HealthCareGov",
        "indices" : [ 55, 69 ],
        "id_str" : "86697288",
        "id" : 86697288
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/of3swVRAul",
        "expanded_url" : "http:\/\/go.wh.gov\/UhRUBN",
        "display_url" : "go.wh.gov\/UhRUBN"
      } ]
    },
    "geo" : { },
    "id_str" : "498903795347496960",
    "text" : "Top private-sector engineer Mikey Dickerson helped fix @HealthCareGov. Now he'll be improving digital gov services: http:\/\/t.co\/of3swVRAul",
    "id" : 498903795347496960,
    "created_at" : "2014-08-11 18:48:28 +0000",
    "user" : {
      "name" : "Katie Hill",
      "screen_name" : "Hill44",
      "protected" : false,
      "id_str" : "2151620534",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/658658579142959104\/85LEK24P_normal.jpg",
      "id" : 2151620534,
      "verified" : true
    }
  },
  "id" : 498909646682591233,
  "created_at" : "2014-08-11 19:11:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aneesh Chopra",
      "screen_name" : "aneeshchopra",
      "indices" : [ 3, 16 ],
      "id_str" : "121539516",
      "id" : 121539516
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 32, 43 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/IYCNDamI6L",
      "expanded_url" : "http:\/\/www.washingtonpost.com\/blogs\/the-switch\/wp\/2014\/08\/11\/white-house-launches-u-s-digital-service-with-healthcare-gov-fixer-at-the-helm\/",
      "display_url" : "washingtonpost.com\/blogs\/the-swit\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "498902636981391360",
  "text" : "RT @aneeshchopra: PROGRESS: the @WhiteHouse launched the next chapter in closing the innovation gap on tech\/govt http:\/\/t.co\/IYCNDamI6L #ab\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 14, 25 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "abigdeal",
        "indices" : [ 118, 127 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/IYCNDamI6L",
        "expanded_url" : "http:\/\/www.washingtonpost.com\/blogs\/the-switch\/wp\/2014\/08\/11\/white-house-launches-u-s-digital-service-with-healthcare-gov-fixer-at-the-helm\/",
        "display_url" : "washingtonpost.com\/blogs\/the-swit\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "498893825990201344",
    "text" : "PROGRESS: the @WhiteHouse launched the next chapter in closing the innovation gap on tech\/govt http:\/\/t.co\/IYCNDamI6L #abigdeal",
    "id" : 498893825990201344,
    "created_at" : "2014-08-11 18:08:51 +0000",
    "user" : {
      "name" : "Aneesh Chopra",
      "screen_name" : "aneeshchopra",
      "protected" : false,
      "id_str" : "121539516",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000040581867\/a0962f4551be12d095b281f8afa81a95_normal.jpeg",
      "id" : 121539516,
      "verified" : true
    }
  },
  "id" : 498902636981391360,
  "created_at" : "2014-08-11 18:43:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/fal3HgnYyu",
      "expanded_url" : "http:\/\/go.wh.gov\/UhRUBN",
      "display_url" : "go.wh.gov\/UhRUBN"
    } ]
  },
  "geo" : { },
  "id_str" : "498895434983555072",
  "text" : "The new U.S. Digital Service will help:\nMake government websites more consumer-friendly \u2713\nIdentify and fix problems \u2713\nhttp:\/\/t.co\/fal3HgnYyu",
  "id" : 498895434983555072,
  "created_at" : "2014-08-11 18:15:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/IeOHkrTpcD",
      "expanded_url" : "http:\/\/wapo.st\/1pL73ZS",
      "display_url" : "wapo.st\/1pL73ZS"
    } ]
  },
  "geo" : { },
  "id_str" : "498888077130354689",
  "text" : "President Obama's bringing in private-sector tech talent to improve and simplify digital government services \u2192 http:\/\/t.co\/IeOHkrTpcD",
  "id" : 498888077130354689,
  "created_at" : "2014-08-11 17:46:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/498863106970632193\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/01tkCHykYc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BuxRWjIIcAAOiue.jpg",
      "id_str" : "498863106559602688",
      "id" : 498863106559602688,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BuxRWjIIcAAOiue.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/01tkCHykYc"
    } ],
    "hashtags" : [ {
      "text" : "AskTheWH",
      "indices" : [ 40, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "498863106970632193",
  "text" : "Got a question for the White House? Use #AskTheWH and watch West Wing Week to see if yours gets answered. http:\/\/t.co\/01tkCHykYc",
  "id" : 498863106970632193,
  "created_at" : "2014-08-11 16:06:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    }, {
      "name" : "Joshua Tree NP",
      "screen_name" : "joshuatreenp",
      "indices" : [ 104, 117 ],
      "id_str" : "3825684196",
      "id" : 3825684196
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "supermoon",
      "indices" : [ 38, 48 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "498851958556721153",
  "text" : "RT @Interior: Many people enjoyed the #supermoon on America's public lands. Here's one of our favorites @JoshuaTreeNP! http:\/\/t.co\/MId3nbW5\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Joshua Tree NP",
        "screen_name" : "joshuatreenp",
        "indices" : [ 90, 103 ],
        "id_str" : "3825684196",
        "id" : 3825684196
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/498846464563765248\/photo\/1",
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/MId3nbW5SK",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BuxCN1PIYAE_Zsy.jpg",
        "id_str" : "498846464127557633",
        "id" : 498846464127557633,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BuxCN1PIYAE_Zsy.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/MId3nbW5SK"
      } ],
      "hashtags" : [ {
        "text" : "supermoon",
        "indices" : [ 24, 34 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "498846464563765248",
    "text" : "Many people enjoyed the #supermoon on America's public lands. Here's one of our favorites @JoshuaTreeNP! http:\/\/t.co\/MId3nbW5SK",
    "id" : 498846464563765248,
    "created_at" : "2014-08-11 15:00:39 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 498851958556721153,
  "created_at" : "2014-08-11 15:22:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/et2k4NxE0j",
      "expanded_url" : "http:\/\/go.wh.gov\/QHi8Tq",
      "display_url" : "go.wh.gov\/QHi8Tq"
    } ]
  },
  "geo" : { },
  "id_str" : "498604770840436739",
  "text" : "\"We\u2019ve begun a humanitarian effort to help those Iraqi civilians trapped on that mountain.\" \u2014President Obama: http:\/\/t.co\/et2k4NxE0j",
  "id" : 498604770840436739,
  "created_at" : "2014-08-10 23:00:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/et2k4NxE0j",
      "expanded_url" : "http:\/\/go.wh.gov\/QHi8Tq",
      "display_url" : "go.wh.gov\/QHi8Tq"
    } ]
  },
  "geo" : { },
  "id_str" : "498551893069549568",
  "text" : "\"The food and water we airdropped will help them survive.\" \u2014Obama on the humanitarian effort to help Iraqi civilians: http:\/\/t.co\/et2k4NxE0j",
  "id" : 498551893069549568,
  "created_at" : "2014-08-10 19:30:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/GlG4dAKWjD",
      "expanded_url" : "http:\/\/go.wh.gov\/QHi8Tq",
      "display_url" : "go.wh.gov\/QHi8Tq"
    } ]
  },
  "geo" : { },
  "id_str" : "498506908807229440",
  "text" : "\"American combat troops will not be returning to fight in Iraq.\" \u2014President Obama: http:\/\/t.co\/GlG4dAKWjD",
  "id" : 498506908807229440,
  "created_at" : "2014-08-10 16:31:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/et2k4NxE0j",
      "expanded_url" : "http:\/\/go.wh.gov\/QHi8Tq",
      "display_url" : "go.wh.gov\/QHi8Tq"
    } ]
  },
  "geo" : { },
  "id_str" : "498268761321787392",
  "text" : "\"We\u2019ll do whatever is needed to protect our people.\" \u2014President Obama on protecting American personnel in Iraq: http:\/\/t.co\/et2k4NxE0j",
  "id" : 498268761321787392,
  "created_at" : "2014-08-10 00:45:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/et2k4NxE0j",
      "expanded_url" : "http:\/\/go.wh.gov\/QHi8Tq",
      "display_url" : "go.wh.gov\/QHi8Tq"
    } ]
  },
  "geo" : { },
  "id_str" : "498249928800358400",
  "text" : "\"Today, we salute our brave men and women in uniform\u2014especially our courageous pilots and crews over Iraq.\" \u2014Obama: http:\/\/t.co\/et2k4NxE0j",
  "id" : 498249928800358400,
  "created_at" : "2014-08-09 23:30:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/et2k4NxE0j",
      "expanded_url" : "http:\/\/go.wh.gov\/QHi8Tq",
      "display_url" : "go.wh.gov\/QHi8Tq"
    } ]
  },
  "geo" : { },
  "id_str" : "498234905608736770",
  "text" : "Obama: \"One anguished Iraqi...cried to the world, 'There is no one coming to help.' Today, America is helping.\" http:\/\/t.co\/et2k4NxE0j",
  "id" : 498234905608736770,
  "created_at" : "2014-08-09 22:30:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/evDpwWZQiD",
      "expanded_url" : "http:\/\/go.wh.gov\/DYuexE",
      "display_url" : "go.wh.gov\/DYuexE"
    } ]
  },
  "geo" : { },
  "id_str" : "498227298907074560",
  "text" : "\"We will continue to show gratitude to our men and women in uniform who are conducting our operations.\" \u2014Obama: http:\/\/t.co\/evDpwWZQiD",
  "id" : 498227298907074560,
  "created_at" : "2014-08-09 22:00:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/254FXu5tB5",
      "expanded_url" : "http:\/\/youtu.be\/8puXfr3seFU",
      "display_url" : "youtu.be\/8puXfr3seFU"
    } ]
  },
  "geo" : { },
  "id_str" : "498215937049239552",
  "text" : "\"We continue to call on Iraqis to come together and form the inclusive government that Iraq needs right now.\" \u2014Obama: http:\/\/t.co\/254FXu5tB5",
  "id" : 498215937049239552,
  "created_at" : "2014-08-09 21:15:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/498208355484061696\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/rqVZgriVpU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BunskbHIcAANyyf.jpg",
      "id_str" : "498189344298266624",
      "id" : 498189344298266624,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BunskbHIcAANyyf.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2334,
        "resize" : "fit",
        "w" : 3500
      } ],
      "display_url" : "pic.twitter.com\/rqVZgriVpU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "498208355484061696",
  "text" : "\u201CAmerica is proud to act alongside our closest friends\u201D \u2014Obama on speaking with PM Cameron and President Hollande http:\/\/t.co\/rqVZgriVpU",
  "id" : 498208355484061696,
  "created_at" : "2014-08-09 20:45:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/evDpwWZQiD",
      "expanded_url" : "http:\/\/go.wh.gov\/DYuexE",
      "display_url" : "go.wh.gov\/DYuexE"
    } ]
  },
  "geo" : { },
  "id_str" : "498200823076098048",
  "text" : "\u201CWe will protect our American citizens in Iraq, whether they\u2019re diplomats, civilians or military.\u201D \u2014President Obama: http:\/\/t.co\/evDpwWZQiD",
  "id" : 498200823076098048,
  "created_at" : "2014-08-09 20:15:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/254FXu5tB5",
      "expanded_url" : "http:\/\/youtu.be\/8puXfr3seFU",
      "display_url" : "youtu.be\/8puXfr3seFU"
    } ]
  },
  "geo" : { },
  "id_str" : "498193259533832192",
  "text" : "\u201COur humanitarian effort continues to help the men, women and children stranded on Mount Sinjar.\u201D \u2014President Obama: http:\/\/t.co\/254FXu5tB5",
  "id" : 498193259533832192,
  "created_at" : "2014-08-09 19:45:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/XBEbgScBp8",
      "expanded_url" : "http:\/\/go.wh.gov\/DYuexE",
      "display_url" : "go.wh.gov\/DYuexE"
    } ]
  },
  "geo" : { },
  "id_str" : "498189048411074560",
  "text" : "\u201CAmerican forces have conducted targeted airstrikes against terrorist forces outside the city of Erbil.\u201D \u2014Obama: http:\/\/t.co\/XBEbgScBp8",
  "id" : 498189048411074560,
  "created_at" : "2014-08-09 19:28:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/XBEbgScBp8",
      "expanded_url" : "http:\/\/go.wh.gov\/DYuexE",
      "display_url" : "go.wh.gov\/DYuexE"
    }, {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/aksPU7Fe5x",
      "expanded_url" : "http:\/\/youtu.be\/OARUBbJFvzc",
      "display_url" : "youtu.be\/OARUBbJFvzc"
    } ]
  },
  "geo" : { },
  "id_str" : "498183654544527360",
  "text" : "This morning, President Obama made a statement on Iraq.\nRead the transcript: http:\/\/t.co\/XBEbgScBp8\nWatch the video: http:\/\/t.co\/aksPU7Fe5x",
  "id" : 498183654544527360,
  "created_at" : "2014-08-09 19:06:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "France",
      "indices" : [ 59, 66 ]
    }, {
      "text" : "Germany",
      "indices" : [ 68, 76 ]
    }, {
      "text" : "UK",
      "indices" : [ 85, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "498154580442902528",
  "text" : "RT @NSCPress: Earlier today, POTUS spoke with leaders from #France, #Germany and the #UK. Readouts forthcoming.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "France",
        "indices" : [ 45, 52 ]
      }, {
        "text" : "Germany",
        "indices" : [ 54, 62 ]
      }, {
        "text" : "UK",
        "indices" : [ 71, 74 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "498146831751467009",
    "text" : "Earlier today, POTUS spoke with leaders from #France, #Germany and the #UK. Readouts forthcoming.",
    "id" : 498146831751467009,
    "created_at" : "2014-08-09 16:40:34 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 498154580442902528,
  "created_at" : "2014-08-09 17:11:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/b4tqL3oo0v",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "498114103224057856",
  "text" : "Happening now: President Obama delivers a statement on the situation in Iraq from the South Lawn \u2192 http:\/\/t.co\/b4tqL3oo0v",
  "id" : 498114103224057856,
  "created_at" : "2014-08-09 14:30:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/b4tqL3oo0v",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "498108955223404545",
  "text" : "At 10:25am ET President Obama delivers a statement on the situation in Iraq from the South Lawn \u2192 http:\/\/t.co\/b4tqL3oo0v",
  "id" : 498108955223404545,
  "created_at" : "2014-08-09 14:10:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/497857311524679680\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/TB1dCZ7hoo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Buic-NyIcAAoc6E.jpg",
      "id_str" : "497820351490191360",
      "id" : 497820351490191360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Buic-NyIcAAoc6E.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/TB1dCZ7hoo"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "497857311524679680",
  "text" : "\"At the request of the Iraqi government\u2014we\u2019ve begun operations to help save Iraqi civilians.\" \u2014President Obama http:\/\/t.co\/TB1dCZ7hoo",
  "id" : 497857311524679680,
  "created_at" : "2014-08-08 21:30:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "497849844426219522",
  "text" : "\"I authorized two operations in Iraq\u2014targeted airstrikes to protect our American personnel, and a humanitarian effort.\" \u2014President Obama",
  "id" : 497849844426219522,
  "created_at" : "2014-08-08 21:00:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/MZjda4aWyO",
      "expanded_url" : "http:\/\/youtu.be\/ax4a6cH1Wjs",
      "display_url" : "youtu.be\/ax4a6cH1Wjs"
    } ]
  },
  "geo" : { },
  "id_str" : "497842233828077569",
  "text" : "\u201COne Iraqi...cried to the world, 'There is no one coming to help.' Well today, America is coming to help.\" \u2014Obama: http:\/\/t.co\/MZjda4aWyO",
  "id" : 497842233828077569,
  "created_at" : "2014-08-08 20:30:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/497834737507893248\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/NXfpaRWd6e",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BuicMh6IYAE0Nei.jpg",
      "id_str" : "497819497898991617",
      "id" : 497819497898991617,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BuicMh6IYAE0Nei.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/NXfpaRWd6e"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/PihQFGRmAK",
      "expanded_url" : "http:\/\/go.wh.gov\/V6Fv2L",
      "display_url" : "go.wh.gov\/V6Fv2L"
    } ]
  },
  "geo" : { },
  "id_str" : "497834737507893248",
  "text" : "\"American combat troops will not be returning to fight in Iraq.\" \u2014President Obama: http:\/\/t.co\/PihQFGRmAK http:\/\/t.co\/NXfpaRWd6e",
  "id" : 497834737507893248,
  "created_at" : "2014-08-08 20:00:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/MZjda4aWyO",
      "expanded_url" : "http:\/\/youtu.be\/ax4a6cH1Wjs",
      "display_url" : "youtu.be\/ax4a6cH1Wjs"
    } ]
  },
  "geo" : { },
  "id_str" : "497827124816801792",
  "text" : "Last night, President Obama delivered a statement on the situation in Iraq from the State Dining Room. Watch \u2192 http:\/\/t.co\/MZjda4aWyO",
  "id" : 497827124816801792,
  "created_at" : "2014-08-08 19:30:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/497817224607178752\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/UcX44bQ1Pp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BuiaILlIEAAwW6i.jpg",
      "id_str" : "497817224162578432",
      "id" : 497817224162578432,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BuiaILlIEAAwW6i.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/UcX44bQ1Pp"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/kfreIfBPAp",
      "expanded_url" : "http:\/\/go.wh.gov\/HKQ1fF",
      "display_url" : "go.wh.gov\/HKQ1fF"
    } ]
  },
  "geo" : { },
  "id_str" : "497817224607178752",
  "text" : "\"Tonight, we give thanks to our men and women in uniform.\" \u2014Obama making a statement on Iraq: http:\/\/t.co\/kfreIfBPAp http:\/\/t.co\/UcX44bQ1Pp",
  "id" : 497817224607178752,
  "created_at" : "2014-08-08 18:50:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Iraq",
      "indices" : [ 30, 35 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/seXS5U4rYE",
      "expanded_url" : "http:\/\/1.usa.gov\/1ssUSky",
      "display_url" : "1.usa.gov\/1ssUSky"
    } ]
  },
  "geo" : { },
  "id_str" : "497809301281730561",
  "text" : "RT @NSCPress: Questions about #Iraq? See the White House briefing from Senior Admin Officials last night: http:\/\/t.co\/seXS5U4rYE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Iraq",
        "indices" : [ 16, 21 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/seXS5U4rYE",
        "expanded_url" : "http:\/\/1.usa.gov\/1ssUSky",
        "display_url" : "1.usa.gov\/1ssUSky"
      } ]
    },
    "geo" : { },
    "id_str" : "497787196259454977",
    "text" : "Questions about #Iraq? See the White House briefing from Senior Admin Officials last night: http:\/\/t.co\/seXS5U4rYE",
    "id" : 497787196259454977,
    "created_at" : "2014-08-08 16:51:30 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 497809301281730561,
  "created_at" : "2014-08-08 18:19:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/xiYuRREw6j",
      "expanded_url" : "http:\/\/go.wh.gov\/PLjnGk",
      "display_url" : "go.wh.gov\/PLjnGk"
    } ]
  },
  "geo" : { },
  "id_str" : "497591790979923968",
  "text" : "\"There is no decision that I take more seriously than the use of military force.\" \u2014President Obama on Iraq: http:\/\/t.co\/xiYuRREw6j",
  "id" : 497591790979923968,
  "created_at" : "2014-08-08 03:55:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/tmGcv5PZwi",
      "expanded_url" : "http:\/\/go.wh.gov\/V6Fv2L",
      "display_url" : "go.wh.gov\/V6Fv2L"
    }, {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/WvOcI3hGj1",
      "expanded_url" : "http:\/\/youtu.be\/ax4a6cH1Wjs",
      "display_url" : "youtu.be\/ax4a6cH1Wjs"
    } ]
  },
  "geo" : { },
  "id_str" : "497582035100532736",
  "text" : "Tonight, the President spoke on the situation in Iraq.\nRead the transcript: http:\/\/t.co\/tmGcv5PZwi \nWatch the video: http:\/\/t.co\/WvOcI3hGj1",
  "id" : 497582035100532736,
  "created_at" : "2014-08-08 03:16:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "497578211170328576",
  "text" : "\"Today I authorized two operations in Iraq \u2014 targeted airstrikes to protect our American personnel, and a humanitarian effort\" \u2014Obama",
  "id" : 497578211170328576,
  "created_at" : "2014-08-08 03:01:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/WduJ3PTlFU",
      "expanded_url" : "http:\/\/go.wh.gov\/HjS3R9",
      "display_url" : "go.wh.gov\/HjS3R9"
    } ]
  },
  "geo" : { },
  "id_str" : "497573724921815042",
  "text" : "Tonight, President Obama delivered a statement on the situation in Iraq from the State Dining Room. Watch: http:\/\/t.co\/WduJ3PTlFU",
  "id" : 497573724921815042,
  "created_at" : "2014-08-08 02:43:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "497565491746316288",
  "text" : "RT @PressSec: POTUS: US military pilots &amp; personnel in Iraq are protecting Americans &amp; saving the lives of men\/women\/children that they wil\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "497564998189592576",
    "text" : "POTUS: US military pilots &amp; personnel in Iraq are protecting Americans &amp; saving the lives of men\/women\/children that they will never meet.",
    "id" : 497564998189592576,
    "created_at" : "2014-08-08 02:08:34 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 497565491746316288,
  "created_at" : "2014-08-08 02:10:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "497565475149451264",
  "text" : "RT @PressSec: POTUS: Even as we support Iraqis as they take the fight to these terrorists, American combat troops will not be returning to \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "497564133311528960",
    "text" : "POTUS: Even as we support Iraqis as they take the fight to these terrorists, American combat troops will not be returning to fight in Iraq.",
    "id" : 497564133311528960,
    "created_at" : "2014-08-08 02:05:08 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 497565475149451264,
  "created_at" : "2014-08-08 02:10:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "497565416852828161",
  "text" : "RT @PressSec: POTUS: As Commander-in-Chief, I will not allow the United States to be dragged into fighting another war in Iraq.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "497564244997468160",
    "text" : "POTUS: As Commander-in-Chief, I will not allow the United States to be dragged into fighting another war in Iraq.",
    "id" : 497564244997468160,
    "created_at" : "2014-08-08 02:05:34 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 497565416852828161,
  "created_at" : "2014-08-08 02:10:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "497564145131474944",
  "text" : "RT @PressSec: POTUS: Earlier this week, one Iraqi in the area cried to the world, \u201CThere is no one coming to help.\u201D Well today, America is \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "497563723460927488",
    "text" : "POTUS: Earlier this week, one Iraqi in the area cried to the world, \u201CThere is no one coming to help.\u201D Well today, America is coming to help.",
    "id" : 497563723460927488,
    "created_at" : "2014-08-08 02:03:30 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 497564145131474944,
  "created_at" : "2014-08-08 02:05:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Schultz",
      "screen_name" : "Schultz44",
      "indices" : [ 3, 13 ],
      "id_str" : "1603419038",
      "id" : 1603419038
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "497559210088210432",
  "text" : "RT @Schultz44: Pres Obama: \u201CWhen the lives of American citizens are at risk, we will take action. That is my responsibility as Commander-in\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "497557289709367296",
    "text" : "Pres Obama: \u201CWhen the lives of American citizens are at risk, we will take action. That is my responsibility as Commander-in-Chief.\u201D",
    "id" : 497557289709367296,
    "created_at" : "2014-08-08 01:37:56 +0000",
    "user" : {
      "name" : "Eric Schultz",
      "screen_name" : "Schultz44",
      "protected" : false,
      "id_str" : "1603419038",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/491941155815161856\/u0IdexM6_normal.jpeg",
      "id" : 1603419038,
      "verified" : true
    }
  },
  "id" : 497559210088210432,
  "created_at" : "2014-08-08 01:45:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/b4tqL3oo0v",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "497555032934715392",
  "text" : "At 9:30pm ET President Obama will deliver a statement on Iraq in the State Dining Room \u2192http:\/\/t.co\/b4tqL3oo0v",
  "id" : 497555032934715392,
  "created_at" : "2014-08-08 01:28:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/497514883475582977\/photo\/1",
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/vDJeYJOz9Z",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BueHJm7IYAAkYkV.jpg",
      "id_str" : "497514882984861696",
      "id" : 497514882984861696,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BueHJm7IYAAkYkV.jpg",
      "sizes" : [ {
        "h" : 409,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 698,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 232,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 2333,
        "resize" : "fit",
        "w" : 3422
      } ],
      "display_url" : "pic.twitter.com\/vDJeYJOz9Z"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "497514883475582977",
  "text" : "President Obama meets with his national security team today in the Situation Room. http:\/\/t.co\/vDJeYJOz9Z",
  "id" : 497514883475582977,
  "created_at" : "2014-08-07 22:49:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/3qgBC2nQa4",
      "expanded_url" : "http:\/\/go.wh.gov\/Ua7ftf",
      "display_url" : "go.wh.gov\/Ua7ftf"
    } ]
  },
  "geo" : { },
  "id_str" : "497487871558041600",
  "text" : "Today, the President signed the VA reform bill to ensure veterans have access to the care they\u2019ve earned \u2192 http:\/\/t.co\/3qgBC2nQa4",
  "id" : 497487871558041600,
  "created_at" : "2014-08-07 21:02:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ONE",
      "screen_name" : "ONECampaign",
      "indices" : [ 88, 100 ],
      "id_str" : "16348549",
      "id" : 16348549
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "497442782240591875",
  "text" : "RT @NSCPress: Hi, everyone! Ned Price from the NSC here. Looking forward to joining the @ONECampaign in the Q&amp;A on US-Africa Ldrs Summit. #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ONE",
        "screen_name" : "ONECampaign",
        "indices" : [ 74, 86 ],
        "id_str" : "16348549",
        "id" : 16348549
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "USAfricaChat",
        "indices" : [ 128, 141 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "497442115769888768",
    "text" : "Hi, everyone! Ned Price from the NSC here. Looking forward to joining the @ONECampaign in the Q&amp;A on US-Africa Ldrs Summit. #USAfricaChat",
    "id" : 497442115769888768,
    "created_at" : "2014-08-07 18:00:17 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 497442782240591875,
  "created_at" : "2014-08-07 18:02:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/497417220784660480\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/clBd2jV8hB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BucuU5RIYAAze3n.png",
      "id_str" : "497417220352663552",
      "id" : 497417220352663552,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BucuU5RIYAAze3n.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 357,
        "resize" : "fit",
        "w" : 639
      }, {
        "h" : 190,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 335,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 357,
        "resize" : "fit",
        "w" : 639
      } ],
      "display_url" : "pic.twitter.com\/clBd2jV8hB"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "497417220784660480",
  "text" : "\"We are going to spend each and every day working to do right by you.\" \u2014Obama to the troops on signing the VA reform http:\/\/t.co\/clBd2jV8hB",
  "id" : 497417220784660480,
  "created_at" : "2014-08-07 16:21:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/497415628433924098\/photo\/1",
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/rWMH0Dw1Z1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bucs4NRIUAELgx-.png",
      "id_str" : "497415627993534465",
      "id" : 497415627993534465,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bucs4NRIUAELgx-.png",
      "sizes" : [ {
        "h" : 359,
        "resize" : "fit",
        "w" : 639
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 359,
        "resize" : "fit",
        "w" : 639
      } ],
      "display_url" : "pic.twitter.com\/rWMH0Dw1Z1"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "497415628433924098",
  "text" : "\"America has to do right by all who serve under our proud flag.\" \u2014President Obama http:\/\/t.co\/rWMH0Dw1Z1",
  "id" : 497415628433924098,
  "created_at" : "2014-08-07 16:15:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "497415527124713473",
  "text" : "RT @JoiningForces: \"We\u2019ve cut the disability claims backlog by more than half \u2013 now let\u2019s eliminate the backlog.\" - President Obama",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "497415170164260864",
    "text" : "\"We\u2019ve cut the disability claims backlog by more than half \u2013 now let\u2019s eliminate the backlog.\" - President Obama",
    "id" : 497415170164260864,
    "created_at" : "2014-08-07 16:13:12 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 497415527124713473,
  "created_at" : "2014-08-07 16:14:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "497415009799270400",
  "text" : "RT @WHLive: \"'To care for him, or her, who shall have borne the battle.' That\u2019s the heart of the VA\u2019s motto.\" \u2014President Obama quoting Pres\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "497414960218374144",
    "text" : "\"'To care for him, or her, who shall have borne the battle.' That\u2019s the heart of the VA\u2019s motto.\" \u2014President Obama quoting President Lincoln",
    "id" : 497414960218374144,
    "created_at" : "2014-08-07 16:12:22 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 497415009799270400,
  "created_at" : "2014-08-07 16:12:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Veterans Affairs",
      "screen_name" : "DeptVetAffairs",
      "indices" : [ 112, 127 ],
      "id_str" : "78408666",
      "id" : 78408666
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "497414415541895169",
  "text" : "\"This bill will help us ensure that veterans have access to the care they have earned.\" \u2014President Obama on the @DeptVetAffairs reform bill",
  "id" : 497414415541895169,
  "created_at" : "2014-08-07 16:10:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "497413736811212800",
  "text" : "\"As a country, we have a sacred obligation to serve you as well as you\u2019ve served us.\" \u2014President Obama to the troops at Fort Belvoir",
  "id" : 497413736811212800,
  "created_at" : "2014-08-07 16:07:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Veterans Affairs",
      "screen_name" : "DeptVetAffairs",
      "indices" : [ 91, 106 ],
      "id_str" : "78408666",
      "id" : 78408666
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "497412911586086912",
  "text" : "RT @WHLive: Watch: President Obama heads to Fort Belvoir, Virginia, to sign the bipartisan @DeptVetAffairs reform bill \u2192 http:\/\/t.co\/XLhcoq\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Veterans Affairs",
        "screen_name" : "DeptVetAffairs",
        "indices" : [ 79, 94 ],
        "id_str" : "78408666",
        "id" : 78408666
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/XLhcoqMPWC",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "497412829239328768",
    "text" : "Watch: President Obama heads to Fort Belvoir, Virginia, to sign the bipartisan @DeptVetAffairs reform bill \u2192 http:\/\/t.co\/XLhcoqMPWC",
    "id" : 497412829239328768,
    "created_at" : "2014-08-07 16:03:54 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 497412911586086912,
  "created_at" : "2014-08-07 16:04:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Veterans Affairs",
      "screen_name" : "DeptVetAffairs",
      "indices" : [ 60, 75 ],
      "id_str" : "78408666",
      "id" : 78408666
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/b4tqL3oo0v",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "497398078933311489",
  "text" : "Tune in at 11:20am ET: President Obama signs the bipartisan @DeptVetAffairs reform bill at Fort Belvoir. Watch \u2192 http:\/\/t.co\/b4tqL3oo0v",
  "id" : 497398078933311489,
  "created_at" : "2014-08-07 15:05:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Becky Hammon",
      "screen_name" : "BeckyHammon",
      "indices" : [ 3, 15 ],
      "id_str" : "376759677",
      "id" : 376759677
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 121, 132 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BO",
      "indices" : [ 93, 96 ]
    }, {
      "text" : "POTUS",
      "indices" : [ 97, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "497205848712962048",
  "text" : "RT @BeckyHammon: WOW!! Thank you Mr. President! I didn't think this could get any cooler but #BO #POTUS just tweeted me! @WhiteHouse #thats\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 104, 115 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BO",
        "indices" : [ 76, 79 ]
      }, {
        "text" : "POTUS",
        "indices" : [ 80, 86 ]
      }, {
        "text" : "thatscrazycool",
        "indices" : [ 116, 131 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "497184377038995457",
    "text" : "WOW!! Thank you Mr. President! I didn't think this could get any cooler but #BO #POTUS just tweeted me! @WhiteHouse #thatscrazycool O_O",
    "id" : 497184377038995457,
    "created_at" : "2014-08-07 00:56:07 +0000",
    "user" : {
      "name" : "Becky Hammon",
      "screen_name" : "BeckyHammon",
      "protected" : false,
      "id_str" : "376759677",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/720280336094072832\/fptfgWnB_normal.jpg",
      "id" : 376759677,
      "verified" : true
    }
  },
  "id" : 497205848712962048,
  "created_at" : "2014-08-07 02:21:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Becky Hammon",
      "screen_name" : "BeckyHammon",
      "indices" : [ 12, 24 ],
      "id_str" : "376759677",
      "id" : 376759677
    }, {
      "name" : "NBA",
      "screen_name" : "NBA",
      "indices" : [ 26, 30 ],
      "id_str" : "19923144",
      "id" : 19923144
    }, {
      "name" : "San Antonio Spurs",
      "screen_name" : "spurs",
      "indices" : [ 118, 124 ],
      "id_str" : "18371803",
      "id" : 18371803
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WomenSucceed",
      "indices" : [ 68, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "497177142837264384",
  "text" : "Congrats to @BeckyHammon, @NBA's first full-time female coach. When #WomenSucceed, America succeeds \u2014 and we know the @Spurs will, too. -bo",
  "id" : 497177142837264384,
  "created_at" : "2014-08-07 00:27:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "USAfrica",
      "indices" : [ 115, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "497145521065435136",
  "text" : "\"Africa must know that they will always have a strong and reliable partner in the United States.\" \u2014President Obama #USAfrica",
  "id" : 497145521065435136,
  "created_at" : "2014-08-06 22:21:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "USAfrica",
      "indices" : [ 42, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/DifhyCDEEA",
      "expanded_url" : "http:\/\/go.wh.gov\/8cHgDM",
      "display_url" : "go.wh.gov\/8cHgDM"
    } ]
  },
  "geo" : { },
  "id_str" : "497143631015596032",
  "text" : "Happening now: President Obama closes the #USAfrica Leaders Summit, the first-ever event of its kind \u2192 http:\/\/t.co\/DifhyCDEEA",
  "id" : 497143631015596032,
  "created_at" : "2014-08-06 22:14:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "USAfrica",
      "indices" : [ 53, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/DifhyCDEEA",
      "expanded_url" : "http:\/\/go.wh.gov\/8cHgDM",
      "display_url" : "go.wh.gov\/8cHgDM"
    } ]
  },
  "geo" : { },
  "id_str" : "497086047441133569",
  "text" : "Tune in at 2:30pm ET: President Obama talks with the #USAfrica leaders about governing the next generation \u2192 http:\/\/t.co\/DifhyCDEEA",
  "id" : 497086047441133569,
  "created_at" : "2014-08-06 18:25:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "USAfrica",
      "indices" : [ 129, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "497025087426809856",
  "text" : "Obama: \"We\u2019re here to take action\u2014concrete steps to build on Africa\u2019s progress and forge the partnership of equals that we seek\" #USAfrica",
  "id" : 497025087426809856,
  "created_at" : "2014-08-06 14:23:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "USAfrica",
      "indices" : [ 130, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "497024055497998336",
  "text" : "\"We have come together this week because\u2014even as the continent faces great challenges\u2014a new Africa is emerging.\" \u2014President Obama #USAfrica",
  "id" : 497024055497998336,
  "created_at" : "2014-08-06 14:19:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "USAfrica",
      "indices" : [ 89, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/7g7L7oDU4r",
      "expanded_url" : "http:\/\/go.wh.gov\/8cHgDM",
      "display_url" : "go.wh.gov\/8cHgDM"
    } ]
  },
  "geo" : { },
  "id_str" : "497023717915262978",
  "text" : "RT @WHLive: Happening now: President Obama speaks on investing in Africa\u2019s future at the #USAfrica Summit \u2192 http:\/\/t.co\/7g7L7oDU4r",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "USAfrica",
        "indices" : [ 77, 86 ]
      } ],
      "urls" : [ {
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/7g7L7oDU4r",
        "expanded_url" : "http:\/\/go.wh.gov\/8cHgDM",
        "display_url" : "go.wh.gov\/8cHgDM"
      } ]
    },
    "geo" : { },
    "id_str" : "497023693202419712",
    "text" : "Happening now: President Obama speaks on investing in Africa\u2019s future at the #USAfrica Summit \u2192 http:\/\/t.co\/7g7L7oDU4r",
    "id" : 497023693202419712,
    "created_at" : "2014-08-06 14:17:37 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 497023717915262978,
  "created_at" : "2014-08-06 14:17:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "indices" : [ 3, 13 ],
      "id_str" : "15007149",
      "id" : 15007149
    }, {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 84, 94 ],
      "id_str" : "9624742",
      "id" : 9624742
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/JohnKerry\/status\/497017003396562944\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/KQSZ8PojbE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BuXCVKjCUAA3vRE.jpg",
      "id_str" : "497017002758656000",
      "id" : 497017002758656000,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BuXCVKjCUAA3vRE.jpg",
      "sizes" : [ {
        "h" : 563,
        "resize" : "fit",
        "w" : 563
      }, {
        "h" : 563,
        "resize" : "fit",
        "w" : 563
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 563,
        "resize" : "fit",
        "w" : 563
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/KQSZ8PojbE"
    } ],
    "hashtags" : [ {
      "text" : "African",
      "indices" : [ 60, 68 ]
    }, {
      "text" : "USAfrica",
      "indices" : [ 102, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "497023125146853377",
  "text" : "RT @JohnKerry: Joining with President Obama in welcoming 51 #African leaders to the @StateDept today. #USAfrica http:\/\/t.co\/KQSZ8PojbE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Department of State",
        "screen_name" : "StateDept",
        "indices" : [ 69, 79 ],
        "id_str" : "9624742",
        "id" : 9624742
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JohnKerry\/status\/497017003396562944\/photo\/1",
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/KQSZ8PojbE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BuXCVKjCUAA3vRE.jpg",
        "id_str" : "497017002758656000",
        "id" : 497017002758656000,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BuXCVKjCUAA3vRE.jpg",
        "sizes" : [ {
          "h" : 563,
          "resize" : "fit",
          "w" : 563
        }, {
          "h" : 563,
          "resize" : "fit",
          "w" : 563
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 563,
          "resize" : "fit",
          "w" : 563
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/KQSZ8PojbE"
      } ],
      "hashtags" : [ {
        "text" : "African",
        "indices" : [ 45, 53 ]
      }, {
        "text" : "USAfrica",
        "indices" : [ 87, 96 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "497017003396562944",
    "text" : "Joining with President Obama in welcoming 51 #African leaders to the @StateDept today. #USAfrica http:\/\/t.co\/KQSZ8PojbE",
    "id" : 497017003396562944,
    "created_at" : "2014-08-06 13:51:02 +0000",
    "user" : {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "protected" : false,
      "id_str" : "15007149",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/482149339842617346\/l6b7LXjb_normal.jpeg",
      "id" : 15007149,
      "verified" : true
    }
  },
  "id" : 497023125146853377,
  "created_at" : "2014-08-06 14:15:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "USAfrica",
      "indices" : [ 99, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/DifhyCDEEA",
      "expanded_url" : "http:\/\/go.wh.gov\/8cHgDM",
      "display_url" : "go.wh.gov\/8cHgDM"
    } ]
  },
  "geo" : { },
  "id_str" : "497021678615293952",
  "text" : "Starting soon: President Obama participates in conversation on investing in Africa\u2019s future at the #USAfrica Summit\u2192 http:\/\/t.co\/DifhyCDEEA",
  "id" : 497021678615293952,
  "created_at" : "2014-08-06 14:09:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 35, 42 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "USAfrica",
      "indices" : [ 84, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/b4tqL3oo0v",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "496831417050230784",
  "text" : "Happening now: President Obama and @FLOTUS host a dinner at the White House for the #USAfrica Leaders Summit: http:\/\/t.co\/b4tqL3oo0v",
  "id" : 496831417050230784,
  "created_at" : "2014-08-06 01:33:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 131, 144 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/tg196Ytrm8",
      "expanded_url" : "http:\/\/youtu.be\/hDsNq-rVplE",
      "display_url" : "youtu.be\/hDsNq-rVplE"
    } ]
  },
  "geo" : { },
  "id_str" : "496807950921367553",
  "text" : "Got 3 minutes? Learn why the cost of inaction on wildfires &amp; climate change is too high for us to pay \u2192 http:\/\/t.co\/tg196Ytrm8 #ActOnClimate",
  "id" : 496807950921367553,
  "created_at" : "2014-08-06 00:00:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil Larson",
      "screen_name" : "Phil44",
      "indices" : [ 3, 10 ],
      "id_str" : "2525192749",
      "id" : 2525192749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "496783137423126529",
  "text" : "RT @Phil44: Climate change impacts on wildfires explained by the President's science advisor John Holdren in under 3 minutes \u2192 https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/BwdHN6Y8Kr",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=hDsNq-rVplE",
        "display_url" : "youtube.com\/watch?v=hDsNq-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "496677091820441602",
    "text" : "Climate change impacts on wildfires explained by the President's science advisor John Holdren in under 3 minutes \u2192 https:\/\/t.co\/BwdHN6Y8Kr",
    "id" : 496677091820441602,
    "created_at" : "2014-08-05 15:20:21 +0000",
    "user" : {
      "name" : "Phil Larson",
      "screen_name" : "Phil44",
      "protected" : false,
      "id_str" : "2525192749",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/470938302095183874\/eFAyUNAe_normal.jpeg",
      "id" : 2525192749,
      "verified" : true
    }
  },
  "id" : 496783137423126529,
  "created_at" : "2014-08-05 22:21:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 105, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "496749003401617409",
  "text" : "\u201CWe are interested in Africa because we know that if Africa thrives and succeeds\u2026all of us grow.\u201D \u2014Obama #OpportunityForAll",
  "id" : 496749003401617409,
  "created_at" : "2014-08-05 20:06:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WHLive\/status\/496745806247260160\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/9xJFwzjVgz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BuTLraaIUAA7eg4.png",
      "id_str" : "496745805601329152",
      "id" : 496745805601329152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BuTLraaIUAA7eg4.png",
      "sizes" : [ {
        "h" : 358,
        "resize" : "fit",
        "w" : 642
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 335,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 190,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 358,
        "resize" : "fit",
        "w" : 642
      } ],
      "display_url" : "pic.twitter.com\/9xJFwzjVgz"
    } ],
    "hashtags" : [ {
      "text" : "USAfricaBizForum",
      "indices" : [ 99, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "496745917425668096",
  "text" : "RT @WHLive: \u201CThe reason the internet is so powerful is because it\u2019s open.\u201D \u2014President Obama to the #USAfricaBizForum http:\/\/t.co\/9xJFwzjVgz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WHLive\/status\/496745806247260160\/photo\/1",
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/9xJFwzjVgz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BuTLraaIUAA7eg4.png",
        "id_str" : "496745805601329152",
        "id" : 496745805601329152,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BuTLraaIUAA7eg4.png",
        "sizes" : [ {
          "h" : 358,
          "resize" : "fit",
          "w" : 642
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 335,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 190,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 358,
          "resize" : "fit",
          "w" : 642
        } ],
        "display_url" : "pic.twitter.com\/9xJFwzjVgz"
      } ],
      "hashtags" : [ {
        "text" : "USAfricaBizForum",
        "indices" : [ 87, 104 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "496745806247260160",
    "text" : "\u201CThe reason the internet is so powerful is because it\u2019s open.\u201D \u2014President Obama to the #USAfricaBizForum http:\/\/t.co\/9xJFwzjVgz",
    "id" : 496745806247260160,
    "created_at" : "2014-08-05 19:53:23 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 496745917425668096,
  "created_at" : "2014-08-05 19:53:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/496742272869089281\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/ZFDYDujnZJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BuTIdvxIgAAyoEL.png",
      "id_str" : "496742272281903104",
      "id" : 496742272281903104,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BuTIdvxIgAAyoEL.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 358,
        "resize" : "fit",
        "w" : 641
      }, {
        "h" : 358,
        "resize" : "fit",
        "w" : 641
      }, {
        "h" : 190,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 335,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/ZFDYDujnZJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "496742272869089281",
  "text" : "\"A long-term partnership with Africa...that\u2019s what America offers, that\u2019s what we\u2019re building.\" \u2014President Obama http:\/\/t.co\/ZFDYDujnZJ",
  "id" : 496742272869089281,
  "created_at" : "2014-08-05 19:39:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "496740998836670465",
  "text" : "\"The bottom line is\u2014the US is making a major and long-term investment in Africa\u2019s progress.\" \u2014Obama on the $33b in new commitments to Africa",
  "id" : 496740998836670465,
  "created_at" : "2014-08-05 19:34:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "USAfricaSummit",
      "indices" : [ 110, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "496740275503763456",
  "text" : "RT @vj44: \"We need more Africans\u2014including women and small businesses\u2014getting their goods to market.\" - POTUS #USAfricaSummit http:\/\/t.co\/M\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/496740139482513408\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/M5PDJYOwBO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BuTGhghCYAI2dAC.jpg",
        "id_str" : "496740137884082178",
        "id" : 496740137884082178,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BuTGhghCYAI2dAC.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/M5PDJYOwBO"
      } ],
      "hashtags" : [ {
        "text" : "USAfricaSummit",
        "indices" : [ 100, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "496740139482513408",
    "text" : "\"We need more Africans\u2014including women and small businesses\u2014getting their goods to market.\" - POTUS #USAfricaSummit http:\/\/t.co\/M5PDJYOwBO",
    "id" : 496740139482513408,
    "created_at" : "2014-08-05 19:30:52 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 496740275503763456,
  "created_at" : "2014-08-05 19:31:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/496739832992116737\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/QsjJD72RVN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BuTGPu8IgAA8ekU.png",
      "id_str" : "496739832518180864",
      "id" : 496739832518180864,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BuTGPu8IgAA8ekU.png",
      "sizes" : [ {
        "h" : 334,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 189,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 356,
        "resize" : "fit",
        "w" : 639
      }, {
        "h" : 356,
        "resize" : "fit",
        "w" : 639
      } ],
      "display_url" : "pic.twitter.com\/QsjJD72RVN"
    } ],
    "hashtags" : [ {
      "text" : "USAfricaBizForum",
      "indices" : [ 100, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "496739832992116737",
  "text" : "\"We recognize Africa for its greatest resource\u2014its people, and its talents, their potential\" \u2014Obama #USAfricaBizForum http:\/\/t.co\/QsjJD72RVN",
  "id" : 496739832992116737,
  "created_at" : "2014-08-05 19:29:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "USAfricaBizForum",
      "indices" : [ 121, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "496738164976123904",
  "text" : "\"A secure, prosperous and self-reliant Africa is in the national interest of the United States.\" \u2014President Obama at the #USAfricaBizForum",
  "id" : 496738164976123904,
  "created_at" : "2014-08-05 19:23:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "USAfricaBizForum",
      "indices" : [ 57, 74 ]
    }, {
      "text" : "USAfrica",
      "indices" : [ 99, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "496737676662681601",
  "text" : "RT @WHLive: Happening now: President Obama speaks to the #USAfricaBizForum on building a long-term #USAfrica partnership \u2192 http:\/\/t.co\/XLhc\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "USAfricaBizForum",
        "indices" : [ 45, 62 ]
      }, {
        "text" : "USAfrica",
        "indices" : [ 87, 96 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/XLhcoqMPWC",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "496737597050593280",
    "text" : "Happening now: President Obama speaks to the #USAfricaBizForum on building a long-term #USAfrica partnership \u2192 http:\/\/t.co\/XLhcoqMPWC",
    "id" : 496737597050593280,
    "created_at" : "2014-08-05 19:20:46 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 496737676662681601,
  "created_at" : "2014-08-05 19:21:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/VP\/status\/496722085537124353\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/XT9eDoprNe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BuS2Gp0IQAAhXC5.png",
      "id_str" : "496722084337565696",
      "id" : 496722084337565696,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BuS2Gp0IQAAhXC5.png",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 358,
        "resize" : "fit",
        "w" : 637
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 358,
        "resize" : "fit",
        "w" : 637
      } ],
      "display_url" : "pic.twitter.com\/XT9eDoprNe"
    } ],
    "hashtags" : [ {
      "text" : "USAfrica",
      "indices" : [ 90, 99 ]
    }, {
      "text" : "USAfricaBizForum",
      "indices" : [ 100, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "496723642190135298",
  "text" : "RT @VP: \"The potential around the world \u2013 particularly in Africa \u2013 is immense.\" -VP Biden #USAfrica #USAfricaBizForum http:\/\/t.co\/XT9eDoprNe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/496722085537124353\/photo\/1",
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/XT9eDoprNe",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BuS2Gp0IQAAhXC5.png",
        "id_str" : "496722084337565696",
        "id" : 496722084337565696,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BuS2Gp0IQAAhXC5.png",
        "sizes" : [ {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 358,
          "resize" : "fit",
          "w" : 637
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 358,
          "resize" : "fit",
          "w" : 637
        } ],
        "display_url" : "pic.twitter.com\/XT9eDoprNe"
      } ],
      "hashtags" : [ {
        "text" : "USAfrica",
        "indices" : [ 82, 91 ]
      }, {
        "text" : "USAfricaBizForum",
        "indices" : [ 92, 109 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "496722085537124353",
    "text" : "\"The potential around the world \u2013 particularly in Africa \u2013 is immense.\" -VP Biden #USAfrica #USAfricaBizForum http:\/\/t.co\/XT9eDoprNe",
    "id" : 496722085537124353,
    "created_at" : "2014-08-05 18:19:08 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 496723642190135298,
  "created_at" : "2014-08-05 18:25:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "USAfrica",
      "indices" : [ 115, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "496721103503753216",
  "text" : "RT @VP: \"It\u2019s no surprise that 400,000 new companies were registered last year in Africa. That\u2019s a big deal.\" - VP #USAfrica http:\/\/t.co\/yy\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/496720518801002497\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/yygezLTj3n",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BuS0rbcCUAEKBTW.png",
        "id_str" : "496720517110321153",
        "id" : 496720517110321153,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BuS0rbcCUAEKBTW.png",
        "sizes" : [ {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 359,
          "resize" : "fit",
          "w" : 638
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 359,
          "resize" : "fit",
          "w" : 638
        } ],
        "display_url" : "pic.twitter.com\/yygezLTj3n"
      } ],
      "hashtags" : [ {
        "text" : "USAfrica",
        "indices" : [ 107, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "496720518801002497",
    "text" : "\"It\u2019s no surprise that 400,000 new companies were registered last year in Africa. That\u2019s a big deal.\" - VP #USAfrica http:\/\/t.co\/yygezLTj3n",
    "id" : 496720518801002497,
    "created_at" : "2014-08-05 18:12:54 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 496721103503753216,
  "created_at" : "2014-08-05 18:15:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "496720670567718912",
  "text" : "RT @VP: \"Africa possesses two incredible resources: an overwhelming abundance of natural resources and the resource of its people.\" -VP #US\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "USAfrica",
        "indices" : [ 128, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "496717503985614849",
    "text" : "\"Africa possesses two incredible resources: an overwhelming abundance of natural resources and the resource of its people.\" -VP #USAfrica",
    "id" : 496717503985614849,
    "created_at" : "2014-08-05 18:00:56 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 496720670567718912,
  "created_at" : "2014-08-05 18:13:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "USAfricaBizForum",
      "indices" : [ 50, 67 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/LodgROp9ha",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
      "display_url" : "whitehouse.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "496716347272093696",
  "text" : "RT @VP: Watch as VP Biden delivers remarks at the #USAfricaBizForum \u2192 http:\/\/t.co\/LodgROp9ha",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "USAfricaBizForum",
        "indices" : [ 42, 59 ]
      } ],
      "urls" : [ {
        "indices" : [ 62, 84 ],
        "url" : "http:\/\/t.co\/LodgROp9ha",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
        "display_url" : "whitehouse.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "496716313654722560",
    "text" : "Watch as VP Biden delivers remarks at the #USAfricaBizForum \u2192 http:\/\/t.co\/LodgROp9ha",
    "id" : 496716313654722560,
    "created_at" : "2014-08-05 17:56:12 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 496716347272093696,
  "created_at" : "2014-08-05 17:56:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Becky Hammon",
      "screen_name" : "BeckyHammon",
      "indices" : [ 29, 41 ],
      "id_str" : "376759677",
      "id" : 376759677
    }, {
      "name" : "NBA",
      "screen_name" : "NBA",
      "indices" : [ 61, 65 ],
      "id_str" : "19923144",
      "id" : 19923144
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GirlPower",
      "indices" : [ 121, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/eqxgr5t0da",
      "expanded_url" : "http:\/\/wapo.st\/US0rOq",
      "display_url" : "wapo.st\/US0rOq"
    } ]
  },
  "geo" : { },
  "id_str" : "496716063095402496",
  "text" : "RT @vj44: Congratulations to @BeckyHammon on being named the @NBA's first female assistant coach! http:\/\/t.co\/eqxgr5t0da #GirlPower",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Becky Hammon",
        "screen_name" : "BeckyHammon",
        "indices" : [ 19, 31 ],
        "id_str" : "376759677",
        "id" : 376759677
      }, {
        "name" : "NBA",
        "screen_name" : "NBA",
        "indices" : [ 51, 55 ],
        "id_str" : "19923144",
        "id" : 19923144
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GirlPower",
        "indices" : [ 111, 121 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/eqxgr5t0da",
        "expanded_url" : "http:\/\/wapo.st\/US0rOq",
        "display_url" : "wapo.st\/US0rOq"
      } ]
    },
    "geo" : { },
    "id_str" : "496714370223575040",
    "text" : "Congratulations to @BeckyHammon on being named the @NBA's first female assistant coach! http:\/\/t.co\/eqxgr5t0da #GirlPower",
    "id" : 496714370223575040,
    "created_at" : "2014-08-05 17:48:29 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 496716063095402496,
  "created_at" : "2014-08-05 17:55:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 102, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/wl1ZhQfLRL",
      "expanded_url" : "http:\/\/youtu.be\/hDsNq-rVplE",
      "display_url" : "youtu.be\/hDsNq-rVplE"
    } ]
  },
  "geo" : { },
  "id_str" : "496684847667355648",
  "text" : "Climate change is making fire season longer and on average more intense. RT if you agree it's time to #ActOnClimate \u2192 http:\/\/t.co\/wl1ZhQfLRL",
  "id" : 496684847667355648,
  "created_at" : "2014-08-05 15:51:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "McClatchyDC",
      "screen_name" : "McClatchyDC",
      "indices" : [ 32, 44 ],
      "id_str" : "17487795",
      "id" : 17487795
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/4inUc6Mzh1",
      "expanded_url" : "http:\/\/bit.ly\/1pVDOks",
      "display_url" : "bit.ly\/1pVDOks"
    } ]
  },
  "geo" : { },
  "id_str" : "496663015786160129",
  "text" : "Worth a read: President Obama's @McClatchyDC op-ed \u201CWe have a moral obligation to support Africa\u2019s progress\u201D \u2192 http:\/\/t.co\/4inUc6Mzh1",
  "id" : 496663015786160129,
  "created_at" : "2014-08-05 14:24:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Penny Pritzker",
      "screen_name" : "PennyPritzker",
      "indices" : [ 3, 17 ],
      "id_str" : "308573576",
      "id" : 308573576
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "USAfricaBizForum",
      "indices" : [ 27, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "496651828080418816",
  "text" : "RT @PennyPritzker: Today\u2019s #USAfricaBizForum will catalyze $14 BILLION in biz deals w\/ benefits in both directions across the Atlantic. htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "USAfricaBizForum",
        "indices" : [ 8, 25 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/rYOJdjpEnd",
        "expanded_url" : "http:\/\/www.forbes.com\/sites\/realspin\/2014\/08\/05\/obamas-u-s-africa-forum-will-catalyze-14-billion-in-business-deals\/",
        "display_url" : "forbes.com\/sites\/realspin\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "496607647710576640",
    "text" : "Today\u2019s #USAfricaBizForum will catalyze $14 BILLION in biz deals w\/ benefits in both directions across the Atlantic. http:\/\/t.co\/rYOJdjpEnd",
    "id" : 496607647710576640,
    "created_at" : "2014-08-05 10:44:24 +0000",
    "user" : {
      "name" : "Penny Pritzker",
      "screen_name" : "PennyPritzker",
      "protected" : false,
      "id_str" : "308573576",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000260306047\/1faea5d057983d2f15a31efc6b696ab5_normal.jpeg",
      "id" : 308573576,
      "verified" : true
    }
  },
  "id" : 496651828080418816,
  "created_at" : "2014-08-05 13:39:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/496449410063007744\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/PTR6WQQczn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BuO0GqzIAAEV7Qp.jpg",
      "id_str" : "496438410601824257",
      "id" : 496438410601824257,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BuO0GqzIAAEV7Qp.jpg",
      "sizes" : [ {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 520
      } ],
      "display_url" : "pic.twitter.com\/PTR6WQQczn"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/CgIonazsyY",
      "expanded_url" : "http:\/\/go.wh.gov\/Dqj7iK",
      "display_url" : "go.wh.gov\/Dqj7iK"
    } ]
  },
  "geo" : { },
  "id_str" : "496449410063007744",
  "text" : "Happy Birthday, President Obama! See some of our favorite photos from the past year \u2192 http:\/\/t.co\/CgIonazsyY http:\/\/t.co\/PTR6WQQczn",
  "id" : 496449410063007744,
  "created_at" : "2014-08-05 00:15:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "496426611915231232",
  "text" : "RT @PressSec: Joint statement from me &amp; many of my fellow PressSec's notes that Jim Brady \"set the model and the standard for the rest of u\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "496418681761456129",
    "text" : "Joint statement from me &amp; many of my fellow PressSec's notes that Jim Brady \"set the model and the standard for the rest of us to follow\".",
    "id" : 496418681761456129,
    "created_at" : "2014-08-04 22:13:31 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 496426611915231232,
  "created_at" : "2014-08-04 22:45:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/496392064566034432\/photo\/1",
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/2dLhd0Iijb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BuOJ88yIgAABqR9.png",
      "id_str" : "496392064142442496",
      "id" : 496392064142442496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BuOJ88yIgAABqR9.png",
      "sizes" : [ {
        "h" : 274,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 483,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 564,
        "resize" : "fit",
        "w" : 701
      }, {
        "h" : 564,
        "resize" : "fit",
        "w" : 701
      } ],
      "display_url" : "pic.twitter.com\/2dLhd0Iijb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "496392064566034432",
  "text" : "President Obama\u2019s statement on the passing of former White House Press Secretary James Brady: http:\/\/t.co\/2dLhd0Iijb",
  "id" : 496392064566034432,
  "created_at" : "2014-08-04 20:27:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CDC",
      "screen_name" : "CDCgov",
      "indices" : [ 3, 10 ],
      "id_str" : "146569971",
      "id" : 146569971
    }, {
      "name" : "CDC",
      "screen_name" : "CDCgov",
      "indices" : [ 46, 53 ],
      "id_str" : "146569971",
      "id" : 146569971
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 33, 39 ]
    }, {
      "text" : "CDCchat",
      "indices" : [ 85, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "496361357156315136",
  "text" : "RT @CDCgov: Have questions about #Ebola? Join @CDCgov disease detectives for special #CDCchat TODAY, 8\/4, 4-5PM ET.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CDC",
        "screen_name" : "CDCgov",
        "indices" : [ 34, 41 ],
        "id_str" : "146569971",
        "id" : 146569971
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Ebola",
        "indices" : [ 21, 27 ]
      }, {
        "text" : "CDCchat",
        "indices" : [ 73, 81 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "496305898084913152",
    "text" : "Have questions about #Ebola? Join @CDCgov disease detectives for special #CDCchat TODAY, 8\/4, 4-5PM ET.",
    "id" : 496305898084913152,
    "created_at" : "2014-08-04 14:45:21 +0000",
    "user" : {
      "name" : "CDC",
      "screen_name" : "CDCgov",
      "protected" : false,
      "id_str" : "146569971",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/748879958538321920\/iPUVbyKu_normal.jpg",
      "id" : 146569971,
      "verified" : true
    }
  },
  "id" : 496361357156315136,
  "created_at" : "2014-08-04 18:25:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "USAfrica",
      "indices" : [ 94, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "496330362403168257",
  "text" : "RT @VP: Happening now: VP Biden speaks to the heads of state and government at the first-ever #USAfrica Leaders Summit \u2192 http:\/\/t.co\/skR0Wd\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "USAfrica",
        "indices" : [ 86, 95 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/skR0Wdm8v1",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "496330321957494785",
    "text" : "Happening now: VP Biden speaks to the heads of state and government at the first-ever #USAfrica Leaders Summit \u2192 http:\/\/t.co\/skR0Wdm8v1",
    "id" : 496330321957494785,
    "created_at" : "2014-08-04 16:22:24 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 496330362403168257,
  "created_at" : "2014-08-04 16:22:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "indices" : [ 6, 21 ],
      "id_str" : "19674502",
      "id" : 19674502
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "USAfrica",
      "indices" : [ 53, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/JeODEfGErw",
      "expanded_url" : "http:\/\/youtu.be\/6S9O1q-xZ40",
      "display_url" : "youtu.be\/6S9O1q-xZ40"
    } ]
  },
  "geo" : { },
  "id_str" : "496323706617356288",
  "text" : "Watch @AmbassadorRice preview this week's first-ever #USAfrica Leaders Summit on investing in the next generation \u2192 http:\/\/t.co\/JeODEfGErw",
  "id" : 496323706617356288,
  "created_at" : "2014-08-04 15:56:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CDC NCEZID",
      "screen_name" : "CDC_NCEZID",
      "indices" : [ 3, 14 ],
      "id_str" : "1262167370",
      "id" : 1262167370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/hpmzWVHIvk",
      "expanded_url" : "http:\/\/www.cdc.gov\/vhf\/ebola\/pdf\/infographic.pdf",
      "display_url" : "cdc.gov\/vhf\/ebola\/pdf\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "496089153072009216",
  "text" : "RT @CDC_NCEZID: Facts about Ebola: You can\u2019t get Ebola through air, water, or food. Learn more: http:\/\/t.co\/hpmzWVHIvk http:\/\/t.co\/mIVGE8ym\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/CDC_NCEZID\/status\/496048056224456704\/photo\/1",
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/mIVGE8ymPx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BuJRE-ECAAEPh6j.jpg",
        "id_str" : "496048054785409025",
        "id" : 496048054785409025,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BuJRE-ECAAEPh6j.jpg",
        "sizes" : [ {
          "h" : 690,
          "resize" : "fit",
          "w" : 520
        }, {
          "h" : 451,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 690,
          "resize" : "fit",
          "w" : 520
        }, {
          "h" : 690,
          "resize" : "fit",
          "w" : 520
        } ],
        "display_url" : "pic.twitter.com\/mIVGE8ymPx"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/hpmzWVHIvk",
        "expanded_url" : "http:\/\/www.cdc.gov\/vhf\/ebola\/pdf\/infographic.pdf",
        "display_url" : "cdc.gov\/vhf\/ebola\/pdf\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "496048056224456704",
    "text" : "Facts about Ebola: You can\u2019t get Ebola through air, water, or food. Learn more: http:\/\/t.co\/hpmzWVHIvk http:\/\/t.co\/mIVGE8ymPx",
    "id" : 496048056224456704,
    "created_at" : "2014-08-03 21:40:47 +0000",
    "user" : {
      "name" : "CDC NCEZID",
      "screen_name" : "CDC_NCEZID",
      "protected" : false,
      "id_str" : "1262167370",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623934910215000064\/nMWJpYY6_normal.jpg",
      "id" : 1262167370,
      "verified" : true
    }
  },
  "id" : 496089153072009216,
  "created_at" : "2014-08-04 00:24:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/e3MEXLUFhv",
      "expanded_url" : "http:\/\/go.wh.gov\/CaAf8f",
      "display_url" : "go.wh.gov\/CaAf8f"
    } ]
  },
  "geo" : { },
  "id_str" : "496037878657331200",
  "text" : "\"My top priority as President is doing everything I can to create more jobs...for hardworking families.\" \u2014Obama: http:\/\/t.co\/e3MEXLUFhv",
  "id" : 496037878657331200,
  "created_at" : "2014-08-03 21:00:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/e3MEXLUFhv",
      "expanded_url" : "http:\/\/go.wh.gov\/CaAf8f",
      "display_url" : "go.wh.gov\/CaAf8f"
    } ]
  },
  "geo" : { },
  "id_str" : "496007724623097856",
  "text" : "\"We\u2019re now in a 6-month streak with at least 200,000 new jobs each month. That hasn\u2019t happened since 1997.\" \u2014Obama: http:\/\/t.co\/e3MEXLUFhv",
  "id" : 496007724623097856,
  "created_at" : "2014-08-03 19:00:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/e3MEXLUFhv",
      "expanded_url" : "http:\/\/go.wh.gov\/CaAf8f",
      "display_url" : "go.wh.gov\/CaAf8f"
    } ]
  },
  "geo" : { },
  "id_str" : "495991263431102464",
  "text" : "\"That\u2019s what\u2019s at stake right now. Making sure our economy works for every working American.\" \u2014President Obama: http:\/\/t.co\/e3MEXLUFhv",
  "id" : 495991263431102464,
  "created_at" : "2014-08-03 17:55:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WestWingWeek",
      "indices" : [ 70, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/cwmEtcazxm",
      "expanded_url" : "http:\/\/go.wh.gov\/bcKkyc",
      "display_url" : "go.wh.gov\/bcKkyc"
    } ]
  },
  "geo" : { },
  "id_str" : "495676685144965120",
  "text" : "\"A little barbecue? In Kansas City?\" Don't miss the latest edition of #WestWingWeek: http:\/\/t.co\/cwmEtcazxm",
  "id" : 495676685144965120,
  "created_at" : "2014-08-02 21:05:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/e3MEXLUFhv",
      "expanded_url" : "http:\/\/go.wh.gov\/CaAf8f",
      "display_url" : "go.wh.gov\/CaAf8f"
    } ]
  },
  "geo" : { },
  "id_str" : "495660372209065984",
  "text" : "President Obama's weekly address: It's time for Congress to help the middle class \u2192 http:\/\/t.co\/e3MEXLUFhv",
  "id" : 495660372209065984,
  "created_at" : "2014-08-02 20:00:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/495290391663366144\/photo\/1",
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/2Uy3bxEHot",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bt-f_HmIIAIxyh9.jpg",
      "id_str" : "495290390753583106",
      "id" : 495290390753583106,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bt-f_HmIIAIxyh9.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/2Uy3bxEHot"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/e3MEXLUFhv",
      "expanded_url" : "http:\/\/go.wh.gov\/CaAf8f",
      "display_url" : "go.wh.gov\/CaAf8f"
    } ]
  },
  "geo" : { },
  "id_str" : "495630391261134848",
  "text" : "\"Our businesses have created 9.9 million jobs over the past 53 months.\" \u2014Obama: http:\/\/t.co\/e3MEXLUFhv http:\/\/t.co\/2Uy3bxEHot",
  "id" : 495630391261134848,
  "created_at" : "2014-08-02 18:01:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WestWingWeek",
      "indices" : [ 59, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/cwmEtcazxm",
      "expanded_url" : "http:\/\/go.wh.gov\/bcKkyc",
      "display_url" : "go.wh.gov\/bcKkyc"
    } ]
  },
  "geo" : { },
  "id_str" : "495616314623262722",
  "text" : "Watch President Obama take a walk down Main Street in this #WestWingWeek \u2192 http:\/\/t.co\/cwmEtcazxm",
  "id" : 495616314623262722,
  "created_at" : "2014-08-02 17:05:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/e3MEXLUFhv",
      "expanded_url" : "http:\/\/go.wh.gov\/CaAf8f",
      "display_url" : "go.wh.gov\/CaAf8f"
    } ]
  },
  "geo" : { },
  "id_str" : "495594913019338753",
  "text" : "\"My top priority as President is doing everything I can to create more jobs...for hardworking families.\" \u2014Obama: http:\/\/t.co\/e3MEXLUFhv",
  "id" : 495594913019338753,
  "created_at" : "2014-08-02 15:40:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "indices" : [ 3, 13 ],
      "id_str" : "1613223313",
      "id" : 1613223313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "495379012831559680",
  "text" : "RT @Cecilia44: DACA = taxpayers. \nGOP bill undoes that.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "495358687494832128",
    "text" : "DACA = taxpayers. \nGOP bill undoes that.",
    "id" : 495358687494832128,
    "created_at" : "2014-08-02 00:01:29 +0000",
    "user" : {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "protected" : false,
      "id_str" : "1613223313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000172019215\/ed65eda76f51213f91b33edbaa62054c_normal.jpeg",
      "id" : 1613223313,
      "verified" : true
    }
  },
  "id" : 495379012831559680,
  "created_at" : "2014-08-02 01:22:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/495344075781201920\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/K1EgVZv2lB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bt_Qz-PIQAA_ZMX.jpg",
      "id_str" : "495344075332403200",
      "id" : 495344075332403200,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bt_Qz-PIQAA_ZMX.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      } ],
      "display_url" : "pic.twitter.com\/K1EgVZv2lB"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/Y3UhlLzt8D",
      "expanded_url" : "http:\/\/huff.to\/1AH4tdc",
      "display_url" : "huff.to\/1AH4tdc"
    } ]
  },
  "geo" : { },
  "id_str" : "495344075781201920",
  "text" : "Today, President Obama signed the cellphone unlocking bill into law in the Oval Office: http:\/\/t.co\/Y3UhlLzt8D http:\/\/t.co\/K1EgVZv2lB",
  "id" : 495344075781201920,
  "created_at" : "2014-08-01 23:03:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/495290391663366144\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/2Uy3bxEHot",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bt-f_HmIIAIxyh9.jpg",
      "id_str" : "495290390753583106",
      "id" : 495290390753583106,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bt-f_HmIIAIxyh9.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/2Uy3bxEHot"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "495290391663366144",
  "text" : "\u201CWhat we did worked, and the economy\u2019s better.\u201D \u2014President Obama on fighting to expand opportunity and create jobs http:\/\/t.co\/2Uy3bxEHot",
  "id" : 495290391663366144,
  "created_at" : "2014-08-01 19:30:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 125, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "495287166797221888",
  "text" : "\u201CIn a country as wealthy as ours, we can afford to make sure that everybody has access to affordable care.\u201D \u2014President Obama #ACAWorks",
  "id" : 495287166797221888,
  "created_at" : "2014-08-01 19:17:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DoYourJobHouseGOP",
      "indices" : [ 118, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "495286152866594816",
  "text" : "\u201CCommonsense legislation can\u2019t pass because House Republicans...consider it a compromise of their principles.\u201D \u2014Obama #DoYourJobHouseGOP",
  "id" : 495286152866594816,
  "created_at" : "2014-08-01 19:13:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DoYourJobHouseGOP",
      "indices" : [ 122, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "495281669520515072",
  "text" : "\"After all we\u2019ve had to overcome, our Congress should stop standing in the way of our country\u2019s success\" \u2014President Obama #DoYourJobHouseGOP",
  "id" : 495281669520515072,
  "created_at" : "2014-08-01 18:55:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "495281369250283520",
  "text" : "\"The American people demand and deserve a strong and focused effort on the part of all of us to keep our country moving forward.\" \u2014Obama",
  "id" : 495281369250283520,
  "created_at" : "2014-08-01 18:54:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/495280798317428736\/photo\/1",
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/Td6J8JPK4N",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bt-XQt2IcAAWIsT.jpg",
      "id_str" : "495280797474385920",
      "id" : 495280797474385920,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bt-XQt2IcAAWIsT.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Td6J8JPK4N"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "495280798317428736",
  "text" : "\"States &amp; businesses are raising the minimum wage for their workers because this Congress is failing to do so\" \u2014Obama http:\/\/t.co\/Td6J8JPK4N",
  "id" : 495280798317428736,
  "created_at" : "2014-08-01 18:51:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "495280451045838848",
  "text" : "RT @WHLive: \"We all agree there\u2019s a problem that needs to be solved along a sector of our southern border.\" \u2014President Obama #DoYourJobHous\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DoYourJobHouseGOP",
        "indices" : [ 113, 131 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "495280423451525121",
    "text" : "\"We all agree there\u2019s a problem that needs to be solved along a sector of our southern border.\" \u2014President Obama #DoYourJobHouseGOP",
    "id" : 495280423451525121,
    "created_at" : "2014-08-01 18:50:29 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 495280451045838848,
  "created_at" : "2014-08-01 18:50:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "495279893144686592",
  "text" : "RT @WHLive: \u201CThere are steps that we could be taking that would result in more job growth, higher wages.\u201D  \u2014President Obama #DoYourJobHouse\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DoYourJobHouseGOP",
        "indices" : [ 112, 130 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "495279862098436096",
    "text" : "\u201CThere are steps that we could be taking that would result in more job growth, higher wages.\u201D  \u2014President Obama #DoYourJobHouseGOP",
    "id" : 495279862098436096,
    "created_at" : "2014-08-01 18:48:15 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 495279893144686592,
  "created_at" : "2014-08-01 18:48:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "495279423739150336",
  "text" : "\"We are now in a 6-month streak with at least 200,000 new jobs each month\u2014the first time that\u2019s happened since 1997.\" \u2014President Obama",
  "id" : 495279423739150336,
  "created_at" : "2014-08-01 18:46:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/495279349692506112\/photo\/1",
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/nAqMbMrwwh",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/Bt-V8NfIYAA6DIJ.png",
      "id_str" : "495279345678966784",
      "id" : 495279345678966784,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/Bt-V8NfIYAA6DIJ.png",
      "sizes" : [ {
        "h" : 500,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/nAqMbMrwwh"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "495279349692506112",
  "text" : "\"This morning, we learned that our economy created over 200,000 new jobs in July.\" \u2014President Obama http:\/\/t.co\/nAqMbMrwwh",
  "id" : 495279349692506112,
  "created_at" : "2014-08-01 18:46:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/UQuYFHpENo",
      "expanded_url" : "http:\/\/go.wh.gov\/M4LSSy",
      "display_url" : "go.wh.gov\/M4LSSy"
    } ]
  },
  "geo" : { },
  "id_str" : "495279190112223232",
  "text" : "Happening now: President Obama delivers a statement from the Briefing Room \u2192 http:\/\/t.co\/UQuYFHpENo",
  "id" : 495279190112223232,
  "created_at" : "2014-08-01 18:45:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/UQuYFHpENo",
      "expanded_url" : "http:\/\/go.wh.gov\/M4LSSy",
      "display_url" : "go.wh.gov\/M4LSSy"
    } ]
  },
  "geo" : { },
  "id_str" : "495270582733512704",
  "text" : "At 2:35pm ET, President Obama will deliver a statement from the Briefing Room. Watch \u2192 http:\/\/t.co\/UQuYFHpENo",
  "id" : 495270582733512704,
  "created_at" : "2014-08-01 18:11:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "We the People",
      "screen_name" : "wethepeople",
      "indices" : [ 29, 41 ],
      "id_str" : "369507958",
      "id" : 369507958
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/Y3UhlLzt8D",
      "expanded_url" : "http:\/\/huff.to\/1AH4tdc",
      "display_url" : "huff.to\/1AH4tdc"
    } ]
  },
  "geo" : { },
  "id_str" : "495259888491433984",
  "text" : "You made your voice heard on @WeThePeople\u2014and today President Obama's signing the cellphone unlocking bill into law: http:\/\/t.co\/Y3UhlLzt8D",
  "id" : 495259888491433984,
  "created_at" : "2014-08-01 17:28:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "values",
      "indices" : [ 18, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "495255262690050050",
  "text" : "RT @Simas44: Core #values in House immigration debate:\n\nDEMs call immigrant kids who've grown up in America \"dreamers.\" \n\nGOP calls them \"i\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "values",
        "indices" : [ 5, 12 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "495251004439666688",
    "text" : "Core #values in House immigration debate:\n\nDEMs call immigrant kids who've grown up in America \"dreamers.\" \n\nGOP calls them \"illegals.\"",
    "id" : 495251004439666688,
    "created_at" : "2014-08-01 16:53:35 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 495255262690050050,
  "created_at" : "2014-08-01 17:10:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 3, 13 ],
      "id_str" : "9624742",
      "id" : 9624742
    }, {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "indices" : [ 38, 48 ],
      "id_str" : "15007149",
      "id" : 15007149
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Gaza",
      "indices" : [ 73, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/7qPplpiXnd",
      "expanded_url" : "http:\/\/go.usa.gov\/NjZ5",
      "display_url" : "go.usa.gov\/NjZ5"
    } ]
  },
  "geo" : { },
  "id_str" : "495245415915470851",
  "text" : "RT @StateDept: Statement by Secretary @JohnKerry on the situation in the #Gaza Strip \u2192 http:\/\/t.co\/7qPplpiXnd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Kerry",
        "screen_name" : "JohnKerry",
        "indices" : [ 23, 33 ],
        "id_str" : "15007149",
        "id" : 15007149
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Gaza",
        "indices" : [ 58, 63 ]
      } ],
      "urls" : [ {
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/7qPplpiXnd",
        "expanded_url" : "http:\/\/go.usa.gov\/NjZ5",
        "display_url" : "go.usa.gov\/NjZ5"
      } ]
    },
    "geo" : { },
    "id_str" : "495233219638595585",
    "text" : "Statement by Secretary @JohnKerry on the situation in the #Gaza Strip \u2192 http:\/\/t.co\/7qPplpiXnd",
    "id" : 495233219638595585,
    "created_at" : "2014-08-01 15:42:55 +0000",
    "user" : {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "protected" : false,
      "id_str" : "9624742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724612605185282048\/1rEfkXDZ_normal.jpg",
      "id" : 9624742,
      "verified" : true
    }
  },
  "id" : 495245415915470851,
  "created_at" : "2014-08-01 16:31:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Schultz",
      "screen_name" : "Schultz44",
      "indices" : [ 3, 13 ],
      "id_str" : "1603419038",
      "id" : 1603419038
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "495240712989200385",
  "text" : "RT @Schultz44: Our businesses have added 9.9 million jobs over 53 straight months of growth\u2014the longest such streak on record. http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/495207294292852737\/photo\/1",
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/NFq40CaPOQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bt9UaNiIIAES6Z1.jpg",
        "id_str" : "495207293320175617",
        "id" : 495207293320175617,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bt9UaNiIIAES6Z1.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 700,
          "resize" : "fit",
          "w" : 1400
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/NFq40CaPOQ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "495214862583476224",
    "text" : "Our businesses have added 9.9 million jobs over 53 straight months of growth\u2014the longest such streak on record. http:\/\/t.co\/NFq40CaPOQ",
    "id" : 495214862583476224,
    "created_at" : "2014-08-01 14:29:58 +0000",
    "user" : {
      "name" : "Eric Schultz",
      "screen_name" : "Schultz44",
      "protected" : false,
      "id_str" : "1603419038",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/491941155815161856\/u0IdexM6_normal.jpeg",
      "id" : 1603419038,
      "verified" : true
    }
  },
  "id" : 495240712989200385,
  "created_at" : "2014-08-01 16:12:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "495231282251456512",
  "text" : "RT @VP: Good news for the middle class  \u2192 Our businesses have added 9.9 million jobs over 53 straight months. Keep fightin'. http:\/\/t.co\/R0\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/495230710094258176\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/R0b1YDK6WC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bt9ptIpCcAEbD3O.png",
        "id_str" : "495230708168683521",
        "id" : 495230708168683521,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bt9ptIpCcAEbD3O.png",
        "sizes" : [ {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/R0b1YDK6WC"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "495230710094258176",
    "text" : "Good news for the middle class  \u2192 Our businesses have added 9.9 million jobs over 53 straight months. Keep fightin'. http:\/\/t.co\/R0b1YDK6WC",
    "id" : 495230710094258176,
    "created_at" : "2014-08-01 15:32:56 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 495231282251456512,
  "created_at" : "2014-08-01 15:35:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/495207294292852737\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/Ycd1tkFxak",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bt9UaNiIIAES6Z1.jpg",
      "id_str" : "495207293320175617",
      "id" : 495207293320175617,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bt9UaNiIIAES6Z1.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Ycd1tkFxak"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "495217392755425281",
  "text" : "Total job growth in July exceeded 200,000 for the 6th straight month\u2014the 1st time that's happened since 1997. http:\/\/t.co\/Ycd1tkFxak",
  "id" : 495217392755425281,
  "created_at" : "2014-08-01 14:40:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "indices" : [ 3, 12 ],
      "id_str" : "1604366701",
      "id" : 1604366701
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/LaborSec\/status\/495207574854434816\/photo\/1",
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/QpyXLbBGe4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bt9UqbvIUAEEK2g.png",
      "id_str" : "495207572010717185",
      "id" : 495207572010717185,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bt9UqbvIUAEEK2g.png",
      "sizes" : [ {
        "h" : 440,
        "resize" : "fit",
        "w" : 691
      }, {
        "h" : 440,
        "resize" : "fit",
        "w" : 691
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 216,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 382,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/QpyXLbBGe4"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "495209581065539584",
  "text" : "RT @LaborSec: The last time job growth exceeded 200k for 6 straight months I looked like this: http:\/\/t.co\/QpyXLbBGe4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/LaborSec\/status\/495207574854434816\/photo\/1",
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/QpyXLbBGe4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bt9UqbvIUAEEK2g.png",
        "id_str" : "495207572010717185",
        "id" : 495207572010717185,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bt9UqbvIUAEEK2g.png",
        "sizes" : [ {
          "h" : 440,
          "resize" : "fit",
          "w" : 691
        }, {
          "h" : 440,
          "resize" : "fit",
          "w" : 691
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 216,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 382,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/QpyXLbBGe4"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "495207574854434816",
    "text" : "The last time job growth exceeded 200k for 6 straight months I looked like this: http:\/\/t.co\/QpyXLbBGe4",
    "id" : 495207574854434816,
    "created_at" : "2014-08-01 14:01:01 +0000",
    "user" : {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "protected" : false,
      "id_str" : "1604366701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744887280666611712\/eEeyFjs6_normal.jpg",
      "id" : 1604366701,
      "verified" : true
    }
  },
  "id" : 495209581065539584,
  "created_at" : "2014-08-01 14:08:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/495207294292852737\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/Ycd1tkFxak",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bt9UaNiIIAES6Z1.jpg",
      "id_str" : "495207293320175617",
      "id" : 495207293320175617,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bt9UaNiIIAES6Z1.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Ycd1tkFxak"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "495207294292852737",
  "text" : "Our businesses have added:\n9.9 million jobs over 53 months \u2713\n2.5 million over the past year \u2713\n198,000 in July \u2713\n\u2192 http:\/\/t.co\/Ycd1tkFxak",
  "id" : 495207294292852737,
  "created_at" : "2014-08-01 13:59:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kori Schulman",
      "screen_name" : "ks44",
      "indices" : [ 3, 8 ],
      "id_str" : "369246180",
      "id" : 369246180
    }, {
      "name" : "We the People",
      "screen_name" : "wethepeople",
      "indices" : [ 105, 117 ],
      "id_str" : "369507958",
      "id" : 369507958
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "495203536377221122",
  "text" : "RT @ks44: Today the President will sign into law the cellphone unlocking bill, an effort that began w\/ a @wethepeople petition: http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "We the People",
        "screen_name" : "wethepeople",
        "indices" : [ 95, 107 ],
        "id_str" : "369507958",
        "id" : 369507958
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/vPTk7YhHuH",
        "expanded_url" : "http:\/\/huff.to\/1AH4tdc",
        "display_url" : "huff.to\/1AH4tdc"
      } ]
    },
    "geo" : { },
    "id_str" : "495203265790107648",
    "text" : "Today the President will sign into law the cellphone unlocking bill, an effort that began w\/ a @wethepeople petition: http:\/\/t.co\/vPTk7YhHuH",
    "id" : 495203265790107648,
    "created_at" : "2014-08-01 13:43:53 +0000",
    "user" : {
      "name" : "Kori Schulman",
      "screen_name" : "ks44",
      "protected" : false,
      "id_str" : "369246180",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/667876153793859584\/DV7HzP-1_normal.jpg",
      "id" : 369246180,
      "verified" : true
    }
  },
  "id" : 495203536377221122,
  "created_at" : "2014-08-01 13:44:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
} ]