Grailbird.data.tweets_2012_11 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "My2k",
      "indices" : [ 99, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/bXZYn0tF",
      "expanded_url" : "http:\/\/on.wh.gov\/eVt5NgM",
      "display_url" : "on.wh.gov\/eVt5NgM"
    }, {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/vGZOFDXD",
      "expanded_url" : "http:\/\/on.wh.gov\/ozhvyBT",
      "display_url" : "on.wh.gov\/ozhvyBT"
    } ]
  },
  "geo" : { },
  "id_str" : "274672415978713088",
  "text" : "Mayra spoke out on why we need to extend middle-class tax cuts. Have you? http:\/\/t.co\/bXZYn0tF Use #My2k &amp; watch: http:\/\/t.co\/vGZOFDXD",
  "id" : 274672415978713088,
  "created_at" : "2012-12-01 00:33:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura McAfee",
      "screen_name" : "LauraMcAfee1",
      "indices" : [ 3, 16 ],
      "id_str" : "521343911",
      "id" : 521343911
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "my2K",
      "indices" : [ 18, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "274641742144368641",
  "text" : "RT @LauraMcAfee1: #my2K that's 2 months rent and that's huge to me, as a single mom..",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "my2K",
        "indices" : [ 0, 5 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "274641343467360257",
    "text" : "#my2K that's 2 months rent and that's huge to me, as a single mom..",
    "id" : 274641343467360257,
    "created_at" : "2012-11-30 22:29:33 +0000",
    "user" : {
      "name" : "Laura McAfee",
      "screen_name" : "LauraMcAfee1",
      "protected" : false,
      "id_str" : "521343911",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1888745155\/sunbow_normal.jpg",
      "id" : 521343911,
      "verified" : false
    }
  },
  "id" : 274641742144368641,
  "created_at" : "2012-11-30 22:31:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nadine Lujan",
      "screen_name" : "craftydeeney",
      "indices" : [ 3, 16 ],
      "id_str" : "40659307",
      "id" : 40659307
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "my2k",
      "indices" : [ 18, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "274638113710673920",
  "text" : "RT @craftydeeney: #my2k means being able to pay for groceries, household items, and being able to pay our bills. It may not seem like a  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "my2k",
        "indices" : [ 0, 5 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "274633136850223105",
    "text" : "#my2k means being able to pay for groceries, household items, and being able to pay our bills. It may not seem like a lot but it is to us.",
    "id" : 274633136850223105,
    "created_at" : "2012-11-30 21:56:56 +0000",
    "user" : {
      "name" : "Nadine Lujan",
      "screen_name" : "craftydeeney",
      "protected" : false,
      "id_str" : "40659307",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/788371282739986433\/6eF_oMtq_normal.jpg",
      "id" : 40659307,
      "verified" : false
    }
  },
  "id" : 274638113710673920,
  "created_at" : "2012-11-30 22:16:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/274598511553703937\/photo\/1",
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/R7ZuEz8Z",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A8-R5DGCcAAdsoR.jpg",
      "id_str" : "274598511562092544",
      "id" : 274598511562092544,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A8-R5DGCcAAdsoR.jpg",
      "sizes" : [ {
        "h" : 1710,
        "resize" : "fit",
        "w" : 976
      }, {
        "h" : 1051,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1710,
        "resize" : "fit",
        "w" : 976
      }, {
        "h" : 596,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/R7ZuEz8Z"
    } ],
    "hashtags" : [ {
      "text" : "My2k",
      "indices" : [ 84, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "274598511553703937",
  "text" : "Over 235,000 Americans have spoken out on extending middle-class tax cuts. Keep the #My2k stories coming: http:\/\/t.co\/R7ZuEz8Z",
  "id" : 274598511553703937,
  "created_at" : "2012-11-30 19:39:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WorldAIDSDay",
      "indices" : [ 12, 25 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 89, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 128, 148 ],
      "url" : "http:\/\/t.co\/0qRnVcns",
      "expanded_url" : "http:\/\/on.wh.gov\/VNv3j7L",
      "display_url" : "on.wh.gov\/VNv3j7L"
    } ]
  },
  "geo" : { },
  "id_str" : "274569293356728320",
  "text" : "Tomorrow is #WorldAIDSDay - Have Q's about the global fight against HIV\/AIDS? Ask now w\/ #WHChat &amp; join the Q&amp;A at 3ET: http:\/\/t.co\/0qRnVcns",
  "id" : 274569293356728320,
  "created_at" : "2012-11-30 17:43:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/bCbPT74u",
      "expanded_url" : "http:\/\/on.wh.gov\/DZHTcQO",
      "display_url" : "on.wh.gov\/DZHTcQO"
    } ]
  },
  "geo" : { },
  "id_str" : "274548488392560641",
  "text" : "Today at 12:05ET: President Obama speaks at the Rodon Group Manufacturing Facility in Pennsylvania. Watch live: http:\/\/t.co\/bCbPT74u",
  "id" : 274548488392560641,
  "created_at" : "2012-11-30 16:20:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 108, 113 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WorldAIDSDay",
      "indices" : [ 61, 74 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 145, 152 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "274527909622992896",
  "text" : "Have questions about the global fight against HIV\/AIDS &amp; #WorldAIDSDay? Join us at 3ET for a Q&amp;A w\/ @vj44 &amp; NSCs Gayle Smith. Ask w\/ #WHChat",
  "id" : 274527909622992896,
  "created_at" : "2012-11-30 14:58:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/V1Zwn6RY",
      "expanded_url" : "http:\/\/on.wh.gov\/Vh85eL7",
      "display_url" : "on.wh.gov\/Vh85eL7"
    }, {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/kqRJL9Du",
      "expanded_url" : "http:\/\/on.wh.gov\/aJ0PZCj",
      "display_url" : "on.wh.gov\/aJ0PZCj"
    } ]
  },
  "geo" : { },
  "id_str" : "274375479790804993",
  "text" : "First Dog Bo makes a final inspection of the 2012 White House Holiday Decorations: http:\/\/t.co\/V1Zwn6RY Watch: http:\/\/t.co\/kqRJL9Du",
  "id" : 274375479790804993,
  "created_at" : "2012-11-30 04:53:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/274362647238041600\/photo\/1",
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/S3quIDsz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A867X8DCYAAHKC5.jpg",
      "id_str" : "274362647246430208",
      "id" : 274362647246430208,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A867X8DCYAAHKC5.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/S3quIDsz"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "274362647238041600",
  "text" : "Photo of the Day: President Obama and former Governor Mitt Romney talk in the Oval Office following their lunch: http:\/\/t.co\/S3quIDsz",
  "id" : 274362647238041600,
  "created_at" : "2012-11-30 04:02:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kittywhumpus",
      "screen_name" : "kittywhumpus",
      "indices" : [ 3, 16 ],
      "id_str" : "35917965",
      "id" : 35917965
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "My2K",
      "indices" : [ 18, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "274353104856698881",
  "text" : "RT @kittywhumpus: #My2K: 2 months of day care; 3 months of mortgage; 4 months of food. Choose one, but each is 2K I put back into the lo ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "My2K",
        "indices" : [ 0, 5 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "274351931642761216",
    "text" : "#My2K: 2 months of day care; 3 months of mortgage; 4 months of food. Choose one, but each is 2K I put back into the local economy.",
    "id" : 274351931642761216,
    "created_at" : "2012-11-30 03:19:32 +0000",
    "user" : {
      "name" : "kittywhumpus",
      "screen_name" : "kittywhumpus",
      "protected" : false,
      "id_str" : "35917965",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2594305583\/69dqwtk5r8gpvlrwql19_normal.jpeg",
      "id" : 35917965,
      "verified" : false
    }
  },
  "id" : 274353104856698881,
  "created_at" : "2012-11-30 03:24:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/274347174161166336\/photo\/1",
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/fRFJpTYU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A86tTSWCMAAEzyg.png",
      "id_str" : "274347174169554944",
      "id" : 274347174169554944,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A86tTSWCMAAEzyg.png",
      "sizes" : [ {
        "h" : 270,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 788,
        "resize" : "fit",
        "w" : 992
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 477,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 788,
        "resize" : "fit",
        "w" : 992
      } ],
      "display_url" : "pic.twitter.com\/fRFJpTYU"
    } ],
    "hashtags" : [ {
      "text" : "My2k",
      "indices" : [ 47, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/LfTWIjyH",
      "expanded_url" : "http:\/\/WhiteHouse.gov",
      "display_url" : "WhiteHouse.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "274347174161166336",
  "text" : "What does $2,000 mean to you? Let us know with #My2k &amp; you just might see your story on http:\/\/t.co\/LfTWIjyH: http:\/\/t.co\/fRFJpTYU",
  "id" : 274347174161166336,
  "created_at" : "2012-11-30 03:00:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrice M. McKenzie",
      "screen_name" : "patricem08",
      "indices" : [ 3, 14 ],
      "id_str" : "275611127",
      "id" : 275611127
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "My2K",
      "indices" : [ 16, 21 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "274329991821533184",
  "text" : "RT @patricem08: #My2K means a tremendous amount to me as a full time graduate student. Food, bus fare, books, etc are costs easily offse ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "My2K",
        "indices" : [ 0, 5 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "273845357975314432",
    "text" : "#My2K means a tremendous amount to me as a full time graduate student. Food, bus fare, books, etc are costs easily offset with $2k.",
    "id" : 273845357975314432,
    "created_at" : "2012-11-28 17:46:35 +0000",
    "user" : {
      "name" : "Patrice M. McKenzie",
      "screen_name" : "patricem08",
      "protected" : false,
      "id_str" : "275611127",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1308078061\/PSM_1__96x96__normal.jpg",
      "id" : 275611127,
      "verified" : false
    }
  },
  "id" : 274329991821533184,
  "created_at" : "2012-11-30 01:52:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 22, 27 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WorldAIDSDay",
      "indices" : [ 76, 89 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 112, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 121, 141 ],
      "url" : "http:\/\/t.co\/FGCXcOr6",
      "expanded_url" : "http:\/\/on.wh.gov\/TVWs9xW",
      "display_url" : "on.wh.gov\/TVWs9xW"
    } ]
  },
  "geo" : { },
  "id_str" : "274314532036427776",
  "text" : "Tomorrow at 3ET: Join @VJ44 &amp; the NSC's Gayle Smith for Office Hours on #WorldAIDSDay. Have Q's? Ask now w\/ #WHChat: http:\/\/t.co\/FGCXcOr6",
  "id" : 274314532036427776,
  "created_at" : "2012-11-30 00:50:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/274299271753367553\/photo\/1",
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/MptT1ri3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A86Bu_-CAAAHDak.jpg",
      "id_str" : "274299271761756160",
      "id" : 274299271761756160,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A86Bu_-CAAAHDak.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/MptT1ri3"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http:\/\/t.co\/vKbQjyRC",
      "expanded_url" : "http:\/\/on.wh.gov\/Jc4KGcw",
      "display_url" : "on.wh.gov\/Jc4KGcw"
    } ]
  },
  "geo" : { },
  "id_str" : "274299271753367553",
  "text" : "Photo of the Day: First Lady Michelle Obama previews the 2012 White House Holiday Decor: http:\/\/t.co\/vKbQjyRC http:\/\/t.co\/MptT1ri3",
  "id" : 274299271753367553,
  "created_at" : "2012-11-29 23:50:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 7, 10 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "My2k",
      "indices" : [ 48, 53 ]
    }, {
      "text" : "BidenatCostco",
      "indices" : [ 108, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 124, 144 ],
      "url" : "http:\/\/t.co\/xGVYn8ib",
      "expanded_url" : "http:\/\/on.wh.gov\/gkGDDq0",
      "display_url" : "on.wh.gov\/gkGDDq0"
    } ]
  },
  "geo" : { },
  "id_str" : "274284052020871168",
  "text" : "Today, @VP Biden visited a Costco to talk about #My2k &amp; the need to extend middle-class tax cuts. Watch #BidenatCostco: http:\/\/t.co\/xGVYn8ib",
  "id" : 274284052020871168,
  "created_at" : "2012-11-29 22:49:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cory Booker",
      "screen_name" : "CoryBooker",
      "indices" : [ 3, 14 ],
      "id_str" : "15808765",
      "id" : 15808765
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "My2K",
      "indices" : [ 124, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "274255812078211072",
  "text" : "RT @CoryBooker: If Congress fails to act, the average Newark family would see a $2,200 tax hike. How would that affect you? #My2K http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "My2K",
        "indices" : [ 108, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 134 ],
        "url" : "http:\/\/t.co\/ORUQnOd9",
        "expanded_url" : "http:\/\/wh.gov\/my2k",
        "display_url" : "wh.gov\/my2k"
      } ]
    },
    "geo" : { },
    "id_str" : "274212393721163778",
    "text" : "If Congress fails to act, the average Newark family would see a $2,200 tax hike. How would that affect you? #My2K http:\/\/t.co\/ORUQnOd9",
    "id" : 274212393721163778,
    "created_at" : "2012-11-29 18:05:03 +0000",
    "user" : {
      "name" : "Cory Booker",
      "screen_name" : "CoryBooker",
      "protected" : false,
      "id_str" : "15808765",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/694587770812104704\/2fOI9t5R_normal.jpg",
      "id" : 15808765,
      "verified" : true
    }
  },
  "id" : 274255812078211072,
  "created_at" : "2012-11-29 20:57:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LindaB",
      "screen_name" : "LindaBergam",
      "indices" : [ 3, 15 ],
      "id_str" : "273729526",
      "id" : 273729526
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "My2K",
      "indices" : [ 17, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "274245727008468992",
  "text" : "RT @LindaBergam: #My2K is college tuition to start a bright future for our kids. Thanks, Mr. President, for getting all Americans involv ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "My2K",
        "indices" : [ 0, 5 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "274243770831220736",
    "text" : "#My2K is college tuition to start a bright future for our kids. Thanks, Mr. President, for getting all Americans involved in this decision.",
    "id" : 274243770831220736,
    "created_at" : "2012-11-29 20:09:44 +0000",
    "user" : {
      "name" : "LindaB",
      "screen_name" : "LindaBergam",
      "protected" : false,
      "id_str" : "273729526",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3119744622\/987b69b4c1648e6bf0370045015a0c99_normal.jpeg",
      "id" : 273729526,
      "verified" : false
    }
  },
  "id" : 274245727008468992,
  "created_at" : "2012-11-29 20:17:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "my2k",
      "indices" : [ 133, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "274233054762004480",
  "text" : "RT @VP: If there\u2019s one thing we should all agree on, it\u2019s that the middle-class tax cut should be made permanent.- VP @ Costco today #my2k",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "my2k",
        "indices" : [ 125, 130 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "274205190322786305",
    "text" : "If there\u2019s one thing we should all agree on, it\u2019s that the middle-class tax cut should be made permanent.- VP @ Costco today #my2k",
    "id" : 274205190322786305,
    "created_at" : "2012-11-29 17:36:26 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 274233054762004480,
  "created_at" : "2012-11-29 19:27:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Beth Garry",
      "screen_name" : "bgarry",
      "indices" : [ 13, 20 ],
      "id_str" : "37795818",
      "id" : 37795818
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "my2k",
      "indices" : [ 58, 63 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 132, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/X9dkn0zs",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/my2k",
      "display_url" : "whitehouse.gov\/my2k"
    } ]
  },
  "geo" : { },
  "id_str" : "274220853477117952",
  "text" : "RT @WHLive: .@bgarry GREAT question. Adding your voice to #my2k might help get the common sense answer we need http:\/\/t.co\/X9dkn0zs #WHChat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Beth Garry",
        "screen_name" : "bgarry",
        "indices" : [ 1, 8 ],
        "id_str" : "37795818",
        "id" : 37795818
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "my2k",
        "indices" : [ 46, 51 ]
      }, {
        "text" : "WHChat",
        "indices" : [ 120, 127 ]
      } ],
      "urls" : [ {
        "indices" : [ 99, 119 ],
        "url" : "http:\/\/t.co\/X9dkn0zs",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/my2k",
        "display_url" : "whitehouse.gov\/my2k"
      } ]
    },
    "geo" : { },
    "id_str" : "274219291925151744",
    "text" : ".@bgarry GREAT question. Adding your voice to #my2k might help get the common sense answer we need http:\/\/t.co\/X9dkn0zs #WHChat",
    "id" : 274219291925151744,
    "created_at" : "2012-11-29 18:32:28 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 274220853477117952,
  "created_at" : "2012-11-29 18:38:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beth Garry",
      "screen_name" : "bgarry",
      "indices" : [ 3, 10 ],
      "id_str" : "37795818",
      "id" : 37795818
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 12, 19 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "274220833449316352",
  "text" : "RT @bgarry: #WHChat. Why don't members of both parties extend the middle-class tax cuts FIRST and work out other details later?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 0, 7 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "274218647998836736",
    "text" : "#WHChat. Why don't members of both parties extend the middle-class tax cuts FIRST and work out other details later?",
    "id" : 274218647998836736,
    "created_at" : "2012-11-29 18:29:55 +0000",
    "user" : {
      "name" : "Beth Garry",
      "screen_name" : "bgarry",
      "protected" : false,
      "id_str" : "37795818",
      "profile_image_url_https" : "https:\/\/abs.twimg.com\/sticky\/default_profile_images\/default_profile_4_normal.png",
      "id" : 37795818,
      "verified" : false
    }
  },
  "id" : 274220833449316352,
  "created_at" : "2012-11-29 18:38:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Coretta",
      "screen_name" : "CorettaJackson",
      "indices" : [ 13, 28 ],
      "id_str" : "15386833",
      "id" : 15386833
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "274217578300317696",
  "text" : "RT @WHLive: .@CorettaJackson Confidence is at near 5yr high but expiring middle class tax cuts put that at risk. Details: http:\/\/t.co\/GD ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Coretta",
        "screen_name" : "CorettaJackson",
        "indices" : [ 1, 16 ],
        "id_str" : "15386833",
        "id" : 15386833
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WhChat",
        "indices" : [ 131, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 110, 130 ],
        "url" : "http:\/\/t.co\/GDD3YZFH",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/sites\/default\/files\/uploads\/consumer_report.pdf",
        "display_url" : "whitehouse.gov\/sites\/default\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "274216523458048000",
    "text" : ".@CorettaJackson Confidence is at near 5yr high but expiring middle class tax cuts put that at risk. Details: http:\/\/t.co\/GDD3YZFH #WhChat",
    "id" : 274216523458048000,
    "created_at" : "2012-11-29 18:21:28 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 274217578300317696,
  "created_at" : "2012-11-29 18:25:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coretta",
      "screen_name" : "CorettaJackson",
      "indices" : [ 3, 18 ],
      "id_str" : "15386833",
      "id" : 15386833
    }, {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 31, 38 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "The Conference Board",
      "screen_name" : "Conferenceboard",
      "indices" : [ 43, 59 ],
      "id_str" : "43889656",
      "id" : 43889656
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "consumerconfidence",
      "indices" : [ 86, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "274217562097713152",
  "text" : "RT @CorettaJackson: Hi Brian! .@WHLive the @Conferenceboard reports another uptick in #consumerconfidence. Will this  continue beyond ho ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "White House Live",
        "screen_name" : "WHLive",
        "indices" : [ 11, 18 ],
        "id_str" : "369505837",
        "id" : 369505837
      }, {
        "name" : "The Conference Board",
        "screen_name" : "Conferenceboard",
        "indices" : [ 23, 39 ],
        "id_str" : "43889656",
        "id" : 43889656
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "consumerconfidence",
        "indices" : [ 66, 85 ]
      }, {
        "text" : "WHchat",
        "indices" : [ 130, 137 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "274213209358077953",
    "geo" : { },
    "id_str" : "274215104734695424",
    "in_reply_to_user_id" : 369505837,
    "text" : "Hi Brian! .@WHLive the @Conferenceboard reports another uptick in #consumerconfidence. Will this  continue beyond holiday season? #WHchat",
    "id" : 274215104734695424,
    "in_reply_to_status_id" : 274213209358077953,
    "created_at" : "2012-11-29 18:15:50 +0000",
    "in_reply_to_screen_name" : "WHLive",
    "in_reply_to_user_id_str" : "369505837",
    "user" : {
      "name" : "Coretta",
      "screen_name" : "CorettaJackson",
      "protected" : false,
      "id_str" : "15386833",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793457683202510848\/PJ4jBgeS_normal.jpg",
      "id" : 15386833,
      "verified" : false
    }
  },
  "id" : 274217562097713152,
  "created_at" : "2012-11-29 18:25:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "my2K",
      "indices" : [ 69, 74 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 75, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "274213556428365824",
  "text" : "RT @WHLive: Hi all, Brian Deese here ready to take your questions on #my2K #WHChat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "my2K",
        "indices" : [ 57, 62 ]
      }, {
        "text" : "WHChat",
        "indices" : [ 63, 70 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "274213209358077953",
    "text" : "Hi all, Brian Deese here ready to take your questions on #my2K #WHChat",
    "id" : 274213209358077953,
    "created_at" : "2012-11-29 18:08:18 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 274213556428365824,
  "created_at" : "2012-11-29 18:09:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kelli Rogers",
      "screen_name" : "kczingler07",
      "indices" : [ 3, 15 ],
      "id_str" : "811129860",
      "id" : 811129860
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "My2K",
      "indices" : [ 17, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "274191481974165504",
  "text" : "RT @kczingler07: #My2K is being able to pay off my student loans and starting a savings to get ready to buy a house and start a family.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "My2K",
        "indices" : [ 0, 5 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "274190863696007168",
    "text" : "#My2K is being able to pay off my student loans and starting a savings to get ready to buy a house and start a family.",
    "id" : 274190863696007168,
    "created_at" : "2012-11-29 16:39:30 +0000",
    "user" : {
      "name" : "Kelli Rogers",
      "screen_name" : "kczingler07",
      "protected" : false,
      "id_str" : "811129860",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/654729939200008192\/sUpbkxat_normal.jpg",
      "id" : 811129860,
      "verified" : false
    }
  },
  "id" : 274191481974165504,
  "created_at" : "2012-11-29 16:41:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "My2k",
      "indices" : [ 76, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/qWIPoEoA",
      "expanded_url" : "http:\/\/on.wh.gov\/zcSUiIV",
      "display_url" : "on.wh.gov\/zcSUiIV"
    } ]
  },
  "geo" : { },
  "id_str" : "274184233369616385",
  "text" : "Since President Obama's speech yesterday, there have been more than 132,000 #My2k tweets. Keep the stories coming: http:\/\/t.co\/qWIPoEoA",
  "id" : 274184233369616385,
  "created_at" : "2012-11-29 16:13:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "My2k",
      "indices" : [ 68, 73 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 139, 146 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "274166457368195072",
  "text" : "Have questions about middle-class tax cuts, deficit reduction &amp; #My2k? Join us at 1ET for a Q&amp;A with NEC's Brian Deese. Ask now w\/ #WHChat",
  "id" : 274166457368195072,
  "created_at" : "2012-11-29 15:02:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/273998482908512256\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/RUnbLZFn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A81wKyNCAAAk2J4.jpg",
      "id_str" : "273998482916900864",
      "id" : 273998482916900864,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A81wKyNCAAAk2J4.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 403,
        "resize" : "fit",
        "w" : 403
      }, {
        "h" : 403,
        "resize" : "fit",
        "w" : 403
      }, {
        "h" : 403,
        "resize" : "fit",
        "w" : 403
      } ],
      "display_url" : "pic.twitter.com\/RUnbLZFn"
    } ],
    "hashtags" : [ {
      "text" : "My2k",
      "indices" : [ 114, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273998482908512256",
  "text" : "With $2,000, the average middle-class family can buy 3 months of groceries. What does $2k mean to you? Tell us w\/ #My2k http:\/\/t.co\/RUnbLZFn",
  "id" : 273998482908512256,
  "created_at" : "2012-11-29 03:55:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/273982121343856643\/photo\/1",
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/FKhbVguE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A81hSapCMAA7pb5.jpg",
      "id_str" : "273982121356439552",
      "id" : 273982121356439552,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A81hSapCMAA7pb5.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 403,
        "resize" : "fit",
        "w" : 403
      }, {
        "h" : 403,
        "resize" : "fit",
        "w" : 403
      }, {
        "h" : 403,
        "resize" : "fit",
        "w" : 403
      } ],
      "display_url" : "pic.twitter.com\/FKhbVguE"
    } ],
    "hashtags" : [ {
      "text" : "My2k",
      "indices" : [ 113, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273982121343856643",
  "text" : "$2,000 means 18 months of electric bill payments for the average middle-class family. What does $2k mean to you? #My2k http:\/\/t.co\/FKhbVguE",
  "id" : 273982121343856643,
  "created_at" : "2012-11-29 02:50:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "My2k",
      "indices" : [ 88, 93 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 116, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 124, 144 ],
      "url" : "http:\/\/t.co\/KHD3sdHk",
      "expanded_url" : "http:\/\/on.wh.gov\/bCFHvGT",
      "display_url" : "on.wh.gov\/bCFHvGT"
    } ]
  },
  "geo" : { },
  "id_str" : "273965561589952512",
  "text" : "On 11\/29 at 1ET: Join NEC's Brian Deese for Office Hours on middle-class tax cuts &amp; #My2k. Have Q's? Ask now w\/ #WHChat http:\/\/t.co\/KHD3sdHk",
  "id" : 273965561589952512,
  "created_at" : "2012-11-29 01:44:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HF Vance III",
      "screen_name" : "SensingPlace",
      "indices" : [ 3, 16 ],
      "id_str" : "213419159",
      "id" : 213419159
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "My2K",
      "indices" : [ 18, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273956070496559105",
  "text" : "RT @SensingPlace: #My2K is keeping this house and keeping it warm for my growing family this winter.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "My2K",
        "indices" : [ 0, 5 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "273955840090849280",
    "text" : "#My2K is keeping this house and keeping it warm for my growing family this winter.",
    "id" : 273955840090849280,
    "created_at" : "2012-11-29 01:05:36 +0000",
    "user" : {
      "name" : "HF Vance III",
      "screen_name" : "SensingPlace",
      "protected" : false,
      "id_str" : "213419159",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/508611077643702272\/6MQY51mQ_normal.jpeg",
      "id" : 213419159,
      "verified" : false
    }
  },
  "id" : 273956070496559105,
  "created_at" : "2012-11-29 01:06:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stacy B",
      "screen_name" : "stacyo28",
      "indices" : [ 3, 12 ],
      "id_str" : "285811870",
      "id" : 285811870
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "My2K",
      "indices" : [ 14, 19 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273954835362095105",
  "text" : "RT @stacyo28: #My2K will go towards paying for my children's daycare expenses.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "My2K",
        "indices" : [ 0, 5 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "273953869476798465",
    "text" : "#My2K will go towards paying for my children's daycare expenses.",
    "id" : 273953869476798465,
    "created_at" : "2012-11-29 00:57:46 +0000",
    "user" : {
      "name" : "Stacy B",
      "screen_name" : "stacyo28",
      "protected" : false,
      "id_str" : "285811870",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/527898945755045888\/_0CGgkPE_normal.jpeg",
      "id" : 285811870,
      "verified" : false
    }
  },
  "id" : 273954835362095105,
  "created_at" : "2012-11-29 01:01:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "My2k",
      "indices" : [ 130, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/lA27To9Y",
      "expanded_url" : "http:\/\/on.wh.gov\/ILCLhHk",
      "display_url" : "on.wh.gov\/ILCLhHk"
    } ]
  },
  "geo" : { },
  "id_str" : "273949563939856384",
  "text" : "President Obama: \"Make your voice heard. Tell members of Congress what a $2,000 tax hike would mean to you.\" http:\/\/t.co\/lA27To9Y #My2k",
  "id" : 273949563939856384,
  "created_at" : "2012-11-29 00:40:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A. A. Peterson",
      "screen_name" : "AprilAsh2012",
      "indices" : [ 3, 16 ],
      "id_str" : "193922141",
      "id" : 193922141
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "My2K",
      "indices" : [ 18, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273944440425545730",
  "text" : "RT @AprilAsh2012: #My2K would help me pay down college debt and support local businesses.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "My2K",
        "indices" : [ 0, 5 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "273942750393675776",
    "text" : "#My2K would help me pay down college debt and support local businesses.",
    "id" : 273942750393675776,
    "created_at" : "2012-11-29 00:13:35 +0000",
    "user" : {
      "name" : "A. A. Peterson",
      "screen_name" : "AprilAsh2012",
      "protected" : false,
      "id_str" : "193922141",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/740615634367569921\/2ndlO5dL_normal.jpg",
      "id" : 193922141,
      "verified" : false
    }
  },
  "id" : 273944440425545730,
  "created_at" : "2012-11-29 00:20:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josenildo Carneiro",
      "screen_name" : "Jojords",
      "indices" : [ 3, 11 ],
      "id_str" : "2945301887",
      "id" : 2945301887
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "My2k",
      "indices" : [ 13, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273942721679474688",
  "text" : "RT @jojords: #My2k is swim team dues for my 2 children for 9 months.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "My2k",
        "indices" : [ 0, 5 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "273941848312135680",
    "text" : "#My2k is swim team dues for my 2 children for 9 months.",
    "id" : 273941848312135680,
    "created_at" : "2012-11-29 00:10:00 +0000",
    "user" : {
      "name" : "Joelle Lapsley",
      "screen_name" : "jojolapsley",
      "protected" : false,
      "id_str" : "136821562",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/477545062239182848\/aFwcVRG7_normal.jpeg",
      "id" : 136821562,
      "verified" : false
    }
  },
  "id" : 273942721679474688,
  "created_at" : "2012-11-29 00:13:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gov. Martin O'Malley",
      "screen_name" : "GovernorOMalley",
      "indices" : [ 3, 19 ],
      "id_str" : "3343532685",
      "id" : 3343532685
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "My2K",
      "indices" : [ 107, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273941845137031168",
  "text" : "RT @GovernorOMalley: More money for middle class families means a stronger economy and more secure future. #My2K",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "My2K",
        "indices" : [ 86, 91 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "273902033583628288",
    "text" : "More money for middle class families means a stronger economy and more secure future. #My2K",
    "id" : 273902033583628288,
    "created_at" : "2012-11-28 21:31:48 +0000",
    "user" : {
      "name" : "Martin O'Malley",
      "screen_name" : "MartinOMalley",
      "protected" : false,
      "id_str" : "15824288",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746107754864009216\/nEV7ylWo_normal.jpg",
      "id" : 15824288,
      "verified" : true
    }
  },
  "id" : 273941845137031168,
  "created_at" : "2012-11-29 00:10:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uD83C\uDF43 Sacha Brady \uD83C\uDF43",
      "screen_name" : "zigged",
      "indices" : [ 3, 10 ],
      "id_str" : "16303669",
      "id" : 16303669
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 95, 106 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "My2k",
      "indices" : [ 12, 17 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273939678418305024",
  "text" : "RT @zigged: #My2k means property taxes &amp; car insurance for (almost) a year. Tweet yours to @whitehouse too!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 83, 94 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "My2k",
        "indices" : [ 0, 5 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "273914673135501312",
    "geo" : { },
    "id_str" : "273937152298078209",
    "in_reply_to_user_id" : 30313925,
    "text" : "#My2k means property taxes &amp; car insurance for (almost) a year. Tweet yours to @whitehouse too!",
    "id" : 273937152298078209,
    "in_reply_to_status_id" : 273914673135501312,
    "created_at" : "2012-11-28 23:51:21 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "\uD83C\uDF43 Sacha Brady \uD83C\uDF43",
      "screen_name" : "zigged",
      "protected" : false,
      "id_str" : "16303669",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/649186207369445376\/YECEsoaT_normal.jpg",
      "id" : 16303669,
      "verified" : false
    }
  },
  "id" : 273939678418305024,
  "created_at" : "2012-11-29 00:01:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Perry",
      "screen_name" : "Rkilla82",
      "indices" : [ 3, 12 ],
      "id_str" : "903019100",
      "id" : 903019100
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "My2K",
      "indices" : [ 14, 19 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273939207683186689",
  "text" : "RT @Rkilla82: #My2K is being able to buy snow boots for my 7 children. Coats that fit! Field trips at school!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "My2K",
        "indices" : [ 0, 5 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "273937353918255104",
    "text" : "#My2K is being able to buy snow boots for my 7 children. Coats that fit! Field trips at school!",
    "id" : 273937353918255104,
    "created_at" : "2012-11-28 23:52:09 +0000",
    "user" : {
      "name" : "Robert Perry",
      "screen_name" : "Rkilla82",
      "protected" : false,
      "id_str" : "903019100",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2760964362\/26b699c37278ce6f5b820a7de9cae200_normal.jpeg",
      "id" : 903019100,
      "verified" : false
    }
  },
  "id" : 273939207683186689,
  "created_at" : "2012-11-28 23:59:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sally Tardiff",
      "screen_name" : "SallyTardiff",
      "indices" : [ 3, 16 ],
      "id_str" : "830249510",
      "id" : 830249510
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "My2K",
      "indices" : [ 18, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273938478218219520",
  "text" : "RT @SallyTardiff: #My2K goes towards paying for heating oil ... can't live in Maine without it ..send Xmas gifts to grandkids, maybe eve ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "My2K",
        "indices" : [ 0, 5 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "273937859935870976",
    "text" : "#My2K goes towards paying for heating oil ... can't live in Maine without it ..send Xmas gifts to grandkids, maybe even a visit once a year!",
    "id" : 273937859935870976,
    "created_at" : "2012-11-28 23:54:09 +0000",
    "user" : {
      "name" : "Sally Tardiff",
      "screen_name" : "SallyTardiff",
      "protected" : false,
      "id_str" : "830249510",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3166229029\/bd49d5b6d3de007677e17b7845c69d96_normal.jpeg",
      "id" : 830249510,
      "verified" : false
    }
  },
  "id" : 273938478218219520,
  "created_at" : "2012-11-28 23:56:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "jearnest44",
      "indices" : [ 3, 14 ],
      "id_str" : "369238541",
      "id" : 369238541
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "my2k",
      "indices" : [ 127, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273934737536598016",
  "text" : "RT @jearnest44: NEW photo of POTUS meeting with business leaders.  Talking fiscal cliff and preventing a middle class tax hike #my2k  ht ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "my2k",
        "indices" : [ 111, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/NpiH8mrd",
        "expanded_url" : "http:\/\/bit.ly\/SqZpEA",
        "display_url" : "bit.ly\/SqZpEA"
      } ]
    },
    "geo" : { },
    "id_str" : "273922007614226432",
    "text" : "NEW photo of POTUS meeting with business leaders.  Talking fiscal cliff and preventing a middle class tax hike #my2k  http:\/\/t.co\/NpiH8mrd",
    "id" : 273922007614226432,
    "created_at" : "2012-11-28 22:51:10 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "jearnest44",
      "protected" : false,
      "id_str" : "369238541",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1769108407\/Twitter_profile_photo_real_normal.JPG",
      "id" : 369238541,
      "verified" : true
    }
  },
  "id" : 273934737536598016,
  "created_at" : "2012-11-28 23:41:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Garcya",
      "screen_name" : "JaGarcya",
      "indices" : [ 3, 12 ],
      "id_str" : "318924743",
      "id" : 318924743
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "my2k",
      "indices" : [ 14, 19 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273923414027280384",
  "text" : "RT @JaGarcya: #my2k can be the difference between affording car insurance, paying for my sons current semester fees for college courses  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "my2k",
        "indices" : [ 0, 5 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "273921540372959232",
    "text" : "#my2k can be the difference between affording car insurance, paying for my sons current semester fees for college courses &amp; buy kids clothes",
    "id" : 273921540372959232,
    "created_at" : "2012-11-28 22:49:19 +0000",
    "user" : {
      "name" : "Garcya",
      "screen_name" : "JaGarcya",
      "protected" : false,
      "id_str" : "318924743",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/566847040747864064\/C0_qY7ni_normal.jpeg",
      "id" : 318924743,
      "verified" : false
    }
  },
  "id" : 273923414027280384,
  "created_at" : "2012-11-28 22:56:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rebecca DeGumba",
      "screen_name" : "54fyting",
      "indices" : [ 3, 12 ],
      "id_str" : "257206623",
      "id" : 257206623
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "My2K",
      "indices" : [ 14, 19 ]
    }, {
      "text" : "My2K",
      "indices" : [ 104, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273922447529615360",
  "text" : "RT @54fyting: #My2K pays for almost ALL of my daughter's tuition. Single mom of two, one income. I need #My2K in my pocket,  I work HARD ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "My2K",
        "indices" : [ 0, 5 ]
      }, {
        "text" : "My2K",
        "indices" : [ 90, 95 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "273921898801426432",
    "text" : "#My2K pays for almost ALL of my daughter's tuition. Single mom of two, one income. I need #My2K in my pocket,  I work HARD for it!",
    "id" : 273921898801426432,
    "created_at" : "2012-11-28 22:50:44 +0000",
    "user" : {
      "name" : "Rebecca DeGumba",
      "screen_name" : "54fyting",
      "protected" : false,
      "id_str" : "257206623",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2868500334\/a9ebc20a30460625eb700b0df50e84aa_normal.jpeg",
      "id" : 257206623,
      "verified" : false
    }
  },
  "id" : 273922447529615360,
  "created_at" : "2012-11-28 22:52:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Criswell",
      "screen_name" : "mrscriswell",
      "indices" : [ 3, 15 ],
      "id_str" : "404917499",
      "id" : 404917499
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "My2k",
      "indices" : [ 17, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273920845045432320",
  "text" : "RT @mrscriswell: #My2k means food in my children's belly, preschool tuition and my student loans",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "My2k",
        "indices" : [ 0, 5 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "273920454580924416",
    "text" : "#My2k means food in my children's belly, preschool tuition and my student loans",
    "id" : 273920454580924416,
    "created_at" : "2012-11-28 22:45:00 +0000",
    "user" : {
      "name" : "Katie Criswell",
      "screen_name" : "mrscriswell",
      "protected" : false,
      "id_str" : "404917499",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/496650638064103424\/2MIHAhdZ_normal.jpeg",
      "id" : 404917499,
      "verified" : false
    }
  },
  "id" : 273920845045432320,
  "created_at" : "2012-11-28 22:46:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Annie \u2693",
      "screen_name" : "Beantownbroadd",
      "indices" : [ 3, 18 ],
      "id_str" : "552948260",
      "id" : 552948260
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "My2k",
      "indices" : [ 20, 25 ]
    }, {
      "text" : "lifeofa25yearold",
      "indices" : [ 115, 132 ]
    }, {
      "text" : "2k",
      "indices" : [ 133, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273920160581177345",
  "text" : "RT @Beantownbroadd: #My2k goes to my financial aid bills from college, insurance bills, and daily living expenses! #lifeofa25yearold #2k",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "My2k",
        "indices" : [ 0, 5 ]
      }, {
        "text" : "lifeofa25yearold",
        "indices" : [ 95, 112 ]
      }, {
        "text" : "2k",
        "indices" : [ 113, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 42.5773968818, -71.2382236892 ]
    },
    "id_str" : "273916649470570496",
    "text" : "#My2k goes to my financial aid bills from college, insurance bills, and daily living expenses! #lifeofa25yearold #2k",
    "id" : 273916649470570496,
    "created_at" : "2012-11-28 22:29:53 +0000",
    "user" : {
      "name" : "Annie \u2693",
      "screen_name" : "Beantownbroadd",
      "protected" : false,
      "id_str" : "552948260",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000073637025\/65cd39125e4744fba8dc3adfe031f5b8_normal.jpeg",
      "id" : 552948260,
      "verified" : false
    }
  },
  "id" : 273920160581177345,
  "created_at" : "2012-11-28 22:43:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brandy DeWeese",
      "screen_name" : "Brandy_DeWeese",
      "indices" : [ 3, 18 ],
      "id_str" : "203962325",
      "id" : 203962325
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 20, 31 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "my2k",
      "indices" : [ 32, 37 ]
    }, {
      "text" : "APRN",
      "indices" : [ 74, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273919309896622082",
  "text" : "RT @Brandy_DeWeese: @whitehouse #my2k is 1\/3 of one semester's tuition in #APRN school. Studying to provide primary health care for my c ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "my2k",
        "indices" : [ 12, 17 ]
      }, {
        "text" : "APRN",
        "indices" : [ 54, 59 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "273914673135501312",
    "geo" : { },
    "id_str" : "273917088589029376",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse #my2k is 1\/3 of one semester's tuition in #APRN school. Studying to provide primary health care for my community.",
    "id" : 273917088589029376,
    "in_reply_to_status_id" : 273914673135501312,
    "created_at" : "2012-11-28 22:31:37 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Brandy DeWeese",
      "screen_name" : "Brandy_DeWeese",
      "protected" : false,
      "id_str" : "203962325",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/504527321554894848\/nwpBXNDw_normal.jpeg",
      "id" : 203962325,
      "verified" : false
    }
  },
  "id" : 273919309896622082,
  "created_at" : "2012-11-28 22:40:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IndepInMO",
      "screen_name" : "IndepInMO",
      "indices" : [ 3, 13 ],
      "id_str" : "455291534",
      "id" : 455291534
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "my2k",
      "indices" : [ 22, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273916527584100352",
  "text" : "RT @IndepInMO: Losing #my2k would be devastating for us. Would have to forego some bills, upgrades for home heating and car repairs (tra ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "my2k",
        "indices" : [ 7, 12 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "273915051998593024",
    "text" : "Losing #my2k would be devastating for us. Would have to forego some bills, upgrades for home heating and car repairs (transp for work).",
    "id" : 273915051998593024,
    "created_at" : "2012-11-28 22:23:32 +0000",
    "user" : {
      "name" : "IndepInMO",
      "screen_name" : "IndepInMO",
      "protected" : false,
      "id_str" : "455291534",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3468665601\/539e2f46714232d9a9e79448e51c6759_normal.jpeg",
      "id" : 455291534,
      "verified" : false
    }
  },
  "id" : 273916527584100352,
  "created_at" : "2012-11-28 22:29:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve",
      "screen_name" : "koolking83",
      "indices" : [ 3, 14 ],
      "id_str" : "21164301",
      "id" : 21164301
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "my2k",
      "indices" : [ 16, 21 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273916148276416513",
  "text" : "RT @koolking83: #my2k Two mortgage payments...or seven car payments...or ten months of gas to get to work... or a year of student loan p ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "my2k",
        "indices" : [ 0, 5 ]
      }, {
        "text" : "needit",
        "indices" : [ 128, 135 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "273915208471310338",
    "text" : "#my2k Two mortgage payments...or seven car payments...or ten months of gas to get to work... or a year of student loan payments #needit",
    "id" : 273915208471310338,
    "created_at" : "2012-11-28 22:24:09 +0000",
    "user" : {
      "name" : "Steve",
      "screen_name" : "koolking83",
      "protected" : false,
      "id_str" : "21164301",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/648127713665019904\/L8hDZTiu_normal.jpg",
      "id" : 21164301,
      "verified" : false
    }
  },
  "id" : 273916148276416513,
  "created_at" : "2012-11-28 22:27:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Crazy Cupcake \u264A",
      "screen_name" : "QueenCupcakee",
      "indices" : [ 3, 17 ],
      "id_str" : "293786983",
      "id" : 293786983
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "My2k",
      "indices" : [ 19, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273915608658214913",
  "text" : "RT @QueenCupcakee: #My2k means that my kids can get a family vacation this year. Don't all kids deserve a Disney trip?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "My2k",
        "indices" : [ 0, 5 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "273915317196029954",
    "text" : "#My2k means that my kids can get a family vacation this year. Don't all kids deserve a Disney trip?",
    "id" : 273915317196029954,
    "created_at" : "2012-11-28 22:24:35 +0000",
    "user" : {
      "name" : "Crazy Cupcake \u264A",
      "screen_name" : "QueenCupcakee",
      "protected" : false,
      "id_str" : "293786983",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3025379595\/6caae3cb06a74e84a6ab266ffea311d2_normal.jpeg",
      "id" : 293786983,
      "verified" : false
    }
  },
  "id" : 273915608658214913,
  "created_at" : "2012-11-28 22:25:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/273914673135501312\/photo\/1",
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/P2E1vlEd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A80j8adCQAARiJf.jpg",
      "id_str" : "273914673139695616",
      "id" : 273914673139695616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A80j8adCQAARiJf.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 403,
        "resize" : "fit",
        "w" : 403
      }, {
        "h" : 403,
        "resize" : "fit",
        "w" : 403
      }, {
        "h" : 403,
        "resize" : "fit",
        "w" : 403
      } ],
      "display_url" : "pic.twitter.com\/P2E1vlEd"
    } ],
    "hashtags" : [ {
      "text" : "My2k",
      "indices" : [ 110, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273914673135501312",
  "text" : "To the average middle-class family, $2,000 means 2 months of mortgage payments. What does $2,000 mean to you? #My2k http:\/\/t.co\/P2E1vlEd",
  "id" : 273914673135501312,
  "created_at" : "2012-11-28 22:22:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cheryl",
      "screen_name" : "fallingleaves",
      "indices" : [ 3, 17 ],
      "id_str" : "15017836",
      "id" : 15017836
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "my2k",
      "indices" : [ 19, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273914359900680192",
  "text" : "RT @fallingleaves: #my2k 3 months of mortgage payments or groceries or an entire years property tax. 2k is a lot for some families.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "my2k",
        "indices" : [ 0, 5 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "273913276654579712",
    "text" : "#my2k 3 months of mortgage payments or groceries or an entire years property tax. 2k is a lot for some families.",
    "id" : 273913276654579712,
    "created_at" : "2012-11-28 22:16:28 +0000",
    "user" : {
      "name" : "Cheryl",
      "screen_name" : "fallingleaves",
      "protected" : false,
      "id_str" : "15017836",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797313365383090177\/xOsugUaa_normal.jpg",
      "id" : 15017836,
      "verified" : false
    }
  },
  "id" : 273914359900680192,
  "created_at" : "2012-11-28 22:20:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary Hirsch",
      "screen_name" : "swellgalmary",
      "indices" : [ 3, 16 ],
      "id_str" : "21488250",
      "id" : 21488250
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "My2K",
      "indices" : [ 18, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273914049509597184",
  "text" : "RT @swellgalmary: #My2K goes to prescriptions, mortgage, and other necessities. It's not discretionary income for me. I need it to keep  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "My2K",
        "indices" : [ 0, 5 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "273913331490897921",
    "text" : "#My2K goes to prescriptions, mortgage, and other necessities. It's not discretionary income for me. I need it to keep on keeping on.",
    "id" : 273913331490897921,
    "created_at" : "2012-11-28 22:16:41 +0000",
    "user" : {
      "name" : "Mary Hirsch",
      "screen_name" : "swellgalmary",
      "protected" : false,
      "id_str" : "21488250",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1197246119\/2_normal.jpg",
      "id" : 21488250,
      "verified" : false
    }
  },
  "id" : 273914049509597184,
  "created_at" : "2012-11-28 22:19:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tidbits_Trinkets",
      "screen_name" : "TidbitsTrinkets",
      "indices" : [ 3, 19 ],
      "id_str" : "326912531",
      "id" : 326912531
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "My2k",
      "indices" : [ 21, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273912958361415680",
  "text" : "RT @TidbitsTrinkets: #My2k means coats, shoes, &amp; school supplies for my 4 growing teenagers!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "My2k",
        "indices" : [ 0, 5 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "273912661635391490",
    "text" : "#My2k means coats, shoes, &amp; school supplies for my 4 growing teenagers!",
    "id" : 273912661635391490,
    "created_at" : "2012-11-28 22:14:02 +0000",
    "user" : {
      "name" : "Tidbits_Trinkets",
      "screen_name" : "TidbitsTrinkets",
      "protected" : false,
      "id_str" : "326912531",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1765926428\/Rosie_Buy_Handmade_Avatar_normal.png",
      "id" : 326912531,
      "verified" : false
    }
  },
  "id" : 273912958361415680,
  "created_at" : "2012-11-28 22:15:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "My2k",
      "indices" : [ 131, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/p3ZVAHvt",
      "expanded_url" : "http:\/\/wh.gov\/my2k",
      "display_url" : "wh.gov\/my2k"
    } ]
  },
  "geo" : { },
  "id_str" : "273905458044076032",
  "text" : "Over 40,000 Americans have visited http:\/\/t.co\/p3ZVAHvt to share what $2,000 means to them. What does it mean to you? Tell us with #My2k",
  "id" : 273905458044076032,
  "created_at" : "2012-11-28 21:45:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trina McNamara",
      "screen_name" : "Mathemomician",
      "indices" : [ 3, 17 ],
      "id_str" : "21765817",
      "id" : 21765817
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "My2K",
      "indices" : [ 19, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273901232274415616",
  "text" : "RT @Mathemomician: #My2K = groceries, tuition and student loans. Maybe even a zoo membership for some family time with my 4 kids.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "My2K",
        "indices" : [ 0, 5 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "273900343610466305",
    "text" : "#My2K = groceries, tuition and student loans. Maybe even a zoo membership for some family time with my 4 kids.",
    "id" : 273900343610466305,
    "created_at" : "2012-11-28 21:25:05 +0000",
    "user" : {
      "name" : "Trina McNamara",
      "screen_name" : "Mathemomician",
      "protected" : false,
      "id_str" : "21765817",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/740241893\/100_2269_normal.JPG",
      "id" : 21765817,
      "verified" : false
    }
  },
  "id" : 273901232274415616,
  "created_at" : "2012-11-28 21:28:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "My2K",
      "indices" : [ 19, 24 ]
    }, {
      "text" : "Sandy",
      "indices" : [ 50, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273894074367500291",
  "text" : "RT @aishabonitaaa: #My2K  Repairing my house from #Sandy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "My2K",
        "indices" : [ 0, 5 ]
      }, {
        "text" : "Sandy",
        "indices" : [ 31, 37 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "273886334479896577",
    "text" : "#My2K  Repairing my house from #Sandy",
    "id" : 273886334479896577,
    "created_at" : "2012-11-28 20:29:25 +0000",
    "user" : {
      "name" : "Davis, B",
      "screen_name" : "_aishaax",
      "protected" : false,
      "id_str" : "829151971",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/772998232259584000\/AAZmdyG5_normal.jpg",
      "id" : 829151971,
      "verified" : false
    }
  },
  "id" : 273894074367500291,
  "created_at" : "2012-11-28 21:00:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth",
      "screen_name" : "elizab007",
      "indices" : [ 3, 13 ],
      "id_str" : "621189557",
      "id" : 621189557
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 15, 26 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "My2K",
      "indices" : [ 27, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273892750716444675",
  "text" : "RT @elizab007: @whitehouse #My2K means to my family is getting our 10 year old car repaired which we cannot afford at the moment.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "My2K",
        "indices" : [ 12, 17 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "273890628553801729",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse #My2K means to my family is getting our 10 year old car repaired which we cannot afford at the moment.",
    "id" : 273890628553801729,
    "created_at" : "2012-11-28 20:46:29 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Elizabeth",
      "screen_name" : "elizab007",
      "protected" : false,
      "id_str" : "621189557",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/472030159533395968\/hjJRGIqF_normal.jpeg",
      "id" : 621189557,
      "verified" : false
    }
  },
  "id" : 273892750716444675,
  "created_at" : "2012-11-28 20:54:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/PoliticlSvvyPhD\/status\/273883495150022657\/photo\/1",
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/ptcZlkUy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A80HlnbCcAAfwu-.jpg",
      "id_str" : "273883495158411264",
      "id" : 273883495158411264,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A80HlnbCcAAfwu-.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 403,
        "resize" : "fit",
        "w" : 403
      }, {
        "h" : 403,
        "resize" : "fit",
        "w" : 403
      }, {
        "h" : 403,
        "resize" : "fit",
        "w" : 403
      } ],
      "display_url" : "pic.twitter.com\/ptcZlkUy"
    } ],
    "hashtags" : [ {
      "text" : "2k",
      "indices" : [ 26, 29 ]
    }, {
      "text" : "My2k",
      "indices" : [ 68, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273884369985339392",
  "text" : "RT @PoliticlSvvyPhD: What #2k means to the average American family. #My2k http:\/\/t.co\/ptcZlkUy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PoliticlSvvyPhD\/status\/273883495150022657\/photo\/1",
        "indices" : [ 53, 73 ],
        "url" : "http:\/\/t.co\/ptcZlkUy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A80HlnbCcAAfwu-.jpg",
        "id_str" : "273883495158411264",
        "id" : 273883495158411264,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A80HlnbCcAAfwu-.jpg",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 403,
          "resize" : "fit",
          "w" : 403
        }, {
          "h" : 403,
          "resize" : "fit",
          "w" : 403
        }, {
          "h" : 403,
          "resize" : "fit",
          "w" : 403
        } ],
        "display_url" : "pic.twitter.com\/ptcZlkUy"
      } ],
      "hashtags" : [ {
        "text" : "2k",
        "indices" : [ 5, 8 ]
      }, {
        "text" : "My2k",
        "indices" : [ 47, 52 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "273883495150022657",
    "text" : "What #2k means to the average American family. #My2k http:\/\/t.co\/ptcZlkUy",
    "id" : 273883495150022657,
    "created_at" : "2012-11-28 20:18:08 +0000",
    "user" : {
      "name" : "Nicki",
      "screen_name" : "NickiMayPhD",
      "protected" : false,
      "id_str" : "128259816",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719204328381222916\/2EXqn7L9_normal.jpg",
      "id" : 128259816,
      "verified" : false
    }
  },
  "id" : 273884369985339392,
  "created_at" : "2012-11-28 20:21:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary Olsen",
      "screen_name" : "maryolsen46107",
      "indices" : [ 3, 18 ],
      "id_str" : "248836005",
      "id" : 248836005
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 20, 31 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MY2K",
      "indices" : [ 32, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273883542046511104",
  "text" : "RT @maryolsen46107: @whitehouse #MY2K means choosing between meds for lung disease or food and heat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MY2K",
        "indices" : [ 12, 17 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 39.7015667, -86.0833301 ]
    },
    "id_str" : "273881620677812224",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse #MY2K means choosing between meds for lung disease or food and heat",
    "id" : 273881620677812224,
    "created_at" : "2012-11-28 20:10:41 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Mary Olsen",
      "screen_name" : "maryolsen46107",
      "protected" : false,
      "id_str" : "248836005",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/795823183513395201\/i1nwRY1f_normal.jpg",
      "id" : 248836005,
      "verified" : false
    }
  },
  "id" : 273883542046511104,
  "created_at" : "2012-11-28 20:18:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A Vicious Frieze",
      "screen_name" : "completelydark",
      "indices" : [ 3, 18 ],
      "id_str" : "39671383",
      "id" : 39671383
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "My2K",
      "indices" : [ 133, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/4QdhBR0e",
      "expanded_url" : "http:\/\/wh.gov\/my2k",
      "display_url" : "wh.gov\/my2k"
    } ]
  },
  "geo" : { },
  "id_str" : "273882641416212480",
  "text" : "RT @completelydark: I\u2019m speaking out about what $2,000 means to me. Join me and share what $2,000 means to you: http:\/\/t.co\/4QdhBR0e #My2K",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "My2K",
        "indices" : [ 113, 118 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 112 ],
        "url" : "http:\/\/t.co\/4QdhBR0e",
        "expanded_url" : "http:\/\/wh.gov\/my2k",
        "display_url" : "wh.gov\/my2k"
      } ]
    },
    "geo" : { },
    "id_str" : "273881786864500736",
    "text" : "I\u2019m speaking out about what $2,000 means to me. Join me and share what $2,000 means to you: http:\/\/t.co\/4QdhBR0e #My2K",
    "id" : 273881786864500736,
    "created_at" : "2012-11-28 20:11:21 +0000",
    "user" : {
      "name" : "A Vicious Frieze",
      "screen_name" : "completelydark",
      "protected" : false,
      "id_str" : "39671383",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766827991594782722\/L7kS5FGs_normal.jpg",
      "id" : 39671383,
      "verified" : false
    }
  },
  "id" : 273882641416212480,
  "created_at" : "2012-11-28 20:14:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryant Campbell",
      "screen_name" : "bryantcamp",
      "indices" : [ 3, 14 ],
      "id_str" : "746208511",
      "id" : 746208511
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 16, 27 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "my2k",
      "indices" : [ 28, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273881795441860608",
  "text" : "RT @bryantcamp: @whitehouse #my2k is about the future of the middle class. That will affect you no matter how much you make each year.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "my2k",
        "indices" : [ 12, 17 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "273881117470380032",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse #my2k is about the future of the middle class. That will affect you no matter how much you make each year.",
    "id" : 273881117470380032,
    "created_at" : "2012-11-28 20:08:41 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Bryant Campbell",
      "screen_name" : "bryantcamp",
      "protected" : false,
      "id_str" : "746208511",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/666829956283002880\/g9OhIc8d_normal.jpg",
      "id" : 746208511,
      "verified" : false
    }
  },
  "id" : 273881795441860608,
  "created_at" : "2012-11-28 20:11:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Debbie Wroe",
      "screen_name" : "deb3052",
      "indices" : [ 3, 11 ],
      "id_str" : "348112945",
      "id" : 348112945
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 13, 24 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "my2k",
      "indices" : [ 25, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273881407355514881",
  "text" : "RT @deb3052: @whitehouse #my2k means not having to choose between food, health care, rent or utilities.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "my2k",
        "indices" : [ 12, 17 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "273881145215700993",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse #my2k means not having to choose between food, health care, rent or utilities.",
    "id" : 273881145215700993,
    "created_at" : "2012-11-28 20:08:48 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Debbie Wroe",
      "screen_name" : "deb3052",
      "protected" : false,
      "id_str" : "348112945",
      "profile_image_url_https" : "https:\/\/abs.twimg.com\/sticky\/default_profile_images\/default_profile_5_normal.png",
      "id" : 348112945,
      "verified" : false
    }
  },
  "id" : 273881407355514881,
  "created_at" : "2012-11-28 20:09:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tiffany Fichter",
      "screen_name" : "tmarti24",
      "indices" : [ 3, 12 ],
      "id_str" : "114567397",
      "id" : 114567397
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 14, 25 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "My2K",
      "indices" : [ 64, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273881187922112512",
  "text" : "RT @tmarti24: @whitehouse that's my 4 children's school clothes #My2K",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "My2K",
        "indices" : [ 50, 55 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "273837827140235265",
    "geo" : { },
    "id_str" : "273879377190744066",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse that's my 4 children's school clothes #My2K",
    "id" : 273879377190744066,
    "in_reply_to_status_id" : 273837827140235265,
    "created_at" : "2012-11-28 20:01:46 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Tiffany Fichter",
      "screen_name" : "tmarti24",
      "protected" : false,
      "id_str" : "114567397",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2797548480\/839d5f19044d3b1e40d2f9e31e88e2f7_normal.jpeg",
      "id" : 114567397,
      "verified" : false
    }
  },
  "id" : 273881187922112512,
  "created_at" : "2012-11-28 20:08:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 100, 111 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "my2k",
      "indices" : [ 16, 21 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273880697201098752",
  "text" : "RT @RyanMHurst: #my2k Allows me to pay my bills and save a little money for my future. I'm glad the @whitehouse has my back",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 84, 95 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "my2k",
        "indices" : [ 0, 5 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "273879607516729344",
    "text" : "#my2k Allows me to pay my bills and save a little money for my future. I'm glad the @whitehouse has my back",
    "id" : 273879607516729344,
    "created_at" : "2012-11-28 20:02:41 +0000",
    "user" : {
      "name" : "Ryan",
      "screen_name" : "RyanProgress",
      "protected" : false,
      "id_str" : "309273477",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/718843759736131585\/Y0iQwSjk_normal.jpg",
      "id" : 309273477,
      "verified" : false
    }
  },
  "id" : 273880697201098752,
  "created_at" : "2012-11-28 20:07:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heather Corby",
      "screen_name" : "cajungal78",
      "indices" : [ 3, 14 ],
      "id_str" : "198276846",
      "id" : 198276846
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 16, 27 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "my2k",
      "indices" : [ 28, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273878549130268673",
  "text" : "RT @cajungal78: @whitehouse #my2k Being able to know I will have a roof over my head and comfort in keeping the lights on.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "my2k",
        "indices" : [ 12, 17 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "273877358811963394",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse #my2k Being able to know I will have a roof over my head and comfort in keeping the lights on.",
    "id" : 273877358811963394,
    "created_at" : "2012-11-28 19:53:45 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Heather Corby",
      "screen_name" : "cajungal78",
      "protected" : false,
      "id_str" : "198276846",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/685992835053678593\/0gqGzw83_normal.jpg",
      "id" : 198276846,
      "verified" : false
    }
  },
  "id" : 273878549130268673,
  "created_at" : "2012-11-28 19:58:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shawna B",
      "screen_name" : "MustangShawni",
      "indices" : [ 3, 17 ],
      "id_str" : "86165825",
      "id" : 86165825
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 19, 30 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "My2K",
      "indices" : [ 31, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273875384213327873",
  "text" : "RT @MustangShawni: @whitehouse #My2K is life for ppl like me.. gas for work, food for my son, rent, etc. It would be any chance of an em ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "My2K",
        "indices" : [ 12, 17 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "273871107306700800",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse #My2K is life for ppl like me.. gas for work, food for my son, rent, etc. It would be any chance of an emergency savings gone.",
    "id" : 273871107306700800,
    "created_at" : "2012-11-28 19:28:54 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Shawna B",
      "screen_name" : "MustangShawni",
      "protected" : false,
      "id_str" : "86165825",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/713458095456915462\/mZBbWxUx_normal.jpg",
      "id" : 86165825,
      "verified" : false
    }
  },
  "id" : 273875384213327873,
  "created_at" : "2012-11-28 19:45:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alie Bol",
      "screen_name" : "aliebol",
      "indices" : [ 3, 11 ],
      "id_str" : "50117762",
      "id" : 50117762
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "My2k",
      "indices" : [ 13, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273875188066680833",
  "text" : "RT @aliebol: #My2k is being able to buy gas and fix my car so I'm not afraid my car is going to breakdown on my commute to work",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "My2k",
        "indices" : [ 0, 5 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "273871190790119424",
    "text" : "#My2k is being able to buy gas and fix my car so I'm not afraid my car is going to breakdown on my commute to work",
    "id" : 273871190790119424,
    "created_at" : "2012-11-28 19:29:14 +0000",
    "user" : {
      "name" : "Alie Bol",
      "screen_name" : "aliebol",
      "protected" : false,
      "id_str" : "50117762",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/494550835183882241\/sxLLMfXJ_normal.jpeg",
      "id" : 50117762,
      "verified" : false
    }
  },
  "id" : 273875188066680833,
  "created_at" : "2012-11-28 19:45:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Strater",
      "screen_name" : "jeffstrater",
      "indices" : [ 3, 15 ],
      "id_str" : "15268490",
      "id" : 15268490
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 98, 109 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "My2k",
      "indices" : [ 17, 22 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273870854415323138",
  "text" : "RT @jeffstrater: #My2k pays rent, gas, food, student loans. Have to watch every dollar. Thank you @whitehouse for fighting for me.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 81, 92 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "My2k",
        "indices" : [ 0, 5 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "273870429356183554",
    "text" : "#My2k pays rent, gas, food, student loans. Have to watch every dollar. Thank you @whitehouse for fighting for me.",
    "id" : 273870429356183554,
    "created_at" : "2012-11-28 19:26:13 +0000",
    "user" : {
      "name" : "Jeff Strater",
      "screen_name" : "jeffstrater",
      "protected" : false,
      "id_str" : "15268490",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/740375778957742080\/BhPcrrE0_normal.jpg",
      "id" : 15268490,
      "verified" : true
    }
  },
  "id" : 273870854415323138,
  "created_at" : "2012-11-28 19:27:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "My2k",
      "indices" : [ 131, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/FP7NjdEA",
      "expanded_url" : "http:\/\/on.wh.gov\/UlZNROb",
      "display_url" : "on.wh.gov\/UlZNROb"
    } ]
  },
  "geo" : { },
  "id_str" : "273869661437849601",
  "text" : "\"I can only do it with the help of the American people.\" -President Obama on extending middle-class tax cuts: http:\/\/t.co\/FP7NjdEA #My2k",
  "id" : 273869661437849601,
  "created_at" : "2012-11-28 19:23:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 25, 33 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "My2k",
      "indices" : [ 7, 12 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/94NllMa7",
      "expanded_url" : "http:\/\/on.wh.gov\/8Bx3NPT",
      "display_url" : "on.wh.gov\/8Bx3NPT"
    } ]
  },
  "geo" : { },
  "id_str" : "273852516918239232",
  "text" : "Why is #My2k trending on @twitter in the US? Find out and share your story: http:\/\/t.co\/94NllMa7",
  "id" : 273852516918239232,
  "created_at" : "2012-11-28 18:15:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Primavera",
      "screen_name" : "danprim19",
      "indices" : [ 3, 13 ],
      "id_str" : "366370088",
      "id" : 366370088
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 15, 26 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "My2K",
      "indices" : [ 112, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273852109580021760",
  "text" : "RT @danprim19: @whitehouse $2K is about what our family pays for therapy copays for our special needs children. #My2K",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "My2K",
        "indices" : [ 97, 102 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "273837827140235265",
    "geo" : { },
    "id_str" : "273851228813938688",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse $2K is about what our family pays for therapy copays for our special needs children. #My2K",
    "id" : 273851228813938688,
    "in_reply_to_status_id" : 273837827140235265,
    "created_at" : "2012-11-28 18:09:55 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Daniel Primavera",
      "screen_name" : "danprim19",
      "protected" : false,
      "id_str" : "366370088",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1525391948\/MyPortrait1_normal.jpg",
      "id" : 366370088,
      "verified" : false
    }
  },
  "id" : 273852109580021760,
  "created_at" : "2012-11-28 18:13:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chelle",
      "screen_name" : "chellegaylor24",
      "indices" : [ 3, 18 ],
      "id_str" : "35828351",
      "id" : 35828351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "My2K",
      "indices" : [ 20, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273848098663571456",
  "text" : "RT @chellegaylor24: #My2K keeps my son in sports and guitar lessons for a year.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "My2K",
        "indices" : [ 0, 5 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "273847501952540672",
    "text" : "#My2K keeps my son in sports and guitar lessons for a year.",
    "id" : 273847501952540672,
    "created_at" : "2012-11-28 17:55:06 +0000",
    "user" : {
      "name" : "Chelle",
      "screen_name" : "chellegaylor24",
      "protected" : false,
      "id_str" : "35828351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798211086407245830\/w9RJ2Se9_normal.jpg",
      "id" : 35828351,
      "verified" : false
    }
  },
  "id" : 273848098663571456,
  "created_at" : "2012-11-28 17:57:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "geejayeff",
      "screen_name" : "geejayeff",
      "indices" : [ 3, 13 ],
      "id_str" : "17164664",
      "id" : 17164664
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "My2k",
      "indices" : [ 86, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273841764866084864",
  "text" : "RT @geejayeff: I hope congress does the right thing and passes middle class tax cuts. #My2k is money that goes right back into the economy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "My2k",
        "indices" : [ 71, 76 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "273841095375454208",
    "text" : "I hope congress does the right thing and passes middle class tax cuts. #My2k is money that goes right back into the economy",
    "id" : 273841095375454208,
    "created_at" : "2012-11-28 17:29:39 +0000",
    "user" : {
      "name" : "geejayeff",
      "screen_name" : "geejayeff",
      "protected" : false,
      "id_str" : "17164664",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/554007861726957569\/J1KHlCkU_normal.jpeg",
      "id" : 17164664,
      "verified" : false
    }
  },
  "id" : 273841764866084864,
  "created_at" : "2012-11-28 17:32:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LWJohnson",
      "screen_name" : "LWayneJohnson",
      "indices" : [ 3, 17 ],
      "id_str" : "382425362",
      "id" : 382425362
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "My2k",
      "indices" : [ 19, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273840897026846721",
  "text" : "RT @LWayneJohnson: #My2k.. My wife and I agree with president, 2k a month means food on the table, medical bills paid and gas for our ca ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "My2k",
        "indices" : [ 0, 5 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "273840576334557184",
    "text" : "#My2k.. My wife and I agree with president, 2k a month means food on the table, medical bills paid and gas for our car. Do the right thing!",
    "id" : 273840576334557184,
    "created_at" : "2012-11-28 17:27:35 +0000",
    "user" : {
      "name" : "LWJohnson",
      "screen_name" : "LWayneJohnson",
      "protected" : false,
      "id_str" : "382425362",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1572506512\/lwaynejohnson_normal.jpg",
      "id" : 382425362,
      "verified" : false
    }
  },
  "id" : 273840897026846721,
  "created_at" : "2012-11-28 17:28:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary Bademus",
      "screen_name" : "bademus",
      "indices" : [ 3, 11 ],
      "id_str" : "73025452",
      "id" : 73025452
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MY2K",
      "indices" : [ 123, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273840327117377537",
  "text" : "RT @bademus: Refinanced home 4 sons tuition, with higher payment a $2000 tax increase right now would be a hardship for me #MY2K",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MY2K",
        "indices" : [ 110, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "273838553883082753",
    "text" : "Refinanced home 4 sons tuition, with higher payment a $2000 tax increase right now would be a hardship for me #MY2K",
    "id" : 273838553883082753,
    "created_at" : "2012-11-28 17:19:33 +0000",
    "user" : {
      "name" : "Mary Bademus",
      "screen_name" : "bademus",
      "protected" : false,
      "id_str" : "73025452",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1181756295\/coolsymbol_normal.gif",
      "id" : 73025452,
      "verified" : false
    }
  },
  "id" : 273840327117377537,
  "created_at" : "2012-11-28 17:26:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "My2K",
      "indices" : [ 121, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273838960034340864",
  "text" : "RT @VP: Unless Congress acts, middle-class families will pay $2k more in taxes in 2013. Tell us what $2k means to you w\/ #My2K: http:\/\/t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "My2K",
        "indices" : [ 113, 118 ]
      } ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/0yNiLO4P",
        "expanded_url" : "http:\/\/wh.gov\/my2k",
        "display_url" : "wh.gov\/my2k"
      } ]
    },
    "geo" : { },
    "id_str" : "273837827563876353",
    "text" : "Unless Congress acts, middle-class families will pay $2k more in taxes in 2013. Tell us what $2k means to you w\/ #My2K: http:\/\/t.co\/0yNiLO4P",
    "id" : 273837827563876353,
    "created_at" : "2012-11-28 17:16:40 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 273838960034340864,
  "created_at" : "2012-11-28 17:21:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/273837827140235265\/photo\/1",
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/l0CBS0pW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A8zeDY1CMAE0GjE.jpg",
      "id_str" : "273837827148623873",
      "id" : 273837827148623873,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A8zeDY1CMAE0GjE.jpg",
      "sizes" : [ {
        "h" : 280,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 190,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 280,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 280,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/l0CBS0pW"
    } ],
    "hashtags" : [ {
      "text" : "My2k",
      "indices" : [ 43, 48 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273837827140235265",
  "text" : "What does $2,000 mean to you? Tell us with #My2k http:\/\/t.co\/l0CBS0pW",
  "id" : 273837827140235265,
  "created_at" : "2012-11-28 17:16:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "My2k",
      "indices" : [ 25, 30 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/p3ZVAHvt",
      "expanded_url" : "http:\/\/wh.gov\/my2k",
      "display_url" : "wh.gov\/my2k"
    } ]
  },
  "geo" : { },
  "id_str" : "273837334699577345",
  "text" : "\"Tweet using the hashtag #My2k\" \u2014President Obama calls on Americans to speak out to extend middle-class tax cuts: http:\/\/t.co\/p3ZVAHvt",
  "id" : 273837334699577345,
  "created_at" : "2012-11-28 17:14:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273836207325200384",
  "text" : "RT @jesseclee44: Obama asks folks to join fight to protect middle class tax cut: \"when enough people get involved we have a pretty good  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "My2K",
        "indices" : [ 133, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "273835755468632064",
    "text" : "Obama asks folks to join fight to protect middle class tax cut: \"when enough people get involved we have a pretty good track record\" #My2K",
    "id" : 273835755468632064,
    "created_at" : "2012-11-28 17:08:26 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 273836207325200384,
  "created_at" : "2012-11-28 17:10:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "My2K",
      "indices" : [ 127, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273835972960079872",
  "text" : "President Obama: \"Call your Members of Congress, write them an email, post on their Facebook walls. Tweet it using the hashtag #My2K\"",
  "id" : 273835972960079872,
  "created_at" : "2012-11-28 17:09:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "My2k",
      "indices" : [ 137, 142 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273835814184693760",
  "text" : "President Obama on extending tax cuts for the middle class: \"This is our biggest challenge yet &amp; it\u2019s one we can only meet together\" #My2k",
  "id" : 273835814184693760,
  "created_at" : "2012-11-28 17:08:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273835451943620608",
  "text" : "President Obama: \"If there\u2019s one thing I\u2019ve learned, it\u2019s that when the American people speak loudly enough, Congress listens.\"",
  "id" : 273835451943620608,
  "created_at" : "2012-11-28 17:07:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273835221428862977",
  "text" : "President Obama: \"A clear majority of Americans \u2013 not just Democrats, but Republicans, and Independents \u2013 agreed with a balanced approach.\"",
  "id" : 273835221428862977,
  "created_at" : "2012-11-28 17:06:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "My2K",
      "indices" : [ 127, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273834421927428096",
  "text" : "President Obama: \"If Congress does nothing...a typical middle-class family of four would see its income taxes go up by $2,200\" #My2K",
  "id" : 273834421927428096,
  "created_at" : "2012-11-28 17:03:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273834265542787073",
  "text" : "RT @WHLive: President Obama: \u201CThe voices of the American people have to be part of this debate, and so I asked some friends to join me h ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "273834045593513984",
    "text" : "President Obama: \u201CThe voices of the American people have to be part of this debate, and so I asked some friends to join me here today.\u201D",
    "id" : 273834045593513984,
    "created_at" : "2012-11-28 17:01:38 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 273834265542787073,
  "created_at" : "2012-11-28 17:02:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/c7agBhtL",
      "expanded_url" : "http:\/\/on.wh.gov\/6lS5aMv",
      "display_url" : "on.wh.gov\/6lS5aMv"
    } ]
  },
  "geo" : { },
  "id_str" : "273833924973690880",
  "text" : "Happening now: President Obama discusses the importance of extending middle class tax cuts. Watch: http:\/\/t.co\/c7agBhtL",
  "id" : 273833924973690880,
  "created_at" : "2012-11-28 17:01:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/qHKhzHeB",
      "expanded_url" : "http:\/\/at.wh.gov\/fDkT9",
      "display_url" : "at.wh.gov\/fDkT9"
    } ]
  },
  "geo" : { },
  "id_str" : "273743195584729088",
  "text" : "Today, President Obama will call on all Americans to make their voices heard to extend middle-class tax cuts: http:\/\/t.co\/qHKhzHeB",
  "id" : 273743195584729088,
  "created_at" : "2012-11-28 11:00:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 40, 43 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/273661970119524352\/photo\/1",
      "indices" : [ 123, 143 ],
      "url" : "http:\/\/t.co\/Uds4YncX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A8w-HKXCAAAG8hX.jpg",
      "id_str" : "273661970123718656",
      "id" : 273661970123718656,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A8w-HKXCAAAG8hX.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Uds4YncX"
    } ],
    "hashtags" : [ {
      "text" : "Sandy",
      "indices" : [ 98, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273661970119524352",
  "text" : "Photo of the Day: President Obama &amp; @VP Biden meet with HUD Sec. Donovan to discuss Hurricane #Sandy recovery efforts: http:\/\/t.co\/Uds4YncX",
  "id" : 273661970119524352,
  "created_at" : "2012-11-28 05:37:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/273638712506740737\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/44rioHPl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A8wo9ZBCcAAtGHo.jpg",
      "id_str" : "273638712515129344",
      "id" : 273638712515129344,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A8wo9ZBCcAAtGHo.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/44rioHPl"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273638712506740737",
  "text" : "Earlier today, President Obama met with small business owners to discuss a balanced approach to deficit reduction. Pic: http:\/\/t.co\/44rioHPl",
  "id" : 273638712506740737,
  "created_at" : "2012-11-28 04:05:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BlackFriday",
      "indices" : [ 6, 18 ]
    }, {
      "text" : "CyberMonday",
      "indices" : [ 25, 37 ]
    }, {
      "text" : "GivingTuesday",
      "indices" : [ 45, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 121, 141 ],
      "url" : "http:\/\/t.co\/geGQIaQD",
      "expanded_url" : "http:\/\/on.wh.gov\/Yj2nuxB",
      "display_url" : "on.wh.gov\/Yj2nuxB"
    } ]
  },
  "geo" : { },
  "id_str" : "273609055841435648",
  "text" : "After #BlackFriday &amp; #CyberMonday, comes #GivingTuesday, a day for all Americans to give back and make a difference: http:\/\/t.co\/geGQIaQD",
  "id" : 273609055841435648,
  "created_at" : "2012-11-28 02:07:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/273569753497485313\/photo\/1",
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/xAIFynQc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A8vqPcsCQAAGuZn.jpg",
      "id_str" : "273569753505873920",
      "id" : 273569753505873920,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A8vqPcsCQAAGuZn.jpg",
      "sizes" : [ {
        "h" : 826,
        "resize" : "fit",
        "w" : 518
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 542,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 826,
        "resize" : "fit",
        "w" : 518
      }, {
        "h" : 826,
        "resize" : "fit",
        "w" : 518
      } ],
      "display_url" : "pic.twitter.com\/xAIFynQc"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/3OZSnzku",
      "expanded_url" : "http:\/\/on.wh.gov\/oXgAWF6",
      "display_url" : "on.wh.gov\/oXgAWF6"
    } ]
  },
  "geo" : { },
  "id_str" : "273569753497485313",
  "text" : "If Congress doesn't pass the middle-class tax cuts, consumers could spend $200B less in 2013: http:\/\/t.co\/3OZSnzku http:\/\/t.co\/xAIFynQc",
  "id" : 273569753497485313,
  "created_at" : "2012-11-27 23:31:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/F6aGewtc",
      "expanded_url" : "http:\/\/on.wh.gov\/0tEU8L",
      "display_url" : "on.wh.gov\/0tEU8L"
    } ]
  },
  "geo" : { },
  "id_str" : "273504412037685248",
  "text" : "\"$2,000 is very important to us\" -Tiffany on why Congress must pass the middle-class tax cuts. Watch: http:\/\/t.co\/F6aGewtc",
  "id" : 273504412037685248,
  "created_at" : "2012-11-27 19:11:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Todd Park",
      "screen_name" : "todd_park",
      "indices" : [ 3, 13 ],
      "id_str" : "200176600",
      "id" : 200176600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/gLH3S4N5",
      "expanded_url" : "http:\/\/go.usa.gov\/g25Q",
      "display_url" : "go.usa.gov\/g25Q"
    } ]
  },
  "geo" : { },
  "id_str" : "273480337168941056",
  "text" : "RT @todd_park: Answer the Equal Futures App Challenge - all-star judges just announced http:\/\/t.co\/gLH3S4N5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 92 ],
        "url" : "http:\/\/t.co\/gLH3S4N5",
        "expanded_url" : "http:\/\/go.usa.gov\/g25Q",
        "display_url" : "go.usa.gov\/g25Q"
      } ]
    },
    "geo" : { },
    "id_str" : "273472947748995073",
    "text" : "Answer the Equal Futures App Challenge - all-star judges just announced http:\/\/t.co\/gLH3S4N5",
    "id" : 273472947748995073,
    "created_at" : "2012-11-27 17:06:46 +0000",
    "user" : {
      "name" : "Todd Park",
      "screen_name" : "todd_park",
      "protected" : false,
      "id_str" : "200176600",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1140157375\/toddpark_normal.jpg",
      "id" : 200176600,
      "verified" : false
    }
  },
  "id" : 273480337168941056,
  "created_at" : "2012-11-27 17:36:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273443229058342915",
  "text" : "RT @pfeiffer44: President Obama heads to Pennsylvania on Friday to discuss extending middle class taxes at a local business",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "273391174595776513",
    "text" : "President Obama heads to Pennsylvania on Friday to discuss extending middle class taxes at a local business",
    "id" : 273391174595776513,
    "created_at" : "2012-11-27 11:41:50 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 273443229058342915,
  "created_at" : "2012-11-27 15:08:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 45, 48 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/273288064351236096\/photo\/1",
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/1YTS4yWy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A8rqC-2CcAIZviz.jpg",
      "id_str" : "273288064359624706",
      "id" : 273288064359624706,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A8rqC-2CcAIZviz.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/1YTS4yWy"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273288064351236096",
  "text" : "Photo of the Day: President Obama talks with @VP Biden in the hallway outside of the Oval Office: http:\/\/t.co\/1YTS4yWy",
  "id" : 273288064351236096,
  "created_at" : "2012-11-27 04:52:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/273248507383656448\/photo\/1",
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/Jq5G8wqi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A8rGEdqCMAAe1OV.jpg",
      "id_str" : "273248507392045056",
      "id" : 273248507392045056,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A8rGEdqCMAAe1OV.jpg",
      "sizes" : [ {
        "h" : 772,
        "resize" : "fit",
        "w" : 518
      }, {
        "h" : 772,
        "resize" : "fit",
        "w" : 518
      }, {
        "h" : 772,
        "resize" : "fit",
        "w" : 518
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 507,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Jq5G8wqi"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/ElzUYrPT",
      "expanded_url" : "http:\/\/on.wh.gov\/JMhkyL",
      "display_url" : "on.wh.gov\/JMhkyL"
    } ]
  },
  "geo" : { },
  "id_str" : "273248507383656448",
  "text" : "7 reasons why middle-class families and our economy can't afford a tax hike right now: http:\/\/t.co\/ElzUYrPT http:\/\/t.co\/Jq5G8wqi",
  "id" : 273248507383656448,
  "created_at" : "2012-11-27 02:14:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/bEATdJXR",
      "expanded_url" : "http:\/\/on.wh.gov\/imgytq",
      "display_url" : "on.wh.gov\/imgytq"
    } ]
  },
  "geo" : { },
  "id_str" : "273214215702052864",
  "text" : "Increasing Taxes on Middle-Class Families Will Hurt Consumer Spending: http:\/\/t.co\/bEATdJXR",
  "id" : 273214215702052864,
  "created_at" : "2012-11-26 23:58:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/fGcJq0LU",
      "expanded_url" : "http:\/\/on.wh.gov\/RCG07X",
      "display_url" : "on.wh.gov\/RCG07X"
    } ]
  },
  "geo" : { },
  "id_str" : "273198364890378240",
  "text" : "Open Today: Summer 2013 White House Internship Program Application: http:\/\/t.co\/fGcJq0LU",
  "id" : 273198364890378240,
  "created_at" : "2012-11-26 22:55:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/273182493161701376\/photo\/1",
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/hMI0OhJX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A8qKB7hCQAA6l4F.jpg",
      "id_str" : "273182493170089984",
      "id" : 273182493170089984,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A8qKB7hCQAA6l4F.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 403,
        "resize" : "fit",
        "w" : 403
      }, {
        "h" : 403,
        "resize" : "fit",
        "w" : 403
      }, {
        "h" : 403,
        "resize" : "fit",
        "w" : 403
      } ],
      "display_url" : "pic.twitter.com\/hMI0OhJX"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/C3Z5QONh",
      "expanded_url" : "http:\/\/on.wh.gov\/ZYtXNU",
      "display_url" : "on.wh.gov\/ZYtXNU"
    } ]
  },
  "geo" : { },
  "id_str" : "273182493161701376",
  "text" : "If Congress doesn't act, middle-class families will see their income taxes go up on January 1st: http:\/\/t.co\/C3Z5QONh http:\/\/t.co\/hMI0OhJX",
  "id" : 273182493161701376,
  "created_at" : "2012-11-26 21:52:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 31, 42 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "273067865589039105",
  "text" : "RT @PressSec: On Cyber Monday, @WhiteHouse releases a new report on middle-class tax cuts\u2019 impact on retailers &amp; consumer spending:  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 17, 28 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 122, 142 ],
        "url" : "http:\/\/t.co\/DW4Jn3rl",
        "expanded_url" : "http:\/\/at.wh.gov\/fz0Fz",
        "display_url" : "at.wh.gov\/fz0Fz"
      } ]
    },
    "geo" : { },
    "id_str" : "273018487176314880",
    "text" : "On Cyber Monday, @WhiteHouse releases a new report on middle-class tax cuts\u2019 impact on retailers &amp; consumer spending: http:\/\/t.co\/DW4Jn3rl",
    "id" : 273018487176314880,
    "created_at" : "2012-11-26 11:00:54 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 273067865589039105,
  "created_at" : "2012-11-26 14:17:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/272865330303488001\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/2kx0P3Bd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A8lpknzCUAE5aPI.jpg",
      "id_str" : "272865330311876609",
      "id" : 272865330311876609,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A8lpknzCUAE5aPI.jpg",
      "sizes" : [ {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 373,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 373,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 373,
        "resize" : "fit",
        "w" : 560
      } ],
      "display_url" : "pic.twitter.com\/2kx0P3Bd"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/zNMUPzue",
      "expanded_url" : "http:\/\/on.wh.gov\/GOz75j",
      "display_url" : "on.wh.gov\/GOz75j"
    } ]
  },
  "geo" : { },
  "id_str" : "272865330303488001",
  "text" : "On Friday, the White House Christmas tree arrived via horse-drawn carriage at the White House http:\/\/t.co\/zNMUPzue Pic: http:\/\/t.co\/2kx0P3Bd",
  "id" : 272865330303488001,
  "created_at" : "2012-11-26 00:52:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/272461597400788992\/photo\/1",
      "indices" : [ 124, 144 ],
      "url" : "http:\/\/t.co\/jyS5UShT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A8f6YRiCcAEMOrh.jpg",
      "id_str" : "272461597409177601",
      "id" : 272461597409177601,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A8f6YRiCcAEMOrh.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/jyS5UShT"
    } ],
    "hashtags" : [ {
      "text" : "SmallBizSat",
      "indices" : [ 111, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "272461597400788992",
  "text" : "President Obama &amp; his daughters did some Christmas shopping today at a local bookstore in Arlington, VA on #SmallBizSat http:\/\/t.co\/jyS5UShT",
  "id" : 272461597400788992,
  "created_at" : "2012-11-24 22:08:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SBA",
      "screen_name" : "SBAgov",
      "indices" : [ 3, 10 ],
      "id_str" : "153149305",
      "id" : 153149305
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Massachusetts",
      "indices" : [ 82, 96 ]
    }, {
      "text" : "SmallBizSat",
      "indices" : [ 119, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/U6lGOKd3",
      "expanded_url" : "http:\/\/ow.ly\/i\/1ahNg",
      "display_url" : "ow.ly\/i\/1ahNg"
    } ]
  },
  "geo" : { },
  "id_str" : "272452978282209283",
  "text" : "RT @SBAgov: SBA Administrator Karen Mills shopping small at Roslindale Village in #Massachusetts: http:\/\/t.co\/U6lGOKd3 #SmallBizSat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Massachusetts",
        "indices" : [ 70, 84 ]
      }, {
        "text" : "SmallBizSat",
        "indices" : [ 107, 119 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 106 ],
        "url" : "http:\/\/t.co\/U6lGOKd3",
        "expanded_url" : "http:\/\/ow.ly\/i\/1ahNg",
        "display_url" : "ow.ly\/i\/1ahNg"
      } ]
    },
    "geo" : { },
    "id_str" : "272441995300065280",
    "text" : "SBA Administrator Karen Mills shopping small at Roslindale Village in #Massachusetts: http:\/\/t.co\/U6lGOKd3 #SmallBizSat",
    "id" : 272441995300065280,
    "created_at" : "2012-11-24 20:50:08 +0000",
    "user" : {
      "name" : "SBA",
      "screen_name" : "SBAgov",
      "protected" : false,
      "id_str" : "153149305",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/637366120236756992\/ky6enEIv_normal.png",
      "id" : 153149305,
      "verified" : true
    }
  },
  "id" : 272452978282209283,
  "created_at" : "2012-11-24 21:33:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SmallBizSat",
      "indices" : [ 71, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "272418391887847425",
  "text" : "My family &amp; I started our holiday shopping at a local bookstore on #SmallBizSat. I hope you'll join &amp; shop small this holiday season. -bo",
  "id" : 272418391887847425,
  "created_at" : "2012-11-24 19:16:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/272370787648950273\/photo\/1",
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/EVCpOpa5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A8enyc2CUAA_fXl.jpg",
      "id_str" : "272370787657338880",
      "id" : 272370787657338880,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A8enyc2CUAA_fXl.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 403,
        "resize" : "fit",
        "w" : 403
      }, {
        "h" : 403,
        "resize" : "fit",
        "w" : 403
      }, {
        "h" : 403,
        "resize" : "fit",
        "w" : 403
      } ],
      "display_url" : "pic.twitter.com\/EVCpOpa5"
    } ],
    "hashtags" : [ {
      "text" : "SmallBizSat",
      "indices" : [ 100, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "272370787648950273",
  "text" : "There are over 28 million U.S. small businesses. Where are you shopping on Small Business Saturday? #SmallBizSat http:\/\/t.co\/EVCpOpa5",
  "id" : 272370787648950273,
  "created_at" : "2012-11-24 16:07:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/272093968387432448\/photo\/1",
      "indices" : [ 125, 145 ],
      "url" : "http:\/\/t.co\/NgfBK149",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A8asBcvCYAEvZ39.jpg",
      "id_str" : "272093968395821057",
      "id" : 272093968395821057,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A8asBcvCYAEvZ39.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/NgfBK149"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "272093968387432448",
  "text" : "First Lady Michelle Obama, daughters Sasha &amp; Malia, &amp; First Dog Bo, welcome the official White House Christmas Tree: http:\/\/t.co\/NgfBK149",
  "id" : 272093968387432448,
  "created_at" : "2012-11-23 21:47:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kramerbooks",
      "screen_name" : "kramerbooks",
      "indices" : [ 90, 102 ],
      "id_str" : "84436630",
      "id" : 84436630
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/272028549328814080\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/sOaCchfX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A8ZwhjwCQAAeFQA.jpg",
      "id_str" : "272028549337202688",
      "id" : 272028549337202688,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A8ZwhjwCQAAeFQA.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 403,
        "resize" : "fit",
        "w" : 403
      }, {
        "h" : 403,
        "resize" : "fit",
        "w" : 403
      }, {
        "h" : 403,
        "resize" : "fit",
        "w" : 403
      } ],
      "display_url" : "pic.twitter.com\/sOaCchfX"
    } ],
    "hashtags" : [ {
      "text" : "ShopSmall",
      "indices" : [ 10, 20 ]
    }, {
      "text" : "SmallBizSat",
      "indices" : [ 106, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "272028549328814080",
  "text" : "Tomorrow, #ShopSmall on Small Business Saturday, Nov 24. In 2011, President Obama visited @kramerbooks on #SmallBizSat: http:\/\/t.co\/sOaCchfX",
  "id" : 272028549328814080,
  "created_at" : "2012-11-23 17:27:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/271798666044518400\/photo\/1",
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/Df9bk4Do",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A8WfclyCMAIX9gu.jpg",
      "id_str" : "271798666052907010",
      "id" : 271798666052907010,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A8WfclyCMAIX9gu.jpg",
      "sizes" : [ {
        "h" : 2731,
        "resize" : "fit",
        "w" : 4096
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Df9bk4Do"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "271798666044518400",
  "text" : "\"From our family to yours, happy Thanksgiving.\" -President Obama http:\/\/t.co\/Df9bk4Do",
  "id" : 271798666044518400,
  "created_at" : "2012-11-23 02:13:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/Le48dr6F",
      "expanded_url" : "http:\/\/on.wh.gov\/3ZUz9d",
      "display_url" : "on.wh.gov\/3ZUz9d"
    } ]
  },
  "geo" : { },
  "id_str" : "271783472471887872",
  "text" : "\"Today we give thanks for blessings that are all too rare in this world\" -President Obama in his Weekly Address: http:\/\/t.co\/Le48dr6F",
  "id" : 271783472471887872,
  "created_at" : "2012-11-23 01:13:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "271709953155272704",
  "text" : "RT @petesouza: Thanksgiving Day photo of President Obama greeting players from Oregon State U basketball team in the Oval Office: http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 135 ],
        "url" : "http:\/\/t.co\/I5EyMRUa",
        "expanded_url" : "http:\/\/bit.ly\/WD44qf",
        "display_url" : "bit.ly\/WD44qf"
      } ]
    },
    "geo" : { },
    "id_str" : "271708062509838336",
    "text" : "Thanksgiving Day photo of President Obama greeting players from Oregon State U basketball team in the Oval Office: http:\/\/t.co\/I5EyMRUa",
    "id" : 271708062509838336,
    "created_at" : "2012-11-22 20:13:44 +0000",
    "user" : {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "protected" : false,
      "id_str" : "18215973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771916869808844800\/7d_poH48_normal.jpg",
      "id" : 18215973,
      "verified" : true
    }
  },
  "id" : 271709953155272704,
  "created_at" : "2012-11-22 20:21:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/CsewGyx5",
      "expanded_url" : "http:\/\/on.wh.gov\/lx350x",
      "display_url" : "on.wh.gov\/lx350x"
    } ]
  },
  "geo" : { },
  "id_str" : "271612036176297984",
  "text" : "\"From our family to yours, happy Thanksgiving.\" -President Obama: http:\/\/t.co\/CsewGyx5",
  "id" : 271612036176297984,
  "created_at" : "2012-11-22 13:52:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/271565186324910080\/photo\/1",
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/ALhY6Goa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A8TLGSDCUAAOtcP.jpg",
      "id_str" : "271565186333298688",
      "id" : 271565186333298688,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A8TLGSDCUAAOtcP.jpg",
      "sizes" : [ {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1920,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/ALhY6Goa"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http:\/\/t.co\/ALNQKHHp",
      "expanded_url" : "http:\/\/on.wh.gov\/4zhKtQ",
      "display_url" : "on.wh.gov\/4zhKtQ"
    } ]
  },
  "geo" : { },
  "id_str" : "271565186324910080",
  "text" : "New photo gallery: President Obama's Trip To Asia: http:\/\/t.co\/ALNQKHHp The President at Shwedagon Pagoda in Burma: http:\/\/t.co\/ALhY6Goa",
  "id" : 271565186324910080,
  "created_at" : "2012-11-22 10:46:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/271449753672359936\/photo\/1",
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/L2dyKTM0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A8RiHN6CIAEPrZ3.jpg",
      "id_str" : "271449753680748545",
      "id" : 271449753680748545,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A8RiHN6CIAEPrZ3.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/L2dyKTM0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "271449753672359936",
  "text" : "Today, President Obama pardoned Cobbler, the National Thanksgiving Turkey, in a ceremony at the White House: http:\/\/t.co\/L2dyKTM0",
  "id" : 271449753672359936,
  "created_at" : "2012-11-22 03:07:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CapitalAreaFoodBank",
      "screen_name" : "foodbankmetrodc",
      "indices" : [ 3, 19 ],
      "id_str" : "17626836",
      "id" : 17626836
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Thanksgiving",
      "indices" : [ 56, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "271445812083568641",
  "text" : "RT @foodbankmetrodc: First Family continuing its annual #Thanksgiving tradition and participating in a service project... here at our fo ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Thanksgiving",
        "indices" : [ 35, 48 ]
      }, {
        "text" : "Obama",
        "indices" : [ 124, 130 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "271373648483471361",
    "text" : "First Family continuing its annual #Thanksgiving tradition and participating in a service project... here at our food bank! #Obama",
    "id" : 271373648483471361,
    "created_at" : "2012-11-21 22:04:54 +0000",
    "user" : {
      "name" : "CapitalAreaFoodBank",
      "screen_name" : "foodbankmetrodc",
      "protected" : false,
      "id_str" : "17626836",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618784428781912064\/UTylVgTB_normal.jpg",
      "id" : 17626836,
      "verified" : false
    }
  },
  "id" : 271445812083568641,
  "created_at" : "2012-11-22 02:51:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/riqkQyGr",
      "expanded_url" : "http:\/\/on.wh.gov\/cYe6Gp",
      "display_url" : "on.wh.gov\/cYe6Gp"
    } ]
  },
  "geo" : { },
  "id_str" : "271407625453842432",
  "text" : "\"May you all have a very happy Thanksgiving\" -President Obama at the National Thanksgiving Turkey Pardon. Watch: http:\/\/t.co\/riqkQyGr",
  "id" : 271407625453842432,
  "created_at" : "2012-11-22 00:19:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/XJt2DBqq",
      "expanded_url" : "http:\/\/wh.gov\/IiGK",
      "display_url" : "wh.gov\/IiGK"
    } ]
  },
  "geo" : { },
  "id_str" : "271393008686084097",
  "text" : "RT @petesouza: Slide show of President Obama's trip to Asia: http:\/\/t.co\/XJt2DBqq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 46, 66 ],
        "url" : "http:\/\/t.co\/XJt2DBqq",
        "expanded_url" : "http:\/\/wh.gov\/IiGK",
        "display_url" : "wh.gov\/IiGK"
      } ]
    },
    "geo" : { },
    "id_str" : "271354015286165504",
    "text" : "Slide show of President Obama's trip to Asia: http:\/\/t.co\/XJt2DBqq",
    "id" : 271354015286165504,
    "created_at" : "2012-11-21 20:46:53 +0000",
    "user" : {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "protected" : false,
      "id_str" : "18215973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771916869808844800\/7d_poH48_normal.jpg",
      "id" : 18215973,
      "verified" : true
    }
  },
  "id" : 271393008686084097,
  "created_at" : "2012-11-21 23:21:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/271368262707707904\/photo\/1",
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/Chk7a3mW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A8QX_0ZCAAEJd9n.jpg",
      "id_str" : "271368262711902209",
      "id" : 271368262711902209,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A8QX_0ZCAAEJd9n.jpg",
      "sizes" : [ {
        "h" : 435,
        "resize" : "fit",
        "w" : 432
      }, {
        "h" : 435,
        "resize" : "fit",
        "w" : 432
      }, {
        "h" : 435,
        "resize" : "fit",
        "w" : 432
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 342,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Chk7a3mW"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/xGHLq6z6",
      "expanded_url" : "http:\/\/on.wh.gov\/GxOUji",
      "display_url" : "on.wh.gov\/GxOUji"
    } ]
  },
  "geo" : { },
  "id_str" : "271368262707707904",
  "text" : "Photos from the Archives: Thanksgiving at the White House: http:\/\/t.co\/xGHLq6z6 Including President Kennedy in 1963: http:\/\/t.co\/Chk7a3mW",
  "id" : 271368262707707904,
  "created_at" : "2012-11-21 21:43:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/XFBWa44Z",
      "expanded_url" : "http:\/\/on.wh.gov\/ZBHDUy",
      "display_url" : "on.wh.gov\/ZBHDUy"
    } ]
  },
  "geo" : { },
  "id_str" : "271324624652996608",
  "text" : "Starting at 2ET: President Obama pardons the 2012 National Thanksgiving Turkey live from the Rose Garden. Watch: http:\/\/t.co\/XFBWa44Z",
  "id" : 271324624652996608,
  "created_at" : "2012-11-21 18:50:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/271301676533686272\/photo\/1",
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/oxXknfa8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A8Pbb_mCIAA-rJN.jpg",
      "id_str" : "271301676546269184",
      "id" : 271301676546269184,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A8Pbb_mCIAA-rJN.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 403,
        "resize" : "fit",
        "w" : 403
      }, {
        "h" : 403,
        "resize" : "fit",
        "w" : 403
      }, {
        "h" : 403,
        "resize" : "fit",
        "w" : 403
      } ],
      "display_url" : "pic.twitter.com\/oxXknfa8"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/kYCQHRtE",
      "expanded_url" : "http:\/\/on.wh.gov\/CDsTzH",
      "display_url" : "on.wh.gov\/CDsTzH"
    } ]
  },
  "geo" : { },
  "id_str" : "271301676533686272",
  "text" : "Today at 2ET: President Obama pardons Cobbler, your 2012 National Thanksgiving Turkey. Watch: http:\/\/t.co\/kYCQHRtE http:\/\/t.co\/oxXknfa8",
  "id" : 271301676533686272,
  "created_at" : "2012-11-21 17:18:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/270972571825086464\/photo\/1",
      "indices" : [ 124, 144 ],
      "url" : "http:\/\/t.co\/oh4JDz1K",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A8KwHlACIAArCl3.jpg",
      "id_str" : "270972571833475072",
      "id" : 270972571833475072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A8KwHlACIAArCl3.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 806,
        "resize" : "fit",
        "w" : 1612
      } ],
      "display_url" : "pic.twitter.com\/oh4JDz1K"
    } ],
    "hashtags" : [ {
      "text" : "TeamCobbler",
      "indices" : [ 70, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http:\/\/t.co\/cClGC1jF",
      "expanded_url" : "http:\/\/on.wh.gov\/FRNdHA",
      "display_url" : "on.wh.gov\/FRNdHA"
    } ]
  },
  "geo" : { },
  "id_str" : "270972571825086464",
  "text" : "Vote for the Natl Thanksgiving Turkey http:\/\/t.co\/cClGC1jF Are you on #TeamCobbler? He loves cranberries &amp; Carly Simon: http:\/\/t.co\/oh4JDz1K",
  "id" : 270972571825086464,
  "created_at" : "2012-11-20 19:31:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/270960497266933760\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/5nMXlNFc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A8KlIvyCQAIjGrv.jpg",
      "id_str" : "270960497279516674",
      "id" : 270960497279516674,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A8KlIvyCQAIjGrv.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 806,
        "resize" : "fit",
        "w" : 1612
      } ],
      "display_url" : "pic.twitter.com\/5nMXlNFc"
    } ],
    "hashtags" : [ {
      "text" : "TeamGobbler",
      "indices" : [ 71, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/FAEle2Bv",
      "expanded_url" : "http:\/\/on.wh.gov\/JloGFv",
      "display_url" : "on.wh.gov\/JloGFv"
    } ]
  },
  "geo" : { },
  "id_str" : "270960497266933760",
  "text" : "Vote for the Natl Thanksgiving Turkey: http:\/\/t.co\/FAEle2Bv Are you on #TeamGobbler? He can't get enough of the fiddle: http:\/\/t.co\/5nMXlNFc",
  "id" : 270960497266933760,
  "created_at" : "2012-11-20 18:43:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/270944282284797952\/photo\/1",
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/Zn3S6e42",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A8KWY6QCMAAmdPM.jpg",
      "id_str" : "270944282293186560",
      "id" : 270944282293186560,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A8KWY6QCMAAmdPM.jpg",
      "sizes" : [ {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/Zn3S6e42"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "270944282284797952",
  "text" : "Photo of the day: President Obama walks with Aung San Suu Kyi at her home in Rangoon, Burma, Nov. 19, 2012. http:\/\/t.co\/Zn3S6e42",
  "id" : 270944282284797952,
  "created_at" : "2012-11-20 17:38:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/270928988124377089\/photo\/1",
      "indices" : [ 123, 143 ],
      "url" : "http:\/\/t.co\/0nvMLN2U",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A8KIerECcAELVZV.jpg",
      "id_str" : "270928988132765697",
      "id" : 270928988132765697,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A8KIerECcAELVZV.jpg",
      "sizes" : [ {
        "h" : 315,
        "resize" : "fit",
        "w" : 851
      }, {
        "h" : 126,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 222,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 315,
        "resize" : "fit",
        "w" : 851
      } ],
      "display_url" : "pic.twitter.com\/0nvMLN2U"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/qrFbhfT4",
      "expanded_url" : "http:\/\/on.wh.gov\/vAUjax",
      "display_url" : "on.wh.gov\/vAUjax"
    } ]
  },
  "geo" : { },
  "id_str" : "270928988124377089",
  "text" : "Who will be the 2012 National Thanksgiving Turkey? Meet Cobbler &amp; Gobbler, then vote on Facebook: http:\/\/t.co\/qrFbhfT4 http:\/\/t.co\/0nvMLN2U",
  "id" : 270928988124377089,
  "created_at" : "2012-11-20 16:37:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/270738015675092992\/photo\/1",
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/kuXkN7Or",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A8HaynQCEAEiRwU.jpg",
      "id_str" : "270738015683481601",
      "id" : 270738015683481601,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A8HaynQCEAEiRwU.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 403,
        "resize" : "fit",
        "w" : 403
      }, {
        "h" : 403,
        "resize" : "fit",
        "w" : 403
      }, {
        "h" : 403,
        "resize" : "fit",
        "w" : 403
      } ],
      "display_url" : "pic.twitter.com\/kuXkN7Or"
    } ],
    "hashtags" : [ {
      "text" : "Burma",
      "indices" : [ 29, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "270738015675092992",
  "text" : "President Obama on Monday in #Burma: \"Even though we come from different places, we share common dreams\" http:\/\/t.co\/kuXkN7Or",
  "id" : 270738015675092992,
  "created_at" : "2012-11-20 03:59:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/BxRln6kx",
      "expanded_url" : "http:\/\/on.wh.gov\/O8OGjh",
      "display_url" : "on.wh.gov\/O8OGjh"
    } ]
  },
  "geo" : { },
  "id_str" : "270679734004895744",
  "text" : "On the road with President Obama, Natl Security Advisor Ben Rhodes gives you an update on the Asia trip from Burma: http:\/\/t.co\/BxRln6kx",
  "id" : 270679734004895744,
  "created_at" : "2012-11-20 00:07:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/270606359614087169\/photo\/1",
      "indices" : [ 124, 144 ],
      "url" : "http:\/\/t.co\/m20jsvkU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A8FjDONCYAAhh2d.jpg",
      "id_str" : "270606359622475776",
      "id" : 270606359622475776,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A8FjDONCYAAhh2d.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/m20jsvkU"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/VFHxeFen",
      "expanded_url" : "http:\/\/on.wh.gov\/Z4ItPT",
      "display_url" : "on.wh.gov\/Z4ItPT"
    } ]
  },
  "geo" : { },
  "id_str" : "270606359614087169",
  "text" : "Updates &amp; photos from President Obama's Asia trip: http:\/\/t.co\/VFHxeFen The President greets Aung San Suu Kyi in Burma: http:\/\/t.co\/m20jsvkU",
  "id" : 270606359614087169,
  "created_at" : "2012-11-19 19:15:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 3, 13 ],
      "id_str" : "9624742",
      "id" : 9624742
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SecClinton",
      "indices" : [ 23, 34 ]
    }, {
      "text" : "Burma",
      "indices" : [ 76, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/rdcxET4w",
      "expanded_url" : "http:\/\/flic.kr\/p\/duDaeq",
      "display_url" : "flic.kr\/p\/duDaeq"
    } ]
  },
  "geo" : { },
  "id_str" : "270575832953659393",
  "text" : "RT @StateDept: (Photo) #SecClinton and President Obama wave upon landing in #Burma on November 19: http:\/\/t.co\/rdcxET4w",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SecClinton",
        "indices" : [ 8, 19 ]
      }, {
        "text" : "Burma",
        "indices" : [ 61, 67 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 104 ],
        "url" : "http:\/\/t.co\/rdcxET4w",
        "expanded_url" : "http:\/\/flic.kr\/p\/duDaeq",
        "display_url" : "flic.kr\/p\/duDaeq"
      } ]
    },
    "geo" : { },
    "id_str" : "270562758725091328",
    "text" : "(Photo) #SecClinton and President Obama wave upon landing in #Burma on November 19: http:\/\/t.co\/rdcxET4w",
    "id" : 270562758725091328,
    "created_at" : "2012-11-19 16:22:43 +0000",
    "user" : {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "protected" : false,
      "id_str" : "9624742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724612605185282048\/1rEfkXDZ_normal.jpg",
      "id" : 9624742,
      "verified" : true
    }
  },
  "id" : 270575832953659393,
  "created_at" : "2012-11-19 17:14:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Burma",
      "indices" : [ 64, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/LQ3A0qoH",
      "expanded_url" : "http:\/\/on.wh.gov\/bhad7s",
      "display_url" : "on.wh.gov\/bhad7s"
    } ]
  },
  "geo" : { },
  "id_str" : "270463414999080960",
  "text" : "Today, President Obama became the first U.S. President to visit #Burma: http:\/\/t.co\/LQ3A0qoH",
  "id" : 270463414999080960,
  "created_at" : "2012-11-19 09:47:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Embassy Burma",
      "screen_name" : "USEmbassyBurma",
      "indices" : [ 3, 18 ],
      "id_str" : "537204717",
      "id" : 537204717
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obama",
      "indices" : [ 30, 36 ]
    }, {
      "text" : "Burma",
      "indices" : [ 116, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "270370828531687424",
  "text" : "RT @USEmbassyBurma: President #Obama greets officials at Rangoon Int'l Airport as the first U.S. President to visit #Burma http:\/\/t.co\/5 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/USEmbassyBurma\/status\/270367019998777344\/photo\/1",
        "indices" : [ 103, 123 ],
        "url" : "http:\/\/t.co\/5r2AK6PX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A8CJX0pCEAApciv.jpg",
        "id_str" : "270367020002971648",
        "id" : 270367020002971648,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A8CJX0pCEAApciv.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/5r2AK6PX"
      } ],
      "hashtags" : [ {
        "text" : "Obama",
        "indices" : [ 10, 16 ]
      }, {
        "text" : "Burma",
        "indices" : [ 96, 102 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "270367019998777344",
    "text" : "President #Obama greets officials at Rangoon Int'l Airport as the first U.S. President to visit #Burma http:\/\/t.co\/5r2AK6PX",
    "id" : 270367019998777344,
    "created_at" : "2012-11-19 03:24:56 +0000",
    "user" : {
      "name" : "U.S. Embassy Burma",
      "screen_name" : "USEmbassyBurma",
      "protected" : false,
      "id_str" : "537204717",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/454128839501692928\/ngWHbhCC_normal.png",
      "id" : 537204717,
      "verified" : true
    }
  },
  "id" : 270370828531687424,
  "created_at" : "2012-11-19 03:40:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/270333619002826752\/photo\/1",
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/8NFVKY0y",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A8Bq_oQCYAEelbj.jpg",
      "id_str" : "270333619011215361",
      "id" : 270333619011215361,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A8Bq_oQCYAEelbj.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1317,
        "resize" : "fit",
        "w" : 1976
      } ],
      "display_url" : "pic.twitter.com\/8NFVKY0y"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "270333619002826752",
  "text" : "Photo: President Obama &amp; Secretary Clinton view the Vihan of the Reclining Buddha at Wat Pho in Bangkok, Thailand: http:\/\/t.co\/8NFVKY0y",
  "id" : 270333619002826752,
  "created_at" : "2012-11-19 01:12:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 40, 50 ],
      "id_str" : "9624742",
      "id" : 9624742
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/270260299934871553\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/gIDlEu7x",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A8AoT5bCMAEVesZ.jpg",
      "id_str" : "270260299939065857",
      "id" : 270260299939065857,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A8AoT5bCMAEVesZ.jpg",
      "sizes" : [ {
        "h" : 1366,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/gIDlEu7x"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "270260299934871553",
  "text" : "Photo of the Day: President Obama &amp; @StateDept Sec. Clinton meet with King Bhumibol Adulyadej in Bangkok, Thailand: http:\/\/t.co\/gIDlEu7x",
  "id" : 270260299934871553,
  "created_at" : "2012-11-18 20:20:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Senator Bob Menendez",
      "screen_name" : "SenatorMenendez",
      "indices" : [ 15, 31 ],
      "id_str" : "18695134",
      "id" : 18695134
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Sandy",
      "indices" : [ 113, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "270216231322279936",
  "text" : "RT @VP: VP and @SenatorMenendez land in Island Beach State Park in New Jersey to tour areas damaged by Hurricane #Sandy. http:\/\/t.co\/vwN ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Senator Bob Menendez",
        "screen_name" : "SenatorMenendez",
        "indices" : [ 7, 23 ],
        "id_str" : "18695134",
        "id" : 18695134
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/270208711803432960\/photo\/1",
        "indices" : [ 113, 133 ],
        "url" : "http:\/\/t.co\/vwNkcesf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A7_5ZErCcAAc41d.jpg",
        "id_str" : "270208711811821568",
        "id" : 270208711811821568,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A7_5ZErCcAAc41d.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        } ],
        "display_url" : "pic.twitter.com\/vwNkcesf"
      } ],
      "hashtags" : [ {
        "text" : "Sandy",
        "indices" : [ 105, 111 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "270208711803432960",
    "text" : "VP and @SenatorMenendez land in Island Beach State Park in New Jersey to tour areas damaged by Hurricane #Sandy. http:\/\/t.co\/vwNkcesf",
    "id" : 270208711803432960,
    "created_at" : "2012-11-18 16:55:52 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 270216231322279936,
  "created_at" : "2012-11-18 17:25:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/FNpaahb5",
      "expanded_url" : "http:\/\/on.wh.gov\/3affYd",
      "display_url" : "on.wh.gov\/3affYd"
    } ]
  },
  "geo" : { },
  "id_str" : "269878130691411968",
  "text" : "President Obama: \"I know these challenges won't be easy to solve. But we can do it if we work together.\" Watch: http:\/\/t.co\/FNpaahb5",
  "id" : 269878130691411968,
  "created_at" : "2012-11-17 19:02:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/joTPiUPe",
      "expanded_url" : "http:\/\/on.wh.gov\/bdG2lY",
      "display_url" : "on.wh.gov\/bdG2lY"
    } ]
  },
  "geo" : { },
  "id_str" : "269820975904874500",
  "text" : "\"I'm willing to work with anyone of any party to move this country forward.\" -President Obama in his Weekly Address: http:\/\/t.co\/joTPiUPe",
  "id" : 269820975904874500,
  "created_at" : "2012-11-17 15:15:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "McKayla Maroney",
      "screen_name" : "McKaylaMaroney",
      "indices" : [ 3, 18 ],
      "id_str" : "375383001",
      "id" : 375383001
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/269785942326398976\/photo\/1",
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/4BkKAfaV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A7544poCUAARaUN.jpg",
      "id_str" : "269785942330593280",
      "id" : 269785942330593280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A7544poCUAARaUN.jpg",
      "sizes" : [ {
        "h" : 1366,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/4BkKAfaV"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "269785942326398976",
  "text" : "RT @McKaylaMaroney Did I just do the Not Impressed face with the President..? \/\/ Yes. http:\/\/t.co\/4BkKAfaV",
  "id" : 269785942326398976,
  "created_at" : "2012-11-17 12:55:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 10, 21 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "SoundCloud",
      "screen_name" : "SoundCloud",
      "indices" : [ 71, 82 ],
      "id_str" : "5943942",
      "id" : 5943942
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/SDM7W5Xr",
      "expanded_url" : "http:\/\/on.wh.gov\/zmjodp",
      "display_url" : "on.wh.gov\/zmjodp"
    } ]
  },
  "geo" : { },
  "id_str" : "269730420747276289",
  "text" : "Hear from @whitehouse in a new way. Check out our official presence on @SoundCloud: http:\/\/t.co\/SDM7W5Xr",
  "id" : 269730420747276289,
  "created_at" : "2012-11-17 09:15:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/z2hLcejn",
      "expanded_url" : "http:\/\/on.wh.gov\/hXFiXv",
      "display_url" : "on.wh.gov\/hXFiXv"
    } ]
  },
  "geo" : { },
  "id_str" : "269572181393014784",
  "text" : "Get a preview of President Obama's upcoming trip to Thailand, Burma &amp; Cambodia: http:\/\/t.co\/z2hLcejn",
  "id" : 269572181393014784,
  "created_at" : "2012-11-16 22:46:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Sandy",
      "indices" : [ 75, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/HMeasYkg",
      "expanded_url" : "http:\/\/on.wh.gov\/u63cr3",
      "display_url" : "on.wh.gov\/u63cr3"
    } ]
  },
  "geo" : { },
  "id_str" : "269545354872102912",
  "text" : "This week, President Obama honored Veterans Day and visited NYC to monitor #Sandy recovery efforts. Watch: http:\/\/t.co\/HMeasYkg",
  "id" : 269545354872102912,
  "created_at" : "2012-11-16 20:59:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Bloomberg",
      "screen_name" : "MikeBloomberg",
      "indices" : [ 83, 97 ],
      "id_str" : "16581604",
      "id" : 16581604
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/269528989419335680\/photo\/1",
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/UwgF6SLu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A72PMBeCcAEl9jN.jpg",
      "id_str" : "269528989427724289",
      "id" : 269528989427724289,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A72PMBeCcAEl9jN.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/UwgF6SLu"
    } ],
    "hashtags" : [ {
      "text" : "Sandy",
      "indices" : [ 46, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "269528989419335680",
  "text" : "Yesterday, President Obama surveyed Hurricane #Sandy recovery efforts w\/ NYC Mayor @MikeBloomberg aboard Marine One: http:\/\/t.co\/UwgF6SLu",
  "id" : 269528989419335680,
  "created_at" : "2012-11-16 19:54:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Treasury Department",
      "screen_name" : "USTreasury",
      "indices" : [ 3, 14 ],
      "id_str" : "120176950",
      "id" : 120176950
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/USTreasury\/status\/269436055164428289\/photo\/1",
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/m7Cogl1d",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A706qiaCIAEDqop.jpg",
      "id_str" : "269436055177011201",
      "id" : 269436055177011201,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A706qiaCIAEDqop.jpg",
      "sizes" : [ {
        "h" : 263,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1582,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 463,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 791,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/m7Cogl1d"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "269455897879781376",
  "text" : "RT @USTreasury: A closer look at how the President\u2019s plan raises $1.6T in revenue http:\/\/t.co\/m7Cogl1d",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/USTreasury\/status\/269436055164428289\/photo\/1",
        "indices" : [ 66, 86 ],
        "url" : "http:\/\/t.co\/m7Cogl1d",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A706qiaCIAEDqop.jpg",
        "id_str" : "269436055177011201",
        "id" : 269436055177011201,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A706qiaCIAEDqop.jpg",
        "sizes" : [ {
          "h" : 263,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1582,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 463,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 791,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/m7Cogl1d"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "269436055164428289",
    "text" : "A closer look at how the President\u2019s plan raises $1.6T in revenue http:\/\/t.co\/m7Cogl1d",
    "id" : 269436055164428289,
    "created_at" : "2012-11-16 13:45:36 +0000",
    "user" : {
      "name" : "Treasury Department",
      "screen_name" : "USTreasury",
      "protected" : false,
      "id_str" : "120176950",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461250108441370624\/-9PNMlfp_normal.jpeg",
      "id" : 120176950,
      "verified" : true
    }
  },
  "id" : 269455897879781376,
  "created_at" : "2012-11-16 15:04:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/269295344465084416\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/xtxpyQOu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A7y6sGMCAAA10Qn.jpg",
      "id_str" : "269295344473473024",
      "id" : 269295344473473024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A7y6sGMCAAA10Qn.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/xtxpyQOu"
    } ],
    "hashtags" : [ {
      "text" : "Sandy",
      "indices" : [ 37, 43 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/4vOECFRi",
      "expanded_url" : "http:\/\/on.wh.gov\/liKKFd",
      "display_url" : "on.wh.gov\/liKKFd"
    } ]
  },
  "geo" : { },
  "id_str" : "269295344465084416",
  "text" : "Photo Gallery: President Obama Tours #Sandy Damage in New York: http:\/\/t.co\/4vOECFRi &amp; meets with the Moore Family: http:\/\/t.co\/xtxpyQOu",
  "id" : 269295344465084416,
  "created_at" : "2012-11-16 04:26:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 75, 78 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 104, 115 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/269260959737065474\/photo\/1",
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/tH7ysmZ3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A7ybapGCMAAcBej.jpg",
      "id_str" : "269260959745454080",
      "id" : 269260959745454080,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A7ybapGCMAAcBej.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 667,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 667,
        "resize" : "fit",
        "w" : 1000
      } ],
      "display_url" : "pic.twitter.com\/tH7ysmZ3"
    } ],
    "hashtags" : [ {
      "text" : "ParksandRec",
      "indices" : [ 57, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "269260959737065474",
  "text" : "Tonight Vice President Biden makes a guest appearance on #ParksandRec Pic: @VP chats w\/ cast &amp; crew @Whitehouse: http:\/\/t.co\/tH7ysmZ3",
  "id" : 269260959737065474,
  "created_at" : "2012-11-16 02:09:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Sandy",
      "indices" : [ 95, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/VbpcYtY8",
      "expanded_url" : "http:\/\/on.wh.gov\/BwHgyI",
      "display_url" : "on.wh.gov\/BwHgyI"
    } ]
  },
  "geo" : { },
  "id_str" : "269242315292430336",
  "text" : "\"We as Americans are going to stand with each other in their hour of need.\"-President Obama to #Sandy survivors in NYC http:\/\/t.co\/VbpcYtY8",
  "id" : 269242315292430336,
  "created_at" : "2012-11-16 00:55:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gabrielle Douglas",
      "screen_name" : "gabrielledoug",
      "indices" : [ 43, 57 ],
      "id_str" : "279319647",
      "id" : 279319647
    }, {
      "name" : "Alexandra Raisman",
      "screen_name" : "Aly_Raisman",
      "indices" : [ 58, 70 ],
      "id_str" : "372891057",
      "id" : 372891057
    }, {
      "name" : "Jordyn Wieber",
      "screen_name" : "jordyn_wieber",
      "indices" : [ 71, 85 ],
      "id_str" : "35364809",
      "id" : 35364809
    }, {
      "name" : "McKayla Maroney",
      "screen_name" : "McKaylaMaroney",
      "indices" : [ 86, 101 ],
      "id_str" : "375383001",
      "id" : 375383001
    }, {
      "name" : "Kyla Ross",
      "screen_name" : "kyla_ross96",
      "indices" : [ 102, 114 ],
      "id_str" : "528717274",
      "id" : 528717274
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/269220693114249216\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/fdpIEBWH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A7x2y0PCYAAdyPz.jpg",
      "id_str" : "269220693122637824",
      "id" : 269220693122637824,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A7x2y0PCYAAdyPz.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/fdpIEBWH"
    } ],
    "hashtags" : [ {
      "text" : "TeamUSA",
      "indices" : [ 25, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "269220693114249216",
  "text" : "President Obama meets w\/ #TeamUSA gymnasts @GabrielleDoug @Aly_Raisman @Jordyn_Wieber @McKaylaMaroney @Kyla_Ross96 Pic: http:\/\/t.co\/fdpIEBWH",
  "id" : 269220693114249216,
  "created_at" : "2012-11-15 23:29:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "269185776091271171",
  "text" : "RT @vj44: Steve didn't vote for the President, but agrees we must put aside our differences to make progress. Read his letter: http:\/\/t. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/269182650214924288\/photo\/1",
        "indices" : [ 117, 137 ],
        "url" : "http:\/\/t.co\/hATephgR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A7xUMbYCQAIlsiT.jpg",
        "id_str" : "269182650219118594",
        "id" : 269182650219118594,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A7xUMbYCQAIlsiT.jpg",
        "sizes" : [ {
          "h" : 680,
          "resize" : "fit",
          "w" : 329
        }, {
          "h" : 1076,
          "resize" : "fit",
          "w" : 520
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1076,
          "resize" : "fit",
          "w" : 520
        }, {
          "h" : 1076,
          "resize" : "fit",
          "w" : 520
        } ],
        "display_url" : "pic.twitter.com\/hATephgR"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "269182650214924288",
    "text" : "Steve didn't vote for the President, but agrees we must put aside our differences to make progress. Read his letter: http:\/\/t.co\/hATephgR",
    "id" : 269182650214924288,
    "created_at" : "2012-11-15 20:58:40 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 269185776091271171,
  "created_at" : "2012-11-15 21:11:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Cuomo",
      "screen_name" : "NYGovCuomo",
      "indices" : [ 3, 14 ],
      "id_str" : "232268199",
      "id" : 232268199
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StatenIsland",
      "indices" : [ 46, 59 ]
    }, {
      "text" : "Sandy",
      "indices" : [ 75, 81 ]
    }, {
      "text" : "recovery",
      "indices" : [ 94, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/RQH4spYF",
      "expanded_url" : "http:\/\/instagr.am\/p\/SD08uIJHWN\/",
      "display_url" : "instagr.am\/p\/SD08uIJHWN\/"
    } ]
  },
  "geo" : { },
  "id_str" : "269155738448957440",
  "text" : "RT @NYGovCuomo: Gov Cuomo &amp; Pres Obama in #StatenIsland today, touring #Sandy devastation #recovery http:\/\/t.co\/RQH4spYF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "StatenIsland",
        "indices" : [ 30, 43 ]
      }, {
        "text" : "Sandy",
        "indices" : [ 59, 65 ]
      }, {
        "text" : "recovery",
        "indices" : [ 78, 87 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 108 ],
        "url" : "http:\/\/t.co\/RQH4spYF",
        "expanded_url" : "http:\/\/instagr.am\/p\/SD08uIJHWN\/",
        "display_url" : "instagr.am\/p\/SD08uIJHWN\/"
      } ]
    },
    "geo" : { },
    "id_str" : "269141252820320256",
    "text" : "Gov Cuomo &amp; Pres Obama in #StatenIsland today, touring #Sandy devastation #recovery http:\/\/t.co\/RQH4spYF",
    "id" : 269141252820320256,
    "created_at" : "2012-11-15 18:14:09 +0000",
    "user" : {
      "name" : "Andrew Cuomo",
      "screen_name" : "NYGovCuomo",
      "protected" : false,
      "id_str" : "232268199",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/788019377870348288\/83Xj5Zh3_normal.jpg",
      "id" : 232268199,
      "verified" : true
    }
  },
  "id" : 269155738448957440,
  "created_at" : "2012-11-15 19:11:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 3, 13 ],
      "id_str" : "9624742",
      "id" : 9624742
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 39, 50 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Entrepreneurship",
      "indices" : [ 73, 90 ]
    }, {
      "text" : "GES_EVA",
      "indices" : [ 116, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/HUZhUyKw",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "269139631268827136",
  "text" : "RT @StateDept: Starting now! Watch the @WhiteHouse Celebration of Global #Entrepreneurship on http:\/\/t.co\/HUZhUyKw. #GES_EVA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 24, 35 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Entrepreneurship",
        "indices" : [ 58, 75 ]
      }, {
        "text" : "GES_EVA",
        "indices" : [ 101, 109 ]
      } ],
      "urls" : [ {
        "indices" : [ 79, 99 ],
        "url" : "http:\/\/t.co\/HUZhUyKw",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "269139359381475328",
    "text" : "Starting now! Watch the @WhiteHouse Celebration of Global #Entrepreneurship on http:\/\/t.co\/HUZhUyKw. #GES_EVA",
    "id" : 269139359381475328,
    "created_at" : "2012-11-15 18:06:38 +0000",
    "user" : {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "protected" : false,
      "id_str" : "9624742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724612605185282048\/1rEfkXDZ_normal.jpg",
      "id" : 9624742,
      "verified" : true
    }
  },
  "id" : 269139631268827136,
  "created_at" : "2012-11-15 18:07:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Parks and Recreation",
      "screen_name" : "parksandrecnbc",
      "indices" : [ 45, 60 ],
      "id_str" : "20630639",
      "id" : 20630639
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 75, 78 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 106, 117 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/VP\/status\/269115432710070273\/photo\/1",
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/UO5E0S1d",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A7wXD2qCYAItUgu.jpg",
      "id_str" : "269115432714264578",
      "id" : 269115432714264578,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A7wXD2qCYAItUgu.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 667,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 667,
        "resize" : "fit",
        "w" : 1000
      } ],
      "display_url" : "pic.twitter.com\/UO5E0S1d"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "269117154346020864",
  "text" : "RT @VP: VP Biden makes a guest appearance on @parksandrecnbc tonight. Pic: @VP &amp; Leslie on set at the @whitehouse: http:\/\/t.co\/UO5E0S1d",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Parks and Recreation",
        "screen_name" : "parksandrecnbc",
        "indices" : [ 37, 52 ],
        "id_str" : "20630639",
        "id" : 20630639
      }, {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 67, 70 ],
        "id_str" : "325830217",
        "id" : 325830217
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 98, 109 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/VP\/status\/269115432710070273\/photo\/1",
        "indices" : [ 111, 131 ],
        "url" : "http:\/\/t.co\/UO5E0S1d",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A7wXD2qCYAItUgu.jpg",
        "id_str" : "269115432714264578",
        "id" : 269115432714264578,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A7wXD2qCYAItUgu.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        } ],
        "display_url" : "pic.twitter.com\/UO5E0S1d"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "269115432710070273",
    "text" : "VP Biden makes a guest appearance on @parksandrecnbc tonight. Pic: @VP &amp; Leslie on set at the @whitehouse: http:\/\/t.co\/UO5E0S1d",
    "id" : 269115432710070273,
    "created_at" : "2012-11-15 16:31:34 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 269117154346020864,
  "created_at" : "2012-11-15 16:38:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Sandy",
      "indices" : [ 61, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "269111069660831745",
  "text" : "Today, President Obama travels to New York to view Hurricane #Sandy damage, talk to citizens who are recovering &amp; thank first responders.",
  "id" : 269111069660831745,
  "created_at" : "2012-11-15 16:14:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 82, 93 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/268914276348092416\/photo\/1",
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/fOJNChnX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A7tgHA0CYAA7E_8.jpg",
      "id_str" : "268914276352286720",
      "id" : 268914276352286720,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A7tgHA0CYAA7E_8.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/fOJNChnX"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "268914276348092416",
  "text" : "Photo of the Day: President Obama is introduced as he enters the East Room of the @whitehouse for a news conference: http:\/\/t.co\/fOJNChnX",
  "id" : 268914276348092416,
  "created_at" : "2012-11-15 03:12:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/gHtpb5aa",
      "expanded_url" : "http:\/\/blogs.wsj.com\/washwire\/2012\/11\/14\/wal-marts-duke-to-d-c-avoid-the-fiscal-cliff\/",
      "display_url" : "blogs.wsj.com\/washwire\/2012\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "268889879868497922",
  "text" : "RT @Brundage44: Wal-Mart CEO who met w\/ POTUS today says Washington must act to avoid tax uncertainty for consumers http:\/\/t.co\/gHtpb5aa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 120 ],
        "url" : "http:\/\/t.co\/gHtpb5aa",
        "expanded_url" : "http:\/\/blogs.wsj.com\/washwire\/2012\/11\/14\/wal-marts-duke-to-d-c-avoid-the-fiscal-cliff\/",
        "display_url" : "blogs.wsj.com\/washwire\/2012\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "268889385087414272",
    "text" : "Wal-Mart CEO who met w\/ POTUS today says Washington must act to avoid tax uncertainty for consumers http:\/\/t.co\/gHtpb5aa",
    "id" : 268889385087414272,
    "created_at" : "2012-11-15 01:33:19 +0000",
    "user" : {
      "name" : "Liz Allen",
      "screen_name" : "LizAllen44",
      "protected" : false,
      "id_str" : "562456722",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705867932392407042\/-1npI72O_normal.jpg",
      "id" : 562456722,
      "verified" : true
    }
  },
  "id" : 268889879868497922,
  "created_at" : "2012-11-15 01:35:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/zhOAduYM",
      "expanded_url" : "http:\/\/on.wh.gov\/00dmwm",
      "display_url" : "on.wh.gov\/00dmwm"
    } ]
  },
  "geo" : { },
  "id_str" : "268883583148625920",
  "text" : "President Obama: \"I've got a mandate to help middle-class families &amp; families that are working hard\" Watch: http:\/\/t.co\/zhOAduYM",
  "id" : 268883583148625920,
  "created_at" : "2012-11-15 01:10:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "268879477168295936",
  "text" : "RT @pfeiffer44: \"I\u2019ve got a mandate to help middle-class families\" -President Obama during today's news conference. Watch: http:\/\/t.co\/B ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 127 ],
        "url" : "http:\/\/t.co\/B7juujXc",
        "expanded_url" : "http:\/\/youtu.be\/gaF6rzT-eWg",
        "display_url" : "youtu.be\/gaF6rzT-eWg"
      } ]
    },
    "geo" : { },
    "id_str" : "268878274283843584",
    "text" : "\"I\u2019ve got a mandate to help middle-class families\" -President Obama during today's news conference. Watch: http:\/\/t.co\/B7juujXc",
    "id" : 268878274283843584,
    "created_at" : "2012-11-15 00:49:10 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 268879477168295936,
  "created_at" : "2012-11-15 00:53:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/268868027330736128\/photo\/1",
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/ueWBZUoc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A7s2C90CMAELQ9W.jpg",
      "id_str" : "268868027339124737",
      "id" : 268868027339124737,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A7s2C90CMAELQ9W.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/ueWBZUoc"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/xEcbEQ85",
      "expanded_url" : "http:\/\/on.wh.gov\/RuKliR",
      "display_url" : "on.wh.gov\/RuKliR"
    } ]
  },
  "geo" : { },
  "id_str" : "268868027330736128",
  "text" : "President Obama: \"There's only one way to solve these challenges &amp; that is to do it together\" http:\/\/t.co\/xEcbEQ85 http:\/\/t.co\/ueWBZUoc",
  "id" : 268868027330736128,
  "created_at" : "2012-11-15 00:08:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/PICYK7R5",
      "expanded_url" : "http:\/\/on.wh.gov\/qKqF4A",
      "display_url" : "on.wh.gov\/qKqF4A"
    } ]
  },
  "geo" : { },
  "id_str" : "268826933905723393",
  "text" : "President Obama: \"This nation succeeds when we've got a growing, thriving middle class.\" Watch: http:\/\/t.co\/PICYK7R5",
  "id" : 268826933905723393,
  "created_at" : "2012-11-14 21:25:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/Cx9cTnTQ",
      "expanded_url" : "http:\/\/on.wh.gov\/Ry1Php",
      "display_url" : "on.wh.gov\/Ry1Php"
    } ]
  },
  "geo" : { },
  "id_str" : "268788023540469760",
  "text" : "\"I'm open to compromise and I'm open to new ideas\" -President Obama http:\/\/t.co\/Cx9cTnTQ",
  "id" : 268788023540469760,
  "created_at" : "2012-11-14 18:50:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "268785344277782528",
  "text" : "RT @WHLive: President Obama: I believe that both parties can work together to make these decisions in a balanced &amp; responsible way",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "268784235370934272",
    "text" : "President Obama: I believe that both parties can work together to make these decisions in a balanced &amp; responsible way",
    "id" : 268784235370934272,
    "created_at" : "2012-11-14 18:35:30 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 268785344277782528,
  "created_at" : "2012-11-14 18:39:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/vbaE6hJm",
      "expanded_url" : "http:\/\/at.wh.gov\/fi6BX",
      "display_url" : "at.wh.gov\/fi6BX"
    } ]
  },
  "geo" : { },
  "id_str" : "268783842003935232",
  "text" : "Happening now: President Obama holds a news conference in the East Room of the White House. Watch live: http:\/\/t.co\/vbaE6hJm",
  "id" : 268783842003935232,
  "created_at" : "2012-11-14 18:33:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/YF6zCTJu",
      "expanded_url" : "http:\/\/on.wh.gov\/VO9g8Y",
      "display_url" : "on.wh.gov\/VO9g8Y"
    } ]
  },
  "geo" : { },
  "id_str" : "268737238706315265",
  "text" : "Today at 1:30 ET, President Obama will hold a news conference in the East Room of the White House. Watch it live: http:\/\/t.co\/YF6zCTJu",
  "id" : 268737238706315265,
  "created_at" : "2012-11-14 15:28:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/268521653452021760\/photo\/1",
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/wbgPzIle",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A7n7BWkCIAAH4Cc.jpg",
      "id_str" : "268521653460410368",
      "id" : 268521653460410368,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A7n7BWkCIAAH4Cc.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/wbgPzIle"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http:\/\/t.co\/urR7MWYl",
      "expanded_url" : "http:\/\/on.wh.gov\/qBIQ2b",
      "display_url" : "on.wh.gov\/qBIQ2b"
    } ]
  },
  "geo" : { },
  "id_str" : "268521653452021760",
  "text" : "Statement by President Obama on Diwali: http:\/\/t.co\/urR7MWYl Photo: The Obamas mark Diwali in India in 2010: http:\/\/t.co\/wbgPzIle",
  "id" : 268521653452021760,
  "created_at" : "2012-11-14 01:12:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "268477883331272704",
  "text" : "RT @vj44: This week, the President is meeting with business, labor &amp; civic leaders to hear their ideas. Together, we can move our ec ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "268463362571108353",
    "text" : "This week, the President is meeting with business, labor &amp; civic leaders to hear their ideas. Together, we can move our economy forward.",
    "id" : 268463362571108353,
    "created_at" : "2012-11-13 21:20:28 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 268477883331272704,
  "created_at" : "2012-11-13 22:18:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/268447749022814208\/photo\/1",
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/xSVkBDZv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A7m3zjGCEAEJiFs.jpg",
      "id_str" : "268447749027008513",
      "id" : 268447749027008513,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A7m3zjGCEAEJiFs.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/xSVkBDZv"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/NrTrIJA5",
      "expanded_url" : "http:\/\/on.wh.gov\/dIMvAS",
      "display_url" : "on.wh.gov\/dIMvAS"
    } ]
  },
  "geo" : { },
  "id_str" : "268447749022814208",
  "text" : "So who are those 14 people standing behind the President? http:\/\/t.co\/NrTrIJA5 http:\/\/t.co\/xSVkBDZv",
  "id" : 268447749022814208,
  "created_at" : "2012-11-13 20:18:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Sandy",
      "indices" : [ 88, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/UeyNfSYa",
      "expanded_url" : "http:\/\/on.wh.gov\/PcfkeC",
      "display_url" : "on.wh.gov\/PcfkeC"
    } ]
  },
  "geo" : { },
  "id_str" : "268432513398095872",
  "text" : "On Thursday, President Obama travels to New York to visit areas devastated by Hurricane #Sandy. How you can help: http:\/\/t.co\/UeyNfSYa",
  "id" : 268432513398095872,
  "created_at" : "2012-11-13 19:17:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 125, 145 ],
      "url" : "http:\/\/t.co\/atQ0a4by",
      "expanded_url" : "http:\/\/on.wh.gov\/Dhn17m",
      "display_url" : "on.wh.gov\/Dhn17m"
    } ]
  },
  "geo" : { },
  "id_str" : "268416782568665089",
  "text" : "\"To those celebrating Diwali, I wish you, your families &amp; loved ones Happy Diwali &amp; Saal Mubarak.\" -President Obama: http:\/\/t.co\/atQ0a4by",
  "id" : 268416782568665089,
  "created_at" : "2012-11-13 18:15:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "indices" : [ 3, 10 ],
      "id_str" : "44783853",
      "id" : 44783853
    }, {
      "name" : "Everyday Health",
      "screen_name" : "EverydayHealth",
      "indices" : [ 72, 87 ],
      "id_str" : "17393790",
      "id" : 17393790
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 110, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http:\/\/t.co\/vG6pYomT",
      "expanded_url" : "http:\/\/bit.ly\/UmlTmV",
      "display_url" : "bit.ly\/UmlTmV"
    } ]
  },
  "geo" : { },
  "id_str" : "268383024691961856",
  "text" : "RT @HHSGov: Sec. Sebelius answers your questions about Health Care, via @EverydayHealth. http:\/\/t.co\/vG6pYomT #ACA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Everyday Health",
        "screen_name" : "EverydayHealth",
        "indices" : [ 60, 75 ],
        "id_str" : "17393790",
        "id" : 17393790
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ACA",
        "indices" : [ 98, 102 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 97 ],
        "url" : "http:\/\/t.co\/vG6pYomT",
        "expanded_url" : "http:\/\/bit.ly\/UmlTmV",
        "display_url" : "bit.ly\/UmlTmV"
      } ]
    },
    "geo" : { },
    "id_str" : "268381367723769857",
    "text" : "Sec. Sebelius answers your questions about Health Care, via @EverydayHealth. http:\/\/t.co\/vG6pYomT #ACA",
    "id" : 268381367723769857,
    "created_at" : "2012-11-13 15:54:39 +0000",
    "user" : {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "protected" : false,
      "id_str" : "44783853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567350542326718464\/FXOsgyA7_normal.jpeg",
      "id" : 44783853,
      "verified" : true
    }
  },
  "id" : 268383024691961856,
  "created_at" : "2012-11-13 16:01:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Veterans",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/mYHW1VBo",
      "expanded_url" : "http:\/\/on.wh.gov\/JXFMZi",
      "display_url" : "on.wh.gov\/JXFMZi"
    } ]
  },
  "geo" : { },
  "id_str" : "268186658124464129",
  "text" : "Presidential Proclamation in honor of #Veterans Day, November 11, 2012: http:\/\/t.co\/mYHW1VBo",
  "id" : 268186658124464129,
  "created_at" : "2012-11-13 03:00:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/268089363177566208\/photo\/1",
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/tr1ggVGH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A7hx2vzCcAAvXcw.jpg",
      "id_str" : "268089363185954816",
      "id" : 268089363185954816,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A7hx2vzCcAAvXcw.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/tr1ggVGH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "268089363177566208",
  "text" : "Photo of the Day: President Obama lays a wreath at Arlington National Cemetery on Veterans Day: http:\/\/t.co\/tr1ggVGH",
  "id" : 268089363177566208,
  "created_at" : "2012-11-12 20:34:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Dept of Defense",
      "screen_name" : "DeptofDefense",
      "indices" : [ 3, 17 ],
      "id_str" : "66369181",
      "id" : 66369181
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DOD",
      "indices" : [ 55, 59 ]
    }, {
      "text" : "Veterans",
      "indices" : [ 107, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/siXH93Ln",
      "expanded_url" : "http:\/\/ow.ly\/fdwqr",
      "display_url" : "ow.ly\/fdwqr"
    } ]
  },
  "geo" : { },
  "id_str" : "268054466652147712",
  "text" : "RT @DeptofDefense: Here's a special report on all that #DOD did yesterday and continues to do to honor our #Veterans: http:\/\/t.co\/siXH93Ln",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DOD",
        "indices" : [ 36, 40 ]
      }, {
        "text" : "Veterans",
        "indices" : [ 88, 97 ]
      } ],
      "urls" : [ {
        "indices" : [ 99, 119 ],
        "url" : "http:\/\/t.co\/siXH93Ln",
        "expanded_url" : "http:\/\/ow.ly\/fdwqr",
        "display_url" : "ow.ly\/fdwqr"
      } ]
    },
    "geo" : { },
    "id_str" : "268051831123476480",
    "text" : "Here's a special report on all that #DOD did yesterday and continues to do to honor our #Veterans: http:\/\/t.co\/siXH93Ln",
    "id" : 268051831123476480,
    "created_at" : "2012-11-12 18:05:11 +0000",
    "user" : {
      "name" : "U.S. Dept of Defense",
      "screen_name" : "DeptofDefense",
      "protected" : false,
      "id_str" : "66369181",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/533350546027995137\/b84VANoF_normal.png",
      "id" : 66369181,
      "verified" : true
    }
  },
  "id" : 268054466652147712,
  "created_at" : "2012-11-12 18:15:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/267790339237105664\/photo\/1",
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/ga95NIHC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A7dh5Q0CUAAcAm4.jpg",
      "id_str" : "267790339245494272",
      "id" : 267790339245494272,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A7dh5Q0CUAAcAm4.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/ga95NIHC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "267790339237105664",
  "text" : "Today, President Obama \"laid a wreath to remember every service member who has ever worn our nation's uniform.\" http:\/\/t.co\/ga95NIHC",
  "id" : 267790339237105664,
  "created_at" : "2012-11-12 00:46:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 123, 143 ],
      "url" : "http:\/\/t.co\/eBYNXQyr",
      "expanded_url" : "http:\/\/on.wh.gov\/fBM1q1",
      "display_url" : "on.wh.gov\/fBM1q1"
    } ]
  },
  "geo" : { },
  "id_str" : "267759786345500673",
  "text" : "\"We must commit \u2013 this day &amp; every day \u2013 to serving you as well as you've served us\" -President Obama on Veterans Day: http:\/\/t.co\/eBYNXQyr",
  "id" : 267759786345500673,
  "created_at" : "2012-11-11 22:44:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/ncgKVEem",
      "expanded_url" : "http:\/\/on.wh.gov\/0q30HA",
      "display_url" : "on.wh.gov\/0q30HA"
    } ]
  },
  "geo" : { },
  "id_str" : "267732963217793024",
  "text" : "Today, President Obama honored our nation's veterans &amp; military families at Arlington National Cemetery. Watch: http:\/\/t.co\/ncgKVEem",
  "id" : 267732963217793024,
  "created_at" : "2012-11-11 20:58:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/4xjJG4YY",
      "expanded_url" : "http:\/\/wh.gov\/9E43",
      "display_url" : "wh.gov\/9E43"
    } ]
  },
  "geo" : { },
  "id_str" : "267681648798208000",
  "text" : "RT @JoiningForces: This Veterans Day, we hope you'll join First Lady Michelle Obama and thank an American hero: http:\/\/t.co\/4xjJG4YY htt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JoiningForces\/status\/267677969516986369\/photo\/1",
        "indices" : [ 114, 134 ],
        "url" : "http:\/\/t.co\/BPfBZ7vD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A7b7sfACAAABx4s.jpg",
        "id_str" : "267677969529569280",
        "id" : 267677969529569280,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A7b7sfACAAABx4s.jpg",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 797,
          "resize" : "fit",
          "w" : 797
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 797,
          "resize" : "fit",
          "w" : 797
        } ],
        "display_url" : "pic.twitter.com\/BPfBZ7vD"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 113 ],
        "url" : "http:\/\/t.co\/4xjJG4YY",
        "expanded_url" : "http:\/\/wh.gov\/9E43",
        "display_url" : "wh.gov\/9E43"
      } ]
    },
    "geo" : { },
    "id_str" : "267677969516986369",
    "text" : "This Veterans Day, we hope you'll join First Lady Michelle Obama and thank an American hero: http:\/\/t.co\/4xjJG4YY http:\/\/t.co\/BPfBZ7vD",
    "id" : 267677969516986369,
    "created_at" : "2012-11-11 17:19:36 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 267681648798208000,
  "created_at" : "2012-11-11 17:34:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Veterans Affairs",
      "screen_name" : "DeptVetAffairs",
      "indices" : [ 3, 18 ],
      "id_str" : "78408666",
      "id" : 78408666
    }, {
      "name" : "Arlington Cemetery",
      "screen_name" : "ArlingtonNatl",
      "indices" : [ 98, 112 ],
      "id_str" : "102455692",
      "id" : 102455692
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/DeptVetAffairs\/status\/267671311424299009\/photo\/1",
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/MiKC0T3J",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A7b1o7qCIAI8Dvw.jpg",
      "id_str" : "267671311432687618",
      "id" : 267671311432687618,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A7b1o7qCIAI8Dvw.jpg",
      "sizes" : [ {
        "h" : 420,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 717,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 238,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 717,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/MiKC0T3J"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "267675959170322432",
  "text" : "RT @DeptVetAffairs: President Obama speaks about the sacred obligation to ensure Veterans care at @ArlingtonNatl http:\/\/t.co\/MiKC0T3J",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Arlington Cemetery",
        "screen_name" : "ArlingtonNatl",
        "indices" : [ 78, 92 ],
        "id_str" : "102455692",
        "id" : 102455692
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DeptVetAffairs\/status\/267671311424299009\/photo\/1",
        "indices" : [ 93, 113 ],
        "url" : "http:\/\/t.co\/MiKC0T3J",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A7b1o7qCIAI8Dvw.jpg",
        "id_str" : "267671311432687618",
        "id" : 267671311432687618,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A7b1o7qCIAI8Dvw.jpg",
        "sizes" : [ {
          "h" : 420,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 717,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 238,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 717,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/MiKC0T3J"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "267671311424299009",
    "text" : "President Obama speaks about the sacred obligation to ensure Veterans care at @ArlingtonNatl http:\/\/t.co\/MiKC0T3J",
    "id" : 267671311424299009,
    "created_at" : "2012-11-11 16:53:08 +0000",
    "user" : {
      "name" : "Veterans Affairs",
      "screen_name" : "DeptVetAffairs",
      "protected" : false,
      "id_str" : "78408666",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/344513261565984455\/a9fcce7feb947b2ec498491c6c6d6985_normal.png",
      "id" : 78408666,
      "verified" : true
    }
  },
  "id" : 267675959170322432,
  "created_at" : "2012-11-11 17:11:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "267668001774514178",
  "text" : "President Obama on Veterans Day: \"We must commit \u2013 this day and every day \u2013 to serving you as well as you\u2019ve served us\"",
  "id" : 267668001774514178,
  "created_at" : "2012-11-11 16:39:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/LyiLV7Pd",
      "expanded_url" : "http:\/\/on.wh.gov\/kx2Lgv",
      "display_url" : "on.wh.gov\/kx2Lgv"
    } ]
  },
  "geo" : { },
  "id_str" : "267666939776753664",
  "text" : "Happening now: President Obama honors Veterans Day at Arlington National Cemetery. Watch live: http:\/\/t.co\/LyiLV7Pd",
  "id" : 267666939776753664,
  "created_at" : "2012-11-11 16:35:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Veterans Affairs",
      "screen_name" : "DeptVetAffairs",
      "indices" : [ 3, 18 ],
      "id_str" : "78408666",
      "id" : 78408666
    }, {
      "name" : "Arlington Cemetery",
      "screen_name" : "ArlingtonNatl",
      "indices" : [ 83, 97 ],
      "id_str" : "102455692",
      "id" : 102455692
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 101, 112 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/DeptVetAffairs\/status\/267665343533678592\/photo\/1",
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/ZRRoEh4I",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A7bwNjiCAAApd4M.jpg",
      "id_str" : "267665343542067200",
      "id" : 267665343542067200,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A7bwNjiCAAApd4M.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/ZRRoEh4I"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "267666211897225216",
  "text" : "RT @DeptVetAffairs: President Obama places a wreath at the Tomb of the Unknowns at @arlingtonnatl cc @whitehouse http:\/\/t.co\/ZRRoEh4I",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Arlington Cemetery",
        "screen_name" : "ArlingtonNatl",
        "indices" : [ 63, 77 ],
        "id_str" : "102455692",
        "id" : 102455692
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 81, 92 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DeptVetAffairs\/status\/267665343533678592\/photo\/1",
        "indices" : [ 93, 113 ],
        "url" : "http:\/\/t.co\/ZRRoEh4I",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A7bwNjiCAAApd4M.jpg",
        "id_str" : "267665343542067200",
        "id" : 267665343542067200,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A7bwNjiCAAApd4M.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/ZRRoEh4I"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "267665343533678592",
    "text" : "President Obama places a wreath at the Tomb of the Unknowns at @arlingtonnatl cc @whitehouse http:\/\/t.co\/ZRRoEh4I",
    "id" : 267665343533678592,
    "created_at" : "2012-11-11 16:29:26 +0000",
    "user" : {
      "name" : "Veterans Affairs",
      "screen_name" : "DeptVetAffairs",
      "protected" : false,
      "id_str" : "78408666",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/344513261565984455\/a9fcce7feb947b2ec498491c6c6d6985_normal.png",
      "id" : 78408666,
      "verified" : true
    }
  },
  "id" : 267666211897225216,
  "created_at" : "2012-11-11 16:32:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Veterans Affairs",
      "screen_name" : "DeptVetAffairs",
      "indices" : [ 3, 18 ],
      "id_str" : "78408666",
      "id" : 78408666
    }, {
      "name" : "Arlington Cemetery",
      "screen_name" : "ArlingtonNatl",
      "indices" : [ 47, 61 ],
      "id_str" : "102455692",
      "id" : 102455692
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/DeptVetAffairs\/status\/267632260520476672\/photo\/1",
      "indices" : [ 62, 82 ],
      "url" : "http:\/\/t.co\/lBHsmBdM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A7bSH3sCAAEHffj.jpg",
      "id_str" : "267632260524670977",
      "id" : 267632260524670977,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A7bSH3sCAAEHffj.jpg",
      "sizes" : [ {
        "h" : 1016,
        "resize" : "fit",
        "w" : 991
      }, {
        "h" : 349,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1016,
        "resize" : "fit",
        "w" : 991
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 615,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/lBHsmBdM"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/u95tzH8r",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "267654946562920449",
  "text" : "RT @DeptVetAffairs A beautiful Veterans Day at @ArlingtonNatl http:\/\/t.co\/lBHsmBdM \/\/ President Obama speaks @ 11:15ET: http:\/\/t.co\/u95tzH8r",
  "id" : 267654946562920449,
  "created_at" : "2012-11-11 15:48:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 46, 49 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/267436761389617153\/photo\/1",
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/6pBNCW1p",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A7YgUUsCUAEmdDm.jpg",
      "id_str" : "267436761398005761",
      "id" : 267436761398005761,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A7YgUUsCUAEmdDm.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/6pBNCW1p"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "267436761389617153",
  "text" : "Photo of the Day: President Obama stands with @VP Biden in the Green Room before speaking on the economy: http:\/\/t.co\/6pBNCW1p",
  "id" : 267436761389617153,
  "created_at" : "2012-11-11 01:21:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/akgUICTJ",
      "expanded_url" : "http:\/\/on.wh.gov\/AInsBF",
      "display_url" : "on.wh.gov\/AInsBF"
    } ]
  },
  "geo" : { },
  "id_str" : "267319377911758849",
  "text" : "In his Weekly Address, President Obama talks about extending middle class tax cuts to grow the economy. Watch: http:\/\/t.co\/akgUICTJ",
  "id" : 267319377911758849,
  "created_at" : "2012-11-10 17:34:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/qDJOkMak",
      "expanded_url" : "http:\/\/on.wh.gov\/wmsUAD",
      "display_url" : "on.wh.gov\/wmsUAD"
    } ]
  },
  "geo" : { },
  "id_str" : "267257904615268353",
  "text" : "President Obama: \"You voted for action, not politics as usual. You elected us to focus on your jobs, not ours.\" Watch: http:\/\/t.co\/qDJOkMak",
  "id" : 267257904615268353,
  "created_at" : "2012-11-10 13:30:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "267257361398390784",
  "text" : "\"\u200EI'm open to compromise. I'm open to new ideas...But I refuse to accept any approach that isn't balanced\" -President Obama",
  "id" : 267257361398390784,
  "created_at" : "2012-11-10 13:28:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/267208349718810624\/photo\/1",
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/rjVx0RWR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A7VQlA6CEAAL6O6.jpg",
      "id_str" : "267208349727199232",
      "id" : 267208349727199232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A7VQlA6CEAAL6O6.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/rjVx0RWR"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/Y3yLb6SC",
      "expanded_url" : "http:\/\/on.wh.gov\/oEk1Yw",
      "display_url" : "on.wh.gov\/oEk1Yw"
    } ]
  },
  "geo" : { },
  "id_str" : "267208349718810624",
  "text" : "\"The American people voted for action, not politics as usual.\" -President Obama: http:\/\/t.co\/Y3yLb6SC Photo: http:\/\/t.co\/rjVx0RWR",
  "id" : 267208349718810624,
  "created_at" : "2012-11-10 10:13:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/m24A16Hf",
      "expanded_url" : "http:\/\/on.wh.gov\/cmDslA",
      "display_url" : "on.wh.gov\/cmDslA"
    } ]
  },
  "geo" : { },
  "id_str" : "267121628406759425",
  "text" : "President Obama will become the first U.S. President to visit Burma later this month: http:\/\/t.co\/m24A16Hf",
  "id" : 267121628406759425,
  "created_at" : "2012-11-10 04:28:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Sandy",
      "indices" : [ 37, 43 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/4fA2f7qI",
      "expanded_url" : "http:\/\/on.wh.gov\/1ATuh6",
      "display_url" : "on.wh.gov\/1ATuh6"
    } ]
  },
  "geo" : { },
  "id_str" : "267049739315470338",
  "text" : "This week, President Obama monitored #Sandy recovery &amp; addressed the nation on the work that lies ahead. Watch: http:\/\/t.co\/4fA2f7qI",
  "id" : 267049739315470338,
  "created_at" : "2012-11-09 23:43:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/267034575845330944\/photo\/1",
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/QdCbJEQF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A7SyiCyCEAAd2d7.jpg",
      "id_str" : "267034575853719552",
      "id" : 267034575853719552,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A7SyiCyCEAAd2d7.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 403,
        "resize" : "fit",
        "w" : 403
      }, {
        "h" : 403,
        "resize" : "fit",
        "w" : 403
      }, {
        "h" : 403,
        "resize" : "fit",
        "w" : 403
      } ],
      "display_url" : "pic.twitter.com\/QdCbJEQF"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/qDsOAVyN",
      "expanded_url" : "http:\/\/on.wh.gov\/WB8Eso",
      "display_url" : "on.wh.gov\/WB8Eso"
    } ]
  },
  "geo" : { },
  "id_str" : "267034575845330944",
  "text" : "Today, President Obama laid out his strategy to grow the economy &amp; reduce our deficits: http:\/\/t.co\/qDsOAVyN http:\/\/t.co\/QdCbJEQF",
  "id" : 267034575845330944,
  "created_at" : "2012-11-09 22:42:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/7fZdfz95",
      "expanded_url" : "http:\/\/on.wh.gov\/Xj8Lt7",
      "display_url" : "on.wh.gov\/Xj8Lt7"
    } ]
  },
  "geo" : { },
  "id_str" : "266984811317579776",
  "text" : "President Obama: \"The American people are looking for is cooperation...Most of all, they want action.\" Watch: http:\/\/t.co\/7fZdfz95",
  "id" : 266984811317579776,
  "created_at" : "2012-11-09 19:25:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266967509075390464",
  "text" : "President Obama: \"[The American people] want cooperation. They want consensus. They want common sense. And most of all, they want action.\"",
  "id" : 266967509075390464,
  "created_at" : "2012-11-09 18:16:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266966467663237120",
  "text" : "President Obama: \"I\u2019m committed to solving our fiscal challenges. But I refuse to accept any approach that isn\u2019t balanced.\"",
  "id" : 266966467663237120,
  "created_at" : "2012-11-09 18:12:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266966177480318976",
  "text" : "President Obama: \"If we\u2019re serious about reducing the deficit, we have to combine spending cuts with revenue.\"",
  "id" : 266966177480318976,
  "created_at" : "2012-11-09 18:11:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266965811724439552",
  "text" : "RT @WHLive: President Obama: \"At a time when our economy is still recovering from the Great Recession, our top priority has to be jobs a ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "266965709844791296",
    "text" : "President Obama: \"At a time when our economy is still recovering from the Great Recession, our top priority has to be jobs and growth.\"",
    "id" : 266965709844791296,
    "created_at" : "2012-11-09 18:09:19 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 266965811724439552,
  "created_at" : "2012-11-09 18:09:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 135, 142 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 37 ],
      "url" : "http:\/\/t.co\/u95tzH8r",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "266965105508499456",
  "text" : "Happening now on http:\/\/t.co\/u95tzH8r: President Obama speaks on ways to grow our economy &amp; reduce our deficit. Follow live tweets @WHLive",
  "id" : 266965105508499456,
  "created_at" : "2012-11-09 18:06:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 127, 134 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/ZnJTOD77",
      "expanded_url" : "http:\/\/on.wh.gov\/ImgGuU",
      "display_url" : "on.wh.gov\/ImgGuU"
    } ]
  },
  "geo" : { },
  "id_str" : "266929907286810624",
  "text" : "Today at 1pm ET: President Obama speaks on growing our economy &amp; reducing our deficit. Watch: http:\/\/t.co\/ZnJTOD77 Follow: @WHLive",
  "id" : 266929907286810624,
  "created_at" : "2012-11-09 15:47:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/266729898561921024\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/F3vrcrUT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A7OdbfcCYAEHLKW.jpg",
      "id_str" : "266729898566115329",
      "id" : 266729898566115329,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A7OdbfcCYAEHLKW.jpg",
      "sizes" : [ {
        "h" : 1351,
        "resize" : "fit",
        "w" : 2028
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/F3vrcrUT"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/G0UhCRsP",
      "expanded_url" : "http:\/\/on.wh.gov\/BI4dq9",
      "display_url" : "on.wh.gov\/BI4dq9"
    } ]
  },
  "geo" : { },
  "id_str" : "266729898561921024",
  "text" : "Photo of the Day: President Obama talks on the phone with world leaders in the Oval Office: http:\/\/t.co\/G0UhCRsP Photo: http:\/\/t.co\/F3vrcrUT",
  "id" : 266729898561921024,
  "created_at" : "2012-11-09 02:32:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266687361629450240",
  "text" : "Tomorrow at 1pm ET, President Obama will speak about action we need to take to keep our economy growing &amp; reduce our deficit.",
  "id" : 266687361629450240,
  "created_at" : "2012-11-08 23:43:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ray LaHood",
      "screen_name" : "RayLaHood",
      "indices" : [ 3, 13 ],
      "id_str" : "1563604279",
      "id" : 1563604279
    }, {
      "name" : "TransportationGov",
      "screen_name" : "USDOT",
      "indices" : [ 74, 80 ],
      "id_str" : "393562221",
      "id" : 393562221
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Sandy",
      "indices" : [ 15, 21 ]
    }, {
      "text" : "fuel",
      "indices" : [ 92, 97 ]
    }, {
      "text" : "housing",
      "indices" : [ 99, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/nZ2aK9Oq",
      "expanded_url" : "http:\/\/1.usa.gov\/UytoHI",
      "display_url" : "1.usa.gov\/UytoHI"
    } ]
  },
  "geo" : { },
  "id_str" : "266681132899246080",
  "text" : "RT @RayLaHood: #Sandy recovery efforts continue as latest storm moves on; @USDOT working on #fuel, #housing delivery http:\/\/t.co\/nZ2aK9Oq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "TransportationGov",
        "screen_name" : "USDOT",
        "indices" : [ 59, 65 ],
        "id_str" : "393562221",
        "id" : 393562221
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Sandy",
        "indices" : [ 0, 6 ]
      }, {
        "text" : "fuel",
        "indices" : [ 77, 82 ]
      }, {
        "text" : "housing",
        "indices" : [ 84, 92 ]
      } ],
      "urls" : [ {
        "indices" : [ 102, 122 ],
        "url" : "http:\/\/t.co\/nZ2aK9Oq",
        "expanded_url" : "http:\/\/1.usa.gov\/UytoHI",
        "display_url" : "1.usa.gov\/UytoHI"
      } ]
    },
    "geo" : { },
    "id_str" : "266628263839944704",
    "text" : "#Sandy recovery efforts continue as latest storm moves on; @USDOT working on #fuel, #housing delivery http:\/\/t.co\/nZ2aK9Oq",
    "id" : 266628263839944704,
    "created_at" : "2012-11-08 19:48:26 +0000",
    "user" : {
      "name" : "Anthony Foxx",
      "screen_name" : "SecretaryFoxx",
      "protected" : false,
      "id_str" : "43920155",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746015409707622400\/clFVYNWs_normal.jpg",
      "id" : 43920155,
      "verified" : true
    }
  },
  "id" : 266681132899246080,
  "created_at" : "2012-11-08 23:18:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FEMA",
      "screen_name" : "fema",
      "indices" : [ 68, 73 ],
      "id_str" : "16669075",
      "id" : 16669075
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/266640134190034947\/photo\/1",
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/njTPdmsT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A7NLyhHCcAIGfth.jpg",
      "id_str" : "266640134198423554",
      "id" : 266640134198423554,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A7NLyhHCcAIGfth.jpg",
      "sizes" : [ {
        "h" : 678,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1044,
        "resize" : "fit",
        "w" : 1577
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 397,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/njTPdmsT"
    } ],
    "hashtags" : [ {
      "text" : "Sandy",
      "indices" : [ 34, 40 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/9ECMOHvu",
      "expanded_url" : "http:\/\/on.wh.gov\/5VsM0Z",
      "display_url" : "on.wh.gov\/5VsM0Z"
    } ]
  },
  "geo" : { },
  "id_str" : "266640134190034947",
  "text" : "Find ways to help after Hurricane #Sandy: http:\/\/t.co\/9ECMOHvu Pic: @FEMA workers assess the situation in New York: http:\/\/t.co\/njTPdmsT",
  "id" : 266640134190034947,
  "created_at" : "2012-11-08 20:35:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Carson",
      "screen_name" : "JonCarson44",
      "indices" : [ 3, 15 ],
      "id_str" : "1287388789",
      "id" : 1287388789
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/WP2OlZ8z",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/engage",
      "display_url" : "whitehouse.gov\/engage"
    } ]
  },
  "geo" : { },
  "id_str" : "266603205406912512",
  "text" : "RT @JonCarson44: On Tuesday night, President Obama said our work isn't done.  Check out http:\/\/t.co\/WP2OlZ8z for ways you can engage w\/  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 91 ],
        "url" : "http:\/\/t.co\/WP2OlZ8z",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/engage",
        "display_url" : "whitehouse.gov\/engage"
      } ]
    },
    "geo" : { },
    "id_str" : "266530640671948802",
    "text" : "On Tuesday night, President Obama said our work isn't done.  Check out http:\/\/t.co\/WP2OlZ8z for ways you can engage w\/ the Administration",
    "id" : 266530640671948802,
    "created_at" : "2012-11-08 13:20:31 +0000",
    "user" : {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "protected" : false,
      "id_str" : "369232105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623146355767140352\/58sqoVrw_normal.jpg",
      "id" : 369232105,
      "verified" : true
    }
  },
  "id" : 266603205406912512,
  "created_at" : "2012-11-08 18:08:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FEMA",
      "screen_name" : "fema",
      "indices" : [ 3, 8 ],
      "id_str" : "16669075",
      "id" : 16669075
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Sandy",
      "indices" : [ 30, 36 ]
    }, {
      "text" : "NJ",
      "indices" : [ 96, 99 ]
    }, {
      "text" : "NY",
      "indices" : [ 100, 103 ]
    }, {
      "text" : "CT",
      "indices" : [ 104, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/rqZHY0UQ",
      "expanded_url" : "http:\/\/www.fema.gov\/sandy",
      "display_url" : "fema.gov\/sandy"
    } ]
  },
  "geo" : { },
  "id_str" : "266557771577692160",
  "text" : "RT @fema: Accurate and timely #Sandy-related information can be found at: http:\/\/t.co\/rqZHY0UQ  #NJ #NY #CT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Sandy",
        "indices" : [ 20, 26 ]
      }, {
        "text" : "NJ",
        "indices" : [ 86, 89 ]
      }, {
        "text" : "NY",
        "indices" : [ 90, 93 ]
      }, {
        "text" : "CT",
        "indices" : [ 94, 97 ]
      } ],
      "urls" : [ {
        "indices" : [ 64, 84 ],
        "url" : "http:\/\/t.co\/rqZHY0UQ",
        "expanded_url" : "http:\/\/www.fema.gov\/sandy",
        "display_url" : "fema.gov\/sandy"
      } ]
    },
    "geo" : { },
    "id_str" : "266556508798586880",
    "text" : "Accurate and timely #Sandy-related information can be found at: http:\/\/t.co\/rqZHY0UQ  #NJ #NY #CT",
    "id" : 266556508798586880,
    "created_at" : "2012-11-08 15:03:18 +0000",
    "user" : {
      "name" : "FEMA",
      "screen_name" : "fema",
      "protected" : false,
      "id_str" : "16669075",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2620163192\/j143q33k69loivqmp2dg_normal.gif",
      "id" : 16669075,
      "verified" : true
    }
  },
  "id" : 266557771577692160,
  "created_at" : "2012-11-08 15:08:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 28, 31 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/266367263727288320\/photo\/1",
      "indices" : [ 123, 143 ],
      "url" : "http:\/\/t.co\/5ycVpqin",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A7JTnXbCAAAdCYF.jpg",
      "id_str" : "266367263735676928",
      "id" : 266367263735676928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A7JTnXbCAAAdCYF.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 865,
        "resize" : "fit",
        "w" : 1297
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/5ycVpqin"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266367263727288320",
  "text" : "Photo: President Obama hugs @VP Biden in Chicago on Nov 6. The First Lady &amp; daughters Sasha &amp; Malia join on stage: http:\/\/t.co\/5ycVpqin",
  "id" : 266367263727288320,
  "created_at" : "2012-11-08 02:31:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/266335333493379072\/photo\/1",
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/dPKwq9nU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A7I2kyDCEAE4lnD.jpg",
      "id_str" : "266335333505961985",
      "id" : 266335333505961985,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A7I2kyDCEAE4lnD.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/dPKwq9nU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "266335333493379072",
  "text" : "\"America has never been about what can be done for us. It's about what can be done by us, together\" -President Obama http:\/\/t.co\/dPKwq9nU",
  "id" : 266335333493379072,
  "created_at" : "2012-11-08 00:24:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/NJTeAsc1",
      "expanded_url" : "http:\/\/on.wh.gov\/EmYL3y",
      "display_url" : "on.wh.gov\/EmYL3y"
    } ]
  },
  "geo" : { },
  "id_str" : "266304581884059648",
  "text" : "UPDATE: Due to bad weather, we are no longer able to live stream President Obama's arrival at the White House. http:\/\/t.co\/NJTeAsc1",
  "id" : 266304581884059648,
  "created_at" : "2012-11-07 22:22:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Homeland Security",
      "screen_name" : "DHSgov",
      "indices" : [ 3, 10 ],
      "id_str" : "15647676",
      "id" : 15647676
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "noreaster",
      "indices" : [ 48, 58 ]
    }, {
      "text" : "NJ",
      "indices" : [ 83, 86 ]
    }, {
      "text" : "NY",
      "indices" : [ 87, 90 ]
    }, {
      "text" : "CT",
      "indices" : [ 91, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http:\/\/t.co\/IrQYnT3n",
      "expanded_url" : "http:\/\/ready.gov\/winter-weather",
      "display_url" : "ready.gov\/winter-weather"
    } ]
  },
  "geo" : { },
  "id_str" : "266290241009238016",
  "text" : "RT @DHSgov: Find tips for staying safe during a #noreaster at http:\/\/t.co\/IrQYnT3n #NJ #NY #CT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "noreaster",
        "indices" : [ 36, 46 ]
      }, {
        "text" : "NJ",
        "indices" : [ 71, 74 ]
      }, {
        "text" : "NY",
        "indices" : [ 75, 78 ]
      }, {
        "text" : "CT",
        "indices" : [ 79, 82 ]
      } ],
      "urls" : [ {
        "indices" : [ 50, 70 ],
        "url" : "http:\/\/t.co\/IrQYnT3n",
        "expanded_url" : "http:\/\/ready.gov\/winter-weather",
        "display_url" : "ready.gov\/winter-weather"
      } ]
    },
    "geo" : { },
    "id_str" : "266287668999106560",
    "text" : "Find tips for staying safe during a #noreaster at http:\/\/t.co\/IrQYnT3n #NJ #NY #CT",
    "id" : 266287668999106560,
    "created_at" : "2012-11-07 21:15:02 +0000",
    "user" : {
      "name" : "Homeland Security",
      "screen_name" : "DHSgov",
      "protected" : false,
      "id_str" : "15647676",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/936215926\/dhs-twitter-300_normal.jpg",
      "id" : 15647676,
      "verified" : true
    }
  },
  "id" : 266290241009238016,
  "created_at" : "2012-11-07 21:25:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/266244524362313728\/photo\/1",
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/UOA51qKq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A7Hj-_pCMAACUcy.jpg",
      "id_str" : "266244524366508032",
      "id" : 266244524366508032,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A7Hj-_pCMAACUcy.jpg",
      "sizes" : [ {
        "h" : 781,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 511,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 781,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 781,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/UOA51qKq"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/Xdyk7P0o",
      "expanded_url" : "http:\/\/on.wh.gov\/3smSZJ",
      "display_url" : "on.wh.gov\/3smSZJ"
    } ]
  },
  "geo" : { },
  "id_str" : "266244524362313728",
  "text" : "Today, President Obama returns to the White House. Watch his arrival live at 5:20pm ET: http:\/\/t.co\/Xdyk7P0o http:\/\/t.co\/UOA51qKq",
  "id" : 266244524362313728,
  "created_at" : "2012-11-07 18:23:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FEMA",
      "screen_name" : "fema",
      "indices" : [ 3, 8 ],
      "id_str" : "16669075",
      "id" : 16669075
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Sandy",
      "indices" : [ 64, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http:\/\/t.co\/b2s7owzH",
      "expanded_url" : "http:\/\/on.wh.gov\/gDT5Sc",
      "display_url" : "on.wh.gov\/gDT5Sc"
    } ]
  },
  "geo" : { },
  "id_str" : "265915712160296960",
  "text" : "RT @FEMA: Check out: http:\/\/t.co\/b2s7owzH for ways to help with #Sandy relief efforts. Cash is best, donate blood, &amp; get more info.",
  "id" : 265915712160296960,
  "created_at" : "2012-11-06 20:37:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Sandy",
      "indices" : [ 69, 75 ]
    } ],
    "urls" : [ {
      "indices" : [ 121, 141 ],
      "url" : "http:\/\/t.co\/QuAHE8x8",
      "expanded_url" : "http:\/\/on.wh.gov\/r7aUxt",
      "display_url" : "on.wh.gov\/r7aUxt"
    } ]
  },
  "geo" : { },
  "id_str" : "265894762643607552",
  "text" : "Today, President Obama convened a call to get an update on Hurricane #Sandy response &amp; recovery efforts. More info:  http:\/\/t.co\/QuAHE8x8",
  "id" : 265894762643607552,
  "created_at" : "2012-11-06 19:13:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SBA",
      "screen_name" : "SBAgov",
      "indices" : [ 20, 27 ],
      "id_str" : "153149305",
      "id" : 153149305
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Sandy",
      "indices" : [ 12, 18 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/LyVVmss9",
      "expanded_url" : "http:\/\/on.wh.gov\/DSvYBo",
      "display_url" : "on.wh.gov\/DSvYBo"
    } ]
  },
  "geo" : { },
  "id_str" : "265551790517399552",
  "text" : "Impacted by #Sandy? @SBAgov has resources to help you rebuild your home or business: http:\/\/t.co\/LyVVmss9",
  "id" : 265551790517399552,
  "created_at" : "2012-11-05 20:30:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Homeland Security",
      "screen_name" : "DHSgov",
      "indices" : [ 3, 10 ],
      "id_str" : "15647676",
      "id" : 15647676
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Sandy",
      "indices" : [ 39, 45 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/jO1uxD24",
      "expanded_url" : "http:\/\/www.disasterassistance.gov",
      "display_url" : "disasterassistance.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "265528564894560256",
  "text" : "RT @DHSgov: If you\u2019ve been affected by #Sandy you can apply for assistance online at http:\/\/t.co\/jO1uxD24  or call 1-800-621-FEMA (3362)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Sandy",
        "indices" : [ 27, 33 ]
      } ],
      "urls" : [ {
        "indices" : [ 73, 93 ],
        "url" : "http:\/\/t.co\/jO1uxD24",
        "expanded_url" : "http:\/\/www.disasterassistance.gov",
        "display_url" : "disasterassistance.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "265521498738020352",
    "text" : "If you\u2019ve been affected by #Sandy you can apply for assistance online at http:\/\/t.co\/jO1uxD24  or call 1-800-621-FEMA (3362)",
    "id" : 265521498738020352,
    "created_at" : "2012-11-05 18:30:33 +0000",
    "user" : {
      "name" : "Homeland Security",
      "screen_name" : "DHSgov",
      "protected" : false,
      "id_str" : "15647676",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/936215926\/dhs-twitter-300_normal.jpg",
      "id" : 15647676,
      "verified" : true
    }
  },
  "id" : 265528564894560256,
  "created_at" : "2012-11-05 18:58:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FEMA",
      "screen_name" : "fema",
      "indices" : [ 73, 78 ],
      "id_str" : "16669075",
      "id" : 16669075
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/265426397529526272\/photo\/1",
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/imFfg1Wm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A6775vsCUAIciz3.jpg",
      "id_str" : "265426397533720578",
      "id" : 265426397533720578,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A6775vsCUAIciz3.jpg",
      "sizes" : [ {
        "h" : 678,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1332,
        "resize" : "fit",
        "w" : 2013
      }, {
        "h" : 397,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/imFfg1Wm"
    } ],
    "hashtags" : [ {
      "text" : "Sandy",
      "indices" : [ 66, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/Qorw8Mqm",
      "expanded_url" : "http:\/\/on.wh.gov\/Obv3Oy",
      "display_url" : "on.wh.gov\/Obv3Oy"
    } ]
  },
  "geo" : { },
  "id_str" : "265426397529526272",
  "text" : "President Obama receives a briefing about the ongoing response to #Sandy @FEMA HQ: http:\/\/t.co\/Qorw8Mqm Photo: http:\/\/t.co\/imFfg1Wm",
  "id" : 265426397529526272,
  "created_at" : "2012-11-05 12:12:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/265224233020448769\/photo\/1",
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/qYRpmdwS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A65ECOOCYAExKn_.jpg",
      "id_str" : "265224233028837377",
      "id" : 265224233028837377,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A65ECOOCYAExKn_.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/qYRpmdwS"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265224233020448769",
  "text" : "President Obama: \"We recover, we rebuild, we come back stronger \u2013 and together we will do that once more.\" http:\/\/t.co\/qYRpmdwS",
  "id" : 265224233020448769,
  "created_at" : "2012-11-04 22:49:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Sandy",
      "indices" : [ 102, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/OgX8aqZS",
      "expanded_url" : "http:\/\/on.wh.gov\/yAxz2R",
      "display_url" : "on.wh.gov\/yAxz2R"
    } ]
  },
  "geo" : { },
  "id_str" : "264846146902564864",
  "text" : "\"When the storm was darkest, the heroism of our fellow citizens shone brightest.\" -President Obama on #Sandy: http:\/\/t.co\/OgX8aqZS",
  "id" : 264846146902564864,
  "created_at" : "2012-11-03 21:46:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Sandy",
      "indices" : [ 116, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 124, 144 ],
      "url" : "http:\/\/t.co\/A6Z05yk5",
      "expanded_url" : "http:\/\/on.wh.gov\/Poaocy",
      "display_url" : "on.wh.gov\/Poaocy"
    } ]
  },
  "geo" : { },
  "id_str" : "264719866525798400",
  "text" : "\"Your country will be there for you for as long as it takes to recover &amp; rebuild\" -President Obama on Hurricane #Sandy: http:\/\/t.co\/A6Z05yk5",
  "id" : 264719866525798400,
  "created_at" : "2012-11-03 13:25:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/3mAzEkDY",
      "expanded_url" : "http:\/\/on.wh.gov\/g2AOkE",
      "display_url" : "on.wh.gov\/g2AOkE"
    }, {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/vQfCjx0X",
      "expanded_url" : "http:\/\/wh.gov\/sandy",
      "display_url" : "wh.gov\/sandy"
    } ]
  },
  "geo" : { },
  "id_str" : "264712830979289088",
  "text" : "In times of crisis, Americans look out for one another. Watch: http:\/\/t.co\/3mAzEkDY &amp; find out how to help: http:\/\/t.co\/vQfCjx0X",
  "id" : 264712830979289088,
  "created_at" : "2012-11-03 12:57:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FEMA",
      "screen_name" : "fema",
      "indices" : [ 3, 8 ],
      "id_str" : "16669075",
      "id" : 16669075
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Sandy",
      "indices" : [ 122, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "264565036851273730",
  "text" : "RT @fema: Tell friends &amp; family w\/o internet access to call 1-800-RED CROSS (1-800-733-2767) for the closest shelter. #Sandy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Sandy",
        "indices" : [ 112, 118 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "264510573260189696",
    "text" : "Tell friends &amp; family w\/o internet access to call 1-800-RED CROSS (1-800-733-2767) for the closest shelter. #Sandy",
    "id" : 264510573260189696,
    "created_at" : "2012-11-02 23:33:29 +0000",
    "user" : {
      "name" : "FEMA",
      "screen_name" : "fema",
      "protected" : false,
      "id_str" : "16669075",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2620163192\/j143q33k69loivqmp2dg_normal.gif",
      "id" : 16669075,
      "verified" : true
    }
  },
  "id" : 264565036851273730,
  "created_at" : "2012-11-03 03:09:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil Goldfeder",
      "screen_name" : "YPGoldfeder",
      "indices" : [ 3, 15 ],
      "id_str" : "166286545",
      "id" : 166286545
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 48, 59 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/YPGoldfeder\/status\/264430593507471360\/photo\/1",
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/9fNrBr0B",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A6tyOUoCMAANMZD.jpg",
      "id_str" : "264430593511665664",
      "id" : 264430593511665664,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A6tyOUoCMAANMZD.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/9fNrBr0B"
    } ],
    "hashtags" : [ {
      "text" : "Recovery",
      "indices" : [ 108, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "264498420495024128",
  "text" : "RT @YPGoldfeder: Visited Rockaway families with @whitehouse Chief of Staff, Jack Lew. Thank you for caring! #Recovery http:\/\/t.co\/9fNrBr0B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 31, 42 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/YPGoldfeder\/status\/264430593507471360\/photo\/1",
        "indices" : [ 101, 121 ],
        "url" : "http:\/\/t.co\/9fNrBr0B",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A6tyOUoCMAANMZD.jpg",
        "id_str" : "264430593511665664",
        "id" : 264430593511665664,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A6tyOUoCMAANMZD.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/9fNrBr0B"
      } ],
      "hashtags" : [ {
        "text" : "Recovery",
        "indices" : [ 91, 100 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "264430593507471360",
    "text" : "Visited Rockaway families with @whitehouse Chief of Staff, Jack Lew. Thank you for caring! #Recovery http:\/\/t.co\/9fNrBr0B",
    "id" : 264430593507471360,
    "created_at" : "2012-11-02 18:15:41 +0000",
    "user" : {
      "name" : "Phil Goldfeder",
      "screen_name" : "YPGoldfeder",
      "protected" : false,
      "id_str" : "166286545",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776573645904674816\/YNU0aDbN_normal.jpg",
      "id" : 166286545,
      "verified" : false
    }
  },
  "id" : 264498420495024128,
  "created_at" : "2012-11-02 22:45:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "jearnest44",
      "indices" : [ 3, 14 ],
      "id_str" : "369238541",
      "id" : 369238541
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Sandy",
      "indices" : [ 124, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "264483184832565248",
  "text" : "RT @jearnest44: Obama admin using military aircraft to fly in assets from Cali that will help restore power to areas hit by #Sandy http: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Sandy",
        "indices" : [ 108, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 135 ],
        "url" : "http:\/\/t.co\/jG1nSGGR",
        "expanded_url" : "http:\/\/www.boston.com\/business\/news\/2012\/11\/01\/military-flying-power-equipment-storm-area\/yq5KtXOVmsrzHz5PxURVlK\/story.html",
        "display_url" : "boston.com\/business\/news\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "264127081774989312",
    "text" : "Obama admin using military aircraft to fly in assets from Cali that will help restore power to areas hit by #Sandy http:\/\/t.co\/jG1nSGGR",
    "id" : 264127081774989312,
    "created_at" : "2012-11-01 22:09:38 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "jearnest44",
      "protected" : false,
      "id_str" : "369238541",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1769108407\/Twitter_profile_photo_real_normal.JPG",
      "id" : 369238541,
      "verified" : true
    }
  },
  "id" : 264483184832565248,
  "created_at" : "2012-11-02 21:44:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Sandy",
      "indices" : [ 35, 41 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/hVpE3zt9",
      "expanded_url" : "http:\/\/on.wh.gov\/W5cwDR",
      "display_url" : "on.wh.gov\/W5cwDR"
    } ]
  },
  "geo" : { },
  "id_str" : "264477536786989058",
  "text" : "This week, President Obama visited #Sandy survivors in NJ &amp; spoke on the recovery ahead. Watch your West Wing Week: http:\/\/t.co\/hVpE3zt9",
  "id" : 264477536786989058,
  "created_at" : "2012-11-02 21:22:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Cuomo",
      "screen_name" : "NYGovCuomo",
      "indices" : [ 57, 68 ],
      "id_str" : "232268199",
      "id" : 232268199
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/264449418055516161\/photo\/1",
      "indices" : [ 123, 143 ],
      "url" : "http:\/\/t.co\/GhZl6D4N",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A6uDWDjCAAAOO3h.jpg",
      "id_str" : "264449418063904768",
      "id" : 264449418063904768,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A6uDWDjCAAAOO3h.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/GhZl6D4N"
    } ],
    "hashtags" : [ {
      "text" : "Sandy",
      "indices" : [ 115, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "264449418055516161",
  "text" : "Photo of the Day: President Obama holds a call to update @NYGovCuomo &amp; NY officials on the federal response to #Sandy: http:\/\/t.co\/GhZl6D4N",
  "id" : 264449418055516161,
  "created_at" : "2012-11-02 19:30:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Cuomo",
      "screen_name" : "NYGovCuomo",
      "indices" : [ 3, 14 ],
      "id_str" : "232268199",
      "id" : 232268199
    }, {
      "name" : "U.S. Air Force",
      "screen_name" : "usairforce",
      "indices" : [ 19, 30 ],
      "id_str" : "19611483",
      "id" : 19611483
    }, {
      "name" : "NY National Guard",
      "screen_name" : "NationalGuardNY",
      "indices" : [ 120, 136 ],
      "id_str" : "48711058",
      "id" : 48711058
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "power",
      "indices" : [ 53, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/EDVOZCUF",
      "expanded_url" : "http:\/\/www.flickr.com\/photos\/governorandrewcuomo\/8146155758\/in\/photostream",
      "display_url" : "flickr.com\/photos\/governo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "264447500801409024",
  "text" : "RT @NYGovCuomo: TY @usairforce for helping transport #power equip. from CA, answering our call http:\/\/t.co\/EDVOZCUF via @NationalGuardNY ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "U.S. Air Force",
        "screen_name" : "usairforce",
        "indices" : [ 3, 14 ],
        "id_str" : "19611483",
        "id" : 19611483
      }, {
        "name" : "NY National Guard",
        "screen_name" : "NationalGuardNY",
        "indices" : [ 104, 120 ],
        "id_str" : "48711058",
        "id" : 48711058
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "power",
        "indices" : [ 37, 43 ]
      }, {
        "text" : "recovery",
        "indices" : [ 121, 130 ]
      } ],
      "urls" : [ {
        "indices" : [ 79, 99 ],
        "url" : "http:\/\/t.co\/EDVOZCUF",
        "expanded_url" : "http:\/\/www.flickr.com\/photos\/governorandrewcuomo\/8146155758\/in\/photostream",
        "display_url" : "flickr.com\/photos\/governo\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "264142485952028673",
    "text" : "TY @usairforce for helping transport #power equip. from CA, answering our call http:\/\/t.co\/EDVOZCUF via @NationalGuardNY #recovery",
    "id" : 264142485952028673,
    "created_at" : "2012-11-01 23:10:50 +0000",
    "user" : {
      "name" : "Andrew Cuomo",
      "screen_name" : "NYGovCuomo",
      "protected" : false,
      "id_str" : "232268199",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/788019377870348288\/83Xj5Zh3_normal.jpg",
      "id" : 232268199,
      "verified" : true
    }
  },
  "id" : 264447500801409024,
  "created_at" : "2012-11-02 19:22:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Carson",
      "screen_name" : "JonCarson44",
      "indices" : [ 3, 15 ],
      "id_str" : "1287388789",
      "id" : 1287388789
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http:\/\/t.co\/3B7AM4om",
      "expanded_url" : "http:\/\/youtu.be\/r_kWNVDFhmE",
      "display_url" : "youtu.be\/r_kWNVDFhmE"
    } ]
  },
  "geo" : { },
  "id_str" : "264395013071458304",
  "text" : "RT @JonCarson44: In times of crisis, Americans look out for one another: http:\/\/t.co\/3B7AM4om Find out how you can help: http:\/\/t.co\/h1I ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 76 ],
        "url" : "http:\/\/t.co\/3B7AM4om",
        "expanded_url" : "http:\/\/youtu.be\/r_kWNVDFhmE",
        "display_url" : "youtu.be\/r_kWNVDFhmE"
      }, {
        "indices" : [ 104, 124 ],
        "url" : "http:\/\/t.co\/h1IMavaC",
        "expanded_url" : "http:\/\/WH.gov\/sandy",
        "display_url" : "WH.gov\/sandy"
      } ]
    },
    "geo" : { },
    "id_str" : "264392263419969536",
    "text" : "In times of crisis, Americans look out for one another: http:\/\/t.co\/3B7AM4om Find out how you can help: http:\/\/t.co\/h1IMavaC",
    "id" : 264392263419969536,
    "created_at" : "2012-11-02 15:43:22 +0000",
    "user" : {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "protected" : false,
      "id_str" : "369232105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623146355767140352\/58sqoVrw_normal.jpg",
      "id" : 369232105,
      "verified" : true
    }
  },
  "id" : 264395013071458304,
  "created_at" : "2012-11-02 15:54:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/264381945478250497\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/HtHqOzMi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A6tF-omCAAMtmZW.jpg",
      "id_str" : "264381945482444803",
      "id" : 264381945482444803,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A6tF-omCAAMtmZW.jpg",
      "sizes" : [ {
        "h" : 1013,
        "resize" : "fit",
        "w" : 865
      }, {
        "h" : 398,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 703,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1013,
        "resize" : "fit",
        "w" : 865
      } ],
      "display_url" : "pic.twitter.com\/HtHqOzMi"
    } ],
    "hashtags" : [ {
      "text" : "s",
      "indices" : [ 9, 11 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/HMq3FOKn",
      "expanded_url" : "http:\/\/on.wh.gov\/zUUEId",
      "display_url" : "on.wh.gov\/zUUEId"
    } ]
  },
  "geo" : { },
  "id_str" : "264381945478250497",
  "text" : "New jobs #s: US economy adds 184k private sector jobs in Oct, 5.4M jobs over 32 months: http:\/\/t.co\/HMq3FOKn More to do http:\/\/t.co\/HtHqOzMi",
  "id" : 264381945478250497,
  "created_at" : "2012-11-02 15:02:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FEMA",
      "screen_name" : "fema",
      "indices" : [ 11, 16 ],
      "id_str" : "16669075",
      "id" : 16669075
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Sandy",
      "indices" : [ 133, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "264352839143411712",
  "text" : "Please RT: @fema: Text SHELTER + your ZIP code to 43362 (4FEMA) to find the nearest shelter in your area. Standard text rates apply. #Sandy",
  "id" : 264352839143411712,
  "created_at" : "2012-11-02 13:06:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Governor Christie",
      "screen_name" : "GovChristie",
      "indices" : [ 107, 119 ],
      "id_str" : "90484508",
      "id" : 90484508
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/264082058756907009\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/TqYm5Hra",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A6o1O7hCYAA7HrX.jpg",
      "id_str" : "264082058765295616",
      "id" : 264082058765295616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A6o1O7hCYAA7HrX.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/TqYm5Hra"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/qzByyT3e",
      "expanded_url" : "http:\/\/on.wh.gov\/eduEAQ",
      "display_url" : "on.wh.gov\/eduEAQ"
    } ]
  },
  "geo" : { },
  "id_str" : "264082058756907009",
  "text" : "Photo gallery: President Obama views storm damage in NJ: http:\/\/t.co\/qzByyT3e Here talking to survivors w\/ @GovChristie http:\/\/t.co\/TqYm5Hra",
  "id" : 264082058756907009,
  "created_at" : "2012-11-01 19:10:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Governor Christie",
      "screen_name" : "GovChristie",
      "indices" : [ 40, 52 ],
      "id_str" : "90484508",
      "id" : 90484508
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/264056055187795971\/photo\/1",
      "indices" : [ 124, 144 ],
      "url" : "http:\/\/t.co\/ZEgdZR5T",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A6odlUrCcAAhthS.jpg",
      "id_str" : "264056055196184576",
      "id" : 264056055196184576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A6odlUrCcAAhthS.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ZEgdZR5T"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "264056055187795971",
  "text" : "Photo of the day: President Obama &amp; @GovChristie view storm damage along the New Jersey coast on Marine One helicopter: http:\/\/t.co\/ZEgdZR5T",
  "id" : 264056055187795971,
  "created_at" : "2012-11-01 17:27:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
} ]