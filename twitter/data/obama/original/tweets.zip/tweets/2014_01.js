Grailbird.data.tweets_2014_01 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Denver Broncos",
      "screen_name" : "Broncos",
      "indices" : [ 17, 25 ],
      "id_str" : "18734310",
      "id" : 18734310
    }, {
      "name" : "Seattle Seahawks",
      "screen_name" : "Seahawks",
      "indices" : [ 30, 39 ],
      "id_str" : "23642374",
      "id" : 23642374
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/429412263515004928\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/NnopE3ZWLZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfWULazCQAAqbEd.jpg",
      "id_str" : "429412263376601088",
      "id" : 429412263376601088,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfWULazCQAAqbEd.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 683
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 683
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/NnopE3ZWLZ"
    } ],
    "hashtags" : [ {
      "text" : "Omaha",
      "indices" : [ 68, 74 ]
    }, {
      "text" : "12thMan",
      "indices" : [ 79, 87 ]
    }, {
      "text" : "SuperBowlXLVIII",
      "indices" : [ 88, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "429412263515004928",
  "text" : "Good luck to the @Broncos and @Seahawks!\nWho's gonna win it all?\n1. #Omaha!\n2. #12thMan\n#SuperBowlXLVIII, http:\/\/t.co\/NnopE3ZWLZ",
  "id" : 429412263515004928,
  "created_at" : "2014-02-01 00:33:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "City of Syracuse",
      "screen_name" : "Syracuse1848",
      "indices" : [ 107, 120 ],
      "id_str" : "871951412",
      "id" : 871951412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "429402648673284096",
  "text" : "RT @VP: Mayor Miner -- Duke may be a worthy opponent, but I'm sticking with the Orange for this one.  --VP @Syracuse1848 http:\/\/t.co\/Mmg1Sy\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "City of Syracuse",
        "screen_name" : "Syracuse1848",
        "indices" : [ 99, 112 ],
        "id_str" : "871951412",
        "id" : 871951412
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/429401101390348288\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/Mmg1SyDRM7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BfWKBsNIYAA762W.jpg",
        "id_str" : "429401101134487552",
        "id" : 429401101134487552,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfWKBsNIYAA762W.jpg",
        "sizes" : [ {
          "h" : 480,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 819,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 272,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 819,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/Mmg1SyDRM7"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "429401101390348288",
    "text" : "Mayor Miner -- Duke may be a worthy opponent, but I'm sticking with the Orange for this one.  --VP @Syracuse1848 http:\/\/t.co\/Mmg1SyDRM7",
    "id" : 429401101390348288,
    "created_at" : "2014-01-31 23:49:35 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 429402648673284096,
  "created_at" : "2014-01-31 23:55:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin",
      "screen_name" : "Erin44",
      "indices" : [ 3, 10 ],
      "id_str" : "41044637",
      "id" : 41044637
    }, {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "indices" : [ 36, 48 ],
      "id_str" : "369232105",
      "id" : 369232105
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 54, 65 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FromageFriday",
      "indices" : [ 18, 32 ]
    }, {
      "text" : "BigBlockOfCheeseDay",
      "indices" : [ 96, 116 ]
    }, {
      "text" : "SoGouda",
      "indices" : [ 121, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "429399089013612544",
  "text" : "RT @Erin44: A big #FromageFriday to @PAniskoff44, the @WhiteHouse tweeter who answered the most #BigBlockOfCheeseDay Qs! #SoGouda http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Paulette Aniskoff",
        "screen_name" : "PAniskoff44",
        "indices" : [ 24, 36 ],
        "id_str" : "369232105",
        "id" : 369232105
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 42, 53 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Erin44\/status\/429398889783775232\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/IccGSaljjJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BfWIA-VCUAAtlqN.jpg",
        "id_str" : "429398889796358144",
        "id" : 429398889796358144,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfWIA-VCUAAtlqN.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/IccGSaljjJ"
      } ],
      "hashtags" : [ {
        "text" : "FromageFriday",
        "indices" : [ 6, 20 ]
      }, {
        "text" : "BigBlockOfCheeseDay",
        "indices" : [ 84, 104 ]
      }, {
        "text" : "SoGouda",
        "indices" : [ 109, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "429398889783775232",
    "text" : "A big #FromageFriday to @PAniskoff44, the @WhiteHouse tweeter who answered the most #BigBlockOfCheeseDay Qs! #SoGouda http:\/\/t.co\/IccGSaljjJ",
    "id" : 429398889783775232,
    "created_at" : "2014-01-31 23:40:47 +0000",
    "user" : {
      "name" : "Alex Wall",
      "screen_name" : "Alex44",
      "protected" : false,
      "id_str" : "2169098419",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/632215085256081409\/_vjZ92WM_normal.jpg",
      "id" : 2169098419,
      "verified" : true
    }
  },
  "id" : 429399089013612544,
  "created_at" : "2014-01-31 23:41:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WestWingWeek",
      "indices" : [ 0, 13 ]
    }, {
      "text" : "Astronauts",
      "indices" : [ 84, 95 ]
    }, {
      "text" : "Space",
      "indices" : [ 96, 102 ]
    }, {
      "text" : "POTUSOnBoard",
      "indices" : [ 103, 116 ]
    }, {
      "text" : "SOTU",
      "indices" : [ 117, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/yInY9zGTSt",
      "expanded_url" : "http:\/\/go.wh.gov\/msBUK8",
      "display_url" : "go.wh.gov\/msBUK8"
    } ]
  },
  "geo" : { },
  "id_str" : "429393608241057792",
  "text" : "#WestWingWeek turns 200, and this one's pretty epic. Watch \u2192 http:\/\/t.co\/yInY9zGTSt #Astronauts #Space #POTUSOnBoard #SOTU",
  "id" : 429393608241057792,
  "created_at" : "2014-01-31 23:19:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Penny Pritzker",
      "screen_name" : "PennyPritzker",
      "indices" : [ 3, 17 ],
      "id_str" : "308573576",
      "id" : 308573576
    }, {
      "name" : "The Cabinet",
      "screen_name" : "Cabinet",
      "indices" : [ 44, 52 ],
      "id_str" : "1854981890",
      "id" : 1854981890
    }, {
      "name" : "Instagram",
      "screen_name" : "instagram",
      "indices" : [ 66, 76 ],
      "id_str" : "180505807",
      "id" : 180505807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/NBu5yjfqtu",
      "expanded_url" : "http:\/\/instagram.com\/p\/j1xqM3Cbeh\/",
      "display_url" : "instagram.com\/p\/j1xqM3Cbeh\/"
    } ]
  },
  "geo" : { },
  "id_str" : "429385373643710465",
  "text" : "RT @PennyPritzker: Very excited to be first @Cabinet secretary on @Instagram http:\/\/t.co\/NBu5yjfqtu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Cabinet",
        "screen_name" : "Cabinet",
        "indices" : [ 25, 33 ],
        "id_str" : "1854981890",
        "id" : 1854981890
      }, {
        "name" : "Instagram",
        "screen_name" : "instagram",
        "indices" : [ 47, 57 ],
        "id_str" : "180505807",
        "id" : 180505807
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/NBu5yjfqtu",
        "expanded_url" : "http:\/\/instagram.com\/p\/j1xqM3Cbeh\/",
        "display_url" : "instagram.com\/p\/j1xqM3Cbeh\/"
      } ]
    },
    "geo" : { },
    "id_str" : "429300126981824512",
    "text" : "Very excited to be first @Cabinet secretary on @Instagram http:\/\/t.co\/NBu5yjfqtu",
    "id" : 429300126981824512,
    "created_at" : "2014-01-31 17:08:20 +0000",
    "user" : {
      "name" : "Penny Pritzker",
      "screen_name" : "PennyPritzker",
      "protected" : false,
      "id_str" : "308573576",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000260306047\/1faea5d057983d2f15a31efc6b696ab5_normal.jpeg",
      "id" : 308573576,
      "verified" : true
    }
  },
  "id" : 429385373643710465,
  "created_at" : "2014-01-31 22:47:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Lubin44\/status\/429374904002031616\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/MLL9ugMudU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfVyM0UCMAAf1Jg.jpg",
      "id_str" : "429374904010420224",
      "id" : 429374904010420224,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfVyM0UCMAAf1Jg.jpg",
      "sizes" : [ {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/MLL9ugMudU"
    } ],
    "hashtags" : [ {
      "text" : "POTUSRoadTrip",
      "indices" : [ 89, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/PmRlsClktk",
      "expanded_url" : "http:\/\/go.wh.gov\/QbGESm",
      "display_url" : "go.wh.gov\/QbGESm"
    } ]
  },
  "geo" : { },
  "id_str" : "429377334479970304",
  "text" : "RT @Lubin44: POTUS being POTUS. Check out the full hangout --&gt; http:\/\/t.co\/PmRlsClktk #POTUSRoadTrip http:\/\/t.co\/MLL9ugMudU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Lubin44\/status\/429374904002031616\/photo\/1",
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/MLL9ugMudU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BfVyM0UCMAAf1Jg.jpg",
        "id_str" : "429374904010420224",
        "id" : 429374904010420224,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfVyM0UCMAAf1Jg.jpg",
        "sizes" : [ {
          "h" : 1365,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/MLL9ugMudU"
      } ],
      "hashtags" : [ {
        "text" : "POTUSRoadTrip",
        "indices" : [ 76, 90 ]
      } ],
      "urls" : [ {
        "indices" : [ 53, 75 ],
        "url" : "http:\/\/t.co\/PmRlsClktk",
        "expanded_url" : "http:\/\/go.wh.gov\/QbGESm",
        "display_url" : "go.wh.gov\/QbGESm"
      } ]
    },
    "geo" : { },
    "id_str" : "429374904002031616",
    "text" : "POTUS being POTUS. Check out the full hangout --&gt; http:\/\/t.co\/PmRlsClktk #POTUSRoadTrip http:\/\/t.co\/MLL9ugMudU",
    "id" : 429374904002031616,
    "created_at" : "2014-01-31 22:05:29 +0000",
    "user" : {
      "name" : "Lindsay Holst",
      "screen_name" : "Holst44",
      "protected" : false,
      "id_str" : "1563426390",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615987325261082625\/QxtC65p2_normal.jpg",
      "id" : 1563426390,
      "verified" : true
    }
  },
  "id" : 429377334479970304,
  "created_at" : "2014-01-31 22:15:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 33, 43 ],
      "id_str" : "9624742",
      "id" : 9624742
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Sochi",
      "indices" : [ 51, 57 ]
    }, {
      "text" : "TeamUSA",
      "indices" : [ 92, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/q5RQ23k2Wb",
      "expanded_url" : "http:\/\/goo.gl\/C4qpzR",
      "display_url" : "goo.gl\/C4qpzR"
    } ]
  },
  "geo" : { },
  "id_str" : "429362238349402112",
  "text" : "RT @NSCPress: Great new video by @StateDept on our #Sochi athletes: http:\/\/t.co\/q5RQ23k2Wb. #TeamUSA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Department of State",
        "screen_name" : "StateDept",
        "indices" : [ 19, 29 ],
        "id_str" : "9624742",
        "id" : 9624742
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Sochi",
        "indices" : [ 37, 43 ]
      }, {
        "text" : "TeamUSA",
        "indices" : [ 78, 86 ]
      } ],
      "urls" : [ {
        "indices" : [ 54, 76 ],
        "url" : "http:\/\/t.co\/q5RQ23k2Wb",
        "expanded_url" : "http:\/\/goo.gl\/C4qpzR",
        "display_url" : "goo.gl\/C4qpzR"
      } ]
    },
    "geo" : { },
    "id_str" : "429332922701578240",
    "text" : "Great new video by @StateDept on our #Sochi athletes: http:\/\/t.co\/q5RQ23k2Wb. #TeamUSA",
    "id" : 429332922701578240,
    "created_at" : "2014-01-31 19:18:40 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 429362238349402112,
  "created_at" : "2014-01-31 21:15:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/429345781632348160\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/x4j0pBESlA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfVXtqRCcAAYjd3.jpg",
      "id_str" : "429345781435232256",
      "id" : 429345781435232256,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfVXtqRCcAAYjd3.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/x4j0pBESlA"
    } ],
    "hashtags" : [ {
      "text" : "POTUSRoadTrip",
      "indices" : [ 39, 53 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/DVHHvse3IP",
      "expanded_url" : "http:\/\/go.wh.gov\/QbGESm",
      "display_url" : "go.wh.gov\/QbGESm"
    } ]
  },
  "geo" : { },
  "id_str" : "429345781632348160",
  "text" : "Missed your chance to join the virtual #POTUSRoadTrip with President Obama? Watch it here: http:\/\/t.co\/DVHHvse3IP, http:\/\/t.co\/x4j0pBESlA",
  "id" : 429345781632348160,
  "created_at" : "2014-01-31 20:09:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "POTUSRoadTrip",
      "indices" : [ 93, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "429341052131377153",
  "text" : "President Obama: \u201CMy wife, at least, still thinks I\u2019m pretty cute, even with the gray hair.\u201D #POTUSRoadTrip",
  "id" : 429341052131377153,
  "created_at" : "2014-01-31 19:50:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "POTUSRoadTrip",
      "indices" : [ 126, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "429340599335272448",
  "text" : "Obama on what it's like to be POTUS: \u201CEvery single day\u2026you realize it\u2019s pretty lucky to be able to serve the American people\u201D #POTUSRoadTrip",
  "id" : 429340599335272448,
  "created_at" : "2014-01-31 19:49:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "POTUSRoadTrip",
      "indices" : [ 0, 14 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "429339992541102080",
  "text" : "#POTUSRoadTrip question: \"How are you?\u201D Obama: \u201CI am pretty happy\u2026the main reason is I have this amazing wife and two...terrific daughters.\u201D",
  "id" : 429339992541102080,
  "created_at" : "2014-01-31 19:46:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "POTUSRoadTrip",
      "indices" : [ 101, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "429339407842549761",
  "text" : "President Obama: \u201COur best defense against extremists is a strong Muslim community working with us.\u201D #POTUSRoadTrip",
  "id" : 429339407842549761,
  "created_at" : "2014-01-31 19:44:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/429335318496428032\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/1A21EUfLSe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfVOMnoCAAAp0yP.jpg",
      "id_str" : "429335318186033152",
      "id" : 429335318186033152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfVOMnoCAAAp0yP.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/1A21EUfLSe"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 84, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "429335318496428032",
  "text" : "Obama to a man from WI making the minimum wage: \u201CWe\u2019ve got to make sure work pays.\u201D #RaiseTheWage, http:\/\/t.co\/1A21EUfLSe",
  "id" : 429335318496428032,
  "created_at" : "2014-01-31 19:28:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "POTUSRoadTrip",
      "indices" : [ 104, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "429333815270440960",
  "text" : "RT @WHLive: President Obama to a father from Arizona: \u201CI\u2019ve been a strong supporter of net neutrality.\u201D #POTUSRoadTrip",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "POTUSRoadTrip",
        "indices" : [ 92, 106 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "429333760840970240",
    "text" : "President Obama to a father from Arizona: \u201CI\u2019ve been a strong supporter of net neutrality.\u201D #POTUSRoadTrip",
    "id" : 429333760840970240,
    "created_at" : "2014-01-31 19:21:59 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 429333815270440960,
  "created_at" : "2014-01-31 19:22:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/429331881700495360\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/rijDcqr6RL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfVLElNCYAA3UkZ.jpg",
      "id_str" : "429331881562103808",
      "id" : 429331881562103808,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfVLElNCYAA3UkZ.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/rijDcqr6RL"
    } ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 55, 73 ]
    }, {
      "text" : "POTUSRoadTrip",
      "indices" : [ 91, 105 ]
    }, {
      "text" : "ActOnCIR",
      "indices" : [ 106, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "429331881700495360",
  "text" : "President Obama: \u201CIt is my firm belief that we can get #ImmigrationReform done this year.\u201D #POTUSRoadTrip #ActOnCIR http:\/\/t.co\/rijDcqr6RL",
  "id" : 429331881700495360,
  "created_at" : "2014-01-31 19:14:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 38, 56 ]
    }, {
      "text" : "POTUSRoadTrip",
      "indices" : [ 117, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "429331363247181824",
  "text" : "Obama answering a question from CA on #ImmigrationReform: \u201CI\u2019m modestly optimistic about Congress acting this year.\u201D #POTUSRoadTrip",
  "id" : 429331363247181824,
  "created_at" : "2014-01-31 19:12:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "POTUSRoadTrip",
      "indices" : [ 48, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/qLnzylW7Ee",
      "expanded_url" : "http:\/\/go.wh.gov\/TM8Uh6",
      "display_url" : "go.wh.gov\/TM8Uh6"
    } ]
  },
  "geo" : { },
  "id_str" : "429330642623807488",
  "text" : "Starting now: Join President Obama on a virtual #POTUSRoadTrip as he answers questions from around the country \u2192 http:\/\/t.co\/qLnzylW7Ee",
  "id" : 429330642623807488,
  "created_at" : "2014-01-31 19:09:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "POTUSRoadTrip",
      "indices" : [ 123, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/0a4eCEIsnm",
      "expanded_url" : "http:\/\/go.wh.gov\/zNuVgM",
      "display_url" : "go.wh.gov\/zNuVgM"
    } ]
  },
  "geo" : { },
  "id_str" : "429323514563543040",
  "text" : "Virtual road trip! Join President Obama at 2pm ET as he answers questions from around the country \u2192 http:\/\/t.co\/0a4eCEIsnm #POTUSRoadTrip",
  "id" : 429323514563543040,
  "created_at" : "2014-01-31 18:41:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/429308911720484865\/photo\/1",
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/682wFCeNVt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfU2LjeCEAArv5m.jpg",
      "id_str" : "429308911611416576",
      "id" : 429308911611416576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfU2LjeCEAArv5m.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 354,
        "resize" : "fit",
        "w" : 630
      }, {
        "h" : 354,
        "resize" : "fit",
        "w" : 630
      } ],
      "display_url" : "pic.twitter.com\/682wFCeNVt"
    } ],
    "hashtags" : [ {
      "text" : "POTUSRoadTrip",
      "indices" : [ 80, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/rJVAKqLulO",
      "expanded_url" : "http:\/\/go.wh.gov\/oJPut4",
      "display_url" : "go.wh.gov\/oJPut4"
    } ]
  },
  "geo" : { },
  "id_str" : "429308911720484865",
  "text" : "Join President Obama for a virtual road trip at 2pm ET \u2192 http:\/\/t.co\/rJVAKqLulO #POTUSRoadTrip, http:\/\/t.co\/682wFCeNVt",
  "id" : 429308911720484865,
  "created_at" : "2014-01-31 17:43:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "429304507248676865",
  "text" : "RT @PressSec: Treasury Secretary Jack Lew up with a new op-ed on \u201CMyRA\u201D - a simple, safe and affordable starter savings account http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/n3wXlH8UIi",
        "expanded_url" : "http:\/\/bit.ly\/1ddDdUp",
        "display_url" : "bit.ly\/1ddDdUp"
      } ]
    },
    "geo" : { },
    "id_str" : "429281386529181696",
    "text" : "Treasury Secretary Jack Lew up with a new op-ed on \u201CMyRA\u201D - a simple, safe and affordable starter savings account http:\/\/t.co\/n3wXlH8UIi",
    "id" : 429281386529181696,
    "created_at" : "2014-01-31 15:53:52 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 429304507248676865,
  "created_at" : "2014-01-31 17:25:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 73, 91 ]
    }, {
      "text" : "ActOnUI",
      "indices" : [ 92, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "429297528686014464",
  "text" : "RT @WHLive: President Obama: \"Every job applicant deserves a fair shot.\" #OpportunityForAll #ActOnUI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OpportunityForAll",
        "indices" : [ 61, 79 ]
      }, {
        "text" : "ActOnUI",
        "indices" : [ 80, 88 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "429296566223269888",
    "text" : "President Obama: \"Every job applicant deserves a fair shot.\" #OpportunityForAll #ActOnUI",
    "id" : 429296566223269888,
    "created_at" : "2014-01-31 16:54:12 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 429297528686014464,
  "created_at" : "2014-01-31 16:58:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "429296532253605888",
  "text" : "RT @WHLive: Obama: \"I am directing every federal agency to make sure they\u2019re evaluating candidates...without regard to their unemployment h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "429296273263714304",
    "text" : "Obama: \"I am directing every federal agency to make sure they\u2019re evaluating candidates...without regard to their unemployment history.\"",
    "id" : 429296273263714304,
    "created_at" : "2014-01-31 16:53:02 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 429296532253605888,
  "created_at" : "2014-01-31 16:54:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "429295537431773184",
  "text" : "RT @WHLive: Obama: \"While Congress decides whether or not it\u2019s going to extend unemployment insurance for these Americans, we\u2019re going to..\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "429295409585221632",
    "text" : "Obama: \"While Congress decides whether or not it\u2019s going to extend unemployment insurance for these Americans, we\u2019re going to...act.\"",
    "id" : 429295409585221632,
    "created_at" : "2014-01-31 16:49:36 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 429295537431773184,
  "created_at" : "2014-01-31 16:50:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 96, 114 ]
    }, {
      "text" : "ActOnUI",
      "indices" : [ 115, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "429295189518475264",
  "text" : "Obama: \"Giving up on the unemployed will create a drag on our economy that we cannot tolerate.\" #OpportunityForAll #ActOnUI",
  "id" : 429295189518475264,
  "created_at" : "2014-01-31 16:48:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 102, 120 ]
    }, {
      "text" : "ActOnUI",
      "indices" : [ 121, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "429294692942217216",
  "text" : "President Obama: \"Just because you're out of work for a while doesn\u2019t mean you're not a hard worker.\" #OpportunityForAll #ActOnUI",
  "id" : 429294692942217216,
  "created_at" : "2014-01-31 16:46:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnUI",
      "indices" : [ 38, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "429294395842891777",
  "text" : "RT @WHLive: Obama on why it's time to #ActOnUI: \"So that losing your livelihood doesn\u2019t...mean losing everything you\u2019ve worked so hard to b\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnUI",
        "indices" : [ 26, 34 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "429294303132008448",
    "text" : "Obama on why it's time to #ActOnUI: \"So that losing your livelihood doesn\u2019t...mean losing everything you\u2019ve worked so hard to build.\"",
    "id" : 429294303132008448,
    "created_at" : "2014-01-31 16:45:12 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 429294395842891777,
  "created_at" : "2014-01-31 16:45:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "429293965142417408",
  "text" : "RT @WHLive: Obama: \"Each week that Congress fails to restore that insurance...72,000 Americans will join the ranks of the long-term unemplo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnUI",
        "indices" : [ 132, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "429293894791344129",
    "text" : "Obama: \"Each week that Congress fails to restore that insurance...72,000 Americans will join the ranks of the long-term unemployed\" #ActOnUI",
    "id" : 429293894791344129,
    "created_at" : "2014-01-31 16:43:35 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 429293965142417408,
  "created_at" : "2014-01-31 16:43:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/429293745662459904\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/Qqi6lDgl7y",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfUoYxUCUAA78rB.jpg",
      "id_str" : "429293745503096832",
      "id" : 429293745503096832,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfUoYxUCUAA78rB.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/Qqi6lDgl7y"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "429293745662459904",
  "text" : "Obama: \"We\u2019ve got to guarantee every child access to a world-class education, from early childhood to college.\" http:\/\/t.co\/Qqi6lDgl7y",
  "id" : 429293745662459904,
  "created_at" : "2014-01-31 16:42:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 111, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "429293301121175552",
  "text" : "President Obama: \"We\u2019ve got a lot more to do to build an economy where everyone who works hard can get ahead.\" #OpportunityForAll",
  "id" : 429293301121175552,
  "created_at" : "2014-01-31 16:41:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 113, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/5a0iP0DnRV",
      "expanded_url" : "http:\/\/go.wh.gov\/YrRqV3",
      "display_url" : "go.wh.gov\/YrRqV3"
    } ]
  },
  "geo" : { },
  "id_str" : "429293153653637120",
  "text" : "Right now: President Obama outlines new efforts to help the long-term unemployed. Watch \u2192 http:\/\/t.co\/5a0iP0DnRV #OpportunityForAll",
  "id" : 429293153653637120,
  "created_at" : "2014-01-31 16:40:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 117, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/5a0iP0DnRV",
      "expanded_url" : "http:\/\/go.wh.gov\/YrRqV3",
      "display_url" : "go.wh.gov\/YrRqV3"
    } ]
  },
  "geo" : { },
  "id_str" : "429276388827607041",
  "text" : "At 11:30am ET, President Obama outlines new efforts to help the long-term unemployed. Watch \u2192 http:\/\/t.co\/5a0iP0DnRV #OpportunityForAll",
  "id" : 429276388827607041,
  "created_at" : "2014-01-31 15:34:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/429060378761633792\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/Y8PR8BYTg5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfRUJB1IIAAB8_J.jpg",
      "id_str" : "429060378593861632",
      "id" : 429060378593861632,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfRUJB1IIAAB8_J.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Y8PR8BYTg5"
    } ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 110, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/5Ciy1Ql55f",
      "expanded_url" : "http:\/\/go.wh.gov\/pLFjw4",
      "display_url" : "go.wh.gov\/pLFjw4"
    } ]
  },
  "geo" : { },
  "id_str" : "429060378761633792",
  "text" : "\"Like the America he serves, Sergeant 1st Class Cory Remsburg never gives up.\" \u2014Obama: http:\/\/t.co\/5Ciy1Ql55f #SOTU, http:\/\/t.co\/Y8PR8BYTg5",
  "id" : 429060378761633792,
  "created_at" : "2014-01-31 01:15:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 119, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/fsVsXeCb54",
      "expanded_url" : "http:\/\/go.wh.gov\/v4akni",
      "display_url" : "go.wh.gov\/v4akni"
    } ]
  },
  "geo" : { },
  "id_str" : "429048524094054400",
  "text" : "\"We know it'll help families...if you work hard you shouldn't be in poverty.\" \u2014President Obama: http:\/\/t.co\/fsVsXeCb54 #RaiseTheWage",
  "id" : 429048524094054400,
  "created_at" : "2014-01-31 00:28:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "429030139326783488",
  "text" : "Obama: \"If we...make sure every young person can go as far as their...hard work will take them, then we will keep the American Dream alive.\"",
  "id" : 429030139326783488,
  "created_at" : "2014-01-30 23:15:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 118, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "429028734562082816",
  "text" : "Obama: \"A quality education shouldn\u2019t be something that other kids get\u2014it should be something that all our kids get.\" #CollegeOpportunity",
  "id" : 429028734562082816,
  "created_at" : "2014-01-30 23:09:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/429026389677719553\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/o3GRmYwAMC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfQ1OmRCYAEFodF.jpg",
      "id_str" : "429026389413486593",
      "id" : 429026389413486593,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfQ1OmRCYAEFodF.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/o3GRmYwAMC"
    } ],
    "hashtags" : [ {
      "text" : "ActOnPreK",
      "indices" : [ 100, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "429026389677719553",
  "text" : "Obama: \"High-quality early education is one of the best investments we can make in a child\u2019s life.\" #ActOnPreK, http:\/\/t.co\/o3GRmYwAMC",
  "id" : 429026389677719553,
  "created_at" : "2014-01-30 23:00:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 101, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "429025976152891392",
  "text" : "RT @WHLive: President Obama: \"Our high school graduation rate is the highest it\u2019s been in 30 years.\" #CollegeOpportunity",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CollegeOpportunity",
        "indices" : [ 89, 108 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "429025928258146304",
    "text" : "President Obama: \"Our high school graduation rate is the highest it\u2019s been in 30 years.\" #CollegeOpportunity",
    "id" : 429025928258146304,
    "created_at" : "2014-01-30 22:58:46 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 429025976152891392,
  "created_at" : "2014-01-30 22:58:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnJobs",
      "indices" : [ 41, 51 ]
    }, {
      "text" : "CollegeOpportunity",
      "indices" : [ 94, 113 ]
    }, {
      "text" : "OpportunityForAll",
      "indices" : [ 114, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "429025844535623680",
  "text" : "President Obama's opportunity agenda:\n1. #ActOnJobs\n2. Skills training\n3. Reward hard work\n4. #CollegeOpportunity\n#OpportunityForAll",
  "id" : 429025844535623680,
  "created_at" : "2014-01-30 22:58:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "429025542809997312",
  "text" : "Obama: \"I was able to go to college even though we didn\u2019t have a lot of money...I want every young person in America to have that...chance.\"",
  "id" : 429025542809997312,
  "created_at" : "2014-01-30 22:57:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 105, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "429024961655603201",
  "text" : "President Obama in TN: \"We want every child to have every chance in life...and every chance at success.\" #CollegeOpportunity",
  "id" : 429024961655603201,
  "created_at" : "2014-01-30 22:54:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 118, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/RHrt8Y7OBX",
      "expanded_url" : "http:\/\/go.wh.gov\/4UsgYd",
      "display_url" : "go.wh.gov\/4UsgYd"
    } ]
  },
  "geo" : { },
  "id_str" : "429018329408229378",
  "text" : "Starting soon: President Obama speaks on helping more students afford and succeed in college \u2192 http:\/\/t.co\/RHrt8Y7OBX #CollegeOpportunity",
  "id" : 429018329408229378,
  "created_at" : "2014-01-30 22:28:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/428993683703476225\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/tSX73eybst",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfQXe3RIAAAIPH5.jpg",
      "id_str" : "428993683506331648",
      "id" : 428993683506331648,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfQXe3RIAAAIPH5.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/tSX73eybst"
    } ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 97, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/MLAacv5Q2U",
      "expanded_url" : "http:\/\/go.wh.gov\/V3eas9",
      "display_url" : "go.wh.gov\/V3eas9"
    } ]
  },
  "geo" : { },
  "id_str" : "428993683703476225",
  "text" : "Obama: \"Manufacturing is adding jobs for the first time since the 1990s.\" http:\/\/t.co\/MLAacv5Q2U #MadeInAmerica, http:\/\/t.co\/tSX73eybst",
  "id" : 428993683703476225,
  "created_at" : "2014-01-30 20:50:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/428983381183836160\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/IgmzRPOrc4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfQOHLkCYAALUJk.jpg",
      "id_str" : "428983381032853504",
      "id" : 428983381032853504,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfQOHLkCYAALUJk.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/IgmzRPOrc4"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 97, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428983381183836160",
  "text" : "RT if you agree with President Obama: \"Tell Congress to make this happen. Give America a raise.\" #RaiseTheWage, http:\/\/t.co\/IgmzRPOrc4",
  "id" : 428983381183836160,
  "created_at" : "2014-01-30 20:09:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Google",
      "screen_name" : "google",
      "indices" : [ 81, 88 ],
      "id_str" : "20536157",
      "id" : 20536157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/ggY55cpdxu",
      "expanded_url" : "http:\/\/go.wh.gov\/pt2kRt",
      "display_url" : "go.wh.gov\/pt2kRt"
    } ]
  },
  "geo" : { },
  "id_str" : "428973602785206272",
  "text" : "President Obama is headed on a virtual road trip! Join him tomorrow at 2pm ET on @Google+: http:\/\/t.co\/ggY55cpdxu",
  "id" : 428973602785206272,
  "created_at" : "2014-01-30 19:30:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Ryan Seacrest",
      "screen_name" : "RyanSeacrest",
      "indices" : [ 112, 125 ],
      "id_str" : "16190898",
      "id" : 16190898
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428966781529894912",
  "text" : "RT @FLOTUS: \"Life throws you some curveballs and young people in particular need to have insurance.\u201D \u2014FLOTUS to @RyanSeacrest: http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ryan Seacrest",
        "screen_name" : "RyanSeacrest",
        "indices" : [ 100, 113 ],
        "id_str" : "16190898",
        "id" : 16190898
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/XN3TZ8hs7Y",
        "expanded_url" : "http:\/\/shar.es\/UL8jf",
        "display_url" : "shar.es\/UL8jf"
      } ]
    },
    "geo" : { },
    "id_str" : "428965851812073472",
    "text" : "\"Life throws you some curveballs and young people in particular need to have insurance.\u201D \u2014FLOTUS to @RyanSeacrest: http:\/\/t.co\/XN3TZ8hs7Y",
    "id" : 428965851812073472,
    "created_at" : "2014-01-30 19:00:03 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 428966781529894912,
  "created_at" : "2014-01-30 19:03:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/428948592502403072\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/mA1hdAlUeQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfPueNtCEAAfTXP.jpg",
      "id_str" : "428948592372355072",
      "id" : 428948592372355072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfPueNtCEAAfTXP.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/mA1hdAlUeQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428948592502403072",
  "text" : "Obama: \"There\u2019s a bill in Congress to raise the...minimum wage to $10.10. They should say yes...give America a raise\" http:\/\/t.co\/mA1hdAlUeQ",
  "id" : 428948592502403072,
  "created_at" : "2014-01-30 17:51:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/428948191682125824\/photo\/1",
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/ytjgtHXKL3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfPuG4gCYAAOqbR.jpg",
      "id_str" : "428948191543713792",
      "id" : 428948191543713792,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfPuG4gCYAAOqbR.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      } ],
      "display_url" : "pic.twitter.com\/ytjgtHXKL3"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 83, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428948191682125824",
  "text" : "Obama: \"Today, the federal minimum wage doesn\u2019t even go as far as it did in 1950.\" #RaiseTheWage, http:\/\/t.co\/ytjgtHXKL3",
  "id" : 428948191682125824,
  "created_at" : "2014-01-30 17:49:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 125, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428947742011170816",
  "text" : "President Obama: \"Americans overwhelmingly agree, no one who works full time should ever have to raise a family in poverty.\" #RaiseTheWage",
  "id" : 428947742011170816,
  "created_at" : "2014-01-30 17:48:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/428947451710414848\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/1dDI8KKlEz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfPtbzyCAAExgnF.jpg",
      "id_str" : "428947451542634497",
      "id" : 428947451542634497,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfPtbzyCAAExgnF.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      } ],
      "display_url" : "pic.twitter.com\/1dDI8KKlEz"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428947451710414848",
  "text" : "Obama: \"Women make up about half our workforce. But they make $0.77 for every $1 a man makes. That\u2019s wrong.\" http:\/\/t.co\/1dDI8KKlEz",
  "id" : 428947451710414848,
  "created_at" : "2014-01-30 17:46:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428946951380664320",
  "text" : "Obama: \"While we redouble our efforts to train today\u2019s workforce, we have to make sure that...hard work pays off for every single American.\"",
  "id" : 428946951380664320,
  "created_at" : "2014-01-30 17:44:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 20, 23 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428946137266286593",
  "text" : "RT @WHLive: Obama: \"@VP Biden, a man who was raised on the value of hard work, will lead an across-the-board review of America\u2019s training p\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 8, 11 ],
        "id_str" : "325830217",
        "id" : 325830217
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "428946060850233344",
    "text" : "Obama: \"@VP Biden, a man who was raised on the value of hard work, will lead an across-the-board review of America\u2019s training programs.\"",
    "id" : 428946060850233344,
    "created_at" : "2014-01-30 17:41:25 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 428946137266286593,
  "created_at" : "2014-01-30 17:41:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnJobs",
      "indices" : [ 125, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428945878662250497",
  "text" : "Obama: \"I\u2019ve asked Congress to fund\u2026proven programs that connect more ready-to-work Americans with ready-to-be-filled jobs.\" #ActOnJobs",
  "id" : 428945878662250497,
  "created_at" : "2014-01-30 17:40:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428945204503379968",
  "text" : "RT @WHLive: Obama: \"Not all of today\u2019s good jobs need a 4-year degree, but the ones that don\u2019t almost always require...specialized training\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnJobs",
        "indices" : [ 130, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "428945169099280384",
    "text" : "Obama: \"Not all of today\u2019s good jobs need a 4-year degree, but the ones that don\u2019t almost always require...specialized training.\" #ActOnJobs",
    "id" : 428945169099280384,
    "created_at" : "2014-01-30 17:37:52 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 428945204503379968,
  "created_at" : "2014-01-30 17:38:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 101, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428944876341039104",
  "text" : "RT @WHLive: President Obama: \"We've got to train more Americans with the skills to fill those jobs.\" #OpportunityForAll",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OpportunityForAll",
        "indices" : [ 89, 107 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "428944817675325440",
    "text" : "President Obama: \"We've got to train more Americans with the skills to fill those jobs.\" #OpportunityForAll",
    "id" : 428944817675325440,
    "created_at" : "2014-01-30 17:36:28 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 428944876341039104,
  "created_at" : "2014-01-30 17:36:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 114, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428944314962829312",
  "text" : "Obama: \"The defining project of our generation...is to make sure we're restoring opportunity for more Americans.\" #OpportunityForAll",
  "id" : 428944314962829312,
  "created_at" : "2014-01-30 17:34:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/428943637955624960\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/RE4cxkClvR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfPp90WCYAAMGs9.jpg",
      "id_str" : "428943637762695168",
      "id" : 428943637762695168,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfPp90WCYAAMGs9.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/RE4cxkClvR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428943637955624960",
  "text" : "Obama: \"We\u2019re at a moment where businesses like GE have created 8 million new jobs over the past 4 years.\" http:\/\/t.co\/RE4cxkClvR",
  "id" : 428943637955624960,
  "created_at" : "2014-01-30 17:31:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428942971304964096",
  "text" : "President Obama: \"It's good to be in Wisconsin...I\u2019ve always appreciated the hospitality that Packer Country gives this Bears fan.\"",
  "id" : 428942971304964096,
  "created_at" : "2014-01-30 17:29:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 120, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/tkqOcqV9c7",
      "expanded_url" : "http:\/\/go.wh.gov\/fmmySs",
      "display_url" : "go.wh.gov\/fmmySs"
    } ]
  },
  "geo" : { },
  "id_str" : "428941448814526464",
  "text" : "Starting soon: Don't miss President Obama speak on expanding skills training for in-demand jobs: http:\/\/t.co\/tkqOcqV9c7 #OpportunityForAll",
  "id" : 428941448814526464,
  "created_at" : "2014-01-30 17:23:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/4B3eiitBXt",
      "expanded_url" : "http:\/\/instagram.com\/p\/jzNWgvQiui\/",
      "display_url" : "instagram.com\/p\/jzNWgvQiui\/"
    } ]
  },
  "geo" : { },
  "id_str" : "428935135195832320",
  "text" : "\u2708 \"POTUS on board.\" \u2708\nWatch \u2192 http:\/\/t.co\/4B3eiitBXt",
  "id" : 428935135195832320,
  "created_at" : "2014-01-30 16:58:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/sXHgSIjIw7",
      "expanded_url" : "http:\/\/go.wh.gov\/GzkWVN",
      "display_url" : "go.wh.gov\/GzkWVN"
    } ]
  },
  "geo" : { },
  "id_str" : "428933335633522691",
  "text" : "FACT: Without the government shutdown, GDP growth would have been at least 0.3% higher last quarter: http:\/\/t.co\/sXHgSIjIw7",
  "id" : 428933335633522691,
  "created_at" : "2014-01-30 16:50:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/fMNsQM3Wnm",
      "expanded_url" : "http:\/\/go.wh.gov\/PDLyTT",
      "display_url" : "go.wh.gov\/PDLyTT"
    } ]
  },
  "geo" : { },
  "id_str" : "428925785240395776",
  "text" : "FACT: Last quarter, consumer spending grew at an annual rate of 3.3%\u2014the strongest growth in 3 years: http:\/\/t.co\/fMNsQM3Wnm",
  "id" : 428925785240395776,
  "created_at" : "2014-01-30 16:20:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/428915967578492929\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/JfgXkEAyY9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfPQzMkCQAAo0cj.jpg",
      "id_str" : "428915967494602752",
      "id" : 428915967494602752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfPQzMkCQAAo0cj.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/JfgXkEAyY9"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/ifvw7E4CeO",
      "expanded_url" : "http:\/\/go.wh.gov\/Esi3oe",
      "display_url" : "go.wh.gov\/Esi3oe"
    } ]
  },
  "geo" : { },
  "id_str" : "428915967578492929",
  "text" : "Wheels up for Wisconsin. President Obama speaks at 12:20pm ET on expanding job training: http:\/\/t.co\/ifvw7E4CeO, http:\/\/t.co\/JfgXkEAyY9",
  "id" : 428915967578492929,
  "created_at" : "2014-01-30 15:41:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Furman",
      "screen_name" : "CEAChair",
      "indices" : [ 3, 12 ],
      "id_str" : "1861751828",
      "id" : 1861751828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/jU4tk7dO0f",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2014\/01\/30\/advance-estimate-gdp-fourth-quarter-2013",
      "display_url" : "whitehouse.gov\/blog\/2014\/01\/3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "428908889602801664",
  "text" : "RT @CEAChair: Real GDP rose at a solid 3.2% annual rate in Q4; 11th consecutive quarter of growth http:\/\/t.co\/jU4tk7dO0f http:\/\/t.co\/15KUl6\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CEAChair\/status\/428905988293279744\/photo\/1",
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/15KUl6U1BB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BfPHuVLCQAErHr8.jpg",
        "id_str" : "428905988301668353",
        "id" : 428905988301668353,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfPHuVLCQAErHr8.jpg",
        "sizes" : [ {
          "h" : 660,
          "resize" : "fit",
          "w" : 910
        }, {
          "h" : 660,
          "resize" : "fit",
          "w" : 910
        }, {
          "h" : 435,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 247,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/15KUl6U1BB"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/jU4tk7dO0f",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2014\/01\/30\/advance-estimate-gdp-fourth-quarter-2013",
        "display_url" : "whitehouse.gov\/blog\/2014\/01\/3\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "428905988293279744",
    "text" : "Real GDP rose at a solid 3.2% annual rate in Q4; 11th consecutive quarter of growth http:\/\/t.co\/jU4tk7dO0f http:\/\/t.co\/15KUl6U1BB",
    "id" : 428905988293279744,
    "created_at" : "2014-01-30 15:02:11 +0000",
    "user" : {
      "name" : "Jason Furman",
      "screen_name" : "CEAChair",
      "protected" : false,
      "id_str" : "1861751828",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000628384447\/c9cb85dbdb73c8bac4f28ce4cc46f38b_normal.jpeg",
      "id" : 1861751828,
      "verified" : true
    }
  },
  "id" : 428908889602801664,
  "created_at" : "2014-01-30 15:13:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 126, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/8T7w3GExcI",
      "expanded_url" : "http:\/\/go.wh.gov\/8yZWc8",
      "display_url" : "go.wh.gov\/8yZWc8"
    } ]
  },
  "geo" : { },
  "id_str" : "428696772651675648",
  "text" : "\"The only way to get Congress to move is if the American people\u2026tell them this is a priority.\" \u2014Obama: http:\/\/t.co\/8T7w3GExcI #RaiseTheWage",
  "id" : 428696772651675648,
  "created_at" : "2014-01-30 01:10:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BigBlockOfCheeseDay",
      "indices" : [ 27, 47 ]
    }, {
      "text" : "RaiseTheWage",
      "indices" : [ 73, 86 ]
    }, {
      "text" : "AskTheWH",
      "indices" : [ 87, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/dpxMIjdAgA",
      "expanded_url" : "http:\/\/go.wh.gov\/Voxs7g",
      "display_url" : "go.wh.gov\/Voxs7g"
    } ]
  },
  "geo" : { },
  "id_str" : "428679126409814016",
  "text" : "President Obama gets in on #BigBlockOfCheeseDay \u2192 http:\/\/t.co\/dpxMIjdAgA #RaiseTheWage #AskTheWH",
  "id" : 428679126409814016,
  "created_at" : "2014-01-30 00:00:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Spring",
      "screen_name" : "rspring72",
      "indices" : [ 5, 15 ],
      "id_str" : "1935052189",
      "id" : 1935052189
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BigBlockOfCheeseDay",
      "indices" : [ 59, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/8T7w3GExcI",
      "expanded_url" : "http:\/\/go.wh.gov\/8yZWc8",
      "display_url" : "go.wh.gov\/8yZWc8"
    } ]
  },
  "in_reply_to_status_id_str" : "428550006010699778",
  "geo" : { },
  "id_str" : "428677261386997760",
  "in_reply_to_user_id" : 1935052189,
  "text" : "Hey, @rspring72. Someone you might recognize answered your #BigBlockOfCheeseDay question... http:\/\/t.co\/8T7w3GExcI",
  "id" : 428677261386997760,
  "in_reply_to_status_id" : 428550006010699778,
  "created_at" : "2014-01-29 23:53:18 +0000",
  "in_reply_to_screen_name" : "rspring72",
  "in_reply_to_user_id_str" : "1935052189",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Kacey O'Connor",
      "screen_name" : "kaceyoconnor",
      "indices" : [ 13, 26 ],
      "id_str" : "255748597",
      "id" : 255748597
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428669140757671936",
  "text" : "RT @FLOTUS: .@kaceyoconnor I am so inspired by SFC Remsburg! Sitting next to him was a reminder that, as Barack said, \u201CAmerica has never co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kacey O'Connor",
        "screen_name" : "kaceyoconnor",
        "indices" : [ 1, 14 ],
        "id_str" : "255748597",
        "id" : 255748597
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "428663290047115264",
    "text" : ".@kaceyoconnor I am so inspired by SFC Remsburg! Sitting next to him was a reminder that, as Barack said, \u201CAmerica has never come easy\u201D \u2013mo",
    "id" : 428663290047115264,
    "created_at" : "2014-01-29 22:57:47 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 428669140757671936,
  "created_at" : "2014-01-29 23:21:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Veterans Affairs",
      "screen_name" : "DeptVetAffairs",
      "indices" : [ 3, 18 ],
      "id_str" : "78408666",
      "id" : 78408666
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 23, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428658317171634177",
  "text" : "RT @DeptVetAffairs: At #SOTU: \"SFC Remsburg never gives up, and he does not quit.\" He says VA gives \"untouchable support and care.\" http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SOTU",
        "indices" : [ 3, 8 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/CvCSrXwUzB",
        "expanded_url" : "http:\/\/1.usa.gov\/1ib53pD",
        "display_url" : "1.usa.gov\/1ib53pD"
      } ]
    },
    "geo" : { },
    "id_str" : "428591637137072129",
    "text" : "At #SOTU: \"SFC Remsburg never gives up, and he does not quit.\" He says VA gives \"untouchable support and care.\" http:\/\/t.co\/CvCSrXwUzB",
    "id" : 428591637137072129,
    "created_at" : "2014-01-29 18:13:03 +0000",
    "user" : {
      "name" : "Veterans Affairs",
      "screen_name" : "DeptVetAffairs",
      "protected" : false,
      "id_str" : "78408666",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/344513261565984455\/a9fcce7feb947b2ec498491c6c6d6985_normal.png",
      "id" : 78408666,
      "verified" : true
    }
  },
  "id" : 428658317171634177,
  "created_at" : "2014-01-29 22:38:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/428643925583073281\/photo\/1",
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/tk7sara6TH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfLZYQ6CUAA8Sd-.jpg",
      "id_str" : "428643925432094720",
      "id" : 428643925432094720,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfLZYQ6CUAA8Sd-.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/tk7sara6TH"
    } ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 0, 14 ]
    } ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/sxVFfet61C",
      "expanded_url" : "http:\/\/go.wh.gov\/gcJsaH",
      "display_url" : "go.wh.gov\/gcJsaH"
    } ]
  },
  "geo" : { },
  "id_str" : "428643925583073281",
  "text" : "#MadeInAmerica: http:\/\/t.co\/sxVFfet61C, http:\/\/t.co\/tk7sara6TH",
  "id" : 428643925583073281,
  "created_at" : "2014-01-29 21:40:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bobby Harrison ",
      "screen_name" : "bobby44",
      "indices" : [ 3, 11 ],
      "id_str" : "2806537362",
      "id" : 2806537362
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 114, 117 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Bobby44\/status\/428624342214512640\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/ANRkFUHx22",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfLHkXFIQAAnlDo.jpg",
      "id_str" : "428624342038364160",
      "id" : 428624342038364160,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfLHkXFIQAAnlDo.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/ANRkFUHx22"
    } ],
    "hashtags" : [ {
      "text" : "BigBlockOfCheeseDay",
      "indices" : [ 71, 91 ]
    }, {
      "text" : "Literally",
      "indices" : [ 93, 103 ]
    }, {
      "text" : "SOTU",
      "indices" : [ 104, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428637138461405184",
  "text" : "RT @Bobby44: Special delivery to lower press. a big block of cheese on #BigBlockOfCheeseDay. #Literally #SOTU cc: @VP http:\/\/t.co\/ANRkFUHx22",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 101, 104 ],
        "id_str" : "325830217",
        "id" : 325830217
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Bobby44\/status\/428624342214512640\/photo\/1",
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/ANRkFUHx22",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BfLHkXFIQAAnlDo.jpg",
        "id_str" : "428624342038364160",
        "id" : 428624342038364160,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfLHkXFIQAAnlDo.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/ANRkFUHx22"
      } ],
      "hashtags" : [ {
        "text" : "BigBlockOfCheeseDay",
        "indices" : [ 58, 78 ]
      }, {
        "text" : "Literally",
        "indices" : [ 80, 90 ]
      }, {
        "text" : "SOTU",
        "indices" : [ 91, 96 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "428624342214512640",
    "text" : "Special delivery to lower press. a big block of cheese on #BigBlockOfCheeseDay. #Literally #SOTU cc: @VP http:\/\/t.co\/ANRkFUHx22",
    "id" : 428624342214512640,
    "created_at" : "2014-01-29 20:23:01 +0000",
    "user" : {
      "name" : "Brandi Hoffine",
      "screen_name" : "Hoffine44",
      "protected" : false,
      "id_str" : "1665298740",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/502212746134302720\/RqyFWrpZ_normal.jpeg",
      "id" : 1665298740,
      "verified" : true
    }
  },
  "id" : 428637138461405184,
  "created_at" : "2014-01-29 21:13:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyRA",
      "indices" : [ 105, 110 ]
    }, {
      "text" : "OpportunityForAll",
      "indices" : [ 111, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428609472500891648",
  "text" : "President Obama: \"I want more people to have the chance to save for retirement through their hard work.\" #MyRA #OpportunityForAll",
  "id" : 428609472500891648,
  "created_at" : "2014-01-29 19:23:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyRA",
      "indices" : [ 89, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428608271159922688",
  "text" : "President Obama: \"After a lifetime of hard work, Americans deserve a secure retirement.\" #MyRA",
  "id" : 428608271159922688,
  "created_at" : "2014-01-29 19:19:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 116, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428607198760280064",
  "text" : "\"We\u2019ve got to get rid of workplace policies that belong back in...a 'Mad Men' episode.\" \u2014Obama on why women deserve #EqualPay for equal work",
  "id" : 428607198760280064,
  "created_at" : "2014-01-29 19:14:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/428606778800996352\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/Aceo08JDvc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfK3mCVCAAEPbSb.jpg",
      "id_str" : "428606778641612801",
      "id" : 428606778641612801,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfK3mCVCAAEPbSb.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      } ],
      "display_url" : "pic.twitter.com\/Aceo08JDvc"
    } ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 89, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428606778800996352",
  "text" : "President Obama: \"We've got to guarantee every child access to a world-class education.\" #CollegeOpportunity, http:\/\/t.co\/Aceo08JDvc",
  "id" : 428606778800996352,
  "created_at" : "2014-01-29 19:13:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428606167267700737",
  "text" : "RT @WHLive: Obama: \"Business leaders are increasingly deciding that China\u2019s no longer the best place to invest &amp; create jobs\u2014America is.\" #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MadeInAmerica",
        "indices" : [ 130, 144 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "428606065090260992",
    "text" : "Obama: \"Business leaders are increasingly deciding that China\u2019s no longer the best place to invest &amp; create jobs\u2014America is.\" #MadeInAmerica",
    "id" : 428606065090260992,
    "created_at" : "2014-01-29 19:10:23 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 428606167267700737,
  "created_at" : "2014-01-29 19:10:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 114, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428605470946123776",
  "text" : "President Obama at U.S. Steel: \"This company helped build America, and over 100 years later, you\u2019re still at it.\" #MadeInAmerica",
  "id" : 428605470946123776,
  "created_at" : "2014-01-29 19:08:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SteelCity",
      "indices" : [ 45, 55 ]
    }, {
      "text" : "MadeInAmerica",
      "indices" : [ 87, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428604988789886976",
  "text" : "President Obama: \"You just don\u2019t come to the #SteelCity without coming to U.S. Steel.\" #MadeInAmerica",
  "id" : 428604988789886976,
  "created_at" : "2014-01-29 19:06:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyRA",
      "indices" : [ 131, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/Njmu9HXEbS",
      "expanded_url" : "http:\/\/go.wh.gov\/W9a3Rn",
      "display_url" : "go.wh.gov\/W9a3Rn"
    } ]
  },
  "geo" : { },
  "id_str" : "428604663689388032",
  "text" : "Starting now: President Obama speaks about his plan to help more Americans gain retirement security. Watch: http:\/\/t.co\/Njmu9HXEbS #MyRA",
  "id" : 428604663689388032,
  "created_at" : "2014-01-29 19:04:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Education",
      "screen_name" : "usedgov",
      "indices" : [ 3, 11 ],
      "id_str" : "20437286",
      "id" : 20437286
    }, {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 23, 34 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/usedgov\/status\/428598064203722752\/photo\/1",
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/1NhYAOJmDH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfKvqx9IMAAgrLh.jpg",
      "id_str" : "428598064052711424",
      "id" : 428598064052711424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfKvqx9IMAAgrLh.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/1NhYAOJmDH"
    } ],
    "hashtags" : [ {
      "text" : "BigBlockOfCheeseDay",
      "indices" : [ 70, 90 ]
    }, {
      "text" : "AsktheWH",
      "indices" : [ 92, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428601316299268097",
  "text" : "RT @usedgov: Secretary @arneduncan is answering your questions during #BigBlockOfCheeseDay. #AsktheWH http:\/\/t.co\/1NhYAOJmDH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Arne Duncan",
        "screen_name" : "arneduncan",
        "indices" : [ 10, 21 ],
        "id_str" : "4662969794",
        "id" : 4662969794
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/usedgov\/status\/428598064203722752\/photo\/1",
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/1NhYAOJmDH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BfKvqx9IMAAgrLh.jpg",
        "id_str" : "428598064052711424",
        "id" : 428598064052711424,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfKvqx9IMAAgrLh.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/1NhYAOJmDH"
      } ],
      "hashtags" : [ {
        "text" : "BigBlockOfCheeseDay",
        "indices" : [ 57, 77 ]
      }, {
        "text" : "AsktheWH",
        "indices" : [ 79, 88 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "428598064203722752",
    "text" : "Secretary @arneduncan is answering your questions during #BigBlockOfCheeseDay. #AsktheWH http:\/\/t.co\/1NhYAOJmDH",
    "id" : 428598064203722752,
    "created_at" : "2014-01-29 18:38:36 +0000",
    "user" : {
      "name" : "US Dept of Education",
      "screen_name" : "usedgov",
      "protected" : false,
      "id_str" : "20437286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749204008108261377\/93-TTeZl_normal.jpg",
      "id" : 20437286,
      "verified" : true
    }
  },
  "id" : 428601316299268097,
  "created_at" : "2014-01-29 18:51:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/428589203065016320\/photo\/1",
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/BQlunpTHyu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfKnm_jCUAAy2fq.jpg",
      "id_str" : "428589202888871936",
      "id" : 428589202888871936,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfKnm_jCUAAy2fq.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/BQlunpTHyu"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 59, 72 ]
    }, {
      "text" : "ActOnTenTen",
      "indices" : [ 73, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428589203065016320",
  "text" : "No one who works full time should have to live in poverty. #RaiseTheWage #ActOnTenTen http:\/\/t.co\/BQlunpTHyu",
  "id" : 428589203065016320,
  "created_at" : "2014-01-29 18:03:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BigBlockOfCheeseDay",
      "indices" : [ 94, 114 ]
    }, {
      "text" : "AsktheWH",
      "indices" : [ 115, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/l7yYJunHXF",
      "expanded_url" : "http:\/\/youtu.be\/2JJGDieJ5Tc",
      "display_url" : "youtu.be\/2JJGDieJ5Tc"
    } ]
  },
  "geo" : { },
  "id_str" : "428579660122030080",
  "text" : "RT @PressSec: What's Big Block of Cheese Day, you ask? Let me explain: http:\/\/t.co\/l7yYJunHXF #BigBlockOfCheeseDay #AsktheWH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BigBlockOfCheeseDay",
        "indices" : [ 80, 100 ]
      }, {
        "text" : "AsktheWH",
        "indices" : [ 101, 110 ]
      } ],
      "urls" : [ {
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/l7yYJunHXF",
        "expanded_url" : "http:\/\/youtu.be\/2JJGDieJ5Tc",
        "display_url" : "youtu.be\/2JJGDieJ5Tc"
      } ]
    },
    "geo" : { },
    "id_str" : "428548810022084608",
    "text" : "What's Big Block of Cheese Day, you ask? Let me explain: http:\/\/t.co\/l7yYJunHXF #BigBlockOfCheeseDay #AsktheWH",
    "id" : 428548810022084608,
    "created_at" : "2014-01-29 15:22:53 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 428579660122030080,
  "created_at" : "2014-01-29 17:25:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/428570402634223616\/photo\/1",
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/m7bPhd3ruu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfKWgqTCYAArCn1.jpg",
      "id_str" : "428570402407735296",
      "id" : 428570402407735296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfKWgqTCYAArCn1.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      } ],
      "display_url" : "pic.twitter.com\/m7bPhd3ruu"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 52, 65 ]
    }, {
      "text" : "ActOnTenTen",
      "indices" : [ 66, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428570402634223616",
  "text" : "RT if you agree: It's time to give America a raise. #RaiseTheWage #ActOnTenTen, http:\/\/t.co\/m7bPhd3ruu",
  "id" : 428570402634223616,
  "created_at" : "2014-01-29 16:48:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Lehrich",
      "screen_name" : "Lehrich44",
      "indices" : [ 3, 13 ],
      "id_str" : "116324294",
      "id" : 116324294
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BigBlockOfCheeseDay",
      "indices" : [ 118, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428563186292621312",
  "text" : "RT @Lehrich44: Just settled in at US Steel in the Pittsburgh area. Will be answering some Qs from the road as part of #BigBlockOfCheeseDay \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BigBlockOfCheeseDay",
        "indices" : [ 103, 123 ]
      }, {
        "text" : "AsktheWH",
        "indices" : [ 130, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "428561791858118656",
    "text" : "Just settled in at US Steel in the Pittsburgh area. Will be answering some Qs from the road as part of #BigBlockOfCheeseDay using #AsktheWH",
    "id" : 428561791858118656,
    "created_at" : "2014-01-29 16:14:28 +0000",
    "user" : {
      "name" : "Patrick Rodenbush",
      "screen_name" : "Patrick44",
      "protected" : false,
      "id_str" : "1665386791",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798907223174946816\/KIC4Jq2Q_normal.jpg",
      "id" : 1665386791,
      "verified" : true
    }
  },
  "id" : 428563186292621312,
  "created_at" : "2014-01-29 16:20:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 3, 13 ],
      "id_str" : "9624742",
      "id" : 9624742
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 16, 27 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BigBlockofCheeseDay",
      "indices" : [ 36, 56 ]
    }, {
      "text" : "AsktheWH",
      "indices" : [ 94, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/NC3sD73lRz",
      "expanded_url" : "http:\/\/go.wh.gov\/ucw3zJ",
      "display_url" : "go.wh.gov\/ucw3zJ"
    } ]
  },
  "geo" : { },
  "id_str" : "428556842252656641",
  "text" : "RT @StateDept: .@WhiteHouse hosting #BigBlockofCheeseDay. Look forward to your questions. -JK #AsktheWH. More info: http:\/\/t.co\/NC3sD73lRz.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 1, 12 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BigBlockofCheeseDay",
        "indices" : [ 21, 41 ]
      }, {
        "text" : "AsktheWH",
        "indices" : [ 79, 88 ]
      } ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/NC3sD73lRz",
        "expanded_url" : "http:\/\/go.wh.gov\/ucw3zJ",
        "display_url" : "go.wh.gov\/ucw3zJ"
      } ]
    },
    "geo" : { },
    "id_str" : "428555723232911361",
    "text" : ".@WhiteHouse hosting #BigBlockofCheeseDay. Look forward to your questions. -JK #AsktheWH. More info: http:\/\/t.co\/NC3sD73lRz.",
    "id" : 428555723232911361,
    "created_at" : "2014-01-29 15:50:21 +0000",
    "user" : {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "protected" : false,
      "id_str" : "9624742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724612605185282048\/1rEfkXDZ_normal.jpg",
      "id" : 9624742,
      "verified" : true
    }
  },
  "id" : 428556842252656641,
  "created_at" : "2014-01-29 15:54:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/428551401979908097\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/d3m8TLCsnT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfKFOrtCIAAFMHZ.jpg",
      "id_str" : "428551401849888768",
      "id" : 428551401849888768,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfKFOrtCIAAFMHZ.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      } ],
      "display_url" : "pic.twitter.com\/d3m8TLCsnT"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 80, 93 ]
    }, {
      "text" : "ActOnTenTen",
      "indices" : [ 94, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428551401979908097",
  "text" : "President Obama: \"Let\u2019s tell Congress, make this happen. Give America a raise.\" #RaiseTheWage #ActOnTenTen http:\/\/t.co\/d3m8TLCsnT",
  "id" : 428551401979908097,
  "created_at" : "2014-01-29 15:33:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 80, 93 ]
    }, {
      "text" : "ActOnTenTen",
      "indices" : [ 94, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428550979873964032",
  "text" : "Obama: \"If you put in a hard day\u2019s work, you deserve to get decent pay for it.\" #RaiseTheWage #ActOnTenTen",
  "id" : 428550979873964032,
  "created_at" : "2014-01-29 15:31:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 100, 113 ]
    }, {
      "text" : "ActOnTenTen",
      "indices" : [ 114, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428550780770332672",
  "text" : "Obama: \"If you cook our troops\u2019 meals or wash their dishes, you shouldn\u2019t have to live in poverty.\" #RaiseTheWage #ActOnTenTen",
  "id" : 428550780770332672,
  "created_at" : "2014-01-29 15:30:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/428549917733183488\/photo\/1",
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/My1HemsHWi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfKD4SYCUAAtwtH.jpg",
      "id_str" : "428549917582184448",
      "id" : 428549917582184448,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfKD4SYCUAAtwtH.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      } ],
      "display_url" : "pic.twitter.com\/My1HemsHWi"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 81, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428549917733183488",
  "text" : "Obama: \"Today, the minimum wage doesn\u2019t even go as far as it did back in 1950s.\" #RaiseTheWage, http:\/\/t.co\/My1HemsHWi",
  "id" : 428549917733183488,
  "created_at" : "2014-01-29 15:27:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Costco",
      "screen_name" : "Costco",
      "indices" : [ 49, 56 ],
      "id_str" : "1056152593",
      "id" : 1056152593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428549553374384128",
  "text" : "RT @WHLive: Obama: \"Profitable corporations like @Costco see higher wages as the smart way to boost productivity and reduce turnover.\" #Rai\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Costco",
        "screen_name" : "Costco",
        "indices" : [ 37, 44 ],
        "id_str" : "1056152593",
        "id" : 1056152593
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RaiseTheWage",
        "indices" : [ 123, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "428549484290015232",
    "text" : "Obama: \"Profitable corporations like @Costco see higher wages as the smart way to boost productivity and reduce turnover.\" #RaiseTheWage",
    "id" : 428549484290015232,
    "created_at" : "2014-01-29 15:25:33 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 428549553374384128,
  "created_at" : "2014-01-29 15:25:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 93, 106 ]
    }, {
      "text" : "ActOnTenTen",
      "indices" : [ 107, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428549248125501440",
  "text" : "President Obama: \"No one who works full time should ever have to raise a family in poverty.\" #RaiseTheWage #ActOnTenTen",
  "id" : 428549248125501440,
  "created_at" : "2014-01-29 15:24:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 57, 66 ]
    }, {
      "text" : "OpportunityForAll",
      "indices" : [ 67, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428548988389052416",
  "text" : "President Obama: \"When women succeed, America succeeds.\" #EqualPay #OpportunityForAll",
  "id" : 428548988389052416,
  "created_at" : "2014-01-29 15:23:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/428548773308944384\/photo\/1",
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/TzROYlTJGk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfKC1rSCAAAQX_4.jpg",
      "id_str" : "428548773216649216",
      "id" : 428548773216649216,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfKC1rSCAAAQX_4.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      } ],
      "display_url" : "pic.twitter.com\/TzROYlTJGk"
    } ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 32, 41 ]
    }, {
      "text" : "OpportunityForAll",
      "indices" : [ 59, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428548773308944384",
  "text" : "President Obama: \"Women deserve #EqualPay for equal work.\" #OpportunityForAll http:\/\/t.co\/TzROYlTJGk",
  "id" : 428548773308944384,
  "created_at" : "2014-01-29 15:22:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnJobs",
      "indices" : [ 52, 62 ]
    }, {
      "text" : "CollegeOpportunity",
      "indices" : [ 82, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428548474897186816",
  "text" : "Obama: \"This opportunity agenda has four parts.\"\n1. #ActOnJobs\n2. Job training\n3. #CollegeOpportunity\n4. Making sure hard work pays off",
  "id" : 428548474897186816,
  "created_at" : "2014-01-29 15:21:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 74, 92 ]
    }, {
      "text" : "RaiseTheWage",
      "indices" : [ 93, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428547994477416448",
  "text" : "President Obama: \"I believe this can be a breakthrough year for America.\" #OpportunityForAll #RaiseTheWage",
  "id" : 428547994477416448,
  "created_at" : "2014-01-29 15:19:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Costco",
      "screen_name" : "Costco",
      "indices" : [ 48, 55 ],
      "id_str" : "1056152593",
      "id" : 1056152593
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/428547847571513345\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/oiBeqcu2KU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfKB_xWCcAE7yW_.jpg",
      "id_str" : "428547847131131905",
      "id" : 428547847131131905,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfKB_xWCcAE7yW_.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/oiBeqcu2KU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428547847571513345",
  "text" : "Obama: \"We\u2019re at a moment where businesses like @Costco have created 8 million new jobs over the past 4 years.\" http:\/\/t.co\/oiBeqcu2KU",
  "id" : 428547847571513345,
  "created_at" : "2014-01-29 15:19:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 101, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428547414832971776",
  "text" : "President Obama: \"I talked about last night...an idea that\u2019s at the heart of who we are as a people: #OpportunityForAll.\"",
  "id" : 428547414832971776,
  "created_at" : "2014-01-29 15:17:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 95, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428547212424278016",
  "text" : "President Obama: \"Treating workers well isn\u2019t just the right thing to do, it\u2019s an investment.\" #RaiseTheWage",
  "id" : 428547212424278016,
  "created_at" : "2014-01-29 15:16:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 57, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/ZjiQxWeQW4",
      "expanded_url" : "http:\/\/go.wh.gov\/vsJ6Wu",
      "display_url" : "go.wh.gov\/vsJ6Wu"
    } ]
  },
  "geo" : { },
  "id_str" : "428546883683119104",
  "text" : "Right now: President Obama speaks about why it's time to #RaiseTheWage. Watch \u2192 http:\/\/t.co\/ZjiQxWeQW4",
  "id" : 428546883683119104,
  "created_at" : "2014-01-29 15:15:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 29, 42 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/ZjiQxWeQW4",
      "expanded_url" : "http:\/\/go.wh.gov\/vsJ6Wu",
      "display_url" : "go.wh.gov\/vsJ6Wu"
    } ]
  },
  "geo" : { },
  "id_str" : "428540011668332544",
  "text" : "After calling on Congress to #RaiseTheWage, President Obama speaks at 10:25am ET on why it's time to make it happen: http:\/\/t.co\/ZjiQxWeQW4",
  "id" : 428540011668332544,
  "created_at" : "2014-01-29 14:47:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BigBlockOfCheeseDay",
      "indices" : [ 6, 26 ]
    }, {
      "text" : "AskTheWH",
      "indices" : [ 123, 132 ]
    }, {
      "text" : "SOTU",
      "indices" : [ 134, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428528640096468992",
  "text" : "Happy #BigBlockOfCheeseDay!  Ask your questions about last night's State of the Union &amp; President Obama's agenda using #AskTheWH. #SOTU",
  "id" : 428528640096468992,
  "created_at" : "2014-01-29 14:02:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/428406004120690688\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/KCivlyACE0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfIA_aWCQAEJFuK.jpg",
      "id_str" : "428406003957121025",
      "id" : 428406003957121025,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfIA_aWCQAEJFuK.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/KCivlyACE0"
    } ],
    "hashtags" : [ {
      "text" : "SNOWTU",
      "indices" : [ 8, 15 ]
    }, {
      "text" : "BigBlockOfCheeseDay",
      "indices" : [ 33, 53 ]
    }, {
      "text" : "AskTheWH",
      "indices" : [ 79, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/QyZVjEd34v",
      "expanded_url" : "http:\/\/go.wh.gov\/WxrTkR",
      "display_url" : "go.wh.gov\/WxrTkR"
    } ]
  },
  "geo" : { },
  "id_str" : "428406004120690688",
  "text" : "\u2745 Happy #SNOWTU! \u2745 Get ready for #BigBlockOfCheeseDay by asking questions with #AskTheWH: http:\/\/t.co\/QyZVjEd34v, http:\/\/t.co\/KCivlyACE0",
  "id" : 428406004120690688,
  "created_at" : "2014-01-29 05:55:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 92, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/0DyeSpICcn",
      "expanded_url" : "http:\/\/go.wh.gov\/AJJvAG",
      "display_url" : "go.wh.gov\/AJJvAG"
    } ]
  },
  "geo" : { },
  "id_str" : "428400973435142144",
  "text" : "Watch the enhanced version of President Obama's State of the Union \u2192 http:\/\/t.co\/0DyeSpICcn #SOTU",
  "id" : 428400973435142144,
  "created_at" : "2014-01-29 05:35:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter Government",
      "screen_name" : "gov",
      "indices" : [ 3, 7 ],
      "id_str" : "222953824",
      "id" : 222953824
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 21, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428394650995810304",
  "text" : "RT @gov: Most-quoted #SOTU moments on Twitter:\n1. \"Son of a single mom can be President\"\n2. Equal pay\n3. Sgt. Cory Remsburg http:\/\/t.co\/ANd\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/gov\/status\/428393730437951488\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/ANdLV6vZyb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BfH10-3CMAAC0dP.png",
        "id_str" : "428393730152738816",
        "id" : 428393730152738816,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfH10-3CMAAC0dP.png",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/ANdLV6vZyb"
      } ],
      "hashtags" : [ {
        "text" : "SOTU",
        "indices" : [ 12, 17 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "428393730437951488",
    "text" : "Most-quoted #SOTU moments on Twitter:\n1. \"Son of a single mom can be President\"\n2. Equal pay\n3. Sgt. Cory Remsburg http:\/\/t.co\/ANdLV6vZyb",
    "id" : 428393730437951488,
    "created_at" : "2014-01-29 05:06:39 +0000",
    "user" : {
      "name" : "Twitter Government",
      "screen_name" : "gov",
      "protected" : false,
      "id_str" : "222953824",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/663898965784395776\/rEWW6euI_normal.png",
      "id" : 222953824,
      "verified" : true
    }
  },
  "id" : 428394650995810304,
  "created_at" : "2014-01-29 05:10:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/428382878628474880\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/wI9iDiWL2e",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfHr9VDCQAEh8i4.jpg",
      "id_str" : "428382878431330305",
      "id" : 428382878431330305,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfHr9VDCQAEh8i4.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/wI9iDiWL2e"
    } ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 93, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428382878628474880",
  "text" : "\"The son of a single mom can be President of the greatest nation on Earth.\" \u2014President Obama #OpportunityForAll http:\/\/t.co\/wI9iDiWL2e",
  "id" : 428382878628474880,
  "created_at" : "2014-01-29 04:23:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bobby Harrison ",
      "screen_name" : "bobby44",
      "indices" : [ 3, 11 ],
      "id_str" : "2806537362",
      "id" : 2806537362
    }, {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "indices" : [ 14, 23 ],
      "id_str" : "1604366701",
      "id" : 1604366701
    }, {
      "name" : "Costco",
      "screen_name" : "Costco",
      "indices" : [ 67, 74 ],
      "id_str" : "1056152593",
      "id" : 1056152593
    }, {
      "name" : "Costco",
      "screen_name" : "Costco",
      "indices" : [ 92, 99 ],
      "id_str" : "1056152593",
      "id" : 1056152593
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTUChat",
      "indices" : [ 37, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428382186128302080",
  "text" : "RT @Bobby44: .@LaborSec drops by the #SOTUChat &amp; shows off his @Costco card. Heading to @Costco tomorrow w\/ POTUS to talk min wage http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tom Perez",
        "screen_name" : "LaborSec",
        "indices" : [ 1, 10 ],
        "id_str" : "1604366701",
        "id" : 1604366701
      }, {
        "name" : "Costco",
        "screen_name" : "Costco",
        "indices" : [ 54, 61 ],
        "id_str" : "1056152593",
        "id" : 1056152593
      }, {
        "name" : "Costco",
        "screen_name" : "Costco",
        "indices" : [ 79, 86 ],
        "id_str" : "1056152593",
        "id" : 1056152593
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Bobby44\/status\/428381695239155712\/photo\/1",
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/lr8qHGyCuo",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BfHq4dVCcAA3VFJ.jpg",
        "id_str" : "428381695243350016",
        "id" : 428381695243350016,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfHq4dVCcAA3VFJ.jpg",
        "sizes" : [ {
          "h" : 761,
          "resize" : "fit",
          "w" : 890
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 513,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 761,
          "resize" : "fit",
          "w" : 890
        }, {
          "h" : 291,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/lr8qHGyCuo"
      } ],
      "hashtags" : [ {
        "text" : "SOTUChat",
        "indices" : [ 24, 33 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "428381695239155712",
    "text" : ".@LaborSec drops by the #SOTUChat &amp; shows off his @Costco card. Heading to @Costco tomorrow w\/ POTUS to talk min wage http:\/\/t.co\/lr8qHGyCuo",
    "id" : 428381695239155712,
    "created_at" : "2014-01-29 04:18:49 +0000",
    "user" : {
      "name" : "Brandi Hoffine",
      "screen_name" : "Hoffine44",
      "protected" : false,
      "id_str" : "1665298740",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/502212746134302720\/RqyFWrpZ_normal.jpeg",
      "id" : 1665298740,
      "verified" : true
    }
  },
  "id" : 428382186128302080,
  "created_at" : "2014-01-29 04:20:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gov. Martin O'Malley",
      "screen_name" : "GovernorOMalley",
      "indices" : [ 3, 19 ],
      "id_str" : "3343532685",
      "id" : 3343532685
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 85, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428377536712945664",
  "text" : "RT @GovernorOMalley: President Obama is right \u2014 it\u2019s time to \u201Cgive America a raise.\u201D #RaiseTheWage",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RaiseTheWage",
        "indices" : [ 64, 77 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "428359605874610176",
    "text" : "President Obama is right \u2014 it\u2019s time to \u201Cgive America a raise.\u201D #RaiseTheWage",
    "id" : 428359605874610176,
    "created_at" : "2014-01-29 02:51:03 +0000",
    "user" : {
      "name" : "Martin O'Malley",
      "screen_name" : "MartinOMalley",
      "protected" : false,
      "id_str" : "15824288",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746107754864009216\/nEV7ylWo_normal.jpg",
      "id" : 15824288,
      "verified" : true
    }
  },
  "id" : 428377536712945664,
  "created_at" : "2014-01-29 04:02:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "indices" : [ 3, 12 ],
      "id_str" : "1604366701",
      "id" : 1604366701
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 30, 41 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTUChat",
      "indices" : [ 42, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/wjZLPrQfDL",
      "expanded_url" : "http:\/\/wh.gov\/SOTU",
      "display_url" : "wh.gov\/SOTU"
    } ]
  },
  "geo" : { },
  "id_str" : "428374130975854592",
  "text" : "RT @LaborSec: Dropping by the @WhiteHouse #SOTUChat to take your questions &amp; give my thoughts on the speech. Tune in: http:\/\/t.co\/wjZLPrQfDL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 16, 27 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SOTUChat",
        "indices" : [ 28, 37 ]
      } ],
      "urls" : [ {
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/wjZLPrQfDL",
        "expanded_url" : "http:\/\/wh.gov\/SOTU",
        "display_url" : "wh.gov\/SOTU"
      } ]
    },
    "geo" : { },
    "id_str" : "428371476585385985",
    "text" : "Dropping by the @WhiteHouse #SOTUChat to take your questions &amp; give my thoughts on the speech. Tune in: http:\/\/t.co\/wjZLPrQfDL",
    "id" : 428371476585385985,
    "created_at" : "2014-01-29 03:38:13 +0000",
    "user" : {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "protected" : false,
      "id_str" : "1604366701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744887280666611712\/eEeyFjs6_normal.jpg",
      "id" : 1604366701,
      "verified" : true
    }
  },
  "id" : 428374130975854592,
  "created_at" : "2014-01-29 03:48:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/428372883191001088\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/jLuUzwIZII",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfHi3ffCIAAqr8q.jpg",
      "id_str" : "428372882549252096",
      "id" : 428372882549252096,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfHi3ffCIAAqr8q.jpg",
      "sizes" : [ {
        "h" : 433,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 566
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 566
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 566
      } ],
      "display_url" : "pic.twitter.com\/jLuUzwIZII"
    } ],
    "hashtags" : [ {
      "text" : "SOTUChat",
      "indices" : [ 39, 48 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/0wCbuDsiMA",
      "expanded_url" : "http:\/\/wh.gov\/sotu",
      "display_url" : "wh.gov\/sotu"
    } ]
  },
  "geo" : { },
  "id_str" : "428372883191001088",
  "text" : "Tune in now for our State of the Union #SOTUChat with administration officials \u2192 http:\/\/t.co\/0wCbuDsiMA, http:\/\/t.co\/jLuUzwIZII",
  "id" : 428372883191001088,
  "created_at" : "2014-01-29 03:43:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTUChat",
      "indices" : [ 55, 64 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/GD8K6aq7lH",
      "expanded_url" : "http:\/\/wh.gov\/sotu",
      "display_url" : "wh.gov\/sotu"
    } ]
  },
  "geo" : { },
  "id_str" : "428371722057035776",
  "text" : "Have questions about tonight's State of the Union? Use #SOTUChat and tune in for a live panel from the White House: http:\/\/t.co\/GD8K6aq7lH",
  "id" : 428371722057035776,
  "created_at" : "2014-01-29 03:39:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "indices" : [ 3, 12 ],
      "id_str" : "249722522",
      "id" : 249722522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428369262689124352",
  "text" : "RT @rhodes44: Thank you Cory Remsburg. And please think of all the other wounded warriors like him who are fighting back from difficult wou\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "428367822377345024",
    "text" : "Thank you Cory Remsburg. And please think of all the other wounded warriors like him who are fighting back from difficult wounds",
    "id" : 428367822377345024,
    "created_at" : "2014-01-29 03:23:42 +0000",
    "user" : {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "protected" : false,
      "id_str" : "249722522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/700766726644850688\/1lytmnAl_normal.jpg",
      "id" : 249722522,
      "verified" : true
    }
  },
  "id" : 428369262689124352,
  "created_at" : "2014-01-29 03:29:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Knoller",
      "screen_name" : "markknoller",
      "indices" : [ 3, 15 ],
      "id_str" : "31127446",
      "id" : 31127446
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428368586240167936",
  "text" : "RT @markknoller: A standing ovation for Sergeant First Class Cory Remsburg, whom Pres Obama hails as one who \"never gives up, and he does n\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "428366196958703616",
    "text" : "A standing ovation for Sergeant First Class Cory Remsburg, whom Pres Obama hails as one who \"never gives up, and he does not quit.\"",
    "id" : 428366196958703616,
    "created_at" : "2014-01-29 03:17:14 +0000",
    "user" : {
      "name" : "Mark Knoller",
      "screen_name" : "markknoller",
      "protected" : false,
      "id_str" : "31127446",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/137394623\/knoller_normal.jpg",
      "id" : 31127446,
      "verified" : true
    }
  },
  "id" : 428368586240167936,
  "created_at" : "2014-01-29 03:26:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivier Knox",
      "screen_name" : "OKnox",
      "indices" : [ 3, 9 ],
      "id_str" : "11771512",
      "id" : 11771512
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 130, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428368356589469696",
  "text" : "RT @OKnox: I don't think I have seen a standing ovation that long, that sustained, that bipartisan, in about 14 years of covering #SOTU.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SOTU",
        "indices" : [ 119, 124 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "428366607174205440",
    "text" : "I don't think I have seen a standing ovation that long, that sustained, that bipartisan, in about 14 years of covering #SOTU.",
    "id" : 428366607174205440,
    "created_at" : "2014-01-29 03:18:52 +0000",
    "user" : {
      "name" : "Olivier Knox",
      "screen_name" : "OKnox",
      "protected" : false,
      "id_str" : "11771512",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/552580492596232192\/juCAGmwU_normal.jpeg",
      "id" : 11771512,
      "verified" : true
    }
  },
  "id" : 428368356589469696,
  "created_at" : "2014-01-29 03:25:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTUChat",
      "indices" : [ 73, 82 ]
    }, {
      "text" : "SOTU",
      "indices" : [ 108, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/GD8K6aq7lH",
      "expanded_url" : "http:\/\/wh.gov\/sotu",
      "display_url" : "wh.gov\/sotu"
    } ]
  },
  "geo" : { },
  "id_str" : "428367592714403840",
  "text" : "Right now: Get your questions in for Obama administration officials with #SOTUChat \u2192 http:\/\/t.co\/GD8K6aq7lH #SOTU",
  "id" : 428367592714403840,
  "created_at" : "2014-01-29 03:22:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 78, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428367030140805120",
  "text" : "\"God bless you, and God bless the United States of America.\" \u2014President Obama #SOTU",
  "id" : 428367030140805120,
  "created_at" : "2014-01-29 03:20:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 116, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428366957885538304",
  "text" : "President Obama: \"If we work together, if we summon what is best in us...I know it\u2019s within our reach. Believe it.\" #OpportunityForAll",
  "id" : 428366957885538304,
  "created_at" : "2014-01-29 03:20:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 26, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428366866466504704",
  "text" : "\"A rising America where...#OpportunityForAll lets us go as far as our dreams and toll will take us\u2014none of it is easy.\" \u2014President Obama",
  "id" : 428366866466504704,
  "created_at" : "2014-01-29 03:19:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 110, 115 ]
    }, {
      "text" : "OpportunityForAll",
      "indices" : [ 116, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428366795633098752",
  "text" : "President Obama: \"For more than 200 years...we have placed our collective shoulder to the wheel of progress.\" #SOTU #OpportunityForAll",
  "id" : 428366795633098752,
  "created_at" : "2014-01-29 03:19:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 138, 143 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428366622748065792",
  "text" : "President Obama: \"Men &amp; women like Cory remind us that America has never come easy. Our freedom, our democracy, has never been easy.\" #SOTU",
  "id" : 428366622748065792,
  "created_at" : "2014-01-29 03:18:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 134, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428366465608470528",
  "text" : "Obama: \"Like the Army he loves, like the America he serves, Sergeant First Class Cory Remsburg never gives up, and he does not quit.\" #SOTU",
  "id" : 428366465608470528,
  "created_at" : "2014-01-29 03:18:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/428365955563917312\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/papV6s2DvS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfHckRyCEAArXga.jpg",
      "id_str" : "428365955383562240",
      "id" : 428365955383562240,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfHckRyCEAArXga.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/papV6s2DvS"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428365955563917312",
  "text" : "President Obama: \"Slowly, steadily, with the support of caregivers like his dad Craig...Cory has grown stronger.\" http:\/\/t.co\/papV6s2DvS",
  "id" : 428365955563917312,
  "created_at" : "2014-01-29 03:16:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/428365763489964033\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/CU29om1WRb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfHcZGXCEAAWr0u.jpg",
      "id_str" : "428365763338964992",
      "id" : 428365763338964992,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfHcZGXCEAAWr0u.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/CU29om1WRb"
    } ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 109, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428365763489964033",
  "text" : "President Obama: \"On his 10th deployment, Cory was nearly killed by a massive roadside bomb in Afghanistan.\" #SOTU http:\/\/t.co\/CU29om1WRb",
  "id" : 428365763489964033,
  "created_at" : "2014-01-29 03:15:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActForOurTroops",
      "indices" : [ 115, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428365505599393792",
  "text" : "Obama: \"We\u2019ll keep working to help all our veterans translate their skills and leadership into jobs here at home.\" #ActForOurTroops",
  "id" : 428365505599393792,
  "created_at" : "2014-01-29 03:14:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActForOurTroops",
      "indices" : [ 110, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428365371490717696",
  "text" : "President Obama: \"As this time of war draws to a close, a new generation of heroes returns to civilian life.\" #ActForOurTroops",
  "id" : 428365371490717696,
  "created_at" : "2014-01-29 03:13:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428365314150371328",
  "text" : "\"On every issue, the world turns to us...because of the ideals we stand for, and the burdens we bear to advance them.\" \u2014President Obama",
  "id" : 428365314150371328,
  "created_at" : "2014-01-29 03:13:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/428365180737572864\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/LGPdplvRM2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfHb3K-CQAAvL6h.jpg",
      "id_str" : "428365180460744704",
      "id" : 428365180460744704,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfHb3K-CQAAvL6h.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      } ],
      "display_url" : "pic.twitter.com\/LGPdplvRM2"
    } ],
    "hashtags" : [ {
      "text" : "TeamUSA",
      "indices" : [ 77, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428365180737572864",
  "text" : "President Obama: \"The world will see one expression of that commitment, when #TeamUSA...brings home the gold.\" http:\/\/t.co\/LGPdplvRM2",
  "id" : 428365180737572864,
  "created_at" : "2014-01-29 03:13:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428365068716503040",
  "text" : "Obama: \"We believe in the inherent dignity and equality of every human being, regardless of race or religion, creed or sexual orientation.\"",
  "id" : 428365068716503040,
  "created_at" : "2014-01-29 03:12:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428364997270704130",
  "text" : "Obama: \"We will support our allies, shape a future of greater security and prosperity, and extend a hand to those devastated by disaster.\"",
  "id" : 428364997270704130,
  "created_at" : "2014-01-29 03:12:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 108, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428364926999355393",
  "text" : "Obama: \"Across Africa, we\u2019re bringing together businesses and governments to double access to electricity.\" #SOTU",
  "id" : 428364926999355393,
  "created_at" : "2014-01-29 03:12:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 132, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428364832140972032",
  "text" : "President Obama: \"All people have the right to express themselves freely and peacefully, and have a say in their country\u2019s future.\" #SOTU",
  "id" : 428364832140972032,
  "created_at" : "2014-01-29 03:11:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 124, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428364770090430465",
  "text" : "President Obama: \"From Tunisia to Burma, we\u2019re supporting those who are willing to do the hard work of building democracy.\" #SOTU",
  "id" : 428364770090430465,
  "created_at" : "2014-01-29 03:11:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 128, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428364679015313408",
  "text" : "Obama: \"Our leadership is defined not by our defense against threats, but by the enormous opportunities that exist to do good.\" #SOTU",
  "id" : 428364679015313408,
  "created_at" : "2014-01-29 03:11:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428364609989672960",
  "text" : "President Obama: \"If Iran\u2019s leaders do seize the chance, then Iran could take an important step to rejoin the community of nations.\"",
  "id" : 428364609989672960,
  "created_at" : "2014-01-29 03:10:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 120, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428364553681129472",
  "text" : "President Obama: \"If Iran\u2019s leaders do not take this opportunity, then I will be the first to call for more sanctions.\" #SOTU",
  "id" : 428364553681129472,
  "created_at" : "2014-01-29 03:10:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Iran",
      "indices" : [ 102, 107 ]
    }, {
      "text" : "SOTU",
      "indices" : [ 108, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428364482549915648",
  "text" : "\"For the sake of our national security, we must give diplomacy a chance to succeed.\" \u2014President Obama #Iran #SOTU",
  "id" : 428364482549915648,
  "created_at" : "2014-01-29 03:10:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 131, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428364406482030594",
  "text" : "Obama: \"Let me be clear: If this Congress sends me a new sanctions bill now that threatens to derail these talks, I will veto it.\" #SOTU",
  "id" : 428364406482030594,
  "created_at" : "2014-01-29 03:10:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428364275196129280",
  "text" : "Obama: \"Any long-term deal we agree to must be based on verifiable action that convinces us...that Iran is not building a nuclear bomb.\"",
  "id" : 428364275196129280,
  "created_at" : "2014-01-29 03:09:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 133, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428364037089689601",
  "text" : "Obama: \"We\u2019re engaged in negotiations to...peacefully achieve a goal we all share: preventing Iran from obtaining a nuclear weapon.\" #SOTU",
  "id" : 428364037089689601,
  "created_at" : "2014-01-29 03:08:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/428363907791466496\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/vDBun8lcBt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfHatDpCYAI2HUh.jpg",
      "id_str" : "428363907183304706",
      "id" : 428363907183304706,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfHatDpCYAI2HUh.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/vDBun8lcBt"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428363907791466496",
  "text" : "Obama: \"American diplomacy...backed by pressure, that has halted the progress of Iran\u2019s nuclear program.\" http:\/\/t.co\/vDBun8lcBt",
  "id" : 428363907791466496,
  "created_at" : "2014-01-29 03:08:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428363777101529088",
  "text" : "Obama: \"American diplomacy is supporting Israelis &amp; Palestinians as they engage in difficult but necessary talks to end the conflict there.\"",
  "id" : 428363777101529088,
  "created_at" : "2014-01-29 03:07:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 133, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428363706540765184",
  "text" : "President Obama: \"We will continue to pursue the future the Syrian people deserve \u2013 a future free of dictatorship, terror and fear.\" #SOTU",
  "id" : 428363706540765184,
  "created_at" : "2014-01-29 03:07:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 124, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428363664484483072",
  "text" : "President Obama: \"American diplomacy, backed by the threat of force, is why Syria\u2019s chemical weapons are being eliminated.\" #SOTU",
  "id" : 428363664484483072,
  "created_at" : "2014-01-29 03:07:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428363464961449985",
  "text" : "Obama: \"This needs to be the year Congress lifts the remaining restrictions on detainee transfers &amp; we close the prison at Guantanamo Bay.\"",
  "id" : 428363464961449985,
  "created_at" : "2014-01-29 03:06:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428363438675730432",
  "text" : "President Obama: \"We will not be safer if people abroad believe we strike their countries without regard for the consequence.\"",
  "id" : 428363438675730432,
  "created_at" : "2014-01-29 03:06:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428363292940455936",
  "text" : "\"Even as we aggressively pursue terrorist networks...America must move off a permanent war footing.\" \u2014President Obama",
  "id" : 428363292940455936,
  "created_at" : "2014-01-29 03:05:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 91, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428363223390486528",
  "text" : "President Obama: \"I will not send our troops into harm\u2019s way unless it\u2019s truly necessary.\" #SOTU",
  "id" : 428363223390486528,
  "created_at" : "2014-01-29 03:05:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 129, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428363069656682496",
  "text" : "Obama: \"As Commander-in-Chief, I have used force when needed to protect the American people and I will never hesitate to do so.\" #SOTU",
  "id" : 428363069656682496,
  "created_at" : "2014-01-29 03:04:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428362996478660609",
  "text" : "Obama: \"We have to remain vigilant. But I strongly believe our leadership and our security cannot depend on our outstanding military alone.\"",
  "id" : 428362996478660609,
  "created_at" : "2014-01-29 03:04:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 114, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428362806388588544",
  "text" : "\"Here at home, we\u2019ll keep strengthening our defenses, and combat new threats like cyberattacks.\" \u2014President Obama #SOTU",
  "id" : 428362806388588544,
  "created_at" : "2014-01-29 03:03:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/428362696128339968\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/zelqjSam6h",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfHZmjWCYAA4YfY.jpg",
      "id_str" : "428362695922835456",
      "id" : 428362695922835456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfHZmjWCYAA4YfY.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      } ],
      "display_url" : "pic.twitter.com\/zelqjSam6h"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428362696128339968",
  "text" : "\"After 2014, we will support a unified Afghanistan as it takes responsibility for its own future.\" \u2014President Obama http:\/\/t.co\/zelqjSam6h",
  "id" : 428362696128339968,
  "created_at" : "2014-01-29 03:03:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428362509742252032",
  "text" : "Obama: \"Together with our allies, we will complete our mission by the end of this year, and America\u2019s longest war will finally be over.\"",
  "id" : 428362509742252032,
  "created_at" : "2014-01-29 03:02:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/428362471456243712\/photo\/1",
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/wBA7osDtC6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfHZZejCQAA6WKh.jpg",
      "id_str" : "428362471296876544",
      "id" : 428362471296876544,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfHZZejCQAA6WKh.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      } ],
      "display_url" : "pic.twitter.com\/wBA7osDtC6"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428362471456243712",
  "text" : "\u201CToday, all our troops are out of Iraq.\" \u2014President Obama http:\/\/t.co\/wBA7osDtC6",
  "id" : 428362471456243712,
  "created_at" : "2014-01-29 03:02:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428362400736505856",
  "text" : "President Obama: \"When I took office, nearly 180,000 Americans were serving in Iraq and Afghanistan.\u201D",
  "id" : 428362400736505856,
  "created_at" : "2014-01-29 03:02:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428362356801155073",
  "text" : "Obama: \"Tonight, because of the extraordinary troops &amp; civilians who risk &amp; lay down their lives to keep us free, the U.S. is more secure\"",
  "id" : 428362356801155073,
  "created_at" : "2014-01-29 03:01:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SaluteOurTroops",
      "indices" : [ 128, 144 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428362316523241472",
  "text" : "Obama: \"Few Americans give more to their country than our diplomats and the men &amp; women of the United States Armed Forces.\u201D #SaluteOurTroops",
  "id" : 428362316523241472,
  "created_at" : "2014-01-29 03:01:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/428362218439049216\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/2tMndBBE1F",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfHZKv2CAAAQtaa.jpg",
      "id_str" : "428362218241916928",
      "id" : 428362218241916928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfHZKv2CAAAQtaa.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      } ],
      "display_url" : "pic.twitter.com\/2tMndBBE1F"
    } ],
    "hashtags" : [ {
      "text" : "ActForOurKids",
      "indices" : [ 89, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428362218439049216",
  "text" : "Obama: \"I intend to keep trying, with or without Congress, to help stop more tragedies.\" #ActForOurKids, http:\/\/t.co\/2tMndBBE1F",
  "id" : 428362218439049216,
  "created_at" : "2014-01-29 03:01:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/428361893472763904\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/zZGjCtfcZK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfHY31WCQAEMSag.jpg",
      "id_str" : "428361893300813825",
      "id" : 428361893300813825,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfHY31WCQAEMSag.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      } ],
      "display_url" : "pic.twitter.com\/zZGjCtfcZK"
    } ],
    "hashtags" : [ {
      "text" : "ActForOurKids",
      "indices" : [ 96, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428361893472763904",
  "text" : "Obama: \"Citizenship means standing up for the lives that gun violence steals from us each day.\" #ActForOurKids, http:\/\/t.co\/zZGjCtfcZK",
  "id" : 428361893472763904,
  "created_at" : "2014-01-29 03:00:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RightToVote",
      "indices" : [ 116, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428361764506730496",
  "text" : "\"It should be the power of our vote, not the size of our bank account, that drives our democracy.\" \u2014President Obama #RightToVote",
  "id" : 428361764506730496,
  "created_at" : "2014-01-29 02:59:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RightToVote",
      "indices" : [ 63, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428361636261679104",
  "text" : "President Obama: \"Citizenship means standing up for everyone\u2019s #RightToVote.\"",
  "id" : 428361636261679104,
  "created_at" : "2014-01-29 02:59:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 104, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428361493172985857",
  "text" : "President Obama: \"We can pursue our individual dreams, but still come together as one American family.\" #OpportunityForAll",
  "id" : 428361493172985857,
  "created_at" : "2014-01-29 02:58:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 125, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/BI7CMZpdHb",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "428361333101563904",
  "text" : "Obama: \"Moms, get on your kids to sign up. Kids, call your mom and walk her through the application.\" http:\/\/t.co\/BI7CMZpdHb #GetCovered",
  "id" : 428361333101563904,
  "created_at" : "2014-01-29 02:57:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 85, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/BI7CMZpdHb",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "428361275090157568",
  "text" : "Obama: \"I ask every American who knows someone without health insurance to help them #GetCovered by March 31st.\" http:\/\/t.co\/BI7CMZpdHb",
  "id" : 428361275090157568,
  "created_at" : "2014-01-29 02:57:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/428361080050446336\/photo\/1",
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/X6ZbamYu9t",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfHYIfCCEAAUwpE.jpg",
      "id_str" : "428361079857483776",
      "id" : 428361079857483776,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfHYIfCCEAAUwpE.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      } ],
      "display_url" : "pic.twitter.com\/X6ZbamYu9t"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428361080050446336",
  "text" : "Obama: \"We all owe it to the American people to say what we\u2019re for, not just what we\u2019re against.\" http:\/\/t.co\/X6ZbamYu9t",
  "id" : 428361080050446336,
  "created_at" : "2014-01-29 02:56:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PeopleOverPolitics",
      "indices" : [ 116, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428360957824606208",
  "text" : "Obama: \"Let\u2019s not have another forty-something votes to repeal a law that\u2019s already helping millions of Americans.\" #PeopleOverPolitics",
  "id" : 428360957824606208,
  "created_at" : "2014-01-29 02:56:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428360925226487808",
  "text" : "Obama to the GOP: \"If you have specific plans to cut costs, cover more people &amp; increase choice\u2014tell America what you\u2019d do differently.\"",
  "id" : 428360925226487808,
  "created_at" : "2014-01-29 02:56:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 81, 92 ]
    }, {
      "text" : "ACA",
      "indices" : [ 93, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428360844448382977",
  "text" : "President Obama: \"No woman can ever be charged more just because she\u2019s a woman.\" #GetCovered #ACA",
  "id" : 428360844448382977,
  "created_at" : "2014-01-29 02:55:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 129, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428360713800003584",
  "text" : "Obama on Obamacare: \"Because of this law, no American can ever again be dropped or denied coverage for a preexisting condition.\" #GetCovered",
  "id" : 428360713800003584,
  "created_at" : "2014-01-29 02:55:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 127, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428360495020916736",
  "text" : "Obama: \"Because of the Affordable Care Act, over 9 million Americans have signed up for private health insurance or Medicaid.\" #GetCovered",
  "id" : 428360495020916736,
  "created_at" : "2014-01-29 02:54:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428360188018851840",
  "text" : "President Obama: \"For decades, few things exposed hardworking families to economic hardship more than a broken health care system.\"",
  "id" : 428360188018851840,
  "created_at" : "2014-01-29 02:53:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428359968442822656",
  "text" : "Obama: \"Let\u2019s offer every American access to an automatic IRA on the job, so they can save at work just like everyone in this chamber can.\u201D",
  "id" : 428359968442822656,
  "created_at" : "2014-01-29 02:52:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/428359936049815552\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/G0Kz5mdlnP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfHXF5fCEAA-ilQ.jpg",
      "id_str" : "428359935907205120",
      "id" : 428359935907205120,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfHXF5fCEAA-ilQ.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      } ],
      "display_url" : "pic.twitter.com\/G0Kz5mdlnP"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428359936049815552",
  "text" : "Obama: \"Today, most workers don\u2019t have a pension. A Social Security check often isn\u2019t enough on its own.\" http:\/\/t.co\/G0Kz5mdlnP",
  "id" : 428359936049815552,
  "created_at" : "2014-01-29 02:52:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428359828768296960",
  "text" : "Obama on the Earned Income Tax Credit: \"Let\u2019s work together to strengthen it, reward work, and help more Americans get ahead.\"",
  "id" : 428359828768296960,
  "created_at" : "2014-01-29 02:51:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/428359764188229632\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/ff33gFw4qO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfHW75CCEAACfLt.jpg",
      "id_str" : "428359763986878464",
      "id" : 428359763986878464,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfHW75CCEAACfLt.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      } ],
      "display_url" : "pic.twitter.com\/ff33gFw4qO"
    } ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 89, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428359764188229632",
  "text" : "Obama: \"The Earned Income Tax Credit. It helps about half of all parents at some point.\" #OpportunityForAll, http:\/\/t.co\/ff33gFw4qO",
  "id" : 428359764188229632,
  "created_at" : "2014-01-29 02:51:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/428359640531755008\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/iYWuA5yaDy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfHW0sdCQAEMZZM.jpg",
      "id_str" : "428359640351391745",
      "id" : 428359640351391745,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfHW0sdCQAEMZZM.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      } ],
      "display_url" : "pic.twitter.com\/iYWuA5yaDy"
    } ],
    "hashtags" : [ {
      "text" : "ActOnTenTen",
      "indices" : [ 82, 94 ]
    }, {
      "text" : "RaiseTheWage",
      "indices" : [ 95, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428359640531755008",
  "text" : "Obama to Congress: \"Join the rest of the country. Say yes. Give America a raise.\" #ActOnTenTen #RaiseTheWage, http:\/\/t.co\/iYWuA5yaDy",
  "id" : 428359640531755008,
  "created_at" : "2014-01-29 02:51:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 100, 113 ]
    }, {
      "text" : "ActOnTenTen",
      "indices" : [ 114, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428359512127725568",
  "text" : "Obama: \"If you cook our troops\u2019 meals or wash their dishes, you shouldn\u2019t have to live in poverty.\" #RaiseTheWage #ActOnTenTen",
  "id" : 428359512127725568,
  "created_at" : "2014-01-29 02:50:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428359474639040512",
  "text" : "Obama: \"I will issue an Executive Order requiring federal contractors to pay their federally-funded employees a fair wage of $10.10\/hour.\"",
  "id" : 428359474639040512,
  "created_at" : "2014-01-29 02:50:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 124, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428359069548945408",
  "text" : "Obama: \"I ask more of America\u2019s business leaders to follow John\u2019s lead and do what you can to raise your employees\u2019 wages.\" #RaiseTheWage",
  "id" : 428359069548945408,
  "created_at" : "2014-01-29 02:48:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/428358944533131265\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/7QinRH1vcu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfHWMLpCYAA4QLk.jpg",
      "id_str" : "428358944348594176",
      "id" : 428358944348594176,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfHWMLpCYAA4QLk.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      } ],
      "display_url" : "pic.twitter.com\/7QinRH1vcu"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 103, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428358944533131265",
  "text" : "Obama: \"Since I asked...Congress to raise the minimum wage, 5 states have passed laws to raise theirs\" #RaiseTheWage http:\/\/t.co\/7QinRH1vcu",
  "id" : 428358944533131265,
  "created_at" : "2014-01-29 02:48:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/428358835019857921\/photo\/1",
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/tT9Szrm9GZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfHWFzsCcAAG24X.jpg",
      "id_str" : "428358834839515136",
      "id" : 428358834839515136,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfHWFzsCcAAG24X.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      } ],
      "display_url" : "pic.twitter.com\/tT9Szrm9GZ"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 83, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428358835019857921",
  "text" : "Obama: \"No one who works full time should ever have to raise a family in poverty.\" #RaiseTheWage, http:\/\/t.co\/tT9Szrm9GZ",
  "id" : 428358835019857921,
  "created_at" : "2014-01-29 02:47:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 125, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428358723036524544",
  "text" : "Obama: \"Let\u2019s all come together...and give every woman the opportunity she deserves...when women succeed, America succeeds.\" #EqualPay",
  "id" : 428358723036524544,
  "created_at" : "2014-01-29 02:47:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/428358620175036416\/photo\/1",
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/KzkvwUttjg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfHV5TbCYAAfWLP.jpg",
      "id_str" : "428358620019843072",
      "id" : 428358620019843072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfHV5TbCYAAfWLP.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      } ],
      "display_url" : "pic.twitter.com\/KzkvwUttjg"
    } ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 90, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428358620175036416",
  "text" : "Obama: \u201CIt\u2019s time to do away with workplace policies that belong in a \u2018Mad Men\u2019 episode.\u201D #EqualPay, http:\/\/t.co\/KzkvwUttjg",
  "id" : 428358620175036416,
  "created_at" : "2014-01-29 02:47:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 118, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428358546888339456",
  "text" : "President Obama: \"A mother deserves a day off to care for a sick child or sick parent without running into hardship.\" #OpportunityForAll",
  "id" : 428358546888339456,
  "created_at" : "2014-01-29 02:46:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 32, 41 ]
    }, {
      "text" : "SOTU",
      "indices" : [ 59, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428358492693725184",
  "text" : "President Obama: \"Women deserve #EqualPay for equal work.\" #SOTU",
  "id" : 428358492693725184,
  "created_at" : "2014-01-29 02:46:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/428358405787357185\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/a5cCjXBYZp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfHVs0pCMAIrIG5.jpg",
      "id_str" : "428358405598621698",
      "id" : 428358405598621698,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfHVs0pCMAIrIG5.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      } ],
      "display_url" : "pic.twitter.com\/a5cCjXBYZp"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428358405787357185",
  "text" : "Obama: \"Women make up about half our workforce. But they still make $0.77 for every $1 a man earns. That is wrong.\" http:\/\/t.co\/a5cCjXBYZp",
  "id" : 428358405787357185,
  "created_at" : "2014-01-29 02:46:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 97, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428358289991413760",
  "text" : "President Obama: \"Michelle and I want every child to have the same chance this country gave us.\" #OpportunityForAll",
  "id" : 428358289991413760,
  "created_at" : "2014-01-29 02:45:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428358177349181440",
  "text" : "Obama: \"I\u2019m reaching out to some of America\u2019s leading foundations &amp; corporations...to help more young men of color...stay on track.\"",
  "id" : 428358177349181440,
  "created_at" : "2014-01-29 02:45:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428358056272224256",
  "text" : "Obama: \"We\u2019re shaking up our system of higher education to give parents more information &amp; colleges more incentives to offer better value.\"",
  "id" : 428358056272224256,
  "created_at" : "2014-01-29 02:44:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/428358014890819588\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/41SC1z4kpA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfHVWEaCYAAbMI-.jpg",
      "id_str" : "428358014693695488",
      "id" : 428358014693695488,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfHVWEaCYAAbMI-.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      } ],
      "display_url" : "pic.twitter.com\/41SC1z4kpA"
    } ],
    "hashtags" : [ {
      "text" : "ConnectED",
      "indices" : [ 106, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428358014890819588",
  "text" : "Obama: \"We\u2019ve got a down payment to start connecting more than 15,000 schools &amp; 20 million students.\" #ConnectED, http:\/\/t.co\/41SC1z4kpA",
  "id" : 428358014890819588,
  "created_at" : "2014-01-29 02:44:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnPreK",
      "indices" : [ 123, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428357890190352384",
  "text" : "Obama: \"We'll invest in new partnerships with states...across the country in a race to the top for our youngest children.\" #ActOnPreK",
  "id" : 428357890190352384,
  "created_at" : "2014-01-29 02:44:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnPreK",
      "indices" : [ 86, 96 ]
    }, {
      "text" : "SOTU",
      "indices" : [ 97, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428357796896460801",
  "text" : "President Obama: \"As a parent as well as a President, I repeat that request tonight.\" #ActOnPreK #SOTU",
  "id" : 428357796896460801,
  "created_at" : "2014-01-29 02:43:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/428357581505957889\/photo\/1",
      "indices" : [ 120, 142 ],
      "url" : "http:\/\/t.co\/bZnvzXbL7Q",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfHU81_CQAABL95.jpg",
      "id_str" : "428357581325615104",
      "id" : 428357581325615104,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfHU81_CQAABL95.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      } ],
      "display_url" : "pic.twitter.com\/bZnvzXbL7Q"
    } ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 99, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428357581505957889",
  "text" : "Obama: \"We\u2019re not reaching enough kids &amp; we\u2019re not reaching them in time. That has to change.\" #CollegeOpportunity, http:\/\/t.co\/bZnvzXbL7Q",
  "id" : 428357581505957889,
  "created_at" : "2014-01-29 02:43:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 133, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428357470965485568",
  "text" : "Obama: \"New ways to measure how well our kids think, not how well they can fill in a bubble on a test...it\u2019s worth it\u2014it\u2019s working.\" #SOTU",
  "id" : 428357470965485568,
  "created_at" : "2014-01-29 02:42:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 115, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428357016676220928",
  "text" : "Obama: \"We...have to prepare tomorrow\u2019s workforce, by guaranteeing every child access to a world-class education.\" #CollegeOpportunity",
  "id" : 428357016676220928,
  "created_at" : "2014-01-29 02:40:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/428356946920345600\/photo\/1",
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/K1sum9BGJU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfHUX51CUAAWY_y.jpg",
      "id_str" : "428356946702258176",
      "id" : 428356946702258176,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfHUX51CUAAWY_y.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      } ],
      "display_url" : "pic.twitter.com\/K1sum9BGJU"
    } ],
    "hashtags" : [ {
      "text" : "ActOnUI",
      "indices" : [ 68, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428356946920345600",
  "text" : "President Obama: \u201CWe are stronger when America fields a full team.\u201D #ActOnUI, http:\/\/t.co\/K1sum9BGJU",
  "id" : 428356946920345600,
  "created_at" : "2014-01-29 02:40:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/428356731115016192\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/cMEpVY9neB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfHULWLCcAAv5vl.jpg",
      "id_str" : "428356730972434432",
      "id" : 428356730972434432,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfHULWLCcAAv5vl.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      } ],
      "display_url" : "pic.twitter.com\/cMEpVY9neB"
    } ],
    "hashtags" : [ {
      "text" : "ActOnUI",
      "indices" : [ 108, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428356731115016192",
  "text" : "Obama reading Misty D's story: \"I am confident that in time I will find a job...please give us this chance\" #ActOnUI http:\/\/t.co\/cMEpVY9neB",
  "id" : 428356731115016192,
  "created_at" : "2014-01-29 02:39:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnUI",
      "indices" : [ 111, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428356384053542912",
  "text" : "Obama: \"This Congress needs to restore the unemployment insurance you just let expire for 1.6 million people.\" #ActOnUI",
  "id" : 428356384053542912,
  "created_at" : "2014-01-29 02:38:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 19, 22 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/428356132462022657\/photo\/1",
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/w3N5b8zoKd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfHTofwCEAEfuGb.jpg",
      "id_str" : "428356132248096769",
      "id" : 428356132248096769,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfHTofwCEAEfuGb.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      } ],
      "display_url" : "pic.twitter.com\/w3N5b8zoKd"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428356132462022657",
  "text" : "Obama: \"I\u2019ve asked @VP Biden to lead an across-the-board reform of America\u2019s training programs.\" http:\/\/t.co\/w3N5b8zoKd",
  "id" : 428356132462022657,
  "created_at" : "2014-01-29 02:37:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnCIR",
      "indices" : [ 64, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428355866283503616",
  "text" : "\"Let\u2019s get immigration reform done this year.\" \u2014President Obama #ActOnCIR",
  "id" : 428355866283503616,
  "created_at" : "2014-01-29 02:36:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnCIR",
      "indices" : [ 126, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428355715120783360",
  "text" : "Obama: \"Independent economists say immigration reform will grow our economy &amp; shrink our deficits by almost $1 trillion.\" #ActOnCIR",
  "id" : 428355715120783360,
  "created_at" : "2014-01-29 02:35:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/428355646803562496\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/LC9MF6dlci",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfHTMOyCMAAQSkz.jpg",
      "id_str" : "428355646656753664",
      "id" : 428355646656753664,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfHTMOyCMAAQSkz.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/LC9MF6dlci"
    } ],
    "hashtags" : [ {
      "text" : "ActOnCIR",
      "indices" : [ 101, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428355646803562496",
  "text" : "Obama: \"If we are serious about economic growth, it is time to...fix our broken immigration system.\" #ActOnCIR http:\/\/t.co\/LC9MF6dlci",
  "id" : 428355646803562496,
  "created_at" : "2014-01-29 02:35:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 131, 144 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428355516482715648",
  "text" : "Obama: \"When our children\u2019s children look us in the eye &amp; ask if we did all we could...I want us to be able to say yes we did\" #ActOnClimate",
  "id" : 428355516482715648,
  "created_at" : "2014-01-29 02:34:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428355478121631745",
  "text" : "Obama: \"I directed my administration to\u2026set new standards on the amount of carbon pollution our power plants are allowed to dump.\"",
  "id" : 428355478121631745,
  "created_at" : "2014-01-29 02:34:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 101, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428355415706202112",
  "text" : "FACT: Over the past 8 years, we\u2019ve reduced our total carbon pollution more than any nation on Earth. #ActOnClimate",
  "id" : 428355415706202112,
  "created_at" : "2014-01-29 02:34:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 119, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428355293580623872",
  "text" : "Obama: \"We\u2019ll build on that success by setting new standards for our trucks, so we can keep driving down oil imports.\u201D #ActOnClimate",
  "id" : 428355293580623872,
  "created_at" : "2014-01-29 02:33:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/428355238362247169\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/D4G8dBje0R",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfHS0dTCIAEvHkL.jpg",
      "id_str" : "428355238236397569",
      "id" : 428355238236397569,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfHS0dTCIAEvHkL.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      } ],
      "display_url" : "pic.twitter.com\/D4G8dBje0R"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428355238362247169",
  "text" : "Obama: \"When we rescued our automakers...we worked with them to set higher fuel efficiency standards for our cars.\" http:\/\/t.co\/D4G8dBje0R",
  "id" : 428355238362247169,
  "created_at" : "2014-01-29 02:33:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 95, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428355143852359680",
  "text" : "Obama: \u201CEven as we\u2019ve increased the energy production, we\u2019ve...reduced the energy we consume.\u201D #ActOnClimate",
  "id" : 428355143852359680,
  "created_at" : "2014-01-29 02:33:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/428354948133163008\/photo\/1",
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/xOIlV0yU3J",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfHSjj5CEAEgHC5.jpg",
      "id_str" : "428354947948613633",
      "id" : 428354947948613633,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfHSjj5CEAEgHC5.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      } ],
      "display_url" : "pic.twitter.com\/xOIlV0yU3J"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 75, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428354948133163008",
  "text" : "Obama: \u201CEvery four minutes, another American home or business goes solar.\u201D #ActOnClimate, http:\/\/t.co\/xOIlV0yU3J",
  "id" : 428354948133163008,
  "created_at" : "2014-01-29 02:32:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/428354865450872832\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/fAMPuOOI09",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfHSevxCcAAiWIJ.jpg",
      "id_str" : "428354865236963328",
      "id" : 428354865236963328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfHSevxCcAAiWIJ.jpg",
      "sizes" : [ {
        "h" : 377,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 644,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 214,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 644,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/fAMPuOOI09"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 98, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428354865450872832",
  "text" : "Obama: \"I'll use my authority to protect more of our pristine landscapes for future generations.\" #ActOnClimate, http:\/\/t.co\/fAMPuOOI09",
  "id" : 428354865450872832,
  "created_at" : "2014-01-29 02:32:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/428354573841858561\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/alfHj4l7Th",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfHSNxpCQAAaHzc.jpg",
      "id_str" : "428354573682491392",
      "id" : 428354573682491392,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfHSNxpCQAAaHzc.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      } ],
      "display_url" : "pic.twitter.com\/alfHj4l7Th"
    } ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 95, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428354573841858561",
  "text" : "President Obama: \"Today, America is closer to energy independence than we\u2019ve been in decades.\" #MadeInAmerica, http:\/\/t.co\/alfHj4l7Th",
  "id" : 428354573841858561,
  "created_at" : "2014-01-29 02:31:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 99, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428354469810937856",
  "text" : "Obama: \"Let\u2019s pass a patent reform bill that allows our businesses to stay focused on innovation.\" #MadeInAmerica",
  "id" : 428354469810937856,
  "created_at" : "2014-01-29 02:30:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/428354317611827200\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/Ky9zDfsTIh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfHR-2-CIAAdzwR.jpg",
      "id_str" : "428354317414703104",
      "id" : 428354317414703104,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfHR-2-CIAAdzwR.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      } ],
      "display_url" : "pic.twitter.com\/Ky9zDfsTIh"
    } ],
    "hashtags" : [ {
      "text" : "InvestInSTEM",
      "indices" : [ 95, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428354317611827200",
  "text" : "Obama: \"The nation that goes all-in on innovation today will own the global economy tomorrow.\" #InvestInSTEM, http:\/\/t.co\/Ky9zDfsTIh",
  "id" : 428354317611827200,
  "created_at" : "2014-01-29 02:30:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/428354217456058368\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/CRPxPZzhFJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfHR5B7CUAA2HQg.jpg",
      "id_str" : "428354217275707392",
      "id" : 428354217275707392,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfHR5B7CUAA2HQg.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      } ],
      "display_url" : "pic.twitter.com\/CRPxPZzhFJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428354217456058368",
  "text" : "Obama: \"Let\u2019s do more to help the entrepreneurs &amp; small business owners who create most new jobs in America.\" http:\/\/t.co\/CRPxPZzhFJ",
  "id" : 428354217456058368,
  "created_at" : "2014-01-29 02:29:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 105, 119 ]
    }, {
      "text" : "ActOnJobs",
      "indices" : [ 120, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428354142474874881",
  "text" : "Obama on boosting manufacturing: \"Get those bills to my desk and let\u2019s put more Americans back to work.\" #MadeInAmerica #ActOnJobs",
  "id" : 428354142474874881,
  "created_at" : "2014-01-29 02:29:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428354086459944960",
  "text" : "Obama: \"My administration has launched two hubs for high-tech manufacturing...tonight, I'm announcing we\u2019ll launch 6 more this year.\"",
  "id" : 428354086459944960,
  "created_at" : "2014-01-29 02:29:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RebuildAmerica",
      "indices" : [ 119, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428354014271787008",
  "text" : "President Obama: \u201CI will act on my own to slash bureaucracy and keep cutting the permitting process for key projects.\u201D #RebuildAmerica",
  "id" : 428354014271787008,
  "created_at" : "2014-01-29 02:28:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/428353975855759360\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/JbpD7lGLBO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfHRq99CMAAE5ZL.jpg",
      "id_str" : "428353975692177408",
      "id" : 428353975692177408,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfHRq99CMAAE5ZL.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      } ],
      "display_url" : "pic.twitter.com\/JbpD7lGLBO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428353975855759360",
  "text" : "Obama: \"In today\u2019s global economy, 1st-class jobs gravitate to where there\u2019s 1st-class infrastructure.\" http:\/\/t.co\/JbpD7lGLBO",
  "id" : 428353975855759360,
  "created_at" : "2014-01-29 02:28:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/428353895564201984\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/dLG9395EhO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfHRmS1CAAA61Nd.jpg",
      "id_str" : "428353895396409344",
      "id" : 428353895396409344,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfHRmS1CAAA61Nd.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      } ],
      "display_url" : "pic.twitter.com\/dLG9395EhO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428353895564201984",
  "text" : "Obama: \"We can take the money we save with this transition to tax reform to create jobs rebuilding our roads.\" http:\/\/t.co\/dLG9395EhO",
  "id" : 428353895564201984,
  "created_at" : "2014-01-29 02:28:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/428353648184135681\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/ZpIJouG1jI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfHRX5JCcAANnjV.jpg",
      "id_str" : "428353647982833664",
      "id" : 428353647982833664,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfHRX5JCcAANnjV.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ZpIJouG1jI"
    } ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 97, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428353648184135681",
  "text" : "President Obama: \"How the son of a single mom can be President of the greatest nation on Earth.\" #OpportunityForAll, http:\/\/t.co\/ZpIJouG1jI",
  "id" : 428353648184135681,
  "created_at" : "2014-01-29 02:27:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 71, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428353576550006784",
  "text" : "President Obama: \"How the son of a barkeeper is Speaker of the House.\" #OpportunityForAll",
  "id" : 428353576550006784,
  "created_at" : "2014-01-29 02:27:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 107, 125 ]
    }, {
      "text" : "SOTU",
      "indices" : [ 126, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428353441514012672",
  "text" : "Obama: \"Opportunity is who we are. And the defining project of our generation is to restore that promise.\" #OpportunityForAll #SOTU",
  "id" : 428353441514012672,
  "created_at" : "2014-01-29 02:26:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 100, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428353194146934785",
  "text" : "President Obama: \"It\u2019s how the daughter of a factory worker is CEO of America\u2019s largest automaker.\u201D #OpportunityForAll",
  "id" : 428353194146934785,
  "created_at" : "2014-01-29 02:25:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428353102261927936",
  "text" : "Obama: \"Here in America, our success should depend not on accident of birth, but the strength of our work ethic &amp; the scope of our dreams.\"",
  "id" : 428353102261927936,
  "created_at" : "2014-01-29 02:25:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428353007252955136",
  "text" : "Obama: \"There are millions of Americans outside Washington who are tired of stale political arguments, and are moving this country forward.\"",
  "id" : 428353007252955136,
  "created_at" : "2014-01-29 02:24:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/428352966991433728\/photo\/1",
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/ixOZ2iQDfF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfHQwPlCQAAyqaE.jpg",
      "id_str" : "428352966811074560",
      "id" : 428352966811074560,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfHQwPlCQAAyqaE.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      } ],
      "display_url" : "pic.twitter.com\/ixOZ2iQDfF"
    } ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 76, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428352966991433728",
  "text" : "Let's help every kid who works hard access and succeed in higher education. #CollegeOpportunity, http:\/\/t.co\/ixOZ2iQDfF",
  "id" : 428352966991433728,
  "created_at" : "2014-01-29 02:24:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 6, 20 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/428352885542248448\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/lxFLO31aFK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfHQrf9CAAAmVEm.jpg",
      "id_str" : "428352885307342848",
      "id" : 428352885307342848,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfHQrf9CAAAmVEm.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/lxFLO31aFK"
    } ],
    "hashtags" : [ {
      "text" : "ActForOurVets",
      "indices" : [ 100, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428352885542248448",
  "text" : "FACT: @JoiningForces has encouraged employers to hire or train 380,000 vets &amp; military spouses. #ActForOurVets http:\/\/t.co\/lxFLO31aFK",
  "id" : 428352885542248448,
  "created_at" : "2014-01-29 02:24:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 19, 28 ],
      "id_str" : "36719281",
      "id" : 36719281
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/428352784908300288\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/QjrU8vLD6v",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfHQlp-CMAAALPh.jpg",
      "id_str" : "428352784916688896",
      "id" : 428352784916688896,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfHQlp-CMAAALPh.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      } ],
      "display_url" : "pic.twitter.com\/QjrU8vLD6v"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428352784908300288",
  "text" : "Obama: \"Michelle\u2019s @LetsMove partnership...has helped bring down childhood obesity rates for the 1st time in 30 yrs\" http:\/\/t.co\/QjrU8vLD6v",
  "id" : 428352784908300288,
  "created_at" : "2014-01-29 02:23:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 131, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428352659234775040",
  "text" : "Obama: \"Whenever I can take steps without legislation to expand opportunity for more American families, that\u2019s what I\u2019m gonna do.\" #SOTU",
  "id" : 428352659234775040,
  "created_at" : "2014-01-29 02:23:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 121, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428352396017016832",
  "text" : "Obama: \"What I offer tonight is a set of concrete, practical proposals to speed up growth, strengthen the middle class.\" #OpportunityForAll",
  "id" : 428352396017016832,
  "created_at" : "2014-01-29 02:22:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 122, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428352308049903616",
  "text" : "Obama: \"Even in the midst of recovery, too many Americans are working more than ever just to get by\u2014let alone get ahead.\" #OpportunityForAll",
  "id" : 428352308049903616,
  "created_at" : "2014-01-29 02:22:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 102, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428352066944512000",
  "text" : "President Obama: \"What I believe unites the people of this nation...is the simple, profound belief in #OpportunityForAll.\"",
  "id" : 428352066944512000,
  "created_at" : "2014-01-29 02:21:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 114, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428351998971641856",
  "text" : "Obama: \"That\u2019s what most Americans want\u2014for all of us...to focus on their lives, their hopes, their aspirations.\" #OpportunityForAll",
  "id" : 428351998971641856,
  "created_at" : "2014-01-29 02:20:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 105, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428351955099193344",
  "text" : "President Obama: \"Let\u2019s see where else we can make progress together. Let\u2019s make this a year of action.\" #OpportunityForAll",
  "id" : 428351955099193344,
  "created_at" : "2014-01-29 02:20:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/428351796491214848\/photo\/1",
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/rQ9oAlVnPW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfHPsHOCcAE3Zrb.jpg",
      "id_str" : "428351796336029697",
      "id" : 428351796336029697,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfHPsHOCcAE3Zrb.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      } ],
      "display_url" : "pic.twitter.com\/rQ9oAlVnPW"
    } ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 114, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428351796491214848",
  "text" : "Obama: \"I\u2019m committed to making Washington work better &amp; regaining the trust of the people who sent us here.\" #SOTU, http:\/\/t.co\/rQ9oAlVnPW",
  "id" : 428351796491214848,
  "created_at" : "2014-01-29 02:20:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 134, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428351720482439168",
  "text" : "Obama: \"When our differences shut down government or threaten the credit of the U.S...we are not doing right by the American people.\" #SOTU",
  "id" : 428351720482439168,
  "created_at" : "2014-01-29 02:19:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 132, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428351629277265920",
  "text" : "President Obama to Congress: \"The question for everyone in this chamber...is whether we are going to help or hinder this progress.\" #SOTU",
  "id" : 428351629277265920,
  "created_at" : "2014-01-29 02:19:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 119, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428351578719137792",
  "text" : "President Obama: \"The American people have us better-positioned for the 21st century than any other country on Earth.\" #OpportunityForAll",
  "id" : 428351578719137792,
  "created_at" : "2014-01-29 02:19:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 74, 92 ]
    }, {
      "text" : "SOTU",
      "indices" : [ 93, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428351519906615296",
  "text" : "President Obama: \u201CI believe this can be a breakthrough year for America.\u201D #OpportunityForAll #SOTU",
  "id" : 428351519906615296,
  "created_at" : "2014-01-29 02:18:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 133, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428351468325044224",
  "text" : "Obama: \"Business leaders around the world have declared that China is no longer the world\u2019s number one place to invest; America is.\" #SOTU",
  "id" : 428351468325044224,
  "created_at" : "2014-01-29 02:18:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/428351422489296897\/photo\/1",
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/b9ezXZbkz1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfHPWWDCcAEC1iI.jpg",
      "id_str" : "428351422359302145",
      "id" : 428351422359302145,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfHPWWDCcAEC1iI.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/b9ezXZbkz1"
    } ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 55, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428351422489296897",
  "text" : "President Obama: \"Our deficits cut by more than half.\" #SOTU, http:\/\/t.co\/b9ezXZbkz1",
  "id" : 428351422489296897,
  "created_at" : "2014-01-29 02:18:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/428351339349819392\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/1s7ZOtdBw9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfHPRgJCIAA7vHx.jpg",
      "id_str" : "428351339169456128",
      "id" : 428351339169456128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfHPRgJCIAA7vHx.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      } ],
      "display_url" : "pic.twitter.com\/1s7ZOtdBw9"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 93, 106 ]
    }, {
      "text" : "SOTU",
      "indices" : [ 107, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428351339349819392",
  "text" : "We\u2019re importing less oil than we\u2019re producing at home for the first time in nearly 20 years. #ActOnClimate #SOTU, http:\/\/t.co\/1s7ZOtdBw9",
  "id" : 428351339349819392,
  "created_at" : "2014-01-29 02:18:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/428351254360629248\/photo\/1",
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/XF6rml05DU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfHPMjXCcAA40-s.jpg",
      "id_str" : "428351254134157312",
      "id" : 428351254134157312,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfHPMjXCcAA40-s.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 562
      } ],
      "display_url" : "pic.twitter.com\/XF6rml05DU"
    } ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 76, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428351254360629248",
  "text" : "FACT: Our manufacturers are adding jobs for the first time since the 1990s. #MadeInAmerica, http:\/\/t.co\/XF6rml05DU",
  "id" : 428351254360629248,
  "created_at" : "2014-01-29 02:17:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 84, 102 ]
    }, {
      "text" : "SOTU",
      "indices" : [ 103, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428351140804444161",
  "text" : "\"It is you, our citizens, who make the state of our union strong.\" \u2014President Obama #OpportunityForAll #SOTU",
  "id" : 428351140804444161,
  "created_at" : "2014-01-29 02:17:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 108, 126 ]
    }, {
      "text" : "SOTU",
      "indices" : [ 127, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428350937225510912",
  "text" : "Obama: \"A man took the bus home from the graveyard shift, bone-tired, but dreaming big dreams for his son.\" #OpportunityForAll #SOTU",
  "id" : 428350937225510912,
  "created_at" : "2014-01-29 02:16:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 101, 115 ]
    }, {
      "text" : "ActOnClimate",
      "indices" : [ 116, 129 ]
    }, {
      "text" : "SOTU",
      "indices" : [ 130, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428350836432195585",
  "text" : "President Obama: \"An autoworker fine-tuned some of the best, most fuel-efficient cars in the world.\" #MadeInAmerica #ActOnClimate #SOTU",
  "id" : 428350836432195585,
  "created_at" : "2014-01-29 02:16:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 86, 105 ]
    }, {
      "text" : "SOTU",
      "indices" : [ 106, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428350747076755456",
  "text" : "FACT: America's high school graduation rate is higher than its been in three decades. #CollegeOpportunity #SOTU",
  "id" : 428350747076755456,
  "created_at" : "2014-01-29 02:15:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 94, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428350654244225024",
  "text" : "\"Today in America, a teacher spent extra time with a student who needed it.\" \u2014President Obama #OpportunityForAll",
  "id" : 428350654244225024,
  "created_at" : "2014-01-29 02:15:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 105, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/GD8K6aq7lH",
      "expanded_url" : "http:\/\/wh.gov\/sotu",
      "display_url" : "wh.gov\/sotu"
    } ]
  },
  "geo" : { },
  "id_str" : "428350589853270017",
  "text" : "\u201CMr. Speaker, Mr. Vice President, members of Congress, my fellow Americans.\u201D \u2014President Obama begins his #SOTU: http:\/\/t.co\/GD8K6aq7lH",
  "id" : 428350589853270017,
  "created_at" : "2014-01-29 02:15:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StateOfTheUnion",
      "indices" : [ 47, 63 ]
    }, {
      "text" : "SOTU",
      "indices" : [ 104, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/GD8K6aq7lH",
      "expanded_url" : "http:\/\/wh.gov\/sotu",
      "display_url" : "wh.gov\/sotu"
    } ]
  },
  "geo" : { },
  "id_str" : "428349755438424064",
  "text" : "Starting now: President Obama delivers his 5th #StateOfTheUnion address. Watch \u2192 http:\/\/t.co\/GD8K6aq7lH #SOTU",
  "id" : 428349755438424064,
  "created_at" : "2014-01-29 02:11:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/428346451832238080\/photo\/1",
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/HnAi161cKm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfHK1A0CAAEyQdk.jpg",
      "id_str" : "428346451677020161",
      "id" : 428346451677020161,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfHK1A0CAAEyQdk.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/HnAi161cKm"
    } ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 38, 43 ]
    }, {
      "text" : "StateOfTheUnion",
      "indices" : [ 44, 60 ]
    }, {
      "text" : "OutOfManyWeAreOne",
      "indices" : [ 61, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/0wCbuDsiMA",
      "expanded_url" : "http:\/\/wh.gov\/sotu",
      "display_url" : "wh.gov\/sotu"
    } ]
  },
  "geo" : { },
  "id_str" : "428346451832238080",
  "text" : "Let's do this. http:\/\/t.co\/0wCbuDsiMA #SOTU #StateOfTheUnion #OutOfManyWeAreOne, http:\/\/t.co\/HnAi161cKm",
  "id" : 428346451832238080,
  "created_at" : "2014-01-29 01:58:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StateOfTheUnion",
      "indices" : [ 40, 56 ]
    }, {
      "text" : "SOTUinthreewords",
      "indices" : [ 57, 74 ]
    } ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/0wCbuDsiMA",
      "expanded_url" : "http:\/\/wh.gov\/sotu",
      "display_url" : "wh.gov\/sotu"
    } ]
  },
  "geo" : { },
  "id_str" : "428345542947516416",
  "text" : "About to begin \u2192 http:\/\/t.co\/0wCbuDsiMA #StateOfTheUnion #SOTUinthreewords",
  "id" : 428345542947516416,
  "created_at" : "2014-01-29 01:55:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 48, 53 ]
    }, {
      "text" : "StateOfTheUnion",
      "indices" : [ 54, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/LmV8ZJVDHz",
      "expanded_url" : "https:\/\/vine.co\/v\/MuUzvF0AhUz",
      "display_url" : "vine.co\/v\/MuUzvF0AhUz"
    } ]
  },
  "geo" : { },
  "id_str" : "428343521355915265",
  "text" : "Heading to the Capitol. https:\/\/t.co\/LmV8ZJVDHz #SOTU #StateOfTheUnion",
  "id" : 428343521355915265,
  "created_at" : "2014-01-29 01:47:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/428339479120576512\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/76nQ4vs5AY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfHEfJcCUAA58Y4.jpg",
      "id_str" : "428339478965407744",
      "id" : 428339478965407744,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfHEfJcCUAA58Y4.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/76nQ4vs5AY"
    } ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 98, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/0wCbuDsiMA",
      "expanded_url" : "http:\/\/wh.gov\/sotu",
      "display_url" : "wh.gov\/sotu"
    } ]
  },
  "geo" : { },
  "id_str" : "428339479120576512",
  "text" : "President Obama's State of the Union starts in 30 minutes. Don't miss it \u2192 http:\/\/t.co\/0wCbuDsiMA #SOTU, http:\/\/t.co\/76nQ4vs5AY",
  "id" : 428339479120576512,
  "created_at" : "2014-01-29 01:31:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joey Hudy",
      "screen_name" : "Joey_Hudy",
      "indices" : [ 3, 13 ],
      "id_str" : "321466257",
      "id" : 321466257
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 40, 51 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Joey_Hudy\/status\/428305606672650240\/photo\/1",
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/Akkkf7ue3q",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfGlrgpIgAAoLx9.jpg",
      "id_str" : "428305606492323840",
      "id" : 428305606492323840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfGlrgpIgAAoLx9.jpg",
      "sizes" : [ {
        "h" : 1032,
        "resize" : "fit",
        "w" : 581
      }, {
        "h" : 604,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1032,
        "resize" : "fit",
        "w" : 581
      }, {
        "h" : 1032,
        "resize" : "fit",
        "w" : 581
      } ],
      "display_url" : "pic.twitter.com\/Akkkf7ue3q"
    } ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 52, 57 ]
    }, {
      "text" : "dontbeboredmakesomething",
      "indices" : [ 58, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428338355378864128",
  "text" : "RT @Joey_Hudy: Back where it all began. @WhiteHouse #SOTU #dontbeboredmakesomething http:\/\/t.co\/Akkkf7ue3q",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 25, 36 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Joey_Hudy\/status\/428305606672650240\/photo\/1",
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/Akkkf7ue3q",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BfGlrgpIgAAoLx9.jpg",
        "id_str" : "428305606492323840",
        "id" : 428305606492323840,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfGlrgpIgAAoLx9.jpg",
        "sizes" : [ {
          "h" : 1032,
          "resize" : "fit",
          "w" : 581
        }, {
          "h" : 604,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1032,
          "resize" : "fit",
          "w" : 581
        }, {
          "h" : 1032,
          "resize" : "fit",
          "w" : 581
        } ],
        "display_url" : "pic.twitter.com\/Akkkf7ue3q"
      } ],
      "hashtags" : [ {
        "text" : "SOTU",
        "indices" : [ 37, 42 ]
      }, {
        "text" : "dontbeboredmakesomething",
        "indices" : [ 43, 68 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "428305606672650240",
    "text" : "Back where it all began. @WhiteHouse #SOTU #dontbeboredmakesomething http:\/\/t.co\/Akkkf7ue3q",
    "id" : 428305606672650240,
    "created_at" : "2014-01-28 23:16:28 +0000",
    "user" : {
      "name" : "Joey Hudy",
      "screen_name" : "Joey_Hudy",
      "protected" : false,
      "id_str" : "321466257",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/517291421586710528\/NAQCKPN5_normal.jpeg",
      "id" : 321466257,
      "verified" : false
    }
  },
  "id" : 428338355378864128,
  "created_at" : "2014-01-29 01:26:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 61, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/CQh43lBXio",
      "expanded_url" : "http:\/\/wh.gov\/sotu",
      "display_url" : "wh.gov\/sotu"
    } ]
  },
  "geo" : { },
  "id_str" : "428334627720544256",
  "text" : "RT @arneduncan: Here we go. On my way to the Capitol for the #SOTU. You won't want to miss it - 9pm ET http:\/\/t.co\/CQh43lBXio",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SOTU",
        "indices" : [ 45, 50 ]
      } ],
      "urls" : [ {
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/CQh43lBXio",
        "expanded_url" : "http:\/\/wh.gov\/sotu",
        "display_url" : "wh.gov\/sotu"
      } ]
    },
    "geo" : { },
    "id_str" : "428334191676506113",
    "text" : "Here we go. On my way to the Capitol for the #SOTU. You won't want to miss it - 9pm ET http:\/\/t.co\/CQh43lBXio",
    "id" : 428334191676506113,
    "created_at" : "2014-01-29 01:10:04 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 428334627720544256,
  "created_at" : "2014-01-29 01:11:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "indices" : [ 3, 13 ],
      "id_str" : "1613223313",
      "id" : 1613223313
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 52, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/lx5ItHtaNY",
      "expanded_url" : "http:\/\/wh.gov\/sotu",
      "display_url" : "wh.gov\/sotu"
    } ]
  },
  "geo" : { },
  "id_str" : "428330468535439360",
  "text" : "RT @Cecilia44: En route to the Hill to watch my 3rd #SOTU as DPC Director. Don't forget to tune in: http:\/\/t.co\/lx5ItHtaNY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SOTU",
        "indices" : [ 37, 42 ]
      } ],
      "urls" : [ {
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/lx5ItHtaNY",
        "expanded_url" : "http:\/\/wh.gov\/sotu",
        "display_url" : "wh.gov\/sotu"
      } ]
    },
    "geo" : { },
    "id_str" : "428329619813437440",
    "text" : "En route to the Hill to watch my 3rd #SOTU as DPC Director. Don't forget to tune in: http:\/\/t.co\/lx5ItHtaNY",
    "id" : 428329619813437440,
    "created_at" : "2014-01-29 00:51:54 +0000",
    "user" : {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "protected" : false,
      "id_str" : "1613223313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000172019215\/ed65eda76f51213f91b33edbaa62054c_normal.jpeg",
      "id" : 1613223313,
      "verified" : true
    }
  },
  "id" : 428330468535439360,
  "created_at" : "2014-01-29 00:55:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StateOfTheUnion",
      "indices" : [ 44, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/BxtwFUmjOl",
      "expanded_url" : "https:\/\/vine.co\/v\/MuFDThArQb1",
      "display_url" : "vine.co\/v\/MuFDThArQb1"
    }, {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/se4yYSg5Cu",
      "expanded_url" : "http:\/\/wh.gov\/sotu",
      "display_url" : "wh.gov\/sotu"
    } ]
  },
  "geo" : { },
  "id_str" : "428328623209476096",
  "text" : "RT @FLOTUS: \"Heading over to watch Barack's #StateOfTheUnion address.\" \u2014FLOTUS: https:\/\/t.co\/BxtwFUmjOl\n\nWatch here: http:\/\/t.co\/se4yYSg5Cu\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "StateOfTheUnion",
        "indices" : [ 32, 48 ]
      }, {
        "text" : "SOTU",
        "indices" : [ 128, 133 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/BxtwFUmjOl",
        "expanded_url" : "https:\/\/vine.co\/v\/MuFDThArQb1",
        "display_url" : "vine.co\/v\/MuFDThArQb1"
      }, {
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/se4yYSg5Cu",
        "expanded_url" : "http:\/\/wh.gov\/sotu",
        "display_url" : "wh.gov\/sotu"
      } ]
    },
    "geo" : { },
    "id_str" : "428328491944521728",
    "text" : "\"Heading over to watch Barack's #StateOfTheUnion address.\" \u2014FLOTUS: https:\/\/t.co\/BxtwFUmjOl\n\nWatch here: http:\/\/t.co\/se4yYSg5Cu #SOTU",
    "id" : 428328491944521728,
    "created_at" : "2014-01-29 00:47:25 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 428328623209476096,
  "created_at" : "2014-01-29 00:47:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/428315527149142016\/photo\/1",
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/Qrhhw4oyHh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfGus9gCQAAIiz2.jpg",
      "id_str" : "428315527023312896",
      "id" : 428315527023312896,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfGus9gCQAAIiz2.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Qrhhw4oyHh"
    } ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 38, 43 ]
    } ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/0wCbuDsiMA",
      "expanded_url" : "http:\/\/wh.gov\/sotu",
      "display_url" : "wh.gov\/sotu"
    } ]
  },
  "geo" : { },
  "id_str" : "428315527149142016",
  "text" : "Final touches: http:\/\/t.co\/0wCbuDsiMA #SOTU, http:\/\/t.co\/Qrhhw4oyHh",
  "id" : 428315527149142016,
  "created_at" : "2014-01-28 23:55:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/rvn3164X2E",
      "expanded_url" : "http:\/\/Wh.gov\/SOTU",
      "display_url" : "Wh.gov\/SOTU"
    } ]
  },
  "geo" : { },
  "id_str" : "428300892358844416",
  "text" : "RT @FLOTUS: Meet the First Lady's guests for tonight's State of the Union address &amp; watch live \u2014&gt; http:\/\/t.co\/rvn3164X2E,  http:\/\/t.co\/cnsv\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SOTU",
        "indices" : [ 141, 146 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/rvn3164X2E",
        "expanded_url" : "http:\/\/Wh.gov\/SOTU",
        "display_url" : "Wh.gov\/SOTU"
      }, {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/cnsvtV3ot6",
        "expanded_url" : "http:\/\/instagram.com\/p\/jurkSZPZOi\/",
        "display_url" : "instagram.com\/p\/jurkSZPZOi\/"
      } ]
    },
    "geo" : { },
    "id_str" : "428295482063200256",
    "text" : "Meet the First Lady's guests for tonight's State of the Union address &amp; watch live \u2014&gt; http:\/\/t.co\/rvn3164X2E,  http:\/\/t.co\/cnsvtV3ot6 #SOTU",
    "id" : 428295482063200256,
    "created_at" : "2014-01-28 22:36:14 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 428300892358844416,
  "created_at" : "2014-01-28 22:57:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/428294069920731136\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/eH8t5d048O",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfGbL-wIIAAV5J6.jpg",
      "id_str" : "428294069702631424",
      "id" : 428294069702631424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfGbL-wIIAAV5J6.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/eH8t5d048O"
    } ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 108, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/GD8K6aq7lH",
      "expanded_url" : "http:\/\/wh.gov\/sotu",
      "display_url" : "wh.gov\/sotu"
    } ]
  },
  "geo" : { },
  "id_str" : "428294069920731136",
  "text" : "Bo and Sunny will be watching the enhanced State of the Union tonight. You can, too: http:\/\/t.co\/GD8K6aq7lH #SOTU, http:\/\/t.co\/eH8t5d048O",
  "id" : 428294069920731136,
  "created_at" : "2014-01-28 22:30:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/428281669729017856\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/qZVQuqhtWo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfGP6LtCYAMBQBv.jpg",
      "id_str" : "428281669313781763",
      "id" : 428281669313781763,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfGP6LtCYAMBQBv.jpg",
      "sizes" : [ {
        "h" : 433,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 566
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 566
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 566
      } ],
      "display_url" : "pic.twitter.com\/qZVQuqhtWo"
    } ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 108, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/0wCbuDsiMA",
      "expanded_url" : "http:\/\/wh.gov\/sotu",
      "display_url" : "wh.gov\/sotu"
    } ]
  },
  "geo" : { },
  "id_str" : "428281669729017856",
  "text" : "Here's the best place to watch an enhanced version of tonight's State of the Union \u2192 http:\/\/t.co\/0wCbuDsiMA #SOTU, http:\/\/t.co\/qZVQuqhtWo",
  "id" : 428281669729017856,
  "created_at" : "2014-01-28 21:41:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/428273899818999809\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/QoUFARNr1d",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfGI17rIEAAbdvp.jpg",
      "id_str" : "428273899709927424",
      "id" : 428273899709927424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfGI17rIEAAbdvp.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/QoUFARNr1d"
    } ],
    "hashtags" : [ {
      "text" : "InsideSOTU",
      "indices" : [ 101, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/GD8K6aq7lH",
      "expanded_url" : "http:\/\/wh.gov\/sotu",
      "display_url" : "wh.gov\/sotu"
    } ]
  },
  "geo" : { },
  "id_str" : "428273899818999809",
  "text" : "Excited for the State of the Union? Watch the enhanced livestream at 9pm ET \u2192 http:\/\/t.co\/GD8K6aq7lH #InsideSOTU, http:\/\/t.co\/QoUFARNr1d",
  "id" : 428273899818999809,
  "created_at" : "2014-01-28 21:10:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/428267644022558722\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/WN1uA381hC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfGDJywCcAA_z8O.jpg",
      "id_str" : "428267643842228224",
      "id" : 428267643842228224,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfGDJywCcAA_z8O.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/WN1uA381hC"
    } ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 110, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/0wCbuDsiMA",
      "expanded_url" : "http:\/\/wh.gov\/sotu",
      "display_url" : "wh.gov\/sotu"
    } ]
  },
  "geo" : { },
  "id_str" : "428267644022558722",
  "text" : "Tonight at 9pm ET, President Obama will deliver the State of the Union. Don't miss it: http:\/\/t.co\/0wCbuDsiMA #SOTU, http:\/\/t.co\/WN1uA381hC",
  "id" : 428267644022558722,
  "created_at" : "2014-01-28 20:45:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 110, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/uiIFMo9dAs",
      "expanded_url" : "http:\/\/go.wh.gov\/sMiSoe",
      "display_url" : "go.wh.gov\/sMiSoe"
    } ]
  },
  "geo" : { },
  "id_str" : "428261325207506945",
  "text" : "Great news: President Obama is raising the minimum wage for federal contract workers \u2192 http:\/\/t.co\/uiIFMo9dAs #RaiseTheWage",
  "id" : 428261325207506945,
  "created_at" : "2014-01-28 20:20:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/428250812981051392\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/muJzpzVpJE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfFz2GeCIAEFWDU.jpg",
      "id_str" : "428250812863619073",
      "id" : 428250812863619073,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfFz2GeCIAEFWDU.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/muJzpzVpJE"
    } ],
    "hashtags" : [ {
      "text" : "InsideSOTU",
      "indices" : [ 98, 109 ]
    }, {
      "text" : "Coats",
      "indices" : [ 110, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/0wCbuDsiMA",
      "expanded_url" : "http:\/\/wh.gov\/sotu",
      "display_url" : "wh.gov\/sotu"
    } ]
  },
  "geo" : { },
  "id_str" : "428250812981051392",
  "text" : "Network news anchors are here for their annual lunch with President Obama: http:\/\/t.co\/0wCbuDsiMA #InsideSOTU #Coats http:\/\/t.co\/muJzpzVpJE",
  "id" : 428250812981051392,
  "created_at" : "2014-01-28 19:38:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/428237389148852224\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/iP57i1xu6K",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfFnou3CMAAI9_i.jpg",
      "id_str" : "428237389048197120",
      "id" : 428237389048197120,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfFnou3CMAAI9_i.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/iP57i1xu6K"
    } ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 85, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/bcYSgE2MTm",
      "expanded_url" : "http:\/\/go.wh.gov\/3ZbvQH",
      "display_url" : "go.wh.gov\/3ZbvQH"
    } ]
  },
  "geo" : { },
  "id_str" : "428237389148852224",
  "text" : "\"I think the tone is right. I think the framework is right.\" \u2014President Obama on his #SOTU: http:\/\/t.co\/bcYSgE2MTm, http:\/\/t.co\/iP57i1xu6K",
  "id" : 428237389148852224,
  "created_at" : "2014-01-28 18:45:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/428228194391453697\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/rCzSZFfC0O",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfFfRheCUAASVe6.jpg",
      "id_str" : "428228194223673344",
      "id" : 428228194223673344,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfFfRheCUAASVe6.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/rCzSZFfC0O"
    } ],
    "hashtags" : [ {
      "text" : "SOTUisComing",
      "indices" : [ 72, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/0wCbuDsiMA",
      "expanded_url" : "http:\/\/wh.gov\/sotu",
      "display_url" : "wh.gov\/sotu"
    } ]
  },
  "geo" : { },
  "id_str" : "428228194391453697",
  "text" : "President Obama reviews one of the final drafts his State of the Union. #SOTUisComing \u2192 http:\/\/t.co\/0wCbuDsiMA http:\/\/t.co\/rCzSZFfC0O",
  "id" : 428228194391453697,
  "created_at" : "2014-01-28 18:08:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTUinThreeWords",
      "indices" : [ 39, 56 ]
    } ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/0wCbuDsiMA",
      "expanded_url" : "http:\/\/wh.gov\/sotu",
      "display_url" : "wh.gov\/sotu"
    } ]
  },
  "geo" : { },
  "id_str" : "428221130273341440",
  "text" : "Watch it here \u2192 http:\/\/t.co\/0wCbuDsiMA #SOTUinThreeWords",
  "id" : 428221130273341440,
  "created_at" : "2014-01-28 17:40:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Instagram",
      "screen_name" : "instagram",
      "indices" : [ 3, 13 ],
      "id_str" : "180505807",
      "id" : 180505807
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "InsideSOTU",
      "indices" : [ 89, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/ovz32Yu8vd",
      "expanded_url" : "http:\/\/blog.instagram.com\/post\/74842939404\/sotu2014",
      "display_url" : "blog.instagram.com\/post\/748429394\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "428215856871784448",
  "text" : "RT @instagram: A look at the State of the Union through Instagram http:\/\/t.co\/ovz32Yu8vd #InsideSOTU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "InsideSOTU",
        "indices" : [ 74, 85 ]
      } ],
      "urls" : [ {
        "indices" : [ 51, 73 ],
        "url" : "http:\/\/t.co\/ovz32Yu8vd",
        "expanded_url" : "http:\/\/blog.instagram.com\/post\/74842939404\/sotu2014",
        "display_url" : "blog.instagram.com\/post\/748429394\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "428215073580920832",
    "text" : "A look at the State of the Union through Instagram http:\/\/t.co\/ovz32Yu8vd #InsideSOTU",
    "id" : 428215073580920832,
    "created_at" : "2014-01-28 17:16:44 +0000",
    "user" : {
      "name" : "Instagram",
      "screen_name" : "instagram",
      "protected" : false,
      "id_str" : "180505807",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/786681705981673472\/T5OKNZ1-_normal.jpg",
      "id" : 180505807,
      "verified" : true
    }
  },
  "id" : 428215856871784448,
  "created_at" : "2014-01-28 17:19:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTUinThreeWords",
      "indices" : [ 44, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/8vEXNMDFYm",
      "expanded_url" : "http:\/\/vine.co\/v\/MuvOjuUqXgi",
      "display_url" : "vine.co\/v\/MuvOjuUqXgi"
    } ]
  },
  "geo" : { },
  "id_str" : "428214434243547137",
  "text" : "Opportunity for all: http:\/\/t.co\/8vEXNMDFYm #SOTUinThreeWords",
  "id" : 428214434243547137,
  "created_at" : "2014-01-28 17:14:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 61, 72 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/428204749323010048\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/ax1On1ErZg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfFJ81CIMAAn9Ua.jpg",
      "id_str" : "428204748953890816",
      "id" : 428204748953890816,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfFJ81CIMAAn9Ua.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ax1On1ErZg"
    } ],
    "hashtags" : [ {
      "text" : "InsideSOTU",
      "indices" : [ 99, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/pkT6EQGhfw",
      "expanded_url" : "http:\/\/instagram.com\/whitehouse",
      "display_url" : "instagram.com\/whitehouse"
    } ]
  },
  "geo" : { },
  "id_str" : "428204749323010048",
  "text" : "Bo and Sunny are ready for tonight's State of the Union (via @Pfeiffer44) \u2192 http:\/\/t.co\/pkT6EQGhfw #InsideSOTU, http:\/\/t.co\/ax1On1ErZg",
  "id" : 428204749323010048,
  "created_at" : "2014-01-28 16:35:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 128, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/0wCbuDsiMA",
      "expanded_url" : "http:\/\/wh.gov\/sotu",
      "display_url" : "wh.gov\/sotu"
    } ]
  },
  "geo" : { },
  "id_str" : "428198480901718019",
  "text" : "Tonight's enhanced State of the Union:\n1. Real-time graphics\n2. Videos\n3. Charts\nAll that and more here: http:\/\/t.co\/0wCbuDsiMA #SOTU",
  "id" : 428198480901718019,
  "created_at" : "2014-01-28 16:10:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 111, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/BMlZ4MxUTK",
      "expanded_url" : "http:\/\/go.wh.gov\/J9c46w",
      "display_url" : "go.wh.gov\/J9c46w"
    } ]
  },
  "geo" : { },
  "id_str" : "428191993299488768",
  "text" : "Go behind-the-scenes with President Obama as he writes his State of the Union address \u2192 http:\/\/t.co\/BMlZ4MxUTK #SOTU",
  "id" : 428191993299488768,
  "created_at" : "2014-01-28 15:45:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "428185044482404353",
  "text" : "RT @pfeiffer44: After months of work, stacks of memos, dozens of drafts, and a very bushy beard for our speechwriter, it's finally State of\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "428144350984302592",
    "text" : "After months of work, stacks of memos, dozens of drafts, and a very bushy beard for our speechwriter, it's finally State of the Union day",
    "id" : 428144350984302592,
    "created_at" : "2014-01-28 12:35:42 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 428185044482404353,
  "created_at" : "2014-01-28 15:17:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 135, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/GD8K6aq7lH",
      "expanded_url" : "http:\/\/wh.gov\/sotu",
      "display_url" : "wh.gov\/sotu"
    } ]
  },
  "geo" : { },
  "id_str" : "428175376968601601",
  "text" : "Tonight, President Obama will lay out plans to expand opportunity for all hardworking Americans. Don't miss it: http:\/\/t.co\/GD8K6aq7lH #SOTU",
  "id" : 428175376968601601,
  "created_at" : "2014-01-28 14:38:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/427985238992912384\/photo\/1",
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/2YjmZ0jFko",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfCCTp-IgAAct4m.jpg",
      "id_str" : "427985238795780096",
      "id" : 427985238795780096,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfCCTp-IgAAct4m.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/2YjmZ0jFko"
    } ],
    "hashtags" : [ {
      "text" : "SOTUisComing",
      "indices" : [ 44, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/mGdLGFrpiK",
      "expanded_url" : "http:\/\/wh.gov\/SOTU",
      "display_url" : "wh.gov\/SOTU"
    } ]
  },
  "geo" : { },
  "id_str" : "427985238992912384",
  "text" : "With 24 hours to go, the editing continues. #SOTUisComing \u2192 http:\/\/t.co\/mGdLGFrpiK, http:\/\/t.co\/2YjmZ0jFko",
  "id" : 427985238992912384,
  "created_at" : "2014-01-28 02:03:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/427960850335268864\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/t7log4BA82",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfBsIDVCIAAh0Tu.jpg",
      "id_str" : "427960850188476416",
      "id" : 427960850188476416,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfBsIDVCIAAh0Tu.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/t7log4BA82"
    } ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 18, 23 ]
    }, {
      "text" : "InsideSOTU",
      "indices" : [ 97, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/UPhTKuWpGM",
      "expanded_url" : "http:\/\/wh.gov\/SOTU",
      "display_url" : "wh.gov\/SOTU"
    } ]
  },
  "geo" : { },
  "id_str" : "427960850335268864",
  "text" : "President Obama's #SOTU drafts are piling up. Tune in tomorrow at 9pm ET: http:\/\/t.co\/UPhTKuWpGM #InsideSOTU, http:\/\/t.co\/t7log4BA82",
  "id" : 427960850335268864,
  "created_at" : "2014-01-28 00:26:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "indices" : [ 3, 12 ],
      "id_str" : "1604366701",
      "id" : 1604366701
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 82, 93 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 37, 50 ]
    }, {
      "text" : "SOTU",
      "indices" : [ 115, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "427953368787845120",
  "text" : "RT @LaborSec: Pres. Truman's call to #RaiseTheWage is just one great clip in this @WhiteHouse video featuring past #SOTU addresses: http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 68, 79 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RaiseTheWage",
        "indices" : [ 23, 36 ]
      }, {
        "text" : "SOTU",
        "indices" : [ 101, 106 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/ezsgDB4rn9",
        "expanded_url" : "http:\/\/go.wh.gov\/TUawYD",
        "display_url" : "go.wh.gov\/TUawYD"
      } ]
    },
    "geo" : { },
    "id_str" : "427950964424073216",
    "text" : "Pres. Truman's call to #RaiseTheWage is just one great clip in this @WhiteHouse video featuring past #SOTU addresses: http:\/\/t.co\/ezsgDB4rn9",
    "id" : 427950964424073216,
    "created_at" : "2014-01-27 23:47:15 +0000",
    "user" : {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "protected" : false,
      "id_str" : "1604366701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744887280666611712\/eEeyFjs6_normal.jpg",
      "id" : 1604366701,
      "verified" : true
    }
  },
  "id" : 427953368787845120,
  "created_at" : "2014-01-27 23:56:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 110, 121 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "427949834478575617",
  "text" : "RT @Lubin44: Oh hey there. Didn't see you come into my office. But since you did, follow along for the latest @WhiteHouse digital news.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 97, 108 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "427948826926653440",
    "text" : "Oh hey there. Didn't see you come into my office. But since you did, follow along for the latest @WhiteHouse digital news.",
    "id" : 427948826926653440,
    "created_at" : "2014-01-27 23:38:45 +0000",
    "user" : {
      "name" : "Lindsay Holst",
      "screen_name" : "Holst44",
      "protected" : false,
      "id_str" : "1563426390",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615987325261082625\/QxtC65p2_normal.jpg",
      "id" : 1563426390,
      "verified" : true
    }
  },
  "id" : 427949834478575617,
  "created_at" : "2014-01-27 23:42:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/427924793208233984\/photo\/1",
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/aWQ6tje0co",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfBLVQMCIAAr1EP.jpg",
      "id_str" : "427924793094971392",
      "id" : 427924793094971392,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfBLVQMCIAAr1EP.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/aWQ6tje0co"
    } ],
    "hashtags" : [ {
      "text" : "InsideSOTU",
      "indices" : [ 43, 54 ]
    } ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/kTKUEsDRDj",
      "expanded_url" : "http:\/\/instagram.com\/petesouza",
      "display_url" : "instagram.com\/petesouza"
    } ]
  },
  "geo" : { },
  "id_str" : "427924793208233984",
  "text" : "Apples in the Oval: http:\/\/t.co\/kTKUEsDRDj #InsideSOTU, http:\/\/t.co\/aWQ6tje0co",
  "id" : 427924793208233984,
  "created_at" : "2014-01-27 22:03:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Google",
      "screen_name" : "google",
      "indices" : [ 19, 26 ],
      "id_str" : "20536157",
      "id" : 20536157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/RgSd6sqYax",
      "expanded_url" : "http:\/\/youtu.be\/L1b-9Tq-v1Q",
      "display_url" : "youtu.be\/L1b-9Tq-v1Q"
    }, {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/6qUjMgQG3d",
      "expanded_url" : "http:\/\/go.wh.gov\/EohBgJ",
      "display_url" : "go.wh.gov\/EohBgJ"
    } ]
  },
  "geo" : { },
  "id_str" : "427912844940570624",
  "text" : "On Friday, go on a @Google Hangout Road Trip with President Obama: http:\/\/t.co\/RgSd6sqYax. Get your questions in now: http:\/\/t.co\/6qUjMgQG3d",
  "id" : 427912844940570624,
  "created_at" : "2014-01-27 21:15:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 49, 58 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/427903528988725248\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/Q1jWS6tRCy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfA3_gvCIAE0DxJ.jpg",
      "id_str" : "427903528858689537",
      "id" : 427903528858689537,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfA3_gvCIAE0DxJ.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Q1jWS6tRCy"
    } ],
    "hashtags" : [ {
      "text" : "SayCheese",
      "indices" : [ 100, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/y5bWZhkoxp",
      "expanded_url" : "http:\/\/instagram.com\/whitehouse",
      "display_url" : "instagram.com\/whitehouse"
    } ]
  },
  "geo" : { },
  "id_str" : "427903528988725248",
  "text" : "Ever wonder what it's like to be the White House @PressSec? Here's the view. http:\/\/t.co\/y5bWZhkoxp #SayCheese, http:\/\/t.co\/Q1jWS6tRCy",
  "id" : 427903528988725248,
  "created_at" : "2014-01-27 20:38:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joey Hudy",
      "screen_name" : "Joey_Hudy",
      "indices" : [ 3, 13 ],
      "id_str" : "321466257",
      "id" : 321466257
    }, {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 32, 47 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Joey_Hudy\/status\/427877272998010880\/photo\/1",
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/xZani5Nh4L",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfAgHODCYAA7-9K.png",
      "id_str" : "427877273002205184",
      "id" : 427877273002205184,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfAgHODCYAA7-9K.png",
      "sizes" : [ {
        "h" : 172,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 172,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 172,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 172,
        "resize" : "fit",
        "w" : 320
      } ],
      "display_url" : "pic.twitter.com\/xZani5Nh4L"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "427884101392433154",
  "text" : "RT @Joey_Hudy: I'm going to the @whitehouseostp again!! opps forgot my cannon! http:\/\/t.co\/xZani5Nh4L",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House OSTP",
        "screen_name" : "whitehouseostp",
        "indices" : [ 17, 32 ],
        "id_str" : "33998183",
        "id" : 33998183
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Joey_Hudy\/status\/427877272998010880\/photo\/1",
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/xZani5Nh4L",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BfAgHODCYAA7-9K.png",
        "id_str" : "427877273002205184",
        "id" : 427877273002205184,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfAgHODCYAA7-9K.png",
        "sizes" : [ {
          "h" : 172,
          "resize" : "fit",
          "w" : 320
        }, {
          "h" : 172,
          "resize" : "fit",
          "w" : 320
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 172,
          "resize" : "fit",
          "w" : 320
        }, {
          "h" : 172,
          "resize" : "fit",
          "w" : 320
        } ],
        "display_url" : "pic.twitter.com\/xZani5Nh4L"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "427877272998010880",
    "text" : "I'm going to the @whitehouseostp again!! opps forgot my cannon! http:\/\/t.co\/xZani5Nh4L",
    "id" : 427877272998010880,
    "created_at" : "2014-01-27 18:54:26 +0000",
    "user" : {
      "name" : "Joey Hudy",
      "screen_name" : "Joey_Hudy",
      "protected" : false,
      "id_str" : "321466257",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/517291421586710528\/NAQCKPN5_normal.jpeg",
      "id" : 321466257,
      "verified" : false
    }
  },
  "id" : 427884101392433154,
  "created_at" : "2014-01-27 19:21:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 41, 50 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "Instagram",
      "screen_name" : "instagram",
      "indices" : [ 71, 81 ],
      "id_str" : "180505807",
      "id" : 180505807
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/427877452350627840\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/GV04nXxzwq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfAgRpdCAAAc5cQ.png",
      "id_str" : "427877452157681664",
      "id" : 427877452157681664,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfAgRpdCAAAc5cQ.png",
      "sizes" : [ {
        "h" : 187,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 469,
        "resize" : "fit",
        "w" : 853
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 330,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 469,
        "resize" : "fit",
        "w" : 853
      } ],
      "display_url" : "pic.twitter.com\/GV04nXxzwq"
    } ],
    "hashtags" : [ {
      "text" : "InsideSOTU",
      "indices" : [ 102, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "427877452350627840",
  "text" : "Live from the White House Briefing Room: @PressSec Jay Carney takes an @Instagram of the press corps. #InsideSOTU, http:\/\/t.co\/GV04nXxzwq",
  "id" : 427877452350627840,
  "created_at" : "2014-01-27 18:55:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 31, 40 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/427876317120716801\/photo\/1",
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/6UQ8oKLk61",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfAfPk0IEAAkZdb.jpg",
      "id_str" : "427876317041004544",
      "id" : 427876317041004544,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfAfPk0IEAAkZdb.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/6UQ8oKLk61"
    } ],
    "hashtags" : [ {
      "text" : "InsideSOTU",
      "indices" : [ 76, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/pkT6EQGhfw",
      "expanded_url" : "http:\/\/instagram.com\/whitehouse",
      "display_url" : "instagram.com\/whitehouse"
    } ]
  },
  "geo" : { },
  "id_str" : "427876317120716801",
  "text" : "Walk into the Oval Office with @PressSec Jay Carney: http:\/\/t.co\/pkT6EQGhfw #InsideSOTU, http:\/\/t.co\/6UQ8oKLk61",
  "id" : 427876317120716801,
  "created_at" : "2014-01-27 18:50:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Joey Hudy",
      "screen_name" : "Joey_Hudy",
      "indices" : [ 17, 27 ],
      "id_str" : "321466257",
      "id" : 321466257
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontBeBoredMakeSomething",
      "indices" : [ 103, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/3pQOrSfIEi",
      "expanded_url" : "http:\/\/go.wh.gov\/Su2gDH",
      "display_url" : "go.wh.gov\/Su2gDH"
    } ]
  },
  "geo" : { },
  "id_str" : "427872233546338304",
  "text" : "RT @FLOTUS: Meet @Joey_Hudy, one of the First Lady's State of the Union guests: http:\/\/t.co\/3pQOrSfIEi #DontBeBoredMakeSomething, http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Joey Hudy",
        "screen_name" : "Joey_Hudy",
        "indices" : [ 5, 15 ],
        "id_str" : "321466257",
        "id" : 321466257
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/427871371574931456\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/u37PQ8aY3t",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BfAavtHIAAAn5XO.jpg",
        "id_str" : "427871371465850880",
        "id" : 427871371465850880,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfAavtHIAAAn5XO.jpg",
        "sizes" : [ {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1920
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/u37PQ8aY3t"
      } ],
      "hashtags" : [ {
        "text" : "DontBeBoredMakeSomething",
        "indices" : [ 91, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/3pQOrSfIEi",
        "expanded_url" : "http:\/\/go.wh.gov\/Su2gDH",
        "display_url" : "go.wh.gov\/Su2gDH"
      } ]
    },
    "geo" : { },
    "id_str" : "427871371574931456",
    "text" : "Meet @Joey_Hudy, one of the First Lady's State of the Union guests: http:\/\/t.co\/3pQOrSfIEi #DontBeBoredMakeSomething, http:\/\/t.co\/u37PQ8aY3t",
    "id" : 427871371574931456,
    "created_at" : "2014-01-27 18:30:59 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 427872233546338304,
  "created_at" : "2014-01-27 18:34:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/427863866358640640\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/RcreiemdaT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BfAT616IUAEBE13.jpg",
      "id_str" : "427863866224431105",
      "id" : 427863866224431105,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BfAT616IUAEBE13.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/RcreiemdaT"
    } ],
    "hashtags" : [ {
      "text" : "InsideSOTU",
      "indices" : [ 100, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/GD8K6aq7lH",
      "expanded_url" : "http:\/\/wh.gov\/sotu",
      "display_url" : "wh.gov\/sotu"
    } ]
  },
  "geo" : { },
  "id_str" : "427863866358640640",
  "text" : "President Obama's pen\u2014ready for editing his latest State of the Union draft. http:\/\/t.co\/GD8K6aq7lH #InsideSOTU, http:\/\/t.co\/RcreiemdaT",
  "id" : 427863866358640640,
  "created_at" : "2014-01-27 18:01:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter Government",
      "screen_name" : "gov",
      "indices" : [ 3, 7 ],
      "id_str" : "222953824",
      "id" : 222953824
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 81, 92 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 121, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "427859783354703873",
  "text" : "RT @gov: Ahead of his 5th State of the Union, President Obama shares a Vine from @WhiteHouse. Join the conversation with #SOTU http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 72, 83 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SOTU",
        "indices" : [ 112, 117 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/TR0MMEn7zv",
        "expanded_url" : "http:\/\/vine.co\/v\/MuvOjuUqXgi",
        "display_url" : "vine.co\/v\/MuvOjuUqXgi"
      } ]
    },
    "in_reply_to_status_id_str" : "427851597377699840",
    "geo" : { },
    "id_str" : "427855293809455104",
    "in_reply_to_user_id" : 30313925,
    "text" : "Ahead of his 5th State of the Union, President Obama shares a Vine from @WhiteHouse. Join the conversation with #SOTU http:\/\/t.co\/TR0MMEn7zv",
    "id" : 427855293809455104,
    "in_reply_to_status_id" : 427851597377699840,
    "created_at" : "2014-01-27 17:27:05 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Twitter Government",
      "screen_name" : "gov",
      "protected" : false,
      "id_str" : "222953824",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/663898965784395776\/rEWW6euI_normal.png",
      "id" : 222953824,
      "verified" : true
    }
  },
  "id" : 427859783354703873,
  "created_at" : "2014-01-27 17:44:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/eX1XqLwwCM",
      "expanded_url" : "https:\/\/vine.co\/v\/MuvOjuUqXgi",
      "display_url" : "vine.co\/v\/MuvOjuUqXgi"
    }, {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/GD8K6aq7lH",
      "expanded_url" : "http:\/\/wh.gov\/sotu",
      "display_url" : "wh.gov\/sotu"
    } ]
  },
  "geo" : { },
  "id_str" : "427851597377699840",
  "text" : "President Obama has a special message about his 5th State of the Union \u2192 https:\/\/t.co\/eX1XqLwwCM\n\nTune in Tuesday at http:\/\/t.co\/GD8K6aq7lH",
  "id" : 427851597377699840,
  "created_at" : "2014-01-27 17:12:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Seaborn",
      "screen_name" : "SamSeaborn",
      "indices" : [ 3, 14 ],
      "id_str" : "465700933",
      "id" : 465700933
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 70, 81 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 82, 91 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BigBlockOfCheeseDay",
      "indices" : [ 49, 69 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/o1s4zYQYRt",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2014\/01\/24\/first-ever-virtual-big-block-cheese-day-white-house-open-questions",
      "display_url" : "whitehouse.gov\/blog\/2014\/01\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "427832674427097088",
  "text" : "RT @SamSeaborn: You have a voice. Participate in #BigBlockOfCheeseDay @WhiteHouse @PressSec http:\/\/t.co\/o1s4zYQYRt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 54, 65 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "Josh Earnest",
        "screen_name" : "PressSec",
        "indices" : [ 66, 75 ],
        "id_str" : "113420831",
        "id" : 113420831
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BigBlockOfCheeseDay",
        "indices" : [ 33, 53 ]
      } ],
      "urls" : [ {
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/o1s4zYQYRt",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2014\/01\/24\/first-ever-virtual-big-block-cheese-day-white-house-open-questions",
        "display_url" : "whitehouse.gov\/blog\/2014\/01\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "427829336553451521",
    "text" : "You have a voice. Participate in #BigBlockOfCheeseDay @WhiteHouse @PressSec http:\/\/t.co\/o1s4zYQYRt",
    "id" : 427829336553451521,
    "created_at" : "2014-01-27 15:43:57 +0000",
    "user" : {
      "name" : "Sam Seaborn",
      "screen_name" : "SamSeaborn",
      "protected" : false,
      "id_str" : "465700933",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1759535295\/Sam_Seaborn_normal.jpg",
      "id" : 465700933,
      "verified" : false
    }
  },
  "id" : 427832674427097088,
  "created_at" : "2014-01-27 15:57:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 20, 29 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "Instagram",
      "screen_name" : "instagram",
      "indices" : [ 55, 65 ],
      "id_str" : "180505807",
      "id" : 180505807
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/427825593942437888\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/WJ69cOADge",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Be_xHGBCAAAreLS.jpg",
      "id_str" : "427825593799802880",
      "id" : 427825593799802880,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Be_xHGBCAAAreLS.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/WJ69cOADge"
    } ],
    "hashtags" : [ {
      "text" : "InsideSOTU",
      "indices" : [ 3, 14 ]
    }, {
      "text" : "BlackAndWhite",
      "indices" : [ 91, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/y5bWZhkoxp",
      "expanded_url" : "http:\/\/instagram.com\/whitehouse",
      "display_url" : "instagram.com\/whitehouse"
    } ]
  },
  "geo" : { },
  "id_str" : "427825593942437888",
  "text" : "Go #InsideSOTU with @PressSec today on the White House @Instagram \u2192 http:\/\/t.co\/y5bWZhkoxp #BlackAndWhite, http:\/\/t.co\/WJ69cOADge",
  "id" : 427825593942437888,
  "created_at" : "2014-01-27 15:29:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/427606717388423169\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/nJEzAT9quj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Be8qCzZCcAAw7Sk.jpg",
      "id_str" : "427606717266817024",
      "id" : 427606717266817024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Be8qCzZCcAAw7Sk.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/nJEzAT9quj"
    } ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 110, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/0wCbuDsiMA",
      "expanded_url" : "http:\/\/wh.gov\/sotu",
      "display_url" : "wh.gov\/sotu"
    } ]
  },
  "geo" : { },
  "id_str" : "427606717388423169",
  "text" : "Preview President Obama's State of the Union and watch an enhanced version on Tuesday: http:\/\/t.co\/0wCbuDsiMA #SOTU, http:\/\/t.co\/nJEzAT9quj",
  "id" : 427606717388423169,
  "created_at" : "2014-01-27 00:59:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/427565559145054208\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/pjzPfzQ5pR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Be8EnEXIYAAxEhD.jpg",
      "id_str" : "427565558855655424",
      "id" : 427565558855655424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Be8EnEXIYAAxEhD.jpg",
      "sizes" : [ {
        "h" : 1100,
        "resize" : "fit",
        "w" : 733
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1100,
        "resize" : "fit",
        "w" : 733
      } ],
      "display_url" : "pic.twitter.com\/pjzPfzQ5pR"
    } ],
    "hashtags" : [ {
      "text" : "InsideSOTU",
      "indices" : [ 95, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "427565559145054208",
  "text" : "President Obama fine tunes his State of the Union address with Chief Speechwriter Cody Keenan. #InsideSOTU, http:\/\/t.co\/pjzPfzQ5pR",
  "id" : 427565559145054208,
  "created_at" : "2014-01-26 22:15:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/427554378992848896\/photo\/1",
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/jqKAeSYwLa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Be76cT2IUAA3KnE.jpg",
      "id_str" : "427554378917367808",
      "id" : 427554378917367808,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Be76cT2IUAA3KnE.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/jqKAeSYwLa"
    } ],
    "hashtags" : [ {
      "text" : "InsideSOTU",
      "indices" : [ 25, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "427554378992848896",
  "text" : "Presidential cup o' tea. #InsideSOTU, http:\/\/t.co\/jqKAeSYwLa",
  "id" : 427554378992848896,
  "created_at" : "2014-01-26 21:31:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Joshua Malina)))",
      "screen_name" : "JoshMalina",
      "indices" : [ 3, 14 ],
      "id_str" : "24931027",
      "id" : 24931027
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AskTheWH",
      "indices" : [ 101, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "427549233064214528",
  "text" : "RT @JoshMalina: On Wed, the White House is hosting the 1st-ever virtual Big Block of Cheese Day. Use #AskTheWH to ask your questions: http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AskTheWH",
        "indices" : [ 85, 94 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/uCbpV9iXwW",
        "expanded_url" : "http:\/\/go.wh.gov\/HSnmaY",
        "display_url" : "go.wh.gov\/HSnmaY"
      } ]
    },
    "geo" : { },
    "id_str" : "427141055448748032",
    "text" : "On Wed, the White House is hosting the 1st-ever virtual Big Block of Cheese Day. Use #AskTheWH to ask your questions: http:\/\/t.co\/uCbpV9iXwW",
    "id" : 427141055448748032,
    "created_at" : "2014-01-25 18:08:58 +0000",
    "user" : {
      "name" : "(((Joshua Malina)))",
      "screen_name" : "JoshMalina",
      "protected" : false,
      "id_str" : "24931027",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/728236710660702208\/hLBFVJ5A_normal.jpg",
      "id" : 24931027,
      "verified" : true
    }
  },
  "id" : 427549233064214528,
  "created_at" : "2014-01-26 21:10:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leo Thomas McGarry",
      "screen_name" : "LeoMcGarry",
      "indices" : [ 3, 14 ],
      "id_str" : "61868624",
      "id" : 61868624
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 17, 28 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "427534738245828608",
  "text" : "RT @LeoMcGarry: .@WhiteHouse We're going to raise the level of public debate in this country. And let that be our legacy. #BigBlockOfCheese\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 1, 12 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BigBlockOfCheeseDay",
        "indices" : [ 106, 126 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "426854213147451392",
    "geo" : { },
    "id_str" : "427113979857485824",
    "in_reply_to_user_id" : 30313925,
    "text" : ".@WhiteHouse We're going to raise the level of public debate in this country. And let that be our legacy. #BigBlockOfCheeseDay",
    "id" : 427113979857485824,
    "in_reply_to_status_id" : 426854213147451392,
    "created_at" : "2014-01-25 16:21:22 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Leo Thomas McGarry",
      "screen_name" : "LeoMcGarry",
      "protected" : false,
      "id_str" : "61868624",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1117898389\/leo_normal.jpg",
      "id" : 61868624,
      "verified" : false
    }
  },
  "id" : 427534738245828608,
  "created_at" : "2014-01-26 20:13:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Google",
      "screen_name" : "google",
      "indices" : [ 91, 98 ],
      "id_str" : "20536157",
      "id" : 20536157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/NqwePuZ2ZI",
      "expanded_url" : "http:\/\/go.wh.gov\/3PuPZ8",
      "display_url" : "go.wh.gov\/3PuPZ8"
    } ]
  },
  "geo" : { },
  "id_str" : "427526977051168768",
  "text" : "A road trip with President Obama? Yep. Get your questions in for the 1st-ever Presidential @Google Hangout Road Trip: http:\/\/t.co\/NqwePuZ2ZI",
  "id" : 427526977051168768,
  "created_at" : "2014-01-26 19:42:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BigBlockOfCheeseDay",
      "indices" : [ 59, 79 ]
    }, {
      "text" : "AskTheWH",
      "indices" : [ 107, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/hV1kdUs4K9",
      "expanded_url" : "http:\/\/wh.gov\/cheeseday",
      "display_url" : "wh.gov\/cheeseday"
    } ]
  },
  "geo" : { },
  "id_str" : "427516477608955907",
  "text" : "In queso you missed it, we're hosting the 1st-ever virtual #BigBlockOfCheeseDay on Wed. Get your Q's in w\/ #AskTheWH: http:\/\/t.co\/hV1kdUs4K9",
  "id" : 427516477608955907,
  "created_at" : "2014-01-26 19:00:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "InsideSOTU",
      "indices" : [ 129, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/du4WfZ4FJ6",
      "expanded_url" : "http:\/\/go.wh.gov\/ActL1g",
      "display_url" : "go.wh.gov\/ActL1g"
    } ]
  },
  "geo" : { },
  "id_str" : "427504968267202560",
  "text" : "Turn back the clock to see what past State of the Union addresses would look like with enhanced graphics: http:\/\/t.co\/du4WfZ4FJ6 #InsideSOTU",
  "id" : 427504968267202560,
  "created_at" : "2014-01-26 18:15:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/3QiS35ZOAY",
      "expanded_url" : "http:\/\/go.wh.gov\/vFXxkf",
      "display_url" : "go.wh.gov\/vFXxkf"
    } ]
  },
  "geo" : { },
  "id_str" : "427478726222159872",
  "text" : "\"To anyone out there who has ever been assaulted: You are not alone. We have your back. I\u2019ve got your back.\" \u2014Obama: http:\/\/t.co\/3QiS35ZOAY",
  "id" : 427478726222159872,
  "created_at" : "2014-01-26 16:30:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "427470784878354432",
  "text" : "RT @PressSec: With millions covered and everyone with insurance receiving new benefits &amp; protections, repeal is NOT a winning issue for GOP\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NoPlan",
        "indices" : [ 131, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "427458938481553408",
    "text" : "With millions covered and everyone with insurance receiving new benefits &amp; protections, repeal is NOT a winning issue for GOP. #NoPlan.",
    "id" : 427458938481553408,
    "created_at" : "2014-01-26 15:12:07 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 427470784878354432,
  "created_at" : "2014-01-26 15:59:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/DBsWQvnlyD",
      "expanded_url" : "http:\/\/go.wh.gov\/SQw5rX",
      "display_url" : "go.wh.gov\/SQw5rX"
    } ]
  },
  "geo" : { },
  "id_str" : "427456078142402561",
  "text" : "\"We\u2019re going to help schools do a better job of preventing &amp; responding to sexual assault on their campuses.\" \u2014Obama: http:\/\/t.co\/DBsWQvnlyD",
  "id" : 427456078142402561,
  "created_at" : "2014-01-26 15:00:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 96, 107 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "InsideSOTU",
      "indices" : [ 132, 143 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/oYMn7TlucX",
      "expanded_url" : "http:\/\/go.wh.gov\/FWgvCr",
      "display_url" : "go.wh.gov\/FWgvCr"
    } ]
  },
  "geo" : { },
  "id_str" : "427175654619365377",
  "text" : "\"3 words sum up the President's message on Tuesday night: Opportunity, action &amp; optimism.\" \u2014@Pfeiffer44: http:\/\/t.co\/oYMn7TlucX #InsideSOTU",
  "id" : 427175654619365377,
  "created_at" : "2014-01-25 20:26:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1Is2Many",
      "indices" : [ 123, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/5aWFvGXS0O",
      "expanded_url" : "http:\/\/go.wh.gov\/brz2p8",
      "display_url" : "go.wh.gov\/brz2p8"
    } ]
  },
  "geo" : { },
  "id_str" : "427138983374487552",
  "text" : "\"We\u2019ve especially got to teach young men to show women the respect they deserve.\" \u2014President Obama: http:\/\/t.co\/5aWFvGXS0O #1Is2Many",
  "id" : 427138983374487552,
  "created_at" : "2014-01-25 18:00:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1Is2Many",
      "indices" : [ 116, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/fef44QT1RI",
      "expanded_url" : "http:\/\/go.wh.gov\/S7TqQg",
      "display_url" : "go.wh.gov\/S7TqQg"
    } ]
  },
  "geo" : { },
  "id_str" : "427116331977035776",
  "text" : "\"We\u2019re going to keep working to stop sexual assaults wherever they occur.\" \u2014President Obama: http:\/\/t.co\/fef44QT1RI #1Is2Many",
  "id" : 427116331977035776,
  "created_at" : "2014-01-25 16:30:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1Is2Many",
      "indices" : [ 95, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/S8YT3tAU1i",
      "expanded_url" : "http:\/\/go.wh.gov\/Cid7RP",
      "display_url" : "go.wh.gov\/Cid7RP"
    } ]
  },
  "geo" : { },
  "id_str" : "427094834353283072",
  "text" : "President Obama's Weekly Address: Taking action to end sexual assault \u2192 http:\/\/t.co\/S8YT3tAU1i #1Is2Many",
  "id" : 427094834353283072,
  "created_at" : "2014-01-25 15:05:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/426911996873678849\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/l3m9gOGrZC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BeyyMvxCAAEuj3R.jpg",
      "id_str" : "426911996743647233",
      "id" : 426911996743647233,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BeyyMvxCAAEuj3R.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/l3m9gOGrZC"
    } ],
    "hashtags" : [ {
      "text" : "InsideSOTU",
      "indices" : [ 102, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/0wCbuDsiMA",
      "expanded_url" : "http:\/\/wh.gov\/sotu",
      "display_url" : "wh.gov\/sotu"
    } ]
  },
  "geo" : { },
  "id_str" : "426911996873678849",
  "text" : "President Obama at work on his State of the Union.\nTune in Tuesday at 9pm ET \u2192 http:\/\/t.co\/0wCbuDsiMA\n#InsideSOTU, http:\/\/t.co\/l3m9gOGrZC",
  "id" : 426911996873678849,
  "created_at" : "2014-01-25 02:58:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josiah Bartlet",
      "screen_name" : "Pres_Bartlet",
      "indices" : [ 3, 16 ],
      "id_str" : "156763824",
      "id" : 156763824
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BigBlockOfCheeseDay",
      "indices" : [ 38, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "426906507046039552",
  "text" : "RT @Pres_Bartlet: So who is ready for #BigBlockOfCheeseDay this January 29? What will you ask? Big Block of Cheese Day: Virtual Edition htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BigBlockOfCheeseDay",
        "indices" : [ 20, 40 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/IyUjv4QQBN",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=2JJGDieJ5Tc",
        "display_url" : "youtube.com\/watch?v=2JJGDi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "426905581618618368",
    "text" : "So who is ready for #BigBlockOfCheeseDay this January 29? What will you ask? Big Block of Cheese Day: Virtual Edition http:\/\/t.co\/IyUjv4QQBN",
    "id" : 426905581618618368,
    "created_at" : "2014-01-25 02:33:16 +0000",
    "user" : {
      "name" : "Josiah Bartlet",
      "screen_name" : "Pres_Bartlet",
      "protected" : false,
      "id_str" : "156763824",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1301547141\/jed-bartlet-west-wing_normal.jpg",
      "id" : 156763824,
      "verified" : false
    }
  },
  "id" : 426906507046039552,
  "created_at" : "2014-01-25 02:36:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Memoli",
      "screen_name" : "mikememoli",
      "indices" : [ 3, 14 ],
      "id_str" : "16072058",
      "id" : 16072058
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/pWPBcPbtWb",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2014\/01\/24\/first-ever-virtual-big-block-cheese-day-white-house-open-questions",
      "display_url" : "whitehouse.gov\/blog\/2014\/01\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "426885742078754816",
  "text" : "RT @mikememoli: \"West Wing\" fans' heads explode: The real White House promotes a \"Big Block of Cheese Day\" http:\/\/t.co\/pWPBcPbtWb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/pWPBcPbtWb",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2014\/01\/24\/first-ever-virtual-big-block-cheese-day-white-house-open-questions",
        "display_url" : "whitehouse.gov\/blog\/2014\/01\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "426846513956798464",
    "text" : "\"West Wing\" fans' heads explode: The real White House promotes a \"Big Block of Cheese Day\" http:\/\/t.co\/pWPBcPbtWb",
    "id" : 426846513956798464,
    "created_at" : "2014-01-24 22:38:34 +0000",
    "user" : {
      "name" : "Mike Memoli",
      "screen_name" : "mikememoli",
      "protected" : false,
      "id_str" : "16072058",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2738902089\/07ec9c3352520ee523b4039860abd6ef_normal.jpeg",
      "id" : 16072058,
      "verified" : true
    }
  },
  "id" : 426885742078754816,
  "created_at" : "2014-01-25 01:14:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Storify",
      "screen_name" : "Storify",
      "indices" : [ 3, 11 ],
      "id_str" : "17814938",
      "id" : 17814938
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 64, 75 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "InsideSOTU",
      "indices" : [ 122, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/ixakZXjleB",
      "expanded_url" : "http:\/\/1.usa.gov\/1hQaw5h",
      "display_url" : "1.usa.gov\/1hQaw5h"
    } ]
  },
  "geo" : { },
  "id_str" : "426876568842285056",
  "text" : "RT @Storify: What goes into writing the State of the Union? The @WhiteHouse shares an inside look: http:\/\/t.co\/ixakZXjleB #InsideSOTU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 51, 62 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "InsideSOTU",
        "indices" : [ 109, 120 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/ixakZXjleB",
        "expanded_url" : "http:\/\/1.usa.gov\/1hQaw5h",
        "display_url" : "1.usa.gov\/1hQaw5h"
      } ]
    },
    "geo" : { },
    "id_str" : "426792274903986176",
    "text" : "What goes into writing the State of the Union? The @WhiteHouse shares an inside look: http:\/\/t.co\/ixakZXjleB #InsideSOTU",
    "id" : 426792274903986176,
    "created_at" : "2014-01-24 19:03:02 +0000",
    "user" : {
      "name" : "Storify",
      "screen_name" : "Storify",
      "protected" : false,
      "id_str" : "17814938",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/519538829858852865\/Rw_sIo6T_normal.png",
      "id" : 17814938,
      "verified" : true
    }
  },
  "id" : 426876568842285056,
  "created_at" : "2014-01-25 00:37:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NBC Politics",
      "screen_name" : "NBCPolitics",
      "indices" : [ 3, 15 ],
      "id_str" : "11856032",
      "id" : 11856032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/f7nyuLYOTd",
      "expanded_url" : "http:\/\/nbcnews.to\/1dVWwaR",
      "display_url" : "nbcnews.to\/1dVWwaR"
    } ]
  },
  "geo" : { },
  "id_str" : "426870376048914432",
  "text" : "RT @NBCPolitics: Yes, the White House will hold a 'Big Block of Cheese Day' http:\/\/t.co\/f7nyuLYOTd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.nbcnews.com\" rel=\"nofollow\"\u003ENBCNews Feeds\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 81 ],
        "url" : "http:\/\/t.co\/f7nyuLYOTd",
        "expanded_url" : "http:\/\/nbcnews.to\/1dVWwaR",
        "display_url" : "nbcnews.to\/1dVWwaR"
      } ]
    },
    "geo" : { },
    "id_str" : "426865746115694592",
    "text" : "Yes, the White House will hold a 'Big Block of Cheese Day' http:\/\/t.co\/f7nyuLYOTd",
    "id" : 426865746115694592,
    "created_at" : "2014-01-24 23:54:59 +0000",
    "user" : {
      "name" : "NBC Politics",
      "screen_name" : "NBCPolitics",
      "protected" : false,
      "id_str" : "11856032",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/431136755752787968\/ECUS2IUB_normal.png",
      "id" : 11856032,
      "verified" : true
    }
  },
  "id" : 426870376048914432,
  "created_at" : "2014-01-25 00:13:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "Allison Janney",
      "screen_name" : "AllisonBJanney",
      "indices" : [ 18, 33 ],
      "id_str" : "123015364",
      "id" : 123015364
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/l7yYJunHXF",
      "expanded_url" : "http:\/\/youtu.be\/2JJGDieJ5Tc",
      "display_url" : "youtu.be\/2JJGDieJ5Tc"
    } ]
  },
  "geo" : { },
  "id_str" : "426864842335850496",
  "text" : "RT @PressSec: Hey @AllisonBJanney, It's finally happening: a Big Block of Cheese Day at the White House! http:\/\/t.co\/l7yYJunHXF #BigBlockOf\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Allison Janney",
        "screen_name" : "AllisonBJanney",
        "indices" : [ 4, 19 ],
        "id_str" : "123015364",
        "id" : 123015364
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BigBlockOfCheeseDay",
        "indices" : [ 114, 134 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/l7yYJunHXF",
        "expanded_url" : "http:\/\/youtu.be\/2JJGDieJ5Tc",
        "display_url" : "youtu.be\/2JJGDieJ5Tc"
      } ]
    },
    "geo" : { },
    "id_str" : "426863721697140736",
    "text" : "Hey @AllisonBJanney, It's finally happening: a Big Block of Cheese Day at the White House! http:\/\/t.co\/l7yYJunHXF #BigBlockOfCheeseDay",
    "id" : 426863721697140736,
    "created_at" : "2014-01-24 23:46:56 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 426864842335850496,
  "created_at" : "2014-01-24 23:51:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BigBlockOfCheeseDay",
      "indices" : [ 93, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/RepL9h0taS",
      "expanded_url" : "http:\/\/www.wh.gov\/cheeseday",
      "display_url" : "wh.gov\/cheeseday"
    } ]
  },
  "geo" : { },
  "id_str" : "426854213147451392",
  "text" : "We're paying fromage to President Jackson: Join us next Wednesday for the first-ever virtual #BigBlockOfCheeseDay: http:\/\/t.co\/RepL9h0taS",
  "id" : 426854213147451392,
  "created_at" : "2014-01-24 23:09:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BigBlockOfCheeseDay",
      "indices" : [ 96, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/oLyBOsaNQT",
      "expanded_url" : "http:\/\/wh.gov\/cheeseday",
      "display_url" : "wh.gov\/cheeseday"
    } ]
  },
  "geo" : { },
  "id_str" : "426850542036746240",
  "text" : "It's all gouda guys. The West Wing reunion everyone's been waiting for \u2192 http:\/\/t.co\/oLyBOsaNQT #BigBlockOfCheeseDay",
  "id" : 426850542036746240,
  "created_at" : "2014-01-24 22:54:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 85, 94 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BigBlockOfCheeseDay",
      "indices" : [ 35, 55 ]
    } ],
    "urls" : [ {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/87PKRTYAmG",
      "expanded_url" : "http:\/\/go.wh.gov\/ucw3zJ",
      "display_url" : "go.wh.gov\/ucw3zJ"
    } ]
  },
  "geo" : { },
  "id_str" : "426844664768233472",
  "text" : "We're hosting the 1st-ever virtual #BigBlockOfCheeseDay on Wed! Here's an intro from @PressSec &amp; some familiar faces: http:\/\/t.co\/87PKRTYAmG",
  "id" : 426844664768233472,
  "created_at" : "2014-01-24 22:31:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "Bradley Whitford",
      "screen_name" : "WhitfordBradley",
      "indices" : [ 18, 34 ],
      "id_str" : "892219807",
      "id" : 892219807
    }, {
      "name" : "(((Joshua Malina)))",
      "screen_name" : "JoshMalina",
      "indices" : [ 41, 52 ],
      "id_str" : "24931027",
      "id" : 24931027
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/l7yYJunHXF",
      "expanded_url" : "http:\/\/youtu.be\/2JJGDieJ5Tc",
      "display_url" : "youtu.be\/2JJGDieJ5Tc"
    } ]
  },
  "geo" : { },
  "id_str" : "426843378144514048",
  "text" : "RT @PressSec: Hey @WhitfordBradley &amp; @JoshMalina, think this is the West Wing movie everyone's waiting for?http:\/\/t.co\/l7yYJunHXF  #BigBloc\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bradley Whitford",
        "screen_name" : "WhitfordBradley",
        "indices" : [ 4, 20 ],
        "id_str" : "892219807",
        "id" : 892219807
      }, {
        "name" : "(((Joshua Malina)))",
        "screen_name" : "JoshMalina",
        "indices" : [ 27, 38 ],
        "id_str" : "24931027",
        "id" : 24931027
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BigBlockOfCheeseDay",
        "indices" : [ 121, 141 ]
      } ],
      "urls" : [ {
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/l7yYJunHXF",
        "expanded_url" : "http:\/\/youtu.be\/2JJGDieJ5Tc",
        "display_url" : "youtu.be\/2JJGDieJ5Tc"
      } ]
    },
    "geo" : { },
    "id_str" : "426843346259038208",
    "text" : "Hey @WhitfordBradley &amp; @JoshMalina, think this is the West Wing movie everyone's waiting for?http:\/\/t.co\/l7yYJunHXF  #BigBlockOfCheeseDay",
    "id" : 426843346259038208,
    "created_at" : "2014-01-24 22:25:58 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 426843378144514048,
  "created_at" : "2014-01-24 22:26:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "indices" : [ 44, 54 ],
      "id_str" : "1613223313",
      "id" : 1613223313
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/426818145870172160\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/bbtazdmf0U",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bexc15tIIAA1IFB.jpg",
      "id_str" : "426818145786273792",
      "id" : 426818145786273792,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bexc15tIIAA1IFB.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/bbtazdmf0U"
    } ],
    "hashtags" : [ {
      "text" : "InsideSOTU",
      "indices" : [ 80, 91 ]
    }, {
      "text" : "FoodForThought",
      "indices" : [ 92, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/AksV5WC0yT",
      "expanded_url" : "http:\/\/instagram.com\/p\/jkIA1_Qiqm\/",
      "display_url" : "instagram.com\/p\/jkIA1_Qiqm\/"
    } ]
  },
  "geo" : { },
  "id_str" : "426818145870172160",
  "text" : "Some fuel for the policy-making process via @Cecilia44 \u2192 http:\/\/t.co\/AksV5WC0yT #InsideSOTU #FoodForThought, http:\/\/t.co\/bbtazdmf0U",
  "id" : 426818145870172160,
  "created_at" : "2014-01-24 20:45:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Google",
      "screen_name" : "google",
      "indices" : [ 68, 75 ],
      "id_str" : "20536157",
      "id" : 20536157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/DmoznMosCQ",
      "expanded_url" : "http:\/\/go.wh.gov\/AAX9on",
      "display_url" : "go.wh.gov\/AAX9on"
    } ]
  },
  "geo" : { },
  "id_str" : "426810796661022720",
  "text" : "Get your questions in for President Obama's first-ever Presidential @Google Hangout Road Trip \u2192 http:\/\/t.co\/DmoznMosCQ",
  "id" : 426810796661022720,
  "created_at" : "2014-01-24 20:16:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/426791211806883840\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/tjKkWvO470",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BexEWIWCMAAJrA4.jpg",
      "id_str" : "426791211681067008",
      "id" : 426791211681067008,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BexEWIWCMAAJrA4.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/tjKkWvO470"
    } ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 109, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/Ya6E3mYblS",
      "expanded_url" : "http:\/\/sfy.co\/dYuJ",
      "display_url" : "sfy.co\/dYuJ"
    } ]
  },
  "geo" : { },
  "id_str" : "426791211806883840",
  "text" : "Go behind the scenes with President Obama as he prepares for his State of the Union \u2192 http:\/\/t.co\/Ya6E3mYblS #SOTU, http:\/\/t.co\/tjKkWvO470",
  "id" : 426791211806883840,
  "created_at" : "2014-01-24 18:58:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/426781230407770112\/photo\/1",
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/cwgskWpF7K",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bew7RIoCEAAC2-K.jpg",
      "id_str" : "426781230252560384",
      "id" : 426781230252560384,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bew7RIoCEAAC2-K.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/cwgskWpF7K"
    } ],
    "hashtags" : [ {
      "text" : "RenewUI",
      "indices" : [ 30, 38 ]
    }, {
      "text" : "1million600K",
      "indices" : [ 43, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "426781230407770112",
  "text" : "RT if you agree: It's time to #RenewUI for #1million600K Americans looking for a job. http:\/\/t.co\/cwgskWpF7K",
  "id" : 426781230407770112,
  "created_at" : "2014-01-24 18:19:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/426778292067115008\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/bCTCOCFAE3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bew4mFuCcAEOS8d.jpg",
      "id_str" : "426778291714813953",
      "id" : 426778291714813953,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bew4mFuCcAEOS8d.jpg",
      "sizes" : [ {
        "h" : 532,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 333,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 188,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 532,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/bCTCOCFAE3"
    } ],
    "hashtags" : [ {
      "text" : "1million600K",
      "indices" : [ 13, 26 ]
    }, {
      "text" : "RenewUI",
      "indices" : [ 102, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "426778292067115008",
  "text" : "As of today, #1million600K Americans have lost a vital lifeline because Republicans in Congress won't #RenewUI. http:\/\/t.co\/bCTCOCFAE3",
  "id" : 426778292067115008,
  "created_at" : "2014-01-24 18:07:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/426773089913802754\/photo\/1",
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/0N25Tuvcdu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bewz3TKCEAE9BPz.jpg",
      "id_str" : "426773089821528065",
      "id" : 426773089821528065,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bewz3TKCEAE9BPz.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/0N25Tuvcdu"
    } ],
    "hashtags" : [ {
      "text" : "InsideSOTU",
      "indices" : [ 68, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "426773089913802754",
  "text" : "President Obama works on his State of the Union in the Oval Office. #InsideSOTU, http:\/\/t.co\/0N25Tuvcdu",
  "id" : 426773089913802754,
  "created_at" : "2014-01-24 17:46:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "indices" : [ 1, 11 ],
      "id_str" : "1613223313",
      "id" : 1613223313
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/426757682964742144\/photo\/1",
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/l1EE8C4n4A",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bewl2fpIcAA28x4.jpg",
      "id_str" : "426757682830536704",
      "id" : 426757682830536704,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bewl2fpIcAA28x4.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/l1EE8C4n4A"
    } ],
    "hashtags" : [ {
      "text" : "InsideSOTU",
      "indices" : [ 54, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/pkT6EQGhfw",
      "expanded_url" : "http:\/\/instagram.com\/whitehouse",
      "display_url" : "instagram.com\/whitehouse"
    } ]
  },
  "geo" : { },
  "id_str" : "426757682964742144",
  "text" : ".@Cecilia44 is taking over http:\/\/t.co\/pkT6EQGhfw! Go #InsideSOTU with the White House policy teams. http:\/\/t.co\/l1EE8C4n4A",
  "id" : 426757682964742144,
  "created_at" : "2014-01-24 16:45:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 35, 45 ],
      "id_str" : "18215973",
      "id" : 18215973
    }, {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 90, 101 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/426748461380169728\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/gy5sHUrHk1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BewddukCMAALpcb.jpg",
      "id_str" : "426748461245935616",
      "id" : 426748461245935616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BewddukCMAALpcb.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/gy5sHUrHk1"
    } ],
    "hashtags" : [ {
      "text" : "InsideSOTU",
      "indices" : [ 103, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "426748461380169728",
  "text" : "A look inside the Oval Office from @PeteSouza: President Obama meets with Cody Keenan and @Pfeiffer44. #InsideSOTU, http:\/\/t.co\/gy5sHUrHk1",
  "id" : 426748461380169728,
  "created_at" : "2014-01-24 16:08:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 129, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/KQnNDzzd1O",
      "expanded_url" : "http:\/\/go.wh.gov\/2GbYow",
      "display_url" : "go.wh.gov\/2GbYow"
    } ]
  },
  "geo" : { },
  "id_str" : "426728234093674496",
  "text" : "Here's where you can find everything you need to preview the State of the Union\u2014and watch it on Tuesday \u2192 http:\/\/t.co\/KQnNDzzd1O #SOTU",
  "id" : 426728234093674496,
  "created_at" : "2014-01-24 14:48:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/426550147825549312\/photo\/1",
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/4s08RbqJBd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BetpGWvIgAAiwcv.jpg",
      "id_str" : "426550147620044800",
      "id" : 426550147620044800,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BetpGWvIgAAiwcv.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/4s08RbqJBd"
    } ],
    "hashtags" : [ {
      "text" : "NationalPieDay",
      "indices" : [ 6, 21 ]
    } ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/SyijP8LbeR",
      "expanded_url" : "http:\/\/go.wh.gov\/55NcBE",
      "display_url" : "go.wh.gov\/55NcBE"
    } ]
  },
  "geo" : { },
  "id_str" : "426550147825549312",
  "text" : "Happy #NationalPieDay! http:\/\/t.co\/SyijP8LbeR, http:\/\/t.co\/4s08RbqJBd",
  "id" : 426550147825549312,
  "created_at" : "2014-01-24 03:00:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 12, 17 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 54, 61 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/426527628955115520\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/iBq4KrnpYM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BetUnlpCAAAsHq6.jpg",
      "id_str" : "426527628812484608",
      "id" : 426527628812484608,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BetUnlpCAAAsHq6.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/iBq4KrnpYM"
    } ],
    "hashtags" : [ {
      "text" : "TBT",
      "indices" : [ 2, 6 ]
    }, {
      "text" : "InsideSOTU",
      "indices" : [ 98, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/y5bWZhkoxp",
      "expanded_url" : "http:\/\/instagram.com\/whitehouse",
      "display_url" : "instagram.com\/whitehouse"
    } ]
  },
  "geo" : { },
  "id_str" : "426527628955115520",
  "text" : "A #TBT from @VJ44 with then-State Senator Obama &amp; @FLOTUS circa 2003 \u2192 http:\/\/t.co\/y5bWZhkoxp #InsideSOTU, http:\/\/t.co\/iBq4KrnpYM",
  "id" : 426527628955115520,
  "created_at" : "2014-01-24 01:31:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/9SAXF2o5Jt",
      "expanded_url" : "http:\/\/go.wh.gov\/zRenvd",
      "display_url" : "go.wh.gov\/zRenvd"
    } ]
  },
  "geo" : { },
  "id_str" : "426512315773906945",
  "text" : "\"I welcome today\u2019s signing of a cessation of hostilities agreement in South Sudan.\" \u2014President Obama: http:\/\/t.co\/9SAXF2o5Jt",
  "id" : 426512315773906945,
  "created_at" : "2014-01-24 00:30:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Reliable Source",
      "screen_name" : "reliablesource",
      "indices" : [ 3, 18 ],
      "id_str" : "2174393299",
      "id" : 2174393299
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/niVTvHxECY",
      "expanded_url" : "http:\/\/wapo.st\/1egB5wf",
      "display_url" : "wapo.st\/1egB5wf"
    } ]
  },
  "geo" : { },
  "id_str" : "426506108715679744",
  "text" : "RT @reliablesource: Obama\u2019s speechwriter takes over the official White House Instagram http:\/\/t.co\/niVTvHxECY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/niVTvHxECY",
        "expanded_url" : "http:\/\/wapo.st\/1egB5wf",
        "display_url" : "wapo.st\/1egB5wf"
      } ]
    },
    "geo" : { },
    "id_str" : "426383399952334849",
    "text" : "Obama\u2019s speechwriter takes over the official White House Instagram http:\/\/t.co\/niVTvHxECY",
    "id" : 426383399952334849,
    "created_at" : "2014-01-23 15:58:19 +0000",
    "user" : {
      "name" : "The Reliable Source",
      "screen_name" : "reliablesource",
      "protected" : false,
      "id_str" : "2174393299",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/467380013575049218\/UExwklkr_normal.jpeg",
      "id" : 2174393299,
      "verified" : false
    }
  },
  "id" : 426506108715679744,
  "created_at" : "2014-01-24 00:05:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 107, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/BF96qFfdI1",
      "expanded_url" : "http:\/\/go.wh.gov\/RY7u55",
      "display_url" : "go.wh.gov\/RY7u55"
    } ]
  },
  "geo" : { },
  "id_str" : "426451159466115072",
  "text" : "Here's why millions of Americans are better off thanks to the Affordable Care Act \u2192 http:\/\/t.co\/BF96qFfdI1 #GetCovered",
  "id" : 426451159466115072,
  "created_at" : "2014-01-23 20:27:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "indices" : [ 92, 101 ],
      "id_str" : "249722522",
      "id" : 249722522
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/426429295863820288\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/Z0bQ7iB1Zi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ber7L2VIgAA-mBN.jpg",
      "id_str" : "426429295721218048",
      "id" : 426429295721218048,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ber7L2VIgAA-mBN.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Z0bQ7iB1Zi"
    } ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 36, 41 ]
    }, {
      "text" : "InsideSOTU",
      "indices" : [ 103, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "426429295863820288",
  "text" : "President Obama works on his latest #SOTU draft with his Chief Speechwriter Cody Keenan and @Rhodes44. #InsideSOTU, http:\/\/t.co\/Z0bQ7iB1Zi",
  "id" : 426429295863820288,
  "created_at" : "2014-01-23 19:00:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/426419303614013440\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/jbLGVlUHHC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BeryGOIIIAEBK3L.jpg",
      "id_str" : "426419303425253377",
      "id" : 426419303425253377,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BeryGOIIIAEBK3L.jpg",
      "sizes" : [ {
        "h" : 314,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 535,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 627,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 178,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/jbLGVlUHHC"
    } ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 14, 18 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 101, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "426419303614013440",
  "text" : "Thanks to the #ACA:\nNo more lifetime limits on coverage. \u2714\nInsurers must cover essential benefits. \u2714\n#GetCovered, http:\/\/t.co\/jbLGVlUHHC",
  "id" : 426419303614013440,
  "created_at" : "2014-01-23 18:20:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Team USA ",
      "screen_name" : "USOlympic",
      "indices" : [ 35, 45 ],
      "id_str" : "3061782654",
      "id" : 3061782654
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GoTeamUSA",
      "indices" : [ 72, 82 ]
    }, {
      "text" : "BringHomeTheGold",
      "indices" : [ 83, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "426410766439575552",
  "text" : "To all the amazing athletes on the @USOlympic Team, good luck in Sochi! #GoTeamUSA #BringHomeTheGold",
  "id" : 426410766439575552,
  "created_at" : "2014-01-23 17:47:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/426403948228911105\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/SPVDKaHm5g",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BerkIa3CMAELT9Z.jpg",
      "id_str" : "426403948040171521",
      "id" : 426403948040171521,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BerkIa3CMAELT9Z.jpg",
      "sizes" : [ {
        "h" : 535,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 627,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 178,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 314,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/SPVDKaHm5g"
    } ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 14, 18 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 95, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "426403948228911105",
  "text" : "Thanks to the #ACA:\nYou can't be charged more\nor denied coverage\nfor a pre-existing condition.\n#GetCovered, http:\/\/t.co\/SPVDKaHm5g",
  "id" : 426403948228911105,
  "created_at" : "2014-01-23 17:19:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 23, 28 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Instagram",
      "screen_name" : "instagram",
      "indices" : [ 51, 61 ],
      "id_str" : "180505807",
      "id" : 180505807
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/426394010329313280\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/XoXRPQF8yP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BerbF9zIAAAHbH6.jpg",
      "id_str" : "426394010274758656",
      "id" : 426394010274758656,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BerbF9zIAAAHbH6.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/XoXRPQF8yP"
    } ],
    "hashtags" : [ {
      "text" : "InsideSOTU",
      "indices" : [ 106, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/pkT6EQGhfw",
      "expanded_url" : "http:\/\/instagram.com\/whitehouse",
      "display_url" : "instagram.com\/whitehouse"
    } ]
  },
  "geo" : { },
  "id_str" : "426394010329313280",
  "text" : "Obama's Senior Advisor @VJ44 is taking over the WH @Instagram today. Follow along: http:\/\/t.co\/pkT6EQGhfw #InsideSOTU http:\/\/t.co\/XoXRPQF8yP",
  "id" : 426394010329313280,
  "created_at" : "2014-01-23 16:40:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Team USA ",
      "screen_name" : "USOlympic",
      "indices" : [ 35, 45 ],
      "id_str" : "3061782654",
      "id" : 3061782654
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GoTeamUSA",
      "indices" : [ 71, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "426386007320436737",
  "text" : "RT @FLOTUS: Join me in wishing the @USOlympic Team good luck in Sochi! #GoTeamUSA \u2014 we're rooting for you! \u2013mo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Team USA ",
        "screen_name" : "USOlympic",
        "indices" : [ 23, 33 ],
        "id_str" : "3061782654",
        "id" : 3061782654
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GoTeamUSA",
        "indices" : [ 59, 69 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "426384546595360768",
    "text" : "Join me in wishing the @USOlympic Team good luck in Sochi! #GoTeamUSA \u2014 we're rooting for you! \u2013mo",
    "id" : 426384546595360768,
    "created_at" : "2014-01-23 16:02:52 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 426386007320436737,
  "created_at" : "2014-01-23 16:08:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Google",
      "screen_name" : "google",
      "indices" : [ 64, 71 ],
      "id_str" : "20536157",
      "id" : 20536157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/ljJWE2t8LD",
      "expanded_url" : "http:\/\/go.wh.gov\/qFq3v4",
      "display_url" : "go.wh.gov\/qFq3v4"
    } ]
  },
  "geo" : { },
  "id_str" : "426379899176488960",
  "text" : "Hit the road with President Obama for the 1st-ever Presidential @Google Hangout Road Trip. Submit your questions now: http:\/\/t.co\/ljJWE2t8LD",
  "id" : 426379899176488960,
  "created_at" : "2014-01-23 15:44:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/426188247979401216\/photo\/1",
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/rZKgrc46xF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Beof9BMCEAALxJU.jpg",
      "id_str" : "426188247891316736",
      "id" : 426188247891316736,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Beof9BMCEAALxJU.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/rZKgrc46xF"
    } ],
    "hashtags" : [ {
      "text" : "InsideSOTU",
      "indices" : [ 82, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "426188247979401216",
  "text" : "Here's the latest State of the Union draft for President Obama to review tonight. #InsideSOTU, http:\/\/t.co\/rZKgrc46xF",
  "id" : 426188247979401216,
  "created_at" : "2014-01-23 03:02:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/426178355969286144\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/F5PM06Jpw9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BeoW9OZCYAAPuXp.jpg",
      "id_str" : "426178355830874112",
      "id" : 426178355830874112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BeoW9OZCYAAPuXp.jpg",
      "sizes" : [ {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/F5PM06Jpw9"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/Y2PhO1YJog",
      "expanded_url" : "http:\/\/go.wh.gov\/4qaogB",
      "display_url" : "go.wh.gov\/4qaogB"
    } ]
  },
  "geo" : { },
  "id_str" : "426178355969286144",
  "text" : "\"Anyone out there who has ever been assaulted: You are not alone...we have your back\" \u2014Obama: http:\/\/t.co\/Y2PhO1YJog http:\/\/t.co\/F5PM06Jpw9",
  "id" : 426178355969286144,
  "created_at" : "2014-01-23 02:23:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Instagram",
      "screen_name" : "instagram",
      "indices" : [ 21, 31 ],
      "id_str" : "180505807",
      "id" : 180505807
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/426148629917597696\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/2ralEilqcU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ben768aCEAACqwq.jpg",
      "id_str" : "426148629829521408",
      "id" : 426148629829521408,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ben768aCEAACqwq.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/2ralEilqcU"
    } ],
    "hashtags" : [ {
      "text" : "SpoilerAlert",
      "indices" : [ 101, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "426148629917597696",
  "text" : "Cody Keenan's latest @Instagram: President Obama's notes on the 1st draft of the State of the Union. #SpoilerAlert, http:\/\/t.co\/2ralEilqcU",
  "id" : 426148629917597696,
  "created_at" : "2014-01-23 00:25:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/426125688215572480\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/9YAAjSUsbz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BennDj2CIAElDy8.jpg",
      "id_str" : "426125688110718977",
      "id" : 426125688110718977,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BennDj2CIAElDy8.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/9YAAjSUsbz"
    } ],
    "hashtags" : [ {
      "text" : "InsideSOTU",
      "indices" : [ 97, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "426125688215572480",
  "text" : "Chief Speechwriter Cody Keenan's desk: Coffee, binders, and the latest State of the Union draft. #InsideSOTU, http:\/\/t.co\/9YAAjSUsbz",
  "id" : 426125688215572480,
  "created_at" : "2014-01-22 22:54:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 57, 68 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/426103369510289408\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/PS5Hb7X5ng",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BenSwcCCIAAgYiz.jpg",
      "id_str" : "426103369363496960",
      "id" : 426103369363496960,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BenSwcCCIAAgYiz.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1050
      } ],
      "display_url" : "pic.twitter.com\/PS5Hb7X5ng"
    } ],
    "hashtags" : [ {
      "text" : "InsideSOTU",
      "indices" : [ 38, 49 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/0XGeYlaAW4",
      "expanded_url" : "http:\/\/instagram.com\/p\/jfFJtfwik6\/",
      "display_url" : "instagram.com\/p\/jfFJtfwik6\/"
    } ]
  },
  "geo" : { },
  "id_str" : "426103369510289408",
  "text" : "WH Speechwriter Cody Keenan takes you #InsideSOTU on the @WhiteHouse Instagram. Follow along: http:\/\/t.co\/0XGeYlaAW4 http:\/\/t.co\/PS5Hb7X5ng",
  "id" : 426103369510289408,
  "created_at" : "2014-01-22 21:25:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1Is2Many",
      "indices" : [ 116, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/ldUqghbChU",
      "expanded_url" : "http:\/\/go.wh.gov\/i3xP9B",
      "display_url" : "go.wh.gov\/i3xP9B"
    } ]
  },
  "geo" : { },
  "id_str" : "426080880168534016",
  "text" : "Let's keep working to prevent sexual assault. Read today's report on how all of us can help: http:\/\/t.co\/ldUqghbChU #1Is2Many",
  "id" : 426080880168534016,
  "created_at" : "2014-01-22 19:56:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "426072622884200448",
  "text" : "Obama on preventing assault: \"This is a priority for me\u2014not only as President...but as a husband and father to two extraordinary girls.\"",
  "id" : 426072622884200448,
  "created_at" : "2014-01-22 19:23:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1Is2Many",
      "indices" : [ 124, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "426072143689162752",
  "text" : "Obama: \"We need to keep saying to anyone out there who has ever been assaulted\u2014you are not alone. You will never be alone.\" #1Is2Many",
  "id" : 426072143689162752,
  "created_at" : "2014-01-22 19:21:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "426071819788255232",
  "text" : "Obama: \"We need to keep teaching young men to show women the respect they deserve, to recognize sexual violence and be outraged by it.\"",
  "id" : 426071819788255232,
  "created_at" : "2014-01-22 19:20:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 76, 87 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "426071469937147904",
  "text" : "RT @WHLive: Obama: \"Today, I\u2019ll sign a presidential memorandum creating the @WhiteHouse Task Force to Protect Students from Sexual Assault.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 64, 75 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "1Is2Many",
        "indices" : [ 129, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "426071243230822400",
    "text" : "Obama: \"Today, I\u2019ll sign a presidential memorandum creating the @WhiteHouse Task Force to Protect Students from Sexual Assault.\" #1Is2Many",
    "id" : 426071243230822400,
    "created_at" : "2014-01-22 19:17:55 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 426071469937147904,
  "created_at" : "2014-01-22 19:18:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "426070989269917697",
  "text" : "\"No matter who you are or where you live, everyone in our country deserves security, justice &amp; dignity.\" \u2014Obama on preventing sexual assault",
  "id" : 426070989269917697,
  "created_at" : "2014-01-22 19:16:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VAWA",
      "indices" : [ 55, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "426070764413272064",
  "text" : "Obama: \"I was proud to sign the reauthorization of the #VAWA\u2014which improved the support we give cities &amp; states to help end sexual assault.\"",
  "id" : 426070764413272064,
  "created_at" : "2014-01-22 19:16:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1Is2Many",
      "indices" : [ 125, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "426070396291788803",
  "text" : "Obama: \"We have the capacity to stop sexual assault, support those who have survived it, and bring perpetrators to justice.\" #1Is2Many",
  "id" : 426070396291788803,
  "created_at" : "2014-01-22 19:14:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "426070168150999040",
  "text" : "Obama: \"Sexual violence is more than just a crime against individuals. It threatens our families, our communities &amp; ultimately our country.\"",
  "id" : 426070168150999040,
  "created_at" : "2014-01-22 19:13:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1Is2Many",
      "indices" : [ 83, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "426069683167850496",
  "text" : "President Obama: \"Sexual assault is an affront to our basic decency and humanity.\" #1Is2Many",
  "id" : 426069683167850496,
  "created_at" : "2014-01-22 19:11:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 31, 34 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/98kllYLiNB",
      "expanded_url" : "http:\/\/go.wh.gov\/A8Y9ie",
      "display_url" : "go.wh.gov\/A8Y9ie"
    } ]
  },
  "geo" : { },
  "id_str" : "426068580254629888",
  "text" : "Right now: President Obama and @VP Biden speak at an event for the Council on Women and Girls. Watch \u2192 http:\/\/t.co\/98kllYLiNB",
  "id" : 426068580254629888,
  "created_at" : "2014-01-22 19:07:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "426056992630009856",
  "text" : "RT @Simas44: Here's where you can find everything you need to preview the State of the Union\u2014and watch it next Tuesday \u2192 http:\/\/t.co\/qjCgoD\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SOTU",
        "indices" : [ 131, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/qjCgoDXstP",
        "expanded_url" : "http:\/\/go.wh.gov\/qJhdtS",
        "display_url" : "go.wh.gov\/qJhdtS"
      } ]
    },
    "geo" : { },
    "id_str" : "426024985384058880",
    "text" : "Here's where you can find everything you need to preview the State of the Union\u2014and watch it next Tuesday \u2192 http:\/\/t.co\/qjCgoDXstP #SOTU",
    "id" : 426024985384058880,
    "created_at" : "2014-01-22 16:14:06 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 426056992630009856,
  "created_at" : "2014-01-22 18:21:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/7v2Zsxfx4U",
      "expanded_url" : "http:\/\/go.wh.gov\/4fyLCX",
      "display_url" : "go.wh.gov\/4fyLCX"
    } ]
  },
  "geo" : { },
  "id_str" : "426046765985329154",
  "text" : "\"We reaffirm our steadfast commitment to protecting a woman\u2019s access to safe, affordable health care.\" \u2014Obama: http:\/\/t.co\/7v2Zsxfx4U",
  "id" : 426046765985329154,
  "created_at" : "2014-01-22 17:40:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "426038977280630784",
  "text" : "\"Every woman should be able to make her own choices about her body and her health.\" \u2014President Obama on the 41st anniversary of Roe v. Wade",
  "id" : 426038977280630784,
  "created_at" : "2014-01-22 17:09:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 112, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/Rt522TdIpp",
      "expanded_url" : "http:\/\/go.wh.gov\/9paRRR",
      "display_url" : "go.wh.gov\/9paRRR"
    } ]
  },
  "geo" : { },
  "id_str" : "426007596479561728",
  "text" : "Go behind the scenes as President Obama prepares for next Tuesday's State of the Union \u2192 http:\/\/t.co\/Rt522TdIpp #SOTU",
  "id" : 426007596479561728,
  "created_at" : "2014-01-22 15:05:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/425795705756991488\/photo\/1",
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/SGh24H7thG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bei68DSIcAEzq-t.jpg",
      "id_str" : "425795705622786049",
      "id" : 425795705622786049,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bei68DSIcAEzq-t.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1023
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1023
      } ],
      "display_url" : "pic.twitter.com\/SGh24H7thG"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "425795705756991488",
  "text" : "President Obama with his Chief of Staff along the snowy White House Colonnade. http:\/\/t.co\/SGh24H7thG",
  "id" : 425795705756991488,
  "created_at" : "2014-01-22 01:03:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/425783183720726529\/photo\/1",
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/KLAGj3L0EY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BeivjLECAAAOy6q.jpg",
      "id_str" : "425783183586492416",
      "id" : 425783183586492416,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BeivjLECAAAOy6q.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/KLAGj3L0EY"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "425783183720726529",
  "text" : "The Oval Office in the snow. http:\/\/t.co\/KLAGj3L0EY",
  "id" : 425783183720726529,
  "created_at" : "2014-01-22 00:13:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "indices" : [ 84, 92 ],
      "id_str" : "807095",
      "id" : 807095
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 117, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/KYSqnICRZR",
      "expanded_url" : "http:\/\/nyti.ms\/1cNhDWB",
      "display_url" : "nyti.ms\/1cNhDWB"
    } ]
  },
  "geo" : { },
  "id_str" : "425713186260541440",
  "text" : "The Affordable Care Act's \"Expanded Medicaid Coverage Brings a Surge in Sign-Ups.\" \u2014@NYTimes: http:\/\/t.co\/KYSqnICRZR #GetCovered",
  "id" : 425713186260541440,
  "created_at" : "2014-01-21 19:35:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 47, 54 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "LeBron James",
      "screen_name" : "KingJames",
      "indices" : [ 64, 74 ],
      "id_str" : "23083404",
      "id" : 23083404
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LetsMove",
      "indices" : [ 107, 116 ]
    }, {
      "text" : "ThrowItDownFLOTUS",
      "indices" : [ 117, 135 ]
    }, {
      "text" : "GIF",
      "indices" : [ 136, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/KuCykzD5sf",
      "expanded_url" : "http:\/\/tmblr.co\/ZW21es14-FnZw",
      "display_url" : "tmblr.co\/ZW21es14-FnZw"
    } ]
  },
  "geo" : { },
  "id_str" : "425697821300649984",
  "text" : "In the name of all that is eating healthy, Air @FLOTUS dunks on @KingJames. Watch \u2192 http:\/\/t.co\/KuCykzD5sf #LetsMove #ThrowItDownFLOTUS #GIF",
  "id" : 425697821300649984,
  "created_at" : "2014-01-21 18:34:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "425686923186020352",
  "text" : "RT @pfeiffer44: Excited for next week's State of the Union? Here's Chief of Staff Denis McDonough on how you can get involved \u2192 http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SOTU",
        "indices" : [ 135, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/5LFjPtslZq",
        "expanded_url" : "http:\/\/go.wh.gov\/aueiCx",
        "display_url" : "go.wh.gov\/aueiCx"
      } ]
    },
    "geo" : { },
    "id_str" : "425679213287337984",
    "text" : "Excited for next week's State of the Union? Here's Chief of Staff Denis McDonough on how you can get involved \u2192 http:\/\/t.co\/5LFjPtslZq #SOTU",
    "id" : 425679213287337984,
    "created_at" : "2014-01-21 17:20:07 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 425686923186020352,
  "created_at" : "2014-01-21 17:50:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 135, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/ug2ePcyMdF",
      "expanded_url" : "http:\/\/go.wh.gov\/V8Z4ok",
      "display_url" : "go.wh.gov\/V8Z4ok"
    } ]
  },
  "geo" : { },
  "id_str" : "425669556406075392",
  "text" : "Be a part of next week's State of the Union: WH Chief of Staff Denis McDonough shares how you can get involved. http:\/\/t.co\/ug2ePcyMdF #SOTU",
  "id" : 425669556406075392,
  "created_at" : "2014-01-21 16:41:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 104, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/FxtnPCk77x",
      "expanded_url" : "http:\/\/nyti.ms\/1cNhDWB",
      "display_url" : "nyti.ms\/1cNhDWB"
    } ]
  },
  "geo" : { },
  "id_str" : "425655838028861441",
  "text" : "FACT: Thanks to the Affordable Care Act, about one-third of West Virginia's uninsured have been able to #GetCovered \u2192 http:\/\/t.co\/FxtnPCk77x",
  "id" : 425655838028861441,
  "created_at" : "2014-01-21 15:47:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 5, 14 ],
      "id_str" : "36719281",
      "id" : 36719281
    }, {
      "name" : "LeBron James",
      "screen_name" : "KingJames",
      "indices" : [ 34, 44 ],
      "id_str" : "23083404",
      "id" : 23083404
    }, {
      "name" : "Dwayne (not Dwyane)",
      "screen_name" : "DwayneWade",
      "indices" : [ 48, 59 ],
      "id_str" : "317388371",
      "id" : 317388371
    }, {
      "name" : "Chris Bosh",
      "screen_name" : "chrisbosh",
      "indices" : [ 63, 73 ],
      "id_str" : "16125042",
      "id" : 16125042
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 99, 106 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/YgpMO1si9L",
      "expanded_url" : "http:\/\/go.wh.gov\/oomejp",
      "display_url" : "go.wh.gov\/oomejp"
    } ]
  },
  "geo" : { },
  "id_str" : "425642499278118912",
  "text" : "Your @LetsMove Healthy Eaters:\n1. @KingJames\n2. @DwayneWade\n3. @ChrisBosh\n4. Ray Allen\n5. \u2026and Air @FLOTUS!\nWatch \u2192 http:\/\/t.co\/YgpMO1si9L",
  "id" : 425642499278118912,
  "created_at" : "2014-01-21 14:54:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 51, 58 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "LeBron James",
      "screen_name" : "KingJames",
      "indices" : [ 67, 77 ],
      "id_str" : "23083404",
      "id" : 23083404
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LetsMove",
      "indices" : [ 103, 112 ]
    }, {
      "text" : "DrinkH2O",
      "indices" : [ 113, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/1TNQczREnb",
      "expanded_url" : "http:\/\/go.wh.gov\/Qa5t3P",
      "display_url" : "go.wh.gov\/Qa5t3P"
    } ]
  },
  "geo" : { },
  "id_str" : "425631628246147072",
  "text" : "RT @FLOTUS: You don't want to miss this: Watch Air @FLOTUS dunk on @KingJames \u2192 http:\/\/t.co\/1TNQczREnb #LetsMove #DrinkH2O",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The First Lady",
        "screen_name" : "FLOTUS",
        "indices" : [ 39, 46 ],
        "id_str" : "1093090866",
        "id" : 1093090866
      }, {
        "name" : "LeBron James",
        "screen_name" : "KingJames",
        "indices" : [ 55, 65 ],
        "id_str" : "23083404",
        "id" : 23083404
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LetsMove",
        "indices" : [ 91, 100 ]
      }, {
        "text" : "DrinkH2O",
        "indices" : [ 101, 110 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/1TNQczREnb",
        "expanded_url" : "http:\/\/go.wh.gov\/Qa5t3P",
        "display_url" : "go.wh.gov\/Qa5t3P"
      } ]
    },
    "geo" : { },
    "id_str" : "425630443309113344",
    "text" : "You don't want to miss this: Watch Air @FLOTUS dunk on @KingJames \u2192 http:\/\/t.co\/1TNQczREnb #LetsMove #DrinkH2O",
    "id" : 425630443309113344,
    "created_at" : "2014-01-21 14:06:20 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 425631628246147072,
  "created_at" : "2014-01-21 14:11:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DC Central Kitchen",
      "screen_name" : "dcck",
      "indices" : [ 52, 57 ],
      "id_str" : "14141269",
      "id" : 14141269
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/425402315000913921\/photo\/1",
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/5HDgBJgqAr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BedVJsmCMAAFuer.jpg",
      "id_str" : "425402314887671808",
      "id" : 425402314887671808,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BedVJsmCMAAFuer.jpg",
      "sizes" : [ {
        "h" : 703,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 703,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 412,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 233,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/5HDgBJgqAr"
    } ],
    "hashtags" : [ {
      "text" : "MLKDay",
      "indices" : [ 73, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "425402315000913921",
  "text" : "The Obamas prepared meals for local shelters at the @DCCK as part of the #MLKDay of Service. http:\/\/t.co\/5HDgBJgqAr",
  "id" : 425402315000913921,
  "created_at" : "2014-01-20 22:59:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    }, {
      "name" : "US Dept of Education",
      "screen_name" : "usedgov",
      "indices" : [ 78, 86 ],
      "id_str" : "20437286",
      "id" : 20437286
    }, {
      "name" : "CityYear",
      "screen_name" : "CityYear",
      "indices" : [ 127, 136 ],
      "id_str" : "15758330",
      "id" : 15758330
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MLKDay",
      "indices" : [ 31, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "425377451800145920",
  "text" : "RT @arneduncan: Happy to spend #MLKDay of Service at a DC HS w\/my family, the @usedgov team &amp; the great young leaders from @CityYear http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "US Dept of Education",
        "screen_name" : "usedgov",
        "indices" : [ 62, 70 ],
        "id_str" : "20437286",
        "id" : 20437286
      }, {
        "name" : "CityYear",
        "screen_name" : "CityYear",
        "indices" : [ 111, 120 ],
        "id_str" : "15758330",
        "id" : 15758330
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/arneduncan\/status\/425366722498293760\/photo\/1",
        "indices" : [ 121, 143 ],
        "url" : "http:\/\/t.co\/zqccs3N1WS",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bec0x7hIgAAgzSU.jpg",
        "id_str" : "425366722204696576",
        "id" : 425366722204696576,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bec0x7hIgAAgzSU.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/zqccs3N1WS"
      } ],
      "hashtags" : [ {
        "text" : "MLKDay",
        "indices" : [ 15, 22 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "425366722498293760",
    "text" : "Happy to spend #MLKDay of Service at a DC HS w\/my family, the @usedgov team &amp; the great young leaders from @CityYear http:\/\/t.co\/zqccs3N1WS",
    "id" : 425366722498293760,
    "created_at" : "2014-01-20 20:38:24 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 425377451800145920,
  "created_at" : "2014-01-20 21:21:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MLKDay",
      "indices" : [ 132, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "425372593504649218",
  "text" : "RT @vj44: In honor of Dr. King, we ask Americans to come together for a day of service. What will you do to serve your community on #MLKDay?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MLKDay",
        "indices" : [ 122, 129 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "425318712602677248",
    "text" : "In honor of Dr. King, we ask Americans to come together for a day of service. What will you do to serve your community on #MLKDay?",
    "id" : 425318712602677248,
    "created_at" : "2014-01-20 17:27:37 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 425372593504649218,
  "created_at" : "2014-01-20 21:01:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peace Corps",
      "screen_name" : "PeaceCorps",
      "indices" : [ 3, 14 ],
      "id_str" : "9109712",
      "id" : 9109712
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "volunteering",
      "indices" : [ 104, 117 ]
    }, {
      "text" : "publicservice",
      "indices" : [ 118, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "425345365316235264",
  "text" : "RT @PeaceCorps: \"Life's most persistent and urgent question is: 'What are you doing for others?'\" - MLK #volunteering #publicservice",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "volunteering",
        "indices" : [ 88, 101 ]
      }, {
        "text" : "publicservice",
        "indices" : [ 102, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "425334952335781888",
    "text" : "\"Life's most persistent and urgent question is: 'What are you doing for others?'\" - MLK #volunteering #publicservice",
    "id" : 425334952335781888,
    "created_at" : "2014-01-20 18:32:09 +0000",
    "user" : {
      "name" : "Peace Corps",
      "screen_name" : "PeaceCorps",
      "protected" : false,
      "id_str" : "9109712",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/737985331815841793\/YS-240sx_normal.jpg",
      "id" : 9109712,
      "verified" : true
    }
  },
  "id" : 425345365316235264,
  "created_at" : "2014-01-20 19:13:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/VP\/status\/425329322463727616\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/T5gXxF490X",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BecSw-pCEAAilp-.jpg",
      "id_str" : "425329322467921920",
      "id" : 425329322467921920,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BecSw-pCEAAilp-.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 667,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 667,
        "resize" : "fit",
        "w" : 1000
      } ],
      "display_url" : "pic.twitter.com\/T5gXxF490X"
    } ],
    "hashtags" : [ {
      "text" : "MLKday",
      "indices" : [ 81, 88 ]
    }, {
      "text" : "NatlDayofService",
      "indices" : [ 89, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "425339654703828992",
  "text" : "RT @VP: PHOTO: VP serves lunch at SOME (So Others Might Eat) in Washington, D.C. #MLKday #NatlDayofService http:\/\/t.co\/T5gXxF490X",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/425329322463727616\/photo\/1",
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/T5gXxF490X",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BecSw-pCEAAilp-.jpg",
        "id_str" : "425329322467921920",
        "id" : 425329322467921920,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BecSw-pCEAAilp-.jpg",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        } ],
        "display_url" : "pic.twitter.com\/T5gXxF490X"
      } ],
      "hashtags" : [ {
        "text" : "MLKday",
        "indices" : [ 73, 80 ]
      }, {
        "text" : "NatlDayofService",
        "indices" : [ 81, 98 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "425329322463727616",
    "text" : "PHOTO: VP serves lunch at SOME (So Others Might Eat) in Washington, D.C. #MLKday #NatlDayofService http:\/\/t.co\/T5gXxF490X",
    "id" : 425329322463727616,
    "created_at" : "2014-01-20 18:09:47 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 425339654703828992,
  "created_at" : "2014-01-20 18:50:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CommerceSec",
      "screen_name" : "CommerceSec",
      "indices" : [ 3, 15 ],
      "id_str" : "2319148561",
      "id" : 2319148561
    }, {
      "name" : "Food & Friends",
      "screen_name" : "foodandfriends",
      "indices" : [ 49, 64 ],
      "id_str" : "60956491",
      "id" : 60956491
    }, {
      "name" : "U.S. Commerce Dept.",
      "screen_name" : "CommerceGov",
      "indices" : [ 70, 82 ],
      "id_str" : "110541296",
      "id" : 110541296
    }, {
      "name" : "CNCS",
      "screen_name" : "NationalService",
      "indices" : [ 83, 99 ],
      "id_str" : "17961886",
      "id" : 17961886
    }, {
      "name" : "Wendy Spencer",
      "screen_name" : "WendyCNCS",
      "indices" : [ 100, 110 ],
      "id_str" : "29519977",
      "id" : 29519977
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MLKDay",
      "indices" : [ 17, 24 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/y1GjRjWUmO",
      "expanded_url" : "http:\/\/ow.ly\/i\/4lcGG",
      "display_url" : "ow.ly\/i\/4lcGG"
    } ]
  },
  "geo" : { },
  "id_str" : "425337272725413888",
  "text" : "RT @CommerceSec: #MLKDay of Service volunteering @FoodandFriends with @Commercegov @nationalservice @WendyCNCS http:\/\/t.co\/y1GjRjWUmO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Food & Friends",
        "screen_name" : "foodandfriends",
        "indices" : [ 32, 47 ],
        "id_str" : "60956491",
        "id" : 60956491
      }, {
        "name" : "U.S. Commerce Dept.",
        "screen_name" : "CommerceGov",
        "indices" : [ 53, 65 ],
        "id_str" : "110541296",
        "id" : 110541296
      }, {
        "name" : "CNCS",
        "screen_name" : "NationalService",
        "indices" : [ 66, 82 ],
        "id_str" : "17961886",
        "id" : 17961886
      }, {
        "name" : "Wendy Spencer",
        "screen_name" : "WendyCNCS",
        "indices" : [ 83, 93 ],
        "id_str" : "29519977",
        "id" : 29519977
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MLKDay",
        "indices" : [ 0, 7 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/y1GjRjWUmO",
        "expanded_url" : "http:\/\/ow.ly\/i\/4lcGG",
        "display_url" : "ow.ly\/i\/4lcGG"
      } ]
    },
    "geo" : { },
    "id_str" : "425294106383101952",
    "text" : "#MLKDay of Service volunteering @FoodandFriends with @Commercegov @nationalservice @WendyCNCS http:\/\/t.co\/y1GjRjWUmO",
    "id" : 425294106383101952,
    "created_at" : "2014-01-20 15:49:51 +0000",
    "user" : {
      "name" : "Penny Pritzker",
      "screen_name" : "PennyPritzker",
      "protected" : false,
      "id_str" : "308573576",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000260306047\/1faea5d057983d2f15a31efc6b696ab5_normal.jpeg",
      "id" : 308573576,
      "verified" : true
    }
  },
  "id" : 425337272725413888,
  "created_at" : "2014-01-20 18:41:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/425296808865452032\/photo\/1",
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/zfGyj5nxF8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Beb1MbHIgAABaSM.jpg",
      "id_str" : "425296808618000384",
      "id" : 425296808618000384,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Beb1MbHIgAABaSM.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/zfGyj5nxF8"
    } ],
    "hashtags" : [ {
      "text" : "MLK",
      "indices" : [ 80, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "425323340572930048",
  "text" : "RT @Interior: Today we honor the life and legacy of Dr. Martin Luther King, Jr. #MLK http:\/\/t.co\/zfGyj5nxF8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/425296808865452032\/photo\/1",
        "indices" : [ 71, 93 ],
        "url" : "http:\/\/t.co\/zfGyj5nxF8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Beb1MbHIgAABaSM.jpg",
        "id_str" : "425296808618000384",
        "id" : 425296808618000384,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Beb1MbHIgAABaSM.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/zfGyj5nxF8"
      } ],
      "hashtags" : [ {
        "text" : "MLK",
        "indices" : [ 66, 70 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "425296808865452032",
    "text" : "Today we honor the life and legacy of Dr. Martin Luther King, Jr. #MLK http:\/\/t.co\/zfGyj5nxF8",
    "id" : 425296808865452032,
    "created_at" : "2014-01-20 16:00:35 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 425323340572930048,
  "created_at" : "2014-01-20 17:46:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ISS",
      "indices" : [ 80, 84 ]
    }, {
      "text" : "MLK",
      "indices" : [ 107, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "425319283883663360",
  "text" : "RT @NASA: Today we honor Martin Luther King Jr, who inspired us to dream, w\/ an #ISS pic of Atlanta, where #MLK was born. http:\/\/t.co\/JZwzK\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.exacttarget.com\/social\" rel=\"nofollow\"\u003ESocialEngage\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/NASA\/status\/425315637359947776\/photo\/1",
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/JZwzKlaVUi",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BecGUY9CMAExeid.jpg",
        "id_str" : "425315637175398401",
        "id" : 425315637175398401,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BecGUY9CMAExeid.jpg",
        "sizes" : [ {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 465,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 465,
          "resize" : "fit",
          "w" : 700
        } ],
        "display_url" : "pic.twitter.com\/JZwzKlaVUi"
      } ],
      "hashtags" : [ {
        "text" : "ISS",
        "indices" : [ 70, 74 ]
      }, {
        "text" : "MLK",
        "indices" : [ 97, 101 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "425315637359947776",
    "text" : "Today we honor Martin Luther King Jr, who inspired us to dream, w\/ an #ISS pic of Atlanta, where #MLK was born. http:\/\/t.co\/JZwzKlaVUi",
    "id" : 425315637359947776,
    "created_at" : "2014-01-20 17:15:24 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 425319283883663360,
  "created_at" : "2014-01-20 17:29:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MLKDay",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "425303010022277120",
  "text" : "\"Let us put aside our narrow ambitions, lift up one another, and march a little closer to the nation Dr. King envisioned.\u201D \u2014Obama on #MLKDay",
  "id" : 425303010022277120,
  "created_at" : "2014-01-20 16:25:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alicia Keys",
      "screen_name" : "aliciakeys",
      "indices" : [ 3, 14 ],
      "id_str" : "35094637",
      "id" : 35094637
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 25, 29 ]
    }, {
      "text" : "HIV",
      "indices" : [ 103, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/PgBQEuKPdQ",
      "expanded_url" : "http:\/\/bit.ly\/1i5el8W",
      "display_url" : "bit.ly\/1i5el8W"
    } ]
  },
  "geo" : { },
  "id_str" : "425298457143050240",
  "text" : "RT @aliciakeys: FYI: The #ACA makes health insurance easier to get &amp; more affordable for many with #HIV. Learn more: http:\/\/t.co\/PgBQEuKPdQ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ACA",
        "indices" : [ 9, 13 ]
      }, {
        "text" : "HIV",
        "indices" : [ 87, 91 ]
      }, {
        "text" : "WeAreEMPOWERED",
        "indices" : [ 128, 143 ]
      } ],
      "urls" : [ {
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/PgBQEuKPdQ",
        "expanded_url" : "http:\/\/bit.ly\/1i5el8W",
        "display_url" : "bit.ly\/1i5el8W"
      } ]
    },
    "geo" : { },
    "id_str" : "425075345985769472",
    "text" : "FYI: The #ACA makes health insurance easier to get &amp; more affordable for many with #HIV. Learn more: http:\/\/t.co\/PgBQEuKPdQ #WeAreEMPOWERED",
    "id" : 425075345985769472,
    "created_at" : "2014-01-20 01:20:34 +0000",
    "user" : {
      "name" : "Alicia Keys",
      "screen_name" : "aliciakeys",
      "protected" : false,
      "id_str" : "35094637",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/784235369906614272\/IyyZ25fR_normal.jpg",
      "id" : 35094637,
      "verified" : true
    }
  },
  "id" : 425298457143050240,
  "created_at" : "2014-01-20 16:07:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LeBron James",
      "screen_name" : "KingJames",
      "indices" : [ 1, 11 ],
      "id_str" : "23083404",
      "id" : 23083404
    }, {
      "name" : "DWade",
      "screen_name" : "DwyaneWade",
      "indices" : [ 16, 27 ],
      "id_str" : "33995409",
      "id" : 33995409
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WestWingWeek",
      "indices" : [ 37, 50 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/LyfdkvDG8U",
      "expanded_url" : "http:\/\/go.wh.gov\/N4PRUM",
      "display_url" : "go.wh.gov\/N4PRUM"
    } ]
  },
  "geo" : { },
  "id_str" : "425085416601964546",
  "text" : ".@KingJames and @DwyaneWade kick off #WestWingWeek in style. Here's your recap of this week at the White House \u2192 http:\/\/t.co\/LyfdkvDG8U",
  "id" : 425085416601964546,
  "created_at" : "2014-01-20 02:00:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/08bz167Bf4",
      "expanded_url" : "http:\/\/go.wh.gov\/gwTf2z",
      "display_url" : "go.wh.gov\/gwTf2z"
    } ]
  },
  "geo" : { },
  "id_str" : "424957066805927936",
  "text" : "Obama: \"Where Congress isn\u2019t acting, I\u2019ll act...to put opportunity within reach for anyone...willing to work for it.\" http:\/\/t.co\/08bz167Bf4",
  "id" : 424957066805927936,
  "created_at" : "2014-01-19 17:30:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/XmEhAKeYq3",
      "expanded_url" : "http:\/\/go.wh.gov\/ggsSQb",
      "display_url" : "go.wh.gov\/ggsSQb"
    } ]
  },
  "geo" : { },
  "id_str" : "424919319772815360",
  "text" : "\"Health care costs are growing at their slowest rate in 50 years\u2014due in part to the Affordable Care Act.\" \u2014Obama: http:\/\/t.co\/XmEhAKeYq3",
  "id" : 424919319772815360,
  "created_at" : "2014-01-19 15:00:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/424587391798890496\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/Oyo8IbG97e",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BeRv-7BIQAAXi8e.jpg",
      "id_str" : "424587391664668672",
      "id" : 424587391664668672,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BeRv-7BIQAAXi8e.jpg",
      "sizes" : [ {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/Oyo8IbG97e"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/DRNGCqBLsF",
      "expanded_url" : "http:\/\/go.wh.gov\/L7UBrf",
      "display_url" : "go.wh.gov\/L7UBrf"
    } ]
  },
  "geo" : { },
  "id_str" : "424587391798890496",
  "text" : "\"Since I took office, we\u2019ve cut our deficits by more than half.\" \u2014President Obama: http:\/\/t.co\/DRNGCqBLsF, http:\/\/t.co\/Oyo8IbG97e",
  "id" : 424587391798890496,
  "created_at" : "2014-01-18 17:01:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 73, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/pCFceyL45d",
      "expanded_url" : "http:\/\/go.wh.gov\/Qa78oP",
      "display_url" : "go.wh.gov\/Qa78oP"
    } ]
  },
  "geo" : { },
  "id_str" : "424556924286164992",
  "text" : "President Obama's Weekly Address: Making 2014 a year of action to expand #OpportunityForAll \u2192 http:\/\/t.co\/pCFceyL45d",
  "id" : 424556924286164992,
  "created_at" : "2014-01-18 15:00:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/hB4wxz7m2u",
      "expanded_url" : "http:\/\/go.wh.gov\/91FvHN",
      "display_url" : "go.wh.gov\/91FvHN"
    } ]
  },
  "geo" : { },
  "id_str" : "424335176592666624",
  "text" : "\"I've got to get back because somebody is having a birthday today\u2026I'm going to go ahead and sign this bill.\" \u2014Obama: http:\/\/t.co\/hB4wxz7m2u",
  "id" : 424335176592666624,
  "created_at" : "2014-01-18 00:19:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MLK",
      "indices" : [ 44, 48 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "424320569883250688",
  "text" : "RT @Interior: Did you know that in honor of #MLK day, Monday is a fee free day for all National Parks? RT to spread the word!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MLK",
        "indices" : [ 30, 34 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "424297477966004224",
    "text" : "Did you know that in honor of #MLK day, Monday is a fee free day for all National Parks? RT to spread the word!",
    "id" : 424297477966004224,
    "created_at" : "2014-01-17 21:49:36 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 424320569883250688,
  "created_at" : "2014-01-17 23:21:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LeBron James",
      "screen_name" : "KingJames",
      "indices" : [ 76, 86 ],
      "id_str" : "23083404",
      "id" : 23083404
    }, {
      "name" : "DWade",
      "screen_name" : "DwyaneWade",
      "indices" : [ 93, 104 ],
      "id_str" : "33995409",
      "id" : 33995409
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WestWingWeek",
      "indices" : [ 5, 18 ]
    }, {
      "text" : "CollegeOpportunity",
      "indices" : [ 26, 45 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 46, 57 ]
    }, {
      "text" : "InnovationNation",
      "indices" : [ 58, 75 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/LyfdkvDG8U",
      "expanded_url" : "http:\/\/go.wh.gov\/N4PRUM",
      "display_url" : "go.wh.gov\/N4PRUM"
    } ]
  },
  "geo" : { },
  "id_str" : "424315327095115776",
  "text" : "Your #WestWingWeek recap:\n#CollegeOpportunity\n#GetCovered\n#InnovationNation\n@KingJames &amp; @DwyaneWade\nWatch \u2192 http:\/\/t.co\/LyfdkvDG8U",
  "id" : 424315327095115776,
  "created_at" : "2014-01-17 23:00:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Betty White",
      "screen_name" : "BettyMWhite",
      "indices" : [ 16, 28 ],
      "id_str" : "544517731",
      "id" : 544517731
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/424295130607419392\/photo\/1",
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/ah5M6nqiEl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BeNmLFKIMAE22xt.jpg",
      "id_str" : "424295130452209665",
      "id" : 424295130452209665,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BeNmLFKIMAE22xt.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/ah5M6nqiEl"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/YIQDSam8YP",
      "expanded_url" : "http:\/\/go.wh.gov\/KCWH61",
      "display_url" : "go.wh.gov\/KCWH61"
    } ]
  },
  "geo" : { },
  "id_str" : "424295130607419392",
  "text" : "Happy birthday, @BettyMWhite! http:\/\/t.co\/YIQDSam8YP, http:\/\/t.co\/ah5M6nqiEl",
  "id" : 424295130607419392,
  "created_at" : "2014-01-17 21:40:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/DzosM7rGaL",
      "expanded_url" : "http:\/\/go.wh.gov\/bLQxs8",
      "display_url" : "go.wh.gov\/bLQxs8"
    } ]
  },
  "geo" : { },
  "id_str" : "424292676783976448",
  "text" : "Obama: \"We can shape an approach that meets our security needs while upholding the civil liberties of every American\" http:\/\/t.co\/DzosM7rGaL",
  "id" : 424292676783976448,
  "created_at" : "2014-01-17 21:30:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Clinton",
      "screen_name" : "billclinton",
      "indices" : [ 3, 15 ],
      "id_str" : "1330457336",
      "id" : 1330457336
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 31, 38 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 93, 102 ],
      "id_str" : "36719281",
      "id" : 36719281
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "424284249861001217",
  "text" : "RT @billclinton: Happy 50th to @FLOTUS Michelle Obama. Thanks for the great work you do with @LetsMove to help our kids get healthy.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The First Lady",
        "screen_name" : "FLOTUS",
        "indices" : [ 14, 21 ],
        "id_str" : "1093090866",
        "id" : 1093090866
      }, {
        "name" : "Let's Move!",
        "screen_name" : "letsmove",
        "indices" : [ 76, 85 ],
        "id_str" : "36719281",
        "id" : 36719281
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "424283532127510528",
    "text" : "Happy 50th to @FLOTUS Michelle Obama. Thanks for the great work you do with @LetsMove to help our kids get healthy.",
    "id" : 424283532127510528,
    "created_at" : "2014-01-17 20:54:11 +0000",
    "user" : {
      "name" : "Bill Clinton",
      "screen_name" : "billclinton",
      "protected" : false,
      "id_str" : "1330457336",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451207149478096896\/HoMUOmyu_normal.jpeg",
      "id" : 1330457336,
      "verified" : true
    }
  },
  "id" : 424284249861001217,
  "created_at" : "2014-01-17 20:57:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 88, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/YPvdmqgd8r",
      "expanded_url" : "http:\/\/go.wh.gov\/KiGaQr",
      "display_url" : "go.wh.gov\/KiGaQr"
    } ]
  },
  "geo" : { },
  "id_str" : "424272754796294144",
  "text" : "Here's how we're teaming up with colleges, businesses and other organizations to expand #CollegeOpportunity \u2192 http:\/\/t.co\/YPvdmqgd8r",
  "id" : 424272754796294144,
  "created_at" : "2014-01-17 20:11:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 44, 51 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/424254570236108800\/photo\/1",
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/msxXl4h17X",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BeNBSKDCEAI2sCn.jpg",
      "id_str" : "424254570093481986",
      "id" : 424254570093481986,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BeNBSKDCEAI2sCn.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 766
      }, {
        "h" : 341,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 602,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 766
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/msxXl4h17X"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "424254570236108800",
  "text" : "Someone's turning 50 today. Happy birthday, @FLOTUS! http:\/\/t.co\/msxXl4h17X",
  "id" : 424254570236108800,
  "created_at" : "2014-01-17 18:59:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NSAspeech",
      "indices" : [ 90, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/8kjA9mlHrd",
      "expanded_url" : "http:\/\/go.wh.gov\/ydatvc",
      "display_url" : "go.wh.gov\/ydatvc"
    } ]
  },
  "geo" : { },
  "id_str" : "424239279733088256",
  "text" : "Get the facts on the latest review of U.S. intelligence programs \u2192 http:\/\/t.co\/8kjA9mlHrd #NSAspeech",
  "id" : 424239279733088256,
  "created_at" : "2014-01-17 17:58:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "424224783480279040",
  "text" : "Obama: \"Let us chart a way forward that secures the life of our nation while preserving the liberties that make [it] worth fighting for.\"",
  "id" : 424224783480279040,
  "created_at" : "2014-01-17 17:00:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "424224308999647232",
  "text" : "RT @WHLive: Obama: \"We are held to a different standard precisely because we have been at the forefront in defending personal privacy &amp; hum\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "424223892471689216",
    "text" : "Obama: \"We are held to a different standard precisely because we have been at the forefront in defending personal privacy &amp; human dignity.\"",
    "id" : 424223892471689216,
    "created_at" : "2014-01-17 16:57:12 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 424224308999647232,
  "created_at" : "2014-01-17 16:58:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "424223923631190017",
  "text" : "RT @WHLive: Obama: \"This debate will make us stronger. And I also know that in this time of change, the United States of America will have \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "424223677693980672",
    "text" : "Obama: \"This debate will make us stronger. And I also know that in this time of change, the United States of America will have to lead.\"",
    "id" : 424223677693980672,
    "created_at" : "2014-01-17 16:56:21 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 424223923631190017,
  "created_at" : "2014-01-17 16:57:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "424223485586452481",
  "text" : "President Obama: \"What\u2019s really at stake is how we remain true to who we are in a world that is remaking itself at dizzying speed.\"",
  "id" : 424223485586452481,
  "created_at" : "2014-01-17 16:55:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "424222902506881024",
  "text" : "Obama: \"People around the world...should know that the U.S. is not spying on ordinary people who don\u2019t threaten our national security.\"",
  "id" : 424222902506881024,
  "created_at" : "2014-01-17 16:53:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "424221950169210880",
  "text" : "Obama: \"I am confident that we can shape an approach that meets our security needs while upholding the civil liberties of every American.\"",
  "id" : 424221950169210880,
  "created_at" : "2014-01-17 16:49:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "424221754198749184",
  "text" : "RT @WHLive: President Obama: \"The reforms I\u2019m proposing today should give the American people greater confidence that their rights are bein\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "424221670224572416",
    "text" : "President Obama: \"The reforms I\u2019m proposing today should give the American people greater confidence that their rights are being protected.\"",
    "id" : 424221670224572416,
    "created_at" : "2014-01-17 16:48:22 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 424221754198749184,
  "created_at" : "2014-01-17 16:48:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "424220972598579200",
  "text" : "President Obama: \"I am...ordering a transition that will end the Section 215 bulk metadata program as it currently exists.\"",
  "id" : 424220972598579200,
  "created_at" : "2014-01-17 16:45:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "424219276434616320",
  "text" : "President Obama: \"We will reform programs and procedures in place to provide greater transparency to our surveillance activities.\"",
  "id" : 424219276434616320,
  "created_at" : "2014-01-17 16:38:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "424219053670924288",
  "text" : "Obama: \"Those who defend these programs are not dismissive of civil liberties. The challenge is getting the details right.\"",
  "id" : 424219053670924288,
  "created_at" : "2014-01-17 16:37:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "424218049315500032",
  "text" : "RT @WHLive: President Obama: \"We cannot prevent terrorist attacks or cyber-threats without some capability to penetrate digital communicati\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "424217960735969280",
    "text" : "President Obama: \"We cannot prevent terrorist attacks or cyber-threats without some capability to penetrate digital communications.\"",
    "id" : 424217960735969280,
    "created_at" : "2014-01-17 16:33:38 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 424218049315500032,
  "created_at" : "2014-01-17 16:33:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "424217451765592065",
  "text" : "RT @WHLive: Obama: \"We have to make some important decisions about how to protect ourselves...while upholding...civil liberties &amp; privacy p\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "424217391208226816",
    "text" : "Obama: \"We have to make some important decisions about how to protect ourselves...while upholding...civil liberties &amp; privacy protections.\"",
    "id" : 424217391208226816,
    "created_at" : "2014-01-17 16:31:22 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 424217451765592065,
  "created_at" : "2014-01-17 16:31:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "424217056716681216",
  "text" : "President Obama: \"Our nation\u2019s defense depends in part on the fidelity of those entrusted with our nation\u2019s secrets.\"",
  "id" : 424217056716681216,
  "created_at" : "2014-01-17 16:30:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "424216596232425472",
  "text" : "Obama on intelligence programs: \"Nothing that I have learned since indicated that our intelligence community has sought to violate the law.\"",
  "id" : 424216596232425472,
  "created_at" : "2014-01-17 16:28:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "424216051262316544",
  "text" : "President Obama: \"I maintained a healthy skepticism toward our surveillance programs after I became President.\"",
  "id" : 424216051262316544,
  "created_at" : "2014-01-17 16:26:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "424215461387984896",
  "text" : "Obama: \"A variety of factors have continued to complicate America\u2019s efforts to both defend our nation and uphold our civil liberties.\"",
  "id" : 424215461387984896,
  "created_at" : "2014-01-17 16:23:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "424215183964139522",
  "text" : "RT @WHLive: Obama: \"These efforts have prevented multiple attacks and saved innocent lives\u2014not just here in the United States, but around t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "424215142776074241",
    "text" : "Obama: \"These efforts have prevented multiple attacks and saved innocent lives\u2014not just here in the United States, but around the globe.\"",
    "id" : 424215142776074241,
    "created_at" : "2014-01-17 16:22:26 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 424215183964139522,
  "created_at" : "2014-01-17 16:22:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "424214769625624576",
  "text" : "President Obama on U.S. intelligence post-9\/11: \"We demanded that our intelligence community improve its capabilities.\"",
  "id" : 424214769625624576,
  "created_at" : "2014-01-17 16:20:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "424214317680979969",
  "text" : "RT @WHLive: Obama: \"Even the U.S. proved not to be immune to the abuse of surveillance. In the 1960s, government spied on civil rights lead\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "424214087354957825",
    "text" : "Obama: \"Even the U.S. proved not to be immune to the abuse of surveillance. In the 1960s, government spied on civil rights leaders.\"",
    "id" : 424214087354957825,
    "created_at" : "2014-01-17 16:18:14 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 424214317680979969,
  "created_at" : "2014-01-17 16:19:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "424213951061041153",
  "text" : "RT @WHLive: Obama: \"In the early days of the Cold War, President Truman created the National Security Agency to give us insight into the So\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "424213835088556032",
    "text" : "Obama: \"In the early days of the Cold War, President Truman created the National Security Agency to give us insight into the Soviet bloc.\"",
    "id" : 424213835088556032,
    "created_at" : "2014-01-17 16:17:14 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 424213951061041153,
  "created_at" : "2014-01-17 16:17:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "424213758756409345",
  "text" : "President Obama: \"Throughout our history, intelligence has helped secure our country and our freedoms.\"",
  "id" : 424213758756409345,
  "created_at" : "2014-01-17 16:16:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/6xq7Effdme",
      "expanded_url" : "http:\/\/go.wh.gov\/kXzmuQ",
      "display_url" : "go.wh.gov\/kXzmuQ"
    } ]
  },
  "geo" : { },
  "id_str" : "424213617353830400",
  "text" : "Right now: President Obama speaks about U.S. intelligence programs. Watch \u2192 http:\/\/t.co\/6xq7Effdme",
  "id" : 424213617353830400,
  "created_at" : "2014-01-17 16:16:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/6xq7Effdme",
      "expanded_url" : "http:\/\/go.wh.gov\/kXzmuQ",
      "display_url" : "go.wh.gov\/kXzmuQ"
    } ]
  },
  "geo" : { },
  "id_str" : "424209673651093505",
  "text" : "Starting soon, President Obama speaks on U.S. intelligence programs. Watch \u2192 http:\/\/t.co\/6xq7Effdme",
  "id" : 424209673651093505,
  "created_at" : "2014-01-17 16:00:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "AARP",
      "screen_name" : "AARP",
      "indices" : [ 71, 76 ],
      "id_str" : "80628196",
      "id" : 80628196
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/424197242228981760\/photo\/1",
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/JdbixuLGnb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BeMNJOjCMAEmSwj.jpg",
      "id_str" : "424197242077982721",
      "id" : 424197242077982721,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BeMNJOjCMAEmSwj.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/JdbixuLGnb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "424197278044155905",
  "text" : "RT @FLOTUS: Excited to join Barack in the 50+ club today\u2026 check out my @AARP card! \u2013mo http:\/\/t.co\/JdbixuLGnb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "AARP",
        "screen_name" : "AARP",
        "indices" : [ 59, 64 ],
        "id_str" : "80628196",
        "id" : 80628196
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/424197242228981760\/photo\/1",
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/JdbixuLGnb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BeMNJOjCMAEmSwj.jpg",
        "id_str" : "424197242077982721",
        "id" : 424197242077982721,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BeMNJOjCMAEmSwj.jpg",
        "sizes" : [ {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/JdbixuLGnb"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "424197242228981760",
    "text" : "Excited to join Barack in the 50+ club today\u2026 check out my @AARP card! \u2013mo http:\/\/t.co\/JdbixuLGnb",
    "id" : 424197242228981760,
    "created_at" : "2014-01-17 15:11:18 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 424197278044155905,
  "created_at" : "2014-01-17 15:11:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 1, 4 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 103, 117 ]
    }, {
      "text" : "NAIAS",
      "indices" : [ 118, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/jPPlcT2f2F",
      "expanded_url" : "https:\/\/vine.co\/v\/hLLYEbEVD5e",
      "display_url" : "vine.co\/v\/hLLYEbEVD5e"
    } ]
  },
  "geo" : { },
  "id_str" : "424002007649632258",
  "text" : ".@VP Biden checks out the showcase of American cars at the Detroit Auto Show \u2192 https:\/\/t.co\/jPPlcT2f2F #MadeInAmerica #NAIAS",
  "id" : 424002007649632258,
  "created_at" : "2014-01-17 02:15:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 129, 144 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/1SWsZayvAM",
      "expanded_url" : "http:\/\/go.wh.gov\/SA6g6f",
      "display_url" : "go.wh.gov\/SA6g6f"
    } ]
  },
  "geo" : { },
  "id_str" : "423991528541786113",
  "text" : "Today's passage of the 2014 funding bill marks a positive step forward for the nation &amp; our economy \u2192 http:\/\/t.co\/1SWsZayvAM #ABetterBargain",
  "id" : 423991528541786113,
  "created_at" : "2014-01-17 01:33:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 98, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 142 ],
      "url" : "http:\/\/t.co\/jSXgU7pp5E",
      "expanded_url" : "http:\/\/go.wh.gov\/GxoGjp",
      "display_url" : "go.wh.gov\/GxoGjp"
    } ]
  },
  "geo" : { },
  "id_str" : "423971808744710144",
  "text" : "Here's how President Obama's teaming up with colleges, businesses &amp; other orgs to help expand #CollegeOpportunity \u2192 http:\/\/t.co\/jSXgU7pp5E",
  "id" : 423971808744710144,
  "created_at" : "2014-01-17 00:15:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 94, 101 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/6amitSFKOl",
      "expanded_url" : "http:\/\/youtu.be\/SNhDLQMzduM",
      "display_url" : "youtu.be\/SNhDLQMzduM"
    } ]
  },
  "geo" : { },
  "id_str" : "423961159734005761",
  "text" : "\"There's nothing more important to this nation's future than investing in our young people.\" \u2014@FLOTUS: http:\/\/t.co\/6amitSFKOl",
  "id" : 423961159734005761,
  "created_at" : "2014-01-16 23:33:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Facebook",
      "screen_name" : "facebook",
      "indices" : [ 58, 67 ],
      "id_str" : "2425151",
      "id" : 2425151
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 89, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/qLgVM0uj7d",
      "expanded_url" : "https:\/\/www.facebook.com\/WhiteHouse",
      "display_url" : "facebook.com\/WhiteHouse"
    } ]
  },
  "geo" : { },
  "id_str" : "423920520606662656",
  "text" : "At 4pm ET, join President Obama's education advisor for a @Facebook Q&amp;A on expanding #CollegeOpportunity \u2192 https:\/\/t.co\/qLgVM0uj7d",
  "id" : 423920520606662656,
  "created_at" : "2014-01-16 20:51:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kerry washington",
      "screen_name" : "kerrywashington",
      "indices" : [ 3, 19 ],
      "id_str" : "205302299",
      "id" : 205302299
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 42, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "423908588550381569",
  "text" : "RT @kerrywashington: Friends help friends #GetCovered. Join me and millions of Americans 3p ET today for a livestream event via YouTube htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 21, 32 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/O73BYtPYLC",
        "expanded_url" : "http:\/\/bit.ly\/TAFGC",
        "display_url" : "bit.ly\/TAFGC"
      } ]
    },
    "geo" : { },
    "id_str" : "423900819936014336",
    "text" : "Friends help friends #GetCovered. Join me and millions of Americans 3p ET today for a livestream event via YouTube http:\/\/t.co\/O73BYtPYLC",
    "id" : 423900819936014336,
    "created_at" : "2014-01-16 19:33:25 +0000",
    "user" : {
      "name" : "kerry washington",
      "screen_name" : "kerrywashington",
      "protected" : false,
      "id_str" : "205302299",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778641930536284160\/3-m-BwGQ_normal.jpg",
      "id" : 205302299,
      "verified" : true
    }
  },
  "id" : 423908588550381569,
  "created_at" : "2014-01-16 20:04:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/hGK5dxmjrk",
      "expanded_url" : "http:\/\/go.wh.gov\/6ndnVo",
      "display_url" : "go.wh.gov\/6ndnVo"
    } ]
  },
  "geo" : { },
  "id_str" : "423899248459923456",
  "text" : "RT @FLOTUS: \"By...2020, we want to make the United States the leader in college graduation rates.\" \u2014FLOTUS: http:\/\/t.co\/hGK5dxmjrk #College\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CollegeOpportunity",
        "indices" : [ 119, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/hGK5dxmjrk",
        "expanded_url" : "http:\/\/go.wh.gov\/6ndnVo",
        "display_url" : "go.wh.gov\/6ndnVo"
      } ]
    },
    "geo" : { },
    "id_str" : "423898058049327104",
    "text" : "\"By...2020, we want to make the United States the leader in college graduation rates.\" \u2014FLOTUS: http:\/\/t.co\/hGK5dxmjrk #CollegeOpportunity",
    "id" : 423898058049327104,
    "created_at" : "2014-01-16 19:22:27 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 423899248459923456,
  "created_at" : "2014-01-16 19:27:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 120, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/VVfNLGv1Kh",
      "expanded_url" : "http:\/\/go.wh.gov\/hWEk4h",
      "display_url" : "go.wh.gov\/hWEk4h"
    } ]
  },
  "geo" : { },
  "id_str" : "423892536403300352",
  "text" : "FACT: More than 80 schools are making commitments to help more students in need attend college \u2192 http:\/\/t.co\/VVfNLGv1Kh #CollegeOpportunity",
  "id" : 423892536403300352,
  "created_at" : "2014-01-16 19:00:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 3, 12 ],
      "id_str" : "36719281",
      "id" : 36719281
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/letsmove\/status\/423883725080784896\/photo\/1",
      "indices" : [ 45, 67 ],
      "url" : "http:\/\/t.co\/yXEUee1chV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BeHwAIvCcAAb6Co.jpg",
      "id_str" : "423883725084979200",
      "id" : 423883725084979200,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BeHwAIvCcAAb6Co.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/yXEUee1chV"
    } ],
    "hashtags" : [ {
      "text" : "HealthySnack",
      "indices" : [ 30, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "423883796006465536",
  "text" : "RT @letsmove: An apple a day. #HealthySnack, http:\/\/t.co\/yXEUee1chV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/letsmove\/status\/423883725080784896\/photo\/1",
        "indices" : [ 31, 53 ],
        "url" : "http:\/\/t.co\/yXEUee1chV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BeHwAIvCcAAb6Co.jpg",
        "id_str" : "423883725084979200",
        "id" : 423883725084979200,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BeHwAIvCcAAb6Co.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 733,
          "resize" : "fit",
          "w" : 1100
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/yXEUee1chV"
      } ],
      "hashtags" : [ {
        "text" : "HealthySnack",
        "indices" : [ 16, 29 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "423883725080784896",
    "text" : "An apple a day. #HealthySnack, http:\/\/t.co\/yXEUee1chV",
    "id" : 423883725080784896,
    "created_at" : "2014-01-16 18:25:30 +0000",
    "user" : {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "protected" : false,
      "id_str" : "36719281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207340336\/780fc13e31b6fdd80bd57d000dc13838_normal.jpeg",
      "id" : 36719281,
      "verified" : true
    }
  },
  "id" : 423883796006465536,
  "created_at" : "2014-01-16 18:25:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 63, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/9vhsH1hSLY",
      "expanded_url" : "http:\/\/go.wh.gov\/p59sUt",
      "display_url" : "go.wh.gov\/p59sUt"
    } ]
  },
  "geo" : { },
  "id_str" : "423874917663133696",
  "text" : "Get the facts on President Obama's call to action on expanding #CollegeOpportunity \u2192 http:\/\/t.co\/9vhsH1hSLY",
  "id" : 423874917663133696,
  "created_at" : "2014-01-16 17:50:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SUNY",
      "screen_name" : "SUNY",
      "indices" : [ 3, 8 ],
      "id_str" : "71048920",
      "id" : 71048920
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 54, 65 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 110, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/y5h1iLrMbM",
      "expanded_url" : "http:\/\/ow.ly\/sEy4k",
      "display_url" : "ow.ly\/sEy4k"
    } ]
  },
  "geo" : { },
  "id_str" : "423871444893044736",
  "text" : "RT @SUNY: HAPPENING NOW: Chancellor Zimpher addresses @WhiteHouse press corps - WATCH: http:\/\/t.co\/y5h1iLrMbM #CollegeOpportunity",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 44, 55 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CollegeOpportunity",
        "indices" : [ 100, 119 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/y5h1iLrMbM",
        "expanded_url" : "http:\/\/ow.ly\/sEy4k",
        "display_url" : "ow.ly\/sEy4k"
      } ]
    },
    "geo" : { },
    "id_str" : "423869174231080960",
    "text" : "HAPPENING NOW: Chancellor Zimpher addresses @WhiteHouse press corps - WATCH: http:\/\/t.co\/y5h1iLrMbM #CollegeOpportunity",
    "id" : 423869174231080960,
    "created_at" : "2014-01-16 17:27:40 +0000",
    "user" : {
      "name" : "SUNY",
      "screen_name" : "SUNY",
      "protected" : false,
      "id_str" : "71048920",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744286119047487488\/K7hXqzfz_normal.jpg",
      "id" : 71048920,
      "verified" : true
    }
  },
  "id" : 423871444893044736,
  "created_at" : "2014-01-16 17:36:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 118, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "423866106193788929",
  "text" : "\"As parents, as teachers, as business...leaders...and as citizens, we've all got a role to play.\" \u2014Obama on expanding #CollegeOpportunity",
  "id" : 423866106193788929,
  "created_at" : "2014-01-16 17:15:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 29, 48 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "423864664204664834",
  "text" : "President Obama on expanding #CollegeOpportunity: \u201CWe don\u2019t have a level playing field when it comes to so-called standardized tests.\u201D",
  "id" : 423864664204664834,
  "created_at" : "2014-01-16 17:09:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 115, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "423863322983686144",
  "text" : "Obama: \"We need to do more to make sure rising tuition doesn\u2019t price the middle class out of a college education.\" #CollegeOpportunity",
  "id" : 423863322983686144,
  "created_at" : "2014-01-16 17:04:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "423863149150744576",
  "text" : "RT @WHLive: Obama: \"We\u2019ve taken new steps to help students stay in school, and today the high school dropout rate is the lowest it\u2019s been i\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "423862972046245888",
    "text" : "Obama: \"We\u2019ve taken new steps to help students stay in school, and today the high school dropout rate is the lowest it\u2019s been in 40 years.\"",
    "id" : 423862972046245888,
    "created_at" : "2014-01-16 17:03:02 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 423863149150744576,
  "created_at" : "2014-01-16 17:03:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "423863004300451840",
  "text" : "RT @WHLive: President Obama: \"We\u2019ve set a goal of training 100,000 new math and science teachers over the next ten years.\" #CollegeOpportun\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CollegeOpportunity",
        "indices" : [ 111, 130 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "423862927016198144",
    "text" : "President Obama: \"We\u2019ve set a goal of training 100,000 new math and science teachers over the next ten years.\" #CollegeOpportunity",
    "id" : 423862927016198144,
    "created_at" : "2014-01-16 17:02:51 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 423863004300451840,
  "created_at" : "2014-01-16 17:03:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 120, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "423862570299047936",
  "text" : "Obama: \"If we hadn\u2019t made a commitment as a country to send more...people to college, Michelle and I wouldn\u2019t be here.\" #CollegeOpportunity",
  "id" : 423862570299047936,
  "created_at" : "2014-01-16 17:01:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 104, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "423862419434135553",
  "text" : "President Obama: \"While we don\u2019t promise equal outcomes, we have strived to deliver equal opportunity.\" #OpportunityForAll",
  "id" : 423862419434135553,
  "created_at" : "2014-01-16 17:00:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 85, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "423862315717378048",
  "text" : "President Obama: \"Graduating college has never been more valuable than it is today.\" #CollegeOpportunity",
  "id" : 423862315717378048,
  "created_at" : "2014-01-16 17:00:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "423862231361523713",
  "text" : "Obama: \"Today, more than 100 colleges &amp; 40 organizations are announcing new commitments to help more young people...graduate from college.\"",
  "id" : 423862231361523713,
  "created_at" : "2014-01-16 17:00:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "423862073349533698",
  "text" : "RT @WHLive: President Obama: \"I\u2019ve got a pen to take executive action where Congress won\u2019t, and I\u2019ve got a phone to rally folks.\" #Opportun\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OpportunityForAll",
        "indices" : [ 118, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "423862006400045056",
    "text" : "President Obama: \"I\u2019ve got a pen to take executive action where Congress won\u2019t, and I\u2019ve got a phone to rally folks.\" #OpportunityForAll",
    "id" : 423862006400045056,
    "created_at" : "2014-01-16 16:59:11 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 423862073349533698,
  "created_at" : "2014-01-16 16:59:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 102, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "423861399589093376",
  "text" : "President Obama: \"We want to make sure more young people have the chance to earn a higher education.\" #CollegeOpportunity",
  "id" : 423861399589093376,
  "created_at" : "2014-01-16 16:56:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "423861245670735874",
  "text" : "President Obama on the First Lady: \"She did leave one thing out of her speech\u2014it\u2019s her birthday tomorrow!\"",
  "id" : 423861245670735874,
  "created_at" : "2014-01-16 16:56:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 31, 38 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 58, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/lQqbgAbeAc",
      "expanded_url" : "http:\/\/go.wh.gov\/sCZir7",
      "display_url" : "go.wh.gov\/sCZir7"
    } ]
  },
  "geo" : { },
  "id_str" : "423847902276898817",
  "text" : "Don't miss President Obama and @FLOTUS speak on expanding #CollegeOpportunity at 11:20am ET \u2192 http:\/\/t.co\/lQqbgAbeAc",
  "id" : 423847902276898817,
  "created_at" : "2014-01-16 16:03:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yahoo News",
      "screen_name" : "YahooNews",
      "indices" : [ 7, 17 ],
      "id_str" : "7309052",
      "id" : 7309052
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 120, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/uK8MabO33t",
      "expanded_url" : "http:\/\/yhoo.it\/1j86o3q",
      "display_url" : "yhoo.it\/1j86o3q"
    } ]
  },
  "geo" : { },
  "id_str" : "423833399782940672",
  "text" : "Join a @YahooNews live chat on college affordability with Obama's education advisor at 12pm ET \u2192 http:\/\/t.co\/uK8MabO33t #CollegeOpportunity",
  "id" : 423833399782940672,
  "created_at" : "2014-01-16 15:05:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "InnovationNation",
      "indices" : [ 122, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/V458ttRrhY",
      "expanded_url" : "http:\/\/go.wh.gov\/1gsjSQ",
      "display_url" : "go.wh.gov\/1gsjSQ"
    } ]
  },
  "geo" : { },
  "id_str" : "423630006841917440",
  "text" : "\"When times get tough, we don\u2019t give up. We get up. We innovate. We adapt. We keep going.\" \u2014Obama: http:\/\/t.co\/V458ttRrhY #InnovationNation",
  "id" : 423630006841917440,
  "created_at" : "2014-01-16 01:37:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/423619237169471488\/photo\/1",
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/Kl4DdFnO9P",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BeD_c54CQAErjBp.jpg",
      "id_str" : "423619237010096129",
      "id" : 423619237010096129,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BeD_c54CQAErjBp.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Kl4DdFnO9P"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "423619237169471488",
  "text" : "Let's dance. http:\/\/t.co\/Kl4DdFnO9P",
  "id" : 423619237169471488,
  "created_at" : "2014-01-16 00:54:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USA TODAY",
      "screen_name" : "USATODAY",
      "indices" : [ 1, 10 ],
      "id_str" : "15754281",
      "id" : 15754281
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/q4J4s7MxmJ",
      "expanded_url" : "http:\/\/usat.ly\/KhIm6G",
      "display_url" : "usat.ly\/KhIm6G"
    } ]
  },
  "geo" : { },
  "id_str" : "423579076930965505",
  "text" : ".@USAToday: \"Young people are enrolling in health care coverage under the Affordable Care Act\u2014and for good reason.\" http:\/\/t.co\/q4J4s7MxmJ",
  "id" : 423579076930965505,
  "created_at" : "2014-01-15 22:14:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rep. Jared Huffman",
      "screen_name" : "RepHuffman",
      "indices" : [ 3, 14 ],
      "id_str" : "1071102246",
      "id" : 1071102246
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RenewUI",
      "indices" : [ 107, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "423571598692847616",
  "text" : "RT @RepHuffman: Unemployment insurance is not a handout; it\u2019s a hand up for job seekers who need our help. #RenewUI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RenewUI",
        "indices" : [ 91, 99 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "423537207924637696",
    "text" : "Unemployment insurance is not a handout; it\u2019s a hand up for job seekers who need our help. #RenewUI",
    "id" : 423537207924637696,
    "created_at" : "2014-01-15 19:28:33 +0000",
    "user" : {
      "name" : "Rep. Jared Huffman",
      "screen_name" : "RepHuffman",
      "protected" : false,
      "id_str" : "1071102246",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/651435990100279296\/5lQBk2Ut_normal.png",
      "id" : 1071102246,
      "verified" : true
    }
  },
  "id" : 423571598692847616,
  "created_at" : "2014-01-15 21:45:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "indices" : [ 3, 12 ],
      "id_str" : "1604366701",
      "id" : 1604366701
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MinWage",
      "indices" : [ 18, 26 ]
    }, {
      "text" : "RaiseTheWage",
      "indices" : [ 112, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "423561413693804544",
  "text" : "RT @LaborSec: The #MinWage's value has not kept up w\/ the cost of living. This is about economics AND fairness. #RaiseTheWage http:\/\/t.co\/c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/LaborSec\/status\/423536857591197697\/photo\/1",
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/cvnO5iQ8jn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BeC0hyqCMAIpmBX.jpg",
        "id_str" : "423536857599586306",
        "id" : 423536857599586306,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BeC0hyqCMAIpmBX.jpg",
        "sizes" : [ {
          "h" : 763,
          "resize" : "fit",
          "w" : 792
        }, {
          "h" : 328,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 578,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 763,
          "resize" : "fit",
          "w" : 792
        } ],
        "display_url" : "pic.twitter.com\/cvnO5iQ8jn"
      } ],
      "hashtags" : [ {
        "text" : "MinWage",
        "indices" : [ 4, 12 ]
      }, {
        "text" : "RaiseTheWage",
        "indices" : [ 98, 111 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "423536857591197697",
    "text" : "The #MinWage's value has not kept up w\/ the cost of living. This is about economics AND fairness. #RaiseTheWage http:\/\/t.co\/cvnO5iQ8jn",
    "id" : 423536857591197697,
    "created_at" : "2014-01-15 19:27:10 +0000",
    "user" : {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "protected" : false,
      "id_str" : "1604366701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744887280666611712\/eEeyFjs6_normal.jpg",
      "id" : 1604366701,
      "verified" : true
    }
  },
  "id" : 423561413693804544,
  "created_at" : "2014-01-15 21:04:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "indices" : [ 3, 15 ],
      "id_str" : "369232105",
      "id" : 369232105
    }, {
      "name" : "The Onion",
      "screen_name" : "TheOnion",
      "indices" : [ 118, 127 ],
      "id_str" : "14075928",
      "id" : 14075928
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/qs8xVe2BZs",
      "expanded_url" : "http:\/\/onion.com\/1eK84wy",
      "display_url" : "onion.com\/1eK84wy"
    } ]
  },
  "geo" : { },
  "id_str" : "423553274453581824",
  "text" : "RT @PAniskoff44: Nation Recalls Simpler Time When Health Care System Was Broken Beyond Repair http:\/\/t.co\/qs8xVe2BZs. @TheOnion nails it, a\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Onion",
        "screen_name" : "TheOnion",
        "indices" : [ 101, 110 ],
        "id_str" : "14075928",
        "id" : 14075928
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/qs8xVe2BZs",
        "expanded_url" : "http:\/\/onion.com\/1eK84wy",
        "display_url" : "onion.com\/1eK84wy"
      } ]
    },
    "geo" : { },
    "id_str" : "423546847571886080",
    "text" : "Nation Recalls Simpler Time When Health Care System Was Broken Beyond Repair http:\/\/t.co\/qs8xVe2BZs. @TheOnion nails it, as usual.",
    "id" : 423546847571886080,
    "created_at" : "2014-01-15 20:06:52 +0000",
    "user" : {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "protected" : false,
      "id_str" : "369232105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623146355767140352\/58sqoVrw_normal.jpg",
      "id" : 369232105,
      "verified" : true
    }
  },
  "id" : 423553274453581824,
  "created_at" : "2014-01-15 20:32:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alicia Keys",
      "screen_name" : "aliciakeys",
      "indices" : [ 3, 14 ],
      "id_str" : "35094637",
      "id" : 35094637
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 29, 40 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 96, 103 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "education",
      "indices" : [ 126, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "423549496920768512",
  "text" : "RT @aliciakeys: On my way to @WhiteHouse to watch The Inevitable Defeat of Mister &amp; Pete w\/ @FLOTUS and talk about higher #education http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 13, 24 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "The First Lady",
        "screen_name" : "FLOTUS",
        "indices" : [ 80, 87 ],
        "id_str" : "1093090866",
        "id" : 1093090866
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/aliciakeys\/status\/423539762675208194\/photo\/1",
        "indices" : [ 121, 143 ],
        "url" : "http:\/\/t.co\/TnoEaYCYO2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BeC3K48CUAIbdMp.jpg",
        "id_str" : "423539762683596802",
        "id" : 423539762683596802,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BeC3K48CUAIbdMp.jpg",
        "sizes" : [ {
          "h" : 1365,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/TnoEaYCYO2"
      } ],
      "hashtags" : [ {
        "text" : "education",
        "indices" : [ 110, 120 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "423539762675208194",
    "text" : "On my way to @WhiteHouse to watch The Inevitable Defeat of Mister &amp; Pete w\/ @FLOTUS and talk about higher #education http:\/\/t.co\/TnoEaYCYO2",
    "id" : 423539762675208194,
    "created_at" : "2014-01-15 19:38:43 +0000",
    "user" : {
      "name" : "Alicia Keys",
      "screen_name" : "aliciakeys",
      "protected" : false,
      "id_str" : "35094637",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/784235369906614272\/IyyZ25fR_normal.jpg",
      "id" : 35094637,
      "verified" : true
    }
  },
  "id" : 423549496920768512,
  "created_at" : "2014-01-15 20:17:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Labor Department",
      "screen_name" : "USDOL",
      "indices" : [ 3, 9 ],
      "id_str" : "20179628",
      "id" : 20179628
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/USDOL\/status\/419505437113729025\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/kzP4X8fP64",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BdJh-PECQAE8Y4x.jpg",
      "id_str" : "419505437122117633",
      "id" : 419505437122117633,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BdJh-PECQAE8Y4x.jpg",
      "sizes" : [ {
        "h" : 1122,
        "resize" : "fit",
        "w" : 1559
      }, {
        "h" : 432,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 245,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 737,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/kzP4X8fP64"
    } ],
    "hashtags" : [ {
      "text" : "MinimumWage",
      "indices" : [ 43, 55 ]
    }, {
      "text" : "RaisetheWage",
      "indices" : [ 93, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "423541917322735616",
  "text" : "RT @USDOL: 13 additional states raised the #MinimumWage in 2014, was your state one of them? #RaisetheWage http:\/\/t.co\/kzP4X8fP64",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/USDOL\/status\/419505437113729025\/photo\/1",
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/kzP4X8fP64",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BdJh-PECQAE8Y4x.jpg",
        "id_str" : "419505437122117633",
        "id" : 419505437122117633,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BdJh-PECQAE8Y4x.jpg",
        "sizes" : [ {
          "h" : 1122,
          "resize" : "fit",
          "w" : 1559
        }, {
          "h" : 432,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 245,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 737,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/kzP4X8fP64"
      } ],
      "hashtags" : [ {
        "text" : "MinimumWage",
        "indices" : [ 32, 44 ]
      }, {
        "text" : "RaisetheWage",
        "indices" : [ 82, 95 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "419505437113729025",
    "text" : "13 additional states raised the #MinimumWage in 2014, was your state one of them? #RaisetheWage http:\/\/t.co\/kzP4X8fP64",
    "id" : 419505437113729025,
    "created_at" : "2014-01-04 16:27:45 +0000",
    "user" : {
      "name" : "US Labor Department",
      "screen_name" : "USDOL",
      "protected" : false,
      "id_str" : "20179628",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655006480697978880\/Fom0f0nJ_normal.png",
      "id" : 20179628,
      "verified" : true
    }
  },
  "id" : 423541917322735616,
  "created_at" : "2014-01-15 19:47:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "InnovationNation",
      "indices" : [ 118, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/HegKubqOXV",
      "expanded_url" : "http:\/\/go.wh.gov\/xxYbUs",
      "display_url" : "go.wh.gov\/xxYbUs"
    } ]
  },
  "geo" : { },
  "id_str" : "423536631342063616",
  "text" : "FACT: American manufacturing production is growing at the fastest pace in more than a decade \u2192 http:\/\/t.co\/HegKubqOXV #InnovationNation",
  "id" : 423536631342063616,
  "created_at" : "2014-01-15 19:26:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "InnovationNation",
      "indices" : [ 121, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "423523146189533184",
  "text" : "Obama: \"When times get tough, we don\u2019t give up. We get up. We innovate. We adapt. We keep going. We look to the future.\" #InnovationNation",
  "id" : 423523146189533184,
  "created_at" : "2014-01-15 18:32:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "423522843104915456",
  "text" : "RT @WHLive: Obama: \"We\u2019ll be launching two more innovation hubs...focused on digital design and...developing lightweight metals.\" #Innovati\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "InnovationNation",
        "indices" : [ 118, 135 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "423522741112029184",
    "text" : "Obama: \"We\u2019ll be launching two more innovation hubs...focused on digital design and...developing lightweight metals.\" #InnovationNation",
    "id" : 423522741112029184,
    "created_at" : "2014-01-15 18:31:04 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 423522843104915456,
  "created_at" : "2014-01-15 18:31:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "423521845686435841",
  "text" : "RT @WHLive: Obama in NC: \"I\u2019m pleased to announce America\u2019s newest high-tech manufacturing hub focused on the next generation of power elec\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "423521740653101056",
    "text" : "Obama in NC: \"I\u2019m pleased to announce America\u2019s newest high-tech manufacturing hub focused on the next generation of power electronics.\"",
    "id" : 423521740653101056,
    "created_at" : "2014-01-15 18:27:06 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 423521845686435841,
  "created_at" : "2014-01-15 18:27:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "InnovationNation",
      "indices" : [ 119, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "423521543709552640",
  "text" : "Obama: \"I don\u2019t want the next big...discovery to be made in Germany or China...I want it to be right here in America.\" #InnovationNation",
  "id" : 423521543709552640,
  "created_at" : "2014-01-15 18:26:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "NC State University",
      "screen_name" : "NCState",
      "indices" : [ 70, 78 ],
      "id_str" : "487624974",
      "id" : 487624974
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "423521513049174016",
  "text" : "RT @WHLive: Obama: \"Let\u2019s build on the kind of work you\u2019re doing...at @NCState to develop tech that can lead to new jobs and entire new ind\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NC State University",
        "screen_name" : "NCState",
        "indices" : [ 58, 66 ],
        "id_str" : "487624974",
        "id" : 487624974
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "423521236514537473",
    "text" : "Obama: \"Let\u2019s build on the kind of work you\u2019re doing...at @NCState to develop tech that can lead to new jobs and entire new industries.\"",
    "id" : 423521236514537473,
    "created_at" : "2014-01-15 18:25:06 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 423521513049174016,
  "created_at" : "2014-01-15 18:26:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "InnovationNation",
      "indices" : [ 120, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "423521099901444096",
  "text" : "Obama: \"I\u2019m here to act\u2014to help make Raleigh-Durham, and America, a magnet for the good, high-tech manufacturing jobs.\" #InnovationNation",
  "id" : 423521099901444096,
  "created_at" : "2014-01-15 18:24:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RenewUI",
      "indices" : [ 112, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "423520605481467904",
  "text" : "President Obama: \"Congress should do the right thing and extend this vital lifeline for millions of Americans.\" #RenewUI",
  "id" : 423520605481467904,
  "created_at" : "2014-01-15 18:22:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "423520435075317760",
  "text" : "Obama: \"The pieces are there to restore some of the ground the middle class...lost in recent decades...raising wages for American families.\"",
  "id" : 423520435075317760,
  "created_at" : "2014-01-15 18:21:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "423520128358445056",
  "text" : "Obama: \"Health care costs are growing at their slowest rate in 50 years...and part of that...has to do with the Affordable Care Act.\"",
  "id" : 423520128358445056,
  "created_at" : "2014-01-15 18:20:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "423519983780773888",
  "text" : "RT @WHLive: Obama: \"Today, thanks to the hard work and sacrifice of the American people...the economy is growing stronger.\" http:\/\/t.co\/M9k\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WHLive\/status\/423519893892661248\/photo\/1",
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/M9kbak8jX1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BeClGXHIQAAZVYV.jpg",
        "id_str" : "423519893674541056",
        "id" : 423519893674541056,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BeClGXHIQAAZVYV.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 700,
          "resize" : "fit",
          "w" : 1400
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/M9kbak8jX1"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "423519893892661248",
    "text" : "Obama: \"Today, thanks to the hard work and sacrifice of the American people...the economy is growing stronger.\" http:\/\/t.co\/M9kbak8jX1",
    "id" : 423519893892661248,
    "created_at" : "2014-01-15 18:19:45 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 423519983780773888,
  "created_at" : "2014-01-15 18:20:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "423519655966560256",
  "text" : "Obama: \"We've got to do more to connect universities...with companies...to make America the number one place...to open new businesses.\"",
  "id" : 423519655966560256,
  "created_at" : "2014-01-15 18:18:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "InnovationNation",
      "indices" : [ 116, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/RpMvUBm3a4",
      "expanded_url" : "http:\/\/go.wh.gov\/FnAqES",
      "display_url" : "go.wh.gov\/FnAqES"
    } ]
  },
  "geo" : { },
  "id_str" : "423518538993639424",
  "text" : "Right now: President Obama announces new steps to strengthen American manufacturing. Watch \u2192 http:\/\/t.co\/RpMvUBm3a4 #InnovationNation",
  "id" : 423518538993639424,
  "created_at" : "2014-01-15 18:14:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "InnovationNation",
      "indices" : [ 98, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/RpMvUBm3a4",
      "expanded_url" : "http:\/\/go.wh.gov\/FnAqES",
      "display_url" : "go.wh.gov\/FnAqES"
    } ]
  },
  "geo" : { },
  "id_str" : "423512522247770114",
  "text" : "FACT: Our manufacturers have added 568,000 new jobs over the past 4 years. http:\/\/t.co\/RpMvUBm3a4 #InnovationNation",
  "id" : 423512522247770114,
  "created_at" : "2014-01-15 17:50:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "InnovationNation",
      "indices" : [ 113, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/2GNzrI2dys",
      "expanded_url" : "http:\/\/go.wh.gov\/frgxRD",
      "display_url" : "go.wh.gov\/frgxRD"
    } ]
  },
  "geo" : { },
  "id_str" : "423508629199671296",
  "text" : "Watch President Obama announce new steps to strengthen American manufacturing at 1pm ET \u2192 http:\/\/t.co\/2GNzrI2dys #InnovationNation",
  "id" : 423508629199671296,
  "created_at" : "2014-01-15 17:35:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Earvin Magic Johnson",
      "screen_name" : "MagicJohnson",
      "indices" : [ 1, 14 ],
      "id_str" : "248900032",
      "id" : 248900032
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 55, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/FqrOoiT0IU",
      "expanded_url" : "http:\/\/youtu.be\/wlakfp83iEg",
      "display_url" : "youtu.be\/wlakfp83iEg"
    } ]
  },
  "geo" : { },
  "id_str" : "423487557351899136",
  "text" : ".@MagicJohnson knows you can't always win on your own. #GetCovered so your health gets an assist when you need it: http:\/\/t.co\/FqrOoiT0IU",
  "id" : 423487557351899136,
  "created_at" : "2014-01-15 16:11:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Earvin Magic Johnson",
      "screen_name" : "MagicJohnson",
      "indices" : [ 95, 108 ],
      "id_str" : "248900032",
      "id" : 248900032
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 133, 144 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/FqrOoiT0IU",
      "expanded_url" : "http:\/\/youtu.be\/wlakfp83iEg",
      "display_url" : "youtu.be\/wlakfp83iEg"
    } ]
  },
  "geo" : { },
  "id_str" : "423473514587234304",
  "text" : "\"Everybody deserves to have good health care &amp; when you think about it\u2014it saved my life.\" \u2014@MagicJohnson: http:\/\/t.co\/FqrOoiT0IU #GetCovered",
  "id" : 423473514587234304,
  "created_at" : "2014-01-15 15:15:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Earvin Magic Johnson",
      "screen_name" : "MagicJohnson",
      "indices" : [ 3, 16 ],
      "id_str" : "248900032",
      "id" : 248900032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/6Tm8s9RnuQ",
      "expanded_url" : "http:\/\/youtu.be\/wlakfp83iEg",
      "display_url" : "youtu.be\/wlakfp83iEg"
    } ]
  },
  "geo" : { },
  "id_str" : "423470107277688832",
  "text" : "RT @MagicJohnson: Having good health care saved my life. Make sure you've got a game plan for your health: http:\/\/t.co\/6Tm8s9RnuQ #GetCover\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.whosay.com\" rel=\"nofollow\"\u003EWhoSay\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 112, 123 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/6Tm8s9RnuQ",
        "expanded_url" : "http:\/\/youtu.be\/wlakfp83iEg",
        "display_url" : "youtu.be\/wlakfp83iEg"
      } ]
    },
    "geo" : { },
    "id_str" : "423469821855277056",
    "text" : "Having good health care saved my life. Make sure you've got a game plan for your health: http:\/\/t.co\/6Tm8s9RnuQ #GetCovered",
    "id" : 423469821855277056,
    "created_at" : "2014-01-15 15:00:47 +0000",
    "user" : {
      "name" : "Earvin Magic Johnson",
      "screen_name" : "MagicJohnson",
      "protected" : false,
      "id_str" : "248900032",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/735621697642975232\/YznfoCzt_normal.jpg",
      "id" : 248900032,
      "verified" : true
    }
  },
  "id" : 423470107277688832,
  "created_at" : "2014-01-15 15:01:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin",
      "screen_name" : "Erin44",
      "indices" : [ 3, 10 ],
      "id_str" : "41044637",
      "id" : 41044637
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHFilmFest",
      "indices" : [ 63, 74 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/DIDW36nlrl",
      "expanded_url" : "http:\/\/WH.gov\/FilmFest",
      "display_url" : "WH.gov\/FilmFest"
    } ]
  },
  "geo" : { },
  "id_str" : "423270521782812672",
  "text" : "RT @Erin44: Just watched some of the great submissions for the #WHFilmFest. It's not too late to apply! http:\/\/t.co\/DIDW36nlrl http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/410203182438969344\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/i378oKg1Wt",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BbFVnv-CcAAGhLi.jpg",
        "id_str" : "410203182447357952",
        "id" : 410203182447357952,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BbFVnv-CcAAGhLi.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 700,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 700,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/i378oKg1Wt"
      } ],
      "hashtags" : [ {
        "text" : "WHFilmFest",
        "indices" : [ 51, 62 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/DIDW36nlrl",
        "expanded_url" : "http:\/\/WH.gov\/FilmFest",
        "display_url" : "WH.gov\/FilmFest"
      } ]
    },
    "geo" : { },
    "id_str" : "423265694428323840",
    "text" : "Just watched some of the great submissions for the #WHFilmFest. It's not too late to apply! http:\/\/t.co\/DIDW36nlrl http:\/\/t.co\/i378oKg1Wt",
    "id" : 423265694428323840,
    "created_at" : "2014-01-15 01:29:40 +0000",
    "user" : {
      "name" : "Alex Wall",
      "screen_name" : "Alex44",
      "protected" : false,
      "id_str" : "2169098419",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/632215085256081409\/_vjZ92WM_normal.jpg",
      "id" : 2169098419,
      "verified" : true
    }
  },
  "id" : 423270521782812672,
  "created_at" : "2014-01-15 01:48:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Maria Shriver",
      "screen_name" : "mariashriver",
      "indices" : [ 20, 33 ],
      "id_str" : "19362341",
      "id" : 19362341
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/423257911737868288\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/CWQ8is4afa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bd-21AYCYAAwjw0.jpg",
      "id_str" : "423257911746256896",
      "id" : 423257911746256896,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bd-21AYCYAAwjw0.jpg",
      "sizes" : [ {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/CWQ8is4afa"
    } ],
    "hashtags" : [ {
      "text" : "WhatWomenNeed",
      "indices" : [ 101, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "423258602476810241",
  "text" : "RT @vj44: Thank you @mariashriver for a great meeting with President Obama, and for all your work on #WhatWomenNeed http:\/\/t.co\/CWQ8is4afa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Maria Shriver",
        "screen_name" : "mariashriver",
        "indices" : [ 10, 23 ],
        "id_str" : "19362341",
        "id" : 19362341
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/423257911737868288\/photo\/1",
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/CWQ8is4afa",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bd-21AYCYAAwjw0.jpg",
        "id_str" : "423257911746256896",
        "id" : 423257911746256896,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bd-21AYCYAAwjw0.jpg",
        "sizes" : [ {
          "h" : 733,
          "resize" : "fit",
          "w" : 1100
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/CWQ8is4afa"
      } ],
      "hashtags" : [ {
        "text" : "WhatWomenNeed",
        "indices" : [ 91, 105 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "423257911737868288",
    "text" : "Thank you @mariashriver for a great meeting with President Obama, and for all your work on #WhatWomenNeed http:\/\/t.co\/CWQ8is4afa",
    "id" : 423257911737868288,
    "created_at" : "2014-01-15 00:58:44 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 423258602476810241,
  "created_at" : "2014-01-15 01:01:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "LeBron James",
      "screen_name" : "KingJames",
      "indices" : [ 59, 69 ],
      "id_str" : "23083404",
      "id" : 23083404
    }, {
      "name" : "DWade",
      "screen_name" : "DwyaneWade",
      "indices" : [ 71, 82 ],
      "id_str" : "33995409",
      "id" : 33995409
    }, {
      "name" : "Chris Bosh",
      "screen_name" : "chrisbosh",
      "indices" : [ 84, 94 ],
      "id_str" : "16125042",
      "id" : 16125042
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LetsMove",
      "indices" : [ 110, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "423250604895391745",
  "text" : "RT @FLOTUS: Getting the word out about healthy eating with @KingJames, @DwyaneWade, @ChrisBosh and Ray Allen. #LetsMove, http:\/\/t.co\/7r7w7j\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "LeBron James",
        "screen_name" : "KingJames",
        "indices" : [ 47, 57 ],
        "id_str" : "23083404",
        "id" : 23083404
      }, {
        "name" : "DWade",
        "screen_name" : "DwyaneWade",
        "indices" : [ 59, 70 ],
        "id_str" : "33995409",
        "id" : 33995409
      }, {
        "name" : "Chris Bosh",
        "screen_name" : "chrisbosh",
        "indices" : [ 72, 82 ],
        "id_str" : "16125042",
        "id" : 16125042
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/423249818501120000\/photo\/1",
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/7r7w7jxXQS",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bd-vd6ECAAADQJ2.jpg",
        "id_str" : "423249818333347840",
        "id" : 423249818333347840,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bd-vd6ECAAADQJ2.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 733,
          "resize" : "fit",
          "w" : 1100
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/7r7w7jxXQS"
      } ],
      "hashtags" : [ {
        "text" : "LetsMove",
        "indices" : [ 98, 107 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "423249818501120000",
    "text" : "Getting the word out about healthy eating with @KingJames, @DwyaneWade, @ChrisBosh and Ray Allen. #LetsMove, http:\/\/t.co\/7r7w7jxXQS",
    "id" : 423249818501120000,
    "created_at" : "2014-01-15 00:26:34 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 423250604895391745,
  "created_at" : "2014-01-15 00:29:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/423244558357762048\/photo\/1",
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/ONPPzFamGv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bd-qruhIIAAbQd_.jpg",
      "id_str" : "423244558194188288",
      "id" : 423244558194188288,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bd-qruhIIAAbQd_.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/ONPPzFamGv"
    } ],
    "hashtags" : [ {
      "text" : "SOTUSocial",
      "indices" : [ 42, 53 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/GX84wtNMxz",
      "expanded_url" : "http:\/\/go.wh.gov\/Eewgb4",
      "display_url" : "go.wh.gov\/Eewgb4"
    } ]
  },
  "geo" : { },
  "id_str" : "423244558357762048",
  "text" : "Apply for your chance to join this year's #SOTUSocial at the WhiteHouse \u2192 http:\/\/t.co\/GX84wtNMxz, http:\/\/t.co\/ONPPzFamGv",
  "id" : 423244558357762048,
  "created_at" : "2014-01-15 00:05:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "indices" : [ 3, 12 ],
      "id_str" : "1604366701",
      "id" : 1604366701
    }, {
      "name" : "Eva Longoria Baston",
      "screen_name" : "EvaLongoria",
      "indices" : [ 75, 87 ],
      "id_str" : "110827653",
      "id" : 110827653
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PayGap",
      "indices" : [ 26, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "423232197387382784",
  "text" : "RT @LaborSec: Closing the #PayGap is an economic necessity. Great essay by @EvaLongoria on giving women opportunities to succeed: http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Eva Longoria Baston",
        "screen_name" : "EvaLongoria",
        "indices" : [ 61, 73 ],
        "id_str" : "110827653",
        "id" : 110827653
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PayGap",
        "indices" : [ 12, 19 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/Ur6NyPHtWK",
        "expanded_url" : "http:\/\/shriverreport.org\/empowering-latinas-eva-longoria\/",
        "display_url" : "shriverreport.org\/empowering-lat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "423224097397821440",
    "text" : "Closing the #PayGap is an economic necessity. Great essay by @EvaLongoria on giving women opportunities to succeed: http:\/\/t.co\/Ur6NyPHtWK",
    "id" : 423224097397821440,
    "created_at" : "2014-01-14 22:44:22 +0000",
    "user" : {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "protected" : false,
      "id_str" : "1604366701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744887280666611712\/eEeyFjs6_normal.jpg",
      "id" : 1604366701,
      "verified" : true
    }
  },
  "id" : 423232197387382784,
  "created_at" : "2014-01-14 23:16:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aisha Tyler",
      "screen_name" : "aishatyler",
      "indices" : [ 38, 49 ],
      "id_str" : "18125335",
      "id" : 18125335
    }, {
      "name" : "Funny Or Die",
      "screen_name" : "funnyordie",
      "indices" : [ 54, 65 ],
      "id_str" : "15693493",
      "id" : 15693493
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 0, 11 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/iqVmbVn747",
      "expanded_url" : "http:\/\/FunnyOrDie.com\/m\/8il1",
      "display_url" : "FunnyOrDie.com\/m\/8il1"
    } ]
  },
  "geo" : { },
  "id_str" : "423199705321832448",
  "text" : "#GetCovered because\u2026accidents happen. @AishaTyler and @FunnyOrDie on why it's so important to get health coverage: http:\/\/t.co\/iqVmbVn747",
  "id" : 423199705321832448,
  "created_at" : "2014-01-14 21:07:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 3, 12 ],
      "id_str" : "36719281",
      "id" : 36719281
    }, {
      "name" : "NBA",
      "screen_name" : "NBA",
      "indices" : [ 84, 88 ],
      "id_str" : "19923144",
      "id" : 19923144
    }, {
      "name" : "Miami HEAT",
      "screen_name" : "MiamiHEAT",
      "indices" : [ 98, 108 ],
      "id_str" : "11026952",
      "id" : 11026952
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 116, 127 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "423177627864559617",
  "text" : "RT @letsmove: Tune in at 2:45 p.m. ET today to watch President Obama honor the 2013 @NBA Champion @MiamiHEAT to the @WhiteHouse: http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NBA",
        "screen_name" : "NBA",
        "indices" : [ 70, 74 ],
        "id_str" : "19923144",
        "id" : 19923144
      }, {
        "name" : "Miami HEAT",
        "screen_name" : "MiamiHEAT",
        "indices" : [ 84, 94 ],
        "id_str" : "11026952",
        "id" : 11026952
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 102, 113 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/lS3qNyF80x",
        "expanded_url" : "http:\/\/WH.gov\/live",
        "display_url" : "WH.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "423172618884104192",
    "text" : "Tune in at 2:45 p.m. ET today to watch President Obama honor the 2013 @NBA Champion @MiamiHEAT to the @WhiteHouse: http:\/\/t.co\/lS3qNyF80x",
    "id" : 423172618884104192,
    "created_at" : "2014-01-14 19:19:49 +0000",
    "user" : {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "protected" : false,
      "id_str" : "36719281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207340336\/780fc13e31b6fdd80bd57d000dc13838_normal.jpeg",
      "id" : 36719281,
      "verified" : true
    }
  },
  "id" : 423177627864559617,
  "created_at" : "2014-01-14 19:39:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 74, 85 ]
    }, {
      "text" : "EnrollTide",
      "indices" : [ 86, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/iz5umQviM2",
      "expanded_url" : "http:\/\/bit.ly\/1a2WE7M",
      "display_url" : "bit.ly\/1a2WE7M"
    } ]
  },
  "geo" : { },
  "id_str" : "423167749007757312",
  "text" : "\"More Alabamians signing up for health insurance.\" http:\/\/t.co\/iz5umQviM2 #GetCovered #EnrollTide",
  "id" : 423167749007757312,
  "created_at" : "2014-01-14 19:00:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 79, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/uvXCniOFSK",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    }, {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/f9nTJiT8dd",
      "expanded_url" : "http:\/\/bit.ly\/1hQSlyX",
      "display_url" : "bit.ly\/1hQSlyX"
    } ]
  },
  "geo" : { },
  "id_str" : "423150128610820096",
  "text" : "\"New Mexico's http:\/\/t.co\/uvXCniOFSK enrollment soars.\" http:\/\/t.co\/f9nTJiT8dd #GetCovered",
  "id" : 423150128610820096,
  "created_at" : "2014-01-14 17:50:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Detroit Free Press",
      "screen_name" : "freep",
      "indices" : [ 1, 7 ],
      "id_str" : "8795772",
      "id" : 8795772
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 87, 91 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 117, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/byD1dU3S5R",
      "expanded_url" : "http:\/\/on.freep.com\/1fsMQpF",
      "display_url" : "on.freep.com\/1fsMQpF"
    } ]
  },
  "geo" : { },
  "id_str" : "423142578460954625",
  "text" : ".@FreeP: \"Health insurance enrollment takes off in Michigan, nation for coverage under #ACA.\" http:\/\/t.co\/byD1dU3S5R #GetCovered",
  "id" : 423142578460954625,
  "created_at" : "2014-01-14 17:20:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 124, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/dACF0ZfZWr",
      "expanded_url" : "http:\/\/bit.ly\/1lWK7VZ",
      "display_url" : "bit.ly\/1lWK7VZ"
    } ]
  },
  "geo" : { },
  "id_str" : "423135028625682433",
  "text" : "FACT: More than 61,000 Illinoisans enrolled in coverage through the Affordable Care Act last month \u2192 http:\/\/t.co\/dACF0ZfZWr #GetCovered",
  "id" : 423135028625682433,
  "created_at" : "2014-01-14 16:50:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Cabinet",
      "screen_name" : "Cabinet",
      "indices" : [ 3, 11 ],
      "id_str" : "1854981890",
      "id" : 1854981890
    }, {
      "name" : "The Cabinet",
      "screen_name" : "Cabinet",
      "indices" : [ 19, 27 ],
      "id_str" : "1854981890",
      "id" : 1854981890
    }, {
      "name" : "Homeland Security",
      "screen_name" : "DHSgov",
      "indices" : [ 50, 57 ],
      "id_str" : "15647676",
      "id" : 15647676
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "423128550124695552",
  "text" : "RT @Cabinet: First @Cabinet meeting today for new @DHSgov Sec. Jeh Johnson. Chair and plaque ready and awaiting his arrival. http:\/\/t.co\/qo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Cabinet",
        "screen_name" : "Cabinet",
        "indices" : [ 6, 14 ],
        "id_str" : "1854981890",
        "id" : 1854981890
      }, {
        "name" : "Homeland Security",
        "screen_name" : "DHSgov",
        "indices" : [ 37, 44 ],
        "id_str" : "15647676",
        "id" : 15647676
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Cabinet\/status\/423122387660337152\/photo\/1",
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/qoX0gwjfHI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bd87kd1CcAAO9cY.jpg",
        "id_str" : "423122387664531456",
        "id" : 423122387664531456,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bd87kd1CcAAO9cY.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 610,
          "resize" : "fit",
          "w" : 610
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 610,
          "resize" : "fit",
          "w" : 610
        } ],
        "display_url" : "pic.twitter.com\/qoX0gwjfHI"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "423122387660337152",
    "text" : "First @Cabinet meeting today for new @DHSgov Sec. Jeh Johnson. Chair and plaque ready and awaiting his arrival. http:\/\/t.co\/qoX0gwjfHI",
    "id" : 423122387660337152,
    "created_at" : "2014-01-14 16:00:13 +0000",
    "user" : {
      "name" : "The Cabinet",
      "screen_name" : "Cabinet",
      "protected" : false,
      "id_str" : "1854981890",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000444833438\/6f96900dcf05562d4e699ae28d7861c6_normal.jpeg",
      "id" : 1854981890,
      "verified" : true
    }
  },
  "id" : 423128550124695552,
  "created_at" : "2014-01-14 16:24:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Cabinet",
      "screen_name" : "Cabinet",
      "indices" : [ 51, 59 ],
      "id_str" : "1854981890",
      "id" : 1854981890
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/423120060677255168\/photo\/1",
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/A2VLxEEidn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bd85c__CcAAMbT3.png",
      "id_str" : "423120060371070976",
      "id" : 423120060371070976,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bd85c__CcAAMbT3.png",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 611,
        "resize" : "fit",
        "w" : 611
      }, {
        "h" : 611,
        "resize" : "fit",
        "w" : 611
      } ],
      "display_url" : "pic.twitter.com\/A2VLxEEidn"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "423120060677255168",
  "text" : "No bones about it, Bo's looking forward to today's @Cabinet meeting. http:\/\/t.co\/A2VLxEEidn",
  "id" : 423120060677255168,
  "created_at" : "2014-01-14 15:50:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOTU",
      "indices" : [ 133, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/4YADppqzGk",
      "expanded_url" : "http:\/\/go.wh.gov\/nsihh5",
      "display_url" : "go.wh.gov\/nsihh5"
    } ]
  },
  "geo" : { },
  "id_str" : "423112201402994688",
  "text" : "Two weeks from today, President Obama will deliver his 5th State of the Union. Here's what you need to know \u2192 http:\/\/t.co\/4YADppqzGk #SOTU",
  "id" : 423112201402994688,
  "created_at" : "2014-01-14 15:19:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/422888531640729600\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/IfnkESxCB2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bd5m4PnIMAAan8C.jpg",
      "id_str" : "422888531468759040",
      "id" : 422888531468759040,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bd5m4PnIMAAan8C.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/IfnkESxCB2"
    } ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 14, 18 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 103, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "422888531640729600",
  "text" : "Thanks to the #ACA:\n1. 2.2 million Americans signed up for health coverage\n2. 30% of them are under 35\n#GetCovered, http:\/\/t.co\/IfnkESxCB2",
  "id" : 422888531640729600,
  "created_at" : "2014-01-14 00:30:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 114, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/KslWmHm4DG",
      "expanded_url" : "http:\/\/go.wh.gov\/ceDoUm",
      "display_url" : "go.wh.gov\/ceDoUm"
    } ]
  },
  "geo" : { },
  "id_str" : "422882583081259008",
  "text" : "In the states: Affordable Care Act enrollment \"soars,\" \"spikes,\" surges,\" and \"takes off.\" http:\/\/t.co\/KslWmHm4DG #GetCovered",
  "id" : 422882583081259008,
  "created_at" : "2014-01-14 00:07:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 69, 79 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 111, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "422860101293064192",
  "text" : "FACT: 30% of Americans who signed up for health coverage through the #Obamacare marketplaces are under age 35. #GetCovered",
  "id" : 422860101293064192,
  "created_at" : "2014-01-13 22:37:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YI",
      "screen_name" : "YI_Care",
      "indices" : [ 3, 11 ],
      "id_str" : "2510807636",
      "id" : 2510807636
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "healthcare",
      "indices" : [ 58, 69 ]
    }, {
      "text" : "Obamacare",
      "indices" : [ 78, 88 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 113, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "422848950815948801",
  "text" : "RT @YI_Care: And they said young people didn't care about #healthcare. 30% of #Obamacare enrollees under age 35. #GetCovered http:\/\/t.co\/6o\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/YI_Care\/status\/422841981119655936\/photo\/1",
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/6o0qHKkeDj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bd48iplCUAElCgS.png",
        "id_str" : "422841980993818625",
        "id" : 422841980993818625,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bd48iplCUAElCgS.png",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/6o0qHKkeDj"
      } ],
      "hashtags" : [ {
        "text" : "healthcare",
        "indices" : [ 45, 56 ]
      }, {
        "text" : "Obamacare",
        "indices" : [ 65, 75 ]
      }, {
        "text" : "GetCovered",
        "indices" : [ 100, 111 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "422841981119655936",
    "text" : "And they said young people didn't care about #healthcare. 30% of #Obamacare enrollees under age 35. #GetCovered http:\/\/t.co\/6o0qHKkeDj",
    "id" : 422841981119655936,
    "created_at" : "2014-01-13 21:25:58 +0000",
    "user" : {
      "name" : "Young Invincibles",
      "screen_name" : "YoungInvincible",
      "protected" : false,
      "id_str" : "67215899",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/691632503577161728\/Zj3TLgji_normal.png",
      "id" : 67215899,
      "verified" : false
    }
  },
  "id" : 422848950815948801,
  "created_at" : "2014-01-13 21:53:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 0, 4 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 132, 143 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "422842327527198720",
  "text" : "#ACA enrollment is ramping up: December sign-ups were more than 6 times greater than the combined total for October &amp; November. #GetCovered",
  "id" : 422842327527198720,
  "created_at" : "2014-01-13 21:27:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 76, 86 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 120, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "422840061122461696",
  "text" : "Share the news: 1 out of 4 Americans who signed up for coverage through the #Obamacare exchanges are between 18 and 24. #GetCovered",
  "id" : 422840061122461696,
  "created_at" : "2014-01-13 21:18:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/422829398954221569\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/R9LpnarwGn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bd4xGRTCUAEBP0Y.jpg",
      "id_str" : "422829398811627521",
      "id" : 422829398811627521,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bd4xGRTCUAEBP0Y.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/R9LpnarwGn"
    } ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 79, 83 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 101, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "422829398954221569",
  "text" : "JoAnn S. from Florida hasn't been able to get insured for years. Thanks to the #ACA, she was able to #GetCovered. http:\/\/t.co\/R9LpnarwGn",
  "id" : 422829398954221569,
  "created_at" : "2014-01-13 20:35:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/422814570906783744\/photo\/1",
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/LbhAUmRBID",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bd4jnKWCAAAf1VD.jpg",
      "id_str" : "422814570718035968",
      "id" : 422814570718035968,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bd4jnKWCAAAf1VD.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/LbhAUmRBID"
    } ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 19, 23 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/PIFxR1CJrJ",
      "expanded_url" : "http:\/\/go.wh.gov\/hG7nZm",
      "display_url" : "go.wh.gov\/hG7nZm"
    } ]
  },
  "geo" : { },
  "id_str" : "422814570906783744",
  "text" : "\"Thank you for the #ACA. It is a life changer.\" \u2014Brian F. from Florida: http:\/\/t.co\/PIFxR1CJrJ, http:\/\/t.co\/LbhAUmRBID",
  "id" : 422814570906783744,
  "created_at" : "2014-01-13 19:37:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 3, 11 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHFilmFest",
      "indices" : [ 115, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "422803010956165120",
  "text" : "RT @DrBiden: Technology plays a huge role in helping kids learn. Show us how your school uses tech by entering the #WHFilmFest: http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHFilmFest",
        "indices" : [ 102, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/hWa8yKMAKT",
        "expanded_url" : "http:\/\/WH.gov\/filmfest",
        "display_url" : "WH.gov\/filmfest"
      } ]
    },
    "geo" : { },
    "id_str" : "422791730404921344",
    "text" : "Technology plays a huge role in helping kids learn. Show us how your school uses tech by entering the #WHFilmFest: http:\/\/t.co\/hWa8yKMAKT",
    "id" : 422791730404921344,
    "created_at" : "2014-01-13 18:06:18 +0000",
    "user" : {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "protected" : false,
      "id_str" : "1281405877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608687663034474496\/wvzVG_yt_normal.jpg",
      "id" : 1281405877,
      "verified" : true
    }
  },
  "id" : 422803010956165120,
  "created_at" : "2014-01-13 18:51:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/422797810137063424\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/WePpkEyAmt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bd4UXjsIcAAW0kf.jpg",
      "id_str" : "422797809969295360",
      "id" : 422797809969295360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bd4UXjsIcAAW0kf.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/WePpkEyAmt"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 103, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "422797810137063424",
  "text" : "Thanks to the ACA, Kelly M. from MD no longer has to spend half her paycheck at an urgent care center. #GetCovered, http:\/\/t.co\/WePpkEyAmt",
  "id" : 422797810137063424,
  "created_at" : "2014-01-13 18:30:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 97, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/56Fo9JxGrh",
      "expanded_url" : "http:\/\/go.wh.gov\/AzcRnD",
      "display_url" : "go.wh.gov\/AzcRnD"
    } ]
  },
  "geo" : { },
  "id_str" : "422790253284323328",
  "text" : "Every American should have the peace of mind that comes from getting health coverage. Share your #GetCovered story \u2192 http:\/\/t.co\/56Fo9JxGrh",
  "id" : 422790253284323328,
  "created_at" : "2014-01-13 18:00:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 129, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/IwEgVWEswF",
      "expanded_url" : "http:\/\/go.wh.gov\/4L2s7n",
      "display_url" : "go.wh.gov\/4L2s7n"
    } ]
  },
  "geo" : { },
  "id_str" : "422782642325426176",
  "text" : "Thanks to the ACA, Rachelle L.'s daughter\u2014who has a kidney disease\u2014reduced her premium by more than half: http:\/\/t.co\/IwEgVWEswF #GetCovered",
  "id" : 422782642325426176,
  "created_at" : "2014-01-13 17:30:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 125, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "422767601555492864",
  "text" : "\"I can't describe just how life changing this is...we can afford to live again.\" \u2014Gayla W. on getting coverage for $87\/month #GetCovered",
  "id" : 422767601555492864,
  "created_at" : "2014-01-13 16:30:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 12, 16 ]
    } ],
    "urls" : [ {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/4LIMtijZxp",
      "expanded_url" : "http:\/\/go.wh.gov\/3U8Wof",
      "display_url" : "go.wh.gov\/3U8Wof"
    } ]
  },
  "geo" : { },
  "id_str" : "422759753060601856",
  "text" : "Without the #ACA, Stella R.'s medical expenses \"would wipe out any savings I have &amp; leave me medically at high risk.\" http:\/\/t.co\/4LIMtijZxp",
  "id" : 422759753060601856,
  "created_at" : "2014-01-13 15:59:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/4UaQOm0z95",
      "expanded_url" : "http:\/\/go.wh.gov\/UwMLPz",
      "display_url" : "go.wh.gov\/UwMLPz"
    } ]
  },
  "geo" : { },
  "id_str" : "422541105079394305",
  "text" : "\"I\u2019ll keep doing everything I can to create new jobs and new opportunities for American families.\" \u2014President Obama: http:\/\/t.co\/4UaQOm0z95",
  "id" : 422541105079394305,
  "created_at" : "2014-01-13 01:30:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WestWingWeek",
      "indices" : [ 0, 13 ]
    }, {
      "text" : "OpportunityforAll",
      "indices" : [ 39, 57 ]
    }, {
      "text" : "RenewUI",
      "indices" : [ 76, 84 ]
    }, {
      "text" : "PolarVortex",
      "indices" : [ 95, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 142 ],
      "url" : "http:\/\/t.co\/JVFL2H9BNG",
      "expanded_url" : "http:\/\/go.wh.gov\/yjeFpL",
      "display_url" : "go.wh.gov\/yjeFpL"
    } ]
  },
  "geo" : { },
  "id_str" : "422424082173288452",
  "text" : "#WestWingWeek: The President speaks on #OpportunityforAll &amp; the need to #RenewUI. Plus the #PolarVortex explained \u2192 http:\/\/t.co\/JVFL2H9BNG",
  "id" : 422424082173288452,
  "created_at" : "2014-01-12 17:45:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RenewUI",
      "indices" : [ 129, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/gX4ViASd2C",
      "expanded_url" : "http:\/\/go.wh.gov\/ioAZ3p",
      "display_url" : "go.wh.gov\/ioAZ3p"
    } ]
  },
  "geo" : { },
  "id_str" : "422393883096412162",
  "text" : "\"This vital economic lifeline helps people support their families while they look for a new job.\" \u2014Obama: http:\/\/t.co\/gX4ViASd2C #RenewUI",
  "id" : 422393883096412162,
  "created_at" : "2014-01-12 15:45:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WestWingWeek",
      "indices" : [ 113, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/VjzVNxB0Zs",
      "expanded_url" : "http:\/\/go.wh.gov\/J1vvko",
      "display_url" : "go.wh.gov\/J1vvko"
    } ]
  },
  "geo" : { },
  "id_str" : "422190035786420225",
  "text" : "Don't miss this behind-the-scenes look at President Obama's week at the White House \u2014&gt; http:\/\/t.co\/VjzVNxB0Zs #WestWingWeek",
  "id" : 422190035786420225,
  "created_at" : "2014-01-12 02:15:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/422167582452359168\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/0oKSbAzDUO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BdvXLeuCQAEBdOE.jpg",
      "id_str" : "422167582313955329",
      "id" : 422167582313955329,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BdvXLeuCQAEBdOE.jpg",
      "sizes" : [ {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/0oKSbAzDUO"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/Dx5e4rJDnb",
      "expanded_url" : "http:\/\/go.wh.gov\/2Bx3ue",
      "display_url" : "go.wh.gov\/2Bx3ue"
    } ]
  },
  "geo" : { },
  "id_str" : "422167582452359168",
  "text" : "\"Since I took office, we\u2019ve cut our deficits by more than half.\" \u2014President Obama: http:\/\/t.co\/Dx5e4rJDnb, http:\/\/t.co\/0oKSbAzDUO",
  "id" : 422167582452359168,
  "created_at" : "2014-01-12 00:46:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/422140159174262784\/photo\/1",
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/7XbNncmHmT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bdu-PONCAAEkN7F.jpg",
      "id_str" : "422140158809341953",
      "id" : 422140158809341953,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bdu-PONCAAEkN7F.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/7XbNncmHmT"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/Ifoe6Nb5pq",
      "expanded_url" : "http:\/\/go.wh.gov\/ZFmAfg",
      "display_url" : "go.wh.gov\/ZFmAfg"
    } ]
  },
  "geo" : { },
  "id_str" : "422140159174262784",
  "text" : "\"In 2013, our businesses created 2.2 million new jobs.\" \u2014President Obama: http:\/\/t.co\/Ifoe6Nb5pq, http:\/\/t.co\/7XbNncmHmT",
  "id" : 422140159174262784,
  "created_at" : "2014-01-11 22:57:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RenewUI",
      "indices" : [ 127, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/OTa1kFpMHh",
      "expanded_url" : "http:\/\/go.wh.gov\/x2RpFa",
      "display_url" : "go.wh.gov\/x2RpFa"
    } ]
  },
  "geo" : { },
  "id_str" : "422073012095942660",
  "text" : "\"The Senate took the 1st steps toward making this right. But Congress needs to finish the job.\" \u2014Obama: http:\/\/t.co\/OTa1kFpMHh #RenewUI",
  "id" : 422073012095942660,
  "created_at" : "2014-01-11 18:30:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/KZLrEAkGHu",
      "expanded_url" : "http:\/\/go.wh.gov\/tyQGjH",
      "display_url" : "go.wh.gov\/tyQGjH"
    } ]
  },
  "geo" : { },
  "id_str" : "422023938172928001",
  "text" : "\"I will mobilize the country around...making sure our economy offers everyone who works hard a fair shot.\" \u2014Obama: http:\/\/t.co\/KZLrEAkGHu",
  "id" : 422023938172928001,
  "created_at" : "2014-01-11 15:15:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/421801910937481216\/photo\/1",
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/0e2075cbb2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BdqKmmPCAAEB_P6.jpg",
      "id_str" : "421801910815817729",
      "id" : 421801910815817729,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BdqKmmPCAAEB_P6.jpg",
      "sizes" : [ {
        "h" : 446,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 253,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 760,
        "resize" : "fit",
        "w" : 1023
      }, {
        "h" : 760,
        "resize" : "fit",
        "w" : 1023
      } ],
      "display_url" : "pic.twitter.com\/0e2075cbb2"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "421801910937481216",
  "text" : "\u2708 Baby Force One \u2708 http:\/\/t.co\/0e2075cbb2",
  "id" : 421801910937481216,
  "created_at" : "2014-01-11 00:33:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/421775825537482752\/photo\/1",
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/7qzu8u2blm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bdpy4NTCQAEyKS8.png",
      "id_str" : "421775825080303617",
      "id" : 421775825080303617,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bdpy4NTCQAEyKS8.png",
      "sizes" : [ {
        "h" : 336,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 994,
        "resize" : "fit",
        "w" : 1775
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 573,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 190,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/7qzu8u2blm"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/LO1ocdsj5R",
      "expanded_url" : "http:\/\/instagram.com\/p\/jAU6sOQiqP\/",
      "display_url" : "instagram.com\/p\/jAU6sOQiqP\/"
    } ]
  },
  "geo" : { },
  "id_str" : "421775825537482752",
  "text" : "Happy Friday! http:\/\/t.co\/LO1ocdsj5R, http:\/\/t.co\/7qzu8u2blm",
  "id" : 421775825537482752,
  "created_at" : "2014-01-10 22:49:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 15, 25 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 122, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/PIFxR1CJrJ",
      "expanded_url" : "http:\/\/go.wh.gov\/hG7nZm",
      "display_url" : "go.wh.gov\/hG7nZm"
    } ]
  },
  "geo" : { },
  "id_str" : "421748371288637441",
  "text" : "\"Thank god for #Obamacare\u2026it may well end up saving her life.\" \u2014Elina K. from Colorado on her mom: http:\/\/t.co\/PIFxR1CJrJ #GetCovered",
  "id" : 421748371288637441,
  "created_at" : "2014-01-10 21:00:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 114, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/59hgL1TkLS",
      "expanded_url" : "http:\/\/go.wh.gov\/cXajuM",
      "display_url" : "go.wh.gov\/cXajuM"
    } ]
  },
  "geo" : { },
  "id_str" : "421742080482742273",
  "text" : "Hear the stories of Americans who have health coverage thanks to the Affordable Care Act \u2192 http:\/\/t.co\/59hgL1TkLS #GetCovered",
  "id" : 421742080482742273,
  "created_at" : "2014-01-10 20:35:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 65, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/QLyfmJDFoR",
      "expanded_url" : "http:\/\/go.wh.gov\/L2ipS4",
      "display_url" : "go.wh.gov\/L2ipS4"
    } ]
  },
  "geo" : { },
  "id_str" : "421725719123607554",
  "text" : "You don't want to miss this: Watch President Obama on increasing #OpportunityForAll our kids \u2192 http:\/\/t.co\/QLyfmJDFoR",
  "id" : 421725719123607554,
  "created_at" : "2014-01-10 19:30:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WeTheGeeks",
      "indices" : [ 19, 30 ]
    }, {
      "text" : "PolarVortex",
      "indices" : [ 46, 58 ]
    }, {
      "text" : "ActOnClimate",
      "indices" : [ 94, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/pJ5PHF6VSf",
      "expanded_url" : "http:\/\/wh.gov\/we-the-geeks",
      "display_url" : "wh.gov\/we-the-geeks"
    }, {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/jU5s7GnZBo",
      "expanded_url" : "http:\/\/youtu.be\/5eDTzV6a9F4",
      "display_url" : "youtu.be\/5eDTzV6a9F4"
    } ]
  },
  "geo" : { },
  "id_str" : "421716166261100544",
  "text" : "Don't miss today's #WeTheGeeks Hangout on the #PolarVortex at 2pm ET \u2192 http:\/\/t.co\/pJ5PHF6VSf #ActOnClimate, http:\/\/t.co\/jU5s7GnZBo",
  "id" : 421716166261100544,
  "created_at" : "2014-01-10 18:52:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/f1inqPm3kg",
      "expanded_url" : "http:\/\/go.wh.gov\/EVYWNL",
      "display_url" : "go.wh.gov\/EVYWNL"
    } ]
  },
  "geo" : { },
  "id_str" : "421708473198321664",
  "text" : "Same-sex marriages in Utah will be recognized as lawful and couples will be eligible for federal benefits \u2192 http:\/\/t.co\/f1inqPm3kg",
  "id" : 421708473198321664,
  "created_at" : "2014-01-10 18:21:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Utech",
      "screen_name" : "Utech44",
      "indices" : [ 3, 11 ],
      "id_str" : "2283772130",
      "id" : 2283772130
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WeTheGeeks",
      "indices" : [ 50, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "421702625784909825",
  "text" : "RT @Utech44: Join me and top experts at 2pm for a #WeTheGeeks Google+ Hangout on the \u2018Polar Vortex\u2019 and Extreme Weather \u2192 http:\/\/t.co\/4lyFE\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WeTheGeeks",
        "indices" : [ 37, 48 ]
      } ],
      "urls" : [ {
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/4lyFE6pVXH",
        "expanded_url" : "http:\/\/wh.gov\/lXH6C",
        "display_url" : "wh.gov\/lXH6C"
      } ]
    },
    "geo" : { },
    "id_str" : "421690334926499840",
    "text" : "Join me and top experts at 2pm for a #WeTheGeeks Google+ Hangout on the \u2018Polar Vortex\u2019 and Extreme Weather \u2192 http:\/\/t.co\/4lyFE6pVXH",
    "id" : 421690334926499840,
    "created_at" : "2014-01-10 17:09:45 +0000",
    "user" : {
      "name" : "Dan Utech",
      "screen_name" : "Utech44",
      "protected" : false,
      "id_str" : "2283772130",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705138779221135360\/UcDKamCq_normal.jpg",
      "id" : 2283772130,
      "verified" : true
    }
  },
  "id" : 421702625784909825,
  "created_at" : "2014-01-10 17:58:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/1KhYphFI02",
      "expanded_url" : "http:\/\/go.wh.gov\/bok734",
      "display_url" : "go.wh.gov\/bok734"
    } ]
  },
  "geo" : { },
  "id_str" : "421682934978859008",
  "text" : "Last year:\n1. Our businesses created 2.2 million jobs\n2. The unemployment rate declined by 1.2%\nMore work to do \u2192\nhttp:\/\/t.co\/1KhYphFI02",
  "id" : 421682934978859008,
  "created_at" : "2014-01-10 16:40:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/421672788219265024\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/aLfuVGTNQE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BdoVKqWCIAA-btK.jpg",
      "id_str" : "421672788022140928",
      "id" : 421672788022140928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BdoVKqWCIAA-btK.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/aLfuVGTNQE"
    } ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 96, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "421672788219265024",
  "text" : "Our businesses have added 8.2 million jobs over the past 46 months\u2014but there's more work to do. #OpportunityForAll, http:\/\/t.co\/aLfuVGTNQE",
  "id" : 421672788219265024,
  "created_at" : "2014-01-10 16:00:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 116, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/RlaMv5l9ew",
      "expanded_url" : "http:\/\/go.wh.gov\/EdRdNP",
      "display_url" : "go.wh.gov\/EdRdNP"
    } ]
  },
  "geo" : { },
  "id_str" : "421443459828822016",
  "text" : "\"Anybody in this country who works hard should have a fair shot at success, period.\" \u2014Obama: http:\/\/t.co\/RlaMv5l9ew #OpportunityForAll",
  "id" : 421443459828822016,
  "created_at" : "2014-01-10 00:48:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sheldon Whitehouse",
      "screen_name" : "SenWhitehouse",
      "indices" : [ 3, 17 ],
      "id_str" : "242555999",
      "id" : 242555999
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 24, 35 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "polarvortex",
      "indices" : [ 74, 86 ]
    }, {
      "text" : "ActOnClimate",
      "indices" : [ 111, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/CdjCy5yTqi",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=5eDTzV6a9F4",
      "display_url" : "youtube.com\/watch?v=5eDTzV\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421436832287842305",
  "text" : "RT @SenWhitehouse: This @WhiteHouse video sets the record straight on the #polarvortex: http:\/\/t.co\/CdjCy5yTqi #ActOnClimate",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 5, 16 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "polarvortex",
        "indices" : [ 55, 67 ]
      }, {
        "text" : "ActOnClimate",
        "indices" : [ 92, 105 ]
      } ],
      "urls" : [ {
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/CdjCy5yTqi",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=5eDTzV6a9F4",
        "display_url" : "youtube.com\/watch?v=5eDTzV\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "421435582946893824",
    "text" : "This @WhiteHouse video sets the record straight on the #polarvortex: http:\/\/t.co\/CdjCy5yTqi #ActOnClimate",
    "id" : 421435582946893824,
    "created_at" : "2014-01-10 00:17:27 +0000",
    "user" : {
      "name" : "Sheldon Whitehouse",
      "screen_name" : "SenWhitehouse",
      "protected" : false,
      "id_str" : "242555999",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000051321410\/55ff7ed4f6264c8eec19a81a66be6bb0_normal.png",
      "id" : 242555999,
      "verified" : true
    }
  },
  "id" : 421436832287842305,
  "created_at" : "2014-01-10 00:22:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "-",
      "screen_name" : "LAMayorsOffice",
      "indices" : [ 3, 18 ],
      "id_str" : "3433610303",
      "id" : 3433610303
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/LAMayorsOffice\/status\/421374322238705664\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/4u92Wi4JYj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BdkFtqsCUAAkkHX.jpg",
      "id_str" : "421374322247094272",
      "id" : 421374322247094272,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BdkFtqsCUAAkkHX.jpg",
      "sizes" : [ {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/4u92Wi4JYj"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "421393971752230913",
  "text" : "RT @LAMayorsOffice: Proud to be designated as one of just five presidential Promise Zones in the nation. http:\/\/t.co\/4u92Wi4JYj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/LAMayorsOffice\/status\/421374322238705664\/photo\/1",
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/4u92Wi4JYj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BdkFtqsCUAAkkHX.jpg",
        "id_str" : "421374322247094272",
        "id" : 421374322247094272,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BdkFtqsCUAAkkHX.jpg",
        "sizes" : [ {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/4u92Wi4JYj"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "421374322238705664",
    "text" : "Proud to be designated as one of just five presidential Promise Zones in the nation. http:\/\/t.co\/4u92Wi4JYj",
    "id" : 421374322238705664,
    "created_at" : "2014-01-09 20:14:02 +0000",
    "user" : {
      "name" : "Mayor of Los Angeles",
      "screen_name" : "MayorOfLA",
      "protected" : false,
      "id_str" : "17070113",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758035630441889792\/JPfM_c3Z_normal.jpg",
      "id" : 17070113,
      "verified" : true
    }
  },
  "id" : 421393971752230913,
  "created_at" : "2014-01-09 21:32:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcia Snyder",
      "screen_name" : "GovSteveBeshear",
      "indices" : [ 3, 19 ],
      "id_str" : "4549215252",
      "id" : 4549215252
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EKY",
      "indices" : [ 44, 48 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/43O68xGyge",
      "expanded_url" : "http:\/\/1.usa.gov\/19gbZkT",
      "display_url" : "1.usa.gov\/19gbZkT"
    } ]
  },
  "geo" : { },
  "id_str" : "421387794276417536",
  "text" : "RT @GovSteveBeshear: Eight-county region in #EKY is 1 of 5 Promise Zones in the nation this year.  More @ http:\/\/t.co\/43O68xGyge #promisezo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "SOAR",
        "screen_name" : "SOAR_EKY",
        "indices" : [ 122, 131 ],
        "id_str" : "2196373082",
        "id" : 2196373082
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EKY",
        "indices" : [ 23, 27 ]
      }, {
        "text" : "promisezones",
        "indices" : [ 108, 121 ]
      } ],
      "urls" : [ {
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/43O68xGyge",
        "expanded_url" : "http:\/\/1.usa.gov\/19gbZkT",
        "display_url" : "1.usa.gov\/19gbZkT"
      } ]
    },
    "geo" : { },
    "id_str" : "421340164770631681",
    "text" : "Eight-county region in #EKY is 1 of 5 Promise Zones in the nation this year.  More @ http:\/\/t.co\/43O68xGyge #promisezones @SOAR_EKY",
    "id" : 421340164770631681,
    "created_at" : "2014-01-09 17:58:18 +0000",
    "user" : {
      "name" : "Steve Beshear",
      "screen_name" : "Steve__Beshear",
      "protected" : false,
      "id_str" : "37656339",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/674302651681648640\/9IZtv6cB_normal.jpg",
      "id" : 37656339,
      "verified" : false
    }
  },
  "id" : 421387794276417536,
  "created_at" : "2014-01-09 21:07:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Utech",
      "screen_name" : "Utech44",
      "indices" : [ 3, 11 ],
      "id_str" : "2283772130",
      "id" : 2283772130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "421378050673369088",
  "text" : "RT @Utech44: Hey, guys! Excited to start tweeting. Follow along for the latest on President Obama's energy and climate change initiatives. \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 126, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "421377488590098433",
    "text" : "Hey, guys! Excited to start tweeting. Follow along for the latest on President Obama's energy and climate change initiatives. #ActOnClimate",
    "id" : 421377488590098433,
    "created_at" : "2014-01-09 20:26:36 +0000",
    "user" : {
      "name" : "Dan Utech",
      "screen_name" : "Utech44",
      "protected" : false,
      "id_str" : "2283772130",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705138779221135360\/UcDKamCq_normal.jpg",
      "id" : 2283772130,
      "verified" : true
    }
  },
  "id" : 421378050673369088,
  "created_at" : "2014-01-09 20:28:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael A. Nutter",
      "screen_name" : "Michael_Nutter",
      "indices" : [ 3, 18 ],
      "id_str" : "202790178",
      "id" : 202790178
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Michael_Nutter\/status\/421361803831312384\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/VkNwB5RqZj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bdj6U_jIQAAesD7.jpg",
      "id_str" : "421361803722244096",
      "id" : 421361803722244096,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bdj6U_jIQAAesD7.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/VkNwB5RqZj"
    } ],
    "hashtags" : [ {
      "text" : "PromiseZone",
      "indices" : [ 38, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "421371627184467968",
  "text" : "RT @Michael_Nutter: Pres Obama at the #PromiseZone designation announcement. Phila is proud to receive this award. http:\/\/t.co\/VkNwB5RqZj",
  "id" : 421371627184467968,
  "created_at" : "2014-01-09 20:03:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 110, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "421368696380993537",
  "text" : "President Obama: \"We should all want every one of our kids and their families to have every shot at success.\" #OpportunityForAll",
  "id" : 421368696380993537,
  "created_at" : "2014-01-09 19:51:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 121, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "421367484558479360",
  "text" : "President Obama: \"If Roger can make it and if I can make it and if Kiara can make it, every kid in America can make it.\" #OpportunityForAll",
  "id" : 421367484558479360,
  "created_at" : "2014-01-09 19:46:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "421366492244869120",
  "text" : "RT @WHLive: Obama: \"Each of these communities is prepared to do what it takes to change the odds for their kids...we will help them succeed\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "421366465229365248",
    "text" : "Obama: \"Each of these communities is prepared to do what it takes to change the odds for their kids...we will help them succeed.\"",
    "id" : 421366465229365248,
    "created_at" : "2014-01-09 19:42:48 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 421366492244869120,
  "created_at" : "2014-01-09 19:42:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 114, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/q2Dh2GVIhb",
      "expanded_url" : "http:\/\/go.wh.gov\/P5amGo",
      "display_url" : "go.wh.gov\/P5amGo"
    } ]
  },
  "geo" : { },
  "id_str" : "421366102136872960",
  "text" : "President Obama: \"Today, I\u2019m pleased to announce the first five Promise Zones in America.\" http:\/\/t.co\/q2Dh2GVIhb #OpportunityForAll",
  "id" : 421366102136872960,
  "created_at" : "2014-01-09 19:41:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "421365889607270400",
  "text" : "President Obama: \"A child\u2019s course in life should be determined not by the zip code she\u2019s born in, but by the strength of her work ethic.\"",
  "id" : 421365889607270400,
  "created_at" : "2014-01-09 19:40:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "421364977610395648",
  "text" : "RT @WHLive: Obama on Harlem: \"In a neighborhood where higher ed was once just something other people did...100s of kids have now gone on to\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "421364959579095040",
    "text" : "Obama on Harlem: \"In a neighborhood where higher ed was once just something other people did...100s of kids have now gone on to college.\"",
    "id" : 421364959579095040,
    "created_at" : "2014-01-09 19:36:49 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 421364977610395648,
  "created_at" : "2014-01-09 19:36:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "421364485643702272",
  "text" : "Obama: \"No amount of money can take the place of a loving parent...but...when communities...work together, we can make a difference.\"",
  "id" : 421364485643702272,
  "created_at" : "2014-01-09 19:34:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 97, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "421363280058142721",
  "text" : "President Obama: \"Anybody in this country who works hard should have a shot at success. Period.\" #OpportunityForAll",
  "id" : 421363280058142721,
  "created_at" : "2014-01-09 19:30:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 109, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "421362658848165888",
  "text" : "President Obama: \"We\u2019ve got to keep our economy growing, and make sure more Americans share in that growth.\" #OpportunityForAll",
  "id" : 421362658848165888,
  "created_at" : "2014-01-09 19:27:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 113, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "421362634919665664",
  "text" : "RT @WHLive: Obama: \"Our businesses have created more than 8 million new jobs since the depths of the recession.\" #ABetterBargain http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WHLive\/status\/421362532184375297\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/jBIE95jVf2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bdj6_Y5CcAAnIt7.jpg",
        "id_str" : "421362532079529984",
        "id" : 421362532079529984,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bdj6_Y5CcAAnIt7.jpg",
        "sizes" : [ {
          "h" : 700,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 700,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/jBIE95jVf2"
      } ],
      "hashtags" : [ {
        "text" : "ABetterBargain",
        "indices" : [ 101, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "421362532184375297",
    "text" : "Obama: \"Our businesses have created more than 8 million new jobs since the depths of the recession.\" #ABetterBargain http:\/\/t.co\/jBIE95jVf2",
    "id" : 421362532184375297,
    "created_at" : "2014-01-09 19:27:10 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 421362634919665664,
  "created_at" : "2014-01-09 19:27:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 106, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "421362383081054208",
  "text" : "President Obama: \"That\u2019s what we\u2019re here to talk about today\u2014changing the odds for every American child.\" #OpportunityForAll",
  "id" : 421362383081054208,
  "created_at" : "2014-01-09 19:26:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 88, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/zByAabpbmd",
      "expanded_url" : "http:\/\/go.wh.gov\/3xBxPf",
      "display_url" : "go.wh.gov\/3xBxPf"
    } ]
  },
  "geo" : { },
  "id_str" : "421361803063328768",
  "text" : "Starting now: President Obama announces partnerships with local communities to increase #OpportunityForAll. Watch \u2192 http:\/\/t.co\/zByAabpbmd",
  "id" : 421361803063328768,
  "created_at" : "2014-01-09 19:24:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 97, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/DvFb13MQeB",
      "expanded_url" : "http:\/\/go.wh.gov\/yesa1R",
      "display_url" : "go.wh.gov\/yesa1R"
    } ]
  },
  "geo" : { },
  "id_str" : "421342382781517825",
  "text" : "At 2:20pm ET, watch President Obama announce new partnerships with local communities to increase #OpportunityForAll \u2192 http:\/\/t.co\/DvFb13MQeB",
  "id" : 421342382781517825,
  "created_at" : "2014-01-09 18:07:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 3, 11 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BreastCancer",
      "indices" : [ 48, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "421337429820178433",
  "text" : "RT @DrBiden: Great news: More women facing high #BreastCancer risk won't have co-pays for certain preventive treatments \u2192 http:\/\/t.co\/1aZcF\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BreastCancer",
        "indices" : [ 35, 48 ]
      } ],
      "urls" : [ {
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/1aZcFYEuF1",
        "expanded_url" : "http:\/\/go.wh.gov\/7LTmif",
        "display_url" : "go.wh.gov\/7LTmif"
      } ]
    },
    "geo" : { },
    "id_str" : "421329254333173761",
    "text" : "Great news: More women facing high #BreastCancer risk won't have co-pays for certain preventive treatments \u2192 http:\/\/t.co\/1aZcFYEuF1",
    "id" : 421329254333173761,
    "created_at" : "2014-01-09 17:14:56 +0000",
    "user" : {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "protected" : false,
      "id_str" : "1281405877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608687663034474496\/wvzVG_yt_normal.jpg",
      "id" : 1281405877,
      "verified" : true
    }
  },
  "id" : 421337429820178433,
  "created_at" : "2014-01-09 17:47:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 96, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/KmHRdauysu",
      "expanded_url" : "http:\/\/go.wh.gov\/MbN5ve",
      "display_url" : "go.wh.gov\/MbN5ve"
    } ]
  },
  "geo" : { },
  "id_str" : "421329348793081857",
  "text" : "Today, President Obama will announce 5 Promise Zones: Partnerships with communities to increase #OpportunityForAll \u2192 http:\/\/t.co\/KmHRdauysu",
  "id" : 421329348793081857,
  "created_at" : "2014-01-09 17:15:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 48, 61 ]
    }, {
      "text" : "RenewUI",
      "indices" : [ 66, 74 ]
    }, {
      "text" : "OpportunityForAll",
      "indices" : [ 100, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/wXywry9ncn",
      "expanded_url" : "http:\/\/go.wh.gov\/f7rT1K",
      "display_url" : "go.wh.gov\/f7rT1K"
    } ]
  },
  "geo" : { },
  "id_str" : "421319506732920832",
  "text" : "New Poll: Americans strongly support efforts to #RaiseTheWage and #RenewUI \u2192 http:\/\/t.co\/wXywry9ncn #OpportunityForAll",
  "id" : 421319506732920832,
  "created_at" : "2014-01-09 16:36:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "indices" : [ 78, 88 ],
      "id_str" : "1613223313",
      "id" : 1613223313
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 113, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/q2Dh2GVIhb",
      "expanded_url" : "http:\/\/go.wh.gov\/P5amGo",
      "display_url" : "go.wh.gov\/P5amGo"
    } ]
  },
  "geo" : { },
  "id_str" : "421306589312610305",
  "text" : "\"A child\u2019s zip code should never be what determines his or her opportunity.\" \u2014@Cecilia44: http:\/\/t.co\/q2Dh2GVIhb #OpportunityForAll",
  "id" : 421306589312610305,
  "created_at" : "2014-01-09 15:44:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "indices" : [ 3, 15 ],
      "id_str" : "15764644",
      "id" : 15764644
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RenewUI",
      "indices" : [ 123, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "421304802614992897",
  "text" : "RT @NancyPelosi: Shameful: 1 person loses much-needed financial help every 8 seconds because of the House GOP\u2019s refusal to #RenewUI. http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RenewUI",
        "indices" : [ 106, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/8tZNVGT58D",
        "expanded_url" : "http:\/\/goo.gl\/j8OnuL",
        "display_url" : "goo.gl\/j8OnuL"
      } ]
    },
    "geo" : { },
    "id_str" : "421299041482207232",
    "text" : "Shameful: 1 person loses much-needed financial help every 8 seconds because of the House GOP\u2019s refusal to #RenewUI. http:\/\/t.co\/8tZNVGT58D",
    "id" : 421299041482207232,
    "created_at" : "2014-01-09 15:14:53 +0000",
    "user" : {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "protected" : false,
      "id_str" : "15764644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571313158510223360\/wnSl3yXF_normal.jpeg",
      "id" : 15764644,
      "verified" : true
    }
  },
  "id" : 421304802614992897,
  "created_at" : "2014-01-09 15:37:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PolarVortex",
      "indices" : [ 64, 76 ]
    }, {
      "text" : "ActOnClimate",
      "indices" : [ 102, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/tHZUXCQw3v",
      "expanded_url" : "http:\/\/go.wh.gov\/ZTMfAF",
      "display_url" : "go.wh.gov\/ZTMfAF"
    } ]
  },
  "geo" : { },
  "id_str" : "421297504244625408",
  "text" : "Don't miss this: President Obama's Science Advisor explains the #PolarVortex \u2192 http:\/\/t.co\/tHZUXCQw3v #ActOnClimate",
  "id" : 421297504244625408,
  "created_at" : "2014-01-09 15:08:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 85, 96 ]
    }, {
      "text" : "ACA",
      "indices" : [ 97, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/yK8u5LFdCu",
      "expanded_url" : "http:\/\/wapo.st\/1d2AxwY",
      "display_url" : "wapo.st\/1d2AxwY"
    } ]
  },
  "geo" : { },
  "id_str" : "421288495395926016",
  "text" : "RT @Simas44: Yes it is ---&gt; \"Despite what the critics say, Obamacare is working.\" #GetCovered #ACA  http:\/\/t.co\/yK8u5LFdCu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 72, 83 ]
      }, {
        "text" : "ACA",
        "indices" : [ 84, 88 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/yK8u5LFdCu",
        "expanded_url" : "http:\/\/wapo.st\/1d2AxwY",
        "display_url" : "wapo.st\/1d2AxwY"
      } ]
    },
    "geo" : { },
    "id_str" : "421276953711095808",
    "text" : "Yes it is ---&gt; \"Despite what the critics say, Obamacare is working.\" #GetCovered #ACA  http:\/\/t.co\/yK8u5LFdCu",
    "id" : 421276953711095808,
    "created_at" : "2014-01-09 13:47:07 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 421288495395926016,
  "created_at" : "2014-01-09 14:32:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bobak Ferdowsi",
      "screen_name" : "tweetsoutloud",
      "indices" : [ 3, 17 ],
      "id_str" : "61306578",
      "id" : 61306578
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/tweetsoutloud\/status\/421073117927055361\/photo\/1",
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/49VALzZMrt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BdfzxQrCMAAM5rO.jpg",
      "id_str" : "421073117797036032",
      "id" : 421073117797036032,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BdfzxQrCMAAM5rO.jpg",
      "sizes" : [ {
        "h" : 540,
        "resize" : "fit",
        "w" : 1011
      }, {
        "h" : 320,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 182,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 540,
        "resize" : "fit",
        "w" : 1011
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/49VALzZMrt"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/bqFPoWkCwT",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2014\/01\/08\/obama-administration-extends-international-space-station-until-least-2024",
      "display_url" : "whitehouse.gov\/blog\/2014\/01\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "421073629934137345",
  "text" : "RT @tweetsoutloud: Space Station extended until 2024; Death Star plans delayed. http:\/\/t.co\/bqFPoWkCwT http:\/\/t.co\/49VALzZMrt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/tweetsoutloud\/status\/421073117927055361\/photo\/1",
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/49VALzZMrt",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BdfzxQrCMAAM5rO.jpg",
        "id_str" : "421073117797036032",
        "id" : 421073117797036032,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BdfzxQrCMAAM5rO.jpg",
        "sizes" : [ {
          "h" : 540,
          "resize" : "fit",
          "w" : 1011
        }, {
          "h" : 320,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 182,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 540,
          "resize" : "fit",
          "w" : 1011
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/49VALzZMrt"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 83 ],
        "url" : "http:\/\/t.co\/bqFPoWkCwT",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2014\/01\/08\/obama-administration-extends-international-space-station-until-least-2024",
        "display_url" : "whitehouse.gov\/blog\/2014\/01\/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "421073117927055361",
    "text" : "Space Station extended until 2024; Death Star plans delayed. http:\/\/t.co\/bqFPoWkCwT http:\/\/t.co\/49VALzZMrt",
    "id" : 421073117927055361,
    "created_at" : "2014-01-09 00:17:09 +0000",
    "user" : {
      "name" : "Bobak Ferdowsi",
      "screen_name" : "tweetsoutloud",
      "protected" : false,
      "id_str" : "61306578",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745368236384911361\/qx3hr6Fb_normal.jpg",
      "id" : 61306578,
      "verified" : true
    }
  },
  "id" : 421073629934137345,
  "created_at" : "2014-01-09 00:19:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "421070754198085632",
  "text" : "RT @CEABetsey: Research shows childhood poverty is self-perpetuating-- solve it now and save $500 billion in foregone income, cost of crime\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "421058329415143424",
    "text" : "Research shows childhood poverty is self-perpetuating-- solve it now and save $500 billion in foregone income, cost of crime &amp; health costs",
    "id" : 421058329415143424,
    "created_at" : "2014-01-08 23:18:23 +0000",
    "user" : {
      "name" : "Sandy Black",
      "screen_name" : "CEASandy",
      "protected" : false,
      "id_str" : "1979039203",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/707608742498439169\/VDM-nQKG_normal.jpg",
      "id" : 1979039203,
      "verified" : true
    }
  },
  "id" : 421070754198085632,
  "created_at" : "2014-01-09 00:07:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    }, {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 120, 125 ],
      "id_str" : "11348282",
      "id" : 11348282
    }, {
      "name" : "ISS Research",
      "screen_name" : "ISS_Research",
      "indices" : [ 126, 139 ],
      "id_str" : "189253902",
      "id" : 189253902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/7RpuVkFJjn",
      "expanded_url" : "http:\/\/wh.gov\/lXFJL",
      "display_url" : "wh.gov\/lXFJL"
    } ]
  },
  "geo" : { },
  "id_str" : "421064237788581888",
  "text" : "RT @whitehouseostp: Obama Administration Extends International Space Station until at Least 2024 http:\/\/t.co\/7RpuVkFJjn @NASA @ISS_Research",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NASA",
        "screen_name" : "NASA",
        "indices" : [ 100, 105 ],
        "id_str" : "11348282",
        "id" : 11348282
      }, {
        "name" : "ISS Research",
        "screen_name" : "ISS_Research",
        "indices" : [ 106, 119 ],
        "id_str" : "189253902",
        "id" : 189253902
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/7RpuVkFJjn",
        "expanded_url" : "http:\/\/wh.gov\/lXFJL",
        "display_url" : "wh.gov\/lXFJL"
      } ]
    },
    "geo" : { },
    "id_str" : "421047832049512448",
    "text" : "Obama Administration Extends International Space Station until at Least 2024 http:\/\/t.co\/7RpuVkFJjn @NASA @ISS_Research",
    "id" : 421047832049512448,
    "created_at" : "2014-01-08 22:36:40 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 421064237788581888,
  "created_at" : "2014-01-08 23:41:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 70, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/NvwqgbDVPo",
      "expanded_url" : "http:\/\/go.wh.gov\/QXaP5V",
      "display_url" : "go.wh.gov\/QXaP5V"
    } ]
  },
  "geo" : { },
  "id_str" : "421041919674683392",
  "text" : "Our growing clean energy economy in 3 charts \u2192 http:\/\/t.co\/NvwqgbDVPo #ActOnClimate",
  "id" : 421041919674683392,
  "created_at" : "2014-01-08 22:13:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PolarVortex",
      "indices" : [ 4, 16 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/ZLjiK5hG8l",
      "expanded_url" : "http:\/\/go.wh.gov\/Wse1sT",
      "display_url" : "go.wh.gov\/Wse1sT"
    } ]
  },
  "geo" : { },
  "id_str" : "421031274766434304",
  "text" : "The #PolarVortex explained in 2 minutes\u2014and why climate change makes extreme weather more likely going forward \u2192 http:\/\/t.co\/ZLjiK5hG8l",
  "id" : 421031274766434304,
  "created_at" : "2014-01-08 21:30:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gabrielle Giffords",
      "screen_name" : "GabbyGiffords",
      "indices" : [ 3, 17 ],
      "id_str" : "44177383",
      "id" : 44177383
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "421020572458680320",
  "text" : "RT @GabbyGiffords: Three years after the shooting that almost took my life, I can move my arm again. Grit can overcome paralysis. http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/LuDvqDajO0",
        "expanded_url" : "http:\/\/www.nytimes.com\/2014\/01\/08\/opinion\/gabrielle-giffordss-call-for-patience-on-gun-reform.html",
        "display_url" : "nytimes.com\/2014\/01\/08\/opi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "420758765130878976",
    "text" : "Three years after the shooting that almost took my life, I can move my arm again. Grit can overcome paralysis. http:\/\/t.co\/LuDvqDajO0",
    "id" : 420758765130878976,
    "created_at" : "2014-01-08 03:28:01 +0000",
    "user" : {
      "name" : "Gabrielle Giffords",
      "screen_name" : "GabbyGiffords",
      "protected" : false,
      "id_str" : "44177383",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738723616485978117\/G9V0XAhU_normal.jpg",
      "id" : 44177383,
      "verified" : true
    }
  },
  "id" : 421020572458680320,
  "created_at" : "2014-01-08 20:48:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "indices" : [ 3, 15 ],
      "id_str" : "369232105",
      "id" : 369232105
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "421004322294726657",
  "text" : "RT @PAniskoff44: Nominate someone you know that's a leader in gun violence prevention to be a Champion of Change. Deadline Jan 12: http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/p8EpVjcsMN",
        "expanded_url" : "http:\/\/1.usa.gov\/1dg6jIx",
        "display_url" : "1.usa.gov\/1dg6jIx"
      } ]
    },
    "geo" : { },
    "id_str" : "420960351505510401",
    "text" : "Nominate someone you know that's a leader in gun violence prevention to be a Champion of Change. Deadline Jan 12: http:\/\/t.co\/p8EpVjcsMN",
    "id" : 420960351505510401,
    "created_at" : "2014-01-08 16:49:03 +0000",
    "user" : {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "protected" : false,
      "id_str" : "369232105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623146355767140352\/58sqoVrw_normal.jpg",
      "id" : 369232105,
      "verified" : true
    }
  },
  "id" : 421004322294726657,
  "created_at" : "2014-01-08 19:43:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AMD",
      "screen_name" : "AMD",
      "indices" : [ 76, 80 ],
      "id_str" : "14861876",
      "id" : 14861876
    }, {
      "name" : "Alicia Gibb",
      "screen_name" : "pipix",
      "indices" : [ 82, 88 ],
      "id_str" : "18248559",
      "id" : 18248559
    }, {
      "name" : "Palmer Luckey",
      "screen_name" : "PalmerLuckey",
      "indices" : [ 90, 103 ],
      "id_str" : "294306372",
      "id" : 294306372
    }, {
      "name" : "Alex Kipman",
      "screen_name" : "akipman",
      "indices" : [ 110, 118 ],
      "id_str" : "6579292",
      "id" : 6579292
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WeTheGeeks",
      "indices" : [ 21, 32 ]
    } ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/VC7u7lJlyo",
      "expanded_url" : "http:\/\/go.wh.gov\/X6jiYw",
      "display_url" : "go.wh.gov\/X6jiYw"
    } ]
  },
  "geo" : { },
  "id_str" : "420993382249676801",
  "text" : "Starting now: Join a #WeTheGeeks G+ Hangout on the future of computing with @AMD, @Pipix, @PalmerLuckey &amp; @Akipman \u2192 http:\/\/t.co\/VC7u7lJlyo",
  "id" : 420993382249676801,
  "created_at" : "2014-01-08 19:00:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "420980695381848064",
  "text" : "RT @CEABetsey: Anti-poverty programs have helped reduce the poverty rate from 25.8% in 1967 to 16.0% in 2012 \u2013 would be 28.7% w\/out http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CEABetsey\/status\/420967054053629952\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/1fLxoVc4PN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BdeTTieCYAAb8Ry.jpg",
        "id_str" : "420967054062018560",
        "id" : 420967054062018560,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BdeTTieCYAAb8Ry.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 368,
          "resize" : "fit",
          "w" : 402
        }, {
          "h" : 368,
          "resize" : "fit",
          "w" : 402
        }, {
          "h" : 368,
          "resize" : "fit",
          "w" : 402
        }, {
          "h" : 311,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/1fLxoVc4PN"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "420967054053629952",
    "text" : "Anti-poverty programs have helped reduce the poverty rate from 25.8% in 1967 to 16.0% in 2012 \u2013 would be 28.7% w\/out http:\/\/t.co\/1fLxoVc4PN",
    "id" : 420967054053629952,
    "created_at" : "2014-01-08 17:15:41 +0000",
    "user" : {
      "name" : "Sandy Black",
      "screen_name" : "CEASandy",
      "protected" : false,
      "id_str" : "1979039203",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/707608742498439169\/VDM-nQKG_normal.jpg",
      "id" : 1979039203,
      "verified" : true
    }
  },
  "id" : 420980695381848064,
  "created_at" : "2014-01-08 18:09:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Chamber",
      "screen_name" : "USChamber",
      "indices" : [ 86, 96 ],
      "id_str" : "85606078",
      "id" : 85606078
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 45, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/WZn2Q2xO9F",
      "expanded_url" : "http:\/\/cnn.it\/19TfQov",
      "display_url" : "cnn.it\/19TfQov"
    } ]
  },
  "geo" : { },
  "id_str" : "420975763752357889",
  "text" : "\"We're determined to make 2014 the year that #ImmigrationReform is finally enacted.\" \u2014@USChamber: http:\/\/t.co\/WZn2Q2xO9F",
  "id" : 420975763752357889,
  "created_at" : "2014-01-08 17:50:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WeTheGeeks",
      "indices" : [ 7, 18 ]
    }, {
      "text" : "CES2014",
      "indices" : [ 136, 144 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/pq3UuufFgG",
      "expanded_url" : "http:\/\/go.wh.gov\/t1gbhf",
      "display_url" : "go.wh.gov\/t1gbhf"
    } ]
  },
  "geo" : { },
  "id_str" : "420968213329887232",
  "text" : "Join a #WeTheGeeks Hangout at 2pm ET on the future of computing &amp; the breakthroughs that may be coming soon: http:\/\/t.co\/pq3UuufFgG #CES2014",
  "id" : 420968213329887232,
  "created_at" : "2014-01-08 17:20:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/nZ7mHP5f00",
      "expanded_url" : "http:\/\/go.wh.gov\/ScFbgC",
      "display_url" : "go.wh.gov\/ScFbgC"
    } ]
  },
  "geo" : { },
  "id_str" : "420959406562361344",
  "text" : "\"Before Medicare, only half of seniors had some form of health insurance. Today, virtually all do.\" \u2014Obama: http:\/\/t.co\/nZ7mHP5f00",
  "id" : 420959406562361344,
  "created_at" : "2014-01-08 16:45:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Furman",
      "screen_name" : "CEAChair",
      "indices" : [ 3, 12 ],
      "id_str" : "1861751828",
      "id" : 1861751828
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "waronpoverty",
      "indices" : [ 38, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "420953078339497985",
  "text" : "RT @CEAChair: CEA's new report on the #waronpoverty shows substantial progress due to major policies, but still work to be done. http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "waronpoverty",
        "indices" : [ 24, 37 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/M7XuuO0vyx",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/sites\/default\/files\/docs\/50th_anniversary_cea_report_-_final_post_embargo.pdf",
        "display_url" : "whitehouse.gov\/sites\/default\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "420951263124004866",
    "text" : "CEA's new report on the #waronpoverty shows substantial progress due to major policies, but still work to be done. http:\/\/t.co\/M7XuuO0vyx",
    "id" : 420951263124004866,
    "created_at" : "2014-01-08 16:12:56 +0000",
    "user" : {
      "name" : "Jason Furman",
      "screen_name" : "CEAChair",
      "protected" : false,
      "id_str" : "1861751828",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000628384447\/c9cb85dbdb73c8bac4f28ce4cc46f38b_normal.jpeg",
      "id" : 1861751828,
      "verified" : true
    }
  },
  "id" : 420953078339497985,
  "created_at" : "2014-01-08 16:20:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Social Security",
      "screen_name" : "SocialSecurity",
      "indices" : [ 9, 24 ],
      "id_str" : "39580052",
      "id" : 39580052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/pkZKCMEiAn",
      "expanded_url" : "http:\/\/go.wh.gov\/ZQ9m3w",
      "display_url" : "go.wh.gov\/ZQ9m3w"
    } ]
  },
  "geo" : { },
  "id_str" : "420945564008603649",
  "text" : "\"Without @SocialSecurity, nearly half of seniors would be living in poverty. Today, fewer than 1 in 7 do.\" \u2014Obama: http:\/\/t.co\/pkZKCMEiAn",
  "id" : 420945564008603649,
  "created_at" : "2014-01-08 15:50:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WarOnPoverty",
      "indices" : [ 98, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/fh01EOCw1f",
      "expanded_url" : "http:\/\/go.wh.gov\/YLqY4v",
      "display_url" : "go.wh.gov\/YLqY4v"
    } ]
  },
  "geo" : { },
  "id_str" : "420938351005286400",
  "text" : "\"Everyone who works hard deserves a chance at opportunity.\" \u2014Obama on the 50th Anniversary of the #WarOnPoverty: http:\/\/t.co\/fh01EOCw1f",
  "id" : 420938351005286400,
  "created_at" : "2014-01-08 15:21:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/420708470745079808\/photo\/1",
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/vujKLQRWbA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BdaoIABCYAMfqxv.jpg",
      "id_str" : "420708470602489859",
      "id" : 420708470602489859,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BdaoIABCYAMfqxv.jpg",
      "sizes" : [ {
        "h" : 784,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 459,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 260,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 784,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/vujKLQRWbA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "420708470745079808",
  "text" : "Don't blink. http:\/\/t.co\/vujKLQRWbA",
  "id" : 420708470745079808,
  "created_at" : "2014-01-08 00:08:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/420681568768647168\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/uEuUTNYKab",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BdaPqGPCUAEcAXk.jpg",
      "id_str" : "420681568596676609",
      "id" : 420681568596676609,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BdaPqGPCUAEcAXk.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/uEuUTNYKab"
    } ],
    "hashtags" : [ {
      "text" : "RenewUI",
      "indices" : [ 32, 40 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/5Q4jFqLL4M",
      "expanded_url" : "http:\/\/go.wh.gov\/Asygb5",
      "display_url" : "go.wh.gov\/Asygb5"
    } ]
  },
  "geo" : { },
  "id_str" : "420681568768647168",
  "text" : "Here's why it's so important to #RenewUI for hardworking Americans looking for a job \u2192 http:\/\/t.co\/5Q4jFqLL4M, http:\/\/t.co\/uEuUTNYKab",
  "id" : 420681568768647168,
  "created_at" : "2014-01-07 22:21:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Labor Department",
      "screen_name" : "USDOL",
      "indices" : [ 3, 9 ],
      "id_str" : "20179628",
      "id" : 20179628
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/USDOL\/status\/420660857027051520\/photo\/1",
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/sC2bgMz7BY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BdZ80hqCQAAzRRF.jpg",
      "id_str" : "420660857035440128",
      "id" : 420660857035440128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BdZ80hqCQAAzRRF.jpg",
      "sizes" : [ {
        "h" : 406,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 692,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1014,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 230,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/sC2bgMz7BY"
    } ],
    "hashtags" : [ {
      "text" : "RenewUI",
      "indices" : [ 55, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "420661542225326080",
  "text" : "RT @USDOL: 240K jobs could be lost in 2014 if we don't #RenewUI. Here's the breakdown by state --&gt; http:\/\/t.co\/sC2bgMz7BY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/USDOL\/status\/420660857027051520\/photo\/1",
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/sC2bgMz7BY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BdZ80hqCQAAzRRF.jpg",
        "id_str" : "420660857035440128",
        "id" : 420660857035440128,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BdZ80hqCQAAzRRF.jpg",
        "sizes" : [ {
          "h" : 406,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 692,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1014,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 230,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/sC2bgMz7BY"
      } ],
      "hashtags" : [ {
        "text" : "RenewUI",
        "indices" : [ 44, 52 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "420660857027051520",
    "text" : "240K jobs could be lost in 2014 if we don't #RenewUI. Here's the breakdown by state --&gt; http:\/\/t.co\/sC2bgMz7BY",
    "id" : 420660857027051520,
    "created_at" : "2014-01-07 20:58:58 +0000",
    "user" : {
      "name" : "US Labor Department",
      "screen_name" : "USDOL",
      "protected" : false,
      "id_str" : "20179628",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655006480697978880\/Fom0f0nJ_normal.png",
      "id" : 20179628,
      "verified" : true
    }
  },
  "id" : 420661542225326080,
  "created_at" : "2014-01-07 21:01:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RenewUI",
      "indices" : [ 125, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "420654619874693120",
  "text" : "FACT: 1.3 million Americans had unemployment benefits taken away over the holidays because Republicans in Congress failed to #RenewUI.",
  "id" : 420654619874693120,
  "created_at" : "2014-01-07 20:34:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/420643155591979008\/photo\/1",
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/xo8gCJB0zn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BdZsuKECIAAsOJn.jpg",
      "id_str" : "420643155436773376",
      "id" : 420643155436773376,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BdZsuKECIAAsOJn.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/xo8gCJB0zn"
    } ],
    "hashtags" : [ {
      "text" : "RenewUI",
      "indices" : [ 91, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "420643155591979008",
  "text" : "FACT: Unemployment insurance helped keep 600,000 kids out of poverty in 2012. It's time to #RenewUI. http:\/\/t.co\/xo8gCJB0zn",
  "id" : 420643155591979008,
  "created_at" : "2014-01-07 19:48:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RenewUI",
      "indices" : [ 33, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "420632979199631360",
  "text" : "RT @Simas44: If Congress doesn't #RenewUI through 2014, 3.6 million more Americans will have unemployment insurance taken away. http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Simas44\/status\/420626202408140801\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/da0LgNuRzH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BdZdTXICQAEsCWp.jpg",
        "id_str" : "420626202412335105",
        "id" : 420626202412335105,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BdZdTXICQAEsCWp.jpg",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/da0LgNuRzH"
      } ],
      "hashtags" : [ {
        "text" : "RenewUI",
        "indices" : [ 20, 28 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "420626202408140801",
    "text" : "If Congress doesn't #RenewUI through 2014, 3.6 million more Americans will have unemployment insurance taken away. http:\/\/t.co\/da0LgNuRzH",
    "id" : 420626202408140801,
    "created_at" : "2014-01-07 18:41:16 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 420632979199631360,
  "created_at" : "2014-01-07 19:08:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/420622504793628672\/photo\/1",
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/PgFxMiWa0U",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BdZZ8H0CMAAer4V.jpg",
      "id_str" : "420622504630038528",
      "id" : 420622504630038528,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BdZZ8H0CMAAer4V.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/PgFxMiWa0U"
    } ],
    "hashtags" : [ {
      "text" : "RenewUI",
      "indices" : [ 27, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "420622504793628672",
  "text" : "FACT: If Congress fails to #RenewUI benefits, it could cost our economy 240,000 jobs this year. http:\/\/t.co\/PgFxMiWa0U",
  "id" : 420622504793628672,
  "created_at" : "2014-01-07 18:26:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/420613694045683712\/photo\/1",
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/YfuyeVAxYp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BdZR7RSCIAEahLF.jpg",
      "id_str" : "420613693898891265",
      "id" : 420613693898891265,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BdZR7RSCIAEahLF.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/YfuyeVAxYp"
    } ],
    "hashtags" : [ {
      "text" : "RenewUI",
      "indices" : [ 87, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "420613694045683712",
  "text" : "RT if you agree: It's time to extend a vital lifeline for Americans looking for a job. #RenewUI, http:\/\/t.co\/YfuyeVAxYp",
  "id" : 420613694045683712,
  "created_at" : "2014-01-07 17:51:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AskCEA",
      "indices" : [ 49, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "420613478311657472",
  "text" : "RT @CEABetsey: Open for questons! Ask away using #AskCEA Looking forward to talking about UI.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AskCEA",
        "indices" : [ 34, 41 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "420611947667542016",
    "text" : "Open for questons! Ask away using #AskCEA Looking forward to talking about UI.",
    "id" : 420611947667542016,
    "created_at" : "2014-01-07 17:44:37 +0000",
    "user" : {
      "name" : "Sandy Black",
      "screen_name" : "CEASandy",
      "protected" : false,
      "id_str" : "1979039203",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/707608742498439169\/VDM-nQKG_normal.jpg",
      "id" : 1979039203,
      "verified" : true
    }
  },
  "id" : 420613478311657472,
  "created_at" : "2014-01-07 17:50:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RenewUI",
      "indices" : [ 70, 78 ]
    }, {
      "text" : "AskCEA",
      "indices" : [ 95, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "420605880090914816",
  "text" : "Starting soon: @CEABetsey will answer your questions about efforts to #RenewUI. Ask away using #AskCEA.",
  "id" : 420605880090914816,
  "created_at" : "2014-01-07 17:20:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RenewUI",
      "indices" : [ 116, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "420603134583394304",
  "text" : "President Obama: \"Voting for unemployment insurance helps people and creates jobs, and voting against it does not.\" #RenewUI",
  "id" : 420603134583394304,
  "created_at" : "2014-01-07 17:09:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RenewUI",
      "indices" : [ 128, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "420602875366998016",
  "text" : "President Obama: \"Letting unemployment insurance expire for millions of Americans is wrong. Congress should make things right.\" #RenewUI",
  "id" : 420602875366998016,
  "created_at" : "2014-01-07 17:08:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RenewUI",
      "indices" : [ 130, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "420602639181549569",
  "text" : "Obama: \"I can't name a time where I've met an American who would rather have an unemployment check than the pride of a paycheck.\" #RenewUI",
  "id" : 420602639181549569,
  "created_at" : "2014-01-07 17:07:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RenewUI",
      "indices" : [ 130, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "420601926837747713",
  "text" : "\"We are not a people who say 'you\u2019re on your own.' We are a people who believe that we\u2019re all in this together.\" \u2014President Obama #RenewUI",
  "id" : 420601926837747713,
  "created_at" : "2014-01-07 17:04:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RenewUI",
      "indices" : [ 23, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "420601687816957953",
  "text" : "President Obama: Let's #RenewUI so that \"losing your livelihood doesn\u2019t have to mean losing everything you\u2019ve worked so hard to build.\"",
  "id" : 420601687816957953,
  "created_at" : "2014-01-07 17:03:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RenewUI",
      "indices" : [ 22, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "420601355930054656",
  "text" : "Obama on the needs to #RenewUI: \u201CIt helps Mom pay the rent while learning new skills to earn that new job.\u201D",
  "id" : 420601355930054656,
  "created_at" : "2014-01-07 17:02:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RenewUI",
      "indices" : [ 36, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "420601219845853184",
  "text" : "President Obama on why it\u2019s time to #RenewUI: \u201CThis insurance helps keep food on the table while Dad is sending out resumes.\u201D",
  "id" : 420601219845853184,
  "created_at" : "2014-01-07 17:01:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RenewUI",
      "indices" : [ 38, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "420600910461407232",
  "text" : "RT @WHLive: Obama sharing Katherine's #RenewUI story: \"I worked hard all my life, paid taxes, voted...and my two sons serve in the U.S. mil\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RenewUI",
        "indices" : [ 26, 34 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "420600865708191744",
    "text" : "Obama sharing Katherine's #RenewUI story: \"I worked hard all my life, paid taxes, voted...and my two sons serve in the U.S. military.\"",
    "id" : 420600865708191744,
    "created_at" : "2014-01-07 17:00:35 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 420600910461407232,
  "created_at" : "2014-01-07 17:00:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RenewUI",
      "indices" : [ 119, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "420600495174987776",
  "text" : "Obama: \"For many, it\u2019s the only source of income they\u2019ve got to support their families while they look for a new job.\" #RenewUI",
  "id" : 420600495174987776,
  "created_at" : "2014-01-07 16:59:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RenewUI",
      "indices" : [ 42, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "420600382230773760",
  "text" : "RT @WHLive: President Obama on efforts to #RenewUI: \"This morning, the Senate took a very important step in that direction.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RenewUI",
        "indices" : [ 30, 38 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "420600276941164545",
    "text" : "President Obama on efforts to #RenewUI: \"This morning, the Senate took a very important step in that direction.\"",
    "id" : 420600276941164545,
    "created_at" : "2014-01-07 16:58:15 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 420600382230773760,
  "created_at" : "2014-01-07 16:58:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RenewUI",
      "indices" : [ 125, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "420600195001249792",
  "text" : "Obama: \"We should build on that progress with...the 1st order of business in 2014...extending insurance for the unemployed.\" #RenewUI",
  "id" : 420600195001249792,
  "created_at" : "2014-01-07 16:57:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/420599916113559552\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/2NMNHMmX4t",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BdZFZSdCUAExzHG.jpg",
      "id_str" : "420599915958390785",
      "id" : 420599915958390785,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BdZFZSdCUAExzHG.jpg",
      "sizes" : [ {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/2NMNHMmX4t"
    } ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 101, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "420599916113559552",
  "text" : "President Obama: \"Our businesses have created more than 8 million new jobs since we hit the bottom.\" #ABetterBargain http:\/\/t.co\/2NMNHMmX4t",
  "id" : 420599916113559552,
  "created_at" : "2014-01-07 16:56:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RenewUI",
      "indices" : [ 65, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/eoNcOe9hwJ",
      "expanded_url" : "http:\/\/go.wh.gov\/zYurjM",
      "display_url" : "go.wh.gov\/zYurjM"
    } ]
  },
  "geo" : { },
  "id_str" : "420599041810894848",
  "text" : "Starting now: President Obama speaks about why Congress needs to #RenewUI for Americans looking for a job. Watch \u2192 http:\/\/t.co\/eoNcOe9hwJ",
  "id" : 420599041810894848,
  "created_at" : "2014-01-07 16:53:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/420589645685325824\/photo\/1",
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/D5oXa3XZDU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BdY8DeMIUAAL-PX.jpg",
      "id_str" : "420589645546934272",
      "id" : 420589645546934272,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BdY8DeMIUAAL-PX.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/D5oXa3XZDU"
    } ],
    "hashtags" : [ {
      "text" : "RenewUI",
      "indices" : [ 76, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "420589645685325824",
  "text" : "RT if you agree: For the sake of our families and our economy, it's time to #RenewUI. http:\/\/t.co\/D5oXa3XZDU",
  "id" : 420589645685325824,
  "created_at" : "2014-01-07 16:16:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RenewUI",
      "indices" : [ 62, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/nuOzNOhaDA",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "420584548313751554",
  "text" : "RT @CEABetsey: Pres Obama is about to speak on why we need to #RenewUI - http:\/\/t.co\/nuOzNOhaDA After I'll answer some Qs on why it's so im\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RenewUI",
        "indices" : [ 47, 55 ]
      }, {
        "text" : "AskCEA",
        "indices" : [ 133, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/nuOzNOhaDA",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "420578887114817536",
    "text" : "Pres Obama is about to speak on why we need to #RenewUI - http:\/\/t.co\/nuOzNOhaDA After I'll answer some Qs on why it's so important. #AskCEA",
    "id" : 420578887114817536,
    "created_at" : "2014-01-07 15:33:15 +0000",
    "user" : {
      "name" : "Sandy Black",
      "screen_name" : "CEASandy",
      "protected" : false,
      "id_str" : "1979039203",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/707608742498439169\/VDM-nQKG_normal.jpg",
      "id" : 1979039203,
      "verified" : true
    }
  },
  "id" : 420584548313751554,
  "created_at" : "2014-01-07 15:55:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RenewUI",
      "indices" : [ 72, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/QZvIJoHTBM",
      "expanded_url" : "http:\/\/go.wh.gov\/RjeFhF",
      "display_url" : "go.wh.gov\/RjeFhF"
    } ]
  },
  "geo" : { },
  "id_str" : "420579983409414144",
  "text" : "Don't miss President Obama speak at 11:40am ET on why Congress needs to #RenewUI for Americans looking for a job \u2192 http:\/\/t.co\/QZvIJoHTBM",
  "id" : 420579983409414144,
  "created_at" : "2014-01-07 15:37:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "420575520485416960",
  "text" : "RT @VP: Congratulations to Janet Yellen on her confirmation. I know she will work hard and keep focus on economic growth.  --VP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "420574254510268416",
    "text" : "Congratulations to Janet Yellen on her confirmation. I know she will work hard and keep focus on economic growth.  --VP",
    "id" : 420574254510268416,
    "created_at" : "2014-01-07 15:14:50 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 420575520485416960,
  "created_at" : "2014-01-07 15:19:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Furman",
      "screen_name" : "CEAChair",
      "indices" : [ 3, 12 ],
      "id_str" : "1861751828",
      "id" : 1861751828
    }, {
      "name" : "Wall Street Journal",
      "screen_name" : "WSJ",
      "indices" : [ 126, 130 ],
      "id_str" : "3108351",
      "id" : 3108351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 39, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "420571180588744705",
  "text" : "RT @CEAChair: Learn more about how the #ACA is contributing to the slowdown in health care cost growth in my op-ed in today's @WSJ: http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Wall Street Journal",
        "screen_name" : "WSJ",
        "indices" : [ 112, 116 ],
        "id_str" : "3108351",
        "id" : 3108351
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ACA",
        "indices" : [ 25, 29 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/C0LHkbjfLe",
        "expanded_url" : "http:\/\/on.wsj.com\/1gBT5ol",
        "display_url" : "on.wsj.com\/1gBT5ol"
      } ]
    },
    "geo" : { },
    "id_str" : "420571088557326337",
    "text" : "Learn more about how the #ACA is contributing to the slowdown in health care cost growth in my op-ed in today's @WSJ: http:\/\/t.co\/C0LHkbjfLe",
    "id" : 420571088557326337,
    "created_at" : "2014-01-07 15:02:16 +0000",
    "user" : {
      "name" : "Jason Furman",
      "screen_name" : "CEAChair",
      "protected" : false,
      "id_str" : "1861751828",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000628384447\/c9cb85dbdb73c8bac4f28ce4cc46f38b_normal.jpeg",
      "id" : 1861751828,
      "verified" : true
    }
  },
  "id" : 420571180588744705,
  "created_at" : "2014-01-07 15:02:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/420374369538703360\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/d61dhVIEqU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BdV4Qv2IIAEzG40.jpg",
      "id_str" : "420374369345740801",
      "id" : 420374369345740801,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BdV4Qv2IIAEzG40.jpg",
      "sizes" : [ {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 413,
        "resize" : "fit",
        "w" : 620
      }, {
        "h" : 413,
        "resize" : "fit",
        "w" : 620
      } ],
      "display_url" : "pic.twitter.com\/d61dhVIEqU"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/eLmS8c3orp",
      "expanded_url" : "http:\/\/s.si.edu\/1cweb5X",
      "display_url" : "s.si.edu\/1cweb5X"
    } ]
  },
  "geo" : { },
  "id_str" : "420374369538703360",
  "text" : "3 pandas from U.S. zoos are up for Panda Cub of the Year!\nMake your voice heard.\nVote now \u2192 http:\/\/t.co\/eLmS8c3orp, http:\/\/t.co\/d61dhVIEqU",
  "id" : 420374369538703360,
  "created_at" : "2014-01-07 02:00:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    }, {
      "name" : "Federal Student Aid",
      "screen_name" : "FAFSA",
      "indices" : [ 47, 53 ],
      "id_str" : "188001904",
      "id" : 188001904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/gBdilpTrmf",
      "expanded_url" : "http:\/\/FAFSA.gov",
      "display_url" : "FAFSA.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "420362923693711360",
  "text" : "RT @arneduncan: The average time to complete a @FAFSA has decreased to 23 minutes. Get started on yours at http:\/\/t.co\/gBdilpTrmf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Federal Student Aid",
        "screen_name" : "FAFSA",
        "indices" : [ 31, 37 ],
        "id_str" : "188001904",
        "id" : 188001904
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/gBdilpTrmf",
        "expanded_url" : "http:\/\/FAFSA.gov",
        "display_url" : "FAFSA.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "420360496983080960",
    "text" : "The average time to complete a @FAFSA has decreased to 23 minutes. Get started on yours at http:\/\/t.co\/gBdilpTrmf",
    "id" : 420360496983080960,
    "created_at" : "2014-01-07 01:05:27 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 420362923693711360,
  "created_at" : "2014-01-07 01:15:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/FRcoCiywqi",
      "expanded_url" : "http:\/\/go.wh.gov\/DZzFBP",
      "display_url" : "go.wh.gov\/DZzFBP"
    } ]
  },
  "geo" : { },
  "id_str" : "420344636016586753",
  "text" : "Congrats to Janet Yellen on her confirmation as the first woman to lead the Federal Reserve \u2192 http:\/\/t.co\/FRcoCiywqi",
  "id" : 420344636016586753,
  "created_at" : "2014-01-07 00:02:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 13, 22 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/420335998531158016\/photo\/1",
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/v0fL9u6dH9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BdVVXRdCQAAvJwp.jpg",
      "id_str" : "420335998539546624",
      "id" : 420335998539546624,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BdVVXRdCQAAvJwp.jpg",
      "sizes" : [ {
        "h" : 234,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 622,
        "resize" : "fit",
        "w" : 905
      }, {
        "h" : 622,
        "resize" : "fit",
        "w" : 905
      }, {
        "h" : 412,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/v0fL9u6dH9"
    } ],
    "hashtags" : [ {
      "text" : "GetBeard",
      "indices" : [ 24, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "420335998531158016",
  "text" : "Nice scruff, @PressSec. #GetBeard, http:\/\/t.co\/v0fL9u6dH9",
  "id" : 420335998531158016,
  "created_at" : "2014-01-06 23:28:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Viagra n tayac. Dagr",
      "screen_name" : "DagVega44",
      "indices" : [ 3, 13 ],
      "id_str" : "2785789802",
      "id" : 2785789802
    }, {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "indices" : [ 16, 25 ],
      "id_str" : "1604366701",
      "id" : 1604366701
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TheLead",
      "indices" : [ 35, 43 ]
    }, {
      "text" : "UI",
      "indices" : [ 45, 48 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "420333019723886592",
  "text" : "RT @DagVega44: .@LaborSec Perez on #TheLead: #UI is a critical lifeline. \"It's not called emergency compensation for nothing.\" ---&gt; http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tom Perez",
        "screen_name" : "LaborSec",
        "indices" : [ 1, 10 ],
        "id_str" : "1604366701",
        "id" : 1604366701
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TheLead",
        "indices" : [ 20, 28 ]
      }, {
        "text" : "UI",
        "indices" : [ 30, 33 ]
      } ],
      "urls" : [ {
        "indices" : [ 120, 142 ],
        "url" : "http:\/\/t.co\/plQOXDr9YQ",
        "expanded_url" : "http:\/\/cnn.it\/1aC0MGa",
        "display_url" : "cnn.it\/1aC0MGa"
      } ]
    },
    "geo" : { },
    "id_str" : "420332352208764928",
    "text" : ".@LaborSec Perez on #TheLead: #UI is a critical lifeline. \"It's not called emergency compensation for nothing.\" ---&gt; http:\/\/t.co\/plQOXDr9YQ",
    "id" : 420332352208764928,
    "created_at" : "2014-01-06 23:13:36 +0000",
    "user" : {
      "name" : "Rob O'Donnell",
      "screen_name" : "RODonnell44",
      "protected" : false,
      "id_str" : "1873091689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/664483086738952192\/UukL2zFT_normal.jpg",
      "id" : 1873091689,
      "verified" : true
    }
  },
  "id" : 420333019723886592,
  "created_at" : "2014-01-06 23:16:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Simas44\/status\/420325002060111872\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/xMRvi191xA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BdVLXMaCIAEe-yO.png",
      "id_str" : "420325002068500481",
      "id" : 420325002068500481,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BdVLXMaCIAEe-yO.png",
      "sizes" : [ {
        "h" : 751,
        "resize" : "fit",
        "w" : 1085
      }, {
        "h" : 235,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 709,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 415,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/xMRvi191xA"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 90, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/0jynZahTG7",
      "expanded_url" : "http:\/\/go.wh.gov\/xjsM5N",
      "display_url" : "go.wh.gov\/xjsM5N"
    } ]
  },
  "geo" : { },
  "id_str" : "420328635237531649",
  "text" : "RT @Simas44: Solar power production \u2191 \nThe cost of solar energy \u2193 \nhttp:\/\/t.co\/0jynZahTG7 #ActOnClimate, http:\/\/t.co\/xMRvi191xA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Simas44\/status\/420325002060111872\/photo\/1",
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/xMRvi191xA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BdVLXMaCIAEe-yO.png",
        "id_str" : "420325002068500481",
        "id" : 420325002068500481,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BdVLXMaCIAEe-yO.png",
        "sizes" : [ {
          "h" : 751,
          "resize" : "fit",
          "w" : 1085
        }, {
          "h" : 235,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 709,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 415,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/xMRvi191xA"
      } ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 77, 90 ]
      } ],
      "urls" : [ {
        "indices" : [ 54, 76 ],
        "url" : "http:\/\/t.co\/0jynZahTG7",
        "expanded_url" : "http:\/\/go.wh.gov\/xjsM5N",
        "display_url" : "go.wh.gov\/xjsM5N"
      } ]
    },
    "geo" : { },
    "id_str" : "420325002060111872",
    "text" : "Solar power production \u2191 \nThe cost of solar energy \u2193 \nhttp:\/\/t.co\/0jynZahTG7 #ActOnClimate, http:\/\/t.co\/xMRvi191xA",
    "id" : 420325002060111872,
    "created_at" : "2014-01-06 22:44:24 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 420328635237531649,
  "created_at" : "2014-01-06 22:58:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/sx8n5rV2k1",
      "expanded_url" : "http:\/\/go.wh.gov\/Fwr7BN",
      "display_url" : "go.wh.gov\/Fwr7BN"
    } ]
  },
  "geo" : { },
  "id_str" : "420320626478309376",
  "text" : "Our growing clean energy economy:\nMore clean energy \u2714\nGreater energy security \u2714\nLess carbon pollution \u2714\nhttp:\/\/t.co\/sx8n5rV2k1\n#ActOnClimate",
  "id" : 420320626478309376,
  "created_at" : "2014-01-06 22:27:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 0, 10 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "420311372371480577",
  "text" : "#Obamacare:\n1. Free preventive care \u2714\n2. No more lifetime limits on coverage \u2714\n3. No more denying coverage for pre-existing conditions \u2714",
  "id" : 420311372371480577,
  "created_at" : "2014-01-06 21:50:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/VZcTcRVSHM",
      "expanded_url" : "http:\/\/go.wh.gov\/wKErCo",
      "display_url" : "go.wh.gov\/wKErCo"
    } ]
  },
  "geo" : { },
  "id_str" : "420302514047574016",
  "text" : "Thanks in part to the Affordable Care Act, health care costs are growing at the slowest rate in more than 50 years \u2192 http:\/\/t.co\/VZcTcRVSHM",
  "id" : 420302514047574016,
  "created_at" : "2014-01-06 21:15:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RenewUI",
      "indices" : [ 27, 35 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/911ru6JGVg",
      "expanded_url" : "http:\/\/go.wh.gov\/F218Hs",
      "display_url" : "go.wh.gov\/F218Hs"
    } ]
  },
  "geo" : { },
  "id_str" : "420278656909320193",
  "text" : "FACT: If Congress fails to #RenewUI benefits, it could cost our economy 240,000 jobs this year \u2192 http:\/\/t.co\/911ru6JGVg",
  "id" : 420278656909320193,
  "created_at" : "2014-01-06 19:40:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RenewUI",
      "indices" : [ 108, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/cVTDnzbdld",
      "expanded_url" : "http:\/\/go.wh.gov\/QEx4z9",
      "display_url" : "go.wh.gov\/QEx4z9"
    } ]
  },
  "geo" : { },
  "id_str" : "420272364824178690",
  "text" : "\"I may lose my vehicle and my home.\" \u2014William M. on losing unemployment benefits because Congress failed to #RenewUI: http:\/\/t.co\/cVTDnzbdld",
  "id" : 420272364824178690,
  "created_at" : "2014-01-06 19:15:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RenewUI",
      "indices" : [ 107, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/JEjbqwTSXl",
      "expanded_url" : "http:\/\/go.wh.gov\/tbDHQ4",
      "display_url" : "go.wh.gov\/tbDHQ4"
    } ]
  },
  "geo" : { },
  "id_str" : "420266073313656832",
  "text" : "\"I am not lazy. I want to work.\" \u2014Erica A. from IL, who just lost a vital lifeline because Congress didn't #RenewUI: http:\/\/t.co\/JEjbqwTSXl",
  "id" : 420266073313656832,
  "created_at" : "2014-01-06 18:50:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RenewUI",
      "indices" : [ 122, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "420261042162106368",
  "text" : "FACT: Because Congress failed to act, 1.3 million Americans lost unemployment insurance this holiday season. It's time to #RenewUI.",
  "id" : 420261042162106368,
  "created_at" : "2014-01-06 18:30:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RenewUI",
      "indices" : [ 13, 21 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 142 ],
      "url" : "http:\/\/t.co\/y8n9irECsx",
      "expanded_url" : "http:\/\/go.wh.gov\/5oCExr",
      "display_url" : "go.wh.gov\/5oCExr"
    } ]
  },
  "geo" : { },
  "id_str" : "420253571091660800",
  "text" : "It's time to #RenewUI for hardworking folks like Bruce, Randy, Candace, Lillian &amp; Kerstin while they look for jobs: http:\/\/t.co\/y8n9irECsx",
  "id" : 420253571091660800,
  "created_at" : "2014-01-06 18:00:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "indices" : [ 3, 15 ],
      "id_str" : "15764644",
      "id" : 15764644
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "420251138626420736",
  "text" : "RT @NancyPelosi: Unemployment insurance has kept more than 11 million people out of poverty, including 620,000 children in 2012 alone. We m\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RenewUI",
        "indices" : [ 126, 134 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "420242713338847232",
    "text" : "Unemployment insurance has kept more than 11 million people out of poverty, including 620,000 children in 2012 alone. We must #RenewUI.",
    "id" : 420242713338847232,
    "created_at" : "2014-01-06 17:17:25 +0000",
    "user" : {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "protected" : false,
      "id_str" : "15764644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571313158510223360\/wnSl3yXF_normal.jpeg",
      "id" : 15764644,
      "verified" : true
    }
  },
  "id" : 420251138626420736,
  "created_at" : "2014-01-06 17:50:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "420241937200054273",
  "text" : "RT @jesseclee44: Was on UI for a time back in '03, last thing it did was decrease motivation to find work; eased panic so I could pursue ef\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RenewUI",
        "indices" : [ 132, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "420227872112930816",
    "text" : "Was on UI for a time back in '03, last thing it did was decrease motivation to find work; eased panic so I could pursue effectively #RenewUI",
    "id" : 420227872112930816,
    "created_at" : "2014-01-06 16:18:26 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 420241937200054273,
  "created_at" : "2014-01-06 17:14:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/420215743343775744\/photo\/1",
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/GtLxZyrZzV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BdTn_faIAAEPnjr.jpg",
      "id_str" : "420215743201148929",
      "id" : 420215743201148929,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BdTn_faIAAEPnjr.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/GtLxZyrZzV"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "420215743343775744",
  "text" : "Father and daughter. http:\/\/t.co\/GtLxZyrZzV",
  "id" : 420215743343775744,
  "created_at" : "2014-01-06 15:30:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/419997165591990272\/photo\/1",
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/pUz1wYoCY9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BdQhMltIAAAMSmG.jpg",
      "id_str" : "419997165415825408",
      "id" : 419997165415825408,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BdQhMltIAAAMSmG.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/pUz1wYoCY9"
    } ],
    "hashtags" : [ {
      "text" : "WestWingWeek",
      "indices" : [ 18, 31 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/Or7vB7uzec",
      "expanded_url" : "http:\/\/go.wh.gov\/Xw7Jpx",
      "display_url" : "go.wh.gov\/Xw7Jpx"
    } ]
  },
  "geo" : { },
  "id_str" : "419997165591990272",
  "text" : "Watch the best of #WestWingWeek from 2013. You don't want to miss it \u2192 http:\/\/t.co\/Or7vB7uzec, http:\/\/t.co\/pUz1wYoCY9",
  "id" : 419997165591990272,
  "created_at" : "2014-01-06 01:01:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 133, 144 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/9NH8biIzbe",
      "expanded_url" : "http:\/\/nbcnews.to\/1dp6YWi",
      "display_url" : "nbcnews.to\/1dp6YWi"
    } ]
  },
  "geo" : { },
  "id_str" : "419906196208766977",
  "text" : "Joyce M.\u2019s canceled plan: \u201CAwful.\u201D Her new one: Lower premiums &amp; $4,750 less\/year in out-of-pocket costs. http:\/\/t.co\/9NH8biIzbe #GetCovered",
  "id" : 419906196208766977,
  "created_at" : "2014-01-05 19:00:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RenewUI",
      "indices" : [ 131, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/TCxUcv67Eu",
      "expanded_url" : "http:\/\/go.wh.gov\/GoULbK",
      "display_url" : "go.wh.gov\/GoULbK"
    } ]
  },
  "geo" : { },
  "id_str" : "419891100057214977",
  "text" : "\"Republicans should make it their New Year\u2019s resolution to...restore this vital economic security.\" \u2014Obama: http:\/\/t.co\/TCxUcv67Eu #RenewUI",
  "id" : 419891100057214977,
  "created_at" : "2014-01-05 18:00:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RenewUI",
      "indices" : [ 132, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/dZxQQpAsxS",
      "expanded_url" : "http:\/\/go.wh.gov\/YUYkmT",
      "display_url" : "go.wh.gov\/YUYkmT"
    } ]
  },
  "geo" : { },
  "id_str" : "419868446214463488",
  "text" : "\"When Congress comes back to work this week\u2014their 1st order of business should be making this right\" \u2014Obama: http:\/\/t.co\/dZxQQpAsxS #RenewUI",
  "id" : 419868446214463488,
  "created_at" : "2014-01-05 16:30:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RenewUI",
      "indices" : [ 106, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/dSnvVkxlYb",
      "expanded_url" : "http:\/\/go.wh.gov\/Rx46HV",
      "display_url" : "go.wh.gov\/Rx46HV"
    } ]
  },
  "geo" : { },
  "id_str" : "419845796700233730",
  "text" : "\"Denying families that security is just...cruel. We\u2019re a better country than that.\" \u2014Obama on the need to #RenewUI: http:\/\/t.co\/dSnvVkxlYb",
  "id" : 419845796700233730,
  "created_at" : "2014-01-05 15:00:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 128, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/OWD1txDaJS",
      "expanded_url" : "http:\/\/wapo.st\/1evhxFZ",
      "display_url" : "wapo.st\/1evhxFZ"
    } ]
  },
  "geo" : { },
  "id_str" : "419558901218934784",
  "text" : "After 6 years uninsured, Adam P. says his new plan: \u201CAllows me to live a normal life with 1 less worry.\u201D http:\/\/t.co\/OWD1txDaJS #GetCovered",
  "id" : 419558901218934784,
  "created_at" : "2014-01-04 20:00:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 129, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/UxfrNSAwXO",
      "expanded_url" : "http:\/\/nyti.ms\/1i2syRo",
      "display_url" : "nyti.ms\/1i2syRo"
    } ]
  },
  "geo" : { },
  "id_str" : "419543801229615104",
  "text" : "The ACA in action: \"With coverage, I can be my best self. Health insurance won't control my job choices.\" http:\/\/t.co\/UxfrNSAwXO #GetCovered",
  "id" : 419543801229615104,
  "created_at" : "2014-01-04 19:00:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RenewUI",
      "indices" : [ 125, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/WRISuteyiI",
      "expanded_url" : "http:\/\/go.wh.gov\/odHg8b",
      "display_url" : "go.wh.gov\/odHg8b"
    } ]
  },
  "geo" : { },
  "id_str" : "419528702175608832",
  "text" : "\"It makes a difference to a mother who needs help feeding her kids while she looks for work.\" \u2014Obama: http:\/\/t.co\/WRISuteyiI #RenewUI",
  "id" : 419528702175608832,
  "created_at" : "2014-01-04 18:00:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RenewUI",
      "indices" : [ 105, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/Io2SdCex4d",
      "expanded_url" : "http:\/\/go.wh.gov\/aitarN",
      "display_url" : "go.wh.gov\/aitarN"
    } ]
  },
  "geo" : { },
  "id_str" : "419506052879507456",
  "text" : "\"Republicans in Congress went home for the holidays and let that lifeline expire.\" \u2014Obama on the need to #RenewUI: http:\/\/t.co\/Io2SdCex4d",
  "id" : 419506052879507456,
  "created_at" : "2014-01-04 16:30:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RenewUI",
      "indices" : [ 104, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/DjPVPFGves",
      "expanded_url" : "http:\/\/go.wh.gov\/W8zmvt",
      "display_url" : "go.wh.gov\/W8zmvt"
    } ]
  },
  "geo" : { },
  "id_str" : "419483403486892032",
  "text" : "\"We don\u2019t abandon our fellow Americans when times get tough.\" \u2014President Obama on why Congress needs to #RenewUI: http:\/\/t.co\/DjPVPFGves",
  "id" : 419483403486892032,
  "created_at" : "2014-01-04 15:00:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/419242221029036032\/photo\/1",
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/rTLnqLMYKC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BdFylB1IIAESGTm.jpg",
      "id_str" : "419242220794159105",
      "id" : 419242220794159105,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BdFylB1IIAESGTm.jpg",
      "sizes" : [ {
        "h" : 449,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 766,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 766,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/rTLnqLMYKC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "419242221029036032",
  "text" : "Stiff arm. http:\/\/t.co\/rTLnqLMYKC",
  "id" : 419242221029036032,
  "created_at" : "2014-01-03 23:01:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 126, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/5FABLmpK3y",
      "expanded_url" : "http:\/\/cnnmon.ie\/1izzDM7",
      "display_url" : "cnnmon.ie\/1izzDM7"
    } ]
  },
  "geo" : { },
  "id_str" : "419230481347915776",
  "text" : "New health insurance \u201Cgives me more freedom to do what I want professionally\u201D says Alan, 45, from FL \u2192 http:\/\/t.co\/5FABLmpK3y #GetCovered",
  "id" : 419230481347915776,
  "created_at" : "2014-01-03 22:15:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 129, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/OWD1txDaJS",
      "expanded_url" : "http:\/\/wapo.st\/1evhxFZ",
      "display_url" : "wapo.st\/1evhxFZ"
    } ]
  },
  "geo" : { },
  "id_str" : "419219158216093698",
  "text" : "28-year-old Emily W. of TN says her new $125\/month plan is \u201Cthe light at the end of the long dark tunnel\u201D http:\/\/t.co\/OWD1txDaJS #GetCovered",
  "id" : 419219158216093698,
  "created_at" : "2014-01-03 21:30:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Video",
      "screen_name" : "WHVideo",
      "indices" : [ 3, 11 ],
      "id_str" : "1378231782",
      "id" : 1378231782
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WestWingWeek",
      "indices" : [ 60, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/jbX9hLyN0V",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=0DKLj2o6d3Y&feature=youtu.be",
      "display_url" : "youtube.com\/watch?v=0DKLj2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "419214652044607488",
  "text" : "RT @WHVideo: Worth watching: Here are the top 10 moments of #WestWingWeek from 2013 \u2192 http:\/\/t.co\/jbX9hLyN0V",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WestWingWeek",
        "indices" : [ 47, 60 ]
      } ],
      "urls" : [ {
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/jbX9hLyN0V",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=0DKLj2o6d3Y&feature=youtu.be",
        "display_url" : "youtube.com\/watch?v=0DKLj2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "419213515275001856",
    "text" : "Worth watching: Here are the top 10 moments of #WestWingWeek from 2013 \u2192 http:\/\/t.co\/jbX9hLyN0V",
    "id" : 419213515275001856,
    "created_at" : "2014-01-03 21:07:45 +0000",
    "user" : {
      "name" : "White House Video",
      "screen_name" : "WHVideo",
      "protected" : false,
      "id_str" : "1378231782",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3636216064\/e21f3204adfdbc85dafef197487218a0_normal.jpeg",
      "id" : 1378231782,
      "verified" : true
    }
  },
  "id" : 419214652044607488,
  "created_at" : "2014-01-03 21:12:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 129, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/0yanWt4n3K",
      "expanded_url" : "http:\/\/bit.ly\/1fSzGyA",
      "display_url" : "bit.ly\/1fSzGyA"
    } ]
  },
  "geo" : { },
  "id_str" : "419209090246516736",
  "text" : "Cancer survivor from GA\u2014once rejected by insurers\u2014now has \"life-changing\" new coverage thanks to the ACA: http:\/\/t.co\/0yanWt4n3K #GetCovered",
  "id" : 419209090246516736,
  "created_at" : "2014-01-03 20:50:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/419200601139216384\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/GnnflhNQBZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BdFMucMIUAAG5QS.jpg",
      "id_str" : "419200601046929408",
      "id" : 419200601046929408,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BdFMucMIUAAG5QS.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/GnnflhNQBZ"
    } ],
    "hashtags" : [ {
      "text" : "RenewUI",
      "indices" : [ 107, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "419200601139216384",
  "text" : "RT if you agree: It's time to restore a vital lifeline for more than 1 million Americans looking for work. #RenewUI, http:\/\/t.co\/GnnflhNQBZ",
  "id" : 419200601139216384,
  "created_at" : "2014-01-03 20:16:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RenewUI",
      "indices" : [ 20, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "419192732720979972",
  "text" : "If Congress doesn't #RenewUI through 2014, 4.9 million Americans and 9 million family members they support will lose unemployment insurance.",
  "id" : 419192732720979972,
  "created_at" : "2014-01-03 19:45:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RenewUI",
      "indices" : [ 27, 35 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/911ru6JGVg",
      "expanded_url" : "http:\/\/go.wh.gov\/F218Hs",
      "display_url" : "go.wh.gov\/F218Hs"
    } ]
  },
  "geo" : { },
  "id_str" : "419185182583709697",
  "text" : "FACT: If Congress fails to #RenewUI benefits, it could cost our economy 240,000 jobs this year \u2192 http:\/\/t.co\/911ru6JGVg",
  "id" : 419185182583709697,
  "created_at" : "2014-01-03 19:15:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "419175963076075520",
  "text" : "RT @VP: Today, we are taking steps to further strengthen the federal background check system. It\u2019s time Congress joins us in this effort. -\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "419173031001337856",
    "text" : "Today, we are taking steps to further strengthen the federal background check system. It\u2019s time Congress joins us in this effort. --VP",
    "id" : 419173031001337856,
    "created_at" : "2014-01-03 18:26:53 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 419175963076075520,
  "created_at" : "2014-01-03 18:38:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RenewUI",
      "indices" : [ 122, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "419173858331987968",
  "text" : "FACT: Because Congress failed to act, 1.3 million Americans lost unemployment insurance this holiday season. It's time to #RenewUI.",
  "id" : 419173858331987968,
  "created_at" : "2014-01-03 18:30:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/419165848419307520\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/Ak40ltjpqk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BdEtHkKCIAA9Z7B.jpg",
      "id_str" : "419165848310259712",
      "id" : 419165848310259712,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BdEtHkKCIAA9Z7B.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/Ak40ltjpqk"
    } ],
    "hashtags" : [ {
      "text" : "RenewUI",
      "indices" : [ 104, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "419165848419307520",
  "text" : "For the sake of our economy and Americans looking for a job, it's time to renew unemployment insurance. #RenewUI, http:\/\/t.co\/Ak40ltjpqk",
  "id" : 419165848419307520,
  "created_at" : "2014-01-03 17:58:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    }, {
      "name" : "Eugene Robinson",
      "screen_name" : "Eugene_Robinson",
      "indices" : [ 74, 90 ],
      "id_str" : "59031230",
      "id" : 59031230
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 91, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/XEfzeuOZup",
      "expanded_url" : "http:\/\/wapo.st\/1euNBd1",
      "display_url" : "wapo.st\/1euNBd1"
    } ]
  },
  "geo" : { },
  "id_str" : "419140227429830656",
  "text" : "RT @Simas44: \"Nobody is going to take this coverage away.\" Must read from @Eugene_Robinson #GetCovered http:\/\/t.co\/XEfzeuOZup",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Eugene Robinson",
        "screen_name" : "Eugene_Robinson",
        "indices" : [ 61, 77 ],
        "id_str" : "59031230",
        "id" : 59031230
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 78, 89 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/XEfzeuOZup",
        "expanded_url" : "http:\/\/wapo.st\/1euNBd1",
        "display_url" : "wapo.st\/1euNBd1"
      } ]
    },
    "geo" : { },
    "id_str" : "419102193468194816",
    "text" : "\"Nobody is going to take this coverage away.\" Must read from @Eugene_Robinson #GetCovered http:\/\/t.co\/XEfzeuOZup",
    "id" : 419102193468194816,
    "created_at" : "2014-01-03 13:45:24 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 419140227429830656,
  "created_at" : "2014-01-03 16:16:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/418913445849755648\/photo\/1",
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/gOpWG2lyXs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BdBHjyYCEAAcJVQ.jpg",
      "id_str" : "418913445489020928",
      "id" : 418913445489020928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BdBHjyYCEAAcJVQ.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/gOpWG2lyXs"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "418913445849755648",
  "text" : "Belly rub. http:\/\/t.co\/gOpWG2lyXs",
  "id" : 418913445849755648,
  "created_at" : "2014-01-03 01:15:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RenewUI",
      "indices" : [ 124, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/65kS91B1YS",
      "expanded_url" : "http:\/\/go.wh.gov\/hV9F9s",
      "display_url" : "go.wh.gov\/hV9F9s"
    } ]
  },
  "geo" : { },
  "id_str" : "418864314875772928",
  "text" : "\"Failing to extend\u2026unemployment insurance through 2014 will negatively impact 14 million Americans.\" http:\/\/t.co\/65kS91B1YS #RenewUI",
  "id" : 418864314875772928,
  "created_at" : "2014-01-02 22:00:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 20, 29 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/ufbkCiVJYd",
      "expanded_url" : "http:\/\/abcn.ws\/1bC5vqV",
      "display_url" : "abcn.ws\/1bC5vqV"
    } ]
  },
  "geo" : { },
  "id_str" : "418849212357300224",
  "text" : "Amazing photos from @Interior: \"The United States like you've never seen it.\" \u2192 http:\/\/t.co\/ufbkCiVJYd",
  "id" : 418849212357300224,
  "created_at" : "2014-01-02 21:00:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/418834518637023232\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/zlYE1znDkT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bc__xodIIAAv2wR.jpg",
      "id_str" : "418834518507003904",
      "id" : 418834518507003904,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bc__xodIIAAv2wR.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/zlYE1znDkT"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/sRQ9w8vSMc",
      "expanded_url" : "http:\/\/hc.gov\/zXiq4Y",
      "display_url" : "hc.gov\/zXiq4Y"
    } ]
  },
  "geo" : { },
  "id_str" : "418834518637023232",
  "text" : "Good news: As of yesterday, insurers are required to cover expanded health benefits \u2192 http:\/\/t.co\/sRQ9w8vSMc, http:\/\/t.co\/zlYE1znDkT",
  "id" : 418834518637023232,
  "created_at" : "2014-01-02 20:01:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 18, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "418819013695655937",
  "text" : "Emily W. couldn't #GetCovered &amp; put off surgery for endometriosis for 5 years. Thanks to the ACA, she's covered &amp; can afford the procedure.",
  "id" : 418819013695655937,
  "created_at" : "2014-01-02 19:00:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RenewUI",
      "indices" : [ 128, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/NDfxLrRHIX",
      "expanded_url" : "http:\/\/go.wh.gov\/FpWpTT",
      "display_url" : "go.wh.gov\/FpWpTT"
    } ]
  },
  "geo" : { },
  "id_str" : "418811462996328449",
  "text" : "\"We as Americans can choose to have each other\u2019s backs when we face...spells of long-term unemployment.\" http:\/\/t.co\/NDfxLrRHIX #RenewUI",
  "id" : 418811462996328449,
  "created_at" : "2014-01-02 18:30:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/418804690642804736\/photo\/1",
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/Sl145K5mdx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bc_kpatIMAA0y2g.jpg",
      "id_str" : "418804690563117056",
      "id" : 418804690563117056,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bc_kpatIMAA0y2g.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Sl145K5mdx"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 83, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "418804690642804736",
  "text" : "As of yesterday, insurers can no longer put annual limits on your health coverage. #GetCovered, http:\/\/t.co\/Sl145K5mdx",
  "id" : 418804690642804736,
  "created_at" : "2014-01-02 18:03:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 126, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/1WenO0QCRz",
      "expanded_url" : "http:\/\/hc.gov\/PUw5Bf",
      "display_url" : "hc.gov\/PUw5Bf"
    } ]
  },
  "geo" : { },
  "id_str" : "418795104908742656",
  "text" : "Thanks to the Affordable Care Act, Daniel M. from Orlando now pays just $70\/month for better coverage. http:\/\/t.co\/1WenO0QCRz #GetCovered",
  "id" : 418795104908742656,
  "created_at" : "2014-01-02 17:25:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041A\u0430\u0442\u0435\u043D\u0430 \u041D\u0438\u043A\u043E\u043D\u0435\u043D\u043A\u043E",
      "screen_name" : "HealthCareTara",
      "indices" : [ 3, 18 ],
      "id_str" : "9448842",
      "id" : 9448842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "418791790012284928",
  "text" : "RT @HealthCareTara: NYT on ACA: \"It\u2019s a better policy \u2014 lower out-of-pocket, more choice of doctors... This is a very happy day.\u201D http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/9mpG45ZssJ",
        "expanded_url" : "http:\/\/nyti.ms\/JLJuiD",
        "display_url" : "nyti.ms\/JLJuiD"
      } ]
    },
    "geo" : { },
    "id_str" : "418782820094341121",
    "text" : "NYT on ACA: \"It\u2019s a better policy \u2014 lower out-of-pocket, more choice of doctors... This is a very happy day.\u201D http:\/\/t.co\/9mpG45ZssJ",
    "id" : 418782820094341121,
    "created_at" : "2014-01-02 16:36:19 +0000",
    "user" : {
      "name" : "Tara McGuinness",
      "screen_name" : "Tara44",
      "protected" : false,
      "id_str" : "1601549102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600334679951081472\/O9XyKAXl_normal.jpg",
      "id" : 1601549102,
      "verified" : true
    }
  },
  "id" : 418791790012284928,
  "created_at" : "2014-01-02 17:11:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/418781433273278465\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/1w23jmEc5R",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bc_PfqSIcAAypdw.jpg",
      "id_str" : "418781433201979392",
      "id" : 418781433201979392,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bc_PfqSIcAAypdw.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/1w23jmEc5R"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 53, 64 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/sRQ9w8vSMc",
      "expanded_url" : "http:\/\/hc.gov\/zXiq4Y",
      "display_url" : "hc.gov\/zXiq4Y"
    } ]
  },
  "geo" : { },
  "id_str" : "418781433273278465",
  "text" : "FACT: Nearly 6 out of 10 uninsured Americans can now #GetCovered for $100\/month or less \u2192 http:\/\/t.co\/sRQ9w8vSMc, http:\/\/t.co\/1w23jmEc5R",
  "id" : 418781433273278465,
  "created_at" : "2014-01-02 16:30:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/418769929236934656\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/rr4JpGftaT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bc_FCCPIMAA9Gqj.jpg",
      "id_str" : "418769929119477760",
      "id" : 418769929119477760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bc_FCCPIMAA9Gqj.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/rr4JpGftaT"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 99, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "418769929236934656",
  "text" : "As of yesterday:\nInsurers can't charge you more\nor deny you coverage\nfor a pre-existing condition.\n#GetCovered, http:\/\/t.co\/rr4JpGftaT",
  "id" : 418769929236934656,
  "created_at" : "2014-01-02 15:45:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "418506024534814720",
  "text" : "RT @FLOTUS: As we look to 2014, let's pledge to keep serving our men and women in uniform, and their families, as well as they've served us\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "418491882893606912",
    "text" : "As we look to 2014, let's pledge to keep serving our men and women in uniform, and their families, as well as they've served us. -mo",
    "id" : 418491882893606912,
    "created_at" : "2014-01-01 21:20:14 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 418506024534814720,
  "created_at" : "2014-01-01 22:16:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/aaWrf6m5hD",
      "expanded_url" : "http:\/\/go.wh.gov\/MUVxH3",
      "display_url" : "go.wh.gov\/MUVxH3"
    } ]
  },
  "geo" : { },
  "id_str" : "418498142305136641",
  "text" : "\"Michelle and I send our best wishes to Mrs. Bush for a speedy recovery.\" \u2014President Obama: http:\/\/t.co\/aaWrf6m5hD",
  "id" : 418498142305136641,
  "created_at" : "2014-01-01 21:45:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "418486228959244288",
  "text" : "I signed the ACA for kids like Marcelas Owens. He lost his mom bc she couldn't afford coverage. Today millions of Americans finally can. -bo",
  "id" : 418486228959244288,
  "created_at" : "2014-01-01 20:57:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Racusen",
      "screen_name" : "Racusen44",
      "indices" : [ 3, 13 ],
      "id_str" : "1729062162",
      "id" : 1729062162
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "418479956197654529",
  "text" : "RT @Racusen44: Mark S., a small business owner from TX, is cutting his premium in half to just $78\/month thanks to the Affordable Care Act.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 125, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "418451760382894080",
    "text" : "Mark S., a small business owner from TX, is cutting his premium in half to just $78\/month thanks to the Affordable Care Act. #GetCovered",
    "id" : 418451760382894080,
    "created_at" : "2014-01-01 18:40:48 +0000",
    "user" : {
      "name" : "Rachel Racusen",
      "screen_name" : "Racusen44",
      "protected" : false,
      "id_str" : "1729062162",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000411689100\/e84b5f12ff73878aa785c296671e9ef8_normal.png",
      "id" : 1729062162,
      "verified" : true
    }
  },
  "id" : 418479956197654529,
  "created_at" : "2014-01-01 20:32:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/1WenO0QCRz",
      "expanded_url" : "http:\/\/hc.gov\/PUw5Bf",
      "display_url" : "hc.gov\/PUw5Bf"
    } ]
  },
  "geo" : { },
  "id_str" : "418465322731982848",
  "text" : "Thanks to the Affordable Care Act, Lucy H. from TX is saving $2,300\/yr on her insurance premium after signing up at http:\/\/t.co\/1WenO0QCRz.",
  "id" : 418465322731982848,
  "created_at" : "2014-01-01 19:34:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 37, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "418456619832606722",
  "text" : "RT @Simas44: A new day! Must read on #ACA \"With coverage, I can be my best self. Health insurance won't control my job choices.\"  http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ACA",
        "indices" : [ 24, 28 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/EgnwuT8DX7",
        "expanded_url" : "http:\/\/nyti.ms\/1k7H9zH",
        "display_url" : "nyti.ms\/1k7H9zH"
      } ]
    },
    "geo" : { },
    "id_str" : "418408834973966337",
    "text" : "A new day! Must read on #ACA \"With coverage, I can be my best self. Health insurance won't control my job choices.\"  http:\/\/t.co\/EgnwuT8DX7",
    "id" : 418408834973966337,
    "created_at" : "2014-01-01 15:50:14 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 418456619832606722,
  "created_at" : "2014-01-01 19:00:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/418448503572951040\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/2c17pYH58P",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bc6gsmzCcAA_KfB.jpg",
      "id_str" : "418448503581339648",
      "id" : 418448503581339648,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bc6gsmzCcAA_KfB.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/2c17pYH58P"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 82, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/XQnuIR42Bg",
      "expanded_url" : "http:\/\/hc.gov\/iysssM",
      "display_url" : "hc.gov\/iysssM"
    } ]
  },
  "geo" : { },
  "id_str" : "418448503572951040",
  "text" : "Share the news: As of today, millions of Americans are getting expanded benefits. #GetCovered http:\/\/t.co\/XQnuIR42Bg http:\/\/t.co\/2c17pYH58P",
  "id" : 418448503572951040,
  "created_at" : "2014-01-01 18:27:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/418245818295271424\/photo\/1",
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/dXoh9AHSka",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bc3oWwgIQAAVG68.jpg",
      "id_str" : "418245818089750528",
      "id" : 418245818089750528,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bc3oWwgIQAAVG68.jpg",
      "sizes" : [ {
        "h" : 237,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 418,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 714,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 714,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/dXoh9AHSka"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "418245818295271424",
  "text" : "Happy New Year! http:\/\/t.co\/dXoh9AHSka",
  "id" : 418245818295271424,
  "created_at" : "2014-01-01 05:02:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
} ]