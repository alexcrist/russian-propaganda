Grailbird.data.tweets_2015_02 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ProtectYourSavings",
      "indices" : [ 118, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/nioxuPjOeA",
      "expanded_url" : "http:\/\/go.wh.gov\/iQJoeL",
      "display_url" : "go.wh.gov\/iQJoeL"
    } ]
  },
  "geo" : { },
  "id_str" : "571810093773148161",
  "text" : "Americans lose $17 billion\/year because of bad financial advice due to conflicts of interest \u2192 http:\/\/t.co\/nioxuPjOeA #ProtectYourSavings",
  "id" : 571810093773148161,
  "created_at" : "2015-02-28 23:12:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ProtectYourSavings",
      "indices" : [ 121, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/nioxuPjOeA",
      "expanded_url" : "http:\/\/go.wh.gov\/iQJoeL",
      "display_url" : "go.wh.gov\/iQJoeL"
    } ]
  },
  "geo" : { },
  "id_str" : "571777938829418496",
  "text" : "\"We\u2019re taking new action to protect hardworking families\u2019 retirement security.\" \u2014President Obama: http:\/\/t.co\/nioxuPjOeA #ProtectYourSavings",
  "id" : 571777938829418496,
  "created_at" : "2015-02-28 21:04:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/nioxuPjOeA",
      "expanded_url" : "http:\/\/go.wh.gov\/iQJoeL",
      "display_url" : "go.wh.gov\/iQJoeL"
    } ]
  },
  "geo" : { },
  "id_str" : "571762577593671680",
  "text" : "\"All told, over the past 5 years, the private sector has added nearly 12 million new jobs.\" \u2014President Obama: http:\/\/t.co\/nioxuPjOeA",
  "id" : 571762577593671680,
  "created_at" : "2015-02-28 20:03:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/569896665588613120\/photo\/1",
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/gBLTEMf3C4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-it9l1IcAAMQYD.jpg",
      "id_str" : "569896626500956160",
      "id" : 569896626500956160,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-it9l1IcAAMQYD.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/gBLTEMf3C4"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/nioxuPjOeA",
      "expanded_url" : "http:\/\/go.wh.gov\/iQJoeL",
      "display_url" : "go.wh.gov\/iQJoeL"
    } ]
  },
  "geo" : { },
  "id_str" : "571736642177785856",
  "text" : "\"Last year was the best year for job growth since the 1990s.\" \u2014President Obama: http:\/\/t.co\/nioxuPjOeA http:\/\/t.co\/gBLTEMf3C4",
  "id" : 571736642177785856,
  "created_at" : "2015-02-28 18:20:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/571717228145610752\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/gLt4hUKX0M",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-8krC7U0AEK7vi.jpg",
      "id_str" : "571715999638016001",
      "id" : 571715999638016001,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-8krC7U0AEK7vi.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1500
      } ],
      "display_url" : "pic.twitter.com\/gLt4hUKX0M"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/z1Z6PqWPrr",
      "expanded_url" : "http:\/\/go.wh.gov\/gGavoE",
      "display_url" : "go.wh.gov\/gGavoE"
    } ]
  },
  "geo" : { },
  "id_str" : "571717228145610752",
  "text" : "A photo of Father Hesburgh joining hands with Dr. King hangs outside of the Oval Office. http:\/\/t.co\/z1Z6PqWPrr http:\/\/t.co\/gLt4hUKX0M",
  "id" : 571717228145610752,
  "created_at" : "2015-02-28 17:03:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/nioxuPBpDa",
      "expanded_url" : "http:\/\/go.wh.gov\/iQJoeL",
      "display_url" : "go.wh.gov\/iQJoeL"
    } ]
  },
  "geo" : { },
  "id_str" : "571709949102960640",
  "text" : "\"A lifetime of hard work and responsibility should be rewarded with a shot at a secure, dignified retirement\" \u2014Obama: http:\/\/t.co\/nioxuPBpDa",
  "id" : 571709949102960640,
  "created_at" : "2015-02-28 16:34:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 13, 22 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "Homeland Security",
      "screen_name" : "DHSgov",
      "indices" : [ 47, 54 ],
      "id_str" : "15647676",
      "id" : 15647676
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/571478578979684353\/photo\/1",
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/UbIPog3SuL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-5MtdNUsAAYdH1.png",
      "id_str" : "571478546540965888",
      "id" : 571478546540965888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-5MtdNUsAAYdH1.png",
      "sizes" : [ {
        "h" : 269,
        "resize" : "fit",
        "w" : 673
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 269,
        "resize" : "fit",
        "w" : 673
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 136,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/UbIPog3SuL"
    } ],
    "hashtags" : [ {
      "text" : "FundDHS",
      "indices" : [ 65, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571478578979684353",
  "text" : "Statement by @PressSec on efforts to prevent a @DHSGov shutdown. #FundDHS http:\/\/t.co\/UbIPog3SuL",
  "id" : 571478578979684353,
  "created_at" : "2015-02-28 01:14:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/571473146844332032\/photo\/1",
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/NqPmRcRhIO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-5HtOlU4AAVzdi.png",
      "id_str" : "571473045056970752",
      "id" : 571473045056970752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-5HtOlU4AAVzdi.png",
      "sizes" : [ {
        "h" : 325,
        "resize" : "fit",
        "w" : 675
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 164,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 289,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 325,
        "resize" : "fit",
        "w" : 675
      } ],
      "display_url" : "pic.twitter.com\/NqPmRcRhIO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571473146844332032",
  "text" : "Statement by the President on the Murder of Boris Nemtsov: http:\/\/t.co\/NqPmRcRhIO",
  "id" : 571473146844332032,
  "created_at" : "2015-02-28 00:53:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "StoryCorps",
      "screen_name" : "StoryCorps",
      "indices" : [ 36, 47 ],
      "id_str" : "13786802",
      "id" : 13786802
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 66, 77 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyBrothersKeeper",
      "indices" : [ 122, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/26wblvYc9D",
      "expanded_url" : "http:\/\/youtu.be\/CnMCsxJjEd8",
      "display_url" : "youtu.be\/CnMCsxJjEd8"
    } ]
  },
  "geo" : { },
  "id_str" : "571454124702584832",
  "text" : "Full video: Watch President Obama's @StoryCorps conversation with @WhiteHouse mentee Noah McQueen: http:\/\/t.co\/26wblvYc9D #MyBrothersKeeper",
  "id" : 571454124702584832,
  "created_at" : "2015-02-27 23:37:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/571442478324125696\/photo\/1",
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/WyqQgTNDod",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-4rM0AUMAAnEBm.jpg",
      "id_str" : "571441701841022976",
      "id" : 571441701841022976,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-4rM0AUMAAnEBm.jpg",
      "sizes" : [ {
        "h" : 1500,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1500,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/WyqQgTNDod"
    } ],
    "hashtags" : [ {
      "text" : "RIPLeonardNimoy",
      "indices" : [ 48, 64 ]
    }, {
      "text" : "LLAP",
      "indices" : [ 65, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571442478324125696",
  "text" : "The spirit of Spock will live long and prosper. #RIPLeonardNimoy #LLAP http:\/\/t.co\/WyqQgTNDod",
  "id" : 571442478324125696,
  "created_at" : "2015-02-27 22:51:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "indices" : [ 3, 15 ],
      "id_str" : "15764644",
      "id" : 15764644
    }, {
      "name" : "John Boehner",
      "screen_name" : "SpeakerBoehner",
      "indices" : [ 18, 33 ],
      "id_str" : "7713202",
      "id" : 7713202
    }, {
      "name" : "House Democrats",
      "screen_name" : "HouseDemocrats",
      "indices" : [ 43, 58 ],
      "id_str" : "43963249",
      "id" : 43963249
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571439724331708416",
  "text" : "RT @NancyPelosi: .@SpeakerBoehner, 100% of @HouseDemocrats support a clean, long-term bill to fund DHS. Bring us the Senate-passed bill. We\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Boehner",
        "screen_name" : "SpeakerBoehner",
        "indices" : [ 1, 16 ],
        "id_str" : "7713202",
        "id" : 7713202
      }, {
        "name" : "House Democrats",
        "screen_name" : "HouseDemocrats",
        "indices" : [ 26, 41 ],
        "id_str" : "43963249",
        "id" : 43963249
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "571436603547258880",
    "text" : ".@SpeakerBoehner, 100% of @HouseDemocrats support a clean, long-term bill to fund DHS. Bring us the Senate-passed bill. We will vote for it.",
    "id" : 571436603547258880,
    "created_at" : "2015-02-27 22:27:57 +0000",
    "user" : {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "protected" : false,
      "id_str" : "15764644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571313158510223360\/wnSl3yXF_normal.jpeg",
      "id" : 15764644,
      "verified" : true
    }
  },
  "id" : 571439724331708416,
  "created_at" : "2015-02-27 22:40:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/571421239484420096\/photo\/1",
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/sX6yvK5eLA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-4YkSIUEAAkBkx.png",
      "id_str" : "571421214343696384",
      "id" : 571421214343696384,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-4YkSIUEAAkBkx.png",
      "sizes" : [ {
        "h" : 188,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 321,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 107,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 324,
        "resize" : "fit",
        "w" : 1033
      } ],
      "display_url" : "pic.twitter.com\/sX6yvK5eLA"
    } ],
    "hashtags" : [ {
      "text" : "RIPLeonardNimoy",
      "indices" : [ 78, 94 ]
    }, {
      "text" : "LLAP",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571421239484420096",
  "text" : "\"Long before being nerdy was cool, there was Leonard Nimoy.\" \u2014President Obama #RIPLeonardNimoy #LLAP http:\/\/t.co\/sX6yvK5eLA",
  "id" : 571421239484420096,
  "created_at" : "2015-02-27 21:26:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/571411444454961152\/photo\/1",
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/vmwjnQ3Zm3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-4ObECUcAABmZJ.png",
      "id_str" : "571410060825358336",
      "id" : 571410060825358336,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-4ObECUcAABmZJ.png",
      "sizes" : [ {
        "h" : 188,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 321,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 107,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 324,
        "resize" : "fit",
        "w" : 1033
      } ],
      "display_url" : "pic.twitter.com\/vmwjnQ3Zm3"
    } ],
    "hashtags" : [ {
      "text" : "RIPLeonardNimoy",
      "indices" : [ 34, 50 ]
    }, {
      "text" : "LLAP",
      "indices" : [ 51, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571411444454961152",
  "text" : "\"I loved Spock.\" \u2014President Obama #RIPLeonardNimoy #LLAP http:\/\/t.co\/vmwjnQ3Zm3",
  "id" : 571411444454961152,
  "created_at" : "2015-02-27 20:47:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/NASA\/status\/571365324781543425\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/nMmFMKYv1L",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-3jtV4VEAAkFI8.jpg",
      "id_str" : "571363095852945408",
      "id" : 571363095852945408,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-3jtV4VEAAkFI8.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 522,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 823,
        "resize" : "fit",
        "w" : 946
      }, {
        "h" : 296,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 823,
        "resize" : "fit",
        "w" : 946
      } ],
      "display_url" : "pic.twitter.com\/nMmFMKYv1L"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/qpeH5BTzQc",
      "expanded_url" : "http:\/\/go.nasa.gov\/10F4Ci0",
      "display_url" : "go.nasa.gov\/10F4Ci0"
    } ]
  },
  "geo" : { },
  "id_str" : "571372732803375104",
  "text" : "RT @NASA: RIP Leonard Nimoy. So many of us at NASA were inspired by Star Trek. Boldly go... http:\/\/t.co\/qpeH5BTzQc http:\/\/t.co\/nMmFMKYv1L",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/NASA\/status\/571365324781543425\/photo\/1",
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/nMmFMKYv1L",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-3jtV4VEAAkFI8.jpg",
        "id_str" : "571363095852945408",
        "id" : 571363095852945408,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-3jtV4VEAAkFI8.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 522,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 823,
          "resize" : "fit",
          "w" : 946
        }, {
          "h" : 296,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 823,
          "resize" : "fit",
          "w" : 946
        } ],
        "display_url" : "pic.twitter.com\/nMmFMKYv1L"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/qpeH5BTzQc",
        "expanded_url" : "http:\/\/go.nasa.gov\/10F4Ci0",
        "display_url" : "go.nasa.gov\/10F4Ci0"
      } ]
    },
    "geo" : { },
    "id_str" : "571365324781543425",
    "text" : "RIP Leonard Nimoy. So many of us at NASA were inspired by Star Trek. Boldly go... http:\/\/t.co\/qpeH5BTzQc http:\/\/t.co\/nMmFMKYv1L",
    "id" : 571365324781543425,
    "created_at" : "2015-02-27 17:44:43 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 571372732803375104,
  "created_at" : "2015-02-27 18:14:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/571352081157586944\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/nxgWCdo56q",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-3YQtTUcAEBd2Q.jpg",
      "id_str" : "571350509296054273",
      "id" : 571350509296054273,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-3YQtTUcAEBd2Q.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/nxgWCdo56q"
    } ],
    "hashtags" : [ {
      "text" : "FundDHS",
      "indices" : [ 108, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571352081157586944",
  "text" : "RT if you agree: It's time for Republicans in Congress to stop playing politics with our national security. #FundDHS http:\/\/t.co\/nxgWCdo56q",
  "id" : 571352081157586944,
  "created_at" : "2015-02-27 16:52:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "indices" : [ 3, 15 ],
      "id_str" : "15764644",
      "id" : 15764644
    }, {
      "name" : "John Boehner",
      "screen_name" : "SpeakerBoehner",
      "indices" : [ 40, 55 ],
      "id_str" : "7713202",
      "id" : 7713202
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontShutDownOurSecurity",
      "indices" : [ 108, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571347588550492160",
  "text" : "RT @NancyPelosi: Less than 24 hrs left. @SpeakerBoehner, let's vote on a clean, long-term bill to fund DHS! #DontShutDownOurSecurity http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Boehner",
        "screen_name" : "SpeakerBoehner",
        "indices" : [ 23, 38 ],
        "id_str" : "7713202",
        "id" : 7713202
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NancyPelosi\/status\/571344506387369984\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/o9Jn94RLQr",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-3SzQ1UUAAm135.jpg",
        "id_str" : "571344505879678976",
        "id" : 571344505879678976,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-3SzQ1UUAAm135.jpg",
        "sizes" : [ {
          "h" : 500,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/o9Jn94RLQr"
      } ],
      "hashtags" : [ {
        "text" : "DontShutDownOurSecurity",
        "indices" : [ 91, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "571344506387369984",
    "text" : "Less than 24 hrs left. @SpeakerBoehner, let's vote on a clean, long-term bill to fund DHS! #DontShutDownOurSecurity http:\/\/t.co\/o9Jn94RLQr",
    "id" : 571344506387369984,
    "created_at" : "2015-02-27 16:22:00 +0000",
    "user" : {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "protected" : false,
      "id_str" : "15764644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571313158510223360\/wnSl3yXF_normal.jpeg",
      "id" : 15764644,
      "verified" : true
    }
  },
  "id" : 571347588550492160,
  "created_at" : "2015-02-27 16:34:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NPR",
      "screen_name" : "NPR",
      "indices" : [ 3, 7 ],
      "id_str" : "5392522",
      "id" : 5392522
    }, {
      "name" : "StoryCorps",
      "screen_name" : "StoryCorps",
      "indices" : [ 86, 97 ],
      "id_str" : "13786802",
      "id" : 13786802
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MBK",
      "indices" : [ 121, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/reexD4G7Vf",
      "expanded_url" : "http:\/\/n.pr\/1Dz9IfN",
      "display_url" : "n.pr\/1Dz9IfN"
    } ]
  },
  "geo" : { },
  "id_str" : "571344951755333632",
  "text" : "RT @NPR: You shouldn't feel like you can't make mistakes, Obama tells Noah McQueen on @StoryCorps http:\/\/t.co\/reexD4G7Vf #MBK http:\/\/t.co\/K\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "StoryCorps",
        "screen_name" : "StoryCorps",
        "indices" : [ 77, 88 ],
        "id_str" : "13786802",
        "id" : 13786802
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NPR\/status\/571332652155981825\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/KjI4A5ea0a",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-3IAvyVIAAaM4S.jpg",
        "id_str" : "571332642899042304",
        "id" : 571332642899042304,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-3IAvyVIAAaM4S.jpg",
        "sizes" : [ {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/KjI4A5ea0a"
      } ],
      "hashtags" : [ {
        "text" : "MBK",
        "indices" : [ 112, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/reexD4G7Vf",
        "expanded_url" : "http:\/\/n.pr\/1Dz9IfN",
        "display_url" : "n.pr\/1Dz9IfN"
      } ]
    },
    "geo" : { },
    "id_str" : "571332652155981825",
    "text" : "You shouldn't feel like you can't make mistakes, Obama tells Noah McQueen on @StoryCorps http:\/\/t.co\/reexD4G7Vf #MBK http:\/\/t.co\/KjI4A5ea0a",
    "id" : 571332652155981825,
    "created_at" : "2015-02-27 15:34:53 +0000",
    "user" : {
      "name" : "NPR Extra",
      "screen_name" : "NPRextra",
      "protected" : false,
      "id_str" : "14062180",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623874833068236800\/eN5WiO7i_normal.png",
      "id" : 14062180,
      "verified" : true
    }
  },
  "id" : 571344951755333632,
  "created_at" : "2015-02-27 16:23:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MSNBC",
      "screen_name" : "MSNBC",
      "indices" : [ 3, 9 ],
      "id_str" : "2836421",
      "id" : 2836421
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamaTownHall",
      "indices" : [ 84, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/Cu8UeTQXeo",
      "expanded_url" : "http:\/\/nbcnews.to\/1BekAAC",
      "display_url" : "nbcnews.to\/1BekAAC"
    } ]
  },
  "geo" : { },
  "id_str" : "571340786203111424",
  "text" : "RT @msnbc: President Obama: \"At some point, there's gonna be a President Rodriguez\" #ObamaTownHall http:\/\/t.co\/Cu8UeTQXeo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/snappytv.com\" rel=\"nofollow\"\u003ESnappyTV.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ObamaTownHall",
        "indices" : [ 73, 87 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/Cu8UeTQXeo",
        "expanded_url" : "http:\/\/nbcnews.to\/1BekAAC",
        "display_url" : "nbcnews.to\/1BekAAC"
      } ]
    },
    "geo" : { },
    "id_str" : "570764945257705472",
    "text" : "President Obama: \"At some point, there's gonna be a President Rodriguez\" #ObamaTownHall http:\/\/t.co\/Cu8UeTQXeo",
    "id" : 570764945257705472,
    "created_at" : "2015-02-26 01:59:01 +0000",
    "user" : {
      "name" : "MSNBC",
      "screen_name" : "MSNBC",
      "protected" : false,
      "id_str" : "2836421",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/753308587498364928\/b53eqF6C_normal.jpg",
      "id" : 2836421,
      "verified" : true
    }
  },
  "id" : 571340786203111424,
  "created_at" : "2015-02-27 16:07:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/571327101393113088\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/3d0IbQ5Jgg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-3CYmhWoAEMaHj.jpg",
      "id_str" : "571326455659012097",
      "id" : 571326455659012097,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-3CYmhWoAEMaHj.jpg",
      "sizes" : [ {
        "h" : 2368,
        "resize" : "fit",
        "w" : 3500
      }, {
        "h" : 230,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 406,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 693,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/3d0IbQ5Jgg"
    } ],
    "hashtags" : [ {
      "text" : "MyBrothersKeeper",
      "indices" : [ 96, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/sZmk8LYaYB",
      "expanded_url" : "http:\/\/n.pr\/1AOJFAl",
      "display_url" : "n.pr\/1AOJFAl"
    } ]
  },
  "geo" : { },
  "id_str" : "571327101393113088",
  "text" : "\"I know you're going to do great things.\" \u2014Obama to mentee Noah McQueen: http:\/\/t.co\/sZmk8LYaYB #MyBrothersKeeper http:\/\/t.co\/3d0IbQ5Jgg",
  "id" : 571327101393113088,
  "created_at" : "2015-02-27 15:12:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Silence",
      "screen_name" : "universilence",
      "indices" : [ 1, 15 ],
      "id_str" : "1325654647",
      "id" : 1325654647
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/571113720538988547\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/Hn1I4WFCsu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-0A5v_UMAEYnYO.jpg",
      "id_str" : "571113719880495105",
      "id" : 571113719880495105,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-0A5v_UMAEYnYO.jpg",
      "sizes" : [ {
        "h" : 1152,
        "resize" : "fit",
        "w" : 890
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 777,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 890
      }, {
        "h" : 440,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Hn1I4WFCsu"
    } ],
    "hashtags" : [ {
      "text" : "NetNeutrality",
      "indices" : [ 99, 113 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "571111277860413440",
  "geo" : { },
  "id_str" : "571113720538988547",
  "in_reply_to_user_id" : 1325654647,
  "text" : ".@universilence you should be proud. A big thanks to you and the millions who spoke out to protect #NetNeutrality. http:\/\/t.co\/Hn1I4WFCsu",
  "id" : 571113720538988547,
  "in_reply_to_status_id" : 571111277860413440,
  "created_at" : "2015-02-27 01:04:56 +0000",
  "in_reply_to_screen_name" : "universilence",
  "in_reply_to_user_id_str" : "1325654647",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan McKenna",
      "screen_name" : "mckennasmark",
      "indices" : [ 1, 14 ],
      "id_str" : "15992301",
      "id" : 15992301
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/571109218490589186\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/iVWUD5wwMF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-z8zr7UYAAa-Tv.jpg",
      "id_str" : "571109217664262144",
      "id" : 571109217664262144,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-z8zr7UYAAa-Tv.jpg",
      "sizes" : [ {
        "h" : 1152,
        "resize" : "fit",
        "w" : 890
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 777,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 890
      }, {
        "h" : 440,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/iVWUD5wwMF"
    } ],
    "hashtags" : [ {
      "text" : "NetNeutrality",
      "indices" : [ 76, 90 ]
    }, {
      "text" : "llamas",
      "indices" : [ 91, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/MgdTxc5oc2",
      "expanded_url" : "http:\/\/wh.gov\/net-neutrality",
      "display_url" : "wh.gov\/net-neutrality"
    } ]
  },
  "in_reply_to_status_id_str" : "571106057834995712",
  "geo" : { },
  "id_str" : "571109218490589186",
  "in_reply_to_user_id" : 15992301,
  "text" : ".@mckennasmark, it was a great day for the internet! http:\/\/t.co\/MgdTxc5oc2 #NetNeutrality #llamas http:\/\/t.co\/iVWUD5wwMF",
  "id" : 571109218490589186,
  "in_reply_to_status_id" : 571106057834995712,
  "created_at" : "2015-02-27 00:47:03 +0000",
  "in_reply_to_screen_name" : "mckennasmark",
  "in_reply_to_user_id_str" : "15992301",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/571104391350124545\/photo\/1",
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/CecY4bOl5t",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-z4atNUYAAenkL.jpg",
      "id_str" : "571104390464954368",
      "id" : 571104390464954368,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-z4atNUYAAenkL.jpg",
      "sizes" : [ {
        "h" : 1152,
        "resize" : "fit",
        "w" : 890
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 777,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 890
      }, {
        "h" : 440,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/CecY4bOl5t"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571104391350124545",
  "text" : "It really was @engr_escalante. Thanks for helping to keep the internet open &amp; free! Here's a note from the President. http:\/\/t.co\/CecY4bOl5t",
  "id" : 571104391350124545,
  "created_at" : "2015-02-27 00:27:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/571095578945429504\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/qEjjDJPOyA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-zvrfjUAAAtDC3.jpg",
      "id_str" : "571094783252234240",
      "id" : 571094783252234240,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-zvrfjUAAAtDC3.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/qEjjDJPOyA"
    } ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 101, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/EEo1XP4I6H",
      "expanded_url" : "http:\/\/go.wh.gov\/exports-map",
      "display_url" : "go.wh.gov\/exports-map"
    } ]
  },
  "geo" : { },
  "id_str" : "571095578945429504",
  "text" : "More exports = more jobs.\nCheck out how exports benefit your state's economy: http:\/\/t.co\/EEo1XP4I6H #MadeInAmerica http:\/\/t.co\/qEjjDJPOyA",
  "id" : 571095578945429504,
  "created_at" : "2015-02-26 23:52:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reddit",
      "screen_name" : "reddit",
      "indices" : [ 27, 34 ],
      "id_str" : "811377",
      "id" : 811377
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/571070364324921344\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/73aiOFf7rK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-zZAZYUsAAMjjq.jpg",
      "id_str" : "571069853605343232",
      "id" : 571069853605343232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-zZAZYUsAAMjjq.jpg",
      "sizes" : [ {
        "h" : 560,
        "resize" : "fit",
        "w" : 1150
      }, {
        "h" : 499,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 292,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 166,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/73aiOFf7rK"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/H0VSWzGDyc",
      "expanded_url" : "http:\/\/www.redditblog.com\/2015\/02\/thank-you-reddit-your-efforts-led-to.html",
      "display_url" : "redditblog.com\/2015\/02\/thank-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "571070364324921344",
  "text" : "President Obama thanks the @Reddit community for helping to keep the internet open and free: http:\/\/t.co\/H0VSWzGDyc http:\/\/t.co\/73aiOFf7rK",
  "id" : 571070364324921344,
  "created_at" : "2015-02-26 22:12:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/571062992198086656\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/qPP9VPTo6a",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-zSe12VIAEBKrR.jpg",
      "id_str" : "571062680062074881",
      "id" : 571062680062074881,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-zSe12VIAEBKrR.jpg",
      "sizes" : [ {
        "h" : 560,
        "resize" : "fit",
        "w" : 1150
      }, {
        "h" : 499,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 292,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 166,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/qPP9VPTo6a"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571062992198086656",
  "text" : "\"Thanks Redditors! Wish I could upvote every one of you for helping to keep the internet open and free.\" \u2014Obama http:\/\/t.co\/qPP9VPTo6a",
  "id" : 571062992198086656,
  "created_at" : "2015-02-26 21:43:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WorkersFirst",
      "indices" : [ 95, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/TMmFcUJrOZ",
      "expanded_url" : "http:\/\/1.usa.gov\/1wlgQav",
      "display_url" : "1.usa.gov\/1wlgQav"
    } ]
  },
  "geo" : { },
  "id_str" : "571052607176876032",
  "text" : "RT @Simas44: Questions about trade agreements? Jeff Zients has answers. http:\/\/t.co\/TMmFcUJrOZ\n#WorkersFirst",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WorkersFirst",
        "indices" : [ 82, 95 ]
      } ],
      "urls" : [ {
        "indices" : [ 59, 81 ],
        "url" : "http:\/\/t.co\/TMmFcUJrOZ",
        "expanded_url" : "http:\/\/1.usa.gov\/1wlgQav",
        "display_url" : "1.usa.gov\/1wlgQav"
      } ]
    },
    "geo" : { },
    "id_str" : "571042573751431168",
    "text" : "Questions about trade agreements? Jeff Zients has answers. http:\/\/t.co\/TMmFcUJrOZ\n#WorkersFirst",
    "id" : 571042573751431168,
    "created_at" : "2015-02-26 20:22:13 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 571052607176876032,
  "created_at" : "2015-02-26 21:02:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth Warren",
      "screen_name" : "SenWarren",
      "indices" : [ 3, 13 ],
      "id_str" : "970207298",
      "id" : 970207298
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571046340257583105",
  "text" : "RT @SenWarren: The FCC did the right thing by adopting strong rules for a free &amp; open Internet. This is a huge victory for the little guys.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NetNeutrality",
        "indices" : [ 129, 143 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "571013298822385664",
    "text" : "The FCC did the right thing by adopting strong rules for a free &amp; open Internet. This is a huge victory for the little guys. #NetNeutrality",
    "id" : 571013298822385664,
    "created_at" : "2015-02-26 18:25:54 +0000",
    "user" : {
      "name" : "Elizabeth Warren",
      "screen_name" : "SenWarren",
      "protected" : false,
      "id_str" : "970207298",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/722044174799777792\/bXaodRhx_normal.jpg",
      "id" : 970207298,
      "verified" : true
    }
  },
  "id" : 571046340257583105,
  "created_at" : "2015-02-26 20:37:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Firefox",
      "screen_name" : "firefox",
      "indices" : [ 3, 11 ],
      "id_str" : "2142731",
      "id" : 2142731
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "netneutrality",
      "indices" : [ 31, 45 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/NKdKMC3cDD",
      "expanded_url" : "http:\/\/mzl.la\/1vC3Y4Q",
      "display_url" : "mzl.la\/1vC3Y4Q"
    } ]
  },
  "geo" : { },
  "id_str" : "571044829070643200",
  "text" : "RT @firefox: The FCC\u2019s vote on #netneutrality today is victory for the world\u2019s largest public resource: the Web. http:\/\/t.co\/NKdKMC3cDD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "netneutrality",
        "indices" : [ 18, 32 ]
      } ],
      "urls" : [ {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/NKdKMC3cDD",
        "expanded_url" : "http:\/\/mzl.la\/1vC3Y4Q",
        "display_url" : "mzl.la\/1vC3Y4Q"
      } ]
    },
    "geo" : { },
    "id_str" : "571021699703025664",
    "text" : "The FCC\u2019s vote on #netneutrality today is victory for the world\u2019s largest public resource: the Web. http:\/\/t.co\/NKdKMC3cDD",
    "id" : 571021699703025664,
    "created_at" : "2015-02-26 18:59:16 +0000",
    "user" : {
      "name" : "Firefox",
      "screen_name" : "firefox",
      "protected" : false,
      "id_str" : "2142731",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747872627218350081\/37FasHm-_normal.jpg",
      "id" : 2142731,
      "verified" : true
    }
  },
  "id" : 571044829070643200,
  "created_at" : "2015-02-26 20:31:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/571041608986193920\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/OsRr0OQ4YZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-y_FXDUUAAwI8I.jpg",
      "id_str" : "571041351577391104",
      "id" : 571041351577391104,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-y_FXDUUAAwI8I.jpg",
      "sizes" : [ {
        "h" : 1152,
        "resize" : "fit",
        "w" : 890
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 777,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 890
      }, {
        "h" : 440,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/OsRr0OQ4YZ"
    } ],
    "hashtags" : [ {
      "text" : "NetNeutrality",
      "indices" : [ 78, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/MgdTxbNNku",
      "expanded_url" : "http:\/\/wh.gov\/net-neutrality",
      "display_url" : "wh.gov\/net-neutrality"
    } ]
  },
  "geo" : { },
  "id_str" : "571041608986193920",
  "text" : "To everyone who spoke out in support of an open and free internet: Thank you. #NetNeutrality \u2192 http:\/\/t.co\/MgdTxbNNku http:\/\/t.co\/OsRr0OQ4YZ",
  "id" : 571041608986193920,
  "created_at" : "2015-02-26 20:18:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The FCC",
      "screen_name" : "FCC",
      "indices" : [ 26, 30 ],
      "id_str" : "66369206",
      "id" : 66369206
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/571034676636200960\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/n5Uec5mqLU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-y46-lUIAAdqWG.jpg",
      "id_str" : "571034576140640256",
      "id" : 571034576140640256,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-y46-lUIAAdqWG.jpg",
      "sizes" : [ {
        "h" : 1152,
        "resize" : "fit",
        "w" : 890
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 777,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1152,
        "resize" : "fit",
        "w" : 890
      }, {
        "h" : 440,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/n5Uec5mqLU"
    } ],
    "hashtags" : [ {
      "text" : "NetNeutrality",
      "indices" : [ 102, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/MgdTxc5oc2",
      "expanded_url" : "http:\/\/wh.gov\/net-neutrality",
      "display_url" : "wh.gov\/net-neutrality"
    } ]
  },
  "geo" : { },
  "id_str" : "571034676636200960",
  "text" : "RT to share the news: The @FCC just voted to keep the internet open and free \u2192 http:\/\/t.co\/MgdTxc5oc2 #NetNeutrality http:\/\/t.co\/n5Uec5mqLU",
  "id" : 571034676636200960,
  "created_at" : "2015-02-26 19:50:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The FCC",
      "screen_name" : "FCC",
      "indices" : [ 4, 8 ],
      "id_str" : "66369206",
      "id" : 66369206
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NetNeutrality",
      "indices" : [ 125, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "571030506302676992",
  "text" : "The @FCC just voted to keep the internet open &amp; free. That's the power of millions making their voices heard. Thank you! #NetNeutrality -bo",
  "id" : 571030506302676992,
  "created_at" : "2015-02-26 19:34:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/TWGSQvSKWl",
      "expanded_url" : "http:\/\/youtu.be\/mrwrsAC3OJk",
      "display_url" : "youtu.be\/mrwrsAC3OJk"
    } ]
  },
  "geo" : { },
  "id_str" : "571006929629085696",
  "text" : "\"If you come to America, it\u2019s because you believe in the future &amp; that has to be reflected in our politics.\" \u2014Obama: http:\/\/t.co\/TWGSQvSKWl",
  "id" : 571006929629085696,
  "created_at" : "2015-02-26 18:00:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "indices" : [ 3, 15 ],
      "id_str" : "15764644",
      "id" : 15764644
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontShutDownOurSecurity",
      "indices" : [ 104, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570989033909825538",
  "text" : "RT @NancyPelosi: Under GOP Homeland Security shutdown, 169k DHS employees would have to work w\/out pay. #DontShutDownOurSecurity Live\u2192 http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DontShutDownOurSecurity",
        "indices" : [ 87, 111 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/jDWlnbj73J",
        "expanded_url" : "http:\/\/goo.gl\/hb6Njt",
        "display_url" : "goo.gl\/hb6Njt"
      } ]
    },
    "geo" : { },
    "id_str" : "570972006784602112",
    "text" : "Under GOP Homeland Security shutdown, 169k DHS employees would have to work w\/out pay. #DontShutDownOurSecurity Live\u2192 http:\/\/t.co\/jDWlnbj73J",
    "id" : 570972006784602112,
    "created_at" : "2015-02-26 15:41:49 +0000",
    "user" : {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "protected" : false,
      "id_str" : "15764644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571313158510223360\/wnSl3yXF_normal.jpeg",
      "id" : 15764644,
      "verified" : true
    }
  },
  "id" : 570989033909825538,
  "created_at" : "2015-02-26 16:49:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "StoryCorps",
      "screen_name" : "StoryCorps",
      "indices" : [ 3, 14 ],
      "id_str" : "13786802",
      "id" : 13786802
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WhiteHouse",
      "indices" : [ 69, 80 ]
    }, {
      "text" : "MBK",
      "indices" : [ 129, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/BxS5SQ2Ms8",
      "expanded_url" : "http:\/\/bit.ly\/1DdW7b4",
      "display_url" : "bit.ly\/1DdW7b4"
    } ]
  },
  "geo" : { },
  "id_str" : "570984852058722304",
  "text" : "RT @StoryCorps: Listen tomorrow as President Obama helps us turn the #WhiteHouse into a recording booth...http:\/\/t.co\/BxS5SQ2Ms8 #MBK http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/StoryCorps\/status\/570965792470278145\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/Eyz9WjA9n2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-x6WvyWkAEQQDy.jpg",
        "id_str" : "570965783972581377",
        "id" : 570965783972581377,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-x6WvyWkAEQQDy.jpg",
        "sizes" : [ {
          "h" : 2368,
          "resize" : "fit",
          "w" : 3500
        }, {
          "h" : 230,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 406,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 693,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/Eyz9WjA9n2"
      } ],
      "hashtags" : [ {
        "text" : "WhiteHouse",
        "indices" : [ 53, 64 ]
      }, {
        "text" : "MBK",
        "indices" : [ 113, 117 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/BxS5SQ2Ms8",
        "expanded_url" : "http:\/\/bit.ly\/1DdW7b4",
        "display_url" : "bit.ly\/1DdW7b4"
      } ]
    },
    "geo" : { },
    "id_str" : "570965792470278145",
    "text" : "Listen tomorrow as President Obama helps us turn the #WhiteHouse into a recording booth...http:\/\/t.co\/BxS5SQ2Ms8 #MBK http:\/\/t.co\/Eyz9WjA9n2",
    "id" : 570965792470278145,
    "created_at" : "2015-02-26 15:17:07 +0000",
    "user" : {
      "name" : "StoryCorps",
      "screen_name" : "StoryCorps",
      "protected" : false,
      "id_str" : "13786802",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791381133107879937\/ybLRDg7L_normal.jpg",
      "id" : 13786802,
      "verified" : true
    }
  },
  "id" : 570984852058722304,
  "created_at" : "2015-02-26 16:32:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 72, 90 ]
    }, {
      "text" : "ObamaTownHall",
      "indices" : [ 124, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/2ClAgwTlEf",
      "expanded_url" : "http:\/\/youtu.be\/WcPPiTbaNTk",
      "display_url" : "youtu.be\/WcPPiTbaNTk"
    } ]
  },
  "geo" : { },
  "id_str" : "570980644731236353",
  "text" : "\"If...we voted at 60%, 70%...we would have already passed comprehensive #ImmigrationReform.\" \u2014Obama: http:\/\/t.co\/2ClAgwTlEf #ObamaTownHall",
  "id" : 570980644731236353,
  "created_at" : "2015-02-26 16:16:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamaTownHall",
      "indices" : [ 119, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570764298210975744",
  "text" : "\"If you come to America, it\u2019s because you believe in the future, and that has to be reflected in our politics.\" \u2014Obama #ObamaTownHall",
  "id" : 570764298210975744,
  "created_at" : "2015-02-26 01:56:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamaTownHall",
      "indices" : [ 125, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570764083584237568",
  "text" : "\"The question is what\u2019s happening for the next generation. You have to vote. You have to get involved now.\" \u2014President Obama #ObamaTownHall",
  "id" : 570764083584237568,
  "created_at" : "2015-02-26 01:55:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamaTownHall",
      "indices" : [ 115, 129 ]
    }, {
      "text" : "ACAWorks",
      "indices" : [ 130, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570762566034694144",
  "text" : "\"There are people who have health insurance right now because somebody went out there and voted.\" \u2014President Obama #ObamaTownHall #ACAWorks",
  "id" : 570762566034694144,
  "created_at" : "2015-02-26 01:49:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamaTownHall",
      "indices" : [ 115, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570762100630376449",
  "text" : "\"If here in the United States of America, we voted at 60%, 70%, it would transform our politics.\" \u2014President Obama #ObamaTownHall",
  "id" : 570762100630376449,
  "created_at" : "2015-02-26 01:47:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 49, 67 ]
    }, {
      "text" : "ObamaTownHall",
      "indices" : [ 126, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570760412066480129",
  "text" : "\"Let\u2019s not be confused about why we don\u2019t have...#ImmigrationReform...John Boehner refused to call the bill\" \u2014President Obama #ObamaTownHall",
  "id" : 570760412066480129,
  "created_at" : "2015-02-26 01:41:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Intel",
      "screen_name" : "intel",
      "indices" : [ 29, 35 ],
      "id_str" : "2803191",
      "id" : 2803191
    }, {
      "name" : "Google",
      "screen_name" : "google",
      "indices" : [ 40, 47 ],
      "id_str" : "20536157",
      "id" : 20536157
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamaTownHall",
      "indices" : [ 111, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570758367326576641",
  "text" : "RT @WHLive: \"The founders of @Intel and @Google and so many of our iconic companies...were immigrants.\" \u2014Obama #ObamaTownHall http:\/\/t.co\/i\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Intel",
        "screen_name" : "intel",
        "indices" : [ 17, 23 ],
        "id_str" : "2803191",
        "id" : 2803191
      }, {
        "name" : "Google",
        "screen_name" : "google",
        "indices" : [ 28, 35 ],
        "id_str" : "20536157",
        "id" : 20536157
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WHLive\/status\/570758330362171392\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/iZsIqSP7MN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-u9pchWwAECs3O.jpg",
        "id_str" : "570758297520881665",
        "id" : 570758297520881665,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-u9pchWwAECs3O.jpg",
        "sizes" : [ {
          "h" : 700,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 700,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/iZsIqSP7MN"
      } ],
      "hashtags" : [ {
        "text" : "ObamaTownHall",
        "indices" : [ 99, 113 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "570758330362171392",
    "text" : "\"The founders of @Intel and @Google and so many of our iconic companies...were immigrants.\" \u2014Obama #ObamaTownHall http:\/\/t.co\/iZsIqSP7MN",
    "id" : 570758330362171392,
    "created_at" : "2015-02-26 01:32:44 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 570758367326576641,
  "created_at" : "2015-02-26 01:32:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/570755674654830592\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/6jHpLezy7z",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-u7PZkXEAAF_9k.jpg",
      "id_str" : "570755651028324352",
      "id" : 570755651028324352,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-u7PZkXEAAF_9k.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/6jHpLezy7z"
    } ],
    "hashtags" : [ {
      "text" : "ObamaTownHall",
      "indices" : [ 102, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570755674654830592",
  "text" : "President Obama: \"We\u2019ve signed up 11 million people to get coverage through the Affordable Care Act.\" #ObamaTownHall http:\/\/t.co\/6jHpLezy7z",
  "id" : 570755674654830592,
  "created_at" : "2015-02-26 01:22:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/570754468645634052\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/xPctq1clwE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-u6IPTXAAM-4nl.jpg",
      "id_str" : "570754428501950467",
      "id" : 570754428501950467,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-u6IPTXAAM-4nl.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/xPctq1clwE"
    } ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 50, 68 ]
    }, {
      "text" : "ObamaTownHall",
      "indices" : [ 101, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570754468645634052",
  "text" : "\"Let\u2019s get on with actually passing comprehensive #ImmigrationReform.\" \u2014Obama to the GOP in Congress #ObamaTownHall http:\/\/t.co\/xPctq1clwE",
  "id" : 570754468645634052,
  "created_at" : "2015-02-26 01:17:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570753921335083008",
  "text" : "RT @WHLive: \"We\u2019re all immigrants. That\u2019s who we are. Unless you\u2019re one of the 1st Americans\u2014Native Americans.\" \u2014President Obama #ObamaTown\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ObamaTownHall",
        "indices" : [ 117, 131 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "570753889437421568",
    "text" : "\"We\u2019re all immigrants. That\u2019s who we are. Unless you\u2019re one of the 1st Americans\u2014Native Americans.\" \u2014President Obama #ObamaTownHall",
    "id" : 570753889437421568,
    "created_at" : "2015-02-26 01:15:05 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 570753921335083008,
  "created_at" : "2015-02-26 01:15:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/570752477273985024\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/rv3elfwllz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-u4U_dW8AACM2B.jpg",
      "id_str" : "570752448563965952",
      "id" : 570752448563965952,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-u4U_dW8AACM2B.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/rv3elfwllz"
    } ],
    "hashtags" : [ {
      "text" : "ObamaTownHall",
      "indices" : [ 103, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570752477273985024",
  "text" : "\"We\u2019re a nation of laws, but we\u2019re also respecting the fact that we\u2019re a nation of immigrants.\" \u2014Obama #ObamaTownHall http:\/\/t.co\/rv3elfwllz",
  "id" : 570752477273985024,
  "created_at" : "2015-02-26 01:09:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MSNBC",
      "screen_name" : "MSNBC",
      "indices" : [ 23, 29 ],
      "id_str" : "2836421",
      "id" : 2836421
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/570750769059782656\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/OamvZ7o3O5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-u2quxXAAAkMXm.jpg",
      "id_str" : "570750623018319872",
      "id" : 570750623018319872,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-u2quxXAAAkMXm.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/OamvZ7o3O5"
    } ],
    "hashtags" : [ {
      "text" : "Immigration",
      "indices" : [ 75, 87 ]
    }, {
      "text" : "ObamaTownHall",
      "indices" : [ 89, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570750769059782656",
  "text" : "Watch live: Tune in to @MSNBC to watch President Obama answer questions on #Immigration. #ObamaTownHall http:\/\/t.co\/OamvZ7o3O5",
  "id" : 570750769059782656,
  "created_at" : "2015-02-26 01:02:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MSNBC",
      "screen_name" : "MSNBC",
      "indices" : [ 3, 9 ],
      "id_str" : "2836421",
      "id" : 2836421
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamaTownHall",
      "indices" : [ 112, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/PWAOffZitS",
      "expanded_url" : "http:\/\/on.msnbc.com\/1ALTCOU",
      "display_url" : "on.msnbc.com\/1ALTCOU"
    } ]
  },
  "geo" : { },
  "id_str" : "570747642914967552",
  "text" : "RT @msnbc: Obama to Congress: Let's get on with passing comprehensive immigration reform http:\/\/t.co\/PWAOffZitS #ObamaTownHall http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/msnbc\/status\/570735201317470209\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/ZrukRgxGEl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-uopCYWkAAQmg6.png",
        "id_str" : "570735200759615488",
        "id" : 570735200759615488,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-uopCYWkAAQmg6.png",
        "sizes" : [ {
          "h" : 425,
          "resize" : "fit",
          "w" : 755
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 425,
          "resize" : "fit",
          "w" : 755
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/ZrukRgxGEl"
      } ],
      "hashtags" : [ {
        "text" : "ObamaTownHall",
        "indices" : [ 101, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/PWAOffZitS",
        "expanded_url" : "http:\/\/on.msnbc.com\/1ALTCOU",
        "display_url" : "on.msnbc.com\/1ALTCOU"
      } ]
    },
    "geo" : { },
    "id_str" : "570735201317470209",
    "text" : "Obama to Congress: Let's get on with passing comprehensive immigration reform http:\/\/t.co\/PWAOffZitS #ObamaTownHall http:\/\/t.co\/ZrukRgxGEl",
    "id" : 570735201317470209,
    "created_at" : "2015-02-26 00:00:50 +0000",
    "user" : {
      "name" : "MSNBC",
      "screen_name" : "MSNBC",
      "protected" : false,
      "id_str" : "2836421",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/753308587498364928\/b53eqF6C_normal.jpg",
      "id" : 2836421,
      "verified" : true
    }
  },
  "id" : 570747642914967552,
  "created_at" : "2015-02-26 00:50:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "BEYONC\u00C9",
      "screen_name" : "Beyonce",
      "indices" : [ 48, 56 ],
      "id_str" : "31239408",
      "id" : 31239408
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GimmeFive",
      "indices" : [ 58, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570731773660938241",
  "text" : "RT @FLOTUS: RT if you're ready to work out with @Beyonce! #GimmeFive of your workout drills (or you'll disappoint the Beygency). http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BEYONC\u00C9",
        "screen_name" : "Beyonce",
        "indices" : [ 36, 44 ],
        "id_str" : "31239408",
        "id" : 31239408
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/570731426427117569\/video\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/BC8Pu0RRRw",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/570731287373225984\/pu\/img\/1Ep9N1s9aTv7i99s.jpg",
        "id_str" : "570731287373225984",
        "id" : 570731287373225984,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/570731287373225984\/pu\/img\/1Ep9N1s9aTv7i99s.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/BC8Pu0RRRw"
      } ],
      "hashtags" : [ {
        "text" : "GimmeFive",
        "indices" : [ 46, 56 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "570731426427117569",
    "text" : "RT if you're ready to work out with @Beyonce! #GimmeFive of your workout drills (or you'll disappoint the Beygency). http:\/\/t.co\/BC8Pu0RRRw",
    "id" : 570731426427117569,
    "created_at" : "2015-02-25 23:45:50 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 570731773660938241,
  "created_at" : "2015-02-25 23:47:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/570715681047629824\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/FEqoKJjicA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-uWuC_WkAE0xbS.jpg",
      "id_str" : "570715495613239297",
      "id" : 570715495613239297,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-uWuC_WkAE0xbS.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/FEqoKJjicA"
    } ],
    "hashtags" : [ {
      "text" : "FundDHS",
      "indices" : [ 64, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570715681047629824",
  "text" : "We can't play politics with our national security. It's time to #FundDHS with no strings attached. http:\/\/t.co\/FEqoKJjicA",
  "id" : 570715681047629824,
  "created_at" : "2015-02-25 22:43:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Reach Higher",
      "screen_name" : "ReachHigher",
      "indices" : [ 27, 39 ],
      "id_str" : "2461821548",
      "id" : 2461821548
    }, {
      "name" : "Federal Student Aid",
      "screen_name" : "FAFSA",
      "indices" : [ 44, 50 ],
      "id_str" : "188001904",
      "id" : 188001904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570706995248025600",
  "text" : "RT @FLOTUS: Happening now: @ReachHigher and @FAFSA are ready to answer questions on filling out your FAFSA to help pay for college. Ask usi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Reach Higher",
        "screen_name" : "ReachHigher",
        "indices" : [ 15, 27 ],
        "id_str" : "2461821548",
        "id" : 2461821548
      }, {
        "name" : "Federal Student Aid",
        "screen_name" : "FAFSA",
        "indices" : [ 32, 38 ],
        "id_str" : "188001904",
        "id" : 188001904
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AskFAFSA",
        "indices" : [ 130, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "570704967020851201",
    "text" : "Happening now: @ReachHigher and @FAFSA are ready to answer questions on filling out your FAFSA to help pay for college. Ask using #AskFAFSA!",
    "id" : 570704967020851201,
    "created_at" : "2015-02-25 22:00:41 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 570706995248025600,
  "created_at" : "2015-02-25 22:08:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/570693575412813824\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/bmWReB2NfB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-uCpxgW8AAP68Q.jpg",
      "id_str" : "570693431967805440",
      "id" : 570693431967805440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-uCpxgW8AAP68Q.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/bmWReB2NfB"
    } ],
    "hashtags" : [ {
      "text" : "FundDHS",
      "indices" : [ 33, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570693575412813824",
  "text" : "If Republicans in Congress don't #FundDHS:\nThey'd still get paid.\nBut 30,000 employees would get furloughed. http:\/\/t.co\/bmWReB2NfB",
  "id" : 570693575412813824,
  "created_at" : "2015-02-25 21:15:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/570688126911418368\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/hDBKMUBoHY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-t8SMvXIAAi97D.jpg",
      "id_str" : "570686429891862528",
      "id" : 570686429891862528,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-t8SMvXIAAi97D.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/hDBKMUBoHY"
    } ],
    "hashtags" : [ {
      "text" : "FundDHS",
      "indices" : [ 108, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570688126911418368",
  "text" : "RT if you agree: It's time for Republicans in Congress to stop playing politics with our national security. #FundDHS http:\/\/t.co\/hDBKMUBoHY",
  "id" : 570688126911418368,
  "created_at" : "2015-02-25 20:53:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "STEM",
      "indices" : [ 31, 36 ]
    }, {
      "text" : "WeTheGeeks",
      "indices" : [ 108, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570673690540576768",
  "text" : "RT @whitehouseostp: Line-up of #STEM all-stars is ready to take your Q's right now. Ask them anything using #WeTheGeeks! https:\/\/t.co\/csGS3\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "STEM",
        "indices" : [ 11, 16 ]
      }, {
        "text" : "WeTheGeeks",
        "indices" : [ 88, 99 ]
      } ],
      "urls" : [ {
        "indices" : [ 101, 124 ],
        "url" : "https:\/\/t.co\/csGS3NQgzo",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=rI7pRNyAiJ0",
        "display_url" : "youtube.com\/watch?v=rI7pRN\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "570670607626588161",
    "text" : "Line-up of #STEM all-stars is ready to take your Q's right now. Ask them anything using #WeTheGeeks! https:\/\/t.co\/csGS3NQgzo",
    "id" : 570670607626588161,
    "created_at" : "2015-02-25 19:44:10 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 570673690540576768,
  "created_at" : "2015-02-25 19:56:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "T.J.Maxx",
      "screen_name" : "tjmaxx",
      "indices" : [ 13, 20 ],
      "id_str" : "9541782",
      "id" : 9541782
    }, {
      "name" : "Marshalls",
      "screen_name" : "marshalls",
      "indices" : [ 22, 32 ],
      "id_str" : "15458197",
      "id" : 15458197
    }, {
      "name" : "HomeGoods",
      "screen_name" : "HomeGoods",
      "indices" : [ 37, 47 ],
      "id_str" : "23986856",
      "id" : 23986856
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/570659066843955200\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/k0uaopQFfK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-tjUJ0W0AAW5-u.jpg",
      "id_str" : "570658975676551168",
      "id" : 570658975676551168,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-tjUJ0W0AAW5-u.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/k0uaopQFfK"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 89, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570659066843955200",
  "text" : "Great to see @TJMaxx, @Marshalls and @HomeGoods raising wages. It's time for Congress to #RaiseTheWage for America. http:\/\/t.co\/k0uaopQFfK",
  "id" : 570659066843955200,
  "created_at" : "2015-02-25 18:58:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WeTheGeeks",
      "indices" : [ 20, 31 ]
    }, {
      "text" : "STEM",
      "indices" : [ 109, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/9wdavxdt4Y",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2015\/02\/23\/telling-untold-stories-african-americans-stem",
      "display_url" : "whitehouse.gov\/blog\/2015\/02\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "570650403446136832",
  "text" : "RT @whitehouseostp: #WeTheGeeks is back! TODAY at 2 ET, we're Telling Untold Stories of African Americans in #STEM http:\/\/t.co\/9wdavxdt4Y h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/whitehouseostp\/status\/570591025519075332\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/Gy86JvFF5e",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-slg5iVEAAbSOX.jpg",
        "id_str" : "570591024923348992",
        "id" : 570591024923348992,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-slg5iVEAAbSOX.jpg",
        "sizes" : [ {
          "h" : 121,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 182,
          "resize" : "fit",
          "w" : 512
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 182,
          "resize" : "fit",
          "w" : 512
        }, {
          "h" : 182,
          "resize" : "fit",
          "w" : 512
        } ],
        "display_url" : "pic.twitter.com\/Gy86JvFF5e"
      } ],
      "hashtags" : [ {
        "text" : "WeTheGeeks",
        "indices" : [ 0, 11 ]
      }, {
        "text" : "STEM",
        "indices" : [ 89, 94 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/9wdavxdt4Y",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2015\/02\/23\/telling-untold-stories-african-americans-stem",
        "display_url" : "whitehouse.gov\/blog\/2015\/02\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "570591025519075332",
    "text" : "#WeTheGeeks is back! TODAY at 2 ET, we're Telling Untold Stories of African Americans in #STEM http:\/\/t.co\/9wdavxdt4Y http:\/\/t.co\/Gy86JvFF5e",
    "id" : 570591025519075332,
    "created_at" : "2015-02-25 14:27:56 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 570650403446136832,
  "created_at" : "2015-02-25 18:23:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 118, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/igihBxIulI",
      "expanded_url" : "http:\/\/youtu.be\/09Gij5hKrxg",
      "display_url" : "youtu.be\/09Gij5hKrxg"
    } ]
  },
  "geo" : { },
  "id_str" : "570636569129787392",
  "text" : "\"In a time when the world is looking to trade more, we can't afford to stand idly by.\"\nWatch \u2192 http:\/\/t.co\/igihBxIulI #MadeInAmerica",
  "id" : 570636569129787392,
  "created_at" : "2015-02-25 17:28:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/570624893651456001\/photo\/1",
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/RfO8hmx1el",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/B-tEOdLWkAA7BGE.png",
      "id_str" : "570624792933601280",
      "id" : 570624792933601280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/B-tEOdLWkAA7BGE.png",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1000
      } ],
      "display_url" : "pic.twitter.com\/RfO8hmx1el"
    } ],
    "hashtags" : [ {
      "text" : "ProtectYourSavings",
      "indices" : [ 100, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570624893651456001",
  "text" : "Back-door payments &amp; hidden fees on retirement funds are hurting the middle class. It's time to #ProtectYourSavings. http:\/\/t.co\/RfO8hmx1el",
  "id" : 570624893651456001,
  "created_at" : "2015-02-25 16:42:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570619488942452736",
  "text" : "RT @VP: \"The private sector has added almost 12 million jobs \u2013 roughly a million jobs in just the last 3 months.\" -VP Biden http:\/\/t.co\/sxW\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/570617405744885761\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/sxWV5YEYLN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-s9f4gVEAAqpmK.jpg",
        "id_str" : "570617395745722368",
        "id" : 570617395745722368,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-s9f4gVEAAqpmK.jpg",
        "sizes" : [ {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/sxWV5YEYLN"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "570617405744885761",
    "text" : "\"The private sector has added almost 12 million jobs \u2013 roughly a million jobs in just the last 3 months.\" -VP Biden http:\/\/t.co\/sxWV5YEYLN",
    "id" : 570617405744885761,
    "created_at" : "2015-02-25 16:12:45 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 570619488942452736,
  "created_at" : "2015-02-25 16:21:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rep. Marc Veasey",
      "screen_name" : "RepVeasey",
      "indices" : [ 3, 13 ],
      "id_str" : "1074129612",
      "id" : 1074129612
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontShutDownOurSecurity",
      "indices" : [ 107, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570598962538741760",
  "text" : "RT @RepVeasey: The clock is ticking. I urge my GOP colleagues, stop holding our national security hostage. #DontShutDownOurSecurity http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/RepVeasey\/status\/570575279808225280\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/Gcu2H6TzPD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-sXMYzW4AAnuYr.jpg",
        "id_str" : "570575279376228352",
        "id" : 570575279376228352,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-sXMYzW4AAnuYr.jpg",
        "sizes" : [ {
          "h" : 500,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/Gcu2H6TzPD"
      } ],
      "hashtags" : [ {
        "text" : "DontShutDownOurSecurity",
        "indices" : [ 92, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "570575279808225280",
    "text" : "The clock is ticking. I urge my GOP colleagues, stop holding our national security hostage. #DontShutDownOurSecurity http:\/\/t.co\/Gcu2H6TzPD",
    "id" : 570575279808225280,
    "created_at" : "2015-02-25 13:25:22 +0000",
    "user" : {
      "name" : "Rep. Marc Veasey",
      "screen_name" : "RepVeasey",
      "protected" : false,
      "id_str" : "1074129612",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/761614028418457600\/j7lOtIzH_normal.jpg",
      "id" : 1074129612,
      "verified" : true
    }
  },
  "id" : 570598962538741760,
  "created_at" : "2015-02-25 14:59:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 58, 69 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BHMEditathon",
      "indices" : [ 80, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570371691945152512",
  "text" : "RT @vj44: Join folks across the country in the first-ever @WhiteHouse Wikepedia #BHMEditathon! Click here to get in on the fun https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 48, 59 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BHMEditathon",
        "indices" : [ 70, 83 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/gO5gr1jQzU",
        "expanded_url" : "https:\/\/en.wikipedia.org\/wiki\/Wikipedia:Meetup\/DC\/African_Americans_in_STEM",
        "display_url" : "en.wikipedia.org\/wiki\/Wikipedia\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "570358406260719620",
    "text" : "Join folks across the country in the first-ever @WhiteHouse Wikepedia #BHMEditathon! Click here to get in on the fun https:\/\/t.co\/gO5gr1jQzU",
    "id" : 570358406260719620,
    "created_at" : "2015-02-24 23:03:35 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 570371691945152512,
  "created_at" : "2015-02-24 23:56:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "STEM",
      "indices" : [ 30, 35 ]
    }, {
      "text" : "BHMEditathon",
      "indices" : [ 107, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/p45SjDJ9bB",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2015\/02\/24\/today-join-us-our-first-stem-heroes-edit-thon",
      "display_url" : "whitehouse.gov\/blog\/2015\/02\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "570346978845917184",
  "text" : "RT @whitehouseostp: Our first #STEM Heroes edit-a-thon has begun. Join the effort - http:\/\/t.co\/p45SjDJ9bB #BHMEditathon http:\/\/t.co\/8uvd7a\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/whitehouseostp\/status\/570346368549519361\/photo\/1",
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/8uvd7aSVc3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-pG_8iWoAA5AQx.jpg",
        "id_str" : "570346367211708416",
        "id" : 570346367211708416,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-pG_8iWoAA5AQx.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/8uvd7aSVc3"
      } ],
      "hashtags" : [ {
        "text" : "STEM",
        "indices" : [ 10, 15 ]
      }, {
        "text" : "BHMEditathon",
        "indices" : [ 87, 100 ]
      } ],
      "urls" : [ {
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/p45SjDJ9bB",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2015\/02\/24\/today-join-us-our-first-stem-heroes-edit-thon",
        "display_url" : "whitehouse.gov\/blog\/2015\/02\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "570346368549519361",
    "text" : "Our first #STEM Heroes edit-a-thon has begun. Join the effort - http:\/\/t.co\/p45SjDJ9bB #BHMEditathon http:\/\/t.co\/8uvd7aSVc3",
    "id" : 570346368549519361,
    "created_at" : "2015-02-24 22:15:45 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 570346978845917184,
  "created_at" : "2015-02-24 22:18:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Surgeon General",
      "screen_name" : "Surgeon_General",
      "indices" : [ 30, 46 ],
      "id_str" : "455024343",
      "id" : 455024343
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/570345255892951040\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/13LMkaW29w",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-pFzO4UYAEcRza.jpg",
      "id_str" : "570345049285746689",
      "id" : 570345049285746689,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-pFzO4UYAEcRza.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/13LMkaW29w"
    } ],
    "hashtags" : [ {
      "text" : "Measles",
      "indices" : [ 66, 74 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/K9ALp1lS4I",
      "expanded_url" : "http:\/\/go.wh.gov\/P5ZmEz",
      "display_url" : "go.wh.gov\/P5ZmEz"
    } ]
  },
  "geo" : { },
  "id_str" : "570345255892951040",
  "text" : "Go behind the scenes with the @Surgeon_General on everything from #Measles to dunking \u2192 http:\/\/t.co\/K9ALp1lS4I http:\/\/t.co\/13LMkaW29w",
  "id" : 570345255892951040,
  "created_at" : "2015-02-24 22:11:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "STEM",
      "indices" : [ 56, 61 ]
    }, {
      "text" : "BHMEditathon",
      "indices" : [ 116, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/WWHY5Ha04o",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2015\/02\/24\/today-join-us-our-first-stem-heroes-edit-thon#",
      "display_url" : "whitehouse.gov\/blog\/2015\/02\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "570312828499980289",
  "text" : "RT @whitehouseostp: 5p ET TODAY - Join us for our First #STEM Heroes Edit-a-Thon. Learn how: http:\/\/t.co\/WWHY5Ha04o #BHMEditathon",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "STEM",
        "indices" : [ 36, 41 ]
      }, {
        "text" : "BHMEditathon",
        "indices" : [ 96, 109 ]
      } ],
      "urls" : [ {
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/WWHY5Ha04o",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2015\/02\/24\/today-join-us-our-first-stem-heroes-edit-thon#",
        "display_url" : "whitehouse.gov\/blog\/2015\/02\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "570312754478907394",
    "text" : "5p ET TODAY - Join us for our First #STEM Heroes Edit-a-Thon. Learn how: http:\/\/t.co\/WWHY5Ha04o #BHMEditathon",
    "id" : 570312754478907394,
    "created_at" : "2015-02-24 20:02:11 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 570312828499980289,
  "created_at" : "2015-02-24 20:02:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chuck Schumer",
      "screen_name" : "SenSchumer",
      "indices" : [ 3, 14 ],
      "id_str" : "17494010",
      "id" : 17494010
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACAworks",
      "indices" : [ 78, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/IL0fXDBm8g",
      "expanded_url" : "http:\/\/www.gallup.com\/poll\/181664\/arkansas-kentucky-improvement-uninsured-rates.aspx?utm_source=tagrss&utm_medium=rss&utm_campaign=syndication",
      "display_url" : "gallup.com\/poll\/181664\/ar\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "570300479063924736",
  "text" : "RT @SenSchumer: In all 50 states the number of uninsured has DROPPED, proving #ACAworks. http:\/\/t.co\/IL0fXDBm8g",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ACAworks",
        "indices" : [ 62, 71 ]
      } ],
      "urls" : [ {
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/IL0fXDBm8g",
        "expanded_url" : "http:\/\/www.gallup.com\/poll\/181664\/arkansas-kentucky-improvement-uninsured-rates.aspx?utm_source=tagrss&utm_medium=rss&utm_campaign=syndication",
        "display_url" : "gallup.com\/poll\/181664\/ar\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "570299077600145409",
    "text" : "In all 50 states the number of uninsured has DROPPED, proving #ACAworks. http:\/\/t.co\/IL0fXDBm8g",
    "id" : 570299077600145409,
    "created_at" : "2015-02-24 19:07:50 +0000",
    "user" : {
      "name" : "Chuck Schumer",
      "screen_name" : "SenSchumer",
      "protected" : false,
      "id_str" : "17494010",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623955176131575808\/zWzgRP4C_normal.jpg",
      "id" : 17494010,
      "verified" : true
    }
  },
  "id" : 570300479063924736,
  "created_at" : "2015-02-24 19:13:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/570290323332706305\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/kk2LYYrRSY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-oUBAxUAAASznc.jpg",
      "id_str" : "570290310435045376",
      "id" : 570290310435045376,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-oUBAxUAAASznc.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/kk2LYYrRSY"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/Cu5QJpiFdc",
      "expanded_url" : "http:\/\/go.wh.gov\/39UUE5",
      "display_url" : "go.wh.gov\/39UUE5"
    } ]
  },
  "geo" : { },
  "id_str" : "570290323332706305",
  "text" : "FACT: The uninsured rate \u2193 dramatically last year thanks to the Affordable Care Act \u2192 http:\/\/t.co\/Cu5QJpiFdc http:\/\/t.co\/kk2LYYrRSY",
  "id" : 570290323332706305,
  "created_at" : "2015-02-24 18:33:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/570273645433483264\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/7g5lJmGseA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-oEspVUAAAXTT5.jpg",
      "id_str" : "570273467871789056",
      "id" : 570273467871789056,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-oEspVUAAAXTT5.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/7g5lJmGseA"
    } ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 60, 69 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 95, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/Cu5QJpAg4K",
      "expanded_url" : "http:\/\/go.wh.gov\/39UUE5",
      "display_url" : "go.wh.gov\/39UUE5"
    } ]
  },
  "geo" : { },
  "id_str" : "570273645433483264",
  "text" : "The uninsured rate: \u2193\nAmericans with health coverage: \u2191\nThe #ACAWorks \u2192 http:\/\/t.co\/Cu5QJpAg4K #GetCovered http:\/\/t.co\/7g5lJmGseA",
  "id" : 570273645433483264,
  "created_at" : "2015-02-24 17:26:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BlackHistoryMonth",
      "indices" : [ 15, 33 ]
    }, {
      "text" : "HBCU",
      "indices" : [ 59, 64 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/EwhnTeDi32",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "570244883237052416",
  "text" : "RT @vj44: This #BlackHistoryMonth heroes tweet goes out to #HBCU students\/staff\/alumni. Tune in to http:\/\/t.co\/EwhnTeDi32 for the WH #HBCUc\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BlackHistoryMonth",
        "indices" : [ 5, 23 ]
      }, {
        "text" : "HBCU",
        "indices" : [ 49, 54 ]
      }, {
        "text" : "HBCUchamps",
        "indices" : [ 123, 134 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/EwhnTeDi32",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "570235246509232129",
    "text" : "This #BlackHistoryMonth heroes tweet goes out to #HBCU students\/staff\/alumni. Tune in to http:\/\/t.co\/EwhnTeDi32 for the WH #HBCUchamps event",
    "id" : 570235246509232129,
    "created_at" : "2015-02-24 14:54:11 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 570244883237052416,
  "created_at" : "2015-02-24 15:32:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Terrence J",
      "screen_name" : "TerrenceJ",
      "indices" : [ 3, 13 ],
      "id_str" : "25398075",
      "id" : 25398075
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 54, 65 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HBCUchamps",
      "indices" : [ 101, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "570017327917322241",
  "text" : "RT @TerrenceJ: Tomorrow I'm moderating a panel at the @WhiteHouse w\/ HBCU alumni! Ask your Q's using #HBCUchamps &amp; watch at 10am ET\u2192 http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 39, 50 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HBCUchamps",
        "indices" : [ 86, 97 ]
      } ],
      "urls" : [ {
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/c0OO9i4yDO",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "570012219200524289",
    "text" : "Tomorrow I'm moderating a panel at the @WhiteHouse w\/ HBCU alumni! Ask your Q's using #HBCUchamps &amp; watch at 10am ET\u2192 http:\/\/t.co\/c0OO9i4yDO",
    "id" : 570012219200524289,
    "created_at" : "2015-02-24 00:07:58 +0000",
    "user" : {
      "name" : "Terrence J",
      "screen_name" : "TerrenceJ",
      "protected" : false,
      "id_str" : "25398075",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/728073389710049280\/r-0xyFKE_normal.jpg",
      "id" : 25398075,
      "verified" : true
    }
  },
  "id" : 570017327917322241,
  "created_at" : "2015-02-24 00:28:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/570009622079279104\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/fJC1mANpIO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-kUEsdVIAAFyTZ.jpg",
      "id_str" : "570008898725289984",
      "id" : 570008898725289984,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-kUEsdVIAAFyTZ.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/fJC1mANpIO"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/3wHNR2eHDQ",
      "expanded_url" : "http:\/\/go.wh.gov\/homxgh",
      "display_url" : "go.wh.gov\/homxgh"
    } ]
  },
  "geo" : { },
  "id_str" : "570009622079279104",
  "text" : "\"After a lifetime of hard work, you should be able to retire with dignity\" \u2014President Obama: http:\/\/t.co\/3wHNR2eHDQ http:\/\/t.co\/fJC1mANpIO",
  "id" : 570009622079279104,
  "created_at" : "2015-02-23 23:57:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/569990573433556992\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/BSYpzwQIP5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-kDP0LCIAA1WKF.jpg",
      "id_str" : "569990398076919808",
      "id" : 569990398076919808,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-kDP0LCIAA1WKF.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/BSYpzwQIP5"
    } ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 101, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/igihBxIulI",
      "expanded_url" : "http:\/\/youtu.be\/09Gij5hKrxg",
      "display_url" : "youtu.be\/09Gij5hKrxg"
    } ]
  },
  "geo" : { },
  "id_str" : "569990573433556992",
  "text" : "American businesses have huge opportunities to sell their products overseas \u2192 http:\/\/t.co\/igihBxIulI #MadeInAmerica http:\/\/t.co\/BSYpzwQIP5",
  "id" : 569990573433556992,
  "created_at" : "2015-02-23 22:41:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rep. Marcia L. Fudge",
      "screen_name" : "RepMarciaFudge",
      "indices" : [ 3, 18 ],
      "id_str" : "153486399",
      "id" : 153486399
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ProtectYourSavings",
      "indices" : [ 118, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "569961493996769281",
  "text" : "RT @RepMarciaFudge: Back-door payments and hidden fees on retirement funds are hurting the middle class. It's time to #ProtectYourSavings h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/RepMarciaFudge\/status\/569956356268150785\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/Gajnf58GJi",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/B-jkSS4CIAALOkY.png",
        "id_str" : "569956355818004480",
        "id" : 569956355818004480,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/B-jkSS4CIAALOkY.png",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1000
        } ],
        "display_url" : "pic.twitter.com\/Gajnf58GJi"
      } ],
      "hashtags" : [ {
        "text" : "ProtectYourSavings",
        "indices" : [ 98, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "569956356268150785",
    "text" : "Back-door payments and hidden fees on retirement funds are hurting the middle class. It's time to #ProtectYourSavings http:\/\/t.co\/Gajnf58GJi",
    "id" : 569956356268150785,
    "created_at" : "2015-02-23 20:25:59 +0000",
    "user" : {
      "name" : "Rep. Marcia L. Fudge",
      "screen_name" : "RepMarciaFudge",
      "protected" : false,
      "id_str" : "153486399",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/748900055793491969\/H51lXb2r_normal.jpg",
      "id" : 153486399,
      "verified" : true
    }
  },
  "id" : 569961493996769281,
  "created_at" : "2015-02-23 20:46:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "569939572815228928",
  "text" : "\"If your business model rests on bilking hard-working Americans out of their retirement money, then you shouldn\u2019t be in business\" \u2014Obama",
  "id" : 569939572815228928,
  "created_at" : "2015-02-23 19:19:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ProtectYourSavings",
      "indices" : [ 125, 144 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "569938319091441664",
  "text" : "\"Bad advice that results from conflicts of interest costs middle-class &amp; working families about $17 billion\/year\" \u2014Obama #ProtectYourSavings",
  "id" : 569938319091441664,
  "created_at" : "2015-02-23 19:14:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ProtectYourSavings",
      "indices" : [ 118, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "569938092662001665",
  "text" : "\"It can cut your savings by more than a quarter over 35 years\" \u2014President Obama on back-door payments and hidden fees #ProtectYourSavings",
  "id" : 569938092662001665,
  "created_at" : "2015-02-23 19:13:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "569937441169108993",
  "text" : "RT @WHLive: \u201CIf you are working hard and putting away money\u2026you should have the peace of mind that the advice you\u2019re getting\u2026is sound\u201D \u2014Pre\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "569937415269253120",
    "text" : "\u201CIf you are working hard and putting away money\u2026you should have the peace of mind that the advice you\u2019re getting\u2026is sound\u201D \u2014President Obama",
    "id" : 569937415269253120,
    "created_at" : "2015-02-23 19:10:43 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 569937441169108993,
  "created_at" : "2015-02-23 19:10:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Social Security",
      "screen_name" : "SocialSecurity",
      "indices" : [ 84, 99 ],
      "id_str" : "39580052",
      "id" : 39580052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "569937022078611456",
  "text" : "\"We will keep it strong as long as I am President.\" \u2014President Obama  on protecting @SocialSecurity",
  "id" : 569937022078611456,
  "created_at" : "2015-02-23 19:09:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ProtectYourSavings",
      "indices" : [ 119, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "569936552660316161",
  "text" : "\"In America, after a lifetime of hard work, you should be able to retire with dignity and a sense of security.\" \u2014Obama #ProtectYourSavings",
  "id" : 569936552660316161,
  "created_at" : "2015-02-23 19:07:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "569935727280070656",
  "text" : "RT @WHLive: \"Since I took office, the stock market has more than doubled, which means\u2026401(k)s for millions of families have been replenishe\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "569935699731808256",
    "text" : "\"Since I took office, the stock market has more than doubled, which means\u2026401(k)s for millions of families have been replenished.\" \u2014Obama",
    "id" : 569935699731808256,
    "created_at" : "2015-02-23 19:03:54 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 569935727280070656,
  "created_at" : "2015-02-23 19:04:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/569935544865714176\/photo\/1",
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/c47EfxxgQe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-jRV7rCYAACIh6.jpg",
      "id_str" : "569935527588028416",
      "id" : 569935527588028416,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-jRV7rCYAACIh6.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/c47EfxxgQe"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "569935544865714176",
  "text" : "\u201CLast year was the best year for job growth since the 1990s.\u201D \u2014President Obama http:\/\/t.co\/c47EfxxgQe",
  "id" : 569935544865714176,
  "created_at" : "2015-02-23 19:03:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ProtectYourSavings",
      "indices" : [ 51, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/13HiqUAgNs",
      "expanded_url" : "http:\/\/go.wh.gov\/LmDktq",
      "display_url" : "go.wh.gov\/LmDktq"
    } ]
  },
  "geo" : { },
  "id_str" : "569934997576163328",
  "text" : "Watch live: President Obama announces new steps to #ProtectYourSavings from back-door payments and hidden fees \u2192 http:\/\/t.co\/13HiqUAgNs",
  "id" : 569934997576163328,
  "created_at" : "2015-02-23 19:01:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jan Schakowsky",
      "screen_name" : "janschakowsky",
      "indices" : [ 3, 17 ],
      "id_str" : "24195214",
      "id" : 24195214
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ProtectYourSavings",
      "indices" : [ 62, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "569934273056247811",
  "text" : "RT @janschakowsky: See how President Obama's taking action to #ProtectYourSavings from conflicted and bad retirement advice. http:\/\/t.co\/7I\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/janschakowsky\/status\/569933887687794689\/photo\/1",
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/7I7BnQmcFn",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/B-jP2c7IAAA-k8z.png",
        "id_str" : "569933887246434304",
        "id" : 569933887246434304,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/B-jP2c7IAAA-k8z.png",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1000
        } ],
        "display_url" : "pic.twitter.com\/7I7BnQmcFn"
      } ],
      "hashtags" : [ {
        "text" : "ProtectYourSavings",
        "indices" : [ 43, 62 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "569933887687794689",
    "text" : "See how President Obama's taking action to #ProtectYourSavings from conflicted and bad retirement advice. http:\/\/t.co\/7I7BnQmcFn",
    "id" : 569933887687794689,
    "created_at" : "2015-02-23 18:56:42 +0000",
    "user" : {
      "name" : "Jan Schakowsky",
      "screen_name" : "janschakowsky",
      "protected" : false,
      "id_str" : "24195214",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778943630123958276\/Tg3a8mgI_normal.jpg",
      "id" : 24195214,
      "verified" : true
    }
  },
  "id" : 569934273056247811,
  "created_at" : "2015-02-23 18:58:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 1, 6 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ProtectYourSavings",
      "indices" : [ 121, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/r6Gx1eINxT",
      "expanded_url" : "http:\/\/linkd.in\/1zaTXqz",
      "display_url" : "linkd.in\/1zaTXqz"
    } ]
  },
  "geo" : { },
  "id_str" : "569931437949849600",
  "text" : ".@VJ44 on how conflicts of interest could be eroding your savings\u2014and what we're doing to fix it: http:\/\/t.co\/r6Gx1eINxT #ProtectYourSavings",
  "id" : 569931437949849600,
  "created_at" : "2015-02-23 18:46:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ProtectYourSavings",
      "indices" : [ 36, 55 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/kAb0SkcwM9",
      "expanded_url" : "http:\/\/go.wh.gov\/YCUui6",
      "display_url" : "go.wh.gov\/YCUui6"
    }, {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/Qq1LNsV3lr",
      "expanded_url" : "http:\/\/youtu.be\/dBs6H1P7Wd0",
      "display_url" : "youtu.be\/dBs6H1P7Wd0"
    } ]
  },
  "geo" : { },
  "id_str" : "569920790348500992",
  "text" : "President Obama is taking action to #ProtectYourSavings from a conflict of interest \u2192 http:\/\/t.co\/kAb0SkcwM9\nWatch \u2192 http:\/\/t.co\/Qq1LNsV3lr",
  "id" : 569920790348500992,
  "created_at" : "2015-02-23 18:04:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/569911987154497538\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/dw0neA0MdD",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/B-i73NsCYAA3t-s.png",
      "id_str" : "569911910103932928",
      "id" : 569911910103932928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/B-i73NsCYAA3t-s.png",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1000
      } ],
      "display_url" : "pic.twitter.com\/dw0neA0MdD"
    } ],
    "hashtags" : [ {
      "text" : "ProtectYourSavings",
      "indices" : [ 86, 105 ]
    }, {
      "text" : "GIF",
      "indices" : [ 111, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "569911987154497538",
  "text" : "Here's why your retirement fund could be at risk, and what President Obama's doing to #ProtectYourSavings\u2014in 1 #GIF. http:\/\/t.co\/dw0neA0MdD",
  "id" : 569911987154497538,
  "created_at" : "2015-02-23 17:29:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FundDHS",
      "indices" : [ 128, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "569898257532350465",
  "text" : "\"Unless Congress acts, one week from now, more than 100,000 DHS employees...will show up for work without getting paid.\" \u2014Obama #FundDHS",
  "id" : 569898257532350465,
  "created_at" : "2015-02-23 16:35:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PeopleOverPolitics",
      "indices" : [ 118, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "569897848197783552",
  "text" : "\"We can all agree that it\u2019s a good thing when a family doesn\u2019t lose their home just because someone gets sick\" \u2014Obama #PeopleOverPolitics",
  "id" : 569897848197783552,
  "created_at" : "2015-02-23 16:33:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NGA",
      "screen_name" : "NatlGovsAssoc",
      "indices" : [ 90, 104 ],
      "id_str" : "393615360",
      "id" : 393615360
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/569897463139708929\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/or668r1InI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-iul9sIcAAnRZS.jpg",
      "id_str" : "569897320100425728",
      "id" : 569897320100425728,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-iul9sIcAAnRZS.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/or668r1InI"
    } ],
    "hashtags" : [ {
      "text" : "LeadOnLeave",
      "indices" : [ 105, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "569897463139708929",
  "text" : "\"States like California are leading the way providing paid leave\" \u2014President Obama to the @NatlGovsAssoc #LeadOnLeave http:\/\/t.co\/or668r1InI",
  "id" : 569897463139708929,
  "created_at" : "2015-02-23 16:31:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/569897210227384320\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/CeBzHXnunj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-iudoKIEAAaYTQ.jpg",
      "id_str" : "569897176881696768",
      "id" : 569897176881696768,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-iudoKIEAAaYTQ.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/CeBzHXnunj"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 102, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "569897210227384320",
  "text" : "\"Since 2013, 17 states have joined companies like Gap and Walmart to raise their minimum wage\" \u2014Obama #RaiseTheWage http:\/\/t.co\/CeBzHXnunj",
  "id" : 569897210227384320,
  "created_at" : "2015-02-23 16:30:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/569896665588613120\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/gBLTEMf3C4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-it9l1IcAAMQYD.jpg",
      "id_str" : "569896626500956160",
      "id" : 569896626500956160,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-it9l1IcAAMQYD.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/gBLTEMf3C4"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "569896665588613120",
  "text" : "\"Last year, the economy created more than 3 million new jobs\u2014the...best year for job growth...since the 1990s\" \u2014Obama http:\/\/t.co\/gBLTEMf3C4",
  "id" : 569896665588613120,
  "created_at" : "2015-02-23 16:28:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NGA",
      "screen_name" : "NatlGovsAssoc",
      "indices" : [ 42, 56 ],
      "id_str" : "393615360",
      "id" : 393615360
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/zKvs48dw2K",
      "expanded_url" : "http:\/\/go.wh.gov\/ahKhpR",
      "display_url" : "go.wh.gov\/ahKhpR"
    } ]
  },
  "geo" : { },
  "id_str" : "569896168085442562",
  "text" : "Watch live: President Obama speaks to the @NatlGovsAssoc \u2192 http:\/\/t.co\/zKvs48dw2K",
  "id" : 569896168085442562,
  "created_at" : "2015-02-23 16:26:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "569871685219823617",
  "text" : "RT @VP: \"We want to make community college free. We no longer believe 12 yrs is enough to compete in the global economy.\" -VP http:\/\/t.co\/Z\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/569869390021304320\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/ZpqekQAqyt",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-iVMHuCEAAigjn.jpg",
        "id_str" : "569869388325457920",
        "id" : 569869388325457920,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-iVMHuCEAAigjn.jpg",
        "sizes" : [ {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/ZpqekQAqyt"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "569869390021304320",
    "text" : "\"We want to make community college free. We no longer believe 12 yrs is enough to compete in the global economy.\" -VP http:\/\/t.co\/ZpqekQAqyt",
    "id" : 569869390021304320,
    "created_at" : "2015-02-23 14:40:24 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 569871685219823617,
  "created_at" : "2015-02-23 14:49:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Labor Department",
      "screen_name" : "USDOL",
      "indices" : [ 3, 9 ],
      "id_str" : "20179628",
      "id" : 20179628
    }, {
      "name" : "Patricia Arquette",
      "screen_name" : "PattyArquette",
      "indices" : [ 30, 44 ],
      "id_str" : "122533830",
      "id" : 122533830
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/USDOL\/status\/569711295785799680\/photo\/1",
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/TQzdAT7tpw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-gFZ2vCYAAhEkT.jpg",
      "id_str" : "569711294610038784",
      "id" : 569711294610038784,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-gFZ2vCYAAhEkT.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/TQzdAT7tpw"
    } ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 71, 80 ]
    }, {
      "text" : "Oscars",
      "indices" : [ 93, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "569711906489020416",
  "text" : "RT @USDOL: RT if you agree w\/ @PattyArquette:  It's 2015. t's time for #EqualPay for women.  #Oscars http:\/\/t.co\/TQzdAT7tpw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Patricia Arquette",
        "screen_name" : "PattyArquette",
        "indices" : [ 19, 33 ],
        "id_str" : "122533830",
        "id" : 122533830
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/USDOL\/status\/569711295785799680\/photo\/1",
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/TQzdAT7tpw",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-gFZ2vCYAAhEkT.jpg",
        "id_str" : "569711294610038784",
        "id" : 569711294610038784,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-gFZ2vCYAAhEkT.jpg",
        "sizes" : [ {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/TQzdAT7tpw"
      } ],
      "hashtags" : [ {
        "text" : "EqualPay",
        "indices" : [ 60, 69 ]
      }, {
        "text" : "Oscars",
        "indices" : [ 82, 89 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "569711295785799680",
    "text" : "RT if you agree w\/ @PattyArquette:  It's 2015. t's time for #EqualPay for women.  #Oscars http:\/\/t.co\/TQzdAT7tpw",
    "id" : 569711295785799680,
    "created_at" : "2015-02-23 04:12:12 +0000",
    "user" : {
      "name" : "US Labor Department",
      "screen_name" : "USDOL",
      "protected" : false,
      "id_str" : "20179628",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655006480697978880\/Fom0f0nJ_normal.png",
      "id" : 20179628,
      "verified" : true
    }
  },
  "id" : 569711906489020416,
  "created_at" : "2015-02-23 04:14:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "indices" : [ 3, 12 ],
      "id_str" : "1604366701",
      "id" : 1604366701
    }, {
      "name" : "Patricia Arquette",
      "screen_name" : "PattyArquette",
      "indices" : [ 30, 44 ],
      "id_str" : "122533830",
      "id" : 122533830
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Oscars",
      "indices" : [ 57, 64 ]
    }, {
      "text" : "EqualPay",
      "indices" : [ 88, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "569697711483707392",
  "text" : "RT @LaborSec: I agree w\/ what @PattyArquette said at the #Oscars: All people should get #EqualPay for equal work. When women succeed, Ameri\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Patricia Arquette",
        "screen_name" : "PattyArquette",
        "indices" : [ 16, 30 ],
        "id_str" : "122533830",
        "id" : 122533830
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Oscars",
        "indices" : [ 43, 50 ]
      }, {
        "text" : "EqualPay",
        "indices" : [ 74, 83 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "569693546762145793",
    "text" : "I agree w\/ what @PattyArquette said at the #Oscars: All people should get #EqualPay for equal work. When women succeed, America succeeds!",
    "id" : 569693546762145793,
    "created_at" : "2015-02-23 03:01:40 +0000",
    "user" : {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "protected" : false,
      "id_str" : "1604366701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744887280666611712\/eEeyFjs6_normal.jpg",
      "id" : 1604366701,
      "verified" : true
    }
  },
  "id" : 569697711483707392,
  "created_at" : "2015-02-23 03:18:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Patricia Arquette",
      "screen_name" : "PattyArquette",
      "indices" : [ 19, 33 ],
      "id_str" : "122533830",
      "id" : 122533830
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 77, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "569696808450048000",
  "text" : "RT @vj44: Congrats @PattyArquette! Thx for using your speech to advocate for #EqualPay and for understanding that when women succeed, Ameri\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Patricia Arquette",
        "screen_name" : "PattyArquette",
        "indices" : [ 9, 23 ],
        "id_str" : "122533830",
        "id" : 122533830
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EqualPay",
        "indices" : [ 67, 76 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "569695668824100865",
    "text" : "Congrats @PattyArquette! Thx for using your speech to advocate for #EqualPay and for understanding that when women succeed, America succeeds",
    "id" : 569695668824100865,
    "created_at" : "2015-02-23 03:10:06 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 569696808450048000,
  "created_at" : "2015-02-23 03:14:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    }, {
      "name" : "Interstellar",
      "screen_name" : "Interstellar",
      "indices" : [ 13, 26 ],
      "id_str" : "1325475392",
      "id" : 1325475392
    }, {
      "name" : "NASA Kepler and K2",
      "screen_name" : "NASAKepler",
      "indices" : [ 54, 65 ],
      "id_str" : "17781165",
      "id" : 17781165
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Oscars2015",
      "indices" : [ 108, 119 ]
    }, {
      "text" : "Oscars",
      "indices" : [ 120, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/KARJWhAK2O",
      "expanded_url" : "http:\/\/1.usa.gov\/eOGD14",
      "display_url" : "1.usa.gov\/eOGD14"
    } ]
  },
  "geo" : { },
  "id_str" : "569677355121311744",
  "text" : "RT @NASA: In @Interstellar, they explored new worlds. @NASAKepler really finds them: http:\/\/t.co\/KARJWhAK2O #Oscars2015 #Oscars http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Interstellar",
        "screen_name" : "Interstellar",
        "indices" : [ 3, 16 ],
        "id_str" : "1325475392",
        "id" : 1325475392
      }, {
        "name" : "NASA Kepler and K2",
        "screen_name" : "NASAKepler",
        "indices" : [ 44, 55 ],
        "id_str" : "17781165",
        "id" : 17781165
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NASA\/status\/569670542518669312\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/VqFm87tbom",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-fIyA4IMAAVSZA.jpg",
        "id_str" : "569644639440089088",
        "id" : 569644639440089088,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-fIyA4IMAAVSZA.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2026,
          "resize" : "fit",
          "w" : 3600
        } ],
        "display_url" : "pic.twitter.com\/VqFm87tbom"
      } ],
      "hashtags" : [ {
        "text" : "Oscars2015",
        "indices" : [ 98, 109 ]
      }, {
        "text" : "Oscars",
        "indices" : [ 110, 117 ]
      } ],
      "urls" : [ {
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/KARJWhAK2O",
        "expanded_url" : "http:\/\/1.usa.gov\/eOGD14",
        "display_url" : "1.usa.gov\/eOGD14"
      } ]
    },
    "geo" : { },
    "id_str" : "569670542518669312",
    "text" : "In @Interstellar, they explored new worlds. @NASAKepler really finds them: http:\/\/t.co\/KARJWhAK2O #Oscars2015 #Oscars http:\/\/t.co\/VqFm87tbom",
    "id" : 569670542518669312,
    "created_at" : "2015-02-23 01:30:15 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 569677355121311744,
  "created_at" : "2015-02-23 01:57:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/37Evzvsnw6",
      "expanded_url" : "http:\/\/go.wh.gov\/uV1K4F",
      "display_url" : "go.wh.gov\/uV1K4F"
    } ]
  },
  "geo" : { },
  "id_str" : "569632806860492801",
  "text" : "\"It would level the playing field for American workers.\" \u2014Obama on our most progressive trade agreement ever: http:\/\/t.co\/37Evzvsnw6",
  "id" : 569632806860492801,
  "created_at" : "2015-02-22 23:00:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/569587595660759041\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/JPIKnpTysH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-d103fIgAAiPyR.jpg",
      "id_str" : "569553428993835008",
      "id" : 569553428993835008,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-d103fIgAAiPyR.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/JPIKnpTysH"
    } ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 98, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/37Evzvsnw6",
      "expanded_url" : "http:\/\/go.wh.gov\/uV1K4F",
      "display_url" : "go.wh.gov\/uV1K4F"
    } ]
  },
  "geo" : { },
  "id_str" : "569587595660759041",
  "text" : "\"95% of the world\u2019s potential customers live outside our borders.\" \u2014Obama: http:\/\/t.co\/37Evzvsnw6 #MadeInAmerica http:\/\/t.co\/JPIKnpTysH",
  "id" : 569587595660759041,
  "created_at" : "2015-02-22 20:00:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/37EvzvaMEy",
      "expanded_url" : "http:\/\/go.wh.gov\/uV1K4F",
      "display_url" : "go.wh.gov\/uV1K4F"
    } ]
  },
  "geo" : { },
  "id_str" : "569552535066939393",
  "text" : "\"9 in 10 American small businesses that use eBay as a platform to sell their products are exporters.\" \u2014Obama: http:\/\/t.co\/37EvzvaMEy",
  "id" : 569552535066939393,
  "created_at" : "2015-02-22 17:41:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/37Evzvsnw6",
      "expanded_url" : "http:\/\/go.wh.gov\/uV1K4F",
      "display_url" : "go.wh.gov\/uV1K4F"
    } ]
  },
  "geo" : { },
  "id_str" : "569277988690210816",
  "text" : "\"More small businesses are using the internet to grow their business by reaching new customers\" \u2014President Obama: http:\/\/t.co\/37Evzvsnw6",
  "id" : 569277988690210816,
  "created_at" : "2015-02-21 23:30:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/569247767857537024\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/4AJbchl1WS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-YoE2sIAAAiFDY.jpg",
      "id_str" : "569186466774122496",
      "id" : 569186466774122496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-YoE2sIAAAiFDY.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/4AJbchl1WS"
    } ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 93, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/37Evzvsnw6",
      "expanded_url" : "http:\/\/go.wh.gov\/uV1K4F",
      "display_url" : "go.wh.gov\/uV1K4F"
    } ]
  },
  "geo" : { },
  "id_str" : "569247767857537024",
  "text" : "\"Exporters tend to pay their workers higher wages.\" \u2014President Obama: http:\/\/t.co\/37Evzvsnw6 #MadeInAmerica http:\/\/t.co\/4AJbchl1WS",
  "id" : 569247767857537024,
  "created_at" : "2015-02-21 21:30:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 130, 144 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/37Evzvsnw6",
      "expanded_url" : "http:\/\/go.wh.gov\/uV1K4F",
      "display_url" : "go.wh.gov\/uV1K4F"
    } ]
  },
  "geo" : { },
  "id_str" : "569217562384297984",
  "text" : "\"Our farmers, our factory workers, &amp; our small businesses are exporting more than ever before\" \u2014Obama: http:\/\/t.co\/37Evzvsnw6 #MadeInAmerica",
  "id" : 569217562384297984,
  "created_at" : "2015-02-21 19:30:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 126, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/37Evzvsnw6",
      "expanded_url" : "http:\/\/go.wh.gov\/uV1K4F",
      "display_url" : "go.wh.gov\/uV1K4F"
    } ]
  },
  "geo" : { },
  "id_str" : "569185905824497666",
  "text" : "\"Our businesses already sell goods and services in other countries at record levels\" \u2014President Obama: http:\/\/t.co\/37Evzvsnw6 #MadeInAmerica",
  "id" : 569185905824497666,
  "created_at" : "2015-02-21 17:24:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/568905370942320640\/photo\/1",
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/BvD1WTW8Y8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-UnAP5IcAIyk1a.jpg",
      "id_str" : "568903813151879170",
      "id" : 568903813151879170,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-UnAP5IcAIyk1a.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/BvD1WTW8Y8"
    } ],
    "hashtags" : [ {
      "text" : "LoveYourPetDay",
      "indices" : [ 11, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568905370942320640",
  "text" : "Best buds. #LoveYourPetDay http:\/\/t.co\/BvD1WTW8Y8",
  "id" : 568905370942320640,
  "created_at" : "2015-02-20 22:49:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Medium",
      "screen_name" : "Medium",
      "indices" : [ 16, 23 ],
      "id_str" : "571202103",
      "id" : 571202103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/pv4TOjCThz",
      "expanded_url" : "http:\/\/go.wh.gov\/data",
      "display_url" : "go.wh.gov\/data"
    } ]
  },
  "geo" : { },
  "id_str" : "568872055367577600",
  "text" : "Worth a read on @Medium: America's Chief Data Scientist on how we can use the power of data to benefit Americans \u2192 http:\/\/t.co\/pv4TOjCThz",
  "id" : 568872055367577600,
  "created_at" : "2015-02-20 20:37:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MSNBC",
      "screen_name" : "MSNBC",
      "indices" : [ 3, 9 ],
      "id_str" : "2836421",
      "id" : 2836421
    }, {
      "name" : "MSNBC",
      "screen_name" : "MSNBC",
      "indices" : [ 66, 72 ],
      "id_str" : "2836421",
      "id" : 2836421
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/msnbc\/status\/568787886998482944\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/o6QKBDkdST",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-S9kbaIQAA61fe.jpg",
      "id_str" : "568787886485815296",
      "id" : 568787886485815296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-S9kbaIQAA61fe.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/o6QKBDkdST"
    } ],
    "hashtags" : [ {
      "text" : "ObamaTownHall",
      "indices" : [ 79, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/9Drgduy4gD",
      "expanded_url" : "http:\/\/on.msnbc.com\/1GbOXHG",
      "display_url" : "on.msnbc.com\/1GbOXHG"
    } ]
  },
  "geo" : { },
  "id_str" : "568866723803172864",
  "text" : "RT @msnbc: Got an immigration question for President Obama? Tweet @msnbc using #ObamaTownHall: http:\/\/t.co\/9Drgduy4gD http:\/\/t.co\/o6QKBDkdST",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "MSNBC",
        "screen_name" : "MSNBC",
        "indices" : [ 55, 61 ],
        "id_str" : "2836421",
        "id" : 2836421
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/msnbc\/status\/568787886998482944\/photo\/1",
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/o6QKBDkdST",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-S9kbaIQAA61fe.jpg",
        "id_str" : "568787886485815296",
        "id" : 568787886485815296,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-S9kbaIQAA61fe.jpg",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/o6QKBDkdST"
      } ],
      "hashtags" : [ {
        "text" : "ObamaTownHall",
        "indices" : [ 68, 82 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/9Drgduy4gD",
        "expanded_url" : "http:\/\/on.msnbc.com\/1GbOXHG",
        "display_url" : "on.msnbc.com\/1GbOXHG"
      } ]
    },
    "geo" : { },
    "id_str" : "568787886998482944",
    "text" : "Got an immigration question for President Obama? Tweet @msnbc using #ObamaTownHall: http:\/\/t.co\/9Drgduy4gD http:\/\/t.co\/o6QKBDkdST",
    "id" : 568787886998482944,
    "created_at" : "2015-02-20 15:02:54 +0000",
    "user" : {
      "name" : "MSNBC",
      "screen_name" : "MSNBC",
      "protected" : false,
      "id_str" : "2836421",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/753308587498364928\/b53eqF6C_normal.jpg",
      "id" : 2836421,
      "verified" : true
    }
  },
  "id" : 568866723803172864,
  "created_at" : "2015-02-20 20:16:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/568860670768361472\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/wbWx4p2lWF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-T_wzcIAAA7lB_.jpg",
      "id_str" : "568860666862501888",
      "id" : 568860666862501888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-T_wzcIAAA7lB_.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/wbWx4p2lWF"
    } ],
    "hashtags" : [ {
      "text" : "FindYourPark",
      "indices" : [ 103, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/RzGINVejR2",
      "expanded_url" : "http:\/\/go.wh.gov\/KwogUx",
      "display_url" : "go.wh.gov\/KwogUx"
    } ]
  },
  "geo" : { },
  "id_str" : "568860670768361472",
  "text" : "No matter where you live, every kid should be able to enjoy our great outdoors: http:\/\/t.co\/RzGINVejR2 #FindYourPark http:\/\/t.co\/wbWx4p2lWF",
  "id" : 568860670768361472,
  "created_at" : "2015-02-20 19:52:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 3, 11 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ATD_DREAM",
      "indices" : [ 120, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568850832130764800",
  "text" : "RT @DrBiden: \"Higher education should be accessible, affordable and attainable for all American families.\"\u2013Dr. Biden at #ATD_DREAM http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ATD_DREAM",
        "indices" : [ 107, 117 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/k8p9dE7dh1",
        "expanded_url" : "http:\/\/wh.gov\/ijlK6",
        "display_url" : "wh.gov\/ijlK6"
      } ]
    },
    "geo" : { },
    "id_str" : "568849620350177281",
    "text" : "\"Higher education should be accessible, affordable and attainable for all American families.\"\u2013Dr. Biden at #ATD_DREAM http:\/\/t.co\/k8p9dE7dh1",
    "id" : 568849620350177281,
    "created_at" : "2015-02-20 19:08:12 +0000",
    "user" : {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "protected" : false,
      "id_str" : "1281405877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608687663034474496\/wvzVG_yt_normal.jpg",
      "id" : 1281405877,
      "verified" : true
    }
  },
  "id" : 568850832130764800,
  "created_at" : "2015-02-20 19:13:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "InvestInKids",
      "indices" : [ 25, 38 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/X4ucGwgLUk",
      "expanded_url" : "http:\/\/go.wh.gov\/iXXnrB",
      "display_url" : "go.wh.gov\/iXXnrB"
    } ]
  },
  "geo" : { },
  "id_str" : "568848444988788736",
  "text" : "Instead of doing more to #InvestInKids, the House GOP plan cuts funding from schools that need it most.\nHere's a map: http:\/\/t.co\/X4ucGwgLUk",
  "id" : 568848444988788736,
  "created_at" : "2015-02-20 19:03:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Kelly",
      "screen_name" : "ShuttleCDRKelly",
      "indices" : [ 3, 19 ],
      "id_str" : "65707359",
      "id" : 65707359
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568818110041436161",
  "text" : "RT @ShuttleCDRKelly: 53 years ago today, John Glenn became the first American to orbit the Earth. A real explorer with real guts. http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/ShuttleCDRKelly\/status\/568813608374640640\/photo\/1",
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/HxZicS2BPN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-TSozLIQAAcuMe.jpg",
        "id_str" : "568811051329011712",
        "id" : 568811051329011712,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-TSozLIQAAcuMe.jpg",
        "sizes" : [ {
          "h" : 423,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 469,
          "resize" : "fit",
          "w" : 666
        }, {
          "h" : 469,
          "resize" : "fit",
          "w" : 666
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 239,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/HxZicS2BPN"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "568813608374640640",
    "text" : "53 years ago today, John Glenn became the first American to orbit the Earth. A real explorer with real guts. http:\/\/t.co\/HxZicS2BPN",
    "id" : 568813608374640640,
    "created_at" : "2015-02-20 16:45:06 +0000",
    "user" : {
      "name" : "Mark Kelly",
      "screen_name" : "ShuttleCDRKelly",
      "protected" : false,
      "id_str" : "65707359",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738724057177325568\/QrZIaw99_normal.jpg",
      "id" : 65707359,
      "verified" : true
    }
  },
  "id" : 568818110041436161,
  "created_at" : "2015-02-20 17:03:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/568811148771921920\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/UPImICoDcC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-TSs7kIcAASQA-.jpg",
      "id_str" : "568811122300841984",
      "id" : 568811122300841984,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-TSs7kIcAASQA-.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/UPImICoDcC"
    } ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 99, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/igihBxIulI",
      "expanded_url" : "http:\/\/youtu.be\/09Gij5hKrxg",
      "display_url" : "youtu.be\/09Gij5hKrxg"
    } ]
  },
  "geo" : { },
  "id_str" : "568811148771921920",
  "text" : "FACT: American exports supported more than 11.3 million U.S. jobs in 2013 \u2192 http:\/\/t.co\/igihBxIulI #MadeInAmerica http:\/\/t.co\/UPImICoDcC",
  "id" : 568811148771921920,
  "created_at" : "2015-02-20 16:35:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sally Jewell",
      "screen_name" : "SecretaryJewell",
      "indices" : [ 3, 19 ],
      "id_str" : "1342861723",
      "id" : 1342861723
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FindYourPark",
      "indices" : [ 106, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568801845243719680",
  "text" : "RT @SecretaryJewell: With \"Every Kid in a Park\" every 4th grader can explore America's great outdoors! SJ #FindYourPark http:\/\/t.co\/pzIRYIj\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SecretaryJewell\/status\/568800251970232320\/photo\/1",
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/pzIRYIj7AT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-TI0LCIIAEbUFo.jpg",
        "id_str" : "568800251595988993",
        "id" : 568800251595988993,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-TI0LCIIAEbUFo.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 347,
          "resize" : "fit",
          "w" : 520
        }, {
          "h" : 347,
          "resize" : "fit",
          "w" : 520
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 347,
          "resize" : "fit",
          "w" : 520
        } ],
        "display_url" : "pic.twitter.com\/pzIRYIj7AT"
      } ],
      "hashtags" : [ {
        "text" : "FindYourPark",
        "indices" : [ 85, 98 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "568800251970232320",
    "text" : "With \"Every Kid in a Park\" every 4th grader can explore America's great outdoors! SJ #FindYourPark http:\/\/t.co\/pzIRYIj7AT",
    "id" : 568800251970232320,
    "created_at" : "2015-02-20 15:52:02 +0000",
    "user" : {
      "name" : "Sally Jewell",
      "screen_name" : "SecretaryJewell",
      "protected" : false,
      "id_str" : "1342861723",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3525481506\/1ddf16c2cb47608803abe4dc7fc133fe_normal.jpeg",
      "id" : 1342861723,
      "verified" : true
    }
  },
  "id" : 568801845243719680,
  "created_at" : "2015-02-20 15:58:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/568796505760530432\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/unOBfjLqih",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-TFMW-IYAAo3wA.jpg",
      "id_str" : "568796269070802944",
      "id" : 568796269070802944,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-TFMW-IYAAo3wA.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/unOBfjLqih"
    } ],
    "hashtags" : [ {
      "text" : "FindYourPark",
      "indices" : [ 69, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/RzGINVejR2",
      "expanded_url" : "http:\/\/go.wh.gov\/KwogUx",
      "display_url" : "go.wh.gov\/KwogUx"
    } ]
  },
  "geo" : { },
  "id_str" : "568796505760530432",
  "text" : "Free admission to all public lands.\nFor every 4th-grader in America.\n#FindYourPark \u2192 http:\/\/t.co\/RzGINVejR2 http:\/\/t.co\/unOBfjLqih",
  "id" : 568796505760530432,
  "created_at" : "2015-02-20 15:37:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/568562250954317824\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/A7cyfDaxlG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-PvYP8IEAAL08h.jpg",
      "id_str" : "568561177853431808",
      "id" : 568561177853431808,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-PvYP8IEAAL08h.jpg",
      "sizes" : [ {
        "h" : 242,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 426,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 728,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1455,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/A7cyfDaxlG"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568562250954317824",
  "text" : "Great news: President Obama's designating Browns Canyon National Monument\u2014protecting nearly 22,000 acres in CO. http:\/\/t.co\/A7cyfDaxlG",
  "id" : 568562250954317824,
  "created_at" : "2015-02-20 00:06:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/568517170247770112\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/MXpcnfBj7M",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-PHWndIYAA7X3v.jpg",
      "id_str" : "568517169341030400",
      "id" : 568517169341030400,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-PHWndIYAA7X3v.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/MXpcnfBj7M"
    } ],
    "hashtags" : [ {
      "text" : "FindYourPark",
      "indices" : [ 95, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568551064271589376",
  "text" : "RT @Interior: America's public lands are living classrooms. We need to get Every Kid in a Park #FindYourPark http:\/\/t.co\/MXpcnfBj7M",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/568517170247770112\/photo\/1",
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/MXpcnfBj7M",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-PHWndIYAA7X3v.jpg",
        "id_str" : "568517169341030400",
        "id" : 568517169341030400,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-PHWndIYAA7X3v.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/MXpcnfBj7M"
      } ],
      "hashtags" : [ {
        "text" : "FindYourPark",
        "indices" : [ 81, 94 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "568517170247770112",
    "text" : "America's public lands are living classrooms. We need to get Every Kid in a Park #FindYourPark http:\/\/t.co\/MXpcnfBj7M",
    "id" : 568517170247770112,
    "created_at" : "2015-02-19 21:07:10 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 568551064271589376,
  "created_at" : "2015-02-19 23:21:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sinai Health System",
      "screen_name" : "SinaiChicago",
      "indices" : [ 3, 16 ],
      "id_str" : "605890170",
      "id" : 605890170
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tbt",
      "indices" : [ 18, 22 ]
    }, {
      "text" : "11MillionAndCounting",
      "indices" : [ 101, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568539390437228544",
  "text" : "RT @SinaiChicago: #tbt Our navigators helping enroll members of community in health insurance plans. #11MillionAndCounting http:\/\/t.co\/B9z7\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SinaiChicago\/status\/568505345880018944\/photo\/1",
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/B9z7nTE2s6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-O8mXQCYAAXXWy.jpg",
        "id_str" : "568505345241145344",
        "id" : 568505345241145344,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-O8mXQCYAAXXWy.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1859,
          "resize" : "fit",
          "w" : 1859
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/B9z7nTE2s6"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/SinaiChicago\/status\/568505345880018944\/photo\/1",
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/B9z7nTE2s6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-O8mPOCEAApqN4.jpg",
        "id_str" : "568505343085252608",
        "id" : 568505343085252608,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-O8mPOCEAApqN4.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1535,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/B9z7nTE2s6"
      } ],
      "hashtags" : [ {
        "text" : "tbt",
        "indices" : [ 0, 4 ]
      }, {
        "text" : "11MillionAndCounting",
        "indices" : [ 83, 104 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "568505345880018944",
    "text" : "#tbt Our navigators helping enroll members of community in health insurance plans. #11MillionAndCounting http:\/\/t.co\/B9z7nTE2s6",
    "id" : 568505345880018944,
    "created_at" : "2015-02-19 20:20:11 +0000",
    "user" : {
      "name" : "Sinai Health System",
      "screen_name" : "SinaiChicago",
      "protected" : false,
      "id_str" : "605890170",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571356653560156160\/EfyAT6Rb_normal.jpeg",
      "id" : 605890170,
      "verified" : false
    }
  },
  "id" : 568539390437228544,
  "created_at" : "2015-02-19 22:35:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "NationalParkService",
      "screen_name" : "NatlParkService",
      "indices" : [ 36, 52 ],
      "id_str" : "36771809",
      "id" : 36771809
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568511161726971904",
  "text" : "RT @FLOTUS: Let's start celebrating @NatlParkService's first 100 years by helping every kid enjoy America's natural beauty. Go out &amp; #FindY\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NationalParkService",
        "screen_name" : "NatlParkService",
        "indices" : [ 24, 40 ],
        "id_str" : "36771809",
        "id" : 36771809
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FindYourPark",
        "indices" : [ 125, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "568510301588439041",
    "text" : "Let's start celebrating @NatlParkService's first 100 years by helping every kid enjoy America's natural beauty. Go out &amp; #FindYourPark! -mo",
    "id" : 568510301588439041,
    "created_at" : "2015-02-19 20:39:52 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 568511161726971904,
  "created_at" : "2015-02-19 20:43:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568506842982322176",
  "text" : "\"It is up to each of us to protect the promise of America, and to expand that promise for all people.\" \u2014President Obama",
  "id" : 568506842982322176,
  "created_at" : "2015-02-19 20:26:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568506120937086976",
  "text" : "\u201CWithout Pullman, I might not be here. Of course, without Michelle, I definitely wouldn\u2019t be here.\u201D \u2014President Obama in Chicago",
  "id" : 568506120937086976,
  "created_at" : "2015-02-19 20:23:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568504644218933248",
  "text" : "\"A massive, moral revolution for jobs and freedom. That\u2019s not just the story of a movement, it\u2019s the story of America.\" \u2014President Obama",
  "id" : 568504644218933248,
  "created_at" : "2015-02-19 20:17:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/568503280831209473\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/ckIlTQgVdP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-O6mc7IMAA2k1g.jpg",
      "id_str" : "568503147740803072",
      "id" : 568503147740803072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-O6mc7IMAA2k1g.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ckIlTQgVdP"
    } ],
    "hashtags" : [ {
      "text" : "ObamaLovesAmerica",
      "indices" : [ 93, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568503280831209473",
  "text" : "Obama: \u201CI\u2019m using my powers as President to announce America\u2019s 3 newest National Monuments.\" #ObamaLovesAmerica http:\/\/t.co\/ckIlTQgVdP",
  "id" : 568503280831209473,
  "created_at" : "2015-02-19 20:11:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/568502940006268930\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/siLhJqzvNr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-O6Y_cIYAA5-wm.jpg",
      "id_str" : "568502916487864320",
      "id" : 568502916487864320,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-O6Y_cIYAA5-wm.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1366,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/siLhJqzvNr"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568502940006268930",
  "text" : "\"No matter where you live, our parks and monuments, lands and waters...are your birthright as Americans.\" \u2014Obama http:\/\/t.co\/siLhJqzvNr",
  "id" : 568502940006268930,
  "created_at" : "2015-02-19 20:10:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/568502396269129728\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/QTg9NdJfep",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-O54GMIgAE_tH5.jpg",
      "id_str" : "568502351364128769",
      "id" : 568502351364128769,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-O54GMIgAE_tH5.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/QTg9NdJfep"
    } ],
    "hashtags" : [ {
      "text" : "FindYourPark",
      "indices" : [ 44, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568502396269129728",
  "text" : "\"We\u2019re going to encourage every American to #FindYourPark...chances are, there\u2019s one closer than you think.\" \u2014Obama http:\/\/t.co\/QTg9NdJfep",
  "id" : 568502396269129728,
  "created_at" : "2015-02-19 20:08:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/568502152332767232\/photo\/1",
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/3bRdxTdoZQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-O5rJ1IQAATr2E.jpg",
      "id_str" : "568502129003085824",
      "id" : 568502129003085824,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-O5rJ1IQAATr2E.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1920,
        "resize" : "fit",
        "w" : 2560
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/3bRdxTdoZQ"
    } ],
    "hashtags" : [ {
      "text" : "FindYourPark",
      "indices" : [ 107, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568502152332767232",
  "text" : "\"I\u2019ve used my authority to set aside more public lands &amp; waters than any President in history.\" \u2014Obama #FindYourPark http:\/\/t.co\/3bRdxTdoZQ",
  "id" : 568502152332767232,
  "created_at" : "2015-02-19 20:07:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/568501893934264320\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/5uq4YJxumE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-O5cIVIMAE5Mqr.jpg",
      "id_str" : "568501870902390785",
      "id" : 568501870902390785,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-O5cIVIMAE5Mqr.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/5uq4YJxumE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568501893934264320",
  "text" : "\"The country\u2019s most special places should belong not just to the rich and powerful, but...to everybody\" \u2014Obama http:\/\/t.co\/5uq4YJxumE",
  "id" : 568501893934264320,
  "created_at" : "2015-02-19 20:06:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NationalParkService",
      "screen_name" : "NatlParkService",
      "indices" : [ 59, 75 ],
      "id_str" : "36771809",
      "id" : 36771809
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/568501402907090945\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/DhdRD7tjEx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-O4yNIIUAAenXX.jpg",
      "id_str" : "568501150635544576",
      "id" : 568501150635544576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-O4yNIIUAAenXX.jpg",
      "sizes" : [ {
        "h" : 242,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 426,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 728,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1455,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/DhdRD7tjEx"
    } ],
    "hashtags" : [ {
      "text" : "FindYourPark",
      "indices" : [ 95, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568501402907090945",
  "text" : "\"We\u2019re here because next year is the 100th birthday of the @NatlParkService.\" \u2014President Obama #FindYourPark http:\/\/t.co\/DhdRD7tjEx",
  "id" : 568501402907090945,
  "created_at" : "2015-02-19 20:04:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/568500282738524160\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/tCE1MTNwTW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-O39zBIMAEFozt.jpg",
      "id_str" : "568500250273656833",
      "id" : 568500250273656833,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-O39zBIMAEFozt.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/tCE1MTNwTW"
    } ],
    "hashtags" : [ {
      "text" : "FindYourPark",
      "indices" : [ 92, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/bqzz1zCl4H",
      "expanded_url" : "http:\/\/go.wh.gov\/v7eKzw",
      "display_url" : "go.wh.gov\/v7eKzw"
    } ]
  },
  "geo" : { },
  "id_str" : "568500282738524160",
  "text" : "\"Hello, Chicago! Also known as, \u201CChiberia.\u201D \u2014President Obama\nWatch \u2192 http:\/\/t.co\/bqzz1zCl4H #FindYourPark http:\/\/t.co\/tCE1MTNwTW",
  "id" : 568500282738524160,
  "created_at" : "2015-02-19 20:00:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/568497364304044032\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/Dqnfv6m5mr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-O1TkNIYAA5Yfs.jpg",
      "id_str" : "568497325719707648",
      "id" : 568497325719707648,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-O1TkNIYAA5Yfs.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1366,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/Dqnfv6m5mr"
    } ],
    "hashtags" : [ {
      "text" : "FindYourPark",
      "indices" : [ 95, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/bqzz1zCl4H",
      "expanded_url" : "http:\/\/go.wh.gov\/v7eKzw",
      "display_url" : "go.wh.gov\/v7eKzw"
    } ]
  },
  "geo" : { },
  "id_str" : "568497364304044032",
  "text" : "Watch President Obama designate 3 new National Monuments at 2:55pm ET \u2192 http:\/\/t.co\/bqzz1zCl4H #FindYourPark http:\/\/t.co\/Dqnfv6m5mr",
  "id" : 568497364304044032,
  "created_at" : "2015-02-19 19:48:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/568494035620335616\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/ZkfuKcA6Ch",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-OvkkgIUAAEzVB.jpg",
      "id_str" : "568491020787404800",
      "id" : 568491020787404800,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-OvkkgIUAAEzVB.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ZkfuKcA6Ch"
    } ],
    "hashtags" : [ {
      "text" : "FindYourPark",
      "indices" : [ 101, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/RzGINUWIss",
      "expanded_url" : "http:\/\/go.wh.gov\/KwogUx",
      "display_url" : "go.wh.gov\/KwogUx"
    } ]
  },
  "geo" : { },
  "id_str" : "568494035620335616",
  "text" : "RT if you agree: Every kid should be able to enjoy America's great outdoors \u2192 http:\/\/t.co\/RzGINUWIss #FindYourPark http:\/\/t.co\/ZkfuKcA6Ch",
  "id" : 568494035620335616,
  "created_at" : "2015-02-19 19:35:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/568488319862116352\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/cpLVFYBTl6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-OsmJuIcAARtQP.jpg",
      "id_str" : "568487749423230976",
      "id" : 568487749423230976,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-OsmJuIcAARtQP.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/cpLVFYBTl6"
    } ],
    "hashtags" : [ {
      "text" : "FindYourPark",
      "indices" : [ 104, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568488319862116352",
  "text" : "The President's launching a new effort to give every 4th-grader in America free access to public lands. #FindYourPark http:\/\/t.co\/cpLVFYBTl6",
  "id" : 568488319862116352,
  "created_at" : "2015-02-19 19:12:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Walmart",
      "screen_name" : "Walmart",
      "indices" : [ 12, 20 ],
      "id_str" : "17137891",
      "id" : 17137891
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/568479232453685248\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/DzvdEicER2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-Oiq88IcAAVaES.jpg",
      "id_str" : "568476836775358464",
      "id" : 568476836775358464,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-Oiq88IcAAVaES.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/DzvdEicER2"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 94, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568479232453685248",
  "text" : "Good to see @Walmart raising wages for about 500,000 employees.\nNow it's time for Congress to #RaiseTheWage. http:\/\/t.co\/DzvdEicER2",
  "id" : 568479232453685248,
  "created_at" : "2015-02-19 18:36:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ERP15",
      "indices" : [ 107, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/fcLGYV0qSg",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/sites\/default\/files\/docs\/cea_2015_erp.pdf",
      "display_url" : "whitehouse.gov\/sites\/default\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "568466066189336576",
  "text" : "RT @CEABetsey: Labor market recovery accelerated in 2014, &amp; the yr saw the best job growth since 1999. #ERP15 http:\/\/t.co\/fcLGYV0qSg http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CEABetsey\/status\/568439924770238464\/photo\/1",
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/kAPBlS6uTG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-OBGVPCQAAVa_7.jpg",
        "id_str" : "568439923758219264",
        "id" : 568439923758219264,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-OBGVPCQAAVa_7.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 460,
          "resize" : "fit",
          "w" : 540
        }, {
          "h" : 460,
          "resize" : "fit",
          "w" : 540
        }, {
          "h" : 460,
          "resize" : "fit",
          "w" : 540
        }, {
          "h" : 290,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/kAPBlS6uTG"
      } ],
      "hashtags" : [ {
        "text" : "ERP15",
        "indices" : [ 92, 98 ]
      } ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/fcLGYV0qSg",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/sites\/default\/files\/docs\/cea_2015_erp.pdf",
        "display_url" : "whitehouse.gov\/sites\/default\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "568439924770238464",
    "text" : "Labor market recovery accelerated in 2014, &amp; the yr saw the best job growth since 1999. #ERP15 http:\/\/t.co\/fcLGYV0qSg http:\/\/t.co\/kAPBlS6uTG",
    "id" : 568439924770238464,
    "created_at" : "2015-02-19 16:00:13 +0000",
    "user" : {
      "name" : "Sandy Black",
      "screen_name" : "CEASandy",
      "protected" : false,
      "id_str" : "1979039203",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/707608742498439169\/VDM-nQKG_normal.jpg",
      "id" : 1979039203,
      "verified" : true
    }
  },
  "id" : 568466066189336576,
  "created_at" : "2015-02-19 17:44:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Furman",
      "screen_name" : "CEAChair",
      "indices" : [ 3, 12 ],
      "id_str" : "1861751828",
      "id" : 1861751828
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/CEAChair\/status\/568445710229573632\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/6NA99BlaJB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-OGXBiCIAExAYT.jpg",
      "id_str" : "568445708085108737",
      "id" : 568445708085108737,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-OGXBiCIAExAYT.jpg",
      "sizes" : [ {
        "h" : 543,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 308,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 928,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1855,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/6NA99BlaJB"
    } ],
    "hashtags" : [ {
      "text" : "ERP15",
      "indices" : [ 78, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/tfSMv4zNMI",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/sites\/default\/files\/docs\/cea_2015_erp.pdf",
      "display_url" : "whitehouse.gov\/sites\/default\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "568459176839491584",
  "text" : "RT @CEAChair: Pickup in job growth in 2014 mainly in higher-paying industries #ERP15 http:\/\/t.co\/tfSMv4zNMI http:\/\/t.co\/6NA99BlaJB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/CEAChair\/status\/568445710229573632\/photo\/1",
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/6NA99BlaJB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-OGXBiCIAExAYT.jpg",
        "id_str" : "568445708085108737",
        "id" : 568445708085108737,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-OGXBiCIAExAYT.jpg",
        "sizes" : [ {
          "h" : 543,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 308,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 928,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1855,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/6NA99BlaJB"
      } ],
      "hashtags" : [ {
        "text" : "ERP15",
        "indices" : [ 64, 70 ]
      } ],
      "urls" : [ {
        "indices" : [ 71, 93 ],
        "url" : "http:\/\/t.co\/tfSMv4zNMI",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/sites\/default\/files\/docs\/cea_2015_erp.pdf",
        "display_url" : "whitehouse.gov\/sites\/default\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "568445710229573632",
    "text" : "Pickup in job growth in 2014 mainly in higher-paying industries #ERP15 http:\/\/t.co\/tfSMv4zNMI http:\/\/t.co\/6NA99BlaJB",
    "id" : 568445710229573632,
    "created_at" : "2015-02-19 16:23:13 +0000",
    "user" : {
      "name" : "Jason Furman",
      "screen_name" : "CEAChair",
      "protected" : false,
      "id_str" : "1861751828",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000628384447\/c9cb85dbdb73c8bac4f28ce4cc46f38b_normal.jpeg",
      "id" : 1861751828,
      "verified" : true
    }
  },
  "id" : 568459176839491584,
  "created_at" : "2015-02-19 17:16:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Furman",
      "screen_name" : "CEAChair",
      "indices" : [ 3, 12 ],
      "id_str" : "1861751828",
      "id" : 1861751828
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CEAChair\/status\/568436496090296320\/photo\/1",
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/kzeZl5fBow",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-N9-YDCAAAc2Mh.jpg",
      "id_str" : "568436488539340800",
      "id" : 568436488539340800,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-N9-YDCAAAc2Mh.jpg",
      "sizes" : [ {
        "h" : 306,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1842,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 540,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 921,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/kzeZl5fBow"
    } ],
    "hashtags" : [ {
      "text" : "ERP15",
      "indices" : [ 66, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/tfSMv4zNMI",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/sites\/default\/files\/docs\/cea_2015_erp.pdf",
      "display_url" : "whitehouse.gov\/sites\/default\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "568448720863399939",
  "text" : "RT @CEAChair: Unemployment fell much faster than expected in 2014 #ERP15 http:\/\/t.co\/tfSMv4zNMI \u2026 http:\/\/t.co\/kzeZl5fBow",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CEAChair\/status\/568436496090296320\/photo\/1",
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/kzeZl5fBow",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-N9-YDCAAAc2Mh.jpg",
        "id_str" : "568436488539340800",
        "id" : 568436488539340800,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-N9-YDCAAAc2Mh.jpg",
        "sizes" : [ {
          "h" : 306,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1842,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 540,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 921,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/kzeZl5fBow"
      } ],
      "hashtags" : [ {
        "text" : "ERP15",
        "indices" : [ 52, 58 ]
      } ],
      "urls" : [ {
        "indices" : [ 59, 81 ],
        "url" : "http:\/\/t.co\/tfSMv4zNMI",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/sites\/default\/files\/docs\/cea_2015_erp.pdf",
        "display_url" : "whitehouse.gov\/sites\/default\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "568436496090296320",
    "text" : "Unemployment fell much faster than expected in 2014 #ERP15 http:\/\/t.co\/tfSMv4zNMI \u2026 http:\/\/t.co\/kzeZl5fBow",
    "id" : 568436496090296320,
    "created_at" : "2015-02-19 15:46:36 +0000",
    "user" : {
      "name" : "Jason Furman",
      "screen_name" : "CEAChair",
      "protected" : false,
      "id_str" : "1861751828",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000628384447\/c9cb85dbdb73c8bac4f28ce4cc46f38b_normal.jpeg",
      "id" : 1861751828,
      "verified" : true
    }
  },
  "id" : 568448720863399939,
  "created_at" : "2015-02-19 16:35:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CVESummit",
      "indices" : [ 133, 143 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568438686137913344",
  "text" : "\"We come from different countries and different cultures &amp; different faiths\u2026 [but] we are all in the same boat\" \u2014President Obama #CVESummit",
  "id" : 568438686137913344,
  "created_at" : "2015-02-19 15:55:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CVESummit",
      "indices" : [ 122, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568437332795375617",
  "text" : "\"When people are free to practice their faith as they choose, it helps hold diverse societies together.\" \u2014President Obama #CVESummit",
  "id" : 568437332795375617,
  "created_at" : "2015-02-19 15:49:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CVESummit",
      "indices" : [ 126, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568436971233632256",
  "text" : "\"When people are oppressed and human rights are denied\u2026when dissent is silenced, it feeds violent extremism\" \u2014President Obama #CVESummit",
  "id" : 568436971233632256,
  "created_at" : "2015-02-19 15:48:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568436778341785600",
  "text" : "\"Let\u2019s commit to expanding education, including for girls...nations will not truly succeed without the contributions of their women.\" \u2014Obama",
  "id" : 568436778341785600,
  "created_at" : "2015-02-19 15:47:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568436414745935872",
  "text" : "RT @WHLive: \"If we\u2019re serious about countering violent extremism, we have to get serious about confronting these economic grievances\" \u2014Obam\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CVESummit",
        "indices" : [ 129, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "568436384857346048",
    "text" : "\"If we\u2019re serious about countering violent extremism, we have to get serious about confronting these economic grievances\" \u2014Obama #CVESummit",
    "id" : 568436384857346048,
    "created_at" : "2015-02-19 15:46:09 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 568436414745935872,
  "created_at" : "2015-02-19 15:46:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CVESummit",
      "indices" : [ 125, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568435687713685504",
  "text" : "\"We need to do more to help lift up voices of tolerance and peace, especially online\" \u2014Obama on countering violent extremism #CVESummit",
  "id" : 568435687713685504,
  "created_at" : "2015-02-19 15:43:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568435415260098561",
  "text" : "\"The notion that the West is at war with Islam is an ugly lie &amp; all of us\u2014regardless of our faith\u2014have a responsibility to reject it\" \u2014Obama",
  "id" : 568435415260098561,
  "created_at" : "2015-02-19 15:42:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CVESummit",
      "indices" : [ 127, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568434907543781376",
  "text" : "\"Countering violent extremism begins with political, civic and religious leaders rejecting sectarian strife.\" \u2014President Obama #CVESummit",
  "id" : 568434907543781376,
  "created_at" : "2015-02-19 15:40:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568434799746027520",
  "text" : "RT @WHLive: \"Nations need to break the cycles of conflict\u2014especially sectarian conflict\u2014that are magnets for violent extremism\" \u2014Obama #CVE\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CVESummit",
        "indices" : [ 123, 133 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "568434775318360064",
    "text" : "\"Nations need to break the cycles of conflict\u2014especially sectarian conflict\u2014that are magnets for violent extremism\" \u2014Obama #CVESummit",
    "id" : 568434775318360064,
    "created_at" : "2015-02-19 15:39:46 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 568434799746027520,
  "created_at" : "2015-02-19 15:39:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CVESummit",
      "indices" : [ 114, 124 ]
    }, {
      "text" : "ISIL",
      "indices" : [ 125, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568433649869156352",
  "text" : "\"We are here today because we are united against the scourge of violent extremism and terrorism\" \u2014President Obama #CVESummit #ISIL",
  "id" : 568433649869156352,
  "created_at" : "2015-02-19 15:35:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 45, 55 ],
      "id_str" : "9624742",
      "id" : 9624742
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CVESummit",
      "indices" : [ 113, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/2Rbn4WIWjP",
      "expanded_url" : "http:\/\/go.wh.gov\/akM96U",
      "display_url" : "go.wh.gov\/akM96U"
    } ]
  },
  "geo" : { },
  "id_str" : "568433412895158272",
  "text" : "Happening now: President Obama speaks at the @StateDept on countering violent extremism \u2192 http:\/\/t.co\/2Rbn4WIWjP #CVESummit",
  "id" : 568433412895158272,
  "created_at" : "2015-02-19 15:34:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CVESummit",
      "indices" : [ 91, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/qUKSAa6G5o",
      "expanded_url" : "http:\/\/snpy.tv\/1EqhFU4",
      "display_url" : "snpy.tv\/1EqhFU4"
    } ]
  },
  "geo" : { },
  "id_str" : "568228362822373376",
  "text" : "No one should be profiled or put under a cloud of suspicion simply because of their faith. #CVESummit http:\/\/t.co\/qUKSAa6G5o",
  "id" : 568228362822373376,
  "created_at" : "2015-02-19 01:59:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/568206527686778880\/photo\/1",
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/259mn24lwp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-KszKHCEAAFlih.jpg",
      "id_str" : "568206497889259520",
      "id" : 568206497889259520,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-KszKHCEAAFlih.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/259mn24lwp"
    } ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 88, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/igihBxIulI",
      "expanded_url" : "http:\/\/youtu.be\/09Gij5hKrxg",
      "display_url" : "youtu.be\/09Gij5hKrxg"
    } ]
  },
  "geo" : { },
  "id_str" : "568206527686778880",
  "text" : "\"Today, our businesses export more than ever.\" \u2014President Obama: http:\/\/t.co\/igihBxIulI #MadeInAmerica http:\/\/t.co\/259mn24lwp",
  "id" : 568206527686778880,
  "created_at" : "2015-02-19 00:32:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Megan Smith",
      "screen_name" : "USCTO",
      "indices" : [ 3, 9 ],
      "id_str" : "2888895350",
      "id" : 2888895350
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 31, 42 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DataScientist",
      "indices" : [ 61, 75 ]
    }, {
      "text" : "OpenData",
      "indices" : [ 116, 125 ]
    }, {
      "text" : "PMI",
      "indices" : [ 126, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/Sw6n2nIZB0",
      "expanded_url" : "http:\/\/go.wh.gov\/xh4wZu",
      "display_url" : "go.wh.gov\/xh4wZu"
    } ]
  },
  "geo" : { },
  "id_str" : "568183218060582912",
  "text" : "RT @USCTO: Welcome DJ Patil to @WhiteHouse !! First US Chief #DataScientist &amp; Deputy CTO http:\/\/t.co\/Sw6n2nIZB0 #OpenData #PMI http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 20, 31 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/USCTO\/status\/568181763262042112\/photo\/1",
        "indices" : [ 120, 142 ],
        "url" : "http:\/\/t.co\/MKTiKEDYAf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-KWTYTCcAA7MP3.jpg",
        "id_str" : "568181762686087168",
        "id" : 568181762686087168,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-KWTYTCcAA7MP3.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 535
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 535
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 357,
          "resize" : "fit",
          "w" : 535
        } ],
        "display_url" : "pic.twitter.com\/MKTiKEDYAf"
      } ],
      "hashtags" : [ {
        "text" : "DataScientist",
        "indices" : [ 50, 64 ]
      }, {
        "text" : "OpenData",
        "indices" : [ 105, 114 ]
      }, {
        "text" : "PMI",
        "indices" : [ 115, 119 ]
      } ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/Sw6n2nIZB0",
        "expanded_url" : "http:\/\/go.wh.gov\/xh4wZu",
        "display_url" : "go.wh.gov\/xh4wZu"
      } ]
    },
    "geo" : { },
    "id_str" : "568181763262042112",
    "text" : "Welcome DJ Patil to @WhiteHouse !! First US Chief #DataScientist &amp; Deputy CTO http:\/\/t.co\/Sw6n2nIZB0 #OpenData #PMI http:\/\/t.co\/MKTiKEDYAf",
    "id" : 568181763262042112,
    "created_at" : "2015-02-18 22:54:23 +0000",
    "user" : {
      "name" : "Megan Smith",
      "screen_name" : "USCTO",
      "protected" : false,
      "id_str" : "2888895350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/534373591228219392\/Ewzw--q6_normal.jpeg",
      "id" : 2888895350,
      "verified" : true
    }
  },
  "id" : 568183218060582912,
  "created_at" : "2015-02-18 23:00:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568166273038688256",
  "text" : "\u201C'Please tell everyone that we are good people &amp; we are just like everyone else'\" \u2014Obama reading a Valentine from Sabrina, 11, who is Muslim",
  "id" : 568166273038688256,
  "created_at" : "2015-02-18 21:52:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CVESummit",
      "indices" : [ 130, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568165469108224001",
  "text" : "\"That\u2019s the story these extremists and terrorists don\u2019t want the world to know\u2014Muslims succeeding and thriving in America\" \u2014Obama #CVESummit",
  "id" : 568165469108224001,
  "created_at" : "2015-02-18 21:49:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CVESummit",
      "indices" : [ 110, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568164313405370369",
  "text" : "\"No one should be profiled or put under a cloud of suspicion simply because of their faith.\" \u2014President Obama #CVESummit",
  "id" : 568164313405370369,
  "created_at" : "2015-02-18 21:45:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CVESummit",
      "indices" : [ 130, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568163253794115584",
  "text" : "\"Countries will not be truly successful if half their populations\u2014their girls and women\u2014are denied opportunity.\" \u2014President Obama #CVESummit",
  "id" : 568163253794115584,
  "created_at" : "2015-02-18 21:40:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CVESummit",
      "indices" : [ 129, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568161832298545152",
  "text" : "\"We need to find new ways to amplify the voices of peace, tolerance and inclusion\u2014and we especially need to do it online\" \u2014Obama #CVESummit",
  "id" : 568161832298545152,
  "created_at" : "2015-02-18 21:35:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CVESummit",
      "indices" : [ 110, 120 ]
    }, {
      "text" : "ISIL",
      "indices" : [ 121, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568161449509588993",
  "text" : "\"Violence against innocents doesn't defend Islam and Muslims, it damages Islam and Muslims.\" \u2014President Obama #CVESummit #ISIL",
  "id" : 568161449509588993,
  "created_at" : "2015-02-18 21:33:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CVESummit",
      "indices" : [ 112, 122 ]
    }, {
      "text" : "ISIL",
      "indices" : [ 123, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568160811530772480",
  "text" : "\"No religion is responsible for terrorism. People are responsible for violence and terrorism.\" \u2014President Obama #CVESummit #ISIL",
  "id" : 568160811530772480,
  "created_at" : "2015-02-18 21:31:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568160528830472192",
  "text" : "\"They\u2019re not religious leaders, they\u2019re terrorists...we are not at war with Islam\u2014we are at war with people who have perverted Islam\" \u2014Obama",
  "id" : 568160528830472192,
  "created_at" : "2015-02-18 21:30:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568159093472391168",
  "text" : "RT @WHLive: \"We're working with allies and partners to dismantle terrorist organizations and protect the American people.\" \u2014Obama #CVESummi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CVESummit",
        "indices" : [ 118, 128 ]
      }, {
        "text" : "ISIL",
        "indices" : [ 129, 134 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "568159045430812674",
    "text" : "\"We're working with allies and partners to dismantle terrorist organizations and protect the American people.\" \u2014Obama #CVESummit #ISIL",
    "id" : 568159045430812674,
    "created_at" : "2015-02-18 21:24:06 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 568159093472391168,
  "created_at" : "2015-02-18 21:24:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CVESummit",
      "indices" : [ 133, 143 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568158723836747777",
  "text" : "\"As Americans, we are strong and we are resilient &amp; when tragedy strikes, when we take a hit, we pull together\" \u2014President Obama #CVESummit",
  "id" : 568158723836747777,
  "created_at" : "2015-02-18 21:22:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568158444605329410",
  "text" : "RT @WHLive: \"On 9\/11, terrorists tried to bring us to our knees, but today a new tower soars above New York City\" \u2014President Obama #CVESumm\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CVESummit",
        "indices" : [ 119, 129 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "568158420295139328",
    "text" : "\"On 9\/11, terrorists tried to bring us to our knees, but today a new tower soars above New York City\" \u2014President Obama #CVESummit",
    "id" : 568158420295139328,
    "created_at" : "2015-02-18 21:21:37 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 568158444605329410,
  "created_at" : "2015-02-18 21:21:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CVESummit",
      "indices" : [ 42, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/BiMUliUxud",
      "expanded_url" : "http:\/\/go.wh.gov\/1kXWSc",
      "display_url" : "go.wh.gov\/1kXWSc"
    } ]
  },
  "geo" : { },
  "id_str" : "568157944266801152",
  "text" : "Watch live: President Obama speaks at the #CVESummit on countering violent extremism \u2192 http:\/\/t.co\/BiMUliUxud",
  "id" : 568157944266801152,
  "created_at" : "2015-02-18 21:19:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/568139195102969856\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/qCzBfd82N7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-JveHbCQAI5ptA.jpg",
      "id_str" : "568139066181304322",
      "id" : 568139066181304322,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-JveHbCQAI5ptA.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/qCzBfd82N7"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/igihBy05Ki",
      "expanded_url" : "http:\/\/youtu.be\/09Gij5hKrxg",
      "display_url" : "youtu.be\/09Gij5hKrxg"
    } ]
  },
  "geo" : { },
  "id_str" : "568139195102969856",
  "text" : "Every $1 million in U.S. exports supports an average of more than 5,000 jobs here at home \u2192 http:\/\/t.co\/igihBy05Ki http:\/\/t.co\/qCzBfd82N7",
  "id" : 568139195102969856,
  "created_at" : "2015-02-18 20:05:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 125, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/igihBxIulI",
      "expanded_url" : "http:\/\/youtu.be\/09Gij5hKrxg",
      "display_url" : "youtu.be\/09Gij5hKrxg"
    } ]
  },
  "geo" : { },
  "id_str" : "568131309584781312",
  "text" : "95% of the world's customers live outside the U.S.\nIt's time to help American businesses export more: http:\/\/t.co\/igihBxIulI #MadeInAmerica",
  "id" : 568131309584781312,
  "created_at" : "2015-02-18 19:33:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "indices" : [ 3, 11 ],
      "id_str" : "2382117350",
      "id" : 2382117350
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 93, 106 ]
    }, {
      "text" : "MonumentsMatter",
      "indices" : [ 108, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568108415844626432",
  "text" : "RT @Deese44: Hey, guys! Taking over for John on the Twitters. Follow along for the latest on #ActOnClimate, #MonumentsMatter &amp; obligatory b\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 80, 93 ]
      }, {
        "text" : "MonumentsMatter",
        "indices" : [ 95, 111 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "568108247816609792",
    "text" : "Hey, guys! Taking over for John on the Twitters. Follow along for the latest on #ActOnClimate, #MonumentsMatter &amp; obligatory budget wonkery.",
    "id" : 568108247816609792,
    "created_at" : "2015-02-18 18:02:15 +0000",
    "user" : {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "protected" : false,
      "id_str" : "2382117350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656551411145027584\/ArrSlGUP_normal.jpg",
      "id" : 2382117350,
      "verified" : true
    }
  },
  "id" : 568108415844626432,
  "created_at" : "2015-02-18 18:02:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568097497207300098",
  "text" : "RT @VP: Investing in our nation's infrastructure helps create more jobs and economic activity. It's a virtuous circle. http:\/\/t.co\/WHZmkZjH\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/568085911466053632\/photo\/1",
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/WHZmkZjH9u",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-I_HvjCcAAo2qD.jpg",
        "id_str" : "568085905257164800",
        "id" : 568085905257164800,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-I_HvjCcAAo2qD.jpg",
        "sizes" : [ {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/WHZmkZjH9u"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "568085911466053632",
    "text" : "Investing in our nation's infrastructure helps create more jobs and economic activity. It's a virtuous circle. http:\/\/t.co\/WHZmkZjH9u",
    "id" : 568085911466053632,
    "created_at" : "2015-02-18 16:33:30 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 568097497207300098,
  "created_at" : "2015-02-18 17:19:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/568085613066342400\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/maSvn8kYjS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-I-wkVCQAAeQSM.png",
      "id_str" : "568085507108651008",
      "id" : 568085507108651008,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-I-wkVCQAAeQSM.png",
      "sizes" : [ {
        "h" : 153,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 219,
        "resize" : "fit",
        "w" : 861
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 86,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 219,
        "resize" : "fit",
        "w" : 861
      } ],
      "display_url" : "pic.twitter.com\/maSvn8kYjS"
    } ],
    "hashtags" : [ {
      "text" : "AshWednesday",
      "indices" : [ 94, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "568085613066342400",
  "text" : "\"Michelle and I join our fellow Christians across the country and around the world in marking #AshWednesday.\" \u2014Obama http:\/\/t.co\/maSvn8kYjS",
  "id" : 568085613066342400,
  "created_at" : "2015-02-18 16:32:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CVESummit",
      "indices" : [ 112, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/cQeU4N9ccT",
      "expanded_url" : "http:\/\/lat.ms\/1vENFPe",
      "display_url" : "lat.ms\/1vENFPe"
    } ]
  },
  "geo" : { },
  "id_str" : "568074673063383042",
  "text" : "\"Governments that deny human rights play into the hands of extremists\" \u2014President Obama: http:\/\/t.co\/cQeU4N9ccT #CVESummit",
  "id" : 568074673063383042,
  "created_at" : "2015-02-18 15:48:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/568060672895922176\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/XluHMkARUr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-IoAyUCIAArMZa.jpg",
      "id_str" : "568060496973012992",
      "id" : 568060496973012992,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-IoAyUCIAArMZa.jpg",
      "sizes" : [ {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/XluHMkARUr"
    } ],
    "hashtags" : [ {
      "text" : "CVESummit",
      "indices" : [ 94, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/cQeU4MRAOj",
      "expanded_url" : "http:\/\/lat.ms\/1vENFPe",
      "display_url" : "lat.ms\/1vENFPe"
    } ]
  },
  "geo" : { },
  "id_str" : "568060672895922176",
  "text" : "Worth a read: President Obama on our fight against violent extremism \u2192 http:\/\/t.co\/cQeU4MRAOj #CVESummit http:\/\/t.co\/XluHMkARUr",
  "id" : 568060672895922176,
  "created_at" : "2015-02-18 14:53:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "11MillionAndCounting",
      "indices" : [ 37, 58 ]
    }, {
      "text" : "ACAWorks",
      "indices" : [ 126, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/uqkAxNzaqh",
      "expanded_url" : "http:\/\/on.fb.me\/1zm2A2r",
      "display_url" : "on.fb.me\/1zm2A2r"
    } ]
  },
  "geo" : { },
  "id_str" : "567858752327663617",
  "text" : "Watch President Obama reflect on how #11MillionAndCounting are signed up for private health coverage \u2192 http:\/\/t.co\/uqkAxNzaqh #ACAWorks",
  "id" : 567858752327663617,
  "created_at" : "2015-02-18 01:30:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 104, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567845614425411584",
  "text" : "RT @VP: 11.4 million: That's the number of Americans who are signed up for private health coverage. The #ACA is working. http:\/\/t.co\/ujdVOZ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/567837259937923072\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/ujdVOZYK5J",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-Fc-n-CIAAPLiV.jpg",
        "id_str" : "567837258976206848",
        "id" : 567837258976206848,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-Fc-n-CIAAPLiV.jpg",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/ujdVOZYK5J"
      } ],
      "hashtags" : [ {
        "text" : "ACA",
        "indices" : [ 96, 100 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "567837259937923072",
    "text" : "11.4 million: That's the number of Americans who are signed up for private health coverage. The #ACA is working. http:\/\/t.co\/ujdVOZYK5J",
    "id" : 567837259937923072,
    "created_at" : "2015-02-18 00:05:27 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 567845614425411584,
  "created_at" : "2015-02-18 00:38:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "11MillionAndCounting",
      "indices" : [ 109, 130 ]
    }, {
      "text" : "ACAWorks",
      "indices" : [ 131, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/uqkAxNzaqh",
      "expanded_url" : "http:\/\/on.fb.me\/1zm2A2r",
      "display_url" : "on.fb.me\/1zm2A2r"
    } ]
  },
  "geo" : { },
  "id_str" : "567841635566030849",
  "text" : "\"11.4 million people have either reenrolled or signed up for the first time.\" \u2014Obama: http:\/\/t.co\/uqkAxNzaqh #11MillionAndCounting #ACAWorks",
  "id" : 567841635566030849,
  "created_at" : "2015-02-18 00:22:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/567833392579084289\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/E7eiiI0oZe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-FZXYNCUAAnea7.jpg",
      "id_str" : "567833286194384896",
      "id" : 567833286194384896,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-FZXYNCUAAnea7.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/E7eiiI0oZe"
    } ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 88, 92 ]
    }, {
      "text" : "11MillionAndCounting",
      "indices" : [ 94, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567833392579084289",
  "text" : "RT the news: About 11.4 million people are \u270D up for private health coverage through the #ACA. #11MillionAndCounting http:\/\/t.co\/E7eiiI0oZe",
  "id" : 567833392579084289,
  "created_at" : "2015-02-17 23:50:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "11MillionAndCounting",
      "indices" : [ 82, 103 ]
    }, {
      "text" : "ACAWorks",
      "indices" : [ 104, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/1zKLkyJvlo",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/a56d09e5-c91d-4a8e-ba4d-347bb810d80b",
      "display_url" : "amp.twimg.com\/v\/a56d09e5-c91\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "567828619558436864",
  "text" : "BREAKING: About 11.4 million Americans are signed up for private health coverage. #11MillionAndCounting #ACAWorks\nhttps:\/\/t.co\/1zKLkyJvlo",
  "id" : 567828619558436864,
  "created_at" : "2015-02-17 23:31:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "STEM",
      "indices" : [ 48, 53 ]
    }, {
      "text" : "WomenInSTEM",
      "indices" : [ 86, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/cuSMqsBf4I",
      "expanded_url" : "http:\/\/youtu.be\/5IljiPJQgSU",
      "display_url" : "youtu.be\/5IljiPJQgSU"
    } ]
  },
  "geo" : { },
  "id_str" : "567784511120089088",
  "text" : "Watch President Obama discuss the importance of #STEM education and the need for more #WomenInSTEM fields \u2192 http:\/\/t.co\/cuSMqsBf4I",
  "id" : 567784511120089088,
  "created_at" : "2015-02-17 20:35:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/567759474417758208\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/Jy9sQHk7LY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-EWCCJCIAAxa0y.jpg",
      "id_str" : "567759252215701504",
      "id" : 567759252215701504,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-EWCCJCIAAxa0y.jpg",
      "sizes" : [ {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/Jy9sQHk7LY"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/WKHZlH2lfb",
      "expanded_url" : "http:\/\/go.wh.gov\/7QHQxS",
      "display_url" : "go.wh.gov\/7QHQxS"
    } ]
  },
  "geo" : { },
  "id_str" : "567759474417758208",
  "text" : "President Obama is taking new steps to help companies respond to cybersecurity threats \u2192 http:\/\/t.co\/WKHZlH2lfb http:\/\/t.co\/Jy9sQHk7LY",
  "id" : 567759474417758208,
  "created_at" : "2015-02-17 18:56:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/VP\/status\/567719129331671041\/photo\/1",
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/5oU9hKvTJk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B-DxihLCMAA5KO0.png",
      "id_str" : "567719128371179520",
      "id" : 567719128371179520,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-DxihLCMAA5KO0.png",
      "sizes" : [ {
        "h" : 189,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 563,
        "resize" : "fit",
        "w" : 1013
      }, {
        "h" : 563,
        "resize" : "fit",
        "w" : 1013
      }, {
        "h" : 333,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/5oU9hKvTJk"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567730559590612993",
  "text" : "RT @VP: Vice President Biden swears in Ash Carter as the new U.S. Secretary of Defense. http:\/\/t.co\/5oU9hKvTJk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/567719129331671041\/photo\/1",
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/5oU9hKvTJk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B-DxihLCMAA5KO0.png",
        "id_str" : "567719128371179520",
        "id" : 567719128371179520,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B-DxihLCMAA5KO0.png",
        "sizes" : [ {
          "h" : 189,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 563,
          "resize" : "fit",
          "w" : 1013
        }, {
          "h" : 563,
          "resize" : "fit",
          "w" : 1013
        }, {
          "h" : 333,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/5oU9hKvTJk"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "567719129331671041",
    "text" : "Vice President Biden swears in Ash Carter as the new U.S. Secretary of Defense. http:\/\/t.co\/5oU9hKvTJk",
    "id" : 567719129331671041,
    "created_at" : "2015-02-17 16:16:02 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 567730559590612993,
  "created_at" : "2015-02-17 17:01:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Tom Frieden",
      "screen_name" : "DrFriedenCDC",
      "indices" : [ 3, 16 ],
      "id_str" : "426909329",
      "id" : 426909329
    }, {
      "name" : "The Hill",
      "screen_name" : "thehill",
      "indices" : [ 126, 134 ],
      "id_str" : "1917731",
      "id" : 1917731
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "measles",
      "indices" : [ 74, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567714520609873920",
  "text" : "RT @DrFriedenCDC: Vaccination is not just a way to protect your kids from #measles. It\u2019s also way to protect kids around you. @TheHill http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Hill",
        "screen_name" : "thehill",
        "indices" : [ 108, 116 ],
        "id_str" : "1917731",
        "id" : 1917731
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "measles",
        "indices" : [ 56, 64 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/TnBSy9obw5",
        "expanded_url" : "http:\/\/bit.ly\/1vlcTlF",
        "display_url" : "bit.ly\/1vlcTlF"
      } ]
    },
    "geo" : { },
    "id_str" : "567701379540848643",
    "text" : "Vaccination is not just a way to protect your kids from #measles. It\u2019s also way to protect kids around you. @TheHill http:\/\/t.co\/TnBSy9obw5",
    "id" : 567701379540848643,
    "created_at" : "2015-02-17 15:05:30 +0000",
    "user" : {
      "name" : "Dr. Tom Frieden",
      "screen_name" : "DrFriedenCDC",
      "protected" : false,
      "id_str" : "426909329",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1677474099\/Frieden-88_-_1200x1200_normal.jpg",
      "id" : 426909329,
      "verified" : true
    }
  },
  "id" : 567714520609873920,
  "created_at" : "2015-02-17 15:57:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PresidentsDay",
      "indices" : [ 115, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/qHKvqxvfPa",
      "expanded_url" : "http:\/\/go.wh.gov\/presidentsday",
      "display_url" : "go.wh.gov\/presidentsday"
    } ]
  },
  "geo" : { },
  "id_str" : "567488718127116289",
  "text" : "Can you name all the U.S. Presidents? Find out with our new and improved historical pages \u2192 http:\/\/t.co\/qHKvqxvfPa #PresidentsDay",
  "id" : 567488718127116289,
  "created_at" : "2015-02-17 01:00:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PresidentsDay",
      "indices" : [ 77, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/qHKvqxvfPa",
      "expanded_url" : "http:\/\/go.wh.gov\/presidentsday",
      "display_url" : "go.wh.gov\/presidentsday"
    } ]
  },
  "geo" : { },
  "id_str" : "567458505221607425",
  "text" : "George Washington \u2713\nAbraham Lincoln \u2713\nEvery other American President \u2713\nHappy #PresidentsDay! \u2192 http:\/\/t.co\/qHKvqxvfPa",
  "id" : 567458505221607425,
  "created_at" : "2015-02-16 23:00:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PresidentsDay",
      "indices" : [ 10, 24 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/qHKvqxvfPa",
      "expanded_url" : "http:\/\/go.wh.gov\/presidentsday",
      "display_url" : "go.wh.gov\/presidentsday"
    } ]
  },
  "geo" : { },
  "id_str" : "567428340697399297",
  "text" : "Celebrate #PresidentsDay with all the U.S. Presidents and First Ladies at our new and improved historical pages \u2192 http:\/\/t.co\/qHKvqxvfPa",
  "id" : 567428340697399297,
  "created_at" : "2015-02-16 21:00:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/567404365527650305\/photo\/1",
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/Z69jtWizAP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9_TQUKCMAAQJlO.png",
      "id_str" : "567404355314135040",
      "id" : 567404355314135040,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9_TQUKCMAAQJlO.png",
      "sizes" : [ {
        "h" : 673,
        "resize" : "fit",
        "w" : 509
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 673,
        "resize" : "fit",
        "w" : 509
      }, {
        "h" : 673,
        "resize" : "fit",
        "w" : 509
      } ],
      "display_url" : "pic.twitter.com\/Z69jtWizAP"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/qHKvqxMRdK",
      "expanded_url" : "http:\/\/go.wh.gov\/presidentsday",
      "display_url" : "go.wh.gov\/presidentsday"
    } ]
  },
  "geo" : { },
  "id_str" : "567404365527650305",
  "text" : "\u201CWe are 6-year-old twin brothers who love American history.\u201D \u2014Jett &amp; Luke to President Obama: http:\/\/t.co\/qHKvqxMRdK http:\/\/t.co\/Z69jtWizAP",
  "id" : 567404365527650305,
  "created_at" : "2015-02-16 19:25:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Interior\/status\/567362494579376129\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/5BGs05fT4H",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9-tLZ4IQAAm5gt.jpg",
      "id_str" : "567362489508446208",
      "id" : 567362489508446208,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9-tLZ4IQAAm5gt.jpg",
      "sizes" : [ {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/5BGs05fT4H"
    } ],
    "hashtags" : [ {
      "text" : "PresidentsDay",
      "indices" : [ 20, 34 ]
    }, {
      "text" : "DC",
      "indices" : [ 95, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567370289080987648",
  "text" : "RT @Interior: Happy #PresidentsDay! Here's one of our favorite pics of the Washington Monument #DC http:\/\/t.co\/5BGs05fT4H",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Interior\/status\/567362494579376129\/photo\/1",
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/5BGs05fT4H",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9-tLZ4IQAAm5gt.jpg",
        "id_str" : "567362489508446208",
        "id" : 567362489508446208,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9-tLZ4IQAAm5gt.jpg",
        "sizes" : [ {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/5BGs05fT4H"
      } ],
      "hashtags" : [ {
        "text" : "PresidentsDay",
        "indices" : [ 6, 20 ]
      }, {
        "text" : "DC",
        "indices" : [ 81, 84 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "567362494579376129",
    "text" : "Happy #PresidentsDay! Here's one of our favorite pics of the Washington Monument #DC http:\/\/t.co\/5BGs05fT4H",
    "id" : 567362494579376129,
    "created_at" : "2015-02-16 16:38:54 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 567370289080987648,
  "created_at" : "2015-02-16 17:09:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/iP0O6miwvO",
      "expanded_url" : "http:\/\/healthcare.gov",
      "display_url" : "healthcare.gov"
    }, {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/ZKt2oNPxmJ",
      "expanded_url" : "http:\/\/cuidadodesalud.gov",
      "display_url" : "cuidadodesalud.gov"
    }, {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/mBtTKvHWow",
      "expanded_url" : "http:\/\/go.wh.gov\/utKn1U",
      "display_url" : "go.wh.gov\/utKn1U"
    } ]
  },
  "geo" : { },
  "id_str" : "567170976136581120",
  "text" : "RT @FLOTUS: \u201CGet yourself &amp; everyone you know to http:\/\/t.co\/iP0O6miwvO or http:\/\/t.co\/ZKt2oNPxmJ.\u201D \u2014The First Lady: http:\/\/t.co\/mBtTKvHWow\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 132, 143 ]
      } ],
      "urls" : [ {
        "indices" : [ 41, 63 ],
        "url" : "http:\/\/t.co\/iP0O6miwvO",
        "expanded_url" : "http:\/\/healthcare.gov",
        "display_url" : "healthcare.gov"
      }, {
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/ZKt2oNPxmJ",
        "expanded_url" : "http:\/\/cuidadodesalud.gov",
        "display_url" : "cuidadodesalud.gov"
      }, {
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/mBtTKvHWow",
        "expanded_url" : "http:\/\/go.wh.gov\/utKn1U",
        "display_url" : "go.wh.gov\/utKn1U"
      } ]
    },
    "geo" : { },
    "id_str" : "567137605355986944",
    "text" : "\u201CGet yourself &amp; everyone you know to http:\/\/t.co\/iP0O6miwvO or http:\/\/t.co\/ZKt2oNPxmJ.\u201D \u2014The First Lady: http:\/\/t.co\/mBtTKvHWow #GetCovered",
    "id" : 567137605355986944,
    "created_at" : "2015-02-16 01:45:16 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 567170976136581120,
  "created_at" : "2015-02-16 03:57:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/567138819648921600\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/aWwoOJasYH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B96yEfpIgAE2vIp.jpg",
      "id_str" : "567086393378504705",
      "id" : 567086393378504705,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B96yEfpIgAE2vIp.jpg",
      "sizes" : [ {
        "h" : 3500,
        "resize" : "fit",
        "w" : 2641
      }, {
        "h" : 1357,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 795,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 451,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/aWwoOJasYH"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 49, 60 ]
    }, {
      "text" : "NBAAllStarNYC",
      "indices" : [ 92, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/JxkdfhYxgO",
      "expanded_url" : "http:\/\/healthcare.gov",
      "display_url" : "healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "567138819648921600",
  "text" : "Don\u2019t have health insurance? Beat the buzzer and #GetCovered today \u2192 http:\/\/t.co\/JxkdfhYxgO #NBAAllStarNYC http:\/\/t.co\/aWwoOJasYH",
  "id" : 567138819648921600,
  "created_at" : "2015-02-16 01:50:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/567042281841389571\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/2lLp55iXXP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B96JwQIIYAEa-N1.jpg",
      "id_str" : "567042065151057921",
      "id" : 567042065151057921,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B96JwQIIYAEa-N1.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/2lLp55iXXP"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 69, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/JxkdfhYxgO",
      "expanded_url" : "http:\/\/healthcare.gov",
      "display_url" : "healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "567111186936635392",
  "text" : "DEADLINE TODAY: Sign up for a 2015 health plan before it\u2019s too late. #GetCovered \u2192 http:\/\/t.co\/JxkdfhYxgO http:\/\/t.co\/2lLp55iXXP",
  "id" : 567111186936635392,
  "created_at" : "2015-02-16 00:00:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 77, 88 ]
    }, {
      "text" : "NBAAllStarNYC",
      "indices" : [ 120, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/GNfbftrfo3",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "567096102294257664",
  "text" : "When it comes to basketball and your health, quality coverage helps you win. #GetCovered today \u2192 http:\/\/t.co\/GNfbftrfo3 #NBAAllStarNYC",
  "id" : 567096102294257664,
  "created_at" : "2015-02-15 23:00:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/mBtTKvHWow",
      "expanded_url" : "http:\/\/go.wh.gov\/utKn1U",
      "display_url" : "go.wh.gov\/utKn1U"
    } ]
  },
  "geo" : { },
  "id_str" : "567086571921227776",
  "text" : "RT @FLOTUS: \u201CMost eligible Americans can qualify for financial assistance to make health care affordable.\u201D \u2014FLOTUS: http:\/\/t.co\/mBtTKvHWow \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 127, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/mBtTKvHWow",
        "expanded_url" : "http:\/\/go.wh.gov\/utKn1U",
        "display_url" : "go.wh.gov\/utKn1U"
      } ]
    },
    "geo" : { },
    "id_str" : "567083196953538560",
    "text" : "\u201CMost eligible Americans can qualify for financial assistance to make health care affordable.\u201D \u2014FLOTUS: http:\/\/t.co\/mBtTKvHWow #GetCovered",
    "id" : 567083196953538560,
    "created_at" : "2015-02-15 22:09:04 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 567086571921227776,
  "created_at" : "2015-02-15 22:22:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/vUNc1NqZoj",
      "expanded_url" : "http:\/\/go.wh.gov\/R35xhz",
      "display_url" : "go.wh.gov\/R35xhz"
    } ]
  },
  "geo" : { },
  "id_str" : "567081000543322112",
  "text" : "\"Nothing will determine our success as a nation in the 21st century more than how well we educate our kids.\" \u2014Obama: http:\/\/t.co\/vUNc1NqZoj",
  "id" : 567081000543322112,
  "created_at" : "2015-02-15 22:00:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/567064115378536448\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/4U6LTHqrxP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B96dvzQIcAAZsEJ.jpg",
      "id_str" : "567064047632543744",
      "id" : 567064047632543744,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B96dvzQIcAAZsEJ.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 3500,
        "resize" : "fit",
        "w" : 2333
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/4U6LTHqrxP"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 59, 70 ]
    }, {
      "text" : "NBAAllStarNYC",
      "indices" : [ 96, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/JxkdfhYxgO",
      "expanded_url" : "http:\/\/healthcare.gov",
      "display_url" : "healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "567064115378536448",
  "text" : "The shot clock's winding down:\nToday's your last chance to #GetCovered \u2192 http:\/\/t.co\/JxkdfhYxgO #NBAAllStarNYC http:\/\/t.co\/4U6LTHqrxP",
  "id" : 567064115378536448,
  "created_at" : "2015-02-15 20:53:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 33, 44 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/EO0WsR3B0F",
      "expanded_url" : "http:\/\/healthcare.gov",
      "display_url" : "healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "567050433844506624",
  "text" : "RT @VP: Today is the last day to #GetCovered in 2015. Visit http:\/\/t.co\/EO0WsR3B0F to find the plan that works best for you and your family.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 25, 36 ]
      } ],
      "urls" : [ {
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/EO0WsR3B0F",
        "expanded_url" : "http:\/\/healthcare.gov",
        "display_url" : "healthcare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "567040417380958209",
    "text" : "Today is the last day to #GetCovered in 2015. Visit http:\/\/t.co\/EO0WsR3B0F to find the plan that works best for you and your family.",
    "id" : 567040417380958209,
    "created_at" : "2015-02-15 19:19:05 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 567050433844506624,
  "created_at" : "2015-02-15 19:58:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/567042281841389571\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/2lLp55iXXP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B96JwQIIYAEa-N1.jpg",
      "id_str" : "567042065151057921",
      "id" : 567042065151057921,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B96JwQIIYAEa-N1.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/2lLp55iXXP"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 71, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/GNfbft9Ewv",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "567042281841389571",
  "text" : "DEADLINE TODAY:\nIt's the last day to sign up for 2015 health coverage.\n#GetCovered at http:\/\/t.co\/GNfbft9Ewv http:\/\/t.co\/2lLp55iXXP",
  "id" : 567042281841389571,
  "created_at" : "2015-02-15 19:26:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "getcovered",
      "indices" : [ 70, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/5mr7XbkMon",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "567030446282665984",
  "text" : "RT @vj44: Hundreds enrolling at events in VA. Join your neighbors and #getcovered by the end of the day! http:\/\/t.co\/5mr7XbkMon http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/567022978450587648\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/hJfZLmY5W1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B954ZBsIEAAAx8N.jpg",
        "id_str" : "567022974440837120",
        "id" : 567022974440837120,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B954ZBsIEAAAx8N.jpg",
        "sizes" : [ {
          "h" : 620,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 620,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 206,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 363,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/hJfZLmY5W1"
      } ],
      "hashtags" : [ {
        "text" : "getcovered",
        "indices" : [ 60, 71 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/5mr7XbkMon",
        "expanded_url" : "http:\/\/Healthcare.gov",
        "display_url" : "Healthcare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "567022978450587648",
    "text" : "Hundreds enrolling at events in VA. Join your neighbors and #getcovered by the end of the day! http:\/\/t.co\/5mr7XbkMon http:\/\/t.co\/hJfZLmY5W1",
    "id" : 567022978450587648,
    "created_at" : "2015-02-15 18:09:47 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 567030446282665984,
  "created_at" : "2015-02-15 18:39:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/vUNc1NqZoj",
      "expanded_url" : "http:\/\/go.wh.gov\/R35xhz",
      "display_url" : "go.wh.gov\/R35xhz"
    } ]
  },
  "geo" : { },
  "id_str" : "567020599159975937",
  "text" : "\"When it comes to education, we are not a collection of states competing against one another.\" \u2014President Obama: http:\/\/t.co\/vUNc1NqZoj",
  "id" : 567020599159975937,
  "created_at" : "2015-02-15 18:00:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Denmark",
      "indices" : [ 47, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "567015344485961729",
  "text" : "RT @NSCPress: United States stands with ppl of #Denmark after yesterday's horrific shootings and will lend any assistance necessary to the \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Denmark",
        "indices" : [ 33, 41 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "566973099879317505",
    "text" : "United States stands with ppl of #Denmark after yesterday's horrific shootings and will lend any assistance necessary to the investigation",
    "id" : 566973099879317505,
    "created_at" : "2015-02-15 14:51:35 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 567015344485961729,
  "created_at" : "2015-02-15 17:39:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/vUNc1N9owL",
      "expanded_url" : "http:\/\/go.wh.gov\/R35xhz",
      "display_url" : "go.wh.gov\/R35xhz"
    } ]
  },
  "geo" : { },
  "id_str" : "566967361451094017",
  "text" : "\"I want to work with both parties in Congress to replace No Child Left Behind with a smarter law.\" \u2014President Obama: http:\/\/t.co\/vUNc1N9owL",
  "id" : 566967361451094017,
  "created_at" : "2015-02-15 14:28:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/vUNc1NqZoj",
      "expanded_url" : "http:\/\/go.wh.gov\/R35xhz",
      "display_url" : "go.wh.gov\/R35xhz"
    } ]
  },
  "geo" : { },
  "id_str" : "566741237793714177",
  "text" : "\"Our kids will only do better than we did if we educate them better than we were educated.\" \u2014President Obama: http:\/\/t.co\/vUNc1NqZoj",
  "id" : 566741237793714177,
  "created_at" : "2015-02-14 23:30:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/566714774411427840\/photo\/1",
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/EjmgVbOxND",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B91cQWcIUAEuRrl.jpg",
      "id_str" : "566710564089778177",
      "id" : 566710564089778177,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B91cQWcIUAEuRrl.jpg",
      "sizes" : [ {
        "h" : 1258,
        "resize" : "fit",
        "w" : 1150
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 372,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 656,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1120,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/EjmgVbOxND"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "566714774411427840",
  "text" : "Happy Valentine's Day! http:\/\/t.co\/EjmgVbOxND",
  "id" : 566714774411427840,
  "created_at" : "2015-02-14 21:45:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/FLOTUS\/status\/566691915803148288\/photo\/1",
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/MqYysGzAhQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B91K7KOIgAEJ20c.jpg",
      "id_str" : "566691508334919681",
      "id" : 566691508334919681,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B91K7KOIgAEJ20c.jpg",
      "sizes" : [ {
        "h" : 467,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1500,
        "resize" : "fit",
        "w" : 1092
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1407,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 824,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/MqYysGzAhQ"
    } ],
    "hashtags" : [ {
      "text" : "HappyValentinesDay",
      "indices" : [ 34, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "566708880143826944",
  "text" : "RT @FLOTUS: Love is all you need. #HappyValentinesDay, Barack. -mo http:\/\/t.co\/MqYysGzAhQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/FLOTUS\/status\/566691915803148288\/photo\/1",
        "indices" : [ 55, 77 ],
        "url" : "http:\/\/t.co\/MqYysGzAhQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B91K7KOIgAEJ20c.jpg",
        "id_str" : "566691508334919681",
        "id" : 566691508334919681,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B91K7KOIgAEJ20c.jpg",
        "sizes" : [ {
          "h" : 467,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1500,
          "resize" : "fit",
          "w" : 1092
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1407,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 824,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/MqYysGzAhQ"
      } ],
      "hashtags" : [ {
        "text" : "HappyValentinesDay",
        "indices" : [ 22, 41 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "566691915803148288",
    "text" : "Love is all you need. #HappyValentinesDay, Barack. -mo http:\/\/t.co\/MqYysGzAhQ",
    "id" : 566691915803148288,
    "created_at" : "2015-02-14 20:14:16 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 566708880143826944,
  "created_at" : "2015-02-14 21:21:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/vUNc1NqZoj",
      "expanded_url" : "http:\/\/go.wh.gov\/R35xhz",
      "display_url" : "go.wh.gov\/R35xhz"
    } ]
  },
  "geo" : { },
  "id_str" : "566680854651342848",
  "text" : "\"Last week, we learned that our high school graduation rate hit a new all-time high.\" \u2014President Obama: http:\/\/t.co\/vUNc1NqZoj",
  "id" : 566680854651342848,
  "created_at" : "2015-02-14 19:30:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/vUNc1NqZoj",
      "expanded_url" : "http:\/\/go.wh.gov\/R35xhz",
      "display_url" : "go.wh.gov\/R35xhz"
    } ]
  },
  "geo" : { },
  "id_str" : "566643134772178944",
  "text" : "\"A core element of this middle-class economics is how well we prepare our kids for the future.\" \u2014President Obama: http:\/\/t.co\/vUNc1NqZoj",
  "id" : 566643134772178944,
  "created_at" : "2015-02-14 17:00:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "InvestInKids",
      "indices" : [ 108, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/vUNc1N9owL",
      "expanded_url" : "http:\/\/go.wh.gov\/R35xhz",
      "display_url" : "go.wh.gov\/R35xhz"
    } ]
  },
  "geo" : { },
  "id_str" : "566626984705658881",
  "text" : "Watch President Obama's weekly address on giving every child a fair shot at success: http:\/\/t.co\/vUNc1N9owL #InvestInKids",
  "id" : 566626984705658881,
  "created_at" : "2015-02-14 15:56:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/566439270416523266\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/t3VNQ3otox",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9xae9qIgAA1BEA.jpg",
      "id_str" : "566427141135695872",
      "id" : 566427141135695872,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9xae9qIgAA1BEA.jpg",
      "sizes" : [ {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/t3VNQ3otox"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/2vB0yxNlUS",
      "expanded_url" : "http:\/\/wh.gov\/ibNsW",
      "display_url" : "wh.gov\/ibNsW"
    } ]
  },
  "geo" : { },
  "id_str" : "566439270416523266",
  "text" : "\"Our connectivity brings extraordinary benefits to our daily lives, but it also brings risks.\" http:\/\/t.co\/2vB0yxNlUS http:\/\/t.co\/t3VNQ3otox",
  "id" : 566439270416523266,
  "created_at" : "2015-02-14 03:30:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/566424358344617984\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/35p8rPSgwY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9xX88JIAAAw8rp.jpg",
      "id_str" : "566424357590007808",
      "id" : 566424357590007808,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9xX88JIAAAw8rp.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/35p8rPSgwY"
    } ],
    "hashtags" : [ {
      "text" : "YesWeCan",
      "indices" : [ 76, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/miL3mwiyt0",
      "expanded_url" : "http:\/\/on.recode.net\/1DmXDvg",
      "display_url" : "on.recode.net\/1DmXDvg"
    } ]
  },
  "geo" : { },
  "id_str" : "566424358344617984",
  "text" : "\"If there was a hashtag for your administration, what would it be?\"\nObama: \"#YesWeCan.\" http:\/\/t.co\/miL3mwiyt0 http:\/\/t.co\/35p8rPSgwY",
  "id" : 566424358344617984,
  "created_at" : "2015-02-14 02:31:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Recode",
      "screen_name" : "Recode",
      "indices" : [ 3, 10 ],
      "id_str" : "2244340904",
      "id" : 2244340904
    }, {
      "name" : "Kara Swisher",
      "screen_name" : "karaswisher",
      "indices" : [ 18, 30 ],
      "id_str" : "5763262",
      "id" : 5763262
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Recode\/status\/566397742709092352\/photo\/1",
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/ved0lWp4PZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9w_vuqCMAAS8dc.jpg",
      "id_str" : "566397742352576512",
      "id" : 566397742352576512,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9w_vuqCMAAS8dc.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 427,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 427,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/ved0lWp4PZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/TWuBHjwbpP",
      "expanded_url" : "http:\/\/recode.net\/2015\/02\/13\/barack-obama-recode-kara-swisher-video\/",
      "display_url" : "recode.net\/2015\/02\/13\/bar\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "566401519411412992",
  "text" : "RT @Recode: Watch @karaswisher's full, exclusive interview with President Obama http:\/\/t.co\/TWuBHjwbpP http:\/\/t.co\/ved0lWp4PZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kara Swisher",
        "screen_name" : "karaswisher",
        "indices" : [ 6, 18 ],
        "id_str" : "5763262",
        "id" : 5763262
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Recode\/status\/566397742709092352\/photo\/1",
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/ved0lWp4PZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9w_vuqCMAAS8dc.jpg",
        "id_str" : "566397742352576512",
        "id" : 566397742352576512,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9w_vuqCMAAS8dc.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 427,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 427,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/ved0lWp4PZ"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/TWuBHjwbpP",
        "expanded_url" : "http:\/\/recode.net\/2015\/02\/13\/barack-obama-recode-kara-swisher-video\/",
        "display_url" : "recode.net\/2015\/02\/13\/bar\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "566397742709092352",
    "text" : "Watch @karaswisher's full, exclusive interview with President Obama http:\/\/t.co\/TWuBHjwbpP http:\/\/t.co\/ved0lWp4PZ",
    "id" : 566397742709092352,
    "created_at" : "2015-02-14 00:45:19 +0000",
    "user" : {
      "name" : "Recode",
      "screen_name" : "Recode",
      "protected" : false,
      "id_str" : "2244340904",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729365899828989952\/o0AuZCNW_normal.jpg",
      "id" : 2244340904,
      "verified" : true
    }
  },
  "id" : 566401519411412992,
  "created_at" : "2015-02-14 01:00:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/566385915807809536\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/SAYzhdmVIo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9w0RFWIgAAhRyU.jpg",
      "id_str" : "566385121239269376",
      "id" : 566385121239269376,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9w0RFWIgAAhRyU.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/SAYzhdmVIo"
    } ],
    "hashtags" : [ {
      "text" : "ThanksJohn",
      "indices" : [ 98, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/mMhVDiZ9Ul",
      "expanded_url" : "https:\/\/storify.com\/whitehouse\/top-10-moments-from-podesta44",
      "display_url" : "storify.com\/whitehouse\/top\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "566385915807809536",
  "text" : "Take a look back at @Podesta44's 10 favorite moments at the White House \u2192 https:\/\/t.co\/mMhVDiZ9Ul #ThanksJohn http:\/\/t.co\/SAYzhdmVIo",
  "id" : 566385915807809536,
  "created_at" : "2015-02-13 23:58:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sen. Barbara Boxer",
      "screen_name" : "SenatorBoxer",
      "indices" : [ 3, 16 ],
      "id_str" : "15442036",
      "id" : 15442036
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 84, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/sAzNkDp7h1",
      "expanded_url" : "http:\/\/go.wh.gov\/get-covered",
      "display_url" : "go.wh.gov\/get-covered"
    } ]
  },
  "geo" : { },
  "id_str" : "566377821988081664",
  "text" : "RT @SenatorBoxer: DEADLINE SUNDAY: Just 2 days left to sign up for health coverage. #GetCovered by Feb. 15 \u2192 http:\/\/t.co\/sAzNkDp7h1 http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/SenatorBoxer\/status\/566377211541090305\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/2N1l4Ff68R",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9wtEn-IMAALx3f.jpg",
        "id_str" : "566377210614132736",
        "id" : 566377210614132736,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9wtEn-IMAALx3f.jpg",
        "sizes" : [ {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/2N1l4Ff68R"
      } ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 66, 77 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/sAzNkDp7h1",
        "expanded_url" : "http:\/\/go.wh.gov\/get-covered",
        "display_url" : "go.wh.gov\/get-covered"
      } ]
    },
    "geo" : { },
    "id_str" : "566377211541090305",
    "text" : "DEADLINE SUNDAY: Just 2 days left to sign up for health coverage. #GetCovered by Feb. 15 \u2192 http:\/\/t.co\/sAzNkDp7h1 http:\/\/t.co\/2N1l4Ff68R",
    "id" : 566377211541090305,
    "created_at" : "2015-02-13 23:23:44 +0000",
    "user" : {
      "name" : "Sen. Barbara Boxer",
      "screen_name" : "SenatorBoxer",
      "protected" : false,
      "id_str" : "15442036",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464147946934517760\/EZ8huLG8_normal.png",
      "id" : 15442036,
      "verified" : true
    }
  },
  "id" : 566377821988081664,
  "created_at" : "2015-02-13 23:26:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 60, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/EO0WsRlbSd",
      "expanded_url" : "http:\/\/healthcare.gov",
      "display_url" : "healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "566376945504366592",
  "text" : "RT @VP: For Valentine's Day, give the gift of health care.\n\n#GetCovered by Sunday \u2192 http:\/\/t.co\/EO0WsRlbSd\n\nNow watch this \u2192 https:\/\/t.co\/Z\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 52, 63 ]
      } ],
      "urls" : [ {
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/EO0WsRlbSd",
        "expanded_url" : "http:\/\/healthcare.gov",
        "display_url" : "healthcare.gov"
      }, {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/ZTlEw0enUb",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=rg3WohBhfU0&feature=youtu.be",
        "display_url" : "youtube.com\/watch?v=rg3Woh\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "566365169299648512",
    "text" : "For Valentine's Day, give the gift of health care.\n\n#GetCovered by Sunday \u2192 http:\/\/t.co\/EO0WsRlbSd\n\nNow watch this \u2192 https:\/\/t.co\/ZTlEw0enUb",
    "id" : 566365169299648512,
    "created_at" : "2015-02-13 22:35:53 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 566376945504366592,
  "created_at" : "2015-02-13 23:22:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/566359885000871936\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/MpgCgbX2T6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9wc1jNIIAAnyJO.jpg",
      "id_str" : "566359359450783744",
      "id" : 566359359450783744,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9wc1jNIIAAnyJO.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/MpgCgbX2T6"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/fEPnw41tbM",
      "expanded_url" : "http:\/\/go.wh.gov\/LDTTU5",
      "display_url" : "go.wh.gov\/LDTTU5"
    } ]
  },
  "geo" : { },
  "id_str" : "566359885000871936",
  "text" : "Check out how President Obama is helping to reduce wait times for international travelers: http:\/\/t.co\/fEPnw41tbM http:\/\/t.co\/MpgCgbX2T6",
  "id" : 566359885000871936,
  "created_at" : "2015-02-13 22:14:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 79, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/9EyZA1amok",
      "expanded_url" : "http:\/\/go.wh.gov\/get-covered",
      "display_url" : "go.wh.gov\/get-covered"
    } ]
  },
  "geo" : { },
  "id_str" : "566355983467679745",
  "text" : "RT @FLOTUS: Being healthy isn't just about eating right. Need health coverage? #GetCovered by Feb. 15: http:\/\/t.co\/9EyZA1amok https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 67, 78 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/9EyZA1amok",
        "expanded_url" : "http:\/\/go.wh.gov\/get-covered",
        "display_url" : "go.wh.gov\/get-covered"
      }, {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/BUmvuxDEso",
        "expanded_url" : "https:\/\/vine.co\/v\/OP69tQhaddw",
        "display_url" : "vine.co\/v\/OP69tQhaddw"
      } ]
    },
    "geo" : { },
    "id_str" : "566355063959224320",
    "text" : "Being healthy isn't just about eating right. Need health coverage? #GetCovered by Feb. 15: http:\/\/t.co\/9EyZA1amok https:\/\/t.co\/BUmvuxDEso",
    "id" : 566355063959224320,
    "created_at" : "2015-02-13 21:55:44 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 566355983467679745,
  "created_at" : "2015-02-13 21:59:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/566350749517754368\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/kV4XmkU7gw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9wUbm4IQAAnHK8.jpg",
      "id_str" : "566350117666832384",
      "id" : 566350117666832384,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9wUbm4IQAAnHK8.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/kV4XmkU7gw"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 71, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/rNzHK5i4MN",
      "expanded_url" : "http:\/\/go.wh.gov\/get-covered",
      "display_url" : "go.wh.gov\/get-covered"
    } ]
  },
  "geo" : { },
  "id_str" : "566350749517754368",
  "text" : "DEADLINE SUNDAY: Just 2 days left to sign up for 2015 health coverage. #GetCovered today \u2192 http:\/\/t.co\/rNzHK5i4MN http:\/\/t.co\/kV4XmkU7gw",
  "id" : 566350749517754368,
  "created_at" : "2015-02-13 21:38:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/566330235260395521\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/1J41SVXySy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9wCSDFIUAAEQ7s.png",
      "id_str" : "566330162229563392",
      "id" : 566330162229563392,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9wCSDFIUAAEQ7s.png",
      "sizes" : [ {
        "h" : 208,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 327,
        "resize" : "fit",
        "w" : 943
      }, {
        "h" : 327,
        "resize" : "fit",
        "w" : 943
      }, {
        "h" : 118,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/1J41SVXySy"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "566330235260395521",
  "text" : "\"No one in the United States of America should ever be targeted because of who they are...or how they worship\" \u2014Obama http:\/\/t.co\/1J41SVXySy",
  "id" : 566330235260395521,
  "created_at" : "2015-02-13 20:17:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CyberSummit",
      "indices" : [ 121, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "566325930054795266",
  "text" : "\u201CThis is not a liberal or conservative issue. Everybody\u2019s online.\u201D \u2014President Obama on the need to improve cybersecurity #CyberSummit",
  "id" : 566325930054795266,
  "created_at" : "2015-02-13 19:59:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/566324975360278530\/photo\/1",
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/STkILnFIVd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9v9cxbIUAEhUNF.jpg",
      "id_str" : "566324848910422017",
      "id" : 566324848910422017,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9v9cxbIUAEhUNF.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/STkILnFIVd"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "566324975360278530",
  "text" : "\"We\u2019ve proposed...legislation to promote greater information sharing between government &amp; the private sector\" \u2014Obama http:\/\/t.co\/STkILnFIVd",
  "id" : 566324975360278530,
  "created_at" : "2015-02-13 19:56:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "566324285044973572",
  "text" : "RT @WHLive: \"We\u2019ve called for a single national standard so Americans know within 30 days if your information has been stolen.\" \u2014Obama #Cyb\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CyberSummit",
        "indices" : [ 123, 135 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "566324261636169728",
    "text" : "\"We\u2019ve called for a single national standard so Americans know within 30 days if your information has been stolen.\" \u2014Obama #CyberSummit",
    "id" : 566324261636169728,
    "created_at" : "2015-02-13 19:53:20 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 566324285044973572,
  "created_at" : "2015-02-13 19:53:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CyberSummit",
      "indices" : [ 117, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "566323740225855488",
  "text" : "\"When we go online, we shouldn\u2019t have to forfeit the basic privacy we\u2019re entitled to as Americans.\" \u2014President Obama #CyberSummit",
  "id" : 566323740225855488,
  "created_at" : "2015-02-13 19:51:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CyberSummit",
      "indices" : [ 116, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/0VB3MmHGCp",
      "expanded_url" : "http:\/\/go.wh.gov\/pHyyxk",
      "display_url" : "go.wh.gov\/pHyyxk"
    } ]
  },
  "geo" : { },
  "id_str" : "566323457613254656",
  "text" : "Get the latest on how President Obama's helping companies respond to cybersecurity threats \u2192 http:\/\/t.co\/0VB3MmHGCp #CyberSummit",
  "id" : 566323457613254656,
  "created_at" : "2015-02-13 19:50:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/566322945786929152\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/QHbsIY9mRM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9v7qCWIcAAf8-l.jpg",
      "id_str" : "566322877767905280",
      "id" : 566322877767905280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9v7qCWIcAAf8-l.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/QHbsIY9mRM"
    } ],
    "hashtags" : [ {
      "text" : "NetNeutrality",
      "indices" : [ 41, 55 ]
    }, {
      "text" : "CyberSummit",
      "indices" : [ 104, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "566322945786929152",
  "text" : "\"I\u2019ve come out publicly and strongly for #NetNeutrality\u2014for an open and free Internet\" \u2014President Obama #CyberSummit http:\/\/t.co\/QHbsIY9mRM",
  "id" : 566322945786929152,
  "created_at" : "2015-02-13 19:48:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CyberSummit",
      "indices" : [ 97, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "566322586229805057",
  "text" : "\"When it comes to educating our children, we can\u2019t afford any digital divides.\" \u2014President Obama #CyberSummit",
  "id" : 566322586229805057,
  "created_at" : "2015-02-13 19:46:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/566322518902857728\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/Kn0lV4Zqua",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9v7UX6IQAA2oz_.jpg",
      "id_str" : "566322505598910464",
      "id" : 566322505598910464,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9v7UX6IQAA2oz_.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/Kn0lV4Zqua"
    } ],
    "hashtags" : [ {
      "text" : "CyberSummit",
      "indices" : [ 94, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "566322518902857728",
  "text" : "\"We\u2019re working to connect 99% of America\u2019s students to high-speed Internet.\" \u2014President Obama #CyberSummit http:\/\/t.co\/Kn0lV4Zqua",
  "id" : 566322518902857728,
  "created_at" : "2015-02-13 19:46:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "566322187166961665",
  "text" : "RT @WHLive: \"These attacks are hurting American companies and costing American jobs.\" \u2014Obama on why he's working to improve cybersecurity #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CyberSummit",
        "indices" : [ 126, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "566322139825840128",
    "text" : "\"These attacks are hurting American companies and costing American jobs.\" \u2014Obama on why he's working to improve cybersecurity #CyberSummit",
    "id" : 566322139825840128,
    "created_at" : "2015-02-13 19:44:54 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 566322187166961665,
  "created_at" : "2015-02-13 19:45:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/SDaMj1N698",
      "expanded_url" : "http:\/\/go.wh.gov\/CUNxMH",
      "display_url" : "go.wh.gov\/CUNxMH"
    } ]
  },
  "geo" : { },
  "id_str" : "566321879225360386",
  "text" : "RT @WHLive: \"As a nation, we do more business online than ever before\u2014trillions of dollars a year\" \u2014President Obama: http:\/\/t.co\/SDaMj1N698\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CyberSummit",
        "indices" : [ 128, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/SDaMj1N698",
        "expanded_url" : "http:\/\/go.wh.gov\/CUNxMH",
        "display_url" : "go.wh.gov\/CUNxMH"
      } ]
    },
    "geo" : { },
    "id_str" : "566321853040295936",
    "text" : "\"As a nation, we do more business online than ever before\u2014trillions of dollars a year\" \u2014President Obama: http:\/\/t.co\/SDaMj1N698 #CyberSummit",
    "id" : 566321853040295936,
    "created_at" : "2015-02-13 19:43:46 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 566321879225360386,
  "created_at" : "2015-02-13 19:43:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CyberSummit",
      "indices" : [ 121, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "566321494871928832",
  "text" : "\"The very technologies that empower us to do great good can also be used to undermine us and inflict great harm.\" \u2014Obama #CyberSummit",
  "id" : 566321494871928832,
  "created_at" : "2015-02-13 19:42:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yahoo",
      "screen_name" : "Yahoo",
      "indices" : [ 30, 36 ],
      "id_str" : "19380829",
      "id" : 19380829
    }, {
      "name" : "Google",
      "screen_name" : "google",
      "indices" : [ 41, 48 ],
      "id_str" : "20536157",
      "id" : 20536157
    }, {
      "name" : "Stanford University",
      "screen_name" : "Stanford",
      "indices" : [ 111, 120 ],
      "id_str" : "18036441",
      "id" : 18036441
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CyberSummit",
      "indices" : [ 121, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "566321339997650944",
  "text" : "\"Student projects here became @Yahoo and @Google\u2014those were pretty good student projects.\" \u2014President Obama at @Stanford #CyberSummit",
  "id" : 566321339997650944,
  "created_at" : "2015-02-13 19:41:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "566321064100528128",
  "text" : "\"If we want to maintain our economic leadership in the world, America has to keep investing in basic research &amp; science &amp; technology\" \u2014Obama",
  "id" : 566321064100528128,
  "created_at" : "2015-02-13 19:40:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/566320398057623552\/photo\/1",
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/bhV1wJf4rd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9v5TiBIYAA-sg6.jpg",
      "id_str" : "566320292109508608",
      "id" : 566320292109508608,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9v5TiBIYAA-sg6.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/bhV1wJf4rd"
    } ],
    "hashtags" : [ {
      "text" : "CyberSummit",
      "indices" : [ 76, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "566320398057623552",
  "text" : "\"We just had the best year of job growth since the 1990s.\" \u2014President Obama #CyberSummit http:\/\/t.co\/bhV1wJf4rd",
  "id" : 566320398057623552,
  "created_at" : "2015-02-13 19:37:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CyberSummit",
      "indices" : [ 115, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/CLzZNSwKZU",
      "expanded_url" : "http:\/\/go.wh.gov\/CUNxMH",
      "display_url" : "go.wh.gov\/CUNxMH"
    } ]
  },
  "geo" : { },
  "id_str" : "566319331756081153",
  "text" : "Watch live: President Obama speaks at the Summit on Cybersecurity and Consumer Protection \u2192 http:\/\/t.co\/CLzZNSwKZU #CyberSummit",
  "id" : 566319331756081153,
  "created_at" : "2015-02-13 19:33:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Schultz",
      "screen_name" : "Schultz44",
      "indices" : [ 3, 13 ],
      "id_str" : "1603419038",
      "id" : 1603419038
    }, {
      "name" : "Stanford University",
      "screen_name" : "Stanford",
      "indices" : [ 117, 126 ],
      "id_str" : "18036441",
      "id" : 18036441
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "566314485389209600",
  "text" : "RT @Schultz44: POTUS loading Marine One en route to first ever WH Summit on Cybersecurity and Consumer Protection at @Stanford http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stanford University",
        "screen_name" : "Stanford",
        "indices" : [ 102, 111 ],
        "id_str" : "18036441",
        "id" : 18036441
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Schultz44\/status\/566303618916048896\/photo\/1",
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/6d56Phk34L",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9vqINdCMAM8SOx.jpg",
        "id_str" : "566303604936421379",
        "id" : 566303604936421379,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9vqINdCMAM8SOx.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/6d56Phk34L"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 37.80194707439836, -122.460746043569 ]
    },
    "id_str" : "566303618916048896",
    "text" : "POTUS loading Marine One en route to first ever WH Summit on Cybersecurity and Consumer Protection at @Stanford http:\/\/t.co\/6d56Phk34L",
    "id" : 566303618916048896,
    "created_at" : "2015-02-13 18:31:18 +0000",
    "user" : {
      "name" : "Eric Schultz",
      "screen_name" : "Schultz44",
      "protected" : false,
      "id_str" : "1603419038",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/491941155815161856\/u0IdexM6_normal.jpeg",
      "id" : 1603419038,
      "verified" : true
    }
  },
  "id" : 566314485389209600,
  "created_at" : "2015-02-13 19:14:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/www.thunderclap.it\" rel=\"nofollow\"\u003EThunderclap\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/566251333443788800\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/k60yHqZy2i",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9u6eabIUAAjrNw.jpg",
      "id_str" : "566251209817083904",
      "id" : 566251209817083904,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9u6eabIUAAjrNw.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/k60yHqZy2i"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 33, 44 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/GNfbft9Ewv",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "566303529728770049",
  "text" : "Don't delay: Just 2 days left to #GetCovered!\nSIgn up for 2015 health coverage today at http:\/\/t.co\/GNfbft9Ewv. http:\/\/t.co\/k60yHqZy2i",
  "id" : 566303529728770049,
  "created_at" : "2015-02-13 18:30:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CyberSummit",
      "indices" : [ 118, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/0VB3MmZi0Z",
      "expanded_url" : "http:\/\/go.wh.gov\/pHyyxk",
      "display_url" : "go.wh.gov\/pHyyxk"
    } ]
  },
  "geo" : { },
  "id_str" : "566298519427100674",
  "text" : "Today, President Obama's taking new steps to help companies respond to cybersecurity threats \u2192 http:\/\/t.co\/0VB3MmZi0Z #CyberSummit",
  "id" : 566298519427100674,
  "created_at" : "2015-02-13 18:11:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/xq2hAe5FAy",
      "expanded_url" : "http:\/\/on.doi.gov\/1vqOsU7",
      "display_url" : "on.doi.gov\/1vqOsU7"
    } ]
  },
  "geo" : { },
  "id_str" : "566294033610182656",
  "text" : "RT @Interior: The sweetest Valentine's Day video you will watch all day! http:\/\/t.co\/xq2hAe5FAy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 81 ],
        "url" : "http:\/\/t.co\/xq2hAe5FAy",
        "expanded_url" : "http:\/\/on.doi.gov\/1vqOsU7",
        "display_url" : "on.doi.gov\/1vqOsU7"
      } ]
    },
    "geo" : { },
    "id_str" : "566272321493934080",
    "text" : "The sweetest Valentine's Day video you will watch all day! http:\/\/t.co\/xq2hAe5FAy",
    "id" : 566272321493934080,
    "created_at" : "2015-02-13 16:26:56 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 566294033610182656,
  "created_at" : "2015-02-13 17:53:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "POLITICO",
      "screen_name" : "politico",
      "indices" : [ 126, 135 ],
      "id_str" : "9300262",
      "id" : 9300262
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 71, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "566281901309456385",
  "text" : "RT @Podesta44: 2. President Obama\u2019s leadership showed time &amp; again #ActOnClimate progress is possible. My parting shot in @POLITICO: http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "POLITICO",
        "screen_name" : "politico",
        "indices" : [ 111, 120 ],
        "id_str" : "9300262",
        "id" : 9300262
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 56, 69 ]
      } ],
      "urls" : [ {
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/hwi22K0RwK",
        "expanded_url" : "http:\/\/www.politico.com\/magazine\/story\/2015\/02\/climate-change-john-podesta-115169.html",
        "display_url" : "politico.com\/magazine\/story\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "566278913131683841",
    "text" : "2. President Obama\u2019s leadership showed time &amp; again #ActOnClimate progress is possible. My parting shot in @POLITICO: http:\/\/t.co\/hwi22K0RwK",
    "id" : 566278913131683841,
    "created_at" : "2015-02-13 16:53:08 +0000",
    "user" : {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "protected" : false,
      "id_str" : "2382117350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656551411145027584\/ArrSlGUP_normal.jpg",
      "id" : 2382117350,
      "verified" : true
    }
  },
  "id" : 566281901309456385,
  "created_at" : "2015-02-13 17:05:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "566272295728336897",
  "text" : "RT @Podesta44: My last day as Counselor to President Obama. It's been a tremendous privilege to serve a great President and the country for\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "566269460621688833",
    "text" : "My last day as Counselor to President Obama. It's been a tremendous privilege to serve a great President and the country for this last year.",
    "id" : 566269460621688833,
    "created_at" : "2015-02-13 16:15:34 +0000",
    "user" : {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "protected" : false,
      "id_str" : "2382117350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656551411145027584\/ArrSlGUP_normal.jpg",
      "id" : 2382117350,
      "verified" : true
    }
  },
  "id" : 566272295728336897,
  "created_at" : "2015-02-13 16:26:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/566268231451566081\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/uSzxQvGP7c",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9vI9OYIQAA9C4T.png",
      "id_str" : "566267132322004992",
      "id" : 566267132322004992,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9vI9OYIQAA9C4T.png",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 806,
        "resize" : "fit",
        "w" : 1436
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/uSzxQvGP7c"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 71, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/edMm32q3mA",
      "expanded_url" : "http:\/\/on.fb.me\/1FD9xRd",
      "display_url" : "on.fb.me\/1FD9xRd"
    }, {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/GNfbftrfo3",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "566268231451566081",
  "text" : "\"Can I live?\" \u2014President Obama\nWatch this \u2192 http:\/\/t.co\/edMm32q3mA\nAnd #GetCovered by Sunday \u2192 http:\/\/t.co\/GNfbftrfo3 http:\/\/t.co\/uSzxQvGP7c",
  "id" : 566268231451566081,
  "created_at" : "2015-02-13 16:10:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/566251333443788800\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/k60yHqZy2i",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9u6eabIUAAjrNw.jpg",
      "id_str" : "566251209817083904",
      "id" : 566251209817083904,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9u6eabIUAAjrNw.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/k60yHqZy2i"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 56, 67 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/rNzHK5zFEl",
      "expanded_url" : "http:\/\/go.wh.gov\/get-covered",
      "display_url" : "go.wh.gov\/get-covered"
    } ]
  },
  "geo" : { },
  "id_str" : "566251333443788800",
  "text" : "2 days left to sign up for health coverage.\nDon\u2019t wait: #GetCovered today \u2192 http:\/\/t.co\/rNzHK5zFEl http:\/\/t.co\/k60yHqZy2i",
  "id" : 566251333443788800,
  "created_at" : "2015-02-13 15:03:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Interior\/status\/566018569759379457\/photo\/1",
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/cxxgOxZafc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9rm4uLIgAAWJ2e.jpg",
      "id_str" : "566018565330206720",
      "id" : 566018565330206720,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9rm4uLIgAAWJ2e.jpg",
      "sizes" : [ {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/cxxgOxZafc"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "566040501212545026",
  "text" : "RT @Interior: RT to spread the word \u2192 This weekend entrance fees will be waived for all public lands http:\/\/t.co\/cxxgOxZafc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Interior\/status\/566018569759379457\/photo\/1",
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/cxxgOxZafc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9rm4uLIgAAWJ2e.jpg",
        "id_str" : "566018565330206720",
        "id" : 566018565330206720,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9rm4uLIgAAWJ2e.jpg",
        "sizes" : [ {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/cxxgOxZafc"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "566018569759379457",
    "text" : "RT to spread the word \u2192 This weekend entrance fees will be waived for all public lands http:\/\/t.co\/cxxgOxZafc",
    "id" : 566018569759379457,
    "created_at" : "2015-02-12 23:38:37 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 566040501212545026,
  "created_at" : "2015-02-13 01:05:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TBT",
      "indices" : [ 12, 16 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 94, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/s27SRe31tV",
      "expanded_url" : "http:\/\/go.wh.gov\/buzzfeed",
      "display_url" : "go.wh.gov\/buzzfeed"
    }, {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/iP0O6miwvO",
      "expanded_url" : "http:\/\/healthcare.gov",
      "display_url" : "healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "566028518975209475",
  "text" : "RT @FLOTUS: #TBT to when we all drew our crushes: http:\/\/t.co\/s27SRe31tV\nBut now it's time to #GetCovered: http:\/\/t.co\/iP0O6miwvO http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/FLOTUS\/status\/566027772489781248\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/mbayUjP331",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9rvIqcIcAAoKff.png",
        "id_str" : "566027635298693120",
        "id" : 566027635298693120,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9rvIqcIcAAoKff.png",
        "sizes" : [ {
          "h" : 572,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 715,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 335,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 190,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/mbayUjP331"
      } ],
      "hashtags" : [ {
        "text" : "TBT",
        "indices" : [ 0, 4 ]
      }, {
        "text" : "GetCovered",
        "indices" : [ 82, 93 ]
      } ],
      "urls" : [ {
        "indices" : [ 38, 60 ],
        "url" : "http:\/\/t.co\/s27SRe31tV",
        "expanded_url" : "http:\/\/go.wh.gov\/buzzfeed",
        "display_url" : "go.wh.gov\/buzzfeed"
      }, {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/iP0O6miwvO",
        "expanded_url" : "http:\/\/healthcare.gov",
        "display_url" : "healthcare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "566027772489781248",
    "text" : "#TBT to when we all drew our crushes: http:\/\/t.co\/s27SRe31tV\nBut now it's time to #GetCovered: http:\/\/t.co\/iP0O6miwvO http:\/\/t.co\/mbayUjP331",
    "id" : 566027772489781248,
    "created_at" : "2015-02-13 00:15:11 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 566028518975209475,
  "created_at" : "2015-02-13 00:18:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 97, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/GNfbftrfo3",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    }, {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/Z8XC7QYiKg",
      "expanded_url" : "https:\/\/vine.co\/v\/OPMM1lIxx2d",
      "display_url" : "vine.co\/v\/OPMM1lIxx2d"
    } ]
  },
  "geo" : { },
  "id_str" : "566000296719958017",
  "text" : "\"Health care for less than your cell phone bill? Now that's a slam dunk!\" http:\/\/t.co\/GNfbftrfo3 #GetCovered https:\/\/t.co\/Z8XC7QYiKg",
  "id" : 566000296719958017,
  "created_at" : "2015-02-12 22:26:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/565995454023073792\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/Wh82V4NR1t",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9rRYbZIMAAcvQN.png",
      "id_str" : "565994920788635648",
      "id" : 565994920788635648,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9rRYbZIMAAcvQN.png",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 805,
        "resize" : "fit",
        "w" : 1434
      }, {
        "h" : 575,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/Wh82V4NR1t"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 41, 52 ]
    }, {
      "text" : "ThanksObama",
      "indices" : [ 100, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/GNfbft9Ewv",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    }, {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/edMm328sv2",
      "expanded_url" : "http:\/\/on.fb.me\/1FD9xRd",
      "display_url" : "on.fb.me\/1FD9xRd"
    } ]
  },
  "geo" : { },
  "id_str" : "565995454023073792",
  "text" : "Can't dunk your cookie?\nAt least you can #GetCovered: http:\/\/t.co\/GNfbft9Ewv http:\/\/t.co\/edMm328sv2 #ThanksObama http:\/\/t.co\/Wh82V4NR1t",
  "id" : 565995454023073792,
  "created_at" : "2015-02-12 22:06:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth Banks",
      "screen_name" : "ElizabethBanks",
      "indices" : [ 3, 18 ],
      "id_str" : "20196258",
      "id" : 20196258
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ElizabethBanks\/status\/565975593125031936\/photo\/1",
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/KES9Isru5M",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9q_zYgCAAAtpZI.png",
      "id_str" : "565975592659451904",
      "id" : 565975592659451904,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9q_zYgCAAAtpZI.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 476,
        "resize" : "fit",
        "w" : 474
      }, {
        "h" : 476,
        "resize" : "fit",
        "w" : 474
      }, {
        "h" : 476,
        "resize" : "fit",
        "w" : 474
      }, {
        "h" : 341,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/KES9Isru5M"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 31, 42 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/8WS7TUzBVn",
      "expanded_url" : "http:\/\/healthcare.gov",
      "display_url" : "healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "565987305161101312",
  "text" : "RT @ElizabethBanks: Get on it! #GetCovered 3 days left. Your body thanks you. http:\/\/t.co\/8WS7TUzBVn http:\/\/t.co\/KES9Isru5M",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ElizabethBanks\/status\/565975593125031936\/photo\/1",
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/KES9Isru5M",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9q_zYgCAAAtpZI.png",
        "id_str" : "565975592659451904",
        "id" : 565975592659451904,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9q_zYgCAAAtpZI.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 476,
          "resize" : "fit",
          "w" : 474
        }, {
          "h" : 476,
          "resize" : "fit",
          "w" : 474
        }, {
          "h" : 476,
          "resize" : "fit",
          "w" : 474
        }, {
          "h" : 341,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/KES9Isru5M"
      } ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 11, 22 ]
      } ],
      "urls" : [ {
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/8WS7TUzBVn",
        "expanded_url" : "http:\/\/healthcare.gov",
        "display_url" : "healthcare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "565975593125031936",
    "text" : "Get on it! #GetCovered 3 days left. Your body thanks you. http:\/\/t.co\/8WS7TUzBVn http:\/\/t.co\/KES9Isru5M",
    "id" : 565975593125031936,
    "created_at" : "2015-02-12 20:47:51 +0000",
    "user" : {
      "name" : "Elizabeth Banks",
      "screen_name" : "ElizabethBanks",
      "protected" : false,
      "id_str" : "20196258",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791454824306880512\/YiAb44jE_normal.jpg",
      "id" : 20196258,
      "verified" : true
    }
  },
  "id" : 565987305161101312,
  "created_at" : "2015-02-12 21:34:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/565981354912137217\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/TCbW90OVt2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9rBeVZIMAAmaDf.jpg",
      "id_str" : "565977430071193600",
      "id" : 565977430071193600,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9rBeVZIMAAmaDf.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/TCbW90OVt2"
    } ],
    "hashtags" : [ {
      "text" : "LeadOnLeave",
      "indices" : [ 103, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565981354912137217",
  "text" : "Congrats to Philadelphia and Mayor Nutter for expanding paid sick leave.\nNow it's time for Congress to #LeadOnLeave. http:\/\/t.co\/TCbW90OVt2",
  "id" : 565981354912137217,
  "created_at" : "2015-02-12 21:10:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/565971629176401920\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/qf4vhdj2wq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9q8JzUIEAAWk47.png",
      "id_str" : "565971579767885824",
      "id" : 565971579767885824,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9q8JzUIEAAWk47.png",
      "sizes" : [ {
        "h" : 327,
        "resize" : "fit",
        "w" : 930
      }, {
        "h" : 327,
        "resize" : "fit",
        "w" : 930
      }, {
        "h" : 120,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 211,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/qf4vhdj2wq"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565971629176401920",
  "text" : "\"I\u2019m proud to welcome him back as our next Secretary of Defense.\" \u2014Obama on Senate confirmation of Ash Carter http:\/\/t.co\/qf4vhdj2wq",
  "id" : 565971629176401920,
  "created_at" : "2015-02-12 20:32:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565954792724656128",
  "text" : "\"If you are hurting, know this: You are not forgotten. You are not alone. You are never alone. We are here for you.\" \u2014Obama to our veterans",
  "id" : 565954792724656128,
  "created_at" : "2015-02-12 19:25:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565953414605975552",
  "text" : "\u201CWe will not will not be satisfied until every man and woman in uniform...gets the help they need to stay healthy and strong.\u201D \u2014Obama",
  "id" : 565953414605975552,
  "created_at" : "2015-02-12 19:19:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565953139208384513",
  "text" : "RT @WHLive: \"It makes it easier for veterans to find the care they need when they need it.\" \u2014President Obama on the Clay Hunt SAV Act #Hono\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HonoringVets",
        "indices" : [ 122, 135 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "565953108266991618",
    "text" : "\"It makes it easier for veterans to find the care they need when they need it.\" \u2014President Obama on the Clay Hunt SAV Act #HonoringVets",
    "id" : 565953108266991618,
    "created_at" : "2015-02-12 19:18:30 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 565953139208384513,
  "created_at" : "2015-02-12 19:18:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HonoringVets",
      "indices" : [ 109, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565952525237780481",
  "text" : "\"Today, I will sign the Clay Hunt [Suicide Prevention for American Veterans] Act into law.\" \u2014President Obama #HonoringVets",
  "id" : 565952525237780481,
  "created_at" : "2015-02-12 19:16:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HonoringVets",
      "indices" : [ 123, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565951950148337664",
  "text" : "\"To anyone out there who\u2019s hurting\u2014it\u2019s not a sign of weakness to ask for help. It\u2019s a sign of strength.\" \u2014President Obama #HonoringVets",
  "id" : 565951950148337664,
  "created_at" : "2015-02-12 19:13:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HonoringVets",
      "indices" : [ 121, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565951323816726529",
  "text" : "\"Every single veteran in America has something extraordinary to give to this country\u2014every single one.\" \u2014President Obama #HonoringVets",
  "id" : 565951323816726529,
  "created_at" : "2015-02-12 19:11:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565951187166322689",
  "text" : "\"After 13 years, our combat mission in Afghanistan is over and a new generation of veterans is coming home.\" \u2014President Obama",
  "id" : 565951187166322689,
  "created_at" : "2015-02-12 19:10:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565950703915782144",
  "text" : "\"Today, we honor a young man who isn\u2019t here, but should be.\" \u2014President Obama on the Clay Hunt Suicide Prevention for American Veterans Act",
  "id" : 565950703915782144,
  "created_at" : "2015-02-12 19:08:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/zpRdIUbWmn",
      "expanded_url" : "http:\/\/go.wh.gov\/u8kdH2",
      "display_url" : "go.wh.gov\/u8kdH2"
    } ]
  },
  "geo" : { },
  "id_str" : "565950536709865472",
  "text" : "Watch live: President Obama speaks before signing the Clay Hunt Suicide Prevention for American Veterans Act \u2192 http:\/\/t.co\/zpRdIUbWmn",
  "id" : 565950536709865472,
  "created_at" : "2015-02-12 19:08:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565940497248579584",
  "text" : "RT @arneduncan: 81% America's new record graduation rate! Thank you to teachers, principals, students &amp; families for working so hard! http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/2itGvocHSX",
        "expanded_url" : "http:\/\/1.usa.gov\/1J2xsyX",
        "display_url" : "1.usa.gov\/1J2xsyX"
      } ]
    },
    "geo" : { },
    "id_str" : "565922638954897408",
    "text" : "81% America's new record graduation rate! Thank you to teachers, principals, students &amp; families for working so hard! http:\/\/t.co\/2itGvocHSX",
    "id" : 565922638954897408,
    "created_at" : "2015-02-12 17:17:26 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 565940497248579584,
  "created_at" : "2015-02-12 18:28:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/565931602266820608\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/Ws1rTHRDC6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9qXrA7IgAAPyJa.png",
      "id_str" : "565931468426608640",
      "id" : 565931468426608640,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9qXrA7IgAAPyJa.png",
      "sizes" : [ {
        "h" : 644,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 804,
        "resize" : "fit",
        "w" : 1279
      }, {
        "h" : 377,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 214,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Ws1rTHRDC6"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 29, 40 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/GNfbft9Ewv",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    }, {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/edMm328sv2",
      "expanded_url" : "http:\/\/on.fb.me\/1FD9xRd",
      "display_url" : "on.fb.me\/1FD9xRd"
    } ]
  },
  "geo" : { },
  "id_str" : "565931602266820608",
  "text" : "President Obama wants YOU to #GetCovered by February 15: http:\/\/t.co\/GNfbft9Ewv\nWatch \u2192 http:\/\/t.co\/edMm328sv2 http:\/\/t.co\/Ws1rTHRDC6",
  "id" : 565931602266820608,
  "created_at" : "2015-02-12 17:53:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/565923102811369473\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/VqzhrcrA7I",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9qPfSuIQAAr7Te.png",
      "id_str" : "565922470952452096",
      "id" : 565922470952452096,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9qPfSuIQAAr7Te.png",
      "sizes" : [ {
        "h" : 317,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 474,
        "resize" : "fit",
        "w" : 898
      }, {
        "h" : 474,
        "resize" : "fit",
        "w" : 898
      }, {
        "h" : 179,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/VqzhrcrA7I"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 64, 75 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/edMm32q3mA",
      "expanded_url" : "http:\/\/on.fb.me\/1FD9xRd",
      "display_url" : "on.fb.me\/1FD9xRd"
    } ]
  },
  "geo" : { },
  "id_str" : "565923102811369473",
  "text" : "\"YOLO man!\"\nFind out why President Obama has a selfie stick\u2014and #GetCovered by February 15: http:\/\/t.co\/edMm32q3mA http:\/\/t.co\/VqzhrcrA7I",
  "id" : 565923102811369473,
  "created_at" : "2015-02-12 17:19:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BuzzFeedVideo",
      "screen_name" : "BuzzFeedVideo",
      "indices" : [ 3, 17 ],
      "id_str" : "774311630",
      "id" : 774311630
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/5kavBMu5tV",
      "expanded_url" : "https:\/\/www.facebook.com\/video.php?v=1631492713658271",
      "display_url" : "facebook.com\/video.php?v=16\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "565919023586488320",
  "text" : "RT @BuzzFeedVideo: Things Everybody Does But Doesn't Talk About, Featuring President Obama https:\/\/t.co\/5kavBMu5tV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/5kavBMu5tV",
        "expanded_url" : "https:\/\/www.facebook.com\/video.php?v=1631492713658271",
        "display_url" : "facebook.com\/video.php?v=16\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "565917373765394432",
    "text" : "Things Everybody Does But Doesn't Talk About, Featuring President Obama https:\/\/t.co\/5kavBMu5tV",
    "id" : 565917373765394432,
    "created_at" : "2015-02-12 16:56:30 +0000",
    "user" : {
      "name" : "BuzzFeedVideo",
      "screen_name" : "BuzzFeedVideo",
      "protected" : false,
      "id_str" : "774311630",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/677565787142381569\/K3EfCvWL_normal.png",
      "id" : 774311630,
      "verified" : true
    }
  },
  "id" : 565919023586488320,
  "created_at" : "2015-02-12 17:03:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Pierce",
      "screen_name" : "paulpierce34",
      "indices" : [ 3, 16 ],
      "id_str" : "27115071",
      "id" : 27115071
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 94, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/5OWmnFZVlq",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "565913661982900224",
  "text" : "RT @paulpierce34: you only have 3 days left to sign up for 2015 health coverage. don't wait!  #GetCovered at http:\/\/t.co\/5OWmnFZVlq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 76, 87 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/5OWmnFZVlq",
        "expanded_url" : "http:\/\/HealthCare.gov",
        "display_url" : "HealthCare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "565907681870098432",
    "text" : "you only have 3 days left to sign up for 2015 health coverage. don't wait!  #GetCovered at http:\/\/t.co\/5OWmnFZVlq",
    "id" : 565907681870098432,
    "created_at" : "2015-02-12 16:18:00 +0000",
    "user" : {
      "name" : "Paul Pierce",
      "screen_name" : "paulpierce34",
      "protected" : false,
      "id_str" : "27115071",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/534069569665896448\/7H9G_mVn_normal.jpeg",
      "id" : 27115071,
      "verified" : true
    }
  },
  "id" : 565913661982900224,
  "created_at" : "2015-02-12 16:41:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "grant hill",
      "screen_name" : "realgranthill33",
      "indices" : [ 3, 19 ],
      "id_str" : "171485965",
      "id" : 171485965
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 46, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/HzLfMSFAKD",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "565910832303706112",
  "text" : "RT @realgranthill33: Don't wait! It's time to #GetCovered.\nJust 3 days left to sign up for 2015 health coverage \u2192 http:\/\/t.co\/HzLfMSFAKD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 25, 36 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/HzLfMSFAKD",
        "expanded_url" : "http:\/\/HealthCare.gov",
        "display_url" : "HealthCare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "565896622832226306",
    "text" : "Don't wait! It's time to #GetCovered.\nJust 3 days left to sign up for 2015 health coverage \u2192 http:\/\/t.co\/HzLfMSFAKD",
    "id" : 565896622832226306,
    "created_at" : "2015-02-12 15:34:03 +0000",
    "user" : {
      "name" : "grant hill",
      "screen_name" : "realgranthill33",
      "protected" : false,
      "id_str" : "171485965",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/788800344490930176\/aglaEr-y_normal.jpg",
      "id" : 171485965,
      "verified" : true
    }
  },
  "id" : 565910832303706112,
  "created_at" : "2015-02-12 16:30:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Recode",
      "screen_name" : "Recode",
      "indices" : [ 3, 10 ],
      "id_str" : "2244340904",
      "id" : 2244340904
    }, {
      "name" : "Recode",
      "screen_name" : "Recode",
      "indices" : [ 40, 47 ],
      "id_str" : "2244340904",
      "id" : 2244340904
    }, {
      "name" : "Kara Swisher",
      "screen_name" : "karaswisher",
      "indices" : [ 48, 60 ],
      "id_str" : "5763262",
      "id" : 5763262
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Recode\/status\/565904473349181440\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/Atj4NMAPWw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9p_HrOIAAAS8lD.jpg",
      "id_str" : "565904473026199552",
      "id" : 565904473026199552,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9p_HrOIAAAS8lD.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Atj4NMAPWw"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/1Dzu3ilYGL",
      "expanded_url" : "http:\/\/on.recode.net\/1KO6ir7",
      "display_url" : "on.recode.net\/1KO6ir7"
    } ]
  },
  "geo" : { },
  "id_str" : "565906543988584448",
  "text" : "RT @Recode: Tomorrow in Silicon Valley: @recode @karaswisher interviews President Barack Obama http:\/\/t.co\/1Dzu3ilYGL http:\/\/t.co\/Atj4NMAPWw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Recode",
        "screen_name" : "Recode",
        "indices" : [ 28, 35 ],
        "id_str" : "2244340904",
        "id" : 2244340904
      }, {
        "name" : "Kara Swisher",
        "screen_name" : "karaswisher",
        "indices" : [ 36, 48 ],
        "id_str" : "5763262",
        "id" : 5763262
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Recode\/status\/565904473349181440\/photo\/1",
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/Atj4NMAPWw",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9p_HrOIAAAS8lD.jpg",
        "id_str" : "565904473026199552",
        "id" : 565904473026199552,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9p_HrOIAAAS8lD.jpg",
        "sizes" : [ {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/Atj4NMAPWw"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/1Dzu3ilYGL",
        "expanded_url" : "http:\/\/on.recode.net\/1KO6ir7",
        "display_url" : "on.recode.net\/1KO6ir7"
      } ]
    },
    "geo" : { },
    "id_str" : "565904473349181440",
    "text" : "Tomorrow in Silicon Valley: @recode @karaswisher interviews President Barack Obama http:\/\/t.co\/1Dzu3ilYGL http:\/\/t.co\/Atj4NMAPWw",
    "id" : 565904473349181440,
    "created_at" : "2015-02-12 16:05:15 +0000",
    "user" : {
      "name" : "Recode",
      "screen_name" : "Recode",
      "protected" : false,
      "id_str" : "2244340904",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729365899828989952\/o0AuZCNW_normal.jpg",
      "id" : 2244340904,
      "verified" : true
    }
  },
  "id" : 565906543988584448,
  "created_at" : "2015-02-12 16:13:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "San Antonio Spurs",
      "screen_name" : "spurs",
      "indices" : [ 82, 88 ],
      "id_str" : "18371803",
      "id" : 18371803
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 61, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/GNfbftrfo3",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    }, {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/FUYoNEmfDp",
      "expanded_url" : "http:\/\/youtu.be\/VShxt3lHLFw",
      "display_url" : "youtu.be\/VShxt3lHLFw"
    } ]
  },
  "geo" : { },
  "id_str" : "565902052274888707",
  "text" : "\"It's game time America. So go visit http:\/\/t.co\/GNfbftrfo3. #GetCovered today.\" \u2014@Spurs Coach Gregg Popovich: http:\/\/t.co\/FUYoNEmfDp",
  "id" : 565902052274888707,
  "created_at" : "2015-02-12 15:55:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Billie Jean King",
      "screen_name" : "BillieJeanKing",
      "indices" : [ 3, 18 ],
      "id_str" : "35391464",
      "id" : 35391464
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 74, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/7hia8Fouyc",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "565884057863852032",
  "text" : "RT @BillieJeanKing: Just 3 days left to sign up for 2015 health coverage. #GetCovered by Feb 15 at http:\/\/t.co\/7hia8Fouyc. Check it out: ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 54, 65 ]
      } ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/7hia8Fouyc",
        "expanded_url" : "http:\/\/HealthCare.gov",
        "display_url" : "HealthCare.gov"
      }, {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/Y4uu1IRZMb",
        "expanded_url" : "http:\/\/ow.ly\/ISA5T",
        "display_url" : "ow.ly\/ISA5T"
      } ]
    },
    "geo" : { },
    "id_str" : "565859168725127170",
    "text" : "Just 3 days left to sign up for 2015 health coverage. #GetCovered by Feb 15 at http:\/\/t.co\/7hia8Fouyc. Check it out: http:\/\/t.co\/Y4uu1IRZMb",
    "id" : 565859168725127170,
    "created_at" : "2015-02-12 13:05:13 +0000",
    "user" : {
      "name" : "Billie Jean King",
      "screen_name" : "BillieJeanKing",
      "protected" : false,
      "id_str" : "35391464",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000533846602\/014475f80e09ac45aed106a32f656e0d_normal.jpeg",
      "id" : 35391464,
      "verified" : true
    }
  },
  "id" : 565884057863852032,
  "created_at" : "2015-02-12 14:44:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/565665890294038529\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/qFbGAxxHqU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9ml3nXIMAATb6j.jpg",
      "id_str" : "565665603089084416",
      "id" : 565665603089084416,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9ml3nXIMAATb6j.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/qFbGAxxHqU"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 66, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/rNzHK5i4MN",
      "expanded_url" : "http:\/\/go.wh.gov\/get-covered",
      "display_url" : "go.wh.gov\/get-covered"
    } ]
  },
  "geo" : { },
  "id_str" : "565665890294038529",
  "text" : "DEADLINE SUNDAY: Just 4 days left to sign up for health coverage. #GetCovered by Feb. 15 \u2192 http:\/\/t.co\/rNzHK5i4MN http:\/\/t.co\/qFbGAxxHqU",
  "id" : 565665890294038529,
  "created_at" : "2015-02-12 00:17:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565660464139735042",
  "text" : "RT @Interior: Visit national parks, wildlife refuges &amp; other public lands for free this weekend. RT to spread the word! http:\/\/t.co\/jQHrAcb\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/565656863254253568\/photo\/1",
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/jQHrAcbdWO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9md0cvIYAEWKPJ.jpg",
        "id_str" : "565656752604340225",
        "id" : 565656752604340225,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9md0cvIYAEWKPJ.jpg",
        "sizes" : [ {
          "h" : 398,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/jQHrAcbdWO"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "565656863254253568",
    "text" : "Visit national parks, wildlife refuges &amp; other public lands for free this weekend. RT to spread the word! http:\/\/t.co\/jQHrAcbdWO",
    "id" : 565656863254253568,
    "created_at" : "2015-02-11 23:41:20 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 565660464139735042,
  "created_at" : "2015-02-11 23:55:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ISIL",
      "indices" : [ 135, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565613081028755457",
  "text" : "\"Long after the terrorists we face today are destroyed and forgotten, America will continue to stand free and tall and strong.\" \u2014Obama #ISIL",
  "id" : 565613081028755457,
  "created_at" : "2015-02-11 20:47:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ISIL",
      "indices" : [ 130, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565612882290028544",
  "text" : "\"Our coalition is strong, our cause is just and our mission will succeed.\" \u2014President Obama on our mission to degrade and destroy #ISIL",
  "id" : 565612882290028544,
  "created_at" : "2015-02-11 20:46:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ISIL",
      "indices" : [ 59, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565612720138256386",
  "text" : "\"Our men &amp; women in uniform continue the fight against #ISIL. We salute them for their courageous service. We pray for their safety.\" \u2014Obama",
  "id" : 565612720138256386,
  "created_at" : "2015-02-11 20:45:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ISIL",
      "indices" : [ 135, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565612085577789440",
  "text" : "\"As Commander in Chief, I will only send our troops into harm\u2019s way when it is absolutely necessary for our national security.\" \u2014Obama #ISIL",
  "id" : 565612085577789440,
  "created_at" : "2015-02-11 20:43:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ISIL",
      "indices" : [ 125, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565611882086948864",
  "text" : "\"The United States should not get dragged back into another...ground war in the Middle East...that's not necessary to defeat #ISIL.\" \u2014Obama",
  "id" : 565611882086948864,
  "created_at" : "2015-02-11 20:42:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565611608437981184",
  "text" : "\"The resolution we\u2019ve submitted today does not call for the deployment of U.S. ground combat forces to Iraq or Syria.\" \u2014President Obama",
  "id" : 565611608437981184,
  "created_at" : "2015-02-11 20:41:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ISIL",
      "indices" : [ 71, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565611390313177090",
  "text" : "RT @WHLive: \"A systematic and sustained campaign of airstrikes against #ISIL in Iraq and Syria.\" \u2014President Obama on what today's AUMF supp\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ISIL",
        "indices" : [ 59, 64 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "565611324068352001",
    "text" : "\"A systematic and sustained campaign of airstrikes against #ISIL in Iraq and Syria.\" \u2014President Obama on what today's AUMF supports",
    "id" : 565611324068352001,
    "created_at" : "2015-02-11 20:40:22 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 565611390313177090,
  "created_at" : "2015-02-11 20:40:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ISIL",
      "indices" : [ 101, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/1wXMadHftx",
      "expanded_url" : "http:\/\/go.wh.gov\/AUMF",
      "display_url" : "go.wh.gov\/AUMF"
    } ]
  },
  "geo" : { },
  "id_str" : "565611239414702081",
  "text" : "\"Today, my Administration submitted a...resolution to Congress to authorize the use of force against #ISIL.\" \u2014Obama: http:\/\/t.co\/1wXMadHftx",
  "id" : 565611239414702081,
  "created_at" : "2015-02-11 20:40:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ISIL",
      "indices" : [ 132, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565611098859388929",
  "text" : "\"There is only one option\u2014with our allies and partners we are going to degrade and ultimately destroy this terrorist group.\" \u2014Obama #ISIL",
  "id" : 565611098859388929,
  "created_at" : "2015-02-11 20:39:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ISIL",
      "indices" : [ 36, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565611011311665153",
  "text" : "\"Our coalition is on the offensive, #ISIL is on the defensive, and ISIL is going to lose.\" \u2014President Obama",
  "id" : 565611011311665153,
  "created_at" : "2015-02-11 20:39:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ISIL",
      "indices" : [ 142, 147 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565610770466349057",
  "text" : "\"More than 2,000 coalition air strikes have pounded these terrorists. We\u2019re disrupting their command &amp; control &amp; supply lines\" \u2014Obama #ISIL",
  "id" : 565610770466349057,
  "created_at" : "2015-02-11 20:38:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ISIL",
      "indices" : [ 57, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565610707824435200",
  "text" : "\"Our men and women in uniform continue the fight against #ISIL in Iraq and Syria.\" \u2014President Obama",
  "id" : 565610707824435200,
  "created_at" : "2015-02-11 20:37:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ISIL",
      "indices" : [ 109, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/6j6x9YDdfv",
      "expanded_url" : "http:\/\/youtu.be\/5euzs5nh9Bc",
      "display_url" : "youtu.be\/5euzs5nh9Bc"
    } ]
  },
  "geo" : { },
  "id_str" : "565610650672836609",
  "text" : "Watch live: President Obama speaks on a bill he sent Congress to authorize the use of military force against #ISIL: http:\/\/t.co\/6j6x9YDdfv",
  "id" : 565610650672836609,
  "created_at" : "2015-02-11 20:37:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ISIL",
      "indices" : [ 111, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/6j6x9YDdfv",
      "expanded_url" : "http:\/\/youtu.be\/5euzs5nh9Bc",
      "display_url" : "youtu.be\/5euzs5nh9Bc"
    } ]
  },
  "geo" : { },
  "id_str" : "565606096380116992",
  "text" : "At 3:30pm ET, President Obama speaks on a bill he sent Congress to authorize the use of military force against #ISIL: http:\/\/t.co\/6j6x9YDdfv",
  "id" : 565606096380116992,
  "created_at" : "2015-02-11 20:19:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ItsOnUs",
      "indices" : [ 116, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/mn63HzWaYN",
      "expanded_url" : "http:\/\/itsonus.org",
      "display_url" : "itsonus.org"
    } ]
  },
  "geo" : { },
  "id_str" : "565601867338874880",
  "text" : "RT @FLOTUS: \"It's not okay, and it has to stop.\" \u2014President Obama on violence against women: http:\/\/t.co\/mn63HzWaYN #ItsOnUs http:\/\/t.co\/GH\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ItsOnUs",
        "indices" : [ 104, 112 ]
      } ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/mn63HzWaYN",
        "expanded_url" : "http:\/\/itsonus.org",
        "display_url" : "itsonus.org"
      }, {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/GHoJ0E3yIM",
        "expanded_url" : "http:\/\/youtu.be\/NEx-qyZAmqs",
        "display_url" : "youtu.be\/NEx-qyZAmqs"
      } ]
    },
    "geo" : { },
    "id_str" : "565601329096052736",
    "text" : "\"It's not okay, and it has to stop.\" \u2014President Obama on violence against women: http:\/\/t.co\/mn63HzWaYN #ItsOnUs http:\/\/t.co\/GHoJ0E3yIM",
    "id" : 565601329096052736,
    "created_at" : "2015-02-11 20:00:39 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 565601867338874880,
  "created_at" : "2015-02-11 20:02:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 124, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565586235109179393",
  "text" : "\"America is as committed as ever, I am as committed as ever, to getting to zero\u2014and I know we can.\" \u2014President Obama on new #Ebola cases",
  "id" : 565586235109179393,
  "created_at" : "2015-02-11 19:00:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 128, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565585987628453888",
  "text" : "\"We cannot built moats around our countries...what we should do is instead make sure everybody has basic health systems\" \u2014Obama #Ebola",
  "id" : 565585987628453888,
  "created_at" : "2015-02-11 18:59:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 83, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565585352803758081",
  "text" : "\"Our focus is now on getting to zero. Because as long as there is even one case of #Ebola that\u2019s active out there, risk still exists\" \u2014Obama",
  "id" : 565585352803758081,
  "created_at" : "2015-02-11 18:57:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565583923087151104",
  "text" : "RT @WHLive: \"Today, we move into the next phase of the fight, winding down our military response while expanding our civilian response.\" \u2014O\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Ebola",
        "indices" : [ 132, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "565583822092525570",
    "text" : "\"Today, we move into the next phase of the fight, winding down our military response while expanding our civilian response.\" \u2014Obama #Ebola",
    "id" : 565583822092525570,
    "created_at" : "2015-02-11 18:51:05 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 565583923087151104,
  "created_at" : "2015-02-11 18:51:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 117, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565583378058330114",
  "text" : "RT @WHLive: \"Thank you to the troops &amp; public health workers who left...loved ones to head into the heart of the #Ebola epidemic in West Af\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Ebola",
        "indices" : [ 105, 111 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "565583351458037760",
    "text" : "\"Thank you to the troops &amp; public health workers who left...loved ones to head into the heart of the #Ebola epidemic in West Africa.\" \u2014Obama",
    "id" : 565583351458037760,
    "created_at" : "2015-02-11 18:49:13 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 565583378058330114,
  "created_at" : "2015-02-11 18:49:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/565583227424092161\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/GXsVIiGzGX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9lavJ0IgAEbxX7.jpg",
      "id_str" : "565582994346639361",
      "id" : 565582994346639361,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9lavJ0IgAEbxX7.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/GXsVIiGzGX"
    } ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 69, 75 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/kICO4RphOx",
      "expanded_url" : "http:\/\/wh.gov\/ebola-response",
      "display_url" : "wh.gov\/ebola-response"
    } ]
  },
  "geo" : { },
  "id_str" : "565583227424092161",
  "text" : "\"We have made enormous progress in just a few months.\" \u2014Obama on our #Ebola response: http:\/\/t.co\/kICO4RphOx http:\/\/t.co\/GXsVIiGzGX",
  "id" : 565583227424092161,
  "created_at" : "2015-02-11 18:48:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 106, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/kICO4RphOx",
      "expanded_url" : "http:\/\/wh.gov\/ebola-response",
      "display_url" : "wh.gov\/ebola-response"
    } ]
  },
  "geo" : { },
  "id_str" : "565582894794817537",
  "text" : "\"Whenever and wherever a disaster or disease strikes, the world looks to us to lead.\" \u2014President Obama on #Ebola: http:\/\/t.co\/kICO4RphOx",
  "id" : 565582894794817537,
  "created_at" : "2015-02-11 18:47:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 90, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/xdOdItW5mp",
      "expanded_url" : "http:\/\/youtu.be\/IYPU6RxR4ss",
      "display_url" : "youtu.be\/IYPU6RxR4ss"
    } ]
  },
  "geo" : { },
  "id_str" : "565582556721319936",
  "text" : "Watch live: President Obama speaks on the progress we've made and new steps to respond to #Ebola in West Africa \u2192 http:\/\/t.co\/xdOdItW5mp",
  "id" : 565582556721319936,
  "created_at" : "2015-02-11 18:46:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/565572261718282240\/photo\/1",
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/1i6R0Vet81",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9lQz3vIgAAL7-k.jpg",
      "id_str" : "565572080276897792",
      "id" : 565572080276897792,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9lQz3vIgAAL7-k.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/1i6R0Vet81"
    } ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 23, 29 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/kICO4RphOx",
      "expanded_url" : "http:\/\/wh.gov\/ebola-response",
      "display_url" : "wh.gov\/ebola-response"
    } ]
  },
  "geo" : { },
  "id_str" : "565572261718282240",
  "text" : "Chart of the week: New #Ebola cases in West Africa are on the decline \u2192 http:\/\/t.co\/kICO4RphOx http:\/\/t.co\/1i6R0Vet81",
  "id" : 565572261718282240,
  "created_at" : "2015-02-11 18:05:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USAID",
      "screen_name" : "USAID",
      "indices" : [ 3, 9 ],
      "id_str" : "36683668",
      "id" : 36683668
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 28, 34 ]
    }, {
      "text" : "Liberia",
      "indices" : [ 49, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565564504378212352",
  "text" : "RT @USAID: Since September, #Ebola infections in #Liberia have dropped from 300+ new cases per week to around one per day. http:\/\/t.co\/e7wO\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/USAID\/status\/565561743867650050\/photo\/1",
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/e7wOE7ENqC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9lHaJgIgAAHW_a.jpg",
        "id_str" : "565561742764572672",
        "id" : 565561742764572672,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9lHaJgIgAAHW_a.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/e7wOE7ENqC"
      } ],
      "hashtags" : [ {
        "text" : "Ebola",
        "indices" : [ 17, 23 ]
      }, {
        "text" : "Liberia",
        "indices" : [ 38, 46 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "565561743867650050",
    "text" : "Since September, #Ebola infections in #Liberia have dropped from 300+ new cases per week to around one per day. http:\/\/t.co\/e7wOE7ENqC",
    "id" : 565561743867650050,
    "created_at" : "2015-02-11 17:23:22 +0000",
    "user" : {
      "name" : "USAID",
      "screen_name" : "USAID",
      "protected" : false,
      "id_str" : "36683668",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/717410574523564032\/ExeUofTG_normal.jpg",
      "id" : 36683668,
      "verified" : true
    }
  },
  "id" : 565564504378212352,
  "created_at" : "2015-02-11 17:34:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Cook",
      "screen_name" : "tim_cook",
      "indices" : [ 16, 25 ],
      "id_str" : "1636590253",
      "id" : 1636590253
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/FiaaDFeUER",
      "expanded_url" : "http:\/\/wapo.st\/1Aia4rr",
      "display_url" : "wapo.st\/1Aia4rr"
    } ]
  },
  "geo" : { },
  "id_str" : "565553823318806528",
  "text" : "RT @Podesta44: .@Tim_Cook: 130 MW solar power effort is Apple's \"biggest and boldest\" project to date \u2192 http:\/\/t.co\/FiaaDFeUER #ActOnClimate",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tim Cook",
        "screen_name" : "tim_cook",
        "indices" : [ 1, 10 ],
        "id_str" : "1636590253",
        "id" : 1636590253
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 112, 125 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/FiaaDFeUER",
        "expanded_url" : "http:\/\/wapo.st\/1Aia4rr",
        "display_url" : "wapo.st\/1Aia4rr"
      } ]
    },
    "geo" : { },
    "id_str" : "565538562397839360",
    "text" : ".@Tim_Cook: 130 MW solar power effort is Apple's \"biggest and boldest\" project to date \u2192 http:\/\/t.co\/FiaaDFeUER #ActOnClimate",
    "id" : 565538562397839360,
    "created_at" : "2015-02-11 15:51:15 +0000",
    "user" : {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "protected" : false,
      "id_str" : "2382117350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656551411145027584\/ArrSlGUP_normal.jpg",
      "id" : 2382117350,
      "verified" : true
    }
  },
  "id" : 565553823318806528,
  "created_at" : "2015-02-11 16:51:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ESL",
      "screen_name" : "ESL",
      "indices" : [ 12, 16 ],
      "id_str" : "16905329",
      "id" : 16905329
    }, {
      "name" : "Twitch",
      "screen_name" : "Twitch",
      "indices" : [ 21, 28 ],
      "id_str" : "309366491",
      "id" : 309366491
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 66, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/t0Xq2SVtLV",
      "expanded_url" : "http:\/\/go.wh.gov\/eSports",
      "display_url" : "go.wh.gov\/eSports"
    }, {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/sq5h6bu3EN",
      "expanded_url" : "http:\/\/youtu.be\/yXbxRp5bJVI",
      "display_url" : "youtu.be\/yXbxRp5bJVI"
    } ]
  },
  "geo" : { },
  "id_str" : "565541294005432320",
  "text" : "Calling all @ESL and @Twitch gamers: eSports athletes want you to #GetCovered by February 15 \u2192 http:\/\/t.co\/t0Xq2SVtLV http:\/\/t.co\/sq5h6bu3EN",
  "id" : 565541294005432320,
  "created_at" : "2015-02-11 16:02:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/565532867749371904\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/ojjcKMMIOv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9ks4OjIYAA8AAP.jpg",
      "id_str" : "565532572701450240",
      "id" : 565532572701450240,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9ks4OjIYAA8AAP.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/ojjcKMMIOv"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 66, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/rNzHK5zFEl",
      "expanded_url" : "http:\/\/go.wh.gov\/get-covered",
      "display_url" : "go.wh.gov\/get-covered"
    } ]
  },
  "geo" : { },
  "id_str" : "565532867749371904",
  "text" : "Don't wait: Just 4 days left to sign up for 2015 health coverage. #GetCovered by Feb. 15 \u2192 http:\/\/t.co\/rNzHK5zFEl http:\/\/t.co\/ojjcKMMIOv",
  "id" : 565532867749371904,
  "created_at" : "2015-02-11 15:28:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BuzzFeed News",
      "screen_name" : "BuzzFeedNews",
      "indices" : [ 3, 16 ],
      "id_str" : "1020058453",
      "id" : 1020058453
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/BuzzFeedNews\/status\/565280223512764417\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/n5xyeVCeBH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9hHXM-IgAI0ag4.jpg",
      "id_str" : "565280217179389954",
      "id" : 565280217179389954,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9hHXM-IgAI0ag4.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 660,
        "resize" : "fit",
        "w" : 990
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 660,
        "resize" : "fit",
        "w" : 990
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/n5xyeVCeBH"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/q63v2XmcP2",
      "expanded_url" : "http:\/\/www.buzzfeed.com\/bensmith\/obama-on-kayla-mueller-not-paying-ransom-is-as-tough-as-anyt?bftw&utm_term=4ldqpgc#4ldqpgc",
      "display_url" : "buzzfeed.com\/bensmith\/obama\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "565300094455775233",
  "text" : "RT @BuzzFeedNews: Obama On Kayla Mueller: Not Paying Ransom \u201CIs As Tough As Anything I Do\u201D http:\/\/t.co\/q63v2XmcP2 http:\/\/t.co\/n5xyeVCeBH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/BuzzFeedNews\/status\/565280223512764417\/photo\/1",
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/n5xyeVCeBH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9hHXM-IgAI0ag4.jpg",
        "id_str" : "565280217179389954",
        "id" : 565280217179389954,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9hHXM-IgAI0ag4.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 660,
          "resize" : "fit",
          "w" : 990
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 660,
          "resize" : "fit",
          "w" : 990
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/n5xyeVCeBH"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/q63v2XmcP2",
        "expanded_url" : "http:\/\/www.buzzfeed.com\/bensmith\/obama-on-kayla-mueller-not-paying-ransom-is-as-tough-as-anyt?bftw&utm_term=4ldqpgc#4ldqpgc",
        "display_url" : "buzzfeed.com\/bensmith\/obama\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "565280223512764417",
    "text" : "Obama On Kayla Mueller: Not Paying Ransom \u201CIs As Tough As Anything I Do\u201D http:\/\/t.co\/q63v2XmcP2 http:\/\/t.co\/n5xyeVCeBH",
    "id" : 565280223512764417,
    "created_at" : "2015-02-10 22:44:42 +0000",
    "user" : {
      "name" : "BuzzFeed News",
      "screen_name" : "BuzzFeedNews",
      "protected" : false,
      "id_str" : "1020058453",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796353157576138752\/H2xr-NkC_normal.jpg",
      "id" : 1020058453,
      "verified" : true
    }
  },
  "id" : 565300094455775233,
  "created_at" : "2015-02-11 00:03:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Naya Rivera Dorsey",
      "screen_name" : "NayaRivera",
      "indices" : [ 3, 14 ],
      "id_str" : "75206471",
      "id" : 75206471
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ItsOnUs",
      "indices" : [ 47, 55 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/wOUZGRkJE4",
      "expanded_url" : "http:\/\/ItsOnUs.org",
      "display_url" : "ItsOnUs.org"
    } ]
  },
  "geo" : { },
  "id_str" : "565285595875147779",
  "text" : "RT @NayaRivera: This is so important. Join the #ItsOnUs campaign and take the pledge to stop violence against women: http:\/\/t.co\/wOUZGRkJE4\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 124, 135 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ItsOnUs",
        "indices" : [ 31, 39 ]
      } ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/wOUZGRkJE4",
        "expanded_url" : "http:\/\/ItsOnUs.org",
        "display_url" : "ItsOnUs.org"
      } ]
    },
    "geo" : { },
    "id_str" : "565245285044346882",
    "text" : "This is so important. Join the #ItsOnUs campaign and take the pledge to stop violence against women: http:\/\/t.co\/wOUZGRkJE4 @WhiteHouse",
    "id" : 565245285044346882,
    "created_at" : "2015-02-10 20:25:52 +0000",
    "user" : {
      "name" : "Naya Rivera Dorsey",
      "screen_name" : "NayaRivera",
      "protected" : false,
      "id_str" : "75206471",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/781939572158496768\/Y7DEulxh_normal.jpg",
      "id" : 75206471,
      "verified" : true
    }
  },
  "id" : 565285595875147779,
  "created_at" : "2015-02-10 23:06:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sally Jewell",
      "screen_name" : "SecretaryJewell",
      "indices" : [ 3, 19 ],
      "id_str" : "1342861723",
      "id" : 1342861723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565266875446468609",
  "text" : "RT @SecretaryJewell: We need to break down barriers to success for Native youth. They are the future leaders of Indian Country &amp; beyond.SJ \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SecretaryJewell\/status\/565217015062102016\/photo\/1",
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/7hfIR3P9M2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9gN4UVCYAA19RS.jpg",
        "id_str" : "565217014415777792",
        "id" : 565217014415777792,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9gN4UVCYAA19RS.jpg",
        "sizes" : [ {
          "h" : 804,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 471,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1608,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 267,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/7hfIR3P9M2"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "565217015062102016",
    "text" : "We need to break down barriers to success for Native youth. They are the future leaders of Indian Country &amp; beyond.SJ http:\/\/t.co\/7hfIR3P9M2",
    "id" : 565217015062102016,
    "created_at" : "2015-02-10 18:33:32 +0000",
    "user" : {
      "name" : "Sally Jewell",
      "screen_name" : "SecretaryJewell",
      "protected" : false,
      "id_str" : "1342861723",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3525481506\/1ddf16c2cb47608803abe4dc7fc133fe_normal.jpeg",
      "id" : 1342861723,
      "verified" : true
    }
  },
  "id" : 565266875446468609,
  "created_at" : "2015-02-10 21:51:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/565263675372888064\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/70EnsTjQii",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9g4SfVIYAALb2O.jpg",
      "id_str" : "565263643533926400",
      "id" : 565263643533926400,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9g4SfVIYAALb2O.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/70EnsTjQii"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 105, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/rNzHK5i4MN",
      "expanded_url" : "http:\/\/go.wh.gov\/get-covered",
      "display_url" : "go.wh.gov\/get-covered"
    } ]
  },
  "geo" : { },
  "id_str" : "565263675372888064",
  "text" : "RT to spread the word: You only have 5 days to sign up for 2015 health coverage \u2192 http:\/\/t.co\/rNzHK5i4MN #GetCovered http:\/\/t.co\/70EnsTjQii",
  "id" : 565263675372888064,
  "created_at" : "2015-02-10 21:38:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "indices" : [ 3, 15 ],
      "id_str" : "15764644",
      "id" : 15764644
    }, {
      "name" : "House Republicans",
      "screen_name" : "HouseGOP",
      "indices" : [ 96, 105 ],
      "id_str" : "15207668",
      "id" : 15207668
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontShutDownOurSecurity",
      "indices" : [ 107, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565253266439954434",
  "text" : "RT @NancyPelosi: Keeping American families safe is the first responsibility of Congress. I urge @HouseGOP, #DontShutDownOurSecurity http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "House Republicans",
        "screen_name" : "HouseGOP",
        "indices" : [ 79, 88 ],
        "id_str" : "15207668",
        "id" : 15207668
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NancyPelosi\/status\/565236747760840706\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/ZumnP6F4Kq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9gf07VIcAAWtRx.jpg",
        "id_str" : "565236747374981120",
        "id" : 565236747374981120,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9gf07VIcAAWtRx.jpg",
        "sizes" : [ {
          "h" : 500,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/ZumnP6F4Kq"
      } ],
      "hashtags" : [ {
        "text" : "DontShutDownOurSecurity",
        "indices" : [ 90, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "565236747760840706",
    "text" : "Keeping American families safe is the first responsibility of Congress. I urge @HouseGOP, #DontShutDownOurSecurity http:\/\/t.co\/ZumnP6F4Kq",
    "id" : 565236747760840706,
    "created_at" : "2015-02-10 19:51:56 +0000",
    "user" : {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "protected" : false,
      "id_str" : "15764644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571313158510223360\/wnSl3yXF_normal.jpeg",
      "id" : 15764644,
      "verified" : true
    }
  },
  "id" : 565253266439954434,
  "created_at" : "2015-02-10 20:57:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joaquin Castro",
      "screen_name" : "JoaquinCastrotx",
      "indices" : [ 3, 19 ],
      "id_str" : "231510077",
      "id" : 231510077
    }, {
      "name" : "Homeland Security",
      "screen_name" : "DHSgov",
      "indices" : [ 84, 91 ],
      "id_str" : "15647676",
      "id" : 15647676
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontShutDownOurSecurity",
      "indices" : [ 112, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565238095726252033",
  "text" : "RT @JoaquinCastrotx: Congress shouldn\u2019t play with our nation\u2019s safety. We must fund @DHSgov and tell House GOP, #DontShutDownOurSecurity ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Homeland Security",
        "screen_name" : "DHSgov",
        "indices" : [ 63, 70 ],
        "id_str" : "15647676",
        "id" : 15647676
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JoaquinCastrotx\/status\/565230416517660672\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/gHqgHlGWBg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9gaEZ5IEAAlOT0.jpg",
        "id_str" : "565230416207286272",
        "id" : 565230416207286272,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9gaEZ5IEAAlOT0.jpg",
        "sizes" : [ {
          "h" : 500,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/gHqgHlGWBg"
      } ],
      "hashtags" : [ {
        "text" : "DontShutDownOurSecurity",
        "indices" : [ 91, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "565230416517660672",
    "text" : "Congress shouldn\u2019t play with our nation\u2019s safety. We must fund @DHSgov and tell House GOP, #DontShutDownOurSecurity http:\/\/t.co\/gHqgHlGWBg",
    "id" : 565230416517660672,
    "created_at" : "2015-02-10 19:26:47 +0000",
    "user" : {
      "name" : "Joaquin Castro",
      "screen_name" : "JoaquinCastrotx",
      "protected" : false,
      "id_str" : "231510077",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1268126174\/Joaquin_Castro_in_2008_normal.jpg",
      "id" : 231510077,
      "verified" : true
    }
  },
  "id" : 565238095726252033,
  "created_at" : "2015-02-10 19:57:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 3, 11 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 76, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/aNBIpz7M08",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "565234146428321792",
  "text" : "RT @DrBiden: You only have 5 days left to sign up for 2015 health coverage. #GetCovered at http:\/\/t.co\/aNBIpz7M08 by February 15. http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/565195534781005825\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/PcAP3t0Kf7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9f54t6CQAAxX8V.jpg",
        "id_str" : "565195031049289728",
        "id" : 565195031049289728,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9f54t6CQAAxX8V.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/PcAP3t0Kf7"
      } ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 63, 74 ]
      } ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/aNBIpz7M08",
        "expanded_url" : "http:\/\/HealthCare.gov",
        "display_url" : "HealthCare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "565215895891750912",
    "text" : "You only have 5 days left to sign up for 2015 health coverage. #GetCovered at http:\/\/t.co\/aNBIpz7M08 by February 15. http:\/\/t.co\/PcAP3t0Kf7",
    "id" : 565215895891750912,
    "created_at" : "2015-02-10 18:29:05 +0000",
    "user" : {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "protected" : false,
      "id_str" : "1281405877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608687663034474496\/wvzVG_yt_normal.jpg",
      "id" : 1281405877,
      "verified" : true
    }
  },
  "id" : 565234146428321792,
  "created_at" : "2015-02-10 19:41:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "indices" : [ 3, 16 ],
      "id_str" : "78138151",
      "id" : 78138151
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/lacasablanca\/status\/565217165494591488\/photo\/1",
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/xGhjRrsgK1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9gOA2YCMAAJsWK.jpg",
      "id_str" : "565217160994107392",
      "id" : 565217160994107392,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9gOA2YCMAAJsWK.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/xGhjRrsgK1"
    } ],
    "hashtags" : [ {
      "text" : "ImmigrationAction",
      "indices" : [ 74, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565218435991207938",
  "text" : "RT @lacasablanca: $3.8 billion boost for Illinois over 10 years thanks to #ImmigrationAction http:\/\/t.co\/xGhjRrsgK1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/lacasablanca\/status\/565217165494591488\/photo\/1",
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/xGhjRrsgK1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9gOA2YCMAAJsWK.jpg",
        "id_str" : "565217160994107392",
        "id" : 565217160994107392,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9gOA2YCMAAJsWK.jpg",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/xGhjRrsgK1"
      } ],
      "hashtags" : [ {
        "text" : "ImmigrationAction",
        "indices" : [ 56, 74 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "565217165494591488",
    "text" : "$3.8 billion boost for Illinois over 10 years thanks to #ImmigrationAction http:\/\/t.co\/xGhjRrsgK1",
    "id" : 565217165494591488,
    "created_at" : "2015-02-10 18:34:08 +0000",
    "user" : {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "protected" : false,
      "id_str" : "78138151",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616360382911754241\/4Tfqcfie_normal.png",
      "id" : 78138151,
      "verified" : true
    }
  },
  "id" : 565218435991207938,
  "created_at" : "2015-02-10 18:39:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/565210992632537089\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/3MKqgj1UVD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9gIT2bCcAAoq0N.jpg",
      "id_str" : "565210890354454528",
      "id" : 565210890354454528,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9gIT2bCcAAoq0N.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/3MKqgj1UVD"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 78, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/GNfbftrfo3",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "565210992632537089",
  "text" : "FACT: Nearly 8 in 10 people can get health coverage for less than $100\/month. #GetCovered at http:\/\/t.co\/GNfbftrfo3. http:\/\/t.co\/3MKqgj1UVD",
  "id" : 565210992632537089,
  "created_at" : "2015-02-10 18:09:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/565195534781005825\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/0QoPdznZ8u",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9f54t6CQAAxX8V.jpg",
      "id_str" : "565195031049289728",
      "id" : 565195031049289728,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9f54t6CQAAxX8V.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/0QoPdznZ8u"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 25, 36 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/rNzHK5zFEl",
      "expanded_url" : "http:\/\/go.wh.gov\/get-covered",
      "display_url" : "go.wh.gov\/get-covered"
    } ]
  },
  "geo" : { },
  "id_str" : "565195534781005825",
  "text" : "Don't wait: It's time to #GetCovered.\nJust 5 days left to sign up for 2015 health coverage \u2192 http:\/\/t.co\/rNzHK5zFEl http:\/\/t.co\/0QoPdznZ8u",
  "id" : 565195534781005825,
  "created_at" : "2015-02-10 17:08:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/565165722184081408\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/bqnFABLJcn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9ffKQFCAAAPKab.jpg",
      "id_str" : "565165645466042368",
      "id" : 565165645466042368,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9ffKQFCAAAPKab.jpg",
      "sizes" : [ {
        "h" : 522,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 173,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 527,
        "resize" : "fit",
        "w" : 1033
      }, {
        "h" : 306,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/bqnFABLJcn"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565169098095464448",
  "text" : "\"Kayla represents what is best about America, and expressed her deep pride in the freedoms that we...enjoy.\" \u2014Obama http:\/\/t.co\/bqnFABLJcn",
  "id" : 565169098095464448,
  "created_at" : "2015-02-10 15:23:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/565165722184081408\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/bqnFABLJcn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9ffKQFCAAAPKab.jpg",
      "id_str" : "565165645466042368",
      "id" : 565165645466042368,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9ffKQFCAAAPKab.jpg",
      "sizes" : [ {
        "h" : 522,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 173,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 527,
        "resize" : "fit",
        "w" : 1033
      }, {
        "h" : 306,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/bqnFABLJcn"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "565165722184081408",
  "text" : "\"The United States will find and bring to justice the terrorists who are responsible for Kayla\u2019s...death.\" \u2014Obama http:\/\/t.co\/bqnFABLJcn",
  "id" : 565165722184081408,
  "created_at" : "2015-02-10 15:09:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 51, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/rNzHK5zFEl",
      "expanded_url" : "http:\/\/go.wh.gov\/get-covered",
      "display_url" : "go.wh.gov\/get-covered"
    }, {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/pNVaDfV7DX",
      "expanded_url" : "http:\/\/vine.co\/v\/OUDxut9LXHq",
      "display_url" : "vine.co\/v\/OUDxut9LXHq"
    } ]
  },
  "geo" : { },
  "id_str" : "564967096606408704",
  "text" : "6 days left: If you don't have a 2015 health plan, #GetCovered by February 15 \u2192 http:\/\/t.co\/rNzHK5zFEl http:\/\/t.co\/pNVaDfV7DX",
  "id" : 564967096606408704,
  "created_at" : "2015-02-10 02:00:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sally Jewell",
      "screen_name" : "SecretaryJewell",
      "indices" : [ 3, 19 ],
      "id_str" : "1342861723",
      "id" : 1342861723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "564958730689974272",
  "text" : "RT @SecretaryJewell: In CA desert to flip the switch on largest solar project on federal public lands - 550 MW are powering 160k homes -SJ \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SecretaryJewell\/status\/564869676954812416\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/FH1kBZzt1Q",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9bR-l1CMAAgZgt.jpg",
        "id_str" : "564869676518223872",
        "id" : 564869676518223872,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9bR-l1CMAAgZgt.jpg",
        "sizes" : [ {
          "h" : 695,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 231,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 857,
          "resize" : "fit",
          "w" : 1262
        }, {
          "h" : 407,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/FH1kBZzt1Q"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "564869676954812416",
    "text" : "In CA desert to flip the switch on largest solar project on federal public lands - 550 MW are powering 160k homes -SJ http:\/\/t.co\/FH1kBZzt1Q",
    "id" : 564869676954812416,
    "created_at" : "2015-02-09 19:33:20 +0000",
    "user" : {
      "name" : "Sally Jewell",
      "screen_name" : "SecretaryJewell",
      "protected" : false,
      "id_str" : "1342861723",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3525481506\/1ddf16c2cb47608803abe4dc7fc133fe_normal.jpeg",
      "id" : 1342861723,
      "verified" : true
    }
  },
  "id" : 564958730689974272,
  "created_at" : "2015-02-10 01:27:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 117, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/9pf7yEQ7WP",
      "expanded_url" : "http:\/\/on.doi.gov\/1z1rUL3",
      "display_url" : "on.doi.gov\/1z1rUL3"
    } ]
  },
  "geo" : { },
  "id_str" : "564954621744275456",
  "text" : "RT @Interior: Desert Sunlight makes history as nation\u2019s largest solar project on public lands http:\/\/t.co\/9pf7yEQ7WP #ActOnClimate http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/564868164068978688\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/q9VwAaG99e",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9bQmhYIMAA9i5N.jpg",
        "id_str" : "564868163494752256",
        "id" : 564868163494752256,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9bQmhYIMAA9i5N.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/q9VwAaG99e"
      } ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 103, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/9pf7yEQ7WP",
        "expanded_url" : "http:\/\/on.doi.gov\/1z1rUL3",
        "display_url" : "on.doi.gov\/1z1rUL3"
      } ]
    },
    "geo" : { },
    "id_str" : "564868164068978688",
    "text" : "Desert Sunlight makes history as nation\u2019s largest solar project on public lands http:\/\/t.co\/9pf7yEQ7WP #ActOnClimate http:\/\/t.co\/q9VwAaG99e",
    "id" : 564868164068978688,
    "created_at" : "2015-02-09 19:27:19 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 564954621744275456,
  "created_at" : "2015-02-10 01:10:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Botticelli",
      "screen_name" : "Botticelli44",
      "indices" : [ 3, 16 ],
      "id_str" : "2382297056",
      "id" : 2382297056
    }, {
      "name" : "U.S. Drug Policy",
      "screen_name" : "ONDCP",
      "indices" : [ 74, 80 ],
      "id_str" : "15460572",
      "id" : 15460572
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RecoveryWorks",
      "indices" : [ 82, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/p5tjyhK1Vi",
      "expanded_url" : "http:\/\/wh.gov\/ib1cV",
      "display_url" : "wh.gov\/ib1cV"
    } ]
  },
  "geo" : { },
  "id_str" : "564949847430938624",
  "text" : "RT @Botticelli44: I am honored to announce my confirmation as Director of @ONDCP. #RecoveryWorks http:\/\/t.co\/p5tjyhK1Vi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "U.S. Drug Policy",
        "screen_name" : "ONDCP",
        "indices" : [ 56, 62 ],
        "id_str" : "15460572",
        "id" : 15460572
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RecoveryWorks",
        "indices" : [ 64, 78 ]
      } ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/p5tjyhK1Vi",
        "expanded_url" : "http:\/\/wh.gov\/ib1cV",
        "display_url" : "wh.gov\/ib1cV"
      } ]
    },
    "geo" : { },
    "id_str" : "564924711096684544",
    "text" : "I am honored to announce my confirmation as Director of @ONDCP. #RecoveryWorks http:\/\/t.co\/p5tjyhK1Vi",
    "id" : 564924711096684544,
    "created_at" : "2015-02-09 23:12:01 +0000",
    "user" : {
      "name" : "Michael Botticelli",
      "screen_name" : "Botticelli44",
      "protected" : false,
      "id_str" : "2382297056",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/789238935159312385\/z7RppzRN_normal.jpg",
      "id" : 2382297056,
      "verified" : true
    }
  },
  "id" : 564949847430938624,
  "created_at" : "2015-02-10 00:51:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Drug Policy",
      "screen_name" : "ONDCP",
      "indices" : [ 3, 9 ],
      "id_str" : "15460572",
      "id" : 15460572
    }, {
      "name" : "Michael Botticelli",
      "screen_name" : "Botticelli44",
      "indices" : [ 28, 41 ],
      "id_str" : "2382297056",
      "id" : 2382297056
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/H5oLtjKDvu",
      "expanded_url" : "http:\/\/wh.gov\/ib1cV",
      "display_url" : "wh.gov\/ib1cV"
    } ]
  },
  "geo" : { },
  "id_str" : "564949690253594624",
  "text" : "RT @ONDCP: Congratulations, @Botticelli44! Just confirmed as Director of National Drug Control Policy: http:\/\/t.co\/H5oLtjKDvu http:\/\/t.co\/9\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Michael Botticelli",
        "screen_name" : "Botticelli44",
        "indices" : [ 17, 30 ],
        "id_str" : "2382297056",
        "id" : 2382297056
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ONDCP\/status\/564926029173514240\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/92G72OLA9F",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9cFOsPCUAISkP-.jpg",
        "id_str" : "564926028208820226",
        "id" : 564926028208820226,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9cFOsPCUAISkP-.jpg",
        "sizes" : [ {
          "h" : 1362,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 681,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/92G72OLA9F"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/H5oLtjKDvu",
        "expanded_url" : "http:\/\/wh.gov\/ib1cV",
        "display_url" : "wh.gov\/ib1cV"
      } ]
    },
    "geo" : { },
    "id_str" : "564926029173514240",
    "text" : "Congratulations, @Botticelli44! Just confirmed as Director of National Drug Control Policy: http:\/\/t.co\/H5oLtjKDvu http:\/\/t.co\/92G72OLA9F",
    "id" : 564926029173514240,
    "created_at" : "2015-02-09 23:17:15 +0000",
    "user" : {
      "name" : "U.S. Drug Policy",
      "screen_name" : "ONDCP",
      "protected" : false,
      "id_str" : "15460572",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/446652455552430080\/t6umtSs5_normal.png",
      "id" : 15460572,
      "verified" : true
    }
  },
  "id" : 564949690253594624,
  "created_at" : "2015-02-10 00:51:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vox",
      "screen_name" : "voxdotcom",
      "indices" : [ 97, 107 ],
      "id_str" : "2347049341",
      "id" : 2347049341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/mWSzUBWiZw",
      "expanded_url" : "http:\/\/bit.ly\/16Fl2ec",
      "display_url" : "bit.ly\/16Fl2ec"
    } ]
  },
  "geo" : { },
  "id_str" : "564929327007936513",
  "text" : "\"When problems happen, they don't call Beijing. They don't call Moscow. They call us.\" \u2014Obama on @VoxDotCom: http:\/\/t.co\/mWSzUBWiZw",
  "id" : 564929327007936513,
  "created_at" : "2015-02-09 23:30:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vox",
      "screen_name" : "voxdotcom",
      "indices" : [ 35, 45 ],
      "id_str" : "2347049341",
      "id" : 2347049341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/JQXXsKWdCV",
      "expanded_url" : "http:\/\/youtu.be\/Icq60Uxd3As",
      "display_url" : "youtu.be\/Icq60Uxd3As"
    } ]
  },
  "geo" : { },
  "id_str" : "564914219892494336",
  "text" : "Watch President Obama talking with @VoxDotCom about the goals of his foreign policy: http:\/\/t.co\/JQXXsKWdCV",
  "id" : 564914219892494336,
  "created_at" : "2015-02-09 22:30:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vox",
      "screen_name" : "voxdotcom",
      "indices" : [ 39, 49 ],
      "id_str" : "2347049341",
      "id" : 2347049341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/D05duaMC3r",
      "expanded_url" : "http:\/\/youtu.be\/iY05U7GaU5I",
      "display_url" : "youtu.be\/iY05U7GaU5I"
    } ]
  },
  "geo" : { },
  "id_str" : "564899197300662272",
  "text" : "Check out President Obama talking with @VoxDotCom on how middle-class economics helps expand opportunity: http:\/\/t.co\/D05duaMC3r",
  "id" : 564899197300662272,
  "created_at" : "2015-02-09 21:30:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vox",
      "screen_name" : "voxdotcom",
      "indices" : [ 47, 57 ],
      "id_str" : "2347049341",
      "id" : 2347049341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/0O1b2zZwwf",
      "expanded_url" : "http:\/\/bit.ly\/1A5cpYc",
      "display_url" : "bit.ly\/1A5cpYc"
    } ]
  },
  "geo" : { },
  "id_str" : "564884051589210114",
  "text" : "Worth a read: President Obama's interview with @VoxDotCom on domestic and foreign policy \u2192 http:\/\/t.co\/0O1b2zZwwf",
  "id" : 564884051589210114,
  "created_at" : "2015-02-09 20:30:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vox",
      "screen_name" : "voxdotcom",
      "indices" : [ 3, 13 ],
      "id_str" : "2347049341",
      "id" : 2347049341
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/voxdotcom\/status\/564756520601001985\/photo\/1",
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/hOae2R2hJQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9ZrEC5CYAAIgw2.jpg",
      "id_str" : "564756520521326592",
      "id" : 564756520521326592,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9ZrEC5CYAAIgw2.jpg",
      "sizes" : [ {
        "h" : 422,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 563,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 563,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 239,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/hOae2R2hJQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/XpuDY41adT",
      "expanded_url" : "http:\/\/bit.ly\/1xWyr8m",
      "display_url" : "bit.ly\/1xWyr8m"
    } ]
  },
  "geo" : { },
  "id_str" : "564880283179425792",
  "text" : "RT @voxdotcom: President Obama on American leadership in the world: http:\/\/t.co\/XpuDY41adT http:\/\/t.co\/hOae2R2hJQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/voxdotcom\/status\/564756520601001985\/photo\/1",
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/hOae2R2hJQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9ZrEC5CYAAIgw2.jpg",
        "id_str" : "564756520521326592",
        "id" : 564756520521326592,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9ZrEC5CYAAIgw2.jpg",
        "sizes" : [ {
          "h" : 422,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 563,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 563,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 239,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/hOae2R2hJQ"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 75 ],
        "url" : "http:\/\/t.co\/XpuDY41adT",
        "expanded_url" : "http:\/\/bit.ly\/1xWyr8m",
        "display_url" : "bit.ly\/1xWyr8m"
      } ]
    },
    "geo" : { },
    "id_str" : "564756520601001985",
    "text" : "President Obama on American leadership in the world: http:\/\/t.co\/XpuDY41adT http:\/\/t.co\/hOae2R2hJQ",
    "id" : 564756520601001985,
    "created_at" : "2015-02-09 12:03:41 +0000",
    "user" : {
      "name" : "Vox",
      "screen_name" : "voxdotcom",
      "protected" : false,
      "id_str" : "2347049341",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/442785905246347265\/v6W3UuIL_normal.jpeg",
      "id" : 2347049341,
      "verified" : true
    }
  },
  "id" : 564880283179425792,
  "created_at" : "2015-02-09 20:15:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "564834504406102016",
  "text" : "\"In a time when conflicts around the world sometimes seem intractable...Germany\u2019s story gives us hope\" \u2014Obama on 70 years since WWII's end",
  "id" : 564834504406102016,
  "created_at" : "2015-02-09 17:13:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "564833037968355328",
  "text" : "\"Two issues in particular that dominated our workday...Russia\u2019s aggression against Ukraine and the international fight against ISIL.\" \u2014Obama",
  "id" : 564833037968355328,
  "created_at" : "2015-02-09 17:07:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "564832302165786624",
  "text" : "\"This is my first opportunity to publicly congratulate Angela and Germany on their fourth World Cup title.\" \u2014Obama to Chancellor Merkel",
  "id" : 564832302165786624,
  "created_at" : "2015-02-09 17:04:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/AuZXN4JN3W",
      "expanded_url" : "http:\/\/go.wh.gov\/g8opfD",
      "display_url" : "go.wh.gov\/g8opfD"
    } ]
  },
  "geo" : { },
  "id_str" : "564820510060457984",
  "text" : "Tune in at 11:40am ET: President Obama holds a press conference with German Chancellor Angela Merkel \u2192 http:\/\/t.co\/AuZXN4JN3W",
  "id" : 564820510060457984,
  "created_at" : "2015-02-09 16:17:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ItsOnUs",
      "indices" : [ 1, 9 ]
    }, {
      "text" : "GRAMMYs",
      "indices" : [ 101, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/xTBvqbOrDd",
      "expanded_url" : "http:\/\/go.wh.gov\/GRAMMYs",
      "display_url" : "go.wh.gov\/GRAMMYs"
    } ]
  },
  "geo" : { },
  "id_str" : "564634872161906688",
  "text" : "\"#ItsOnUs \u2013 all of us \u2013 to create a culture where violence isn\u2019t tolerated.\" \u2014President Obama on the #GRAMMYs. http:\/\/t.co\/xTBvqbOrDd",
  "id" : 564634872161906688,
  "created_at" : "2015-02-09 04:00:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ItsOnUs",
      "indices" : [ 9, 17 ]
    }, {
      "text" : "GRAMMYs",
      "indices" : [ 125, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/7aGUmPQNTW",
      "expanded_url" : "http:\/\/ItsOnUs.org",
      "display_url" : "ItsOnUs.org"
    }, {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/xTBvqc631N",
      "expanded_url" : "http:\/\/go.wh.gov\/GRAMMYs",
      "display_url" : "go.wh.gov\/GRAMMYs"
    } ]
  },
  "geo" : { },
  "id_str" : "564616458567946240",
  "text" : "Join the #ItsOnUs campaign to stop violence against women. Take the pledge at http:\/\/t.co\/7aGUmPQNTW. http:\/\/t.co\/xTBvqc631N #GRAMMYs",
  "id" : 564616458567946240,
  "created_at" : "2015-02-09 02:47:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GRAMMYs",
      "indices" : [ 105, 113 ]
    }, {
      "text" : "ItsOnUs",
      "indices" : [ 114, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/xTBvqc631N",
      "expanded_url" : "http:\/\/go.wh.gov\/GRAMMYs",
      "display_url" : "go.wh.gov\/GRAMMYs"
    } ]
  },
  "geo" : { },
  "id_str" : "564616003615997952",
  "text" : "All of us, in our own lives, have the power to set an example.\u201D \u2014President Obama: http:\/\/t.co\/xTBvqc631N #GRAMMYs #ItsOnUs",
  "id" : 564616003615997952,
  "created_at" : "2015-02-09 02:45:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GRAMMYs",
      "indices" : [ 118, 126 ]
    }, {
      "text" : "ItsOnUs",
      "indices" : [ 127, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/xTBvqc631N",
      "expanded_url" : "http:\/\/go.wh.gov\/GRAMMYs",
      "display_url" : "go.wh.gov\/GRAMMYs"
    } ]
  },
  "geo" : { },
  "id_str" : "564615869146619905",
  "text" : "\"We can change our culture for the better by ending violence against women and girls.\" \u2014Obama: http:\/\/t.co\/xTBvqc631N #GRAMMYs #ItsOnUs",
  "id" : 564615869146619905,
  "created_at" : "2015-02-09 02:44:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/raDblxaHzX",
      "expanded_url" : "http:\/\/go.wh.gov\/yTcn1o",
      "display_url" : "go.wh.gov\/yTcn1o"
    } ]
  },
  "geo" : { },
  "id_str" : "564530420083982336",
  "text" : "\"While we\u2019ve come a long way, we\u2019ve got more work to do to make sure...our recovery reaches more Americans\" \u2014Obama: http:\/\/t.co\/raDblxaHzX",
  "id" : 564530420083982336,
  "created_at" : "2015-02-08 21:05:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/564521824063483904\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/xNFSOoin1J",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9WVmP6CAAAfUeR.png",
      "id_str" : "564521812642365440",
      "id" : 564521812642365440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9WVmP6CAAAfUeR.png",
      "sizes" : [ {
        "h" : 485,
        "resize" : "fit",
        "w" : 672
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 485,
        "resize" : "fit",
        "w" : 672
      }, {
        "h" : 245,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 433,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/xNFSOoin1J"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "564521824063483904",
  "text" : "\"Last night, America lost not just a coaching legend but a gentleman and a citizen.\" \u2014President Obama on Dean Smith: http:\/\/t.co\/xNFSOoin1J",
  "id" : 564521824063483904,
  "created_at" : "2015-02-08 20:31:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/raDblxaHzX",
      "expanded_url" : "http:\/\/go.wh.gov\/yTcn1o",
      "display_url" : "go.wh.gov\/yTcn1o"
    } ]
  },
  "geo" : { },
  "id_str" : "564499025441742849",
  "text" : "\"We should stop refighting old battles, and start working together to help you succeed in the new economy.\" \u2014Obama: http:\/\/t.co\/raDblxaHzX",
  "id" : 564499025441742849,
  "created_at" : "2015-02-08 19:00:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brandon Stanton",
      "screen_name" : "humansofny",
      "indices" : [ 92, 103 ],
      "id_str" : "237548529",
      "id" : 237548529
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/chR6YF6t6c",
      "expanded_url" : "http:\/\/go.wh.gov\/Q3vCXn",
      "display_url" : "go.wh.gov\/Q3vCXn"
    } ]
  },
  "geo" : { },
  "id_str" : "564485857600475140",
  "text" : "\"Who has been the biggest influence in your life?\" \u2014Vidal to President Obama. Go inside the @humansofny visit: http:\/\/t.co\/chR6YF6t6c",
  "id" : 564485857600475140,
  "created_at" : "2015-02-08 18:08:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/raDblxaHzX",
      "expanded_url" : "http:\/\/go.wh.gov\/yTcn1o",
      "display_url" : "go.wh.gov\/yTcn1o"
    } ]
  },
  "geo" : { },
  "id_str" : "564467488633544704",
  "text" : "\"This country does best when everyone gets their fair shot.\" \u2014President Obama in his weekly address: http:\/\/t.co\/raDblxaHzX",
  "id" : 564467488633544704,
  "created_at" : "2015-02-08 16:55:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/raDblxaHzX",
      "expanded_url" : "http:\/\/go.wh.gov\/yTcn1o",
      "display_url" : "go.wh.gov\/yTcn1o"
    } ]
  },
  "geo" : { },
  "id_str" : "564174351524581376",
  "text" : "\"The single most hopeful sign for middle class families\u2014wages are rising again.\" \u2014President Obama: http:\/\/t.co\/raDblxaHzX",
  "id" : 564174351524581376,
  "created_at" : "2015-02-07 21:30:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/raDblxaHzX",
      "expanded_url" : "http:\/\/go.wh.gov\/yTcn1o",
      "display_url" : "go.wh.gov\/yTcn1o"
    } ]
  },
  "geo" : { },
  "id_str" : "564151727499132928",
  "text" : "\"In 2014, our economy created more than 3.1 million jobs...the best year for job growth since the late 1990s\" \u2014Obama: http:\/\/t.co\/raDblxaHzX",
  "id" : 564151727499132928,
  "created_at" : "2015-02-07 20:00:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/563718670342303744\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/ywMXtbaZOs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9K3ecwCYAATkAm.jpg",
      "id_str" : "563714637116366848",
      "id" : 563714637116366848,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9K3ecwCYAATkAm.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ywMXtbaZOs"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/raDblxaHzX",
      "expanded_url" : "http:\/\/go.wh.gov\/yTcn1o",
      "display_url" : "go.wh.gov\/yTcn1o"
    } ]
  },
  "geo" : { },
  "id_str" : "564135551884730368",
  "text" : "\"Last month, America\u2019s businesses added another 267,000 jobs.\" \u2014President Obama: http:\/\/t.co\/raDblxaHzX http:\/\/t.co\/ywMXtbaZOs",
  "id" : 564135551884730368,
  "created_at" : "2015-02-07 18:56:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brandon Stanton",
      "screen_name" : "humansofny",
      "indices" : [ 49, 60 ],
      "id_str" : "237548529",
      "id" : 237548529
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/zshoTvqSG4",
      "expanded_url" : "http:\/\/youtu.be\/8PapL7XlTKY",
      "display_url" : "youtu.be\/8PapL7XlTKY"
    } ]
  },
  "geo" : { },
  "id_str" : "564108768221626370",
  "text" : "Go behind the scenes with Vidal and Ms. Lopez of @HumansOfNY as they meet President Obama in the Oval Office \u2192 http:\/\/t.co\/zshoTvqSG4",
  "id" : 564108768221626370,
  "created_at" : "2015-02-07 17:09:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brandon Stanton",
      "screen_name" : "humansofny",
      "indices" : [ 3, 14 ],
      "id_str" : "237548529",
      "id" : 237548529
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/humansofny\/status\/563751882087075841\/photo\/1",
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/0A34GeQEzQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9LZWWHCYAAszn2.png",
      "id_str" : "563751881290178560",
      "id" : 563751881290178560,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9LZWWHCYAAszn2.png",
      "sizes" : [ {
        "h" : 484,
        "resize" : "fit",
        "w" : 495
      }, {
        "h" : 484,
        "resize" : "fit",
        "w" : 495
      }, {
        "h" : 332,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 484,
        "resize" : "fit",
        "w" : 495
      } ],
      "display_url" : "pic.twitter.com\/0A34GeQEzQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "563812231305895936",
  "text" : "RT @humansofny: \u201CYou don\u2019t do things alone. Nobody does things alone. Everybody always needs support.\" http:\/\/t.co\/0A34GeQEzQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/humansofny\/status\/563751882087075841\/photo\/1",
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/0A34GeQEzQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9LZWWHCYAAszn2.png",
        "id_str" : "563751881290178560",
        "id" : 563751881290178560,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9LZWWHCYAAszn2.png",
        "sizes" : [ {
          "h" : 484,
          "resize" : "fit",
          "w" : 495
        }, {
          "h" : 484,
          "resize" : "fit",
          "w" : 495
        }, {
          "h" : 332,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 484,
          "resize" : "fit",
          "w" : 495
        } ],
        "display_url" : "pic.twitter.com\/0A34GeQEzQ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "563751882087075841",
    "text" : "\u201CYou don\u2019t do things alone. Nobody does things alone. Everybody always needs support.\" http:\/\/t.co\/0A34GeQEzQ",
    "id" : 563751882087075841,
    "created_at" : "2015-02-06 17:31:37 +0000",
    "user" : {
      "name" : "Brandon Stanton",
      "screen_name" : "humansofny",
      "protected" : false,
      "id_str" : "237548529",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/442100778639974400\/Zj7Hfan__normal.jpeg",
      "id" : 237548529,
      "verified" : true
    }
  },
  "id" : 563812231305895936,
  "created_at" : "2015-02-06 21:31:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ivy Tech",
      "screen_name" : "IvyTechCC",
      "indices" : [ 120, 130 ],
      "id_str" : "20565591",
      "id" : 20565591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "563797919984123905",
  "text" : "\u201CMy number one priority is to make sure that the American people\u2019s wages and incomes are going up.\u201D \u2014President Obama at @IvyTechCC",
  "id" : 563797919984123905,
  "created_at" : "2015-02-06 20:34:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/563793781388877824\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/jxsctAHG3O",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9L_WVpCMAAUOLj.jpg",
      "id_str" : "563793662606192640",
      "id" : 563793662606192640,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9L_WVpCMAAUOLj.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/jxsctAHG3O"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "563793781388877824",
  "text" : "\u201CWe want to reward people who are making the effort\u201D \u2014Obama on making community college free for responsible students http:\/\/t.co\/jxsctAHG3O",
  "id" : 563793781388877824,
  "created_at" : "2015-02-06 20:18:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ivy Tech",
      "screen_name" : "IvyTechCC",
      "indices" : [ 128, 138 ],
      "id_str" : "20565591",
      "id" : 20565591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "563792810445258752",
  "text" : "\u201CPolitics is not some sideshow in Washington\u2026it\u2019s how we together\u2014as a community\u2014make decisions about our priorities\u201D \u2014Obama at @IvyTechCC",
  "id" : 563792810445258752,
  "created_at" : "2015-02-06 20:14:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/563791585163214849\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/CpQBLE4XlM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9L6M86CQAAB7_U.png",
      "id_str" : "563788003789651968",
      "id" : 563788003789651968,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9L6M86CQAAB7_U.png",
      "sizes" : [ {
        "h" : 524,
        "resize" : "fit",
        "w" : 936
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 190,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 336,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 524,
        "resize" : "fit",
        "w" : 936
      } ],
      "display_url" : "pic.twitter.com\/CpQBLE4XlM"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/gENnjpUlW8",
      "expanded_url" : "http:\/\/go.wh.gov\/MBK",
      "display_url" : "go.wh.gov\/MBK"
    } ]
  },
  "geo" : { },
  "id_str" : "563791585163214849",
  "text" : "\u201CWe have to have an affirmative agenda to make sure young people feel hope.\u201D \u2014President Obama: http:\/\/t.co\/gENnjpUlW8 http:\/\/t.co\/CpQBLE4XlM",
  "id" : 563791585163214849,
  "created_at" : "2015-02-06 20:09:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/ZkUhG1S1sK",
      "expanded_url" : "http:\/\/go.wh.gov\/2016budget",
      "display_url" : "go.wh.gov\/2016budget"
    } ]
  },
  "geo" : { },
  "id_str" : "563786898926104576",
  "text" : "\"Let\u2019s close loopholes and make it more attractive for businesses to invest in America\" \u2014President Obama: http:\/\/t.co\/ZkUhG1S1sK",
  "id" : 563786898926104576,
  "created_at" : "2015-02-06 19:50:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/563786138230337537\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/KCpTAetOk5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9L4epBCYAAUYiO.jpg",
      "id_str" : "563786108664700928",
      "id" : 563786108664700928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9L4epBCYAAUYiO.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/KCpTAetOk5"
    } ],
    "hashtags" : [ {
      "text" : "FreeCommunityCollege",
      "indices" : [ 78, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "563786138230337537",
  "text" : "\"It shouldn\u2019t matter how much money your folks make.\" \u2014President Obama on his #FreeCommunityCollege proposal http:\/\/t.co\/KCpTAetOk5",
  "id" : 563786138230337537,
  "created_at" : "2015-02-06 19:47:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/563785744993382402\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/TkfQ7LiCyx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9L39E4CcAAVNck.jpg",
      "id_str" : "563785532027596800",
      "id" : 563785532027596800,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9L39E4CcAAVNck.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/TkfQ7LiCyx"
    } ],
    "hashtags" : [ {
      "text" : "FreeCommunityCollege",
      "indices" : [ 91, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "563785744993382402",
  "text" : "\"My budget makes two years of community college free for every responsible student\" \u2014Obama #FreeCommunityCollege http:\/\/t.co\/TkfQ7LiCyx",
  "id" : 563785744993382402,
  "created_at" : "2015-02-06 19:46:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Ivy Tech",
      "screen_name" : "IvyTechCC",
      "indices" : [ 106, 116 ],
      "id_str" : "20565591",
      "id" : 20565591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/mdLgdYKnIq",
      "expanded_url" : "http:\/\/go.wh.gov\/jLZs8Y",
      "display_url" : "go.wh.gov\/jLZs8Y"
    } ]
  },
  "geo" : { },
  "id_str" : "563785462188220418",
  "text" : "RT @WHLive: \"I want to make sure that America is a place where hard work is rewarded\" \u2014President Obama at @IvyTechCC: http:\/\/t.co\/mdLgdYKnIq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ivy Tech",
        "screen_name" : "IvyTechCC",
        "indices" : [ 94, 104 ],
        "id_str" : "20565591",
        "id" : 20565591
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/mdLgdYKnIq",
        "expanded_url" : "http:\/\/go.wh.gov\/jLZs8Y",
        "display_url" : "go.wh.gov\/jLZs8Y"
      } ]
    },
    "geo" : { },
    "id_str" : "563785399265292288",
    "text" : "\"I want to make sure that America is a place where hard work is rewarded\" \u2014President Obama at @IvyTechCC: http:\/\/t.co\/mdLgdYKnIq",
    "id" : 563785399265292288,
    "created_at" : "2015-02-06 19:44:48 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 563785462188220418,
  "created_at" : "2015-02-06 19:45:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ivy Tech",
      "screen_name" : "IvyTechCC",
      "indices" : [ 82, 92 ],
      "id_str" : "20565591",
      "id" : 20565591
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/563784207558651904\/photo\/1",
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/nJdHbeZfkb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9L2vU7CQAAJ6lT.jpg",
      "id_str" : "563784196305338368",
      "id" : 563784196305338368,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9L2vU7CQAAJ6lT.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/nJdHbeZfkb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "563784207558651904",
  "text" : "\"Our dropout rates are down and our graduation rates are up.\" \u2014President Obama at @IvyTechCC http:\/\/t.co\/nJdHbeZfkb",
  "id" : 563784207558651904,
  "created_at" : "2015-02-06 19:40:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ivy Tech",
      "screen_name" : "IvyTechCC",
      "indices" : [ 50, 60 ],
      "id_str" : "20565591",
      "id" : 20565591
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/563784068668485632\/photo\/1",
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/wS6gDHDDSb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9L2m__CAAAYk-e.jpg",
      "id_str" : "563784053246001152",
      "id" : 563784053246001152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9L2m__CAAAYk-e.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/wS6gDHDDSb"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/P2wQCJUgPd",
      "expanded_url" : "http:\/\/go.wh.gov\/jLZs8Y",
      "display_url" : "go.wh.gov\/jLZs8Y"
    } ]
  },
  "geo" : { },
  "id_str" : "563784068668485632",
  "text" : "\"Our deficits are shrinking.\" \u2014President Obama at @IvyTechCC: http:\/\/t.co\/P2wQCJUgPd http:\/\/t.co\/wS6gDHDDSb",
  "id" : 563784068668485632,
  "created_at" : "2015-02-06 19:39:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "563783907292614656",
  "text" : "\"In 2014, our economy created more than 3.1 million jobs\u2014and that\u2019s the best year for job growth since the late 1990s.\" \u2014President Obama",
  "id" : 563783907292614656,
  "created_at" : "2015-02-06 19:38:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/563783783262855170\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/M0o1SBZgbP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9L2SIGCQAEcG_N.jpg",
      "id_str" : "563783694645608449",
      "id" : 563783694645608449,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9L2SIGCQAEcG_N.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/M0o1SBZgbP"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "563783783262855170",
  "text" : "\"This morning, we found out that America\u2019s businesses added another 267,000 jobs\" \u2014President Obama http:\/\/t.co\/M0o1SBZgbP",
  "id" : 563783783262855170,
  "created_at" : "2015-02-06 19:38:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ivy Tech",
      "screen_name" : "IvyTechCC",
      "indices" : [ 101, 111 ],
      "id_str" : "20565591",
      "id" : 20565591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/P2wQCJUgPd",
      "expanded_url" : "http:\/\/go.wh.gov\/jLZs8Y",
      "display_url" : "go.wh.gov\/jLZs8Y"
    } ]
  },
  "geo" : { },
  "id_str" : "563783561946218496",
  "text" : "\"There is no liberal America or conservative America, there's a United States of America.\" \u2014Obama at @IvyTechCC: http:\/\/t.co\/P2wQCJUgPd",
  "id" : 563783561946218496,
  "created_at" : "2015-02-06 19:37:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ivy Tech",
      "screen_name" : "IvyTechCC",
      "indices" : [ 38, 48 ],
      "id_str" : "20565591",
      "id" : 20565591
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FreeCommunityCollege",
      "indices" : [ 56, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/P2wQCJUgPd",
      "expanded_url" : "http:\/\/go.wh.gov\/jLZs8Y",
      "display_url" : "go.wh.gov\/jLZs8Y"
    } ]
  },
  "geo" : { },
  "id_str" : "563782395548012544",
  "text" : "Watch live: President Obama speaks at @IvyTechCC on his #FreeCommunityCollege proposal before answering questions \u2192 http:\/\/t.co\/P2wQCJUgPd",
  "id" : 563782395548012544,
  "created_at" : "2015-02-06 19:32:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/563767779270983681\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/qEIKAC575N",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9LnkO7CMAA7V19.jpg",
      "id_str" : "563767513041743872",
      "id" : 563767513041743872,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9LnkO7CMAA7V19.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/qEIKAC575N"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/rNzHK5zFEl",
      "expanded_url" : "http:\/\/go.wh.gov\/get-covered",
      "display_url" : "go.wh.gov\/get-covered"
    } ]
  },
  "geo" : { },
  "id_str" : "563767779270983681",
  "text" : "Make sure your friends know: There are just 9 days left to sign up for 2015 health coverage \u2192 http:\/\/t.co\/rNzHK5zFEl http:\/\/t.co\/qEIKAC575N",
  "id" : 563767779270983681,
  "created_at" : "2015-02-06 18:34:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/563757371969638402\/photo\/1",
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/1Fno2KTpDB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9LeO6UCQAAwPdX.jpg",
      "id_str" : "563757251127558144",
      "id" : 563757251127558144,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9LeO6UCQAAwPdX.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/1Fno2KTpDB"
    } ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 81, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/2PPbsJTXbJ",
      "expanded_url" : "http:\/\/go.wh.gov\/exports",
      "display_url" : "go.wh.gov\/exports"
    } ]
  },
  "geo" : { },
  "id_str" : "563757371969638402",
  "text" : "More American exports = more higher-paying American jobs: http:\/\/t.co\/2PPbsJTXbJ #MadeInAmerica http:\/\/t.co\/1Fno2KTpDB",
  "id" : 563757371969638402,
  "created_at" : "2015-02-06 17:53:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/563740936769794048\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/Kp6ygaED5p",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9LPNF7CIAIjmKQ.jpg",
      "id_str" : "563740727209762818",
      "id" : 563740727209762818,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9LPNF7CIAIjmKQ.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Kp6ygaED5p"
    } ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 95, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/2PPbsJTXbJ",
      "expanded_url" : "http:\/\/go.wh.gov\/exports",
      "display_url" : "go.wh.gov\/exports"
    } ]
  },
  "geo" : { },
  "id_str" : "563740936769794048",
  "text" : "America is exporting more than ever before.\nThat means more U.S. jobs \u2192 http:\/\/t.co\/2PPbsJTXbJ #MadeInAmerica http:\/\/t.co\/Kp6ygaED5p",
  "id" : 563740936769794048,
  "created_at" : "2015-02-06 16:48:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brandon Stanton",
      "screen_name" : "humansofny",
      "indices" : [ 3, 14 ],
      "id_str" : "237548529",
      "id" : 237548529
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "563732704642887681",
  "text" : "RT @humansofny: On January 19th, I met a young man on the street named Vidal, and I asked him to tell me about the person who...\" http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/humansofny\/status\/563484070751920129\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/Rub24AAO4p",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9HlxpzCIAAGFYB.png",
        "id_str" : "563484069594275840",
        "id" : 563484069594275840,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9HlxpzCIAAGFYB.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 588,
          "resize" : "fit",
          "w" : 496
        }, {
          "h" : 588,
          "resize" : "fit",
          "w" : 496
        }, {
          "h" : 403,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 588,
          "resize" : "fit",
          "w" : 496
        } ],
        "display_url" : "pic.twitter.com\/Rub24AAO4p"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "563484070751920129",
    "text" : "On January 19th, I met a young man on the street named Vidal, and I asked him to tell me about the person who...\" http:\/\/t.co\/Rub24AAO4p",
    "id" : 563484070751920129,
    "created_at" : "2015-02-05 23:47:26 +0000",
    "user" : {
      "name" : "Brandon Stanton",
      "screen_name" : "humansofny",
      "protected" : false,
      "id_str" : "237548529",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/442100778639974400\/Zj7Hfan__normal.jpeg",
      "id" : 237548529,
      "verified" : true
    }
  },
  "id" : 563732704642887681,
  "created_at" : "2015-02-06 16:15:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/563724847906164736\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/7hdqfE4ovP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9LAwpfCEAAursd.jpg",
      "id_str" : "563724845376999424",
      "id" : 563724845376999424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9LAwpfCEAAursd.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/7hdqfE4ovP"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "563724847906164736",
  "text" : "Our businesses have added:\n11.8 million jobs over 59 months \u2713\n3.1 million in the last year \u2713\n267,000 last month \u2713 http:\/\/t.co\/7hdqfE4ovP",
  "id" : 563724847906164736,
  "created_at" : "2015-02-06 15:44:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/563718670342303744\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/ywMXtbaZOs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9K3ecwCYAATkAm.jpg",
      "id_str" : "563714637116366848",
      "id" : 563714637116366848,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9K3ecwCYAATkAm.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ywMXtbaZOs"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/iDvoTbRtFh",
      "expanded_url" : "http:\/\/go.wh.gov\/cdJiVR",
      "display_url" : "go.wh.gov\/cdJiVR"
    } ]
  },
  "geo" : { },
  "id_str" : "563718670342303744",
  "text" : "Good news: Our businesses added 267,000 jobs last month and 3.1 million over the last year \u2192 http:\/\/t.co\/iDvoTbRtFh http:\/\/t.co\/ywMXtbaZOs",
  "id" : 563718670342303744,
  "created_at" : "2015-02-06 15:19:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brandon Stanton",
      "screen_name" : "humansofny",
      "indices" : [ 53, 64 ],
      "id_str" : "237548529",
      "id" : 237548529
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/563456123454246912\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/7uNiWa7BgA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9HMLQYCEAALnqU.jpg",
      "id_str" : "563455922144415744",
      "id" : 563455922144415744,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9HMLQYCEAALnqU.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/7uNiWa7BgA"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/4PvoSQhUF8",
      "expanded_url" : "http:\/\/on.fb.me\/16lHIQN",
      "display_url" : "on.fb.me\/16lHIQN"
    } ]
  },
  "geo" : { },
  "id_str" : "563456123454246912",
  "text" : "President Obama just met with Vidal and Ms. Lopez of @HumansOfNY.\nRead their incredible story: http:\/\/t.co\/4PvoSQhUF8 http:\/\/t.co\/7uNiWa7BgA",
  "id" : 563456123454246912,
  "created_at" : "2015-02-05 21:56:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/563448630585995266\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/13soT5zmAg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9HFTpqCIAADFPR.jpg",
      "id_str" : "563448369788362752",
      "id" : 563448369788362752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9HFTpqCIAADFPR.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/13soT5zmAg"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/whYv7XT6cE",
      "expanded_url" : "http:\/\/go.wh.gov\/VRbAai",
      "display_url" : "go.wh.gov\/VRbAai"
    } ]
  },
  "geo" : { },
  "id_str" : "563448630585995266",
  "text" : "\"Whatever our beliefs...we must seek to be instruments of peace\" \u2014President Obama: http:\/\/t.co\/whYv7XT6cE http:\/\/t.co\/13soT5zmAg",
  "id" : 563448630585995266,
  "created_at" : "2015-02-05 21:26:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 40, 51 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/VP\/status\/563432467692933120\/photo\/1",
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/UfSUqkL25E",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9G213FCQAAy0p7.jpg",
      "id_str" : "563432464832413696",
      "id" : 563432464832413696,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9G213FCQAAy0p7.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 477
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 513,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 477
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 477
      } ],
      "display_url" : "pic.twitter.com\/UfSUqkL25E"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "563434780352450560",
  "text" : "RT @VP: Good luck and thanks a million, @pfeiffer44. See you at the Charcoal Pit in Wilmington. http:\/\/t.co\/UfSUqkL25E",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "pu iezov uf",
        "screen_name" : "pfeiffer44",
        "indices" : [ 32, 43 ],
        "id_str" : "3187888216",
        "id" : 3187888216
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/563432467692933120\/photo\/1",
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/UfSUqkL25E",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9G213FCQAAy0p7.jpg",
        "id_str" : "563432464832413696",
        "id" : 563432464832413696,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9G213FCQAAy0p7.jpg",
        "sizes" : [ {
          "h" : 720,
          "resize" : "fit",
          "w" : 477
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 513,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 477
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 477
        } ],
        "display_url" : "pic.twitter.com\/UfSUqkL25E"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "563432467692933120",
    "text" : "Good luck and thanks a million, @pfeiffer44. See you at the Charcoal Pit in Wilmington. http:\/\/t.co\/UfSUqkL25E",
    "id" : 563432467692933120,
    "created_at" : "2015-02-05 20:22:23 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 563434780352450560,
  "created_at" : "2015-02-05 20:31:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "indices" : [ 3, 12 ],
      "id_str" : "1604366701",
      "id" : 1604366701
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LeadOnLeave",
      "indices" : [ 104, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "563420428115263488",
  "text" : "RT @LaborSec: 22 years ago Pres. Clinton signed FMLA into law. Now, it's time to take the next step and #LeadOnLeave. http:\/\/t.co\/3Q6nmgnYj\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LeadOnLeave",
        "indices" : [ 90, 102 ]
      }, {
        "text" : "FMLA22",
        "indices" : [ 127, 134 ]
      } ],
      "urls" : [ {
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/3Q6nmgnYje",
        "expanded_url" : "http:\/\/youtu.be\/9bDdaO6AINo",
        "display_url" : "youtu.be\/9bDdaO6AINo"
      } ]
    },
    "geo" : { },
    "id_str" : "563419654144946176",
    "text" : "22 years ago Pres. Clinton signed FMLA into law. Now, it's time to take the next step and #LeadOnLeave. http:\/\/t.co\/3Q6nmgnYje #FMLA22",
    "id" : 563419654144946176,
    "created_at" : "2015-02-05 19:31:28 +0000",
    "user" : {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "protected" : false,
      "id_str" : "1604366701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744887280666611712\/eEeyFjs6_normal.jpg",
      "id" : 1604366701,
      "verified" : true
    }
  },
  "id" : 563420428115263488,
  "created_at" : "2015-02-05 19:34:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/PkxaYjG7z8",
      "expanded_url" : "http:\/\/youtu.be\/Muetf_lm240",
      "display_url" : "youtu.be\/Muetf_lm240"
    } ]
  },
  "geo" : { },
  "id_str" : "563400609655955456",
  "text" : "The Affordable Care Act was a game changer for these 10 Americans.\nWatch them share their stories with the President: http:\/\/t.co\/PkxaYjG7z8",
  "id" : 563400609655955456,
  "created_at" : "2015-02-05 18:15:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/563395338388918272\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/liiOuAt927",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9GU74cCQAE1xSr.jpg",
      "id_str" : "563395184881188865",
      "id" : 563395184881188865,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9GU74cCQAE1xSr.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/liiOuAt927"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 70, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/rNzHK5i4MN",
      "expanded_url" : "http:\/\/go.wh.gov\/get-covered",
      "display_url" : "go.wh.gov\/get-covered"
    } ]
  },
  "geo" : { },
  "id_str" : "563395338388918272",
  "text" : "If you need health coverage, you've only got 10 days left to sign up. #GetCovered by Feb. 15 \u2192 http:\/\/t.co\/rNzHK5i4MN http:\/\/t.co\/liiOuAt927",
  "id" : 563395338388918272,
  "created_at" : "2015-02-05 17:54:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/563386596435976192\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/oe16HlD3jS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9GNEU-IIAEaJbx.jpg",
      "id_str" : "563386533886304257",
      "id" : 563386533886304257,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9GNEU-IIAEaJbx.jpg",
      "sizes" : [ {
        "h" : 253,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1345
      }, {
        "h" : 446,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 761,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/oe16HlD3jS"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/DHHgh7htaD",
      "expanded_url" : "http:\/\/go.wh.gov\/K4JagU",
      "display_url" : "go.wh.gov\/K4JagU"
    } ]
  },
  "geo" : { },
  "id_str" : "563386596435976192",
  "text" : "We are a nation that welcomes strivers who want to earn their piece of the American Dream: http:\/\/t.co\/DHHgh7htaD http:\/\/t.co\/oe16HlD3jS",
  "id" : 563386596435976192,
  "created_at" : "2015-02-05 17:20:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/563364804422041600\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/TW38mqYhbX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9F5NZKCcAA0agh.jpg",
      "id_str" : "563364699396272128",
      "id" : 563364699396272128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9F5NZKCcAA0agh.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/TW38mqYhbX"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 103, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/GNfbft9Ewv",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "563364804422041600",
  "text" : "RT to spread the word: You've got 10 days to sign up for 2015 health coverage \u2192 http:\/\/t.co\/GNfbft9Ewv #GetCovered http:\/\/t.co\/TW38mqYhbX",
  "id" : 563364804422041600,
  "created_at" : "2015-02-05 15:53:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LikeAGirl",
      "indices" : [ 116, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "563105904393191424",
  "text" : "RT @FLOTUS: On National Girls and Women in Sports Day, let's make sure all our daughters have opportunities to play #LikeAGirl. http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/563105040760836096\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/U6LwuM99Th",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9CNAoXCcAAWl3d.jpg",
        "id_str" : "563104995394875392",
        "id" : 563104995394875392,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9CNAoXCcAAWl3d.jpg",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 2731,
          "resize" : "fit",
          "w" : 4096
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/U6LwuM99Th"
      } ],
      "hashtags" : [ {
        "text" : "LikeAGirl",
        "indices" : [ 104, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "563105040760836096",
    "text" : "On National Girls and Women in Sports Day, let's make sure all our daughters have opportunities to play #LikeAGirl. http:\/\/t.co\/U6LwuM99Th",
    "id" : 563105040760836096,
    "created_at" : "2015-02-04 22:41:18 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 563105904393191424,
  "created_at" : "2015-02-04 22:44:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/563076816492331009\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/d0tNp3OT9V",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9ByR_7IgAAo67d.jpg",
      "id_str" : "563075606964109312",
      "id" : 563075606964109312,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9ByR_7IgAAo67d.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1500
      } ],
      "display_url" : "pic.twitter.com\/d0tNp3OT9V"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/p3fqzqDrlE",
      "expanded_url" : "http:\/\/go.wh.gov\/CTA5hu",
      "display_url" : "go.wh.gov\/CTA5hu"
    } ]
  },
  "geo" : { },
  "id_str" : "563076816492331009",
  "text" : "These 10 people met with President Obama about how the Affordable Care Act is helping them \u2192 http:\/\/t.co\/p3fqzqDrlE http:\/\/t.co\/d0tNp3OT9V",
  "id" : 563076816492331009,
  "created_at" : "2015-02-04 20:49:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "camillestrong",
      "indices" : [ 91, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/Nd6YQwNGiU",
      "expanded_url" : "http:\/\/onedublin.org\/2014\/12\/07\/dublin-teens-cancer-battle-it-takes-a-village-to-fight-hodgkins-lymphoma",
      "display_url" : "onedublin.org\/2014\/12\/07\/dub\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "563064351633190913",
  "text" : "RT @Podesta44: Camille, the President wanted you to know he was thinking about you on AF1. #camillestrong http:\/\/t.co\/Nd6YQwNGiU http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Podesta44\/status\/563055725308821504\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/TSLoheOE2n",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9BgMg1IgAEr4Tz.jpg",
        "id_str" : "563055721508798465",
        "id" : 563055721508798465,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9BgMg1IgAEr4Tz.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/TSLoheOE2n"
      } ],
      "hashtags" : [ {
        "text" : "camillestrong",
        "indices" : [ 76, 90 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/Nd6YQwNGiU",
        "expanded_url" : "http:\/\/onedublin.org\/2014\/12\/07\/dublin-teens-cancer-battle-it-takes-a-village-to-fight-hodgkins-lymphoma",
        "display_url" : "onedublin.org\/2014\/12\/07\/dub\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "563055725308821504",
    "text" : "Camille, the President wanted you to know he was thinking about you on AF1. #camillestrong http:\/\/t.co\/Nd6YQwNGiU http:\/\/t.co\/TSLoheOE2n",
    "id" : 563055725308821504,
    "created_at" : "2015-02-04 19:25:20 +0000",
    "user" : {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "protected" : false,
      "id_str" : "2382117350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656551411145027584\/ArrSlGUP_normal.jpg",
      "id" : 2382117350,
      "verified" : true
    }
  },
  "id" : 563064351633190913,
  "created_at" : "2015-02-04 19:59:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LikeAGirl",
      "indices" : [ 125, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "563044018138148865",
  "text" : "RT @vj44: Let\u2019s celebrate National Girls and Women in Sports Day by helping ensure everyone has an equal opportunity to play #LikeAGirl \n\n#\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LikeAGirl",
        "indices" : [ 115, 125 ]
      }, {
        "text" : "NGWSD",
        "indices" : [ 128, 134 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "563042429184790528",
    "text" : "Let\u2019s celebrate National Girls and Women in Sports Day by helping ensure everyone has an equal opportunity to play #LikeAGirl \n\n#NGWSD",
    "id" : 563042429184790528,
    "created_at" : "2015-02-04 18:32:30 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 563044018138148865,
  "created_at" : "2015-02-04 18:38:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Wheeler",
      "screen_name" : "TomWheelerFCC",
      "indices" : [ 3, 17 ],
      "id_str" : "2260197309",
      "id" : 2260197309
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpenInternet",
      "indices" : [ 19, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "563038808510590979",
  "text" : "RT @TomWheelerFCC: #OpenInternet is the greatest engine of free expression, innovation &amp; opportunity the world has ever known. We must prot\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OpenInternet",
        "indices" : [ 0, 13 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "563006505524686848",
    "text" : "#OpenInternet is the greatest engine of free expression, innovation &amp; opportunity the world has ever known. We must protect it now.",
    "id" : 563006505524686848,
    "created_at" : "2015-02-04 16:09:45 +0000",
    "user" : {
      "name" : "Tom Wheeler",
      "screen_name" : "TomWheelerFCC",
      "protected" : false,
      "id_str" : "2260197309",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/419133876888289281\/4s-p-W5Y_normal.jpeg",
      "id" : 2260197309,
      "verified" : true
    }
  },
  "id" : 563038808510590979,
  "created_at" : "2015-02-04 18:18:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/563028616091828224\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/oEuAZ4EdMm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B9BGKfzIMAA-rSV.jpg",
      "id_str" : "563027099569893376",
      "id" : 563027099569893376,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9BGKfzIMAA-rSV.jpg",
      "sizes" : [ {
        "h" : 254,
        "resize" : "fit",
        "w" : 889
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 889
      }, {
        "h" : 97,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 171,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/oEuAZ4EdMm"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "563028616091828224",
  "text" : "President Obama on the passing of Charlie Sifford, the first African American golfer to earn a PGA tour card. http:\/\/t.co\/oEuAZ4EdMm",
  "id" : 563028616091828224,
  "created_at" : "2015-02-04 17:37:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 115, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/Khedjv5m7Q",
      "expanded_url" : "http:\/\/www.eia.gov\/todayinenergy\/detail.cfm?id=19851",
      "display_url" : "eia.gov\/todayinenergy\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "563021112242868224",
  "text" : "RT @Podesta44: Leading by example: federal govt energy consumption at its lowest since 1975 http:\/\/t.co\/Khedjv5m7Q #ActOnClimate http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Podesta44\/status\/563012941403148289\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/tPVxVipwEF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B9A5EE0IIAI6GFt.jpg",
        "id_str" : "563012695595950082",
        "id" : 563012695595950082,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B9A5EE0IIAI6GFt.jpg",
        "sizes" : [ {
          "h" : 321,
          "resize" : "fit",
          "w" : 618
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 312,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 321,
          "resize" : "fit",
          "w" : 618
        }, {
          "h" : 177,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/tPVxVipwEF"
      } ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 100, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/Khedjv5m7Q",
        "expanded_url" : "http:\/\/www.eia.gov\/todayinenergy\/detail.cfm?id=19851",
        "display_url" : "eia.gov\/todayinenergy\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "563012941403148289",
    "text" : "Leading by example: federal govt energy consumption at its lowest since 1975 http:\/\/t.co\/Khedjv5m7Q #ActOnClimate http:\/\/t.co\/tPVxVipwEF",
    "id" : 563012941403148289,
    "created_at" : "2015-02-04 16:35:20 +0000",
    "user" : {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "protected" : false,
      "id_str" : "2382117350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656551411145027584\/ArrSlGUP_normal.jpg",
      "id" : 2382117350,
      "verified" : true
    }
  },
  "id" : 563021112242868224,
  "created_at" : "2015-02-04 17:07:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/7tB04OpNTV",
      "expanded_url" : "http:\/\/go.wh.gov\/xD5hQC",
      "display_url" : "go.wh.gov\/xD5hQC"
    } ]
  },
  "geo" : { },
  "id_str" : "563014351016435712",
  "text" : "Yesterday, the House GOP voted to take health care away from millions of Americans. Here's what that would look like: http:\/\/t.co\/7tB04OpNTV",
  "id" : 563014351016435712,
  "created_at" : "2015-02-04 16:40:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Federal Student Aid",
      "screen_name" : "FAFSA",
      "indices" : [ 41, 47 ],
      "id_str" : "188001904",
      "id" : 188001904
    }, {
      "name" : "Connie Britton",
      "screen_name" : "conniebritton",
      "indices" : [ 108, 122 ],
      "id_str" : "1905230346",
      "id" : 1905230346
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562995384075972610",
  "text" : "RT @FLOTUS: \"Don't forget. Complete your @FAFSA. You could save you and your family thousands of dollars.\" \u2014@ConnieBritton: http:\/\/t.co\/uKB\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Federal Student Aid",
        "screen_name" : "FAFSA",
        "indices" : [ 29, 35 ],
        "id_str" : "188001904",
        "id" : 188001904
      }, {
        "name" : "Connie Britton",
        "screen_name" : "conniebritton",
        "indices" : [ 96, 110 ],
        "id_str" : "1905230346",
        "id" : 1905230346
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/uKBawuLQkT",
        "expanded_url" : "http:\/\/go.wh.gov\/QXY3rT",
        "display_url" : "go.wh.gov\/QXY3rT"
      } ]
    },
    "geo" : { },
    "id_str" : "562985783221825537",
    "text" : "\"Don't forget. Complete your @FAFSA. You could save you and your family thousands of dollars.\" \u2014@ConnieBritton: http:\/\/t.co\/uKBawuLQkT",
    "id" : 562985783221825537,
    "created_at" : "2015-02-04 14:47:25 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 562995384075972610,
  "created_at" : "2015-02-04 15:25:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "2016Budget",
      "indices" : [ 18, 29 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/ZkUhG29CRk",
      "expanded_url" : "http:\/\/go.wh.gov\/2016budget",
      "display_url" : "go.wh.gov\/2016budget"
    } ]
  },
  "geo" : { },
  "id_str" : "562984183854018561",
  "text" : "President Obama's #2016Budget would:\nClose tax loopholes \u2713\nInvest in our infrastructure \u2713\nCut middle-class taxes \u2713\nhttp:\/\/t.co\/ZkUhG29CRk",
  "id" : 562984183854018561,
  "created_at" : "2015-02-04 14:41:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/562741914588684288\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/1aaRPAcfyq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B89CYFxIEAAu_nG.jpg",
      "id_str" : "562741460077121536",
      "id" : 562741460077121536,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B89CYFxIEAAu_nG.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/1aaRPAcfyq"
    } ],
    "hashtags" : [ {
      "text" : "2016Budget",
      "indices" : [ 18, 29 ]
    }, {
      "text" : "FreeCommunityCollege",
      "indices" : [ 96, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562741914588684288",
  "text" : "President Obama's #2016Budget would give every hardworking American access to higher education. #FreeCommunityCollege http:\/\/t.co\/1aaRPAcfyq",
  "id" : 562741914588684288,
  "created_at" : "2015-02-03 22:38:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/562717049513066499\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/9gcOIO6ZRu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B88rt8vIEAA9WHn.jpg",
      "id_str" : "562716546842497024",
      "id" : 562716546842497024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B88rt8vIEAA9WHn.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/9gcOIO6ZRu"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 24, 37 ]
    }, {
      "text" : "EqualPay",
      "indices" : [ 62, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562717049513066499",
  "text" : "The House GOP:\nVotes to #RaiseTheWage: \u2718\nVotes to help ensure #EqualPay: \u2718\nVotes to repeal or undermine the ACA: 50+ http:\/\/t.co\/9gcOIO6ZRu",
  "id" : 562717049513066499,
  "created_at" : "2015-02-03 20:59:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/562709899906674688\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/PzJ5SgkTVA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B88i5JzIAAIRwpj.jpg",
      "id_str" : "562706843722842114",
      "id" : 562706843722842114,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B88i5JzIAAIRwpj.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/PzJ5SgkTVA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562709899906674688",
  "text" : "House Republicans are voting to take health coverage away from millions of Americans.\nRT if you agree that's wrong. http:\/\/t.co\/PzJ5SgkTVA",
  "id" : 562709899906674688,
  "created_at" : "2015-02-03 20:31:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/562700554204643329\/photo\/1",
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/7dn0G3szly",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B88dCiEIgAM8YXZ.jpg",
      "id_str" : "562700407785684995",
      "id" : 562700407785684995,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B88dCiEIgAM8YXZ.jpg",
      "sizes" : [ {
        "h" : 382,
        "resize" : "fit",
        "w" : 945
      }, {
        "h" : 382,
        "resize" : "fit",
        "w" : 945
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 137,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 243,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/7dn0G3szly"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562700554204643329",
  "text" : "President Obama on the death of First Lieutenant Moaz al-Kasasbeh. http:\/\/t.co\/7dn0G3szly",
  "id" : 562700554204643329,
  "created_at" : "2015-02-03 19:54:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/562683382178779136\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/pC7yVIRbap",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B88NfbfIUAEZ4-3.jpg",
      "id_str" : "562683312050032641",
      "id" : 562683312050032641,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B88NfbfIUAEZ4-3.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/pC7yVIRbap"
    } ],
    "hashtags" : [ {
      "text" : "2016Budget",
      "indices" : [ 16, 27 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/HN6m0onwAp",
      "expanded_url" : "http:\/\/go.wh.gov\/2016budget",
      "display_url" : "go.wh.gov\/2016budget"
    } ]
  },
  "geo" : { },
  "id_str" : "562683382178779136",
  "text" : "The President's #2016Budget invests in developing better treatments for diseases like cancer: http:\/\/t.co\/HN6m0onwAp http:\/\/t.co\/pC7yVIRbap",
  "id" : 562683382178779136,
  "created_at" : "2015-02-03 18:45:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "indices" : [ 3, 16 ],
      "id_str" : "78138151",
      "id" : 78138151
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Texas",
      "indices" : [ 110, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562676951828430848",
  "text" : "RT @lacasablanca: Share the news: President Obama's executive actions on immigration will add billions to the #Texas GDP http:\/\/t.co\/ipU009\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/lacasablanca\/status\/562672930216476672\/photo\/1",
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/ipU009d8OK",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B88EDEdIYAAiyLz.jpg",
        "id_str" : "562672929226645504",
        "id" : 562672929226645504,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B88EDEdIYAAiyLz.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/ipU009d8OK"
      } ],
      "hashtags" : [ {
        "text" : "Texas",
        "indices" : [ 92, 98 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "562672930216476672",
    "text" : "Share the news: President Obama's executive actions on immigration will add billions to the #Texas GDP http:\/\/t.co\/ipU009d8OK",
    "id" : 562672930216476672,
    "created_at" : "2015-02-03 18:04:15 +0000",
    "user" : {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "protected" : false,
      "id_str" : "78138151",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616360382911754241\/4Tfqcfie_normal.png",
      "id" : 78138151,
      "verified" : true
    }
  },
  "id" : 562676951828430848,
  "created_at" : "2015-02-03 18:20:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/VP\/status\/562651691670339584\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/HSy7qA0Cdc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B87wuggIQAA_odL.jpg",
      "id_str" : "562651685257232384",
      "id" : 562651685257232384,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B87wuggIQAA_odL.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/HSy7qA0Cdc"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 83, 94 ]
    }, {
      "text" : "PeopleOverPolitics",
      "indices" : [ 95, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/fhBFW2Raos",
      "expanded_url" : "http:\/\/www.momsrising.org\/blog\/coffee-and-healthcare-with-the-vice-president",
      "display_url" : "momsrising.org\/blog\/coffee-an\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "562652725129641984",
  "text" : "RT @VP: Health care gives mothers like Marla peace of mind. http:\/\/t.co\/fhBFW2Raos #GetCovered #PeopleOverPolitics http:\/\/t.co\/HSy7qA0Cdc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/562651691670339584\/photo\/1",
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/HSy7qA0Cdc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B87wuggIQAA_odL.jpg",
        "id_str" : "562651685257232384",
        "id" : 562651685257232384,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B87wuggIQAA_odL.jpg",
        "sizes" : [ {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/HSy7qA0Cdc"
      } ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 75, 86 ]
      }, {
        "text" : "PeopleOverPolitics",
        "indices" : [ 87, 106 ]
      } ],
      "urls" : [ {
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/fhBFW2Raos",
        "expanded_url" : "http:\/\/www.momsrising.org\/blog\/coffee-and-healthcare-with-the-vice-president",
        "display_url" : "momsrising.org\/blog\/coffee-an\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "562651691670339584",
    "text" : "Health care gives mothers like Marla peace of mind. http:\/\/t.co\/fhBFW2Raos #GetCovered #PeopleOverPolitics http:\/\/t.co\/HSy7qA0Cdc",
    "id" : 562651691670339584,
    "created_at" : "2015-02-03 16:39:51 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 562652725129641984,
  "created_at" : "2015-02-03 16:43:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "indices" : [ 3, 15 ],
      "id_str" : "369232105",
      "id" : 369232105
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 120, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/JVtBUt0MqQ",
      "expanded_url" : "http:\/\/1.usa.gov\/1uRr0PA",
      "display_url" : "1.usa.gov\/1uRr0PA"
    } ]
  },
  "geo" : { },
  "id_str" : "562637910793416704",
  "text" : "RT @PAniskoff44: Stuff happens. When an avalanche swept up Eric, health coverage kept him alive. http:\/\/t.co\/JVtBUt0MqQ #GetCovered #People\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 103, 114 ]
      }, {
        "text" : "PeopleOverPolitics",
        "indices" : [ 115, 134 ]
      } ],
      "urls" : [ {
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/JVtBUt0MqQ",
        "expanded_url" : "http:\/\/1.usa.gov\/1uRr0PA",
        "display_url" : "1.usa.gov\/1uRr0PA"
      } ]
    },
    "geo" : { },
    "id_str" : "562632009768374273",
    "text" : "Stuff happens. When an avalanche swept up Eric, health coverage kept him alive. http:\/\/t.co\/JVtBUt0MqQ #GetCovered #PeopleOverPolitics",
    "id" : 562632009768374273,
    "created_at" : "2015-02-03 15:21:38 +0000",
    "user" : {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "protected" : false,
      "id_str" : "369232105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623146355767140352\/58sqoVrw_normal.jpg",
      "id" : 369232105,
      "verified" : true
    }
  },
  "id" : 562637910793416704,
  "created_at" : "2015-02-03 15:45:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/562625879185293312\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/Ru3lF7djHg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B87ZIrACcAAIeCW.jpg",
      "id_str" : "562625746472955904",
      "id" : 562625746472955904,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B87ZIrACcAAIeCW.jpg",
      "sizes" : [ {
        "h" : 499,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 283,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 852,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 915,
        "resize" : "fit",
        "w" : 1100
      } ],
      "display_url" : "pic.twitter.com\/Ru3lF7djHg"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562625879185293312",
  "text" : "President Obama meets with Clarence Jones, who worked with Martin Luther King. Jr. on his \"I Have a Dream Speech.\" http:\/\/t.co\/Ru3lF7djHg",
  "id" : 562625879185293312,
  "created_at" : "2015-02-03 14:57:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/petesouza\/status\/562397649438277632\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/kzzVigKHzv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B84JpryCAAAO-nw.jpg",
      "id_str" : "562397615199748096",
      "id" : 562397615199748096,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B84JpryCAAAO-nw.jpg",
      "sizes" : [ {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/kzzVigKHzv"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562402900660736001",
  "text" : "RT @petesouza: President Obama walks w Homeland Security Secretary Jeh Johnson to event today in Washington, DC http:\/\/t.co\/kzzVigKHzv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/petesouza\/status\/562397649438277632\/photo\/1",
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/kzzVigKHzv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B84JpryCAAAO-nw.jpg",
        "id_str" : "562397615199748096",
        "id" : 562397615199748096,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B84JpryCAAAO-nw.jpg",
        "sizes" : [ {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/kzzVigKHzv"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "562397649438277632",
    "text" : "President Obama walks w Homeland Security Secretary Jeh Johnson to event today in Washington, DC http:\/\/t.co\/kzzVigKHzv",
    "id" : 562397649438277632,
    "created_at" : "2015-02-02 23:50:23 +0000",
    "user" : {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "protected" : false,
      "id_str" : "18215973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771916869808844800\/7d_poH48_normal.jpg",
      "id" : 18215973,
      "verified" : true
    }
  },
  "id" : 562402900660736001,
  "created_at" : "2015-02-03 00:11:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WH.gov",
      "screen_name" : "WHWeb",
      "indices" : [ 3, 9 ],
      "id_str" : "390320946",
      "id" : 390320946
    }, {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 119, 126 ],
      "id_str" : "13334762",
      "id" : 13334762
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "2016Budget",
      "indices" : [ 45, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562383593981243393",
  "text" : "RT @WHWeb: President Obama just released his #2016Budget. And, for the 1st time, you can see all the data behind it on @GitHub\u2192 https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "GitHub",
        "screen_name" : "github",
        "indices" : [ 108, 115 ],
        "id_str" : "13334762",
        "id" : 13334762
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "2016Budget",
        "indices" : [ 34, 45 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/W7FZHha4JI",
        "expanded_url" : "https:\/\/github.com\/WhiteHouse\/2016-budget-data",
        "display_url" : "github.com\/WhiteHouse\/201\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "562333567263313920",
    "text" : "President Obama just released his #2016Budget. And, for the 1st time, you can see all the data behind it on @GitHub\u2192 https:\/\/t.co\/W7FZHha4JI",
    "id" : 562333567263313920,
    "created_at" : "2015-02-02 19:35:44 +0000",
    "user" : {
      "name" : "WH.gov",
      "screen_name" : "WHWeb",
      "protected" : false,
      "id_str" : "390320946",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618051538582310913\/0xcdHiQS_normal.jpg",
      "id" : 390320946,
      "verified" : true
    }
  },
  "id" : 562383593981243393,
  "created_at" : "2015-02-02 22:54:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "indices" : [ 3, 10 ],
      "id_str" : "44783853",
      "id" : 44783853
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 61, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562375691187290113",
  "text" : "RT @HHSGov: Don\u2019t delay. Find affordable health coverage and #GetCovered today! The Deadline to sign up is February 15th. http:\/\/t.co\/RoTXZ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 49, 60 ]
      } ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/RoTXZd0MOt",
        "expanded_url" : "http:\/\/bit.ly\/1wWTOWB",
        "display_url" : "bit.ly\/1wWTOWB"
      } ]
    },
    "geo" : { },
    "id_str" : "562373901443801088",
    "text" : "Don\u2019t delay. Find affordable health coverage and #GetCovered today! The Deadline to sign up is February 15th. http:\/\/t.co\/RoTXZd0MOt",
    "id" : 562373901443801088,
    "created_at" : "2015-02-02 22:16:01 +0000",
    "user" : {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "protected" : false,
      "id_str" : "44783853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567350542326718464\/FXOsgyA7_normal.jpeg",
      "id" : 44783853,
      "verified" : true
    }
  },
  "id" : 562375691187290113,
  "created_at" : "2015-02-02 22:23:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Labor Department",
      "screen_name" : "USDOL",
      "indices" : [ 3, 9 ],
      "id_str" : "20179628",
      "id" : 20179628
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SmallBiz",
      "indices" : [ 68, 77 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 115, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/G7BySG9H0b",
      "expanded_url" : "http:\/\/1.usa.gov\/1zvLKk2",
      "display_url" : "1.usa.gov\/1zvLKk2"
    } ]
  },
  "geo" : { },
  "id_str" : "562370907055079424",
  "text" : "RT @USDOL: \u201CWithout the ACA, I\u2019d be dead within a year.\u201D \u2014Victor, a #SmallBiz owner in Utah http:\/\/t.co\/G7BySG9H0b #GetCovered http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/USDOL\/status\/562369280512385025\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/odDkg4CQJb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B83vwj6CEAAnEVr.png",
        "id_str" : "562369146042585088",
        "id" : 562369146042585088,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B83vwj6CEAAnEVr.png",
        "sizes" : [ {
          "h" : 279,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 158,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 440,
          "resize" : "fit",
          "w" : 946
        }, {
          "h" : 440,
          "resize" : "fit",
          "w" : 946
        } ],
        "display_url" : "pic.twitter.com\/odDkg4CQJb"
      } ],
      "hashtags" : [ {
        "text" : "SmallBiz",
        "indices" : [ 57, 66 ]
      }, {
        "text" : "GetCovered",
        "indices" : [ 104, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/G7BySG9H0b",
        "expanded_url" : "http:\/\/1.usa.gov\/1zvLKk2",
        "display_url" : "1.usa.gov\/1zvLKk2"
      } ]
    },
    "geo" : { },
    "id_str" : "562369280512385025",
    "text" : "\u201CWithout the ACA, I\u2019d be dead within a year.\u201D \u2014Victor, a #SmallBiz owner in Utah http:\/\/t.co\/G7BySG9H0b #GetCovered http:\/\/t.co\/odDkg4CQJb",
    "id" : 562369280512385025,
    "created_at" : "2015-02-02 21:57:39 +0000",
    "user" : {
      "name" : "US Labor Department",
      "screen_name" : "USDOL",
      "protected" : false,
      "id_str" : "20179628",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655006480697978880\/Fom0f0nJ_normal.png",
      "id" : 20179628,
      "verified" : true
    }
  },
  "id" : 562370907055079424,
  "created_at" : "2015-02-02 22:04:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/RuOwQxYoFI",
      "expanded_url" : "http:\/\/go.wh.gov\/education",
      "display_url" : "go.wh.gov\/education"
    } ]
  },
  "geo" : { },
  "id_str" : "562345722188541954",
  "text" : "RT @VP: Our budget will help widen the path to the middle class by making college more affordable \u2192 http:\/\/t.co\/RuOwQxYoFI http:\/\/t.co\/gf8G\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/VP\/status\/562342211874848768\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/gf8G4b3OYh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B83XQhaCAAAN5CR.jpg",
        "id_str" : "562342207336611840",
        "id" : 562342207336611840,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B83XQhaCAAAN5CR.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/gf8G4b3OYh"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/RuOwQxYoFI",
        "expanded_url" : "http:\/\/go.wh.gov\/education",
        "display_url" : "go.wh.gov\/education"
      } ]
    },
    "geo" : { },
    "id_str" : "562342211874848768",
    "text" : "Our budget will help widen the path to the middle class by making college more affordable \u2192 http:\/\/t.co\/RuOwQxYoFI http:\/\/t.co\/gf8G4b3OYh",
    "id" : 562342211874848768,
    "created_at" : "2015-02-02 20:10:05 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 562345722188541954,
  "created_at" : "2015-02-02 20:24:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/562340727624331264\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/pdj2corJYH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B83VxUyCQAAjP2f.jpg",
      "id_str" : "562340571860058112",
      "id" : 562340571860058112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B83VxUyCQAAjP2f.jpg",
      "sizes" : [ {
        "h" : 381,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 650,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 216,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 650,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/pdj2corJYH"
    } ],
    "hashtags" : [ {
      "text" : "SixMoreWeeksOfWinter",
      "indices" : [ 13, 34 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 105, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/rNzHK68SaZ",
      "expanded_url" : "http:\/\/go.wh.gov\/get-covered",
      "display_url" : "go.wh.gov\/get-covered"
    } ]
  },
  "geo" : { },
  "id_str" : "562340727624331264",
  "text" : "There may be #SixMoreWeeksOfWinter, but only 2 more weeks to get health coverage: http:\/\/t.co\/rNzHK68SaZ #GetCovered http:\/\/t.co\/pdj2corJYH",
  "id" : 562340727624331264,
  "created_at" : "2015-02-02 20:04:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562332344703782913",
  "text" : "\"I want to recognize...Robbie Rogers of the Galaxy...blazing a trail as one of professional sports\u2019 first openly gay players\" \u2014Obama",
  "id" : 562332344703782913,
  "created_at" : "2015-02-02 19:30:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "#LAKings",
      "screen_name" : "LAKings",
      "indices" : [ 47, 55 ],
      "id_str" : "19013887",
      "id" : 19013887
    }, {
      "name" : "Major League Soccer",
      "screen_name" : "MLS",
      "indices" : [ 64, 68 ],
      "id_str" : "107146095",
      "id" : 107146095
    }, {
      "name" : "LA Galaxy",
      "screen_name" : "LAGalaxy",
      "indices" : [ 78, 87 ],
      "id_str" : "23011345",
      "id" : 23011345
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562330956733087744",
  "text" : "\"Let\u2019s give it up for the Stanley Cup Champion @LAKings and the @MLS Champion @LAGalaxy!\" \u2014President Obama",
  "id" : 562330956733087744,
  "created_at" : "2015-02-02 19:25:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "#LAKings",
      "screen_name" : "LAKings",
      "indices" : [ 60, 68 ],
      "id_str" : "19013887",
      "id" : 19013887
    }, {
      "name" : "Major League Soccer",
      "screen_name" : "MLS",
      "indices" : [ 77, 81 ],
      "id_str" : "107146095",
      "id" : 107146095
    }, {
      "name" : "LA Galaxy",
      "screen_name" : "LAGalaxy",
      "indices" : [ 91, 100 ],
      "id_str" : "23011345",
      "id" : 23011345
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/KhEC8ar1gl",
      "expanded_url" : "http:\/\/go.wh.gov\/eRCj84",
      "display_url" : "go.wh.gov\/eRCj84"
    } ]
  },
  "geo" : { },
  "id_str" : "562330313591128064",
  "text" : "Watch live: President Obama honors the Stanley Cup Champion @LAKings and the @MLS Champion @LAGalaxy \u2192 http:\/\/t.co\/KhEC8ar1gl",
  "id" : 562330313591128064,
  "created_at" : "2015-02-02 19:22:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/562319754380451843\/photo\/1",
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/LYUBuYrVDk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B83C1fDCEAAzgx6.jpg",
      "id_str" : "562319752614252544",
      "id" : 562319752614252544,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B83C1fDCEAAzgx6.jpg",
      "sizes" : [ {
        "h" : 1250,
        "resize" : "fit",
        "w" : 2500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/LYUBuYrVDk"
    } ],
    "hashtags" : [ {
      "text" : "2016Budget",
      "indices" : [ 18, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562319754380451843",
  "text" : "President Obama's #2016Budget would close the trust fund loophole to help invest in the middle class. http:\/\/t.co\/LYUBuYrVDk",
  "id" : 562319754380451843,
  "created_at" : "2015-02-02 18:40:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chuck Schumer",
      "screen_name" : "SenSchumer",
      "indices" : [ 3, 14 ],
      "id_str" : "17494010",
      "id" : 17494010
    }, {
      "name" : "Homeland Security",
      "screen_name" : "DHSgov",
      "indices" : [ 17, 24 ],
      "id_str" : "15647676",
      "id" : 15647676
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FundDHS",
      "indices" : [ 71, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/TwZrR8nF4t",
      "expanded_url" : "http:\/\/wapo.st\/1z3pKxV",
      "display_url" : "wapo.st\/1z3pKxV"
    } ]
  },
  "geo" : { },
  "id_str" : "562310568892432384",
  "text" : "RT @SenSchumer: .@DHSGov's mission is to protect America. It's time to #FundDHS so they can do their job. http:\/\/t.co\/TwZrR8nF4t http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Homeland Security",
        "screen_name" : "DHSgov",
        "indices" : [ 1, 8 ],
        "id_str" : "15647676",
        "id" : 15647676
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SenSchumer\/status\/562310141773885441\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/oJCd5k0m0q",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/B826GBmCIAEgGSG.jpg",
        "id_str" : "562310141161119745",
        "id" : 562310141161119745,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B826GBmCIAEgGSG.jpg",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/oJCd5k0m0q"
      } ],
      "hashtags" : [ {
        "text" : "FundDHS",
        "indices" : [ 55, 63 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/TwZrR8nF4t",
        "expanded_url" : "http:\/\/wapo.st\/1z3pKxV",
        "display_url" : "wapo.st\/1z3pKxV"
      } ]
    },
    "geo" : { },
    "id_str" : "562310141773885441",
    "text" : ".@DHSGov's mission is to protect America. It's time to #FundDHS so they can do their job. http:\/\/t.co\/TwZrR8nF4t http:\/\/t.co\/oJCd5k0m0q",
    "id" : 562310141773885441,
    "created_at" : "2015-02-02 18:02:39 +0000",
    "user" : {
      "name" : "Chuck Schumer",
      "screen_name" : "SenSchumer",
      "protected" : false,
      "id_str" : "17494010",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623955176131575808\/zWzgRP4C_normal.jpg",
      "id" : 17494010,
      "verified" : true
    }
  },
  "id" : 562310568892432384,
  "created_at" : "2015-02-02 18:04:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/562306104949243904\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/dsKWBT5Tuy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B822V9DCQAE8st5.jpg",
      "id_str" : "562306016771981313",
      "id" : 562306016771981313,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B822V9DCQAE8st5.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1250,
        "resize" : "fit",
        "w" : 2500
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/dsKWBT5Tuy"
    } ],
    "hashtags" : [ {
      "text" : "2016Budget",
      "indices" : [ 18, 29 ]
    }, {
      "text" : "ChildCare",
      "indices" : [ 42, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562306104949243904",
  "text" : "President Obama's #2016Budget triples the #ChildCare tax credit so more working families can get ahead. http:\/\/t.co\/dsKWBT5Tuy",
  "id" : 562306104949243904,
  "created_at" : "2015-02-02 17:46:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/562300817106292736\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/rPF1NrBNsf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B82xl2wCIAMfnYZ.jpg",
      "id_str" : "562300792401436675",
      "id" : 562300792401436675,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B82xl2wCIAMfnYZ.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/rPF1NrBNsf"
    } ],
    "hashtags" : [ {
      "text" : "2016Budget",
      "indices" : [ 18, 29 ]
    }, {
      "text" : "FreeCommunityCollege",
      "indices" : [ 72, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/h9PBXMjA8j",
      "expanded_url" : "http:\/\/go.wh.gov\/education",
      "display_url" : "go.wh.gov\/education"
    } ]
  },
  "geo" : { },
  "id_str" : "562300817106292736",
  "text" : "President Obama's #2016Budget would give responsible students access to #FreeCommunityCollege: http:\/\/t.co\/h9PBXMjA8j http:\/\/t.co\/rPF1NrBNsf",
  "id" : 562300817106292736,
  "created_at" : "2015-02-02 17:25:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Medium",
      "screen_name" : "Medium",
      "indices" : [ 63, 70 ],
      "id_str" : "571202103",
      "id" : 571202103
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/562292789837561856\/photo\/1",
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/7s332wty3X",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B82qQQDCYAI8_5U.jpg",
      "id_str" : "562292724653514754",
      "id" : 562292724653514754,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B82qQQDCYAI8_5U.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1001,
        "resize" : "fit",
        "w" : 1500
      } ],
      "display_url" : "pic.twitter.com\/7s332wty3X"
    } ],
    "hashtags" : [ {
      "text" : "2016Budget",
      "indices" : [ 34, 45 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/HN6m0onwAp",
      "expanded_url" : "http:\/\/go.wh.gov\/2016budget",
      "display_url" : "go.wh.gov\/2016budget"
    } ]
  },
  "geo" : { },
  "id_str" : "562292789837561856",
  "text" : "President Obama just released his #2016Budget. Check it out on @Medium \u2192 http:\/\/t.co\/HN6m0onwAp http:\/\/t.co\/7s332wty3X",
  "id" : 562292789837561856,
  "created_at" : "2015-02-02 16:53:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/562288810621685760\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/DOrJS0Uc1c",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B82mqV6CEAAlRE3.jpg",
      "id_str" : "562288774856445952",
      "id" : 562288774856445952,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B82mqV6CEAAlRE3.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/DOrJS0Uc1c"
    } ],
    "hashtags" : [ {
      "text" : "2016Budget",
      "indices" : [ 104, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562288810621685760",
  "text" : "\"What we can\u2019t do is play politics with folks\u2019 economic security or with our national security.\" \u2014Obama #2016Budget http:\/\/t.co\/DOrJS0Uc1c",
  "id" : 562288810621685760,
  "created_at" : "2015-02-02 16:37:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "2016Budget",
      "indices" : [ 125, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562288495310700544",
  "text" : "\"The budget I\u2019ve sent Congress today is fully paid for through a combination of smart spending cuts and tax reforms.\" \u2014Obama #2016Budget",
  "id" : 562288495310700544,
  "created_at" : "2015-02-02 16:36:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/562288226313175040\/photo\/1",
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/Lvf0lIkPXs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B82mI3lCUAAbKth.jpg",
      "id_str" : "562288199779635200",
      "id" : 562288199779635200,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B82mI3lCUAAbKth.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Lvf0lIkPXs"
    } ],
    "hashtags" : [ {
      "text" : "2016Budget",
      "indices" : [ 84, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562288226313175040",
  "text" : "\"Since I took office, we\u2019ve cut our deficits by about two-thirds.\" \u2014President Obama #2016Budget http:\/\/t.co\/Lvf0lIkPXs",
  "id" : 562288226313175040,
  "created_at" : "2015-02-02 16:35:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/562288011720032260\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/HdLhjzMGw5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B82l9pPCMAAsbMd.jpg",
      "id_str" : "562288006950694912",
      "id" : 562288006950694912,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B82l9pPCMAAsbMd.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/HdLhjzMGw5"
    } ],
    "hashtags" : [ {
      "text" : "2016Budget",
      "indices" : [ 99, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562288011720032260",
  "text" : "\"It includes my plan to make two years of community college free for responsible students.\" \u2014Obama #2016Budget http:\/\/t.co\/HdLhjzMGw5",
  "id" : 562288011720032260,
  "created_at" : "2015-02-02 16:34:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/562287233139769345\/photo\/1",
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/n2yYQPuRzR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B82lPC1CUAAf3eJ.jpg",
      "id_str" : "562287206367121408",
      "id" : 562287206367121408,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B82lPC1CUAAf3eJ.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/n2yYQPuRzR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562287233139769345",
  "text" : "\"Our businesses are creating jobs at the fastest pace since the 1990s.\" \u2014President Obama http:\/\/t.co\/n2yYQPuRzR",
  "id" : 562287233139769345,
  "created_at" : "2015-02-02 16:31:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Homeland Security",
      "screen_name" : "DHSgov",
      "indices" : [ 73, 80 ],
      "id_str" : "15647676",
      "id" : 15647676
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/562286742926286848\/photo\/1",
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/8OeQLBS6Fy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B82kwPICYAAuh2L.jpg",
      "id_str" : "562286677092098048",
      "id" : 562286677092098048,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B82kwPICYAAuh2L.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/8OeQLBS6Fy"
    } ],
    "hashtags" : [ {
      "text" : "FundDHS",
      "indices" : [ 81, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562286742926286848",
  "text" : "\"No one works harder than you to keep America safe.\" \u2014President Obama at @DHSGov #FundDHS http:\/\/t.co\/8OeQLBS6Fy",
  "id" : 562286742926286848,
  "created_at" : "2015-02-02 16:29:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "2016Budget",
      "indices" : [ 46, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/Q27sebSE24",
      "expanded_url" : "http:\/\/go.wh.gov\/6mm6Te",
      "display_url" : "go.wh.gov\/6mm6Te"
    } ]
  },
  "geo" : { },
  "id_str" : "562286454806970368",
  "text" : "Watch live: President Obama speaks on how his #2016Budget is a blueprint for middle-class economics \u2192 http:\/\/t.co\/Q27sebSE24",
  "id" : 562286454806970368,
  "created_at" : "2015-02-02 16:28:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Homeland Security",
      "screen_name" : "DHSgov",
      "indices" : [ 22, 29 ],
      "id_str" : "15647676",
      "id" : 15647676
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/562282017996685312\/photo\/1",
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/1PloYeCGYD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B82geK7CMAAa8fC.jpg",
      "id_str" : "562281968679661568",
      "id" : 562281968679661568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B82geK7CMAAa8fC.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/1PloYeCGYD"
    } ],
    "hashtags" : [ {
      "text" : "FundDHS",
      "indices" : [ 68, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/j0VBNq3Tcl",
      "expanded_url" : "http:\/\/wapo.st\/1z3pKxV",
      "display_url" : "wapo.st\/1z3pKxV"
    } ]
  },
  "geo" : { },
  "id_str" : "562282017996685312",
  "text" : "Former Secretaries of @DHSGov from both parties agree: It's time to #FundDHS \u2192 http:\/\/t.co\/j0VBNq3Tcl http:\/\/t.co\/1PloYeCGYD",
  "id" : 562282017996685312,
  "created_at" : "2015-02-02 16:10:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/562276456844525568\/photo\/1",
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/RX28L3rnHL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B82bb3hCEAINh7V.jpg",
      "id_str" : "562276431552450562",
      "id" : 562276431552450562,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B82bb3hCEAINh7V.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/RX28L3rnHL"
    } ],
    "hashtags" : [ {
      "text" : "FundDHS",
      "indices" : [ 58, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/j0VBNq3Tcl",
      "expanded_url" : "http:\/\/wapo.st\/1z3pKxV",
      "display_url" : "wapo.st\/1z3pKxV"
    } ]
  },
  "geo" : { },
  "id_str" : "562276456844525568",
  "text" : "Here's what's at stake if Republicans in Congress fail to #FundDHS \u2192 http:\/\/t.co\/j0VBNq3Tcl http:\/\/t.co\/RX28L3rnHL",
  "id" : 562276456844525568,
  "created_at" : "2015-02-02 15:48:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "New England Patriots",
      "screen_name" : "Patriots",
      "indices" : [ 16, 25 ],
      "id_str" : "31126587",
      "id" : 31126587
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SuperBowl",
      "indices" : [ 39, 49 ]
    }, {
      "text" : "OnToTheWhiteHouse",
      "indices" : [ 57, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562086165659258881",
  "text" : "Congrats to the @Patriots on their 4th #SuperBowl title! #OnToTheWhiteHouse -bo",
  "id" : 562086165659258881,
  "created_at" : "2015-02-02 03:12:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/562053577133543425\/photo\/1",
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/tJmqqjFeNp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B8zQcAfCMAE4MII.jpg",
      "id_str" : "562053233099550721",
      "id" : 562053233099550721,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B8zQcAfCMAE4MII.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/tJmqqjFeNp"
    } ],
    "hashtags" : [ {
      "text" : "SuperBowl",
      "indices" : [ 21, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562053577133543425",
  "text" : "Halftime in America. #SuperBowl http:\/\/t.co\/tJmqqjFeNp",
  "id" : 562053577133543425,
  "created_at" : "2015-02-02 01:03:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Savannah Guthrie",
      "screen_name" : "SavannahGuthrie",
      "indices" : [ 40, 56 ],
      "id_str" : "52070270",
      "id" : 52070270
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/562027506321330177\/photo\/1",
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/FDoavbJjoV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B8y4sO8CYAAvpBa.jpg",
      "id_str" : "562027123578134528",
      "id" : 562027123578134528,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B8y4sO8CYAAvpBa.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/FDoavbJjoV"
    } ],
    "hashtags" : [ {
      "text" : "SB49",
      "indices" : [ 58, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562027506321330177",
  "text" : "A Super Bowl pre-game beer tasting with @SavannahGuthrie. #SB49 http:\/\/t.co\/FDoavbJjoV",
  "id" : 562027506321330177,
  "created_at" : "2015-02-01 23:19:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/562022656682127360\/photo\/1",
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/klJJcmX7AE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B8yr3iFCIAAhYa2.jpg",
      "id_str" : "562013024043540480",
      "id" : 562013024043540480,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B8yr3iFCIAAhYa2.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1366,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/klJJcmX7AE"
    } ],
    "hashtags" : [ {
      "text" : "SB49",
      "indices" : [ 10, 15 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "562022656682127360",
  "text" : "Game day. #SB49 http:\/\/t.co\/klJJcmX7AE",
  "id" : 562022656682127360,
  "created_at" : "2015-02-01 23:00:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/558025014809595905\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/b2VOtIrGk9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/B76Au1QCQAAaUER.jpg",
      "id_str" : "558024945897193472",
      "id" : 558024945897193472,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/B76Au1QCQAAaUER.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/b2VOtIrGk9"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/b6LqRnWIl3",
      "expanded_url" : "http:\/\/youtu.be\/bupE4OonRlk",
      "display_url" : "youtu.be\/bupE4OonRlk"
    } ]
  },
  "geo" : { },
  "id_str" : "561932095333736448",
  "text" : "\"Since I took office, we\u2019ve cut our deficits by about two-thirds.\" \u2014President Obama: http:\/\/t.co\/b6LqRnWIl3 http:\/\/t.co\/b2VOtIrGk9",
  "id" : 561932095333736448,
  "created_at" : "2015-02-01 17:00:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/9Z51pk3kke",
      "expanded_url" : "http:\/\/apne.ws\/1D12uCu",
      "display_url" : "apne.ws\/1D12uCu"
    } ]
  },
  "geo" : { },
  "id_str" : "561921237677772800",
  "text" : "President Obama's budget would:\nClose tax loopholes \u2713\nInvest in our infrastructure \u2713\nCut middle-class taxes \u2713\nhttp:\/\/t.co\/9Z51pk3kke",
  "id" : 561921237677772800,
  "created_at" : "2015-02-01 16:17:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/b6LqRnWIl3",
      "expanded_url" : "http:\/\/youtu.be\/bupE4OonRlk",
      "display_url" : "youtu.be\/bupE4OonRlk"
    } ]
  },
  "geo" : { },
  "id_str" : "561901890355474433",
  "text" : "President Obama on how the budget he's sending Congress creates a path toward a thriving middle class \u2192 http:\/\/t.co\/b6LqRnWIl3",
  "id" : 561901890355474433,
  "created_at" : "2015-02-01 15:00:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
} ]