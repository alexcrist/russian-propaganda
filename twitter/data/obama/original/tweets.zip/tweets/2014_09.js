Grailbird.data.tweets_2014_09 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/517131823344660480\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/nvOfeyrfmp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/By0pW7mIAAAC0Zk.jpg",
      "id_str" : "517115006148935680",
      "id" : 517115006148935680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/By0pW7mIAAAC0Zk.jpg",
      "sizes" : [ {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/nvOfeyrfmp"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/AApe3aX6G9",
      "expanded_url" : "http:\/\/go.wh.gov\/daxDtQ",
      "display_url" : "go.wh.gov\/daxDtQ"
    } ]
  },
  "geo" : { },
  "id_str" : "517131823344660480",
  "text" : "President Obama and Indian Prime Minister Modi visit the Martin Luther King, Jr. memorial: http:\/\/t.co\/AApe3aX6G9 http:\/\/t.co\/nvOfeyrfmp",
  "id" : 517131823344660480,
  "created_at" : "2014-10-01 02:00:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Tom Frieden",
      "screen_name" : "DrFriedenCDC",
      "indices" : [ 40, 53 ],
      "id_str" : "426909329",
      "id" : 426909329
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/517107869612015616\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/LskvypZ6ky",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/By0i3fvIcAEMADm.jpg",
      "id_str" : "517107869024808961",
      "id" : 517107869024808961,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/By0i3fvIcAEMADm.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/LskvypZ6ky"
    } ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 71, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/Cn45X01hMf",
      "expanded_url" : "http:\/\/go.wh.gov\/LGsQnf",
      "display_url" : "go.wh.gov\/LGsQnf"
    } ]
  },
  "geo" : { },
  "id_str" : "517107869612015616",
  "text" : "President Obama receives an update from @DrFriedenCDC on the diagnosed #Ebola case in Dallas: http:\/\/t.co\/Cn45X01hMf http:\/\/t.co\/LskvypZ6ky",
  "id" : 517107869612015616,
  "created_at" : "2014-10-01 00:24:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/517095132068610049\/photo\/1",
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/08u3hJCxTY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/By0XSEwIAAAs_HQ.jpg",
      "id_str" : "517095131498151936",
      "id" : 517095131498151936,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/By0XSEwIAAAs_HQ.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/08u3hJCxTY"
    } ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 17, 23 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/56PQFaDtTD",
      "expanded_url" : "http:\/\/go.wh.gov\/LGsQnf",
      "display_url" : "go.wh.gov\/LGsQnf"
    } ]
  },
  "geo" : { },
  "id_str" : "517106666915909633",
  "text" : "Get the facts on #Ebola, and what we're doing to respond \u2192 http:\/\/t.co\/56PQFaDtTD http:\/\/t.co\/08u3hJCxTY",
  "id" : 517106666915909633,
  "created_at" : "2014-10-01 00:20:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 110, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/56PQFaDtTD",
      "expanded_url" : "http:\/\/go.wh.gov\/LGsQnf",
      "display_url" : "go.wh.gov\/LGsQnf"
    } ]
  },
  "geo" : { },
  "id_str" : "517101652298321920",
  "text" : "America has the best doctors and public health infrastructure in the world, and we are prepared to respond to #Ebola: http:\/\/t.co\/56PQFaDtTD",
  "id" : 517101652298321920,
  "created_at" : "2014-10-01 00:00:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 6, 12 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517098816089378816",
  "text" : "FACT: #Ebola can only spread from contact with the blood or body fluids of a person or animal who is sick with or has died from the disease.",
  "id" : 517098816089378816,
  "created_at" : "2014-09-30 23:48:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/517095132068610049\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/08u3hJCxTY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/By0XSEwIAAAs_HQ.jpg",
      "id_str" : "517095131498151936",
      "id" : 517095131498151936,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/By0XSEwIAAAs_HQ.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/08u3hJCxTY"
    } ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 21, 27 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/Cn45X01hMf",
      "expanded_url" : "http:\/\/go.wh.gov\/LGsQnf",
      "display_url" : "go.wh.gov\/LGsQnf"
    } ]
  },
  "geo" : { },
  "id_str" : "517095132068610049",
  "text" : "FACT: You cannot get #Ebola through the air, water, or food in the U.S.\nLearn more \u2192 http:\/\/t.co\/Cn45X01hMf http:\/\/t.co\/08u3hJCxTY",
  "id" : 517095132068610049,
  "created_at" : "2014-09-30 23:34:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CDC",
      "screen_name" : "CDCgov",
      "indices" : [ 3, 10 ],
      "id_str" : "146569971",
      "id" : 146569971
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 54, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517087029365338112",
  "text" : "RT @CDCgov: CDC recognizes that even a single case of #Ebola diagnosed in US raises concerns, but we've been preparing to respond http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Ebola",
        "indices" : [ 42, 48 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/wjPNZ4ROTZ",
        "expanded_url" : "http:\/\/1.usa.gov\/1nHgD2K",
        "display_url" : "1.usa.gov\/1nHgD2K"
      } ]
    },
    "geo" : { },
    "id_str" : "517085066867269632",
    "text" : "CDC recognizes that even a single case of #Ebola diagnosed in US raises concerns, but we've been preparing to respond http:\/\/t.co\/wjPNZ4ROTZ",
    "id" : 517085066867269632,
    "created_at" : "2014-09-30 22:54:21 +0000",
    "user" : {
      "name" : "CDC",
      "screen_name" : "CDCgov",
      "protected" : false,
      "id_str" : "146569971",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/748879958538321920\/iPUVbyKu_normal.jpg",
      "id" : 146569971,
      "verified" : true
    }
  },
  "id" : 517087029365338112,
  "created_at" : "2014-09-30 23:02:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/bocPMdftBW",
      "expanded_url" : "http:\/\/wh.gov\/brain",
      "display_url" : "wh.gov\/brain"
    } ]
  },
  "geo" : { },
  "id_str" : "517039047337070593",
  "text" : "We're announcing $300 million in commitments to spark the creation of tools researchers need to treat brain disease: http:\/\/t.co\/bocPMdftBW",
  "id" : 517039047337070593,
  "created_at" : "2014-09-30 19:51:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHBrain",
      "indices" : [ 93, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/oAzVVQCHpD",
      "expanded_url" : "http:\/\/wh.gov\/brain",
      "display_url" : "wh.gov\/brain"
    } ]
  },
  "geo" : { },
  "id_str" : "517033609824567296",
  "text" : "RT @whitehouseostp: LIVE at 330pm ET: Major new steps being announced toward the President's #WHBrain Initiative http:\/\/t.co\/oAzVVQCHpD htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/whitehouseostp\/status\/517027547423723520\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/35aCFaJMbG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ByzZ0B5CAAACtP3.jpg",
        "id_str" : "517027545124831232",
        "id" : 517027545124831232,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ByzZ0B5CAAACtP3.jpg",
        "sizes" : [ {
          "h" : 415,
          "resize" : "fit",
          "w" : 412
        }, {
          "h" : 415,
          "resize" : "fit",
          "w" : 412
        }, {
          "h" : 342,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 415,
          "resize" : "fit",
          "w" : 412
        } ],
        "display_url" : "pic.twitter.com\/35aCFaJMbG"
      } ],
      "hashtags" : [ {
        "text" : "WHBrain",
        "indices" : [ 73, 81 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/oAzVVQCHpD",
        "expanded_url" : "http:\/\/wh.gov\/brain",
        "display_url" : "wh.gov\/brain"
      } ]
    },
    "geo" : { },
    "id_str" : "517027547423723520",
    "text" : "LIVE at 330pm ET: Major new steps being announced toward the President's #WHBrain Initiative http:\/\/t.co\/oAzVVQCHpD http:\/\/t.co\/35aCFaJMbG",
    "id" : 517027547423723520,
    "created_at" : "2014-09-30 19:05:47 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 517033609824567296,
  "created_at" : "2014-09-30 19:29:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "indices" : [ 3, 12 ],
      "id_str" : "1604366701",
      "id" : 1604366701
    }, {
      "name" : "NYC Mayor's Office",
      "screen_name" : "NYCMayorsOffice",
      "indices" : [ 61, 77 ],
      "id_str" : "55338739",
      "id" : 55338739
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 26, 39 ]
    }, {
      "text" : "LivingWage",
      "indices" : [ 97, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517006183509786624",
  "text" : "RT @LaborSec: Momentum to #RaiseTheWage continues: I applaud @NYCMayorsOffice for increasing the #LivingWage and expanding it to thousands \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NYC Mayor's Office",
        "screen_name" : "NYCMayorsOffice",
        "indices" : [ 47, 63 ],
        "id_str" : "55338739",
        "id" : 55338739
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RaiseTheWage",
        "indices" : [ 12, 25 ]
      }, {
        "text" : "LivingWage",
        "indices" : [ 83, 94 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "516998923584811009",
    "text" : "Momentum to #RaiseTheWage continues: I applaud @NYCMayorsOffice for increasing the #LivingWage and expanding it to thousands more workers.",
    "id" : 516998923584811009,
    "created_at" : "2014-09-30 17:12:03 +0000",
    "user" : {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "protected" : false,
      "id_str" : "1604366701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744887280666611712\/eEeyFjs6_normal.jpg",
      "id" : 1604366701,
      "verified" : true
    }
  },
  "id" : 517006183509786624,
  "created_at" : "2014-09-30 17:40:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyBrothersKeeper",
      "indices" : [ 49, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "516996400081813504",
  "text" : "RT @vj44: 135+ communities have signed on to the #MyBrothersKeeper Community Challenge. Learn more and get engaged at: http:\/\/t.co\/PopydykQ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MyBrothersKeeper",
        "indices" : [ 39, 56 ]
      } ],
      "urls" : [ {
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/PopydykQD8",
        "expanded_url" : "http:\/\/mbkchallenge.org",
        "display_url" : "mbkchallenge.org"
      } ]
    },
    "geo" : { },
    "id_str" : "516992285121445888",
    "text" : "135+ communities have signed on to the #MyBrothersKeeper Community Challenge. Learn more and get engaged at: http:\/\/t.co\/PopydykQD8",
    "id" : 516992285121445888,
    "created_at" : "2014-09-30 16:45:40 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 516996400081813504,
  "created_at" : "2014-09-30 17:02:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/Ma3zWqpx14",
      "expanded_url" : "http:\/\/go.wh.gov\/36koJN",
      "display_url" : "go.wh.gov\/36koJN"
    } ]
  },
  "geo" : { },
  "id_str" : "516990873129984000",
  "text" : "President Obama will keep calling for commonsense steps Congress can take right now to help create jobs and \u2191 wages: http:\/\/t.co\/Ma3zWqpx14",
  "id" : 516990873129984000,
  "created_at" : "2014-09-30 16:40:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/Ma3zWqpx14",
      "expanded_url" : "http:\/\/go.wh.gov\/36koJN",
      "display_url" : "go.wh.gov\/36koJN"
    } ]
  },
  "geo" : { },
  "id_str" : "516986900633378816",
  "text" : "Just announced: On Thursday, President Obama will lay out our strategy for building broad-based prosperity \u2192 http:\/\/t.co\/Ma3zWqpx14",
  "id" : 516986900633378816,
  "created_at" : "2014-09-30 16:24:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "516973705243926528",
  "text" : "RT @VP: From California to Maine, we\u2019re investing in community colleges to help train America\u2019s workers for in-demand jobs. http:\/\/t.co\/6Hx\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/6HxUnRVYTg",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/ready-to-work",
        "display_url" : "whitehouse.gov\/ready-to-work"
      } ]
    },
    "geo" : { },
    "id_str" : "516967422944116737",
    "text" : "From California to Maine, we\u2019re investing in community colleges to help train America\u2019s workers for in-demand jobs. http:\/\/t.co\/6HxUnRVYTg",
    "id" : 516967422944116737,
    "created_at" : "2014-09-30 15:06:53 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 516973705243926528,
  "created_at" : "2014-09-30 15:31:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/RZRrXpQqqd",
      "expanded_url" : "http:\/\/wh.gov\/ready-to-work",
      "display_url" : "wh.gov\/ready-to-work"
    } ]
  },
  "geo" : { },
  "id_str" : "516964592019582976",
  "text" : "We're partnering with hundreds of employers across the country to train low-wage workers for middle-class jobs: http:\/\/t.co\/RZRrXpQqqd",
  "id" : 516964592019582976,
  "created_at" : "2014-09-30 14:55:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peace Corps",
      "screen_name" : "PeaceCorps",
      "indices" : [ 3, 14 ],
      "id_str" : "9109712",
      "id" : 9109712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "516707739440254977",
  "text" : "RT @PeaceCorps: It only takes an hour to change your life. Search Volunteer openings &amp; apply by 9\/30 to serve abroad ASAP! http:\/\/t.co\/a2XX\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ApplyPC",
        "indices" : [ 134, 142 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/a2XX78ZLMU",
        "expanded_url" : "http:\/\/1.usa.gov\/1rYeC3N",
        "display_url" : "1.usa.gov\/1rYeC3N"
      } ]
    },
    "geo" : { },
    "id_str" : "516697851632836609",
    "text" : "It only takes an hour to change your life. Search Volunteer openings &amp; apply by 9\/30 to serve abroad ASAP! http:\/\/t.co\/a2XX78ZLMU #ApplyPC",
    "id" : 516697851632836609,
    "created_at" : "2014-09-29 21:15:42 +0000",
    "user" : {
      "name" : "Peace Corps",
      "screen_name" : "PeaceCorps",
      "protected" : false,
      "id_str" : "9109712",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/737985331815841793\/YS-240sx_normal.jpg",
      "id" : 9109712,
      "verified" : true
    }
  },
  "id" : 516707739440254977,
  "created_at" : "2014-09-29 21:54:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "60 Minutes",
      "screen_name" : "60Minutes",
      "indices" : [ 82, 92 ],
      "id_str" : "18812572",
      "id" : 18812572
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/516669466059735040\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/Y1VPhNBpao",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ByuUJC_IIAEhgBz.jpg",
      "id_str" : "516669465405431809",
      "id" : 516669465405431809,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ByuUJC_IIAEhgBz.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Y1VPhNBpao"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/XvkRZQu17w",
      "expanded_url" : "http:\/\/cbsn.ws\/Zkmmka",
      "display_url" : "cbsn.ws\/Zkmmka"
    } ]
  },
  "geo" : { },
  "id_str" : "516669466059735040",
  "text" : "\"The place to invest isn't in China. It's the United States.\" \u2014President Obama on @60Minutes: http:\/\/t.co\/XvkRZQu17w http:\/\/t.co\/Y1VPhNBpao",
  "id" : 516669466059735040,
  "created_at" : "2014-09-29 19:22:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "516661145667915776",
  "text" : "RT @VP: Here\u2019s the mission \u2192 we need to widen the path to the middle class by expanding opportunities for America\u2019s workers. http:\/\/t.co\/3H\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/516659418902315008\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/3HBG3tca6F",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ByuLAERCMAAVb2Y.png",
        "id_str" : "516659415525502976",
        "id" : 516659415525502976,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ByuLAERCMAAVb2Y.png",
        "sizes" : [ {
          "h" : 401,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 685,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 840,
          "resize" : "fit",
          "w" : 1256
        } ],
        "display_url" : "pic.twitter.com\/3HBG3tca6F"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "516659418902315008",
    "text" : "Here\u2019s the mission \u2192 we need to widen the path to the middle class by expanding opportunities for America\u2019s workers. http:\/\/t.co\/3HBG3tca6F",
    "id" : 516659418902315008,
    "created_at" : "2014-09-29 18:42:59 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 516661145667915776,
  "created_at" : "2014-09-29 18:49:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/al55ioKQsr",
      "expanded_url" : "http:\/\/wh.gov\/ready-to-work",
      "display_url" : "wh.gov\/ready-to-work"
    } ]
  },
  "geo" : { },
  "id_str" : "516651159822430210",
  "text" : "We're helping 270 community colleges expand job-driven training programs. Find out which ones are in your state: http:\/\/t.co\/al55ioKQsr",
  "id" : 516651159822430210,
  "created_at" : "2014-09-29 18:10:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/516641133829439488\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/eFpG2pMtlf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BytyR9GIUAAyRud.jpg",
      "id_str" : "516632235047669760",
      "id" : 516632235047669760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BytyR9GIUAAyRud.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/eFpG2pMtlf"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/XYFAAPrM5O",
      "expanded_url" : "http:\/\/cbsn.ws\/Zkmmka",
      "display_url" : "cbsn.ws\/Zkmmka"
    } ]
  },
  "geo" : { },
  "id_str" : "516641133829439488",
  "text" : "\"We've had the longest run of uninterrupted private-sector job growth in our history\" \u2014Obama: http:\/\/t.co\/XYFAAPrM5O http:\/\/t.co\/eFpG2pMtlf",
  "id" : 516641133829439488,
  "created_at" : "2014-09-29 17:30:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/OtPIUPjfRC",
      "expanded_url" : "http:\/\/wh.gov\/ready-to-work",
      "display_url" : "wh.gov\/ready-to-work"
    } ]
  },
  "geo" : { },
  "id_str" : "516631721656467456",
  "text" : "RT @VP: We're helping community colleges expand job-driven training programs. See which are near you \u2192 http:\/\/t.co\/OtPIUPjfRC http:\/\/t.co\/U\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/VP\/status\/516629794759643136\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/UKKAyQ8rxi",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BytwDrGCAAABA-m.png",
        "id_str" : "516629790673993728",
        "id" : 516629790673993728,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BytwDrGCAAABA-m.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 635,
          "resize" : "fit",
          "w" : 739
        }, {
          "h" : 635,
          "resize" : "fit",
          "w" : 739
        }, {
          "h" : 516,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 292,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/UKKAyQ8rxi"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/OtPIUPjfRC",
        "expanded_url" : "http:\/\/wh.gov\/ready-to-work",
        "display_url" : "wh.gov\/ready-to-work"
      } ]
    },
    "geo" : { },
    "id_str" : "516629794759643136",
    "text" : "We're helping community colleges expand job-driven training programs. See which are near you \u2192 http:\/\/t.co\/OtPIUPjfRC http:\/\/t.co\/UKKAyQ8rxi",
    "id" : 516629794759643136,
    "created_at" : "2014-09-29 16:45:16 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 516631721656467456,
  "created_at" : "2014-09-29 16:52:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "516628020938170368",
  "text" : "RT @VP: \"In order for us to keep our place in the world\u2026we need the best trained, most advanced and skilled workforce in the world.\" -VP Bi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "516623959463563264",
    "text" : "\"In order for us to keep our place in the world\u2026we need the best trained, most advanced and skilled workforce in the world.\" -VP Biden",
    "id" : 516623959463563264,
    "created_at" : "2014-09-29 16:22:05 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 516628020938170368,
  "created_at" : "2014-09-29 16:38:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/XYFAAPrM5O",
      "expanded_url" : "http:\/\/cbsn.ws\/Zkmmka",
      "display_url" : "cbsn.ws\/Zkmmka"
    } ]
  },
  "geo" : { },
  "id_str" : "516626024558112771",
  "text" : "\"When I came into office, our economy was in crisis. We had unemployment up at 10%. It's now down to 6.1.\" \u2014Obama: http:\/\/t.co\/XYFAAPrM5O",
  "id" : 516626024558112771,
  "created_at" : "2014-09-29 16:30:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "60 Minutes",
      "screen_name" : "60Minutes",
      "indices" : [ 104, 114 ],
      "id_str" : "18812572",
      "id" : 18812572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/lTQ0RO6PAA",
      "expanded_url" : "http:\/\/cbsn.ws\/1vqRqcG",
      "display_url" : "cbsn.ws\/1vqRqcG"
    } ]
  },
  "geo" : { },
  "id_str" : "516618490292092928",
  "text" : "\"America leads. We are the indispensable nation. We have capacity no one else has.\" \u2014President Obama on @60Minutes: http:\/\/t.co\/lTQ0RO6PAA",
  "id" : 516618490292092928,
  "created_at" : "2014-09-29 16:00:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 3, 11 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 23, 26 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "516610356844978177",
  "text" : "RT @DrBiden: Watch the @VP announce how community colleges can build the best-educated, most competitive workforce in the world \u2192 http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 10, 13 ],
        "id_str" : "325830217",
        "id" : 325830217
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/SREktl0F78",
        "expanded_url" : "http:\/\/go.wh.gov\/hWqgEn",
        "display_url" : "go.wh.gov\/hWqgEn"
      } ]
    },
    "geo" : { },
    "id_str" : "516607513538875392",
    "text" : "Watch the @VP announce how community colleges can build the best-educated, most competitive workforce in the world \u2192 http:\/\/t.co\/SREktl0F78",
    "id" : 516607513538875392,
    "created_at" : "2014-09-29 15:16:43 +0000",
    "user" : {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "protected" : false,
      "id_str" : "1281405877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608687663034474496\/wvzVG_yt_normal.jpg",
      "id" : 1281405877,
      "verified" : true
    }
  },
  "id" : 516610356844978177,
  "created_at" : "2014-09-29 15:28:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "516606037806555137",
  "text" : "RT @VP: Today is a big day. We\u2019re announcing the community colleges that won $450 million in grants to help America's workers http:\/\/t.co\/U\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/UPdyKiAVDQ",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/the-press-office\/2014\/09\/29\/fact-sheet-vice-president-biden-announces-recipients-450-million-job-dri",
        "display_url" : "whitehouse.gov\/the-press-offi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "516603768281243648",
    "text" : "Today is a big day. We\u2019re announcing the community colleges that won $450 million in grants to help America's workers http:\/\/t.co\/UPdyKiAVDQ",
    "id" : 516603768281243648,
    "created_at" : "2014-09-29 15:01:51 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 516606037806555137,
  "created_at" : "2014-09-29 15:10:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 10, 13 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "indices" : [ 15, 24 ],
      "id_str" : "1604366701",
      "id" : 1604366701
    }, {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 31, 42 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/Cp8uuJSrvc",
      "expanded_url" : "http:\/\/go.wh.gov\/hWqgEn",
      "display_url" : "go.wh.gov\/hWqgEn"
    } ]
  },
  "geo" : { },
  "id_str" : "516603110580834304",
  "text" : "Watch the @VP, @LaborSec &amp; @ArneDuncan announce job-training grants for community colleges in every state at 11am ET: http:\/\/t.co\/Cp8uuJSrvc",
  "id" : 516603110580834304,
  "created_at" : "2014-09-29 14:59:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/516596378882301952\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/vYR82rpEJX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BytRq08IMAECqQ7.jpg",
      "id_str" : "516596378471247873",
      "id" : 516596378471247873,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BytRq08IMAECqQ7.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/vYR82rpEJX"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/DijprjBaq6",
      "expanded_url" : "http:\/\/cbsn.ws\/1vqRqcG",
      "display_url" : "cbsn.ws\/1vqRqcG"
    } ]
  },
  "geo" : { },
  "id_str" : "516596378882301952",
  "text" : "\"That's how we roll. That's what makes this America.\" \u2014Obama on U.S. leadership in the world: http:\/\/t.co\/DijprjBaq6 http:\/\/t.co\/vYR82rpEJX",
  "id" : 516596378882301952,
  "created_at" : "2014-09-29 14:32:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/NmIFHpIiNo",
      "expanded_url" : "http:\/\/www.cbsnews.com\/news\/president-obama-60-minutes\/",
      "display_url" : "cbsnews.com\/news\/president\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "516582367889461248",
  "text" : "\"When trouble comes up anywhere in the world, they don't call Beijing. They don't call Moscow. They call us.\" \u2014Obama: http:\/\/t.co\/NmIFHpIiNo",
  "id" : 516582367889461248,
  "created_at" : "2014-09-29 13:36:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/SrGRLwY9EF",
      "expanded_url" : "http:\/\/go.wh.gov\/pwwT8i",
      "display_url" : "go.wh.gov\/pwwT8i"
    } ]
  },
  "geo" : { },
  "id_str" : "516391935435472898",
  "text" : "\"America is engaging more partners and allies than ever to confront the growing threat of climate change.\" \u2014Obama: http:\/\/t.co\/SrGRLwY9EF",
  "id" : 516391935435472898,
  "created_at" : "2014-09-29 01:00:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "60 Minutes",
      "screen_name" : "60Minutes",
      "indices" : [ 3, 13 ],
      "id_str" : "18812572",
      "id" : 18812572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "516389337483968512",
  "text" : "RT @60Minutes: \"We've had the longest run of uninterrupted private sector job growth in our history. We have seen deficits cut by more than\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "516373707049426945",
    "text" : "\"We've had the longest run of uninterrupted private sector job growth in our history. We have seen deficits cut by more than half.\"-- Obama",
    "id" : 516373707049426945,
    "created_at" : "2014-09-28 23:47:40 +0000",
    "user" : {
      "name" : "60 Minutes",
      "screen_name" : "60Minutes",
      "protected" : false,
      "id_str" : "18812572",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/463397772071165953\/n_-jHyIO_normal.jpeg",
      "id" : 18812572,
      "verified" : true
    }
  },
  "id" : 516389337483968512,
  "created_at" : "2014-09-29 00:49:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "516382384191967233",
  "text" : "RT @pfeiffer44: Obama on CBS:\"When trouble comes up anywhere in the world, they don't call Beijing, they don't call Moscow. They call us\u2026th\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "516367018136973314",
    "text" : "Obama on CBS:\"When trouble comes up anywhere in the world, they don't call Beijing, they don't call Moscow. They call us\u2026that's how we roll\"",
    "id" : 516367018136973314,
    "created_at" : "2014-09-28 23:21:05 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 516382384191967233,
  "created_at" : "2014-09-29 00:22:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/SrGRLwY9EF",
      "expanded_url" : "http:\/\/go.wh.gov\/pwwT8i",
      "display_url" : "go.wh.gov\/pwwT8i"
    } ]
  },
  "geo" : { },
  "id_str" : "516248523096866816",
  "text" : "\"We\u2019re deploying our doctors and scientists\u2014supported by our military\u2014to help corral the outbreak.\" \u2014Obama on Ebola: http:\/\/t.co\/SrGRLwY9EF",
  "id" : 516248523096866816,
  "created_at" : "2014-09-28 15:30:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 56, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/SrGRLwY9EF",
      "expanded_url" : "http:\/\/go.wh.gov\/pwwT8i",
      "display_url" : "go.wh.gov\/pwwT8i"
    } ]
  },
  "geo" : { },
  "id_str" : "516225860693544961",
  "text" : "\"America is leading the fight to contain and combat the #Ebola epidemic in West Africa.\" \u2014President Obama: http:\/\/t.co\/SrGRLwY9EF",
  "id" : 516225860693544961,
  "created_at" : "2014-09-28 14:00:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/SrGRLwY9EF",
      "expanded_url" : "http:\/\/go.wh.gov\/pwwT8i",
      "display_url" : "go.wh.gov\/pwwT8i"
    } ]
  },
  "geo" : { },
  "id_str" : "515901207626256385",
  "text" : "\"We will support the people of Ukraine as they develop their democracy and economy.\" \u2014President Obama: http:\/\/t.co\/SrGRLwY9EF",
  "id" : 515901207626256385,
  "created_at" : "2014-09-27 16:30:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/SrGRLwY9EF",
      "expanded_url" : "http:\/\/go.wh.gov\/pwwT8i",
      "display_url" : "go.wh.gov\/pwwT8i"
    } ]
  },
  "geo" : { },
  "id_str" : "515886122937753600",
  "text" : "\"America is leading the effort to rally the world against Russian aggression in Ukraine.\" \u2014President Obama: http:\/\/t.co\/SrGRLwY9EF",
  "id" : 515886122937753600,
  "created_at" : "2014-09-27 15:30:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/515867898951507968\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/Ms7cs3y1Am",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Byi7HspCIAAlOef.jpg",
      "id_str" : "515867898250665984",
      "id" : 515867898250665984,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Byi7HspCIAAlOef.jpg",
      "sizes" : [ {
        "h" : 540,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 540,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Ms7cs3y1Am"
    } ],
    "hashtags" : [ {
      "text" : "NPLD",
      "indices" : [ 111, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "515871726262308864",
  "text" : "RT @Interior: Happy National Public Lands Day! We're celebrating by waiving entrance fees for all public lands #NPLD http:\/\/t.co\/Ms7cs3y1Am",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/515867898951507968\/photo\/1",
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/Ms7cs3y1Am",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Byi7HspCIAAlOef.jpg",
        "id_str" : "515867898250665984",
        "id" : 515867898250665984,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Byi7HspCIAAlOef.jpg",
        "sizes" : [ {
          "h" : 540,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 540,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/Ms7cs3y1Am"
      } ],
      "hashtags" : [ {
        "text" : "NPLD",
        "indices" : [ 97, 102 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "515867898951507968",
    "text" : "Happy National Public Lands Day! We're celebrating by waiving entrance fees for all public lands #NPLD http:\/\/t.co\/Ms7cs3y1Am",
    "id" : 515867898951507968,
    "created_at" : "2014-09-27 14:17:46 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 515871726262308864,
  "created_at" : "2014-09-27 14:32:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/qJPDIxdDtJ",
      "expanded_url" : "http:\/\/publiclandsday.org",
      "display_url" : "publiclandsday.org"
    } ]
  },
  "geo" : { },
  "id_str" : "515869279280181248",
  "text" : "RT @Podesta44: Find a beautiful spot near you to celebrate Natl Public Lands Day today. Entry fees are waived http:\/\/t.co\/qJPDIxdDtJ http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Podesta44\/status\/515866620250836992\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/ZKbPuXtKDG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Byi59QUIgAArxzC.png",
        "id_str" : "515866619336491008",
        "id" : 515866619336491008,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Byi59QUIgAArxzC.png",
        "sizes" : [ {
          "h" : 436,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 693,
          "resize" : "fit",
          "w" : 953
        }, {
          "h" : 247,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 693,
          "resize" : "fit",
          "w" : 953
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/ZKbPuXtKDG"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/qJPDIxdDtJ",
        "expanded_url" : "http:\/\/publiclandsday.org",
        "display_url" : "publiclandsday.org"
      } ]
    },
    "geo" : { },
    "id_str" : "515866620250836992",
    "text" : "Find a beautiful spot near you to celebrate Natl Public Lands Day today. Entry fees are waived http:\/\/t.co\/qJPDIxdDtJ http:\/\/t.co\/ZKbPuXtKDG",
    "id" : 515866620250836992,
    "created_at" : "2014-09-27 14:12:41 +0000",
    "user" : {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "protected" : false,
      "id_str" : "2382117350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656551411145027584\/ArrSlGUP_normal.jpg",
      "id" : 2382117350,
      "verified" : true
    }
  },
  "id" : 515869279280181248,
  "created_at" : "2014-09-27 14:23:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/awY17Xk5zh",
      "expanded_url" : "http:\/\/go.wh.gov\/pwwT8i",
      "display_url" : "go.wh.gov\/pwwT8i"
    } ]
  },
  "geo" : { },
  "id_str" : "515863122729762817",
  "text" : "\"America is leading the world in the fight to degrade &amp; ultimately destroy the terrorist group known as ISIL\" \u2014Obama: http:\/\/t.co\/awY17Xk5zh",
  "id" : 515863122729762817,
  "created_at" : "2014-09-27 13:58:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DidYouKnow",
      "indices" : [ 14, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "515625000100184064",
  "text" : "RT @Interior: #DidYouKnow: Tomorrow you can visit all parks, wildlife refuges &amp; public lands for free. RT to spread the word! http:\/\/t.co\/a\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Interior\/status\/515616807999524864\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/arXhXmuzcu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ByfWwOhCMAA4G0u.jpg",
        "id_str" : "515616806375927808",
        "id" : 515616806375927808,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ByfWwOhCMAA4G0u.jpg",
        "sizes" : [ {
          "h" : 749,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1498,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 439,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 249,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/arXhXmuzcu"
      } ],
      "hashtags" : [ {
        "text" : "DidYouKnow",
        "indices" : [ 0, 11 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "515616807999524864",
    "text" : "#DidYouKnow: Tomorrow you can visit all parks, wildlife refuges &amp; public lands for free. RT to spread the word! http:\/\/t.co\/arXhXmuzcu",
    "id" : 515616807999524864,
    "created_at" : "2014-09-26 21:40:01 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 515625000100184064,
  "created_at" : "2014-09-26 22:12:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jack Johnson",
      "screen_name" : "jackjohnson",
      "indices" : [ 3, 15 ],
      "id_str" : "61898653",
      "id" : 61898653
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 19, 32 ]
    }, {
      "text" : "climate2014",
      "indices" : [ 103, 115 ]
    }, {
      "text" : "AAOLocalFood",
      "indices" : [ 117, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "515612529092227072",
  "text" : "RT @jackjohnson: I #ActOnClimate by buying local food and reducing the distance my food has to travel. #climate2014  #AAOLocalFood http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jackjohnson\/status\/514503162615857152\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/1pVGm0xDqC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ByPh5kSIEAA1VvU.jpg",
        "id_str" : "514503161558863872",
        "id" : 514503161558863872,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ByPh5kSIEAA1VvU.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 427
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 427
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 427
        } ],
        "display_url" : "pic.twitter.com\/1pVGm0xDqC"
      } ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 2, 15 ]
      }, {
        "text" : "climate2014",
        "indices" : [ 86, 98 ]
      }, {
        "text" : "AAOLocalFood",
        "indices" : [ 100, 113 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "514503162615857152",
    "text" : "I #ActOnClimate by buying local food and reducing the distance my food has to travel. #climate2014  #AAOLocalFood http:\/\/t.co\/1pVGm0xDqC",
    "id" : 514503162615857152,
    "created_at" : "2014-09-23 19:54:47 +0000",
    "user" : {
      "name" : "Jack Johnson",
      "screen_name" : "jackjohnson",
      "protected" : false,
      "id_str" : "61898653",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/428239392935649281\/2sa5QA3e_normal.jpeg",
      "id" : 61898653,
      "verified" : true
    }
  },
  "id" : 515612529092227072,
  "created_at" : "2014-09-26 21:23:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/515567743262015488\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/xsuRNsaZfB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ByeqIWIIEAAjP6u.png",
      "id_str" : "515567742712549376",
      "id" : 515567742712549376,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ByeqIWIIEAAjP6u.png",
      "sizes" : [ {
        "h" : 334,
        "resize" : "fit",
        "w" : 812
      }, {
        "h" : 140,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 334,
        "resize" : "fit",
        "w" : 812
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 247,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/xsuRNsaZfB"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/NNLD2CXJtf",
      "expanded_url" : "http:\/\/go.wh.gov\/FqC5Kp",
      "display_url" : "go.wh.gov\/FqC5Kp"
    } ]
  },
  "geo" : { },
  "id_str" : "515587687596965888",
  "text" : "FACT: Corporate inverters will cost Americans nearly $20 billion over the next 10 years \u2192 http:\/\/t.co\/NNLD2CXJtf http:\/\/t.co\/xsuRNsaZfB",
  "id" : 515587687596965888,
  "created_at" : "2014-09-26 19:44:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/515567743262015488\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/xsuRNsaZfB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ByeqIWIIEAAjP6u.png",
      "id_str" : "515567742712549376",
      "id" : 515567742712549376,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ByeqIWIIEAAjP6u.png",
      "sizes" : [ {
        "h" : 334,
        "resize" : "fit",
        "w" : 812
      }, {
        "h" : 140,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 334,
        "resize" : "fit",
        "w" : 812
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 247,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/xsuRNsaZfB"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/NNLD2CXJtf",
      "expanded_url" : "http:\/\/go.wh.gov\/FqC5Kp",
      "display_url" : "go.wh.gov\/FqC5Kp"
    } ]
  },
  "geo" : { },
  "id_str" : "515567743262015488",
  "text" : "RT if you agree: You don't get to pick your tax rate, and neither should corporations \u2192 http:\/\/t.co\/NNLD2CXJtf http:\/\/t.co\/xsuRNsaZfB",
  "id" : 515567743262015488,
  "created_at" : "2014-09-26 18:25:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sylvia Burwell",
      "screen_name" : "SecBurwell",
      "indices" : [ 3, 14 ],
      "id_str" : "2458567464",
      "id" : 2458567464
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 24, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "515560018528448512",
  "text" : "RT @SecBurwell: In 1 yr #ACA has reduced # of uninsured adults by 26%. 50 DAYS - the countdown to start of 2014\/2015 Open Enrollment begins\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ACA",
        "indices" : [ 8, 12 ]
      }, {
        "text" : "GetCovered",
        "indices" : [ 125, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "515512120897970176",
    "text" : "In 1 yr #ACA has reduced # of uninsured adults by 26%. 50 DAYS - the countdown to start of 2014\/2015 Open Enrollment begins! #GetCovered",
    "id" : 515512120897970176,
    "created_at" : "2014-09-26 14:44:02 +0000",
    "user" : {
      "name" : "Sylvia Burwell",
      "screen_name" : "SecBurwell",
      "protected" : false,
      "id_str" : "2458567464",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567351512351793152\/jMgeUhVq_normal.jpeg",
      "id" : 2458567464,
      "verified" : true
    }
  },
  "id" : 515560018528448512,
  "created_at" : "2014-09-26 17:54:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/515548967384653824\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/ftNxsaBaoP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ByeZDciIcAAqoJ9.jpg",
      "id_str" : "515548966835220480",
      "id" : 515548966835220480,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ByeZDciIcAAqoJ9.jpg",
      "sizes" : [ {
        "h" : 248,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 379,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 379,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 379,
        "resize" : "fit",
        "w" : 520
      } ],
      "display_url" : "pic.twitter.com\/ftNxsaBaoP"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/EImyEuoTVD",
      "expanded_url" : "http:\/\/go.wh.gov\/c78m6o",
      "display_url" : "go.wh.gov\/c78m6o"
    } ]
  },
  "geo" : { },
  "id_str" : "515548967384653824",
  "text" : "FACT: Our economy grew at a 4.6% rate last quarter, the fastest growth rate since 2011 \u2192 http:\/\/t.co\/EImyEuoTVD http:\/\/t.co\/ftNxsaBaoP",
  "id" : 515548967384653824,
  "created_at" : "2014-09-26 17:10:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 110, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "515533961616162817",
  "text" : "\u201CIt is our moral obligation and it is in our national self interest to help them\u201D \u2014Obama on responding to the #Ebola epidemic in West Africa",
  "id" : 515533961616162817,
  "created_at" : "2014-09-26 16:10:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 83, 89 ]
    }, {
      "text" : "GHSAgenda",
      "indices" : [ 90, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "515532609380950016",
  "text" : "\"No community should be left at the mercy of a horrific disease.\" \u2014President Obama #Ebola #GHSAgenda",
  "id" : 515532609380950016,
  "created_at" : "2014-09-26 16:05:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 132, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "515532460726435840",
  "text" : "\"No one should ever have to die for lack of an isolation tent or a treatment bed, as is happening in West Africa.\" \u2014President Obama #Ebola",
  "id" : 515532460726435840,
  "created_at" : "2014-09-26 16:04:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GHSAgenda",
      "indices" : [ 121, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "515532285605855232",
  "text" : "RT @WHLive: \"We\u2019re issuing a challenge...to design better protective solutions for our health workers.\" \u2014President Obama #GHSAgenda",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GHSAgenda",
        "indices" : [ 109, 119 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "515532241435652097",
    "text" : "\"We\u2019re issuing a challenge...to design better protective solutions for our health workers.\" \u2014President Obama #GHSAgenda",
    "id" : 515532241435652097,
    "created_at" : "2014-09-26 16:03:59 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 515532285605855232,
  "created_at" : "2014-09-26 16:04:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 132, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "515531640123424768",
  "text" : "\"We\u2019ve got to make sure we never see a tragedy on this scale again.\" \u2014Obama on improving response efforts to diseases and outbreaks #Ebola",
  "id" : 515531640123424768,
  "created_at" : "2014-09-26 16:01:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 128, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "515530607330619393",
  "text" : "\"We have to change our mindsets and start thinking about biological threats as the security threats they are.\" \u2014President Obama #Ebola",
  "id" : 515530607330619393,
  "created_at" : "2014-09-26 15:57:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GHSAgenda",
      "indices" : [ 116, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "515530477466574848",
  "text" : "\"All of us\u2014as nations, and as an international community\u2014need to do more to keep our people safe.\" \u2014President Obama #GHSAgenda",
  "id" : 515530477466574848,
  "created_at" : "2014-09-26 15:56:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 124, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "515530228673052672",
  "text" : "\"Outbreaks anywhere, even in\u2026the most remote corners of the world, have the potential to impact everybody\" \u2014President Obama #Ebola",
  "id" : 515530228673052672,
  "created_at" : "2014-09-26 15:55:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 120, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/5Nxms6YFyU",
      "expanded_url" : "http:\/\/go.wh.gov\/9Qizg9",
      "display_url" : "go.wh.gov\/9Qizg9"
    } ]
  },
  "geo" : { },
  "id_str" : "515529794650247168",
  "text" : "\"Fighting this epidemic is a national security priority of the United States.\" \u2014President Obama: http:\/\/t.co\/5Nxms6YFyU #Ebola",
  "id" : 515529794650247168,
  "created_at" : "2014-09-26 15:54:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "515529682465591296",
  "text" : "RT @WHLive: \"If left unchecked, experts predict that hundreds of thousands of people could be killed\u2014in a matter of months.\" \u2014President Oba\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Ebola",
        "indices" : [ 130, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "515529641675984896",
    "text" : "\"If left unchecked, experts predict that hundreds of thousands of people could be killed\u2014in a matter of months.\" \u2014President Obama #Ebola",
    "id" : 515529641675984896,
    "created_at" : "2014-09-26 15:53:39 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 515529682465591296,
  "created_at" : "2014-09-26 15:53:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 105, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "515529460733734913",
  "text" : "\"Today, of course, our thoughts and prayers are with the people of West Africa.\" \u2014President Obama on the #Ebola epidemic",
  "id" : 515529460733734913,
  "created_at" : "2014-09-26 15:52:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GHSAgenda",
      "indices" : [ 112, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/8rqojOaA5V",
      "expanded_url" : "http:\/\/go.wh.gov\/eGfAeV",
      "display_url" : "go.wh.gov\/eGfAeV"
    } ]
  },
  "geo" : { },
  "id_str" : "515529302574911488",
  "text" : "Happening now: Watch President Obama speak at the Global Health Security Agenda Summit \u2192 http:\/\/t.co\/8rqojOaA5V #GHSAgenda",
  "id" : 515529302574911488,
  "created_at" : "2014-09-26 15:52:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GHSAgenda",
      "indices" : [ 119, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/v0tJxj02xd",
      "expanded_url" : "http:\/\/go.wh.gov\/eGfAeV",
      "display_url" : "go.wh.gov\/eGfAeV"
    } ]
  },
  "geo" : { },
  "id_str" : "515528203692441600",
  "text" : "RT @WHLive: Starting soon: President Obama speaks at the Global Health Security Agenda Summit \u2192 http:\/\/t.co\/v0tJxj02xd #GHSAgenda",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GHSAgenda",
        "indices" : [ 107, 117 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/v0tJxj02xd",
        "expanded_url" : "http:\/\/go.wh.gov\/eGfAeV",
        "display_url" : "go.wh.gov\/eGfAeV"
      } ]
    },
    "geo" : { },
    "id_str" : "515528177964556288",
    "text" : "Starting soon: President Obama speaks at the Global Health Security Agenda Summit \u2192 http:\/\/t.co\/v0tJxj02xd #GHSAgenda",
    "id" : 515528177964556288,
    "created_at" : "2014-09-26 15:47:50 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 515528203692441600,
  "created_at" : "2014-09-26 15:47:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "We the People",
      "screen_name" : "wethepeople",
      "indices" : [ 94, 106 ],
      "id_str" : "369507958",
      "id" : 369507958
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/Mnv4IOyhdY",
      "expanded_url" : "http:\/\/go.wh.gov\/NDH26i",
      "display_url" : "go.wh.gov\/NDH26i"
    } ]
  },
  "geo" : { },
  "id_str" : "515513395425316865",
  "text" : "3 years.\n15 million users.\nMore than 22 million signatures.\nHere's a look back at the best of @WeThePeople \u2192 http:\/\/t.co\/Mnv4IOyhdY",
  "id" : 515513395425316865,
  "created_at" : "2014-09-26 14:49:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "515271270322425856",
  "text" : "RT @VP: Eric Holder is a good friend, a great public servant, and an outstanding attorney general. Most importantly, a man of great charact\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "515264287175356416",
    "text" : "Eric Holder is a good friend, a great public servant, and an outstanding attorney general. Most importantly, a man of great character. -VP",
    "id" : 515264287175356416,
    "created_at" : "2014-09-25 22:19:13 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 515271270322425856,
  "created_at" : "2014-09-25 22:46:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kori Schulman",
      "screen_name" : "ks44",
      "indices" : [ 3, 8 ],
      "id_str" : "369246180",
      "id" : 369246180
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 32, 43 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ks44\/status\/515223306300325888\/photo\/1",
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/0fsFYvF21X",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ByZw3aHIYAIRsLk.jpg",
      "id_str" : "515223304584847362",
      "id" : 515223304584847362,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ByZw3aHIYAIRsLk.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/0fsFYvF21X"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/FprDYNUots",
      "expanded_url" : "http:\/\/go.wh.gov\/Mrin7t",
      "display_url" : "go.wh.gov\/Mrin7t"
    } ]
  },
  "geo" : { },
  "id_str" : "515269018060877826",
  "text" : "RT @ks44: Want to intern at the @WhiteHouse? Apply now for summer 2015 \u2192 http:\/\/t.co\/FprDYNUots http:\/\/t.co\/0fsFYvF21X",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 22, 33 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ks44\/status\/515223306300325888\/photo\/1",
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/0fsFYvF21X",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ByZw3aHIYAIRsLk.jpg",
        "id_str" : "515223304584847362",
        "id" : 515223304584847362,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ByZw3aHIYAIRsLk.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/0fsFYvF21X"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 85 ],
        "url" : "http:\/\/t.co\/FprDYNUots",
        "expanded_url" : "http:\/\/go.wh.gov\/Mrin7t",
        "display_url" : "go.wh.gov\/Mrin7t"
      } ]
    },
    "geo" : { },
    "id_str" : "515223306300325888",
    "text" : "Want to intern at the @WhiteHouse? Apply now for summer 2015 \u2192 http:\/\/t.co\/FprDYNUots http:\/\/t.co\/0fsFYvF21X",
    "id" : 515223306300325888,
    "created_at" : "2014-09-25 19:36:23 +0000",
    "user" : {
      "name" : "Kori Schulman",
      "screen_name" : "ks44",
      "protected" : false,
      "id_str" : "369246180",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/667876153793859584\/DV7HzP-1_normal.jpg",
      "id" : 369246180,
      "verified" : true
    }
  },
  "id" : 515269018060877826,
  "created_at" : "2014-09-25 22:38:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/515257014998818816\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/eqQcnS3nvj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ByaPhj8IEAA_ijf.jpg",
      "id_str" : "515257014126383104",
      "id" : 515257014126383104,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ByaPhj8IEAA_ijf.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/eqQcnS3nvj"
    } ],
    "hashtags" : [ {
      "text" : "NPLD",
      "indices" : [ 100, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "515259097810493442",
  "text" : "RT @Interior: RT to spread the word \u2192 On Saturday entrance fees will be waived for all public lands #NPLD http:\/\/t.co\/eqQcnS3nvj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/515257014998818816\/photo\/1",
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/eqQcnS3nvj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ByaPhj8IEAA_ijf.jpg",
        "id_str" : "515257014126383104",
        "id" : 515257014126383104,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ByaPhj8IEAA_ijf.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/eqQcnS3nvj"
      } ],
      "hashtags" : [ {
        "text" : "NPLD",
        "indices" : [ 86, 91 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "515257014998818816",
    "text" : "RT to spread the word \u2192 On Saturday entrance fees will be waived for all public lands #NPLD http:\/\/t.co\/eqQcnS3nvj",
    "id" : 515257014998818816,
    "created_at" : "2014-09-25 21:50:20 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 515259097810493442,
  "created_at" : "2014-09-25 21:58:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/515256180382633984\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/Iow9YQUnwi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ByaOw_jIcAArM3N.jpg",
      "id_str" : "515256179724152832",
      "id" : 515256179724152832,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ByaOw_jIcAArM3N.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Iow9YQUnwi"
    } ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 98, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "515256180382633984",
  "text" : "FACT: This year's premium increases for job-based health coverage tied the lowest rate on record. #ACAWorks http:\/\/t.co\/Iow9YQUnwi",
  "id" : 515256180382633984,
  "created_at" : "2014-09-25 21:47:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 106, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/c3M04LB3hz",
      "expanded_url" : "http:\/\/wh.gov\/ilFrL",
      "display_url" : "wh.gov\/ilFrL"
    } ]
  },
  "geo" : { },
  "id_str" : "515249679530196993",
  "text" : "\u2193 premium increases.\n\u2191 plans with out-of-pocket limits.\nBig savings for hospitals.\nMore evidence that the #ACAWorks \u2192 http:\/\/t.co\/c3M04LB3hz",
  "id" : 515249679530196993,
  "created_at" : "2014-09-25 21:21:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "515238591065501697",
  "text" : "\"No citizen...should have to jump through hoops to exercise their most fundamental right\" \u2014Obama on Holder's efforts to defend voting rights",
  "id" : 515238591065501697,
  "created_at" : "2014-09-25 20:37:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "515238004693409793",
  "text" : "RT @WHLive: \"Thanks to [Holder's] efforts, since I took office, the overall crime rate and the overall incarceration rate have gone down\" \u2014\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "515237963685699584",
    "text" : "\"Thanks to [Holder's] efforts, since I took office, the overall crime rate and the overall incarceration rate have gone down\" \u2014Obama",
    "id" : 515237963685699584,
    "created_at" : "2014-09-25 20:34:37 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 515238004693409793,
  "created_at" : "2014-09-25 20:34:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "515237159574728705",
  "text" : "\"He believes, as I do, that justice is not just an abstract theory. It\u2019s a living and breathing principle.\" \u2014President Obama on AG Holder",
  "id" : 515237159574728705,
  "created_at" : "2014-09-25 20:31:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "515237067920793600",
  "text" : "\"He\u2019s shown a deep and abiding fidelity to one of our most cherished ideals as a people...equal justice under the law.\" \u2014Obama on AG Holder",
  "id" : 515237067920793600,
  "created_at" : "2014-09-25 20:31:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/b4tqL36eMn",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "515236611895078912",
  "text" : "Happening now: President Obama makes a personnel announcement from the White House \u2192 http:\/\/t.co\/b4tqL36eMn",
  "id" : 515236611895078912,
  "created_at" : "2014-09-25 20:29:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/K1N4zB75TR",
      "expanded_url" : "http:\/\/go.wh.gov\/oJhCkN",
      "display_url" : "go.wh.gov\/oJhCkN"
    } ]
  },
  "geo" : { },
  "id_str" : "515230905062162432",
  "text" : "Watch President Obama make a personnel announcement from the White House at 4:30pm ET \u2192 http:\/\/t.co\/K1N4zB75TR",
  "id" : 515230905062162432,
  "created_at" : "2014-09-25 20:06:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/sNle6tZbWn",
      "expanded_url" : "http:\/\/youtu.be\/kH29t9-nX48",
      "display_url" : "youtu.be\/kH29t9-nX48"
    } ]
  },
  "geo" : { },
  "id_str" : "515224244314062849",
  "text" : "\"We are heirs to a proud legacy of freedom\u2014and we\u2019re prepared to do what is necessary to secure that legacy.\" \u2014Obama: http:\/\/t.co\/sNle6tZbWn",
  "id" : 515224244314062849,
  "created_at" : "2014-09-25 19:40:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/515217625144889345\/photo\/1",
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/gaCddXtfkm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ByZrswPIIAA5eXY.jpg",
      "id_str" : "515217623987265536",
      "id" : 515217623987265536,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ByZrswPIIAA5eXY.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/gaCddXtfkm"
    } ],
    "hashtags" : [ {
      "text" : "WomenSucceed",
      "indices" : [ 5, 18 ]
    }, {
      "text" : "HeForShe",
      "indices" : [ 59, 68 ]
    } ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/GBzcbSV0MN",
      "expanded_url" : "http:\/\/heforshe.org\/#take-action",
      "display_url" : "heforshe.org\/#take-action"
    } ]
  },
  "geo" : { },
  "id_str" : "515217625144889345",
  "text" : "When #WomenSucceed, we all succeed: http:\/\/t.co\/GBzcbSV0MN #HeForShe http:\/\/t.co\/gaCddXtfkm",
  "id" : 515217625144889345,
  "created_at" : "2014-09-25 19:13:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Power",
      "screen_name" : "AmbassadorPower",
      "indices" : [ 3, 19 ],
      "id_str" : "1615463502",
      "id" : 1615463502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "515199496784191489",
  "text" : "RT @AmbassadorPower: Pres. Obama on Ebola epidemic: \"It's a marathon but you have to run it like a sprint, and that's only possible if ever\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UNGA",
        "indices" : [ 135, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "515176153821085697",
    "text" : "Pres. Obama on Ebola epidemic: \"It's a marathon but you have to run it like a sprint, and that's only possible if everybody chips in.\" #UNGA",
    "id" : 515176153821085697,
    "created_at" : "2014-09-25 16:29:01 +0000",
    "user" : {
      "name" : "Samantha Power",
      "screen_name" : "AmbassadorPower",
      "protected" : false,
      "id_str" : "1615463502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/620632341497683968\/CkFXABqQ_normal.jpg",
      "id" : 1615463502,
      "verified" : true
    }
  },
  "id" : 515199496784191489,
  "created_at" : "2014-09-25 18:01:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 126, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/7V6QbsmkUQ",
      "expanded_url" : "http:\/\/go.wh.gov\/JxdNSd",
      "display_url" : "go.wh.gov\/JxdNSd"
    } ]
  },
  "geo" : { },
  "id_str" : "515185304970739712",
  "text" : "Climate change is causing sea levels and ocean temperatures to \u2191, and President Obama's taking action: http:\/\/t.co\/7V6QbsmkUQ #ActOnClimate",
  "id" : 515185304970739712,
  "created_at" : "2014-09-25 17:05:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/7V6QbsmkUQ",
      "expanded_url" : "http:\/\/go.wh.gov\/JxdNSd",
      "display_url" : "go.wh.gov\/JxdNSd"
    } ]
  },
  "geo" : { },
  "id_str" : "515169220746051584",
  "text" : "Today, President Obama's designating the largest marine reserve in the world off-limits to development: http:\/\/t.co\/7V6QbsmkUQ #ActOnClimate",
  "id" : 515169220746051584,
  "created_at" : "2014-09-25 16:01:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 126, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/cgkGAqIzxI",
      "expanded_url" : "http:\/\/go.wh.gov\/aZzWCp",
      "display_url" : "go.wh.gov\/aZzWCp"
    } ]
  },
  "geo" : { },
  "id_str" : "515160083723210754",
  "text" : "\"We will not stop, we will not relent until we halt this epidemic once and for all.\" \u2014President Obama: http:\/\/t.co\/cgkGAqIzxI #Ebola",
  "id" : 515160083723210754,
  "created_at" : "2014-09-25 15:25:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 22, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "515159868140191744",
  "text" : "RT @WHLive: \"Stopping #Ebola is a priority for the United States...but this has to be a priority for everyone else.\" \u2014Obama: http:\/\/t.co\/Oq\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Ebola",
        "indices" : [ 10, 16 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/OqqxI6kpqt",
        "expanded_url" : "http:\/\/go.wh.gov\/aZzWCp",
        "display_url" : "go.wh.gov\/aZzWCp"
      } ]
    },
    "geo" : { },
    "id_str" : "515159834430570496",
    "text" : "\"Stopping #Ebola is a priority for the United States...but this has to be a priority for everyone else.\" \u2014Obama: http:\/\/t.co\/OqqxI6kpqt",
    "id" : 515159834430570496,
    "created_at" : "2014-09-25 15:24:10 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 515159868140191744,
  "created_at" : "2014-09-25 15:24:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 133, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/OWdfgf0ntT",
      "expanded_url" : "http:\/\/go.wh.gov\/aZzWCp",
      "display_url" : "go.wh.gov\/aZzWCp"
    } ]
  },
  "geo" : { },
  "id_str" : "515158679331811328",
  "text" : "RT @WHLive: \"Our teams are working as fast as they can to move in personnel, equipment and supplies.\" \u2014Obama: http:\/\/t.co\/OWdfgf0ntT #Ebola",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Ebola",
        "indices" : [ 121, 127 ]
      } ],
      "urls" : [ {
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/OWdfgf0ntT",
        "expanded_url" : "http:\/\/go.wh.gov\/aZzWCp",
        "display_url" : "go.wh.gov\/aZzWCp"
      } ]
    },
    "geo" : { },
    "id_str" : "515158583378337792",
    "text" : "\"Our teams are working as fast as they can to move in personnel, equipment and supplies.\" \u2014Obama: http:\/\/t.co\/OWdfgf0ntT #Ebola",
    "id" : 515158583378337792,
    "created_at" : "2014-09-25 15:19:12 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 515158679331811328,
  "created_at" : "2014-09-25 15:19:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 89, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "515158349877624832",
  "text" : "RT @WHLive: \"In an era where regional crises can quickly become global threats, stopping #Ebola is in the interests of all of us.\" \u2014Preside\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Ebola",
        "indices" : [ 77, 83 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "515158329312956416",
    "text" : "\"In an era where regional crises can quickly become global threats, stopping #Ebola is in the interests of all of us.\" \u2014President Obama",
    "id" : 515158329312956416,
    "created_at" : "2014-09-25 15:18:11 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 515158349877624832,
  "created_at" : "2014-09-25 15:18:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 109, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "515157882820894720",
  "text" : "\"If unchecked, this epidemic could kill hundreds of thousands of people in the coming months.\" \u2014Obama on the #Ebola epidemic in West Africa",
  "id" : 515157882820894720,
  "created_at" : "2014-09-25 15:16:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 133, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "515157813824602112",
  "text" : "\"The Ebola virus is spreading at alarming speed. Thousands of men, women and children have died\u2014thousands more are infected.\" \u2014Obama #Ebola",
  "id" : 515157813824602112,
  "created_at" : "2014-09-25 15:16:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "515157714897747968",
  "text" : "RT @WHLive: \"Mr. Secretary General, thank you for bringing us together today to address an urgent threat to the people of West Africa.\" \u2014Ob\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Ebola",
        "indices" : [ 131, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "515157678990307328",
    "text" : "\"Mr. Secretary General, thank you for bringing us together today to address an urgent threat to the people of West Africa.\" \u2014Obama #Ebola",
    "id" : 515157678990307328,
    "created_at" : "2014-09-25 15:15:36 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 515157714897747968,
  "created_at" : "2014-09-25 15:15:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "United Nations",
      "screen_name" : "UN",
      "indices" : [ 45, 48 ],
      "id_str" : "14159148",
      "id" : 14159148
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 64, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/b4tqL36eMn",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "515157600313569280",
  "text" : "Happening now: President Obama speaks at the @UN meeting on the #Ebola epidemic in West Africa \u2192 http:\/\/t.co\/b4tqL36eMn",
  "id" : 515157600313569280,
  "created_at" : "2014-09-25 15:15:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "United Nations",
      "screen_name" : "UN",
      "indices" : [ 35, 38 ],
      "id_str" : "14159148",
      "id" : 14159148
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 54, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/1Zby70vyD1",
      "expanded_url" : "http:\/\/go.wh.gov\/NmDYkW",
      "display_url" : "go.wh.gov\/NmDYkW"
    } ]
  },
  "geo" : { },
  "id_str" : "515148861472780288",
  "text" : "Watch President Obama speak at the @UN meeting on the #Ebola epidemic in West Africa at 11am ET \u2192 http:\/\/t.co\/1Zby70vyD1",
  "id" : 515148861472780288,
  "created_at" : "2014-09-25 14:40:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 118, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/yew4RwNdh1",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/\/the-press-office\/2014\/09\/24\/fact-sheet-president-obama-designate-largest-marine-monument-world-limit",
      "display_url" : "whitehouse.gov\/\/the-press-off\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "515132871028518912",
  "text" : "RT @Podesta44: Humpbacks can jump for joy: Today POTUS expands Pacific Remote Islands preserve http:\/\/t.co\/yew4RwNdh1 #ActOnClimate http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Podesta44\/status\/515119810854662146\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/yCxmWsjVDL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ByYQPOSIcAA_d_0.jpg",
        "id_str" : "515117061098729472",
        "id" : 515117061098729472,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ByYQPOSIcAA_d_0.jpg",
        "sizes" : [ {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 373,
          "resize" : "fit",
          "w" : 560
        }, {
          "h" : 373,
          "resize" : "fit",
          "w" : 560
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 373,
          "resize" : "fit",
          "w" : 560
        } ],
        "display_url" : "pic.twitter.com\/yCxmWsjVDL"
      } ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 103, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/yew4RwNdh1",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/\/the-press-office\/2014\/09\/24\/fact-sheet-president-obama-designate-largest-marine-monument-world-limit",
        "display_url" : "whitehouse.gov\/\/the-press-off\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "515119810854662146",
    "text" : "Humpbacks can jump for joy: Today POTUS expands Pacific Remote Islands preserve http:\/\/t.co\/yew4RwNdh1 #ActOnClimate http:\/\/t.co\/yCxmWsjVDL",
    "id" : 515119810854662146,
    "created_at" : "2014-09-25 12:45:08 +0000",
    "user" : {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "protected" : false,
      "id_str" : "2382117350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656551411145027584\/ArrSlGUP_normal.jpg",
      "id" : 2382117350,
      "verified" : true
    }
  },
  "id" : 515132871028518912,
  "created_at" : "2014-09-25 13:37:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514914575075266561",
  "text" : "RT @Benenati44: Tomorrow President Obama will designate largest marine monument in the world off-limits to development http:\/\/t.co\/zfEAogsV\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/zfEAogsVmJ",
        "expanded_url" : "http:\/\/wh.gov\/ileey",
        "display_url" : "wh.gov\/ileey"
      } ]
    },
    "geo" : { },
    "id_str" : "514914416719314944",
    "text" : "Tomorrow President Obama will designate largest marine monument in the world off-limits to development http:\/\/t.co\/zfEAogsVmJ",
    "id" : 514914416719314944,
    "created_at" : "2014-09-24 23:08:58 +0000",
    "user" : {
      "name" : "Patrick Rodenbush",
      "screen_name" : "Patrick44",
      "protected" : false,
      "id_str" : "1665386791",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798907223174946816\/KIC4Jq2Q_normal.jpg",
      "id" : 1665386791,
      "verified" : true
    }
  },
  "id" : 514914575075266561,
  "created_at" : "2014-09-24 23:09:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/Jbwl9WH17b",
      "expanded_url" : "http:\/\/youtu.be\/sBUAdVf-nU4",
      "display_url" : "youtu.be\/sBUAdVf-nU4"
    } ]
  },
  "geo" : { },
  "id_str" : "514897102879866881",
  "text" : "\u201CFrom my family to yours, Shanah Tovah\u201D \u2014President Obama wishes all those celebrating Rosh Hashanah a happy new year: http:\/\/t.co\/Jbwl9WH17b",
  "id" : 514897102879866881,
  "created_at" : "2014-09-24 22:00:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514893506268377088",
  "text" : "RT @WHLive: \"Open and honest collaboration with citizens and civil society\u2026makes countries stronger and\u2026more successful\" \u2014President Obama a\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "United Nations",
        "screen_name" : "UN",
        "indices" : [ 133, 136 ],
        "id_str" : "14159148",
        "id" : 14159148
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "514893326865432576",
    "text" : "\"Open and honest collaboration with citizens and civil society\u2026makes countries stronger and\u2026more successful\" \u2014President Obama at the @UN",
    "id" : 514893326865432576,
    "created_at" : "2014-09-24 21:45:10 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 514893506268377088,
  "created_at" : "2014-09-24 21:45:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "United Nations",
      "screen_name" : "UN",
      "indices" : [ 133, 136 ],
      "id_str" : "14159148",
      "id" : 14159148
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514891518654828545",
  "text" : "\"Throughout history, progress has always been driven by citizens who have the courage to raise their voices\" \u2014President Obama at the @UN",
  "id" : 514891518654828545,
  "created_at" : "2014-09-24 21:37:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "United Nations",
      "screen_name" : "UN",
      "indices" : [ 93, 96 ],
      "id_str" : "14159148",
      "id" : 14159148
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/b4tqL36eMn",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "514891241285500928",
  "text" : "Happening now: President Obama speaks at a meeting of the Open Government Partnership at the @UN. Watch \u2192 http:\/\/t.co\/b4tqL36eMn",
  "id" : 514891241285500928,
  "created_at" : "2014-09-24 21:36:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514856974107017216",
  "text" : "\"These terrorists believe our countries will be unable to stop them. The safety of our citizens demands that we do.\" \u2014Obama to the UNSC",
  "id" : 514856974107017216,
  "created_at" : "2014-09-24 19:20:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "United Nations",
      "screen_name" : "UN",
      "indices" : [ 124, 127 ],
      "id_str" : "14159148",
      "id" : 14159148
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514856088953692160",
  "text" : "\"Groups like ISIL betray Islam by killing innocent men, women &amp; children\u2014the majority of whom are Muslim\" \u2014Obama to the @UN Security Council",
  "id" : 514856088953692160,
  "created_at" : "2014-09-24 19:17:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514855623234949120",
  "text" : "RT @WHLive: \"The historic resolution we just adopted enshrines our commitment to meet this challenge.\" \u2014Obama on combatting foreign terrori\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "514855602712231936",
    "text" : "\"The historic resolution we just adopted enshrines our commitment to meet this challenge.\" \u2014Obama on combatting foreign terrorist fighters",
    "id" : 514855602712231936,
    "created_at" : "2014-09-24 19:15:15 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 514855623234949120,
  "created_at" : "2014-09-24 19:15:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514855301338898434",
  "text" : "\"In the Middle East &amp; elsewhere, these terrorists exacerbate conflicts, they pose an immediate threat\" \u2014Obama on foreign terrorist fighters",
  "id" : 514855301338898434,
  "created_at" : "2014-09-24 19:14:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514854946567880706",
  "text" : "\"We stand with you &amp; the French people\u2014not only as you grieve this terrible loss, but as you show resolve against terror\" \u2014Obama to Hollande",
  "id" : 514854946567880706,
  "created_at" : "2014-09-24 19:12:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514854869405282305",
  "text" : "\"Today, the people of the world have been horrified by another brutal murder\u2014of Herve Gourdel by terrorists in Algeria.\" \u2014President Obama",
  "id" : 514854869405282305,
  "created_at" : "2014-09-24 19:12:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514854721275060224",
  "text" : "\"I called this meeting because we must come together...to confront the real and growing threat of foreign terrorist fighters.\" \u2014Obama",
  "id" : 514854721275060224,
  "created_at" : "2014-09-24 19:11:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "United Nations",
      "screen_name" : "UN",
      "indices" : [ 42, 45 ],
      "id_str" : "14159148",
      "id" : 14159148
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/b4tqL36eMn",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "514852547073687552",
  "text" : "Happening now: President Obama chairs the @UN Security Council summit on foreign terrorist fighters \u2192 http:\/\/t.co\/b4tqL36eMn",
  "id" : 514852547073687552,
  "created_at" : "2014-09-24 19:03:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "United Nations",
      "screen_name" : "UN",
      "indices" : [ 32, 35 ],
      "id_str" : "14159148",
      "id" : 14159148
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/b4tqL36eMn",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "514847292877455361",
  "text" : "Watch President Obama chair the @UN Security Council summit on foreign terrorist fighters at 3pm ET \u2192 http:\/\/t.co\/b4tqL36eMn",
  "id" : 514847292877455361,
  "created_at" : "2014-09-24 18:42:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/Oz3911MQZH",
      "expanded_url" : "http:\/\/youtu.be\/kH29t9-nX48",
      "display_url" : "youtu.be\/kH29t9-nX48"
    } ]
  },
  "geo" : { },
  "id_str" : "514839311246950403",
  "text" : "No matter\nwho you are\nwhere you're from\nwhat you look like\nor who you love\nwe all share something fundamental \u2192 http:\/\/t.co\/Oz3911MQZH",
  "id" : 514839311246950403,
  "created_at" : "2014-09-24 18:10:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Clinton",
      "screen_name" : "billclinton",
      "indices" : [ 20, 32 ],
      "id_str" : "1330457336",
      "id" : 1330457336
    }, {
      "name" : "CGI",
      "screen_name" : "ClintonGlobal",
      "indices" : [ 55, 69 ],
      "id_str" : "68999404",
      "id" : 68999404
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/514817023898308608\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/PP7t40oLds",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ByT_WstIYAAZoJm.jpg",
      "id_str" : "514817022849736704",
      "id" : 514817022849736704,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ByT_WstIYAAZoJm.jpg",
      "sizes" : [ {
        "h" : 679,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 398,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 729,
        "resize" : "fit",
        "w" : 1100
      } ],
      "display_url" : "pic.twitter.com\/PP7t40oLds"
    } ],
    "hashtags" : [ {
      "text" : "CGI2014",
      "indices" : [ 106, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/3HEWywmd9s",
      "expanded_url" : "http:\/\/go.wh.gov\/ynRvLF",
      "display_url" : "go.wh.gov\/ynRvLF"
    } ]
  },
  "geo" : { },
  "id_str" : "514817023898308608",
  "text" : "President Obama and @BillClinton talk backstage at the @ClintonGlobal Initiative \u2192 http:\/\/t.co\/3HEWywmd9s #CGI2014 http:\/\/t.co\/PP7t40oLds",
  "id" : 514817023898308608,
  "created_at" : "2014-09-24 16:41:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514789526347456512",
  "text" : "\"We are heirs to a proud legacy of freedom and we are prepared to do what is necessary to secure that legacy for generations to come\" \u2014Obama",
  "id" : 514789526347456512,
  "created_at" : "2014-09-24 14:52:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UNGA",
      "indices" : [ 130, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514789184910143488",
  "text" : "\"No matter who you are, or where you come from, or what you look like...there is something fundamental that we all share.\" \u2014Obama #UNGA",
  "id" : 514789184910143488,
  "created_at" : "2014-09-24 14:51:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514788721099808768",
  "text" : "RT @WHLive: \"Like every country, we continually wrestle with how to reconcile the vast changes wrought by globalization and greater diversi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "514788607862005761",
    "text" : "\"Like every country, we continually wrestle with how to reconcile the vast changes wrought by globalization and greater diversity.\" \u2014Obama",
    "id" : 514788607862005761,
    "created_at" : "2014-09-24 14:49:03 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 514788721099808768,
  "created_at" : "2014-09-24 14:49:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UNGA",
      "indices" : [ 128, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514788267804602368",
  "text" : "\"The status quo in the West Bank and Gaza is not sustainable. We cannot afford to turn away from this effort.\" \u2014President Obama #UNGA",
  "id" : 514788267804602368,
  "created_at" : "2014-09-24 14:47:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UNGA",
      "indices" : [ 119, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514787925457108992",
  "text" : "\"America will not give up on the pursuit of peace.\" \u2014President Obama on the conflict between Palestinians and Israelis #UNGA",
  "id" : 514787925457108992,
  "created_at" : "2014-09-24 14:46:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514787640101834752",
  "text" : "RT @WHLive: \"America will be a respectful &amp; constructive partner. We will neither tolerate terrorist safe-havens, nor act as an occupying p\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "514787617385488384",
    "text" : "\"America will be a respectful &amp; constructive partner. We will neither tolerate terrorist safe-havens, nor act as an occupying power.\" \u2014Obama",
    "id" : 514787617385488384,
    "created_at" : "2014-09-24 14:45:06 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 514787640101834752,
  "created_at" : "2014-09-24 14:45:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514787447876882432",
  "text" : "\"The task of rejecting sectarianism and extremism is a generational task, and a task for the people of the Middle East themselves.\" \u2014Obama",
  "id" : 514787447876882432,
  "created_at" : "2014-09-24 14:44:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UNGA",
      "indices" : [ 129, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514786979104718850",
  "text" : "\"You come from a great tradition that stands for education, not ignorance; innovation, not destruction.\" \u2014Obama to young Muslims #UNGA",
  "id" : 514786979104718850,
  "created_at" : "2014-09-24 14:42:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514785978968715264",
  "text" : "RT @WHLive: \"We must address the cycle of conflict, especially sectarian conflict, that creates the conditions that terrorists prey upon.\" \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UNGA",
        "indices" : [ 134, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "514785957032505344",
    "text" : "\"We must address the cycle of conflict, especially sectarian conflict, that creates the conditions that terrorists prey upon.\" \u2014Obama #UNGA",
    "id" : 514785957032505344,
    "created_at" : "2014-09-24 14:38:31 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 514785978968715264,
  "created_at" : "2014-09-24 14:38:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ISIL",
      "indices" : [ 135, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514784916153053184",
  "text" : "\"We will not succumb to threats, and we will demonstrate that the future belongs to those who build, not those who destroy.\" \u2014Obama on #ISIL",
  "id" : 514784916153053184,
  "created_at" : "2014-09-24 14:34:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ISIL",
      "indices" : [ 134, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514784661151956992",
  "text" : "\"No God condones this terror. No grievance justifies these actions. There can be...no negotiation with this brand of evil.\" \u2014Obama on #ISIL",
  "id" : 514784661151956992,
  "created_at" : "2014-09-24 14:33:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "United Nations",
      "screen_name" : "UN",
      "indices" : [ 104, 107 ],
      "id_str" : "14159148",
      "id" : 14159148
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UNGA",
      "indices" : [ 132, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/b4tqL36eMn",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "514784421552324608",
  "text" : "\"The terrorist group known as ISIL must be degraded, and ultimately destroyed.\" \u2014President Obama at the @UN: http:\/\/t.co\/b4tqL36eMn #UNGA",
  "id" : 514784421552324608,
  "created_at" : "2014-09-24 14:32:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UNGA",
      "indices" : [ 135, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514784168279302144",
  "text" : "\"Humanity\u2019s future depends on us uniting against those who would divide us along fault lines of tribe or sect\u2014race or religion\" \u2014Obama #UNGA",
  "id" : 514784168279302144,
  "created_at" : "2014-09-24 14:31:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UNGA",
      "indices" : [ 134, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514783383705370625",
  "text" : "\"One issue risks a cycle of conflict that could derail such progress, and that is the cancer of violent extremism.\"  \u2014President Obama #UNGA",
  "id" : 514783383705370625,
  "created_at" : "2014-09-24 14:28:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514783077353000960",
  "text" : "RT @WHLive: \"If the world acts together, we can make sure that all of our children can enjoy lives of opportunity and dignity.\" \u2014President \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UNGA",
        "indices" : [ 133, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "514783041634717696",
    "text" : "\"If the world acts together, we can make sure that all of our children can enjoy lives of opportunity and dignity.\" \u2014President Obama #UNGA",
    "id" : 514783041634717696,
    "created_at" : "2014-09-24 14:26:55 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 514783077353000960,
  "created_at" : "2014-09-24 14:27:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514782876555313152",
  "text" : "RT @WHLive: \"We can reach a solution that meets your energy needs while assuring the world that your program is peaceful.\" \u2014Obama to Iran #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UNGA",
        "indices" : [ 126, 131 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "514782835723759616",
    "text" : "\"We can reach a solution that meets your energy needs while assuring the world that your program is peaceful.\" \u2014Obama to Iran #UNGA",
    "id" : 514782835723759616,
    "created_at" : "2014-09-24 14:26:06 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 514782876555313152,
  "created_at" : "2014-09-24 14:26:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UNGA",
      "indices" : [ 133, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514782344558153729",
  "text" : "\"When nations find common ground, not simply based on power, but on principle, then we can make enormous progress.\" \u2014President Obama #UNGA",
  "id" : 514782344558153729,
  "created_at" : "2014-09-24 14:24:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UNGA",
      "indices" : [ 128, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514781796773666816",
  "text" : "\"We believe that right makes might...that people should be able to choose their own future.\" \u2014Obama on the situation in Ukraine #UNGA",
  "id" : 514781796773666816,
  "created_at" : "2014-09-24 14:21:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UNGA",
      "indices" : [ 114, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/AGvpbNmCcC",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "514781532645777408",
  "text" : "RT @WHLive: \"Russia\u2019s actions in Ukraine challenge this post-war order.\" \u2014President Obama: http:\/\/t.co\/AGvpbNmCcC #UNGA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UNGA",
        "indices" : [ 102, 107 ]
      } ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/AGvpbNmCcC",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "514781460222738432",
    "text" : "\"Russia\u2019s actions in Ukraine challenge this post-war order.\" \u2014President Obama: http:\/\/t.co\/AGvpbNmCcC #UNGA",
    "id" : 514781460222738432,
    "created_at" : "2014-09-24 14:20:38 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 514781532645777408,
  "created_at" : "2014-09-24 14:20:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "United Nations",
      "screen_name" : "UN",
      "indices" : [ 112, 115 ],
      "id_str" : "14159148",
      "id" : 14159148
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UNGA",
      "indices" : [ 116, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514781282170335232",
  "text" : "\"We are here because others realized that we gain more from cooperation than conquest.\" \u2014President Obama at the @UN #UNGA",
  "id" : 514781282170335232,
  "created_at" : "2014-09-24 14:19:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UNGA",
      "indices" : [ 126, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514781136481185792",
  "text" : "RT @WHLive: \"Big nations and small must meet our responsibility to observe and enforce international norms.\" \u2014President Obama #UNGA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UNGA",
        "indices" : [ 114, 119 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "514781113827729408",
    "text" : "\"Big nations and small must meet our responsibility to observe and enforce international norms.\" \u2014President Obama #UNGA",
    "id" : 514781113827729408,
    "created_at" : "2014-09-24 14:19:16 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 514781136481185792,
  "created_at" : "2014-09-24 14:19:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UNGA",
      "indices" : [ 130, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514781012828884996",
  "text" : "\"We reject fatalism or cynicism when it comes to human affairs; we choose to work for the world as it should be\" \u2014President Obama #UNGA",
  "id" : 514781012828884996,
  "created_at" : "2014-09-24 14:18:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UNGA",
      "indices" : [ 135, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514780939910922240",
  "text" : "\"We choose hope over fear. We see the future not as something out of our control, but as something we can shape for the better\" \u2014Obama #UNGA",
  "id" : 514780939910922240,
  "created_at" : "2014-09-24 14:18:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514780882604154880",
  "text" : "RT @WHLive: \"We can renew the international system that has enabled so much progress, or we can allow ourselves to be pulled back.\" \u2014Obama \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UNGA",
        "indices" : [ 127, 132 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "514780802769760256",
    "text" : "\"We can renew the international system that has enabled so much progress, or we can allow ourselves to be pulled back.\" \u2014Obama #UNGA",
    "id" : 514780802769760256,
    "created_at" : "2014-09-24 14:18:02 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 514780882604154880,
  "created_at" : "2014-09-24 14:18:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UNGA",
      "indices" : [ 135, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/b4tqL36eMn",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "514780553858785280",
  "text" : "\"The brutality of terrorists in Syria and Iraq forces us to look into the heart of darkness.\" \u2014President Obama: http:\/\/t.co\/b4tqL36eMn #UNGA",
  "id" : 514780553858785280,
  "created_at" : "2014-09-24 14:17:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514780419393605632",
  "text" : "RT @WHLive: \"As we gather here, an outbreak of Ebola overwhelms public health systems in West Africa.\" \u2014President Obama: http:\/\/t.co\/DCegwE\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UNGA",
        "indices" : [ 132, 137 ]
      } ],
      "urls" : [ {
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/DCegwEQp14",
        "expanded_url" : "http:\/\/wh.gov\/ilORQ",
        "display_url" : "wh.gov\/ilORQ"
      } ]
    },
    "geo" : { },
    "id_str" : "514780394353590273",
    "text" : "\"As we gather here, an outbreak of Ebola overwhelms public health systems in West Africa.\" \u2014President Obama: http:\/\/t.co\/DCegwEQp14 #UNGA",
    "id" : 514780394353590273,
    "created_at" : "2014-09-24 14:16:24 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 514780419393605632,
  "created_at" : "2014-09-24 14:16:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UNGA",
      "indices" : [ 132, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514780324308717569",
  "text" : "\"We come together at a crossroads between war and peace; between disorder and integration; between fear and hope.\" \u2014President Obama #UNGA",
  "id" : 514780324308717569,
  "created_at" : "2014-09-24 14:16:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "United Nations",
      "screen_name" : "UN",
      "indices" : [ 45, 48 ],
      "id_str" : "14159148",
      "id" : 14159148
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UNGA",
      "indices" : [ 91, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/CNvLNYAz9K",
      "expanded_url" : "http:\/\/go.wh.gov\/2ksume",
      "display_url" : "go.wh.gov\/2ksume"
    } ]
  },
  "geo" : { },
  "id_str" : "514780169840914432",
  "text" : "Happening now: President Obama speaks to the @UN General Assembly \u2192 http:\/\/t.co\/CNvLNYAz9K #UNGA",
  "id" : 514780169840914432,
  "created_at" : "2014-09-24 14:15:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "United Nations",
      "screen_name" : "UN",
      "indices" : [ 43, 46 ],
      "id_str" : "14159148",
      "id" : 14159148
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UNGA",
      "indices" : [ 100, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/CNvLNYAz9K",
      "expanded_url" : "http:\/\/go.wh.gov\/2ksume",
      "display_url" : "go.wh.gov\/2ksume"
    } ]
  },
  "geo" : { },
  "id_str" : "514773091571212288",
  "text" : "Don't miss President Obama's speech to the @UN General Assembly at 10am ET \u2192 http:\/\/t.co\/CNvLNYAz9K #UNGA",
  "id" : 514773091571212288,
  "created_at" : "2014-09-24 13:47:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/514552278863593472\/photo\/1",
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/9JhQqFLGPr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ByQOkhEIMAEyPHt.jpg",
      "id_str" : "514552277940842497",
      "id" : 514552277940842497,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ByQOkhEIMAEyPHt.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/9JhQqFLGPr"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 59, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/Uf0NUVI3qd",
      "expanded_url" : "http:\/\/wh.gov\/climate-change",
      "display_url" : "wh.gov\/climate-change"
    } ]
  },
  "geo" : { },
  "id_str" : "514552278863593472",
  "text" : "Worth sharing: Get the latest on President Obama's plan to #ActOnClimate \u2192 http:\/\/t.co\/Uf0NUVI3qd http:\/\/t.co\/9JhQqFLGPr",
  "id" : 514552278863593472,
  "created_at" : "2014-09-23 23:09:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Senator Bob Menendez",
      "screen_name" : "SenatorMenendez",
      "indices" : [ 3, 19 ],
      "id_str" : "18695134",
      "id" : 18695134
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 23, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514544085588512769",
  "text" : "RT @SenatorMenendez: I #ActOnClimate bc I care abt the future for my son &amp; daughter. The US must take serious action &amp; lead for them now! h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SenatorMenendez\/status\/514501268371685376\/photo\/1",
        "indices" : [ 125, 147 ],
        "url" : "http:\/\/t.co\/YZ0RMKukCn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ByPgLTNIYAAdazg.jpg",
        "id_str" : "514501267188899840",
        "id" : 514501267188899840,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ByPgLTNIYAAdazg.jpg",
        "sizes" : [ {
          "h" : 816,
          "resize" : "fit",
          "w" : 1632
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/YZ0RMKukCn"
      } ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 2, 15 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "514501268371685376",
    "text" : "I #ActOnClimate bc I care abt the future for my son &amp; daughter. The US must take serious action &amp; lead for them now! http:\/\/t.co\/YZ0RMKukCn",
    "id" : 514501268371685376,
    "created_at" : "2014-09-23 19:47:16 +0000",
    "user" : {
      "name" : "Senator Bob Menendez",
      "screen_name" : "SenatorMenendez",
      "protected" : false,
      "id_str" : "18695134",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/471994418266775552\/14FnKiYy_normal.jpeg",
      "id" : 18695134,
      "verified" : true
    }
  },
  "id" : 514544085588512769,
  "created_at" : "2014-09-23 22:37:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Wall",
      "screen_name" : "Alex44",
      "indices" : [ 3, 10 ],
      "id_str" : "2169098419",
      "id" : 2169098419
    }, {
      "name" : "Upworthy",
      "screen_name" : "Upworthy",
      "indices" : [ 97, 106 ],
      "id_str" : "524396430",
      "id" : 524396430
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 38, 51 ]
    }, {
      "text" : "UpChat",
      "indices" : [ 52, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/38KVSfv9rL",
      "expanded_url" : "http:\/\/go.wh.gov\/xUT1LZ",
      "display_url" : "go.wh.gov\/xUT1LZ"
    } ]
  },
  "geo" : { },
  "id_str" : "514537435473408000",
  "text" : "RT @Alex44: Missed Dr. John Holdren's #ActOnClimate #UpChat? Check out his back &amp; forth with @Upworthy \u2192 http:\/\/t.co\/38KVSfv9rL http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Upworthy",
        "screen_name" : "Upworthy",
        "indices" : [ 85, 94 ],
        "id_str" : "524396430",
        "id" : 524396430
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Alex44\/status\/514531208932622336\/photo\/1",
        "indices" : [ 120, 142 ],
        "url" : "http:\/\/t.co\/H7AZkeFcaM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ByP7aGrIcAAMDC7.jpg",
        "id_str" : "514531208337059840",
        "id" : 514531208337059840,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ByP7aGrIcAAMDC7.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/H7AZkeFcaM"
      } ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 26, 39 ]
      }, {
        "text" : "UpChat",
        "indices" : [ 40, 47 ]
      } ],
      "urls" : [ {
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/38KVSfv9rL",
        "expanded_url" : "http:\/\/go.wh.gov\/xUT1LZ",
        "display_url" : "go.wh.gov\/xUT1LZ"
      } ]
    },
    "geo" : { },
    "id_str" : "514531208932622336",
    "text" : "Missed Dr. John Holdren's #ActOnClimate #UpChat? Check out his back &amp; forth with @Upworthy \u2192 http:\/\/t.co\/38KVSfv9rL http:\/\/t.co\/H7AZkeFcaM",
    "id" : 514531208932622336,
    "created_at" : "2014-09-23 21:46:14 +0000",
    "user" : {
      "name" : "Alex Wall",
      "screen_name" : "Alex44",
      "protected" : false,
      "id_str" : "2169098419",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/632215085256081409\/_vjZ92WM_normal.jpg",
      "id" : 2169098419,
      "verified" : true
    }
  },
  "id" : 514537435473408000,
  "created_at" : "2014-09-23 22:10:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 119, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/KzEU5thslX",
      "expanded_url" : "http:\/\/youtu.be\/zmz6srlnur8",
      "display_url" : "youtu.be\/zmz6srlnur8"
    } ]
  },
  "geo" : { },
  "id_str" : "514527198271639555",
  "text" : "\"We cannot condemn our children...to a future that is beyond their capacity to repair.\" \u2014Obama: http:\/\/t.co\/KzEU5thslX #ActOnClimate",
  "id" : 514527198271639555,
  "created_at" : "2014-09-23 21:30:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UpChat",
      "indices" : [ 109, 116 ]
    }, {
      "text" : "climate",
      "indices" : [ 125, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514516992511180801",
  "text" : "RT @whitehouseostp: Tune in right here at 5pm ET TODAY. Pres. Obama's Science Advisor John Holdren will join #UpChat to talk #climate &amp; tak\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Upworthy",
        "screen_name" : "Upworthy",
        "indices" : [ 130, 139 ],
        "id_str" : "524396430",
        "id" : 524396430
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UpChat",
        "indices" : [ 89, 96 ]
      }, {
        "text" : "climate",
        "indices" : [ 105, 113 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "514512046789255168",
    "text" : "Tune in right here at 5pm ET TODAY. Pres. Obama's Science Advisor John Holdren will join #UpChat to talk #climate &amp; take Q's. @Upworthy",
    "id" : 514512046789255168,
    "created_at" : "2014-09-23 20:30:05 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 514516992511180801,
  "created_at" : "2014-09-23 20:49:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/514512535169826818\/photo\/1",
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/6fevvnSRef",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ByPqbJbIEAEzT2-.jpg",
      "id_str" : "514512534557429761",
      "id" : 514512534557429761,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ByPqbJbIEAEzT2-.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/6fevvnSRef"
    } ],
    "hashtags" : [ {
      "text" : "ChartOfTheWeek",
      "indices" : [ 0, 15 ]
    }, {
      "text" : "ActOnClimate",
      "indices" : [ 38, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/V4T6Lcd1A8",
      "expanded_url" : "http:\/\/go.wh.gov\/g7ArJH",
      "display_url" : "go.wh.gov\/g7ArJH"
    } ]
  },
  "geo" : { },
  "id_str" : "514512535169826818",
  "text" : "#ChartOfTheWeek: Why we can't wait to #ActOnClimate change \u2192 http:\/\/t.co\/V4T6Lcd1A8 http:\/\/t.co\/6fevvnSRef",
  "id" : 514512535169826818,
  "created_at" : "2014-09-23 20:32:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Power",
      "screen_name" : "AmbassadorPower",
      "indices" : [ 3, 19 ],
      "id_str" : "1615463502",
      "id" : 1615463502
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Climate2014",
      "indices" : [ 40, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514508771327229952",
  "text" : "RT @AmbassadorPower: President Obama at #Climate2014: I believe, as Dr. King said, that there is such a thing as being too late. #ActOnClim\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Climate2014",
        "indices" : [ 19, 31 ]
      }, {
        "text" : "ActOnClimate",
        "indices" : [ 108, 121 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "514472396544540672",
    "text" : "President Obama at #Climate2014: I believe, as Dr. King said, that there is such a thing as being too late. #ActOnClimate",
    "id" : 514472396544540672,
    "created_at" : "2014-09-23 17:52:32 +0000",
    "user" : {
      "name" : "Samantha Power",
      "screen_name" : "AmbassadorPower",
      "protected" : false,
      "id_str" : "1615463502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/620632341497683968\/CkFXABqQ_normal.jpg",
      "id" : 1615463502,
      "verified" : true
    }
  },
  "id" : 514508771327229952,
  "created_at" : "2014-09-23 20:17:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MarkeyMemo",
      "screen_name" : "MARKEYMEMO",
      "indices" : [ 3, 14 ],
      "id_str" : "3047090620",
      "id" : 3047090620
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 18, 31 ]
    }, {
      "text" : "climatechange",
      "indices" : [ 106, 120 ]
    }, {
      "text" : "Climate2014",
      "indices" : [ 121, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514499887573237762",
  "text" : "RT @MarkeyMemo: I #ActOnClimate bc US must show that we'll be the leader,not the laggard,in fight against #climatechange #Climate2014 http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/MarkeyMemo\/status\/514470958636498944\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/TEVyhK2SDu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ByPEnDSCUAEKTFW.jpg",
        "id_str" : "514470957625266177",
        "id" : 514470957625266177,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ByPEnDSCUAEKTFW.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/TEVyhK2SDu"
      } ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 2, 15 ]
      }, {
        "text" : "climatechange",
        "indices" : [ 90, 104 ]
      }, {
        "text" : "Climate2014",
        "indices" : [ 105, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "514470958636498944",
    "text" : "I #ActOnClimate bc US must show that we'll be the leader,not the laggard,in fight against #climatechange #Climate2014 http:\/\/t.co\/TEVyhK2SDu",
    "id" : 514470958636498944,
    "created_at" : "2014-09-23 17:46:49 +0000",
    "user" : {
      "name" : "Ed Markey",
      "screen_name" : "SenMarkey",
      "protected" : false,
      "id_str" : "21406834",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/739889609262411780\/qDeJ7rdE_normal.jpg",
      "id" : 21406834,
      "verified" : true
    }
  },
  "id" : 514499887573237762,
  "created_at" : "2014-09-23 19:41:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/514494284498997248\/photo\/1",
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/cK97wDGnlQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ByPZ0wFIAAEpZX9.jpg",
      "id_str" : "514494282733191169",
      "id" : 514494282733191169,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ByPZ0wFIAAEpZX9.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/cK97wDGnlQ"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 38, 51 ]
    }, {
      "text" : "ActOnClimate",
      "indices" : [ 84, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/Uf0NUVI3qd",
      "expanded_url" : "http:\/\/wh.gov\/climate-change",
      "display_url" : "wh.gov\/climate-change"
    } ]
  },
  "geo" : { },
  "id_str" : "514494284498997248",
  "text" : "RT to share President Obama's plan to #ActOnClimate change \u2192 http:\/\/t.co\/Uf0NUVI3qd #ActOnClimate http:\/\/t.co\/cK97wDGnlQ",
  "id" : 514494284498997248,
  "created_at" : "2014-09-23 19:19:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HuffPost Green",
      "screen_name" : "HuffPostGreen",
      "indices" : [ 86, 100 ],
      "id_str" : "45577446",
      "id" : 45577446
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 125, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/daQwQVADmI",
      "expanded_url" : "http:\/\/huff.to\/Y24nxF",
      "display_url" : "huff.to\/Y24nxF"
    } ]
  },
  "geo" : { },
  "id_str" : "514487106430062593",
  "text" : "Worth a read: \"An important step in our fight against climate change.\" \u2014@Podesta44 on @HuffPostGreen: http:\/\/t.co\/daQwQVADmI #ActOnClimate",
  "id" : 514487106430062593,
  "created_at" : "2014-09-23 18:50:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CGI2014",
      "indices" : [ 123, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514483438389567488",
  "text" : "\"No matter how dark the hour...we remember the words of Dr. King: 'the time is always ripe to do right.'\" \u2014President Obama #CGI2014",
  "id" : 514483438389567488,
  "created_at" : "2014-09-23 18:36:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514482683624566784",
  "text" : "\"The United States will not stop speaking out for the human rights of all people and pushing governments to uphold those rights.\" \u2014Obama",
  "id" : 514482683624566784,
  "created_at" : "2014-09-23 18:33:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514481607353569281",
  "text" : "RT @WHLive: \"We're helping to build the next generation of civil society leaders...and our message to them is simple: America stands with y\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "514481584050016257",
    "text" : "\"We're helping to build the next generation of civil society leaders...and our message to them is simple: America stands with you.\" \u2014Obama",
    "id" : 514481584050016257,
    "created_at" : "2014-09-23 18:29:02 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 514481607353569281,
  "created_at" : "2014-09-23 18:29:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CGI2014",
      "indices" : [ 125, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/HZE3xljuhK",
      "expanded_url" : "http:\/\/go.wh.gov\/vZc8WX",
      "display_url" : "go.wh.gov\/vZc8WX"
    } ]
  },
  "geo" : { },
  "id_str" : "514480153540706306",
  "text" : "RT @WHLive: \"America\u2019s support for civil society is a matter of national security.\" \u2014President Obama: http:\/\/t.co\/HZE3xljuhK #CGI2014",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CGI2014",
        "indices" : [ 113, 121 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/HZE3xljuhK",
        "expanded_url" : "http:\/\/go.wh.gov\/vZc8WX",
        "display_url" : "go.wh.gov\/vZc8WX"
      } ]
    },
    "geo" : { },
    "id_str" : "514480116471451648",
    "text" : "\"America\u2019s support for civil society is a matter of national security.\" \u2014President Obama: http:\/\/t.co\/HZE3xljuhK #CGI2014",
    "id" : 514480116471451648,
    "created_at" : "2014-09-23 18:23:13 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 514480153540706306,
  "created_at" : "2014-09-23 18:23:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CGI2014",
      "indices" : [ 130, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514479665650876416",
  "text" : "\"When nations uphold the rights of all their people, including\u2026women\u2026those countries are more likely to thrive.\" \u2014President Obama #CGI2014",
  "id" : 514479665650876416,
  "created_at" : "2014-09-23 18:21:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514479244098158594",
  "text" : "\"When people are free to speak their minds and hold their leaders accountable, governments are more responsive and more effective.\" \u2014Obama",
  "id" : 514479244098158594,
  "created_at" : "2014-09-23 18:19:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514479102460694528",
  "text" : "RT @WHLive: \"It was citizens here in America who worked to abolish slavery and marched for women\u2019s rights and workers\u2019 rights and civil rig\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "514479065898967040",
    "text" : "\"It was citizens here in America who worked to abolish slavery and marched for women\u2019s rights and workers\u2019 rights and civil rights.\" \u2014Obama",
    "id" : 514479065898967040,
    "created_at" : "2014-09-23 18:19:02 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 514479102460694528,
  "created_at" : "2014-09-23 18:19:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514478965432807424",
  "text" : "\"It is citizens\u2014ordinary men and women, determined to forge their own future\u2014who throughout history have sparked all great change\" \u2014Obama",
  "id" : 514478965432807424,
  "created_at" : "2014-09-23 18:18:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CGI2014",
      "indices" : [ 103, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514478896138706944",
  "text" : "\"The most important title is not President...the most important title is citizen.\" \u2014President Obama at #CGI2014",
  "id" : 514478896138706944,
  "created_at" : "2014-09-23 18:18:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CGI2014",
      "indices" : [ 41, 49 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/nF2VscERQa",
      "expanded_url" : "http:\/\/go.wh.gov\/vZc8WX",
      "display_url" : "go.wh.gov\/vZc8WX"
    } ]
  },
  "geo" : { },
  "id_str" : "514477630079664129",
  "text" : "Happening now: President Obama speaks at #CGI2014. Watch \u2192 http:\/\/t.co\/nF2VscERQa",
  "id" : 514477630079664129,
  "created_at" : "2014-09-23 18:13:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sen. Patrick Leahy",
      "screen_name" : "SenatorLeahy",
      "indices" : [ 3, 16 ],
      "id_str" : "242836537",
      "id" : 242836537
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 31, 42 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UN",
      "indices" : [ 80, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514470056974364672",
  "text" : "RT @SenatorLeahy: Proud to see @WhiteHouse pushing urgency of climate threat to #UN and other world leaders. It is past time to #ActOnClima\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 13, 24 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UN",
        "indices" : [ 62, 65 ]
      }, {
        "text" : "ActOnClimate",
        "indices" : [ 110, 123 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "514460016355852288",
    "text" : "Proud to see @WhiteHouse pushing urgency of climate threat to #UN and other world leaders. It is past time to #ActOnClimate",
    "id" : 514460016355852288,
    "created_at" : "2014-09-23 17:03:20 +0000",
    "user" : {
      "name" : "Sen. Patrick Leahy",
      "screen_name" : "SenatorLeahy",
      "protected" : false,
      "id_str" : "242836537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793093163401506816\/kLHLbN0V_normal.jpg",
      "id" : 242836537,
      "verified" : true
    }
  },
  "id" : 514470056974364672,
  "created_at" : "2014-09-23 17:43:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 109, 122 ]
    }, {
      "text" : "UNGA2014",
      "indices" : [ 123, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514463370863706114",
  "text" : "\"Our generation must move toward a global compact to confront a changing climate while we still can.\" \u2014Obama #ActOnClimate #UNGA2014",
  "id" : 514463370863706114,
  "created_at" : "2014-09-23 17:16:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514462750572314624",
  "text" : "\"We can only succeed in combating climate change if we are joined in this effort by every nation\u2014developed and developing alike.\" \u2014Obama",
  "id" : 514462750572314624,
  "created_at" : "2014-09-23 17:14:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 116, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514462446078001153",
  "text" : "\"Today, I call on all countries to join us...because no nation can meet this global threat alone.\" \u2014President Obama #ActOnClimate",
  "id" : 514462446078001153,
  "created_at" : "2014-09-23 17:13:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514462121472823297",
  "text" : "RT @WHLive: \"As the world\u2019s two largest economies &amp; largest emitters, we have a special responsibility to lead\" \u2014Obama on the U.S. &amp; China \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 135, 148 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "514462065277562881",
    "text" : "\"As the world\u2019s two largest economies &amp; largest emitters, we have a special responsibility to lead\" \u2014Obama on the U.S. &amp; China #ActOnClimate",
    "id" : 514462065277562881,
    "created_at" : "2014-09-23 17:11:29 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 514462121472823297,
  "created_at" : "2014-09-23 17:11:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514461670065074177",
  "text" : "RT @WHLive: \"The United States has made ambitious investments in clean energy, and ambitious reductions in our carbon emissions.\" \u2014Obama #A\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 125, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "514461634581254145",
    "text" : "\"The United States has made ambitious investments in clean energy, and ambitious reductions in our carbon emissions.\" \u2014Obama #ActOnClimate",
    "id" : 514461634581254145,
    "created_at" : "2014-09-23 17:09:46 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 514461670065074177,
  "created_at" : "2014-09-23 17:09:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514461421565136898",
  "text" : "RT @WHLive: \"We are the 1st generation to feel the impact of climate change &amp; the last generation that can do something about it.\" \u2014Obama #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 130, 143 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "514461388019093504",
    "text" : "\"We are the 1st generation to feel the impact of climate change &amp; the last generation that can do something about it.\" \u2014Obama #ActOnClimate",
    "id" : 514461388019093504,
    "created_at" : "2014-09-23 17:08:47 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 514461421565136898,
  "created_at" : "2014-09-23 17:08:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 114, 127 ]
    }, {
      "text" : "UNGA2014",
      "indices" : [ 128, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514461154111127552",
  "text" : "\"We cannot condemn our children, and their children, to a future that is beyond their capacity to repair.\" \u2014Obama #ActOnClimate #UNGA2014",
  "id" : 514461154111127552,
  "created_at" : "2014-09-23 17:07:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 111, 124 ]
    }, {
      "text" : "UNGA2014",
      "indices" : [ 125, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514460794722201600",
  "text" : "\"Worldwide, this summer was the hottest ever recorded, with global carbon emissions still on the rise.\" \u2014Obama #ActOnClimate #UNGA2014",
  "id" : 514460794722201600,
  "created_at" : "2014-09-23 17:06:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 100, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514460591080361984",
  "text" : "\"No nation is immune. In America, the past decade has been our hottest on record.\" \u2014President Obama #ActOnClimate",
  "id" : 514460591080361984,
  "created_at" : "2014-09-23 17:05:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 94, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514460492560338944",
  "text" : "\"This once-distant threat has moved firmly into the present.\u201D \u2014President Obama on the need to #ActOnClimate change",
  "id" : 514460492560338944,
  "created_at" : "2014-09-23 17:05:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 53, 66 ]
    }, {
      "text" : "UNGA2014",
      "indices" : [ 99, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/Uf0NUVI3qd",
      "expanded_url" : "http:\/\/wh.gov\/climate-change",
      "display_url" : "wh.gov\/climate-change"
    } ]
  },
  "geo" : { },
  "id_str" : "514460407671820288",
  "text" : "Happening now: President Obama speaks on his plan to #ActOnClimate change \u2192 http:\/\/t.co\/Uf0NUVI3qd #UNGA2014",
  "id" : 514460407671820288,
  "created_at" : "2014-09-23 17:04:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/514456114331930625\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/7vZlJxMAb5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ByO3G9HIcAEmVG-.jpg",
      "id_str" : "514456112561942529",
      "id" : 514456112561942529,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ByO3G9HIcAEmVG-.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/7vZlJxMAb5"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 62, 75 ]
    }, {
      "text" : "UNGA2014",
      "indices" : [ 101, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/Uf0NUVI3qd",
      "expanded_url" : "http:\/\/wh.gov\/climate-change",
      "display_url" : "wh.gov\/climate-change"
    } ]
  },
  "geo" : { },
  "id_str" : "514456114331930625",
  "text" : "Don't miss President Obama speak at 12:50pm ET on his plan to #ActOnClimate \u2192 http:\/\/t.co\/Uf0NUVI3qd #UNGA2014 http:\/\/t.co\/7vZlJxMAb5",
  "id" : 514456114331930625,
  "created_at" : "2014-09-23 16:47:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/514447030400614400\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/IPhGLcDedf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ByOu2OMIEAAtzVu.jpg",
      "id_str" : "514447028995493888",
      "id" : 514447028995493888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ByOu2OMIEAAtzVu.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/IPhGLcDedf"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 68, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/Uf0NUVI3qd",
      "expanded_url" : "http:\/\/wh.gov\/climate-change",
      "display_url" : "wh.gov\/climate-change"
    } ]
  },
  "geo" : { },
  "id_str" : "514447030400614400",
  "text" : "For the sake of our kids and the future of our planet, it's time to #ActOnClimate change \u2192 http:\/\/t.co\/Uf0NUVI3qd http:\/\/t.co\/IPhGLcDedf",
  "id" : 514447030400614400,
  "created_at" : "2014-09-23 16:11:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ISIL",
      "indices" : [ 71, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514418449414881280",
  "text" : "\"We will do what is necessary to defend our country.\" \u2014President Obama #ISIL",
  "id" : 514418449414881280,
  "created_at" : "2014-09-23 14:18:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ISIL",
      "indices" : [ 92, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514417772055764992",
  "text" : "\"We will not tolerate safe havens for terrorists who threaten our people.\" \u2014President Obama #ISIL",
  "id" : 514417772055764992,
  "created_at" : "2014-09-23 14:15:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ISIL",
      "indices" : [ 131, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514417411697938432",
  "text" : "RT @WHLive: \"We will move forward with our plan...to ramp up our effort to train and equip the Syrian opposition\" \u2014President Obama #ISIL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ISIL",
        "indices" : [ 119, 124 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "514417373861117952",
    "text" : "\"We will move forward with our plan...to ramp up our effort to train and equip the Syrian opposition\" \u2014President Obama #ISIL",
    "id" : 514417373861117952,
    "created_at" : "2014-09-23 14:13:54 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 514417411697938432,
  "created_at" : "2014-09-23 14:14:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ISIL",
      "indices" : [ 106, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514417305951154176",
  "text" : "\"This is not America\u2019s fight alone\u2014above all, the people and governments of the Middle East are rejecting #ISIL\" \u2014President Obama",
  "id" : 514417305951154176,
  "created_at" : "2014-09-23 14:13:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ISIL",
      "indices" : [ 121, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514417073037254656",
  "text" : "\"Today, the American people give thanks for the extraordinary service of our men and women in uniform.\" \u2014President Obama #ISIL",
  "id" : 514417073037254656,
  "created_at" : "2014-09-23 14:12:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514417016959401984",
  "text" : "\"Last night, on my orders, America\u2019s armed forces began strikes against ISIL targets in Syria.\" \u2014President Obama",
  "id" : 514417016959401984,
  "created_at" : "2014-09-23 14:12:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/yr9pNC04xB",
      "expanded_url" : "http:\/\/go.wh.gov\/G1n9Qw",
      "display_url" : "go.wh.gov\/G1n9Qw"
    } ]
  },
  "geo" : { },
  "id_str" : "514416900890439680",
  "text" : "Happening now: President Obama delivers a statement from the White House. Watch \u2192 http:\/\/t.co\/yr9pNC04xB",
  "id" : 514416900890439680,
  "created_at" : "2014-09-23 14:12:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/yr9pNC04xB",
      "expanded_url" : "http:\/\/go.wh.gov\/G1n9Qw",
      "display_url" : "go.wh.gov\/G1n9Qw"
    } ]
  },
  "geo" : { },
  "id_str" : "514401464878657536",
  "text" : "At 10am ET, President Obama delivers a statement from the White House. Watch here \u2192 http:\/\/t.co\/yr9pNC04xB",
  "id" : 514401464878657536,
  "created_at" : "2014-09-23 13:10:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/zF7V8OA2g5",
      "expanded_url" : "http:\/\/go.wh.gov\/Z9NMPu",
      "display_url" : "go.wh.gov\/Z9NMPu"
    } ]
  },
  "geo" : { },
  "id_str" : "514191077935697921",
  "text" : "You don't get to pick your tax rate.\nNeither should corporations.\nLet's make sure we all play by the same rules. http:\/\/t.co\/zF7V8OA2g5",
  "id" : 514191077935697921,
  "created_at" : "2014-09-22 23:14:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/514179557524766720\/photo\/1",
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/nhHexWGJyJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ByK7lQ_IUAA8OHW.png",
      "id_str" : "514179556362964992",
      "id" : 514179556362964992,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ByK7lQ_IUAA8OHW.png",
      "sizes" : [ {
        "h" : 123,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 368,
        "resize" : "fit",
        "w" : 1017
      }, {
        "h" : 368,
        "resize" : "fit",
        "w" : 1017
      }, {
        "h" : 217,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/nhHexWGJyJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514179557524766720",
  "text" : "President Obama on new steps to discourage companies from moving their tax residence overseas: http:\/\/t.co\/nhHexWGJyJ",
  "id" : 514179557524766720,
  "created_at" : "2014-09-22 22:28:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Treasury Department",
      "screen_name" : "USTreasury",
      "indices" : [ 27, 38 ],
      "id_str" : "120176950",
      "id" : 120176950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514145620916187137",
  "text" : "RT @Podesta44: Watch live: @USTreasury Sec Jack Lew  explains why tackling climate change is critical for our economy http:\/\/t.co\/0I9bMUCN7\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Treasury Department",
        "screen_name" : "USTreasury",
        "indices" : [ 12, 23 ],
        "id_str" : "120176950",
        "id" : 120176950
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 126, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/0I9bMUCN75",
        "expanded_url" : "http:\/\/www.hamiltonproject.org\/events\/the_economic_costs_of_climate_change\/",
        "display_url" : "hamiltonproject.org\/events\/the_eco\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "514144614635171840",
    "text" : "Watch live: @USTreasury Sec Jack Lew  explains why tackling climate change is critical for our economy http:\/\/t.co\/0I9bMUCN75 #ActOnClimate",
    "id" : 514144614635171840,
    "created_at" : "2014-09-22 20:10:03 +0000",
    "user" : {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "protected" : false,
      "id_str" : "2382117350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656551411145027584\/ArrSlGUP_normal.jpg",
      "id" : 2382117350,
      "verified" : true
    }
  },
  "id" : 514145620916187137,
  "created_at" : "2014-09-22 20:14:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ItsOnUs",
      "indices" : [ 43, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/7aGUmPQNTW",
      "expanded_url" : "http:\/\/ItsOnUs.org",
      "display_url" : "ItsOnUs.org"
    } ]
  },
  "geo" : { },
  "id_str" : "514137023792558080",
  "text" : "Only 13% of rape survivors report assault. #ItsOnUs to help victims report a sexual assault if he or she wants to \u2192 http:\/\/t.co\/7aGUmPQNTW",
  "id" : 514137023792558080,
  "created_at" : "2014-09-22 19:39:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/514124711052476416\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/GcQaTo6cum",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ByKJsuvIQAATHI1.jpg",
      "id_str" : "514124709026611200",
      "id" : 514124709026611200,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ByKJsuvIQAATHI1.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/GcQaTo6cum"
    } ],
    "hashtags" : [ {
      "text" : "ItsOnUs",
      "indices" : [ 0, 8 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/7aGUmPQNTW",
      "expanded_url" : "http:\/\/ItsOnUs.org",
      "display_url" : "ItsOnUs.org"
    } ]
  },
  "geo" : { },
  "id_str" : "514124711052476416",
  "text" : "#ItsOnUs to realize we all have a role to play in stopping sexual assault. Take the pledge at http:\/\/t.co\/7aGUmPQNTW http:\/\/t.co\/GcQaTo6cum",
  "id" : 514124711052476416,
  "created_at" : "2014-09-22 18:50:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ItsOnUs",
      "indices" : [ 0, 8 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/vuqGdApVuz",
      "expanded_url" : "http:\/\/ItsOnUs.org",
      "display_url" : "ItsOnUs.org"
    }, {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/Q3CZUWrVq1",
      "expanded_url" : "http:\/\/youtu.be\/wNMZo31LziM",
      "display_url" : "youtu.be\/wNMZo31LziM"
    } ]
  },
  "geo" : { },
  "id_str" : "514085502312411137",
  "text" : "#ItsOnUs to stop sexual assault. Take the pledge and be a part of the solution at http:\/\/t.co\/vuqGdApVuz. http:\/\/t.co\/Q3CZUWrVq1",
  "id" : 514085502312411137,
  "created_at" : "2014-09-22 16:15:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 19, 32 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/6rj8sfnnx1",
      "expanded_url" : "http:\/\/go.wh.gov\/UVe5Dp",
      "display_url" : "go.wh.gov\/UVe5Dp"
    } ]
  },
  "geo" : { },
  "id_str" : "514077937746710528",
  "text" : "FACT: New steps to #ActOnClimate will cut carbon pollution by nearly 300 million metric tons through 2030 \u2192 http:\/\/t.co\/6rj8sfnnx1",
  "id" : 514077937746710528,
  "created_at" : "2014-09-22 15:45:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/514066460243931136\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/WHfOum7xZy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ByJUuKKIgAA3hgt.jpg",
      "id_str" : "514066459451228160",
      "id" : 514066459451228160,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ByJUuKKIgAA3hgt.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/WHfOum7xZy"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/PbJljwyTX9",
      "expanded_url" : "http:\/\/go.wh.gov\/MyLAab",
      "display_url" : "go.wh.gov\/MyLAab"
    } ]
  },
  "geo" : { },
  "id_str" : "514066460243931136",
  "text" : "President Obama's partnering with businesses to \u2193 emissions that fuel climate change \u2192 http:\/\/t.co\/PbJljwyTX9 http:\/\/t.co\/WHfOum7xZy",
  "id" : 514066460243931136,
  "created_at" : "2014-09-22 14:59:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "indices" : [ 3, 11 ],
      "id_str" : "1530850933",
      "id" : 1530850933
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActonClimate",
      "indices" : [ 77, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514064275842019328",
  "text" : "RT @GinaEPA: The cost of inaction on climate change is too high. Use hashtag #ActonClimate to share how you are taking action. #climatesumm\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActonClimate",
        "indices" : [ 64, 77 ]
      }, {
        "text" : "climatesummit2014",
        "indices" : [ 114, 132 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "514058720037601281",
    "text" : "The cost of inaction on climate change is too high. Use hashtag #ActonClimate to share how you are taking action. #climatesummit2014",
    "id" : 514058720037601281,
    "created_at" : "2014-09-22 14:28:44 +0000",
    "user" : {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "protected" : false,
      "id_str" : "1530850933",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/632229333130604548\/Bb4I34DU_normal.jpg",
      "id" : 1530850933,
      "verified" : true
    }
  },
  "id" : 514064275842019328,
  "created_at" : "2014-09-22 14:50:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/53GscJvXiR",
      "expanded_url" : "http:\/\/go.wh.gov\/iuwmXD",
      "display_url" : "go.wh.gov\/iuwmXD"
    } ]
  },
  "geo" : { },
  "id_str" : "513809928419422209",
  "text" : "\"The American people stand united around supporting our troops and their families.\" \u2014President Obama: http:\/\/t.co\/53GscJvXiR",
  "id" : 513809928419422209,
  "created_at" : "2014-09-21 22:00:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ISIL",
      "indices" : [ 106, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/53GscJvXiR",
      "expanded_url" : "http:\/\/go.wh.gov\/iuwmXD",
      "display_url" : "go.wh.gov\/iuwmXD"
    } ]
  },
  "geo" : { },
  "id_str" : "513749547424559105",
  "text" : "President Obama's weekly address: \"The World is United in the Fight Against ISIL.\" http:\/\/t.co\/53GscJvXiR #ISIL",
  "id" : 513749547424559105,
  "created_at" : "2014-09-21 18:00:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/KrmP4g117d",
      "expanded_url" : "http:\/\/go.wh.gov\/iuwmXD",
      "display_url" : "go.wh.gov\/iuwmXD"
    } ]
  },
  "geo" : { },
  "id_str" : "513694418332028928",
  "text" : "\"This isn\u2019t America vs. ISIL. This is the people of that region vs. ISIL. It\u2019s the world vs ISIL.\" \u2014President Obama: http:\/\/t.co\/KrmP4g117d",
  "id" : 513694418332028928,
  "created_at" : "2014-09-21 14:21:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ISIL",
      "indices" : [ 122, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/53GscJvXiR",
      "expanded_url" : "http:\/\/go.wh.gov\/iuwmXD",
      "display_url" : "go.wh.gov\/iuwmXD"
    } ]
  },
  "geo" : { },
  "id_str" : "513432483652575232",
  "text" : "\"I won\u2019t commit our troops to fighting another ground war in Iraq, or in Syria.\" \u2014President Obama: http:\/\/t.co\/53GscJvXiR #ISIL",
  "id" : 513432483652575232,
  "created_at" : "2014-09-20 21:00:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ISIL",
      "indices" : [ 132, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/53GscJvXiR",
      "expanded_url" : "http:\/\/go.wh.gov\/iuwmXD",
      "display_url" : "go.wh.gov\/iuwmXD"
    } ]
  },
  "geo" : { },
  "id_str" : "513372098236911617",
  "text" : "\"We won\u2019t hesitate to take action against these terrorists...but this is not America\u2019s fight alone.\" \u2014Obama: http:\/\/t.co\/53GscJvXiR #ISIL",
  "id" : 513372098236911617,
  "created_at" : "2014-09-20 17:00:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/513335296457703425\/photo\/1",
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/Ze8gYYfreN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bx-7u08IUAMRsrd.jpg",
      "id_str" : "513335295702749187",
      "id" : 513335295702749187,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bx-7u08IUAMRsrd.jpg",
      "sizes" : [ {
        "h" : 244,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1437,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 736,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 431,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/Ze8gYYfreN"
    } ],
    "hashtags" : [ {
      "text" : "ChildhoodCancerAwarenessMonth",
      "indices" : [ 89, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513335296457703425",
  "text" : "Advocates &amp; families impacted by pediatric cancer toured the White House in honor of #ChildhoodCancerAwarenessMonth: http:\/\/t.co\/Ze8gYYfreN",
  "id" : 513335296457703425,
  "created_at" : "2014-09-20 14:34:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/53GscJvXiR",
      "expanded_url" : "http:\/\/go.wh.gov\/iuwmXD",
      "display_url" : "go.wh.gov\/iuwmXD"
    } ]
  },
  "geo" : { },
  "id_str" : "513311707544838147",
  "text" : "\"When the world is threatened, when the world needs help, it calls on America.\" \u2014President Obama: http:\/\/t.co\/53GscJvXiR",
  "id" : 513311707544838147,
  "created_at" : "2014-09-20 13:00:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/513106172254371841\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/fkNty4lVrz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bx7rWD8IQAA2lot.jpg",
      "id_str" : "513106171813969920",
      "id" : 513106171813969920,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bx7rWD8IQAA2lot.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      } ],
      "display_url" : "pic.twitter.com\/fkNty4lVrz"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/83HJ8gnyEL",
      "expanded_url" : "http:\/\/go.wh.gov\/Z7KYqd",
      "display_url" : "go.wh.gov\/Z7KYqd"
    } ]
  },
  "geo" : { },
  "id_str" : "513106172254371841",
  "text" : "President Obama signs a Continuing Resolution to keep the federal government open \u2192 http:\/\/t.co\/83HJ8gnyEL http:\/\/t.co\/fkNty4lVrz",
  "id" : 513106172254371841,
  "created_at" : "2014-09-19 23:23:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kerry washington",
      "screen_name" : "kerrywashington",
      "indices" : [ 3, 19 ],
      "id_str" : "205302299",
      "id" : 205302299
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ItsOnUs",
      "indices" : [ 128, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/GpdRyGAq2C",
      "expanded_url" : "http:\/\/ItsOnUs.org",
      "display_url" : "ItsOnUs.org"
    }, {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/hqtQaul27t",
      "expanded_url" : "http:\/\/go.wh.gov\/H2Z2Ac",
      "display_url" : "go.wh.gov\/H2Z2Ac"
    } ]
  },
  "geo" : { },
  "id_str" : "513091926065938432",
  "text" : "RT @kerrywashington: Join the fight+help stop sexual assault. \nTake pledge: http:\/\/t.co\/GpdRyGAq2C \nPSA: http:\/\/t.co\/hqtQaul27t #ItsOnUs ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/kerrywashington\/status\/512991725854687233\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/NquGiNqT9g",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bx6DQT7CMAE6Sgs.jpg",
        "id_str" : "512991723815841793",
        "id" : 512991723815841793,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bx6DQT7CMAE6Sgs.jpg",
        "sizes" : [ {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/NquGiNqT9g"
      } ],
      "hashtags" : [ {
        "text" : "ItsOnUs",
        "indices" : [ 107, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 55, 77 ],
        "url" : "http:\/\/t.co\/GpdRyGAq2C",
        "expanded_url" : "http:\/\/ItsOnUs.org",
        "display_url" : "ItsOnUs.org"
      }, {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/hqtQaul27t",
        "expanded_url" : "http:\/\/go.wh.gov\/H2Z2Ac",
        "display_url" : "go.wh.gov\/H2Z2Ac"
      } ]
    },
    "geo" : { },
    "id_str" : "512991725854687233",
    "text" : "Join the fight+help stop sexual assault. \nTake pledge: http:\/\/t.co\/GpdRyGAq2C \nPSA: http:\/\/t.co\/hqtQaul27t #ItsOnUs http:\/\/t.co\/NquGiNqT9g",
    "id" : 512991725854687233,
    "created_at" : "2014-09-19 15:48:53 +0000",
    "user" : {
      "name" : "kerry washington",
      "screen_name" : "kerrywashington",
      "protected" : false,
      "id_str" : "205302299",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778641930536284160\/3-m-BwGQ_normal.jpg",
      "id" : 205302299,
      "verified" : true
    }
  },
  "id" : 513091926065938432,
  "created_at" : "2014-09-19 22:27:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Love",
      "screen_name" : "kevinlove",
      "indices" : [ 3, 13 ],
      "id_str" : "217160945",
      "id" : 217160945
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ItsOnUs",
      "indices" : [ 15, 23 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/MRSUtrobuk",
      "expanded_url" : "http:\/\/instagram.com\/p\/tJIqEXM94z\/",
      "display_url" : "instagram.com\/p\/tJIqEXM94z\/"
    } ]
  },
  "geo" : { },
  "id_str" : "513084210731831296",
  "text" : "RT @kevinlove: #ItsOnUs to stop sexual assault. I just took the pledge to be a part of the solution, and you can too\u2026 http:\/\/t.co\/MRSUtrobuk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ItsOnUs",
        "indices" : [ 0, 8 ]
      } ],
      "urls" : [ {
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/MRSUtrobuk",
        "expanded_url" : "http:\/\/instagram.com\/p\/tJIqEXM94z\/",
        "display_url" : "instagram.com\/p\/tJIqEXM94z\/"
      } ]
    },
    "geo" : { },
    "id_str" : "513082247403274242",
    "text" : "#ItsOnUs to stop sexual assault. I just took the pledge to be a part of the solution, and you can too\u2026 http:\/\/t.co\/MRSUtrobuk",
    "id" : 513082247403274242,
    "created_at" : "2014-09-19 21:48:35 +0000",
    "user" : {
      "name" : "Kevin Love",
      "screen_name" : "kevinlove",
      "protected" : false,
      "id_str" : "217160945",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1709366033\/image_normal.jpg",
      "id" : 217160945,
      "verified" : true
    }
  },
  "id" : 513084210731831296,
  "created_at" : "2014-09-19 21:56:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joel McHale",
      "screen_name" : "joelmchale",
      "indices" : [ 3, 14 ],
      "id_str" : "14506253",
      "id" : 14506253
    }, {
      "name" : "Connie Britton",
      "screen_name" : "conniebritton",
      "indices" : [ 101, 115 ],
      "id_str" : "1905230346",
      "id" : 1905230346
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ItsOnUs",
      "indices" : [ 89, 97 ]
    }, {
      "text" : "JonHamm",
      "indices" : [ 116, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/agBJA0FrKE",
      "expanded_url" : "http:\/\/ItsOnUs.org",
      "display_url" : "ItsOnUs.org"
    } ]
  },
  "geo" : { },
  "id_str" : "513078612975943680",
  "text" : "RT @joelmchale: Sexual assault must stop. Be part of the solution http:\/\/t.co\/agBJA0FrKE #ItsOnUs RT @conniebritton #JonHamm @kerrywashingt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Connie Britton",
        "screen_name" : "conniebritton",
        "indices" : [ 85, 99 ],
        "id_str" : "1905230346",
        "id" : 1905230346
      }, {
        "name" : "kerry washington",
        "screen_name" : "kerrywashington",
        "indices" : [ 109, 125 ],
        "id_str" : "205302299",
        "id" : 205302299
      }, {
        "name" : "Randy Jackson",
        "screen_name" : "randyjackson8",
        "indices" : [ 126, 140 ],
        "id_str" : "82400064",
        "id" : 82400064
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ItsOnUs",
        "indices" : [ 73, 81 ]
      }, {
        "text" : "JonHamm",
        "indices" : [ 100, 108 ]
      } ],
      "urls" : [ {
        "indices" : [ 50, 72 ],
        "url" : "http:\/\/t.co\/agBJA0FrKE",
        "expanded_url" : "http:\/\/ItsOnUs.org",
        "display_url" : "ItsOnUs.org"
      } ]
    },
    "geo" : { },
    "id_str" : "513023257146970112",
    "text" : "Sexual assault must stop. Be part of the solution http:\/\/t.co\/agBJA0FrKE #ItsOnUs RT @conniebritton #JonHamm @kerrywashington @RandyJackson8",
    "id" : 513023257146970112,
    "created_at" : "2014-09-19 17:54:10 +0000",
    "user" : {
      "name" : "Joel McHale",
      "screen_name" : "joelmchale",
      "protected" : false,
      "id_str" : "14506253",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/763795631739510784\/66F_oKWF_normal.jpg",
      "id" : 14506253,
      "verified" : true
    }
  },
  "id" : 513078612975943680,
  "created_at" : "2014-09-19 21:34:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tumblr",
      "screen_name" : "tumblr",
      "indices" : [ 3, 10 ],
      "id_str" : "52484614",
      "id" : 52484614
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ItsOnUs",
      "indices" : [ 38, 46 ]
    } ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/bgjqv72SiE",
      "expanded_url" : "http:\/\/tmblr.co\/ZE5Fby1RC7TzN",
      "display_url" : "tmblr.co\/ZE5Fby1RC7TzN"
    } ]
  },
  "geo" : { },
  "id_str" : "513074486347038720",
  "text" : "RT @tumblr: Help stop sexual assault. #ItsOnUs http:\/\/t.co\/bgjqv72SiE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ItsOnUs",
        "indices" : [ 26, 34 ]
      } ],
      "urls" : [ {
        "indices" : [ 35, 57 ],
        "url" : "http:\/\/t.co\/bgjqv72SiE",
        "expanded_url" : "http:\/\/tmblr.co\/ZE5Fby1RC7TzN",
        "display_url" : "tmblr.co\/ZE5Fby1RC7TzN"
      } ]
    },
    "geo" : { },
    "id_str" : "513074043420160000",
    "text" : "Help stop sexual assault. #ItsOnUs http:\/\/t.co\/bgjqv72SiE",
    "id" : 513074043420160000,
    "created_at" : "2014-09-19 21:15:59 +0000",
    "user" : {
      "name" : "Tumblr",
      "screen_name" : "tumblr",
      "protected" : false,
      "id_str" : "52484614",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791014307089747968\/jqxriE5C_normal.jpg",
      "id" : 52484614,
      "verified" : true
    }
  },
  "id" : 513074486347038720,
  "created_at" : "2014-09-19 21:17:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ItsOnUs",
      "indices" : [ 61, 69 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/7aGUmPQNTW",
      "expanded_url" : "http:\/\/ItsOnUs.org",
      "display_url" : "ItsOnUs.org"
    } ]
  },
  "geo" : { },
  "id_str" : "513051541654495232",
  "text" : "FACT: 8 in 10 victims of sexual assault knew their attacker. #ItsOnUs to hold our friends accountable \u2192 http:\/\/t.co\/7aGUmPQNTW",
  "id" : 513051541654495232,
  "created_at" : "2014-09-19 19:46:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ItsOnUs",
      "indices" : [ 110, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/Udi3NPnv3e",
      "expanded_url" : "http:\/\/ItsOnUs.org",
      "display_url" : "ItsOnUs.org"
    } ]
  },
  "geo" : { },
  "id_str" : "513043684494151680",
  "text" : "RT @FLOTUS: We all have a role to play in stopping sexual assault. Take the pledge at http:\/\/t.co\/Udi3NPnv3e. #ItsOnUs http:\/\/t.co\/6QkUq1Cd\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ItsOnUs",
        "indices" : [ 98, 106 ]
      } ],
      "urls" : [ {
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/Udi3NPnv3e",
        "expanded_url" : "http:\/\/ItsOnUs.org",
        "display_url" : "ItsOnUs.org"
      }, {
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/6QkUq1CdyL",
        "expanded_url" : "http:\/\/youtu.be\/wNMZo31LziM",
        "display_url" : "youtu.be\/wNMZo31LziM"
      } ]
    },
    "geo" : { },
    "id_str" : "513028957810470912",
    "text" : "We all have a role to play in stopping sexual assault. Take the pledge at http:\/\/t.co\/Udi3NPnv3e. #ItsOnUs http:\/\/t.co\/6QkUq1CdyL",
    "id" : 513028957810470912,
    "created_at" : "2014-09-19 18:16:49 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 513043684494151680,
  "created_at" : "2014-09-19 19:15:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Connie Britton",
      "screen_name" : "conniebritton",
      "indices" : [ 3, 17 ],
      "id_str" : "1905230346",
      "id" : 1905230346
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ItsOnUs",
      "indices" : [ 19, 27 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/sfIdI6XDlV",
      "expanded_url" : "http:\/\/ItsOnUs.org",
      "display_url" : "ItsOnUs.org"
    } ]
  },
  "geo" : { },
  "id_str" : "513029993677742080",
  "text" : "RT @conniebritton: #ItsOnUs to stop sexual assault. Take the pledge and be a part of the solution at http:\/\/t.co\/sfIdI6XDlV. http:\/\/t.co\/Gt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ItsOnUs",
        "indices" : [ 0, 8 ]
      } ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/sfIdI6XDlV",
        "expanded_url" : "http:\/\/ItsOnUs.org",
        "display_url" : "ItsOnUs.org"
      }, {
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/GtTjTuPalJ",
        "expanded_url" : "http:\/\/go.wh.gov\/H2Z2Ac",
        "display_url" : "go.wh.gov\/H2Z2Ac"
      } ]
    },
    "geo" : { },
    "id_str" : "513001644259573761",
    "text" : "#ItsOnUs to stop sexual assault. Take the pledge and be a part of the solution at http:\/\/t.co\/sfIdI6XDlV. http:\/\/t.co\/GtTjTuPalJ",
    "id" : 513001644259573761,
    "created_at" : "2014-09-19 16:28:17 +0000",
    "user" : {
      "name" : "Connie Britton",
      "screen_name" : "conniebritton",
      "protected" : false,
      "id_str" : "1905230346",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/795623148842524672\/CqwRofAF_normal.jpg",
      "id" : 1905230346,
      "verified" : true
    }
  },
  "id" : 513029993677742080,
  "created_at" : "2014-09-19 18:20:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sylvia Burwell",
      "screen_name" : "SecBurwell",
      "indices" : [ 3, 14 ],
      "id_str" : "2458567464",
      "id" : 2458567464
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ItsOnUs",
      "indices" : [ 16, 24 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/rKlx0XYbls",
      "expanded_url" : "http:\/\/ItsOnUs.org",
      "display_url" : "ItsOnUs.org"
    } ]
  },
  "geo" : { },
  "id_str" : "513024737690521600",
  "text" : "RT @SecBurwell: #ItsOnUs to stop sexual assault. Be more than a bystander \u2013 join me &amp; take the pledge: http:\/\/t.co\/rKlx0XYbls.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ItsOnUs",
        "indices" : [ 0, 8 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/rKlx0XYbls",
        "expanded_url" : "http:\/\/ItsOnUs.org",
        "display_url" : "ItsOnUs.org"
      } ]
    },
    "geo" : { },
    "id_str" : "512952900218535936",
    "text" : "#ItsOnUs to stop sexual assault. Be more than a bystander \u2013 join me &amp; take the pledge: http:\/\/t.co\/rKlx0XYbls.",
    "id" : 512952900218535936,
    "created_at" : "2014-09-19 13:14:36 +0000",
    "user" : {
      "name" : "Sylvia Burwell",
      "screen_name" : "SecBurwell",
      "protected" : false,
      "id_str" : "2458567464",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567351512351793152\/jMgeUhVq_normal.jpeg",
      "id" : 2458567464,
      "verified" : true
    }
  },
  "id" : 513024737690521600,
  "created_at" : "2014-09-19 18:00:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ItsOnUs",
      "indices" : [ 70, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/7aGUmPQNTW",
      "expanded_url" : "http:\/\/ItsOnUs.org",
      "display_url" : "ItsOnUs.org"
    } ]
  },
  "geo" : { },
  "id_str" : "513021924877017088",
  "text" : "FACT: 1 in 5 women and 1 in 16 men are sexually assaulted in college. #ItsOnUs to stop sexual assault \u2192 http:\/\/t.co\/7aGUmPQNTW",
  "id" : 513021924877017088,
  "created_at" : "2014-09-19 17:48:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Planned Parenthood",
      "screen_name" : "PPact",
      "indices" : [ 3, 9 ],
      "id_str" : "22162854",
      "id" : 22162854
    }, {
      "name" : "kerry washington",
      "screen_name" : "kerrywashington",
      "indices" : [ 41, 57 ],
      "id_str" : "205302299",
      "id" : 205302299
    }, {
      "name" : "Connie Britton",
      "screen_name" : "conniebritton",
      "indices" : [ 59, 73 ],
      "id_str" : "1905230346",
      "id" : 1905230346
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 75, 78 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 142 ],
      "url" : "https:\/\/t.co\/ieR5UZMNDj",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=wNMZo31LziM",
      "display_url" : "youtube.com\/watch?v=wNMZo3\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "513009822682603521",
  "text" : "RT @PPact: Watch a powerful new PSA with @kerrywashington, @conniebritton, @VP, &amp; more\u2014we can stop sexual assault: https:\/\/t.co\/ieR5UZMNDj \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "kerry washington",
        "screen_name" : "kerrywashington",
        "indices" : [ 30, 46 ],
        "id_str" : "205302299",
        "id" : 205302299
      }, {
        "name" : "Connie Britton",
        "screen_name" : "conniebritton",
        "indices" : [ 48, 62 ],
        "id_str" : "1905230346",
        "id" : 1905230346
      }, {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 64, 67 ],
        "id_str" : "325830217",
        "id" : 325830217
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ItsOnUs",
        "indices" : [ 132, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/ieR5UZMNDj",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=wNMZo31LziM",
        "display_url" : "youtube.com\/watch?v=wNMZo3\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "512978162905784320",
    "text" : "Watch a powerful new PSA with @kerrywashington, @conniebritton, @VP, &amp; more\u2014we can stop sexual assault: https:\/\/t.co\/ieR5UZMNDj #ItsOnUs",
    "id" : 512978162905784320,
    "created_at" : "2014-09-19 14:54:59 +0000",
    "user" : {
      "name" : "Planned Parenthood",
      "screen_name" : "PPact",
      "protected" : false,
      "id_str" : "22162854",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796736794452598784\/OVVnbWE7_normal.jpg",
      "id" : 22162854,
      "verified" : true
    }
  },
  "id" : 513009822682603521,
  "created_at" : "2014-09-19 17:00:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ItsOnUs",
      "indices" : [ 106, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513003260131942400",
  "text" : "\"Our nation\u2019s success depends on how we value and defend the rights of women and girls.\" \u2014President Obama #ItsOnUs",
  "id" : 513003260131942400,
  "created_at" : "2014-09-19 16:34:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ItsOnUs",
      "indices" : [ 117, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/7aGUmPQNTW",
      "expanded_url" : "http:\/\/ItsOnUs.org",
      "display_url" : "ItsOnUs.org"
    } ]
  },
  "geo" : { },
  "id_str" : "513003017667637249",
  "text" : "\"Go to http:\/\/t.co\/7aGUmPQNTW...take a pledge to help keep women and men safe from sexual assault.\" \u2014President Obama #ItsOnUs",
  "id" : 513003017667637249,
  "created_at" : "2014-09-19 16:33:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ItsOnUs",
      "indices" : [ 131, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513002312085020672",
  "text" : "\"It is on all of us to reject the quiet tolerance of sexual assault and to refuse to accept what\u2019s unacceptable.\" \u2014President Obama #ItsOnUs",
  "id" : 513002312085020672,
  "created_at" : "2014-09-19 16:30:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ItsOnUs",
      "indices" : [ 130, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513001865630728192",
  "text" : "\"Unless women are allowed to reach their full potential, America cannot reach its full potential. So we've got to change.\" \u2014Obama #ItsOnUs",
  "id" : 513001865630728192,
  "created_at" : "2014-09-19 16:29:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ItsOnUs",
      "indices" : [ 124, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513001435404173312",
  "text" : "\"Our society still does not sufficiently value women. We still don\u2019t condemn sexual assault as loudly as we should.\" \u2014Obama #ItsOnUs",
  "id" : 513001435404173312,
  "created_at" : "2014-09-19 16:27:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513001300272099330",
  "text" : "RT @WHLive: \"Today, we\u2019re taking a step &amp; joining with people across the country to change our culture and help prevent sexual assault.\" \u2014O\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ItsOnUs",
        "indices" : [ 136, 144 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "513001240385835008",
    "text" : "\"Today, we\u2019re taking a step &amp; joining with people across the country to change our culture and help prevent sexual assault.\" \u2014Obama #ItsOnUs",
    "id" : 513001240385835008,
    "created_at" : "2014-09-19 16:26:41 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 513001300272099330,
  "created_at" : "2014-09-19 16:26:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513000782598516736",
  "text" : "\"Every child deserves an education that allows them to fulfill their God-given potential, free from fear of intimidation or violence\" \u2014Obama",
  "id" : 513000782598516736,
  "created_at" : "2014-09-19 16:24:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ItsOnUs",
      "indices" : [ 110, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513000695663190016",
  "text" : "\"It is an affront to our basic humanity. It insults our most basic values\" \u2014President Obama on sexual assault #ItsOnUs",
  "id" : 513000695663190016,
  "created_at" : "2014-09-19 16:24:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ItsOnUs",
      "indices" : [ 111, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513000408428863488",
  "text" : "RT @WHLive: \"An estimated 1 in 5 women has been sexually assaulted during her college years.\" \u2014President Obama #ItsOnUs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ItsOnUs",
        "indices" : [ 99, 107 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "513000292619919360",
    "text" : "\"An estimated 1 in 5 women has been sexually assaulted during her college years.\" \u2014President Obama #ItsOnUs",
    "id" : 513000292619919360,
    "created_at" : "2014-09-19 16:22:55 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 513000408428863488,
  "created_at" : "2014-09-19 16:23:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ItsOnUs",
      "indices" : [ 131, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513000209144905729",
  "text" : "\"Sexual assault is no longer something that we, as a nation, can turn away from and say, that\u2019s not our problem.\" \u2014President Obama #ItsOnUs",
  "id" : 513000209144905729,
  "created_at" : "2014-09-19 16:22:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ItsOnUs",
      "indices" : [ 132, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513000143839567873",
  "text" : "\"This is on all of us to fight campus sexual assault. You are not alone. We\u2019ve got your back\" \u2014Obama to survivors of sexual assault #ItsOnUs",
  "id" : 513000143839567873,
  "created_at" : "2014-09-19 16:22:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ItsOnUs",
      "indices" : [ 132, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512999928797618176",
  "text" : "\"To the survivors who are leading the fight against sexual assault on campuses\u2014your efforts have helped to start a movement\" \u2014Obama #ItsOnUs",
  "id" : 512999928797618176,
  "created_at" : "2014-09-19 16:21:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ItsOnUs",
      "indices" : [ 125, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512999089295077376",
  "text" : "\"We\u2019re here today to talk about an issue that\u2019s a priority for me\u2014and that\u2019s ending campus sexual assault.\" \u2014President Obama #ItsOnUs",
  "id" : 512999089295077376,
  "created_at" : "2014-09-19 16:18:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 38, 41 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ItsOnUs",
      "indices" : [ 136, 144 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/6tOVxBCTFZ",
      "expanded_url" : "http:\/\/go.wh.gov\/oweT8i",
      "display_url" : "go.wh.gov\/oweT8i"
    } ]
  },
  "geo" : { },
  "id_str" : "512996046163943424",
  "text" : "Watch live: President Obama &amp; the @VP speak on how all of us have a role to play in stopping sexual assault. http:\/\/t.co\/6tOVxBCTFZ #ItsOnUs",
  "id" : 512996046163943424,
  "created_at" : "2014-09-19 16:06:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ItsOnUs",
      "indices" : [ 127, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/6tOVxBCTFZ",
      "expanded_url" : "http:\/\/go.wh.gov\/oweT8i",
      "display_url" : "go.wh.gov\/oweT8i"
    } ]
  },
  "geo" : { },
  "id_str" : "512987612232310784",
  "text" : "At 11:45am ET, President Obama speaks on how all of us have a role to play in stopping sexual assault \u2192 http:\/\/t.co\/6tOVxBCTFZ #ItsOnUs",
  "id" : 512987612232310784,
  "created_at" : "2014-09-19 15:32:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/512980419437158400\/photo\/1",
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/5qJyAPGP6Q",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bx54-P_IQAA2Pb7.png",
      "id_str" : "512980418405351424",
      "id" : 512980418405351424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bx54-P_IQAA2Pb7.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 242,
        "resize" : "fit",
        "w" : 932
      }, {
        "h" : 88,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 156,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 242,
        "resize" : "fit",
        "w" : 932
      } ],
      "display_url" : "pic.twitter.com\/5qJyAPGP6Q"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512980419437158400",
  "text" : "\"We welcome the result of yesterday\u2019s referendum on Scottish independence.\" \u2014President Obama http:\/\/t.co\/5qJyAPGP6Q",
  "id" : 512980419437158400,
  "created_at" : "2014-09-19 15:03:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SB Nation",
      "screen_name" : "SBNation",
      "indices" : [ 3, 12 ],
      "id_str" : "16745015",
      "id" : 16745015
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SBNation\/status\/512966978194386944\/photo\/1",
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/2GqOEqb8bI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bx5sv3-CEAELiqe.png",
      "id_str" : "512966977300598785",
      "id" : 512966977300598785,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bx5sv3-CEAELiqe.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 486,
        "resize" : "fit",
        "w" : 730
      }, {
        "h" : 486,
        "resize" : "fit",
        "w" : 730
      }, {
        "h" : 399,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/2GqOEqb8bI"
    } ],
    "hashtags" : [ {
      "text" : "ItsOnUs",
      "indices" : [ 14, 22 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/GN3EqsnOrX",
      "expanded_url" : "http:\/\/www.sbnation.com\/2014\/9\/19\/6523981\/it-on-us-psa-video-white-house",
      "display_url" : "sbnation.com\/2014\/9\/19\/6523\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "512979294285742080",
  "text" : "RT @SBNation: #ItsOnUs to prevent sexual assault. Watch this new PSA: http:\/\/t.co\/GN3EqsnOrX http:\/\/t.co\/2GqOEqb8bI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SBNation\/status\/512966978194386944\/photo\/1",
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/2GqOEqb8bI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bx5sv3-CEAELiqe.png",
        "id_str" : "512966977300598785",
        "id" : 512966977300598785,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bx5sv3-CEAELiqe.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 486,
          "resize" : "fit",
          "w" : 730
        }, {
          "h" : 486,
          "resize" : "fit",
          "w" : 730
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/2GqOEqb8bI"
      } ],
      "hashtags" : [ {
        "text" : "ItsOnUs",
        "indices" : [ 0, 8 ]
      } ],
      "urls" : [ {
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/GN3EqsnOrX",
        "expanded_url" : "http:\/\/www.sbnation.com\/2014\/9\/19\/6523981\/it-on-us-psa-video-white-house",
        "display_url" : "sbnation.com\/2014\/9\/19\/6523\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "512966978194386944",
    "text" : "#ItsOnUs to prevent sexual assault. Watch this new PSA: http:\/\/t.co\/GN3EqsnOrX http:\/\/t.co\/2GqOEqb8bI",
    "id" : 512966978194386944,
    "created_at" : "2014-09-19 14:10:32 +0000",
    "user" : {
      "name" : "SB Nation",
      "screen_name" : "SBNation",
      "protected" : false,
      "id_str" : "16745015",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/770307808768192516\/yVctOSZ-_normal.jpg",
      "id" : 16745015,
      "verified" : true
    }
  },
  "id" : 512979294285742080,
  "created_at" : "2014-09-19 14:59:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivia Munn",
      "screen_name" : "oliviamunn",
      "indices" : [ 3, 14 ],
      "id_str" : "15888142",
      "id" : 15888142
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ItsOnUs",
      "indices" : [ 16, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512976166974926848",
  "text" : "RT @oliviamunn: #ItsOnUs to:\n\nStep up and say something.\n\nNot look the other way.\n\nTake the pledge to help stop sexual assault.\n\nhttp:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ItsOnUs",
        "indices" : [ 0, 8 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/lv7myAlOHO",
        "expanded_url" : "http:\/\/go.wh.gov\/H2Z2Ac",
        "display_url" : "go.wh.gov\/H2Z2Ac"
      } ]
    },
    "geo" : { },
    "id_str" : "512920506564370432",
    "text" : "#ItsOnUs to:\n\nStep up and say something.\n\nNot look the other way.\n\nTake the pledge to help stop sexual assault.\n\nhttp:\/\/t.co\/lv7myAlOHO",
    "id" : 512920506564370432,
    "created_at" : "2014-09-19 11:05:53 +0000",
    "user" : {
      "name" : "Olivia Munn",
      "screen_name" : "oliviamunn",
      "protected" : false,
      "id_str" : "15888142",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/536199408753201154\/Q0MkiYb0_normal.jpeg",
      "id" : 15888142,
      "verified" : true
    }
  },
  "id" : 512976166974926848,
  "created_at" : "2014-09-19 14:47:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "grant hill",
      "screen_name" : "realgranthill33",
      "indices" : [ 3, 19 ],
      "id_str" : "171485965",
      "id" : 171485965
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ItsOnUs",
      "indices" : [ 21, 29 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/2E5m9yps5X",
      "expanded_url" : "http:\/\/ItsOnUs.org",
      "display_url" : "ItsOnUs.org"
    } ]
  },
  "geo" : { },
  "id_str" : "512974689732689920",
  "text" : "RT @realgranthill33: #ItsOnUs to stop sexual assault. Take the pledge and be a part of the solution at http:\/\/t.co\/2E5m9yps5X. http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.twitter.com\" rel=\"nofollow\"\u003ETwitter for Windows Phone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ItsOnUs",
        "indices" : [ 0, 8 ]
      } ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/2E5m9yps5X",
        "expanded_url" : "http:\/\/ItsOnUs.org",
        "display_url" : "ItsOnUs.org"
      }, {
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/zGkcC1K2lS",
        "expanded_url" : "http:\/\/go.wh.gov\/H2Z2Ac",
        "display_url" : "go.wh.gov\/H2Z2Ac"
      } ]
    },
    "geo" : { },
    "id_str" : "512944178222071808",
    "text" : "#ItsOnUs to stop sexual assault. Take the pledge and be a part of the solution at http:\/\/t.co\/2E5m9yps5X. http:\/\/t.co\/zGkcC1K2lS",
    "id" : 512944178222071808,
    "created_at" : "2014-09-19 12:39:56 +0000",
    "user" : {
      "name" : "grant hill",
      "screen_name" : "realgranthill33",
      "protected" : false,
      "id_str" : "171485965",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/788800344490930176\/aglaEr-y_normal.jpg",
      "id" : 171485965,
      "verified" : true
    }
  },
  "id" : 512974689732689920,
  "created_at" : "2014-09-19 14:41:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Team USA ",
      "screen_name" : "USOlympic",
      "indices" : [ 3, 13 ],
      "id_str" : "3061782654",
      "id" : 3061782654
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TeamUSA",
      "indices" : [ 71, 79 ]
    }, {
      "text" : "ItsOnUs",
      "indices" : [ 123, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/ySGjo8PPvj",
      "expanded_url" : "http:\/\/ItsOnUs.org",
      "display_url" : "ItsOnUs.org"
    } ]
  },
  "geo" : { },
  "id_str" : "512972170784673792",
  "text" : "RT @USOlympic: Everyone has a role to play in stopping sexual assault. #TeamUSA took the pledge at http:\/\/t.co\/ySGjo8PPvj. #ItsOnUs http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/USOlympic\/status\/512953106737672192\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/5Fvq9mFabV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bx5gIRwIAAAOeyv.jpg",
        "id_str" : "512953102887288832",
        "id" : 512953102887288832,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bx5gIRwIAAAOeyv.jpg",
        "sizes" : [ {
          "h" : 1650,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 660,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1126,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 374,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/5Fvq9mFabV"
      } ],
      "hashtags" : [ {
        "text" : "TeamUSA",
        "indices" : [ 56, 64 ]
      }, {
        "text" : "ItsOnUs",
        "indices" : [ 108, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/ySGjo8PPvj",
        "expanded_url" : "http:\/\/ItsOnUs.org",
        "display_url" : "ItsOnUs.org"
      } ]
    },
    "geo" : { },
    "id_str" : "512953106737672192",
    "text" : "Everyone has a role to play in stopping sexual assault. #TeamUSA took the pledge at http:\/\/t.co\/ySGjo8PPvj. #ItsOnUs http:\/\/t.co\/5Fvq9mFabV",
    "id" : 512953106737672192,
    "created_at" : "2014-09-19 13:15:25 +0000",
    "user" : {
      "name" : "U.S. Olympic Team",
      "screen_name" : "TeamUSA",
      "protected" : false,
      "id_str" : "21870081",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/781162053104840704\/u4wNd-62_normal.jpg",
      "id" : 21870081,
      "verified" : true
    }
  },
  "id" : 512972170784673792,
  "created_at" : "2014-09-19 14:31:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ItsOnUs",
      "indices" : [ 0, 8 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/7aGUmPQNTW",
      "expanded_url" : "http:\/\/ItsOnUs.org",
      "display_url" : "ItsOnUs.org"
    }, {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/jXgykjLwlc",
      "expanded_url" : "http:\/\/youtu.be\/wNMZo31LziM",
      "display_url" : "youtu.be\/wNMZo31LziM"
    } ]
  },
  "geo" : { },
  "id_str" : "512967009404194816",
  "text" : "#ItsOnUs to realize we all have a role to play in stopping sexual assault. Take the pledge at http:\/\/t.co\/7aGUmPQNTW http:\/\/t.co\/jXgykjLwlc",
  "id" : 512967009404194816,
  "created_at" : "2014-09-19 14:10:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ItsOnUs",
      "indices" : [ 10, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512963652379770880",
  "text" : "RT @vj44: #ItsOnUs to:\nStep up and say something.\nNot look the other way.\nTake the pledge to help stop sexual assault.\nhttp:\/\/t.co\/4MrG5PG8\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ItsOnUs",
        "indices" : [ 0, 8 ]
      } ],
      "urls" : [ {
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/4MrG5PG8So",
        "expanded_url" : "http:\/\/itsonus.org",
        "display_url" : "itsonus.org"
      } ]
    },
    "geo" : { },
    "id_str" : "512957860117237762",
    "text" : "#ItsOnUs to:\nStep up and say something.\nNot look the other way.\nTake the pledge to help stop sexual assault.\nhttp:\/\/t.co\/4MrG5PG8So",
    "id" : 512957860117237762,
    "created_at" : "2014-09-19 13:34:18 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 512963652379770880,
  "created_at" : "2014-09-19 13:57:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ISIL",
      "indices" : [ 119, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512739392704626688",
  "text" : "\"When you harm our citizens, when you threaten the United States\u2014it doesn\u2019t divide us, it unites us.\" \u2014President Obama #ISIL",
  "id" : 512739392704626688,
  "created_at" : "2014-09-18 23:06:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ISIL",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512738875433701376",
  "text" : "\"We are strongest as a nation when the President and Congress work together.\" \u2014President Obama #ISIL",
  "id" : 512738875433701376,
  "created_at" : "2014-09-18 23:04:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ISIL",
      "indices" : [ 130, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512738665701711873",
  "text" : "\"The House and the Senate have now voted to support a key element of our strategy.\" \u2014Obama on our strategy to degrade and destroy #ISIL",
  "id" : 512738665701711873,
  "created_at" : "2014-09-18 23:03:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ISIL",
      "indices" : [ 124, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512738325149409282",
  "text" : "\"The United States continues to build a broad international coalition to degrade and ultimately destroy the terrorist group #ISIL.\" \u2014Obama",
  "id" : 512738325149409282,
  "created_at" : "2014-09-18 23:01:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/KvadYk9atb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "512738256098570242",
  "text" : "Happening now: President Obama delivers a statement on Congressional passage of the Continuing Resolution \u2192 http:\/\/t.co\/KvadYk9atb",
  "id" : 512738256098570242,
  "created_at" : "2014-09-18 23:01:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/KvadYk9atb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "512734125581549569",
  "text" : "At 7pm ET, President Obama delivers a statement on Congressional passage of the Continuing Resolution. Watch \u2192 http:\/\/t.co\/KvadYk9atb",
  "id" : 512734125581549569,
  "created_at" : "2014-09-18 22:45:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "U.S. Air Force",
      "screen_name" : "usairforce",
      "indices" : [ 29, 40 ],
      "id_str" : "19611483",
      "id" : 19611483
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AFBday",
      "indices" : [ 120, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512713205865394176",
  "text" : "RT @VP: Happy 67th birthday, @usairforce. You continue to be the most innovative &amp; powerful Air Force in the world. #AFBday http:\/\/t.co\/qqz\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "U.S. Air Force",
        "screen_name" : "usairforce",
        "indices" : [ 21, 32 ],
        "id_str" : "19611483",
        "id" : 19611483
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/512705886507106304\/photo\/1",
        "indices" : [ 120, 142 ],
        "url" : "http:\/\/t.co\/qqzISkMkou",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bx1_SVECIAA4tDC.jpg",
        "id_str" : "512705885458538496",
        "id" : 512705885458538496,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bx1_SVECIAA4tDC.jpg",
        "sizes" : [ {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/qqzISkMkou"
      } ],
      "hashtags" : [ {
        "text" : "AFBday",
        "indices" : [ 112, 119 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "512705886507106304",
    "text" : "Happy 67th birthday, @usairforce. You continue to be the most innovative &amp; powerful Air Force in the world. #AFBday http:\/\/t.co\/qqzISkMkou",
    "id" : 512705886507106304,
    "created_at" : "2014-09-18 20:53:03 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 512713205865394176,
  "created_at" : "2014-09-18 21:22:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 81, 90 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 91, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/m6GGmDqfPb",
      "expanded_url" : "http:\/\/huff.to\/1r2Mdao",
      "display_url" : "huff.to\/1r2Mdao"
    } ]
  },
  "geo" : { },
  "id_str" : "512685046260436992",
  "text" : "\"Almost all Obamacare enrollees are paying for coverage.\" http:\/\/t.co\/m6GGmDqfPb #ACAWorks #GetCovered",
  "id" : 512685046260436992,
  "created_at" : "2014-09-18 19:30:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kristin Lee",
      "screen_name" : "Lee44",
      "indices" : [ 3, 9 ],
      "id_str" : "2800630026",
      "id" : 2800630026
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/29e9pVdq75",
      "expanded_url" : "http:\/\/wh.gov\/ilT0V",
      "display_url" : "wh.gov\/ilT0V"
    } ]
  },
  "geo" : { },
  "id_str" : "512681012858716161",
  "text" : "RT @Lee44: White House announces new Executive Actions to combat antibiotic resistance and save lives: http:\/\/t.co\/29e9pVdq75",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/29e9pVdq75",
        "expanded_url" : "http:\/\/wh.gov\/ilT0V",
        "display_url" : "wh.gov\/ilT0V"
      } ]
    },
    "geo" : { },
    "id_str" : "512680888182665216",
    "text" : "White House announces new Executive Actions to combat antibiotic resistance and save lives: http:\/\/t.co\/29e9pVdq75",
    "id" : 512680888182665216,
    "created_at" : "2014-09-18 19:13:43 +0000",
    "user" : {
      "name" : "Kristin Lee",
      "screen_name" : "Lee44",
      "protected" : false,
      "id_str" : "2800630026",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/626378024359870464\/dc8kq4yl_normal.png",
      "id" : 2800630026,
      "verified" : true
    }
  },
  "id" : 512681012858716161,
  "created_at" : "2014-09-18 19:14:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/gGOuduLdrZ",
      "expanded_url" : "http:\/\/i.instagram.com\/p\/tGFxlfFwZX\/?modal=true",
      "display_url" : "i.instagram.com\/p\/tGFxlfFwZX\/?\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "512662701316001792",
  "text" : "RT @VP: This nation is strongest when every voice is heard and when everyone has a seat at the table. http:\/\/t.co\/gGOuduLdrZ http:\/\/t.co\/oZ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/512659863822815232\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/oZT8lCvuhR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bx1VbOsCEAEKvX5.png",
        "id_str" : "512659858877714433",
        "id" : 512659858877714433,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bx1VbOsCEAEKvX5.png",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1500
        } ],
        "display_url" : "pic.twitter.com\/oZT8lCvuhR"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/gGOuduLdrZ",
        "expanded_url" : "http:\/\/i.instagram.com\/p\/tGFxlfFwZX\/?modal=true",
        "display_url" : "i.instagram.com\/p\/tGFxlfFwZX\/?\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "512659863822815232",
    "text" : "This nation is strongest when every voice is heard and when everyone has a seat at the table. http:\/\/t.co\/gGOuduLdrZ http:\/\/t.co\/oZT8lCvuhR",
    "id" : 512659863822815232,
    "created_at" : "2014-09-18 17:50:10 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 512662701316001792,
  "created_at" : "2014-09-18 18:01:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 131, 144 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/uyvoBRpkuO",
      "expanded_url" : "http:\/\/go.wh.gov\/UVe5Dp",
      "display_url" : "go.wh.gov\/UVe5Dp"
    } ]
  },
  "geo" : { },
  "id_str" : "512647991556337665",
  "text" : "FACT: We're investing $68 million in 540 clean energy &amp; energy efficiency projects across the country \u2192 http:\/\/t.co\/uyvoBRpkuO #ActOnClimate",
  "id" : 512647991556337665,
  "created_at" : "2014-09-18 17:03:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 27, 40 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/uyvoBRpkuO",
      "expanded_url" : "http:\/\/go.wh.gov\/UVe5Dp",
      "display_url" : "go.wh.gov\/UVe5Dp"
    } ]
  },
  "geo" : { },
  "id_str" : "512630981589995521",
  "text" : "FACT: Today's new steps to #ActOnClimate will save homes and businesses more than $10 billion on energy bills. http:\/\/t.co\/uyvoBRpkuO",
  "id" : 512630981589995521,
  "created_at" : "2014-09-18 15:55:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 13, 26 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/biVZlVxFZm",
      "expanded_url" : "http:\/\/usat.ly\/1ud1qEz",
      "display_url" : "usat.ly\/1ud1qEz"
    } ]
  },
  "geo" : { },
  "id_str" : "512618585194500097",
  "text" : "New steps to #ActOnClimate will:\nSave homes and businesses $10 billion on energy bills \u2713\n\u2704 carbon pollution \u2713\nhttp:\/\/t.co\/biVZlVxFZm",
  "id" : 512618585194500097,
  "created_at" : "2014-09-18 15:06:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    }, {
      "name" : "100Kin10",
      "screen_name" : "100Kin10",
      "indices" : [ 85, 94 ],
      "id_str" : "381073617",
      "id" : 381073617
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/zw9Dy0MSCB",
      "expanded_url" : "http:\/\/blowmindsteachstem.com\/",
      "display_url" : "blowmindsteachstem.com"
    }, {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/il42JZTzek",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=WxVO_5RGM4A",
      "display_url" : "youtube.com\/watch?v=WxVO_5\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "512606678991527936",
  "text" : "RT @whitehouseostp: Answering the President's call to train 100k more STEM teachers: @100kin10 http:\/\/t.co\/zw9Dy0MSCB http:\/\/t.co\/il42JZTzek",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "100Kin10",
        "screen_name" : "100Kin10",
        "indices" : [ 65, 74 ],
        "id_str" : "381073617",
        "id" : 381073617
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/zw9Dy0MSCB",
        "expanded_url" : "http:\/\/blowmindsteachstem.com\/",
        "display_url" : "blowmindsteachstem.com"
      }, {
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/il42JZTzek",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=WxVO_5RGM4A",
        "display_url" : "youtube.com\/watch?v=WxVO_5\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "512604024668188672",
    "text" : "Answering the President's call to train 100k more STEM teachers: @100kin10 http:\/\/t.co\/zw9Dy0MSCB http:\/\/t.co\/il42JZTzek",
    "id" : 512604024668188672,
    "created_at" : "2014-09-18 14:08:17 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 512606678991527936,
  "created_at" : "2014-09-18 14:18:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/VZfDYlekX8",
      "expanded_url" : "http:\/\/youtu.be\/a_iIWx84dyk",
      "display_url" : "youtu.be\/a_iIWx84dyk"
    } ]
  },
  "geo" : { },
  "id_str" : "512390627539955714",
  "text" : "\"If you threaten America, you will find no safe haven.\" \u2014President Obama on our strategy to degrade and destroy ISIL: http:\/\/t.co\/VZfDYlekX8",
  "id" : 512390627539955714,
  "created_at" : "2014-09-18 00:00:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/512371755315658752\/photo\/1",
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/7gqPhrjbIs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BxxPZVWIQAAXYYo.png",
      "id_str" : "512371754258677760",
      "id" : 512371754258677760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxxPZVWIQAAXYYo.png",
      "sizes" : [ {
        "h" : 130,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 368,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 368,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 230,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/7gqPhrjbIs"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512371755315658752",
  "text" : "President Obama on the House vote to authorize the Title X Train &amp; Equip Program for the moderate Syrian opposition: http:\/\/t.co\/7gqPhrjbIs",
  "id" : 512371755315658752,
  "created_at" : "2014-09-17 22:45:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/9ZY0etAzQo",
      "expanded_url" : "http:\/\/go.wh.gov\/fxJXWk",
      "display_url" : "go.wh.gov\/fxJXWk"
    } ]
  },
  "geo" : { },
  "id_str" : "512349665933533185",
  "text" : "Worth sharing: 5 things you should know about our strategy to degrade and destroy ISIL \u2192 http:\/\/t.co\/9ZY0etAzQo",
  "id" : 512349665933533185,
  "created_at" : "2014-09-17 21:17:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HappyConstitutionDay",
      "indices" : [ 79, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/CDlJQFvW9t",
      "expanded_url" : "http:\/\/go.wh.gov\/Upgsk8",
      "display_url" : "go.wh.gov\/Upgsk8"
    } ]
  },
  "geo" : { },
  "id_str" : "512336250574221312",
  "text" : "Go behind the scenes at the Constitutional Convention \u2192 http:\/\/t.co\/CDlJQFvW9t #HappyConstitutionDay",
  "id" : 512336250574221312,
  "created_at" : "2014-09-17 20:24:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512323729997967360",
  "text" : "The UK is an extraordinary partner for America and a force for good in an unstable world. I hope it remains strong, robust and united. -bo",
  "id" : 512323729997967360,
  "created_at" : "2014-09-17 19:34:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    }, {
      "name" : "Rick Mastracchio",
      "screen_name" : "AstroRM",
      "indices" : [ 64, 72 ],
      "id_str" : "541158674",
      "id" : 541158674
    }, {
      "name" : "Koichi Wakata",
      "screen_name" : "Astro_Wakata",
      "indices" : [ 79, 92 ],
      "id_str" : "1081962504",
      "id" : 1081962504
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "askNASA",
      "indices" : [ 120, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/U5qP5NYUVY",
      "expanded_url" : "http:\/\/go.nasa.gov\/Xr8LWK",
      "display_url" : "go.nasa.gov\/Xr8LWK"
    } ]
  },
  "geo" : { },
  "id_str" : "512308340140281856",
  "text" : "RT @NASA: LIVE Now: G+ Hangout on Observing Earth from Space w\/ @AstroRM &amp; @Astro_Wakata: http:\/\/t.co\/U5qP5NYUVY Q? #askNASA\u00A0 http:\/\/t.co\/2\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.exacttarget.com\/social\" rel=\"nofollow\"\u003ESocialEngage\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Rick Mastracchio",
        "screen_name" : "AstroRM",
        "indices" : [ 54, 62 ],
        "id_str" : "541158674",
        "id" : 541158674
      }, {
        "name" : "Koichi Wakata",
        "screen_name" : "Astro_Wakata",
        "indices" : [ 69, 82 ],
        "id_str" : "1081962504",
        "id" : 1081962504
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NASA\/status\/512307957825298432\/photo\/1",
        "indices" : [ 120, 142 ],
        "url" : "http:\/\/t.co\/2o9xcazwT2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BxwVX4ZIIAA6U0t.jpg",
        "id_str" : "512307957632344064",
        "id" : 512307957632344064,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxwVX4ZIIAA6U0t.jpg",
        "sizes" : [ {
          "h" : 397,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 397,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 225,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 397,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/2o9xcazwT2"
      } ],
      "hashtags" : [ {
        "text" : "askNASA",
        "indices" : [ 110, 118 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/U5qP5NYUVY",
        "expanded_url" : "http:\/\/go.nasa.gov\/Xr8LWK",
        "display_url" : "go.nasa.gov\/Xr8LWK"
      } ]
    },
    "geo" : { },
    "id_str" : "512307957825298432",
    "text" : "LIVE Now: G+ Hangout on Observing Earth from Space w\/ @AstroRM &amp; @Astro_Wakata: http:\/\/t.co\/U5qP5NYUVY Q? #askNASA\u00A0 http:\/\/t.co\/2o9xcazwT2",
    "id" : 512307957825298432,
    "created_at" : "2014-09-17 18:31:50 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 512308340140281856,
  "created_at" : "2014-09-17 18:33:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 16, 31 ],
      "id_str" : "33998183",
      "id" : 33998183
    }, {
      "name" : "Miss America Org",
      "screen_name" : "MissAmericaOrg",
      "indices" : [ 36, 51 ],
      "id_str" : "100277512",
      "id" : 100277512
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WeTheGeeks",
      "indices" : [ 58, 69 ]
    }, {
      "text" : "WomenInSTEM",
      "indices" : [ 81, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/Fgh88tu9kl",
      "expanded_url" : "http:\/\/go.wh.gov\/nCnBJ3",
      "display_url" : "go.wh.gov\/nCnBJ3"
    } ]
  },
  "geo" : { },
  "id_str" : "512303393743052800",
  "text" : "At 3pm ET, join @WhiteHouseOSTP and @MissAmericaOrg for a #WeTheGeeks Hangout on #WomenInSTEM \u2192 http:\/\/t.co\/Fgh88tu9kl",
  "id" : 512303393743052800,
  "created_at" : "2014-09-17 18:13:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arianna Huffington",
      "screen_name" : "ariannahuff",
      "indices" : [ 3, 15 ],
      "id_str" : "21982720",
      "id" : 21982720
    }, {
      "name" : "Christina Huffington",
      "screen_name" : "cshuffington",
      "indices" : [ 72, 85 ],
      "id_str" : "218769789",
      "id" : 218769789
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RecoveryatWH",
      "indices" : [ 45, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512294453248524288",
  "text" : "RT @ariannahuff: Join me at 2 PM ET to watch #RecoveryatWH. My daughter @cshuffington is on the panel talking about her own recovery! http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Christina Huffington",
        "screen_name" : "cshuffington",
        "indices" : [ 55, 68 ],
        "id_str" : "218769789",
        "id" : 218769789
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RecoveryatWH",
        "indices" : [ 28, 41 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/WKnPKg4kWw",
        "expanded_url" : "http:\/\/1.usa.gov\/1m9hZm6",
        "display_url" : "1.usa.gov\/1m9hZm6"
      } ]
    },
    "geo" : { },
    "id_str" : "512267448356462592",
    "text" : "Join me at 2 PM ET to watch #RecoveryatWH. My daughter @cshuffington is on the panel talking about her own recovery! http:\/\/t.co\/WKnPKg4kWw",
    "id" : 512267448356462592,
    "created_at" : "2014-09-17 15:50:51 +0000",
    "user" : {
      "name" : "Arianna Huffington",
      "screen_name" : "ariannahuff",
      "protected" : false,
      "id_str" : "21982720",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765947806582468608\/Ywa0eYRp_normal.jpg",
      "id" : 21982720,
      "verified" : true
    }
  },
  "id" : 512294453248524288,
  "created_at" : "2014-09-17 17:38:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 45, 56 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "Discovery Education",
      "screen_name" : "DiscoveryEd",
      "indices" : [ 61, 73 ],
      "id_str" : "1665531",
      "id" : 1665531
    }, {
      "name" : "US National Archives",
      "screen_name" : "USNatArchives",
      "indices" : [ 102, 116 ],
      "id_str" : "101802390",
      "id" : 101802390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512289856207466496",
  "text" : "RT @FLOTUS: Happy Constitution Day! Join the @WhiteHouse and @DiscoveryEd for a live webinar from the @USNatArchives right now: http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 33, 44 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "Discovery Education",
        "screen_name" : "DiscoveryEd",
        "indices" : [ 49, 61 ],
        "id_str" : "1665531",
        "id" : 1665531
      }, {
        "name" : "US National Archives",
        "screen_name" : "USNatArchives",
        "indices" : [ 90, 104 ],
        "id_str" : "101802390",
        "id" : 101802390
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/IPdRjScFfZ",
        "expanded_url" : "http:\/\/go.wh.gov\/uWYL9T",
        "display_url" : "go.wh.gov\/uWYL9T"
      } ]
    },
    "geo" : { },
    "id_str" : "512287079632744449",
    "text" : "Happy Constitution Day! Join the @WhiteHouse and @DiscoveryEd for a live webinar from the @USNatArchives right now: http:\/\/t.co\/IPdRjScFfZ",
    "id" : 512287079632744449,
    "created_at" : "2014-09-17 17:08:52 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 512289856207466496,
  "created_at" : "2014-09-17 17:19:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512275561327370240",
  "text" : "\"We support you. We\u2019re proud of you. We stand in awe of your skill and your service.\" \u2014President Obama to our men and women in uniform",
  "id" : 512275561327370240,
  "created_at" : "2014-09-17 16:23:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512275350949470209",
  "text" : "RT @WHLive: \"I am as confident as I have ever been that this century, like the last century, will be led by America.\" \u2014President Obama",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "512275324395356160",
    "text" : "\"I am as confident as I have ever been that this century, like the last century, will be led by America.\" \u2014President Obama",
    "id" : 512275324395356160,
    "created_at" : "2014-09-17 16:22:09 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 512275350949470209,
  "created_at" : "2014-09-17 16:22:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/b4tqL36eMn",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "512274730431569920",
  "text" : "\"When the world is threatened, when the world needs help, it calls on America.\" \u2014President Obama: http:\/\/t.co\/b4tqL36eMn",
  "id" : 512274730431569920,
  "created_at" : "2014-09-17 16:19:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512274479750586369",
  "text" : "\"We cannot do for Iraqis what they...must do for themselves.\" \u2014President Obama on our strategy to degrade and destroy ISIL",
  "id" : 512274479750586369,
  "created_at" : "2014-09-17 16:18:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512273545523916800",
  "text" : "\"I will not commit you, and the rest of our Armed Forces, to fighting another ground war in Iraq.\" \u2014President Obama to our troops",
  "id" : 512273545523916800,
  "created_at" : "2014-09-17 16:15:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/512273305043476480\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/pCnkJyZ0HK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bxv12zTIYAAU3hx.png",
      "id_str" : "512273304468873216",
      "id" : 512273304468873216,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bxv12zTIYAAU3hx.png",
      "sizes" : [ {
        "h" : 190,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 513,
        "resize" : "fit",
        "w" : 919
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 335,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 513,
        "resize" : "fit",
        "w" : 919
      } ],
      "display_url" : "pic.twitter.com\/pCnkJyZ0HK"
    } ],
    "hashtags" : [ {
      "text" : "ISIL",
      "indices" : [ 103, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512273305043476480",
  "text" : "\"We mean what we say, our reach is long; if you threaten America, you will find no safe haven.\" \u2014Obama #ISIL http:\/\/t.co\/pCnkJyZ0HK",
  "id" : 512273305043476480,
  "created_at" : "2014-09-17 16:14:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512273097589018624",
  "text" : "\"We\u2019re going to degrade and ultimately destroy ISIL through a comprehensive and sustained counter-terrorism strategy.\" \u2014President Obama",
  "id" : 512273097589018624,
  "created_at" : "2014-09-17 16:13:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512272809637457920",
  "text" : "\"If left unchecked, they could pose a growing threat to the United States.\" \u2014President Obama on the terrorist group ISIL",
  "id" : 512272809637457920,
  "created_at" : "2014-09-17 16:12:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/b4tqL36eMn",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "512272666687193089",
  "text" : "\"In an uncertain world of breathtaking change, the one constant is American leadership.\" \u2014President Obama: http:\/\/t.co\/b4tqL36eMn",
  "id" : 512272666687193089,
  "created_at" : "2014-09-17 16:11:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512272549313773569",
  "text" : "\"In three months, our combat mission will be over in Afghanistan &amp; our war in Afghanistan will come to a responsible end.\" \u2014President Obama",
  "id" : 512272549313773569,
  "created_at" : "2014-09-17 16:11:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512272336490614784",
  "text" : "RT @WHLive: \"Osama bin Laden is no more. Because of you, the core al Qaeda leadership in Afghanistan &amp; Pakistan has been decimated\" \u2014Obama \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "512272181070688257",
    "text" : "\"Osama bin Laden is no more. Because of you, the core al Qaeda leadership in Afghanistan &amp; Pakistan has been decimated\" \u2014Obama to our troops",
    "id" : 512272181070688257,
    "created_at" : "2014-09-17 16:09:40 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 512272336490614784,
  "created_at" : "2014-09-17 16:10:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512272108794425344",
  "text" : "\"Today, we remember all who have given their lives in these wars, and we stand with their families.\" \u2014President Obama",
  "id" : 512272108794425344,
  "created_at" : "2014-09-17 16:09:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512271758104469504",
  "text" : "\"On behalf of the American people, I want to thank all of you for your service.\" \u2014President Obama to troops at MacDill Air Force Base",
  "id" : 512271758104469504,
  "created_at" : "2014-09-17 16:07:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/btElzqsdmX",
      "expanded_url" : "http:\/\/go.wh.gov\/BbU3jX",
      "display_url" : "go.wh.gov\/BbU3jX"
    } ]
  },
  "geo" : { },
  "id_str" : "512270665232449536",
  "text" : "Watch live: President Obama speaks at MacDill Air Force Base on our strategy to degrade and destroy ISIL \u2192 http:\/\/t.co\/btElzqsdmX",
  "id" : 512270665232449536,
  "created_at" : "2014-09-17 16:03:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/btElzqsdmX",
      "expanded_url" : "http:\/\/go.wh.gov\/BbU3jX",
      "display_url" : "go.wh.gov\/BbU3jX"
    } ]
  },
  "geo" : { },
  "id_str" : "512260634025943040",
  "text" : "At 11:50am ET, President Obama speaks to troops at MacDill Air Force Base on our strategy to degrade &amp; destroy ISIL: http:\/\/t.co\/btElzqsdmX",
  "id" : 512260634025943040,
  "created_at" : "2014-09-17 15:23:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/512255253254008832\/photo\/1",
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/sFBdWhDOWP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BxvlcCOIYAED6OW.jpg",
      "id_str" : "512255252431921153",
      "id" : 512255252431921153,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxvlcCOIYAED6OW.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/sFBdWhDOWP"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/BRNl5eEGO0",
      "expanded_url" : "http:\/\/go.wh.gov\/CyLWRU",
      "display_url" : "go.wh.gov\/CyLWRU"
    } ]
  },
  "geo" : { },
  "id_str" : "512255253254008832",
  "text" : "Happy Constitution Day! http:\/\/t.co\/BRNl5eEGO0 http:\/\/t.co\/sFBdWhDOWP",
  "id" : 512255253254008832,
  "created_at" : "2014-09-17 15:02:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/512069084587249664\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/P3njDSFVGj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bxs8HjgIIAAGd0L.jpg",
      "id_str" : "512069083123425280",
      "id" : 512069083123425280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bxs8HjgIIAAGd0L.jpg",
      "sizes" : [ {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/P3njDSFVGj"
    } ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 108, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/bar7oI9dsA",
      "expanded_url" : "http:\/\/go.wh.gov\/n2S41P",
      "display_url" : "go.wh.gov\/n2S41P"
    } ]
  },
  "geo" : { },
  "id_str" : "512069084587249664",
  "text" : "\"This is a global threat, and it demands a truly global response.\" \u2014President Obama: http:\/\/t.co\/bar7oI9dsA #Ebola http:\/\/t.co\/P3njDSFVGj",
  "id" : 512069084587249664,
  "created_at" : "2014-09-17 02:42:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 91, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/hXerLgDfuw",
      "expanded_url" : "http:\/\/go.wh.gov\/A6zzsf",
      "display_url" : "go.wh.gov\/A6zzsf"
    } ]
  },
  "geo" : { },
  "id_str" : "512066493300097025",
  "text" : "FACT: The overall poverty rate \u2193 to 14.5% last year, but there's more work to do to expand #OpportunityForAll \u2192 http:\/\/t.co\/hXerLgDfuw",
  "id" : 512066493300097025,
  "created_at" : "2014-09-17 02:32:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/511992652787900416\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/uDteS6bL42",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bxr2mrcIAAA5TaL.jpg",
      "id_str" : "511992652016123904",
      "id" : 511992652016123904,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bxr2mrcIAAA5TaL.jpg",
      "sizes" : [ {
        "h" : 407,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 407,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 266,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 407,
        "resize" : "fit",
        "w" : 520
      } ],
      "display_url" : "pic.twitter.com\/uDteS6bL42"
    } ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 96, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/hXerLgDfuw",
      "expanded_url" : "http:\/\/go.wh.gov\/A6zzsf",
      "display_url" : "go.wh.gov\/A6zzsf"
    } ]
  },
  "geo" : { },
  "id_str" : "511992652787900416",
  "text" : "Last year marked the largest one-year drop in child poverty since 1966 \u2192 http:\/\/t.co\/hXerLgDfuw #OpportunityForAll http:\/\/t.co\/uDteS6bL42",
  "id" : 511992652787900416,
  "created_at" : "2014-09-16 21:38:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 116, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/wTXugR6DZ3",
      "expanded_url" : "http:\/\/go.wh.gov\/xRqbjr",
      "display_url" : "go.wh.gov\/xRqbjr"
    } ]
  },
  "geo" : { },
  "id_str" : "511972103944699905",
  "text" : "\u201CRight now, the world has the responsibly to act, to step up, to do more.\u201D \u2014President Obama: http:\/\/t.co\/wTXugR6DZ3 #Ebola",
  "id" : 511972103944699905,
  "created_at" : "2014-09-16 20:17:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 81, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/wTXugR6DZ3",
      "expanded_url" : "http:\/\/go.wh.gov\/xRqbjr",
      "display_url" : "go.wh.gov\/xRqbjr"
    } ]
  },
  "geo" : { },
  "id_str" : "511971330456297472",
  "text" : "\"This is a global threat, and it demands a truly global response.\" \u2014Obama on the #Ebola epidemic in West Africa: http:\/\/t.co\/wTXugR6DZ3",
  "id" : 511971330456297472,
  "created_at" : "2014-09-16 20:14:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511970893112016897",
  "text" : "RT @WHLive: \"We\u2019ll create a new training site to train thousands of health care workers so they can care for more patients.\" \u2014President Oba\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Ebola",
        "indices" : [ 130, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "511970860870410241",
    "text" : "\"We\u2019ll create a new training site to train thousands of health care workers so they can care for more patients.\" \u2014President Obama #Ebola",
    "id" : 511970860870410241,
    "created_at" : "2014-09-16 20:12:19 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 511970893112016897,
  "created_at" : "2014-09-16 20:12:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 130, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511970361211359233",
  "text" : "\"Here\u2019s what gives us hope. The world knows how to fight this disease. It\u2019s not a mystery. We know the science.\" \u2014President Obama #Ebola",
  "id" : 511970361211359233,
  "created_at" : "2014-09-16 20:10:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 83, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511969860243685376",
  "text" : "\"People are literally dying in the streets. Here\u2019s the hard truth. In West Africa, #Ebola is now an epidemic.\" \u2014President Obama",
  "id" : 511969860243685376,
  "created_at" : "2014-09-16 20:08:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 53, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511969537848528897",
  "text" : "RT @WHLive: \"In the unlikely event that someone with #Ebola does reach our shores, we\u2019ve taken new measures so that we\u2019re prepared here at \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Ebola",
        "indices" : [ 41, 47 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "511969440473571328",
    "text" : "\"In the unlikely event that someone with #Ebola does reach our shores, we\u2019ve taken new measures so that we\u2019re prepared here at home.\" \u2014Obama",
    "id" : 511969440473571328,
    "created_at" : "2014-09-16 20:06:41 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 511969537848528897,
  "created_at" : "2014-09-16 20:07:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 19, 25 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/b4tqL36eMn",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "511969232687734784",
  "text" : "\"The chances of an #Ebola outbreak here in the United States are extremely low.\" \u2014President Obama: http:\/\/t.co\/b4tqL36eMn",
  "id" : 511969232687734784,
  "created_at" : "2014-09-16 20:05:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 126, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511969037350633472",
  "text" : "\"Faced with this outbreak, the world is looking to the United States, and it\u2019s a responsibility we embrace.\" \u2014President Obama #Ebola",
  "id" : 511969037350633472,
  "created_at" : "2014-09-16 20:05:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CDC",
      "screen_name" : "CDCgov",
      "indices" : [ 41, 48 ],
      "id_str" : "146569971",
      "id" : 146569971
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/3wROB8cJ7A",
      "expanded_url" : "http:\/\/go.wh.gov\/nTLLgV",
      "display_url" : "go.wh.gov\/nTLLgV"
    } ]
  },
  "geo" : { },
  "id_str" : "511968636073156608",
  "text" : "Happening now: President Obama speaks at @CDCGov on our response to the Ebola epidemic in West Africa \u2192 http:\/\/t.co\/3wROB8cJ7A",
  "id" : 511968636073156608,
  "created_at" : "2014-09-16 20:03:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/511965757652353025\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/upwDCZBlnC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BxreJLBIEAAbPwP.jpg",
      "id_str" : "511965756817674240",
      "id" : 511965756817674240,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxreJLBIEAAbPwP.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/upwDCZBlnC"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 70, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/PbJljwyTX9",
      "expanded_url" : "http:\/\/go.wh.gov\/MyLAab",
      "display_url" : "go.wh.gov\/MyLAab"
    } ]
  },
  "geo" : { },
  "id_str" : "511965757652353025",
  "text" : "Get the latest on how President Obama's partnering with businesses to #ActOnClimate \u2192 http:\/\/t.co\/PbJljwyTX9 http:\/\/t.co\/upwDCZBlnC",
  "id" : 511965757652353025,
  "created_at" : "2014-09-16 19:52:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CDC",
      "screen_name" : "CDCgov",
      "indices" : [ 37, 44 ],
      "id_str" : "146569971",
      "id" : 146569971
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/3wROB8cJ7A",
      "expanded_url" : "http:\/\/go.wh.gov\/nTLLgV",
      "display_url" : "go.wh.gov\/nTLLgV"
    } ]
  },
  "geo" : { },
  "id_str" : "511958482506244096",
  "text" : "At 4pm ET, President Obama speaks at @CDCGov on our response to the Ebola epidemic in West Africa \u2192 http:\/\/t.co\/3wROB8cJ7A",
  "id" : 511958482506244096,
  "created_at" : "2014-09-16 19:23:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511935869369212929",
  "text" : "RT @CEABetsey: There's a LOT more to do, but it's hard not to celebrate today's news-the gender wage gap is the narrowest on record! http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/CEABetsey\/status\/511908463929458688\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/D3glK1vweI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BxqqCB0IMAEqCsg.jpg",
        "id_str" : "511908459483508737",
        "id" : 511908459483508737,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxqqCB0IMAEqCsg.jpg",
        "sizes" : [ {
          "h" : 407,
          "resize" : "fit",
          "w" : 520
        }, {
          "h" : 407,
          "resize" : "fit",
          "w" : 520
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 266,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 407,
          "resize" : "fit",
          "w" : 520
        } ],
        "display_url" : "pic.twitter.com\/D3glK1vweI"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "511908463929458688",
    "text" : "There's a LOT more to do, but it's hard not to celebrate today's news-the gender wage gap is the narrowest on record! http:\/\/t.co\/D3glK1vweI",
    "id" : 511908463929458688,
    "created_at" : "2014-09-16 16:04:23 +0000",
    "user" : {
      "name" : "Sandy Black",
      "screen_name" : "CEASandy",
      "protected" : false,
      "id_str" : "1979039203",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/707608742498439169\/VDM-nQKG_normal.jpg",
      "id" : 1979039203,
      "verified" : true
    }
  },
  "id" : 511935869369212929,
  "created_at" : "2014-09-16 17:53:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 96, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511917598708355072",
  "text" : "RT @Podesta44: The U.S. will train up to 500 health care providers per week to help address the #Ebola epidemic in West Africa \u2192 http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Ebola",
        "indices" : [ 81, 87 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/l6euLFuP4J",
        "expanded_url" : "http:\/\/yhoo.it\/1wzSrBO",
        "display_url" : "yhoo.it\/1wzSrBO"
      } ]
    },
    "geo" : { },
    "id_str" : "511905724616962048",
    "text" : "The U.S. will train up to 500 health care providers per week to help address the #Ebola epidemic in West Africa \u2192 http:\/\/t.co\/l6euLFuP4J",
    "id" : 511905724616962048,
    "created_at" : "2014-09-16 15:53:30 +0000",
    "user" : {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "protected" : false,
      "id_str" : "2382117350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656551411145027584\/ArrSlGUP_normal.jpg",
      "id" : 2382117350,
      "verified" : true
    }
  },
  "id" : 511917598708355072,
  "created_at" : "2014-09-16 16:40:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/kP9QqcOJKV",
      "expanded_url" : "http:\/\/yhoo.it\/1wzSrBO",
      "display_url" : "yhoo.it\/1wzSrBO"
    } ]
  },
  "geo" : { },
  "id_str" : "511907184230555649",
  "text" : "The U.S. is sending about 3,000 military personnel to help lead our response to the Ebola epidemic in West Africa \u2192 http:\/\/t.co\/kP9QqcOJKV",
  "id" : 511907184230555649,
  "created_at" : "2014-09-16 15:59:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/wTXugR6DZ3",
      "expanded_url" : "http:\/\/go.wh.gov\/xRqbjr",
      "display_url" : "go.wh.gov\/xRqbjr"
    } ]
  },
  "geo" : { },
  "id_str" : "511900916367491072",
  "text" : "Worth sharing: Here's the latest on President Obama's response to the Ebola epidemic in West Africa \u2192 http:\/\/t.co\/wTXugR6DZ3",
  "id" : 511900916367491072,
  "created_at" : "2014-09-16 15:34:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/511884347650355200\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/nkdPjZQg18",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BxqUGUDIUAABcd0.png",
      "id_str" : "511884343841935360",
      "id" : 511884343841935360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxqUGUDIUAABcd0.png",
      "sizes" : [ {
        "h" : 336,
        "resize" : "fit",
        "w" : 1006
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 200,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 114,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 336,
        "resize" : "fit",
        "w" : 1006
      } ],
      "display_url" : "pic.twitter.com\/nkdPjZQg18"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511884347650355200",
  "text" : "\"An unspeakable act of violence.\" \u2014President Obama on the Washington Navy Yard shooting one year ago today http:\/\/t.co\/nkdPjZQg18",
  "id" : 511884347650355200,
  "created_at" : "2014-09-16 14:28:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/511650763055968257\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/rs7EMWKrFc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bxm6mYjIgAEDqEZ.jpg",
      "id_str" : "511645201270865921",
      "id" : 511645201270865921,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bxm6mYjIgAEDqEZ.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/rs7EMWKrFc"
    } ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 98, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/4rSxsB5MOs",
      "expanded_url" : "http:\/\/go.wh.gov\/YJc1KM",
      "display_url" : "go.wh.gov\/YJc1KM"
    } ]
  },
  "geo" : { },
  "id_str" : "511650763055968257",
  "text" : "Let's keep fighting to give every woman the chance to realize her dreams \u2192 http:\/\/t.co\/4rSxsB5MOs #EqualPay http:\/\/t.co\/rs7EMWKrFc",
  "id" : 511650763055968257,
  "created_at" : "2014-09-15 23:00:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/511642653939994624\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/9Udf9bHB93",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bxm4SD-IMAARUzv.jpg",
      "id_str" : "511642653126307840",
      "id" : 511642653126307840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bxm4SD-IMAARUzv.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/9Udf9bHB93"
    } ],
    "hashtags" : [ {
      "text" : "WomenSucceed",
      "indices" : [ 5, 18 ]
    }, {
      "text" : "EqualPay",
      "indices" : [ 68, 77 ]
    }, {
      "text" : "PaycheckFairness",
      "indices" : [ 89, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511642653939994624",
  "text" : "When #WomenSucceed, America succeeds. It's long-past time to ensure #EqualPay for women. #PaycheckFairness http:\/\/t.co\/9Udf9bHB93",
  "id" : 511642653939994624,
  "created_at" : "2014-09-15 22:28:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sherrod Brown",
      "screen_name" : "SenSherrodBrown",
      "indices" : [ 3, 19 ],
      "id_str" : "43910797",
      "id" : 43910797
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaisetheWage",
      "indices" : [ 126, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511635249840029696",
  "text" : "RT @SenSherrodBrown: Women who are employed full time in Ohio lose about $16 billion a year due to the wage gap. It\u2019s time we #RaisetheWage\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RaisetheWage",
        "indices" : [ 105, 118 ]
      }, {
        "text" : "EqualPay",
        "indices" : [ 120, 129 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "511576555605471232",
    "text" : "Women who are employed full time in Ohio lose about $16 billion a year due to the wage gap. It\u2019s time we #RaisetheWage. #EqualPay",
    "id" : 511576555605471232,
    "created_at" : "2014-09-15 18:05:30 +0000",
    "user" : {
      "name" : "Sherrod Brown",
      "screen_name" : "SenSherrodBrown",
      "protected" : false,
      "id_str" : "43910797",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/523158370333638657\/cLmYIfYa_normal.jpeg",
      "id" : 43910797,
      "verified" : true
    }
  },
  "id" : 511635249840029696,
  "created_at" : "2014-09-15 21:58:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sen. Barbara Boxer",
      "screen_name" : "SenatorBoxer",
      "indices" : [ 3, 16 ],
      "id_str" : "15442036",
      "id" : 15442036
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SenatorBoxer\/status\/509806802943614976\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/1enKfkpd15",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BxMyle4IAAA52M7.jpg",
      "id_str" : "509806802348015616",
      "id" : 509806802348015616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxMyle4IAAA52M7.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/1enKfkpd15"
    } ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 107, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511632211037413376",
  "text" : "RT @SenatorBoxer: Women in America should have the same opportunity for success as their male counterparts #EqualPay http:\/\/t.co\/1enKfkpd15",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SenatorBoxer\/status\/509806802943614976\/photo\/1",
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/1enKfkpd15",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BxMyle4IAAA52M7.jpg",
        "id_str" : "509806802348015616",
        "id" : 509806802348015616,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxMyle4IAAA52M7.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/1enKfkpd15"
      } ],
      "hashtags" : [ {
        "text" : "EqualPay",
        "indices" : [ 89, 98 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "509806802943614976",
    "text" : "Women in America should have the same opportunity for success as their male counterparts #EqualPay http:\/\/t.co\/1enKfkpd15",
    "id" : 509806802943614976,
    "created_at" : "2014-09-10 20:53:08 +0000",
    "user" : {
      "name" : "Sen. Barbara Boxer",
      "screen_name" : "SenatorBoxer",
      "protected" : false,
      "id_str" : "15442036",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464147946934517760\/EZ8huLG8_normal.png",
      "id" : 15442036,
      "verified" : true
    }
  },
  "id" : 511632211037413376,
  "created_at" : "2014-09-15 21:46:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Murphy",
      "screen_name" : "ChrisMurphyCT",
      "indices" : [ 3, 17 ],
      "id_str" : "150078976",
      "id" : 150078976
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 57, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/yKOe5Y4J7h",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=szZsKdJYR-A",
      "display_url" : "youtube.com\/watch?v=szZsKd\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "511631587537346560",
  "text" : "RT @ChrisMurphyCT: Outrageous that we are STILL debating #EqualPay for equal work: https:\/\/t.co\/yKOe5Y4J7h",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EqualPay",
        "indices" : [ 38, 47 ]
      } ],
      "urls" : [ {
        "indices" : [ 64, 87 ],
        "url" : "https:\/\/t.co\/yKOe5Y4J7h",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=szZsKdJYR-A",
        "display_url" : "youtube.com\/watch?v=szZsKd\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "509765919753904128",
    "text" : "Outrageous that we are STILL debating #EqualPay for equal work: https:\/\/t.co\/yKOe5Y4J7h",
    "id" : 509765919753904128,
    "created_at" : "2014-09-10 18:10:40 +0000",
    "user" : {
      "name" : "Chris Murphy",
      "screen_name" : "ChrisMurphyCT",
      "protected" : false,
      "id_str" : "150078976",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738767780246396928\/YrcsMalf_normal.jpg",
      "id" : 150078976,
      "verified" : true
    }
  },
  "id" : 511631587537346560,
  "created_at" : "2014-09-15 21:44:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/511625644250525696\/photo\/1",
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/hL7hbQKN6t",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bxmoz-nIQAAmvF2.jpg",
      "id_str" : "511625643617173504",
      "id" : 511625643617173504,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bxmoz-nIQAAmvF2.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/hL7hbQKN6t"
    } ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 94, 103 ]
    }, {
      "text" : "PaycheckFairness",
      "indices" : [ 104, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511625644250525696",
  "text" : "It's time for Republicans in Congress to help close the earnings gap between men &amp; women. #EqualPay #PaycheckFairness http:\/\/t.co\/hL7hbQKN6t",
  "id" : 511625644250525696,
  "created_at" : "2014-09-15 21:20:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 90, 93 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ItsOnUs",
      "indices" : [ 108, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/nYdjS9Xo1q",
      "expanded_url" : "http:\/\/apne.ws\/1s3SapR",
      "display_url" : "apne.ws\/1s3SapR"
    } ]
  },
  "geo" : { },
  "id_str" : "511610318020411392",
  "text" : "We all have a role to play in stopping sexual assault. That's why President Obama and the @VP are launching #ItsOnUs: http:\/\/t.co\/nYdjS9Xo1q",
  "id" : 511610318020411392,
  "created_at" : "2014-09-15 20:19:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/511603649270001664\/photo\/1",
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/f9rChBolqE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BxmUzrmIIAAbP-q.jpg",
      "id_str" : "511603648280141824",
      "id" : 511603648280141824,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxmUzrmIIAAbP-q.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/f9rChBolqE"
    } ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 37, 46 ]
    }, {
      "text" : "PaycheckFairness",
      "indices" : [ 82, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/ePySh9A52I",
      "expanded_url" : "http:\/\/go.wh.gov\/YJc1KM",
      "display_url" : "go.wh.gov\/YJc1KM"
    } ]
  },
  "geo" : { },
  "id_str" : "511603649270001664",
  "text" : "RT if you agree: It's time to ensure #EqualPay for women \u2192 http:\/\/t.co\/ePySh9A52I #PaycheckFairness http:\/\/t.co\/f9rChBolqE",
  "id" : 511603649270001664,
  "created_at" : "2014-09-15 19:53:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/511590355570290688\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/VdEYpa4jen",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BxmIt5WIMAACHDQ.jpg",
      "id_str" : "511590354752385024",
      "id" : 511590354752385024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxmIt5WIMAACHDQ.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/VdEYpa4jen"
    } ],
    "hashtags" : [ {
      "text" : "MedalOfHonor",
      "indices" : [ 95, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511590355570290688",
  "text" : "\"Our Vietnam vets are patriots. You served with valor. You made us proud.\" \u2014Obama awarding the #MedalOfHonor http:\/\/t.co\/VdEYpa4jen",
  "id" : 511590355570290688,
  "created_at" : "2014-09-15 19:00:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511580114833121280",
  "text" : "\"No matter how long it takes\u2014no matter how many years go by\u2014we will continue to express...gratitude for your\u2026service\" \u2014Obama to Vietnam vets",
  "id" : 511580114833121280,
  "created_at" : "2014-09-15 18:19:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfHonor",
      "indices" : [ 122, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511579970754605056",
  "text" : "\"As we have been reminded again today, our Vietnam vets...are patriots. You served with valor. You made us proud.\" \u2014Obama #MedalOfHonor",
  "id" : 511579970754605056,
  "created_at" : "2014-09-15 18:19:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Army",
      "screen_name" : "USArmy",
      "indices" : [ 3, 10 ],
      "id_str" : "8775672",
      "id" : 8775672
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalofHonor",
      "indices" : [ 112, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511579257953583104",
  "text" : "RT @USArmy: \"Sloat covered the grenade with his own body. He saved the lives of the men around him.\" - POTUS on #MedalofHonor recipient SP4\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MedalofHonor",
        "indices" : [ 100, 113 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "511577049648340992",
    "text" : "\"Sloat covered the grenade with his own body. He saved the lives of the men around him.\" - POTUS on #MedalofHonor recipient SP4 Donald Sloat",
    "id" : 511577049648340992,
    "created_at" : "2014-09-15 18:07:27 +0000",
    "user" : {
      "name" : "U.S. Army",
      "screen_name" : "USArmy",
      "protected" : false,
      "id_str" : "8775672",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684036669515759616\/BF3rskvn_normal.png",
      "id" : 8775672,
      "verified" : true
    }
  },
  "id" : 511579257953583104,
  "created_at" : "2014-09-15 18:16:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfHonor",
      "indices" : [ 113, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511578120223473665",
  "text" : "RT @WHLive: \"In Bennie\u2019s life, we see the enduring service of our men and women in uniform.\" \u2014President Obama on #MedalOfHonor recipient Be\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MedalOfHonor",
        "indices" : [ 101, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "511578075944206338",
    "text" : "\"In Bennie\u2019s life, we see the enduring service of our men and women in uniform.\" \u2014President Obama on #MedalOfHonor recipient Bennie Adkins",
    "id" : 511578075944206338,
    "created_at" : "2014-09-15 18:11:32 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 511578120223473665,
  "created_at" : "2014-09-15 18:11:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Veterans Affairs",
      "screen_name" : "DeptVetAffairs",
      "indices" : [ 3, 18 ],
      "id_str" : "78408666",
      "id" : 78408666
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/DeptVetAffairs\/status\/511577188978544640\/photo\/1",
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/nBLDzifm7G",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bxl8vgyCIAAjkgK.jpg",
      "id_str" : "511577188378746880",
      "id" : 511577188378746880,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bxl8vgyCIAAjkgK.jpg",
      "sizes" : [ {
        "h" : 1536,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1920,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/nBLDzifm7G"
    } ],
    "hashtags" : [ {
      "text" : "MedalofHonor",
      "indices" : [ 50, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511577348442169344",
  "text" : "RT @DeptVetAffairs: Dr. William Sloat accepts the #MedalofHonor on behalf of his fallen brother http:\/\/t.co\/nBLDzifm7G",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DeptVetAffairs\/status\/511577188978544640\/photo\/1",
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/nBLDzifm7G",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bxl8vgyCIAAjkgK.jpg",
        "id_str" : "511577188378746880",
        "id" : 511577188378746880,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bxl8vgyCIAAjkgK.jpg",
        "sizes" : [ {
          "h" : 1536,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1920,
          "resize" : "fit",
          "w" : 1280
        } ],
        "display_url" : "pic.twitter.com\/nBLDzifm7G"
      } ],
      "hashtags" : [ {
        "text" : "MedalofHonor",
        "indices" : [ 30, 43 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "511577188978544640",
    "text" : "Dr. William Sloat accepts the #MedalofHonor on behalf of his fallen brother http:\/\/t.co\/nBLDzifm7G",
    "id" : 511577188978544640,
    "created_at" : "2014-09-15 18:08:01 +0000",
    "user" : {
      "name" : "Veterans Affairs",
      "screen_name" : "DeptVetAffairs",
      "protected" : false,
      "id_str" : "78408666",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/344513261565984455\/a9fcce7feb947b2ec498491c6c6d6985_normal.png",
      "id" : 78408666,
      "verified" : true
    }
  },
  "id" : 511577348442169344,
  "created_at" : "2014-09-15 18:08:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfHonor",
      "indices" : [ 105, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511574796786995201",
  "text" : "\"Today, we honor two American soldiers for gallantry above and beyond the call of duty\" \u2014President Obama #MedalOfHonor",
  "id" : 511574796786995201,
  "created_at" : "2014-09-15 17:58:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfHonor",
      "indices" : [ 39, 52 ]
    }, {
      "text" : "HonoringVets",
      "indices" : [ 118, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/d5MGjDfNZ1",
      "expanded_url" : "http:\/\/go.wh.gov\/TwWp4w",
      "display_url" : "go.wh.gov\/TwWp4w"
    } ]
  },
  "geo" : { },
  "id_str" : "511574069775716352",
  "text" : "Watch live: President Obama awards the #MedalOfHonor to Bennie G. Adkins and Donald P. Sloat \u2192 http:\/\/t.co\/d5MGjDfNZ1 #HonoringVets",
  "id" : 511574069775716352,
  "created_at" : "2014-09-15 17:55:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 110, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/87ZrHTHWSn",
      "expanded_url" : "http:\/\/go.wh.gov\/1NPvKX",
      "display_url" : "go.wh.gov\/1NPvKX"
    } ]
  },
  "geo" : { },
  "id_str" : "511571723142311936",
  "text" : "RT @VP: Our businesses are selling $70 billion more overseas each month than in 2009 \u2192 http:\/\/t.co\/87ZrHTHWSn #MadeInAmerica http:\/\/t.co\/hR\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/511571437531172864\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/hRlvz3XCa4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bxl3gpiIAAEGoqF.jpg",
        "id_str" : "511571435471765505",
        "id" : 511571435471765505,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bxl3gpiIAAEGoqF.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/hRlvz3XCa4"
      } ],
      "hashtags" : [ {
        "text" : "MadeInAmerica",
        "indices" : [ 102, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/87ZrHTHWSn",
        "expanded_url" : "http:\/\/go.wh.gov\/1NPvKX",
        "display_url" : "go.wh.gov\/1NPvKX"
      } ]
    },
    "geo" : { },
    "id_str" : "511571437531172864",
    "text" : "Our businesses are selling $70 billion more overseas each month than in 2009 \u2192 http:\/\/t.co\/87ZrHTHWSn #MadeInAmerica http:\/\/t.co\/hRlvz3XCa4",
    "id" : 511571437531172864,
    "created_at" : "2014-09-15 17:45:09 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 511571723142311936,
  "created_at" : "2014-09-15 17:46:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfHonor",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/pXfPXPscUI",
      "expanded_url" : "http:\/\/youtu.be\/nt53GPz9dmE",
      "display_url" : "youtu.be\/nt53GPz9dmE"
    } ]
  },
  "geo" : { },
  "id_str" : "511552627234988032",
  "text" : "\"I raised my right hand and I went over there knowing the risk, and you know, I'm proud of what I did.\" http:\/\/t.co\/pXfPXPscUI #MedalOfHonor",
  "id" : 511552627234988032,
  "created_at" : "2014-09-15 16:30:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfHonor",
      "indices" : [ 25, 38 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/2jmWE8W0bJ",
      "expanded_url" : "http:\/\/youtu.be\/nt53GPz9dmE",
      "display_url" : "youtu.be\/nt53GPz9dmE"
    } ]
  },
  "geo" : { },
  "id_str" : "511546441215795200",
  "text" : "Before today's 1:50pm ET #MedalOfHonor ceremony, watch what goes into the presentation of our highest military honor: http:\/\/t.co\/2jmWE8W0bJ",
  "id" : 511546441215795200,
  "created_at" : "2014-09-15 16:05:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/507981568841744386\/photo\/1",
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/mhjbqROSmv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BwywuYdIUAAzHt3.jpg",
      "id_str" : "507975168871124992",
      "id" : 507975168871124992,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwywuYdIUAAzHt3.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1250,
        "resize" : "fit",
        "w" : 2500
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/mhjbqROSmv"
    } ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 82, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/HoQ0b4fSwx",
      "expanded_url" : "http:\/\/go.wh.gov\/1NPvKX",
      "display_url" : "go.wh.gov\/1NPvKX"
    } ]
  },
  "geo" : { },
  "id_str" : "511534972692213761",
  "text" : "FACT: We're building cars at the highest rate since 2002 \u2192 http:\/\/t.co\/HoQ0b4fSwx #MadeInAmerica http:\/\/t.co\/mhjbqROSmv",
  "id" : 511534972692213761,
  "created_at" : "2014-09-15 15:20:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/507893954323705856\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/yagKBtGcEe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bwxm1uiIEAEZ9hc.jpg",
      "id_str" : "507893931196289025",
      "id" : 507893931196289025,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bwxm1uiIEAEZ9hc.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/yagKBtGcEe"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/PL0l3vTIF9",
      "expanded_url" : "http:\/\/go.wh.gov\/1NPvKX",
      "display_url" : "go.wh.gov\/1NPvKX"
    } ]
  },
  "geo" : { },
  "id_str" : "511529051874656256",
  "text" : "We've come a long way since the financial crisis hit 6 years ago\u2014but there's more work to do: http:\/\/t.co\/PL0l3vTIF9 http:\/\/t.co\/yagKBtGcEe",
  "id" : 511529051874656256,
  "created_at" : "2014-09-15 14:56:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511524934418694144",
  "text" : "RT @vj44: FACT: 52% of POTUS\u2019 second term circuit court appointments have been women. No other President has appointed more than 35% in a s\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "511522180086394880",
    "text" : "FACT: 52% of POTUS\u2019 second term circuit court appointments have been women. No other President has appointed more than 35% in a single term.",
    "id" : 511522180086394880,
    "created_at" : "2014-09-15 14:29:26 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 511524934418694144,
  "created_at" : "2014-09-15 14:40:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 92, 100 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "InvictusGames",
      "indices" : [ 126, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/z5Ky1po5EX",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=BjsFsNOOrto",
      "display_url" : "youtube.com\/watch?v=BjsFsN\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "511326097892323328",
  "text" : "\"Not only do you inspire countless other recovering warriors...you inspire all Americans.\" \u2014@DrBiden: https:\/\/t.co\/z5Ky1po5EX #InvictusGames",
  "id" : 511326097892323328,
  "created_at" : "2014-09-15 01:30:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/mpaMGYgjQ0",
      "expanded_url" : "http:\/\/go.wh.gov\/BMzezT",
      "display_url" : "go.wh.gov\/BMzezT"
    } ]
  },
  "geo" : { },
  "id_str" : "511310986033115136",
  "text" : "\"As Commander in Chief, my highest priority is the security of the American people.\" \u2014Obama in his weekly address: http:\/\/t.co\/mpaMGYgjQ0",
  "id" : 511310986033115136,
  "created_at" : "2014-09-15 00:30:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/mpaMGYgjQ0",
      "expanded_url" : "http:\/\/go.wh.gov\/BMzezT",
      "display_url" : "go.wh.gov\/BMzezT"
    } ]
  },
  "geo" : { },
  "id_str" : "511212872014114816",
  "text" : "\"We don\u2019t give in to fear. We carry on. And we will never waver in the defense of the country we love.\" \u2014Obama: http:\/\/t.co\/mpaMGYgjQ0",
  "id" : 511212872014114816,
  "created_at" : "2014-09-14 18:00:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/mpaMGYgjQ0",
      "expanded_url" : "http:\/\/go.wh.gov\/BMzezT",
      "display_url" : "go.wh.gov\/BMzezT"
    } ]
  },
  "geo" : { },
  "id_str" : "511182661113487360",
  "text" : "\"We\u2019re moving ahead with our strategy to degrade and ultimately destroy this terrorist organization.\" \u2014Obama on ISIL: http:\/\/t.co\/mpaMGYgjQ0",
  "id" : 511182661113487360,
  "created_at" : "2014-09-14 16:00:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/510997366292627456\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/iscj8GSB5h",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BxdtZYaIMAAPNw_.png",
      "id_str" : "510997365546037248",
      "id" : 510997365546037248,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxdtZYaIMAAPNw_.png",
      "sizes" : [ {
        "h" : 275,
        "resize" : "fit",
        "w" : 730
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 128,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 275,
        "resize" : "fit",
        "w" : 730
      } ],
      "display_url" : "pic.twitter.com\/iscj8GSB5h"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510997366292627456",
  "text" : "\"The United States strongly condemns the barbaric murder of UK citizen David Haines by the terrorist group ISIL.\" http:\/\/t.co\/iscj8GSB5h",
  "id" : 510997366292627456,
  "created_at" : "2014-09-14 03:44:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/IxrNC5Hz9p",
      "expanded_url" : "http:\/\/wh.gov\/iqocZ",
      "display_url" : "wh.gov\/iqocZ"
    } ]
  },
  "geo" : { },
  "id_str" : "510993203663994880",
  "text" : "RT @NSCPress: Statement by the President on the Death of David Haines: http:\/\/t.co\/IxrNC5Hz9p",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/IxrNC5Hz9p",
        "expanded_url" : "http:\/\/wh.gov\/iqocZ",
        "display_url" : "wh.gov\/iqocZ"
      } ]
    },
    "geo" : { },
    "id_str" : "510949229397688320",
    "text" : "Statement by the President on the Death of David Haines: http:\/\/t.co\/IxrNC5Hz9p",
    "id" : 510949229397688320,
    "created_at" : "2014-09-14 00:32:43 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 510993203663994880,
  "created_at" : "2014-09-14 03:27:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/UwHrW9IGAg",
      "expanded_url" : "http:\/\/time.com\/3319325\/joe-biden-violence-against-women\/",
      "display_url" : "time.com\/3319325\/joe-bi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "510935370465558528",
  "text" : "RT @VP: The American people have sent a clear message: you\u2019re a coward for raising a hand to a woman. http:\/\/t.co\/UwHrW9IGAg http:\/\/t.co\/5U\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/510931429715640320\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/5U6zAR6iJf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BxcxI-UIIAA0i4l.jpg",
        "id_str" : "510931112965971968",
        "id" : 510931112965971968,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxcxI-UIIAA0i4l.jpg",
        "sizes" : [ {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/5U6zAR6iJf"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/UwHrW9IGAg",
        "expanded_url" : "http:\/\/time.com\/3319325\/joe-biden-violence-against-women\/",
        "display_url" : "time.com\/3319325\/joe-bi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "510931429715640320",
    "text" : "The American people have sent a clear message: you\u2019re a coward for raising a hand to a woman. http:\/\/t.co\/UwHrW9IGAg http:\/\/t.co\/5U6zAR6iJf",
    "id" : 510931429715640320,
    "created_at" : "2014-09-13 23:22:00 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 510935370465558528,
  "created_at" : "2014-09-13 23:37:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/MyoX3jBJ5Q",
      "expanded_url" : "http:\/\/go.wh.gov\/BMzezT",
      "display_url" : "go.wh.gov\/BMzezT"
    } ]
  },
  "geo" : { },
  "id_str" : "510912875104583680",
  "text" : "\"Those who threaten the United States will find no safe haven.\" \u2014Obama on our strategy to degrade and destroy ISIL: http:\/\/t.co\/MyoX3jBJ5Q",
  "id" : 510912875104583680,
  "created_at" : "2014-09-13 22:08:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/MyoX3jBJ5Q",
      "expanded_url" : "http:\/\/go.wh.gov\/BMzezT",
      "display_url" : "go.wh.gov\/BMzezT"
    } ]
  },
  "geo" : { },
  "id_str" : "510799116671410176",
  "text" : "\"As Commander in Chief, my highest priority is the security of the American people.\" \u2014Obama in his weekly address: http:\/\/t.co\/MyoX3jBJ5Q",
  "id" : 510799116671410176,
  "created_at" : "2014-09-13 14:36:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Clinton",
      "screen_name" : "billclinton",
      "indices" : [ 20, 32 ],
      "id_str" : "1330457336",
      "id" : 1330457336
    }, {
      "name" : "AmeriCorps",
      "screen_name" : "AmeriCorps",
      "indices" : [ 69, 80 ],
      "id_str" : "17967675",
      "id" : 17967675
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/510563596338597888\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/7aLBB8dUqn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BxXQBT6IMAE_w3y.jpg",
      "id_str" : "510542853718945793",
      "id" : 510542853718945793,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxXQBT6IMAE_w3y.jpg",
      "sizes" : [ {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/7aLBB8dUqn"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/RYeoPcAGG6",
      "expanded_url" : "http:\/\/go.wh.gov\/ehVMPG",
      "display_url" : "go.wh.gov\/ehVMPG"
    } ]
  },
  "geo" : { },
  "id_str" : "510563596338597888",
  "text" : "President Obama and @BillClinton commemorate the 20th anniversary of @AmeriCorps \u2192 http:\/\/t.co\/RYeoPcAGG6 http:\/\/t.co\/7aLBB8dUqn",
  "id" : 510563596338597888,
  "created_at" : "2014-09-12 23:00:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/510542346157821952\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/CewJvScBSR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BxXPjueIAAAJJfp.jpg",
      "id_str" : "510542345453174784",
      "id" : 510542345453174784,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxXPjueIAAAJJfp.jpg",
      "sizes" : [ {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/CewJvScBSR"
    } ],
    "hashtags" : [ {
      "text" : "AmeriCorps20",
      "indices" : [ 103, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/o751jvJKM0",
      "expanded_url" : "http:\/\/go.wh.gov\/ehVMPG",
      "display_url" : "go.wh.gov\/ehVMPG"
    } ]
  },
  "geo" : { },
  "id_str" : "510542346157821952",
  "text" : "\"You have made America stronger because of what you\u2019ve done.\" \u2014President Obama: http:\/\/t.co\/o751jvJKM0 #AmeriCorps20 http:\/\/t.co\/CewJvScBSR",
  "id" : 510542346157821952,
  "created_at" : "2014-09-12 21:35:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kristin Lee",
      "screen_name" : "Lee44",
      "indices" : [ 3, 9 ],
      "id_str" : "2800630026",
      "id" : 2800630026
    }, {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 108, 123 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510518640966643712",
  "text" : "RT @Lee44: Hello, Twitter! Excited to bring you news on science and tech policy from the brilliant geeks at @WhiteHouseOSTP.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House OSTP",
        "screen_name" : "whitehouseostp",
        "indices" : [ 97, 112 ],
        "id_str" : "33998183",
        "id" : 33998183
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "510514872510332929",
    "text" : "Hello, Twitter! Excited to bring you news on science and tech policy from the brilliant geeks at @WhiteHouseOSTP.",
    "id" : 510514872510332929,
    "created_at" : "2014-09-12 19:46:45 +0000",
    "user" : {
      "name" : "Kristin Lee",
      "screen_name" : "Lee44",
      "protected" : false,
      "id_str" : "2800630026",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/626378024359870464\/dc8kq4yl_normal.png",
      "id" : 2800630026,
      "verified" : true
    }
  },
  "id" : 510518640966643712,
  "created_at" : "2014-09-12 20:01:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AmeriCorps20",
      "indices" : [ 20, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510508223028535296",
  "text" : "RT @VP: In honor of #AmeriCorps20, let's recommit ourselves to service and volunteer work. That's what makes America great. http:\/\/t.co\/HZI\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/VP\/status\/510507055929917440\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/HZIpGytEGv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BxWvdYWCQAAS68X.jpg",
        "id_str" : "510507052062359552",
        "id" : 510507052062359552,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxWvdYWCQAAS68X.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 436,
          "resize" : "fit",
          "w" : 654
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 436,
          "resize" : "fit",
          "w" : 654
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/HZIpGytEGv"
      } ],
      "hashtags" : [ {
        "text" : "AmeriCorps20",
        "indices" : [ 12, 25 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "510507055929917440",
    "text" : "In honor of #AmeriCorps20, let's recommit ourselves to service and volunteer work. That's what makes America great. http:\/\/t.co\/HZIpGytEGv",
    "id" : 510507055929917440,
    "created_at" : "2014-09-12 19:15:41 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 510508223028535296,
  "created_at" : "2014-09-12 19:20:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "AmeriCorps",
      "screen_name" : "AmeriCorps",
      "indices" : [ 27, 38 ],
      "id_str" : "17967675",
      "id" : 17967675
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510505095365423104",
  "text" : "RT @FLOTUS: Happy Birthday @AmeriCorps! I'm honored to have served with them in Chicago and couldn't be prouder of all they've accomplished\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "AmeriCorps",
        "screen_name" : "AmeriCorps",
        "indices" : [ 15, 26 ],
        "id_str" : "17967675",
        "id" : 17967675
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "510503324995821568",
    "text" : "Happy Birthday @AmeriCorps! I'm honored to have served with them in Chicago and couldn't be prouder of all they've accomplished. \u2013mo",
    "id" : 510503324995821568,
    "created_at" : "2014-09-12 19:00:52 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 510505095365423104,
  "created_at" : "2014-09-12 19:07:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/510499520330092544\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/C9I1F3W64a",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BxWom8AIAAEweVK.jpg",
      "id_str" : "510499519671566337",
      "id" : 510499519671566337,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxWom8AIAAEweVK.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/C9I1F3W64a"
    } ],
    "hashtags" : [ {
      "text" : "ChartOfTheWeek",
      "indices" : [ 0, 15 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/3sFaljfPKi",
      "expanded_url" : "http:\/\/go.wh.gov\/Xp7RKE",
      "display_url" : "go.wh.gov\/Xp7RKE"
    } ]
  },
  "geo" : { },
  "id_str" : "510499520330092544",
  "text" : "#ChartOfTheWeek: Public high school students are graduating at the highest rate ever \u2192 http:\/\/t.co\/3sFaljfPKi http:\/\/t.co\/C9I1F3W64a",
  "id" : 510499520330092544,
  "created_at" : "2014-09-12 18:45:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Senator Dick Durbin",
      "screen_name" : "SenatorDurbin",
      "indices" : [ 3, 17 ],
      "id_str" : "247334603",
      "id" : 247334603
    }, {
      "name" : "AmeriCorps",
      "screen_name" : "AmeriCorps",
      "indices" : [ 52, 63 ],
      "id_str" : "17967675",
      "id" : 17967675
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510490522973372417",
  "text" : "RT @SenatorDurbin: Very proud of all the great work @AmeriCorps members do for Illinois and the entire US. Congratulations on 20 successful\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "AmeriCorps",
        "screen_name" : "AmeriCorps",
        "indices" : [ 33, 44 ],
        "id_str" : "17967675",
        "id" : 17967675
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AmeriCorps20",
        "indices" : [ 127, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "510488290106298368",
    "text" : "Very proud of all the great work @AmeriCorps members do for Illinois and the entire US. Congratulations on 20 successful years #AmeriCorps20",
    "id" : 510488290106298368,
    "created_at" : "2014-09-12 18:01:07 +0000",
    "user" : {
      "name" : "Senator Dick Durbin",
      "screen_name" : "SenatorDurbin",
      "protected" : false,
      "id_str" : "247334603",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/789474472088698880\/1QiXwROv_normal.jpg",
      "id" : 247334603,
      "verified" : true
    }
  },
  "id" : 510490522973372417,
  "created_at" : "2014-09-12 18:09:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernest Moniz",
      "screen_name" : "ErnestMoniz",
      "indices" : [ 3, 15 ],
      "id_str" : "1393155566",
      "id" : 1393155566
    }, {
      "name" : "AmeriCorps",
      "screen_name" : "AmeriCorps",
      "indices" : [ 33, 44 ],
      "id_str" : "17967675",
      "id" : 17967675
    }, {
      "name" : "Martha's Table",
      "screen_name" : "MarthasTableorg",
      "indices" : [ 89, 105 ],
      "id_str" : "21120919",
      "id" : 21120919
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AmeriCorps20",
      "indices" : [ 117, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510488237698453505",
  "text" : "RT @ErnestMoniz: Happy birthday, @AmeriCorps! I enjoyed volunteering with some of you at @MarthasTableorg yesterday. #AmeriCorps20 http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/measuredvoice.com\/\" rel=\"nofollow\"\u003EMeasured Voice\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "AmeriCorps",
        "screen_name" : "AmeriCorps",
        "indices" : [ 16, 27 ],
        "id_str" : "17967675",
        "id" : 17967675
      }, {
        "name" : "Martha's Table",
        "screen_name" : "MarthasTableorg",
        "indices" : [ 72, 88 ],
        "id_str" : "21120919",
        "id" : 21120919
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ErnestMoniz\/status\/510463805986713600\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/xx6lJZu9CH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BxWIIHPIcAAPLih.jpg",
        "id_str" : "510463805739266048",
        "id" : 510463805739266048,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxWIIHPIcAAPLih.jpg",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/xx6lJZu9CH"
      } ],
      "hashtags" : [ {
        "text" : "AmeriCorps20",
        "indices" : [ 100, 113 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "510463805986713600",
    "text" : "Happy birthday, @AmeriCorps! I enjoyed volunteering with some of you at @MarthasTableorg yesterday. #AmeriCorps20 http:\/\/t.co\/xx6lJZu9CH",
    "id" : 510463805986713600,
    "created_at" : "2014-09-12 16:23:49 +0000",
    "user" : {
      "name" : "Ernest Moniz",
      "screen_name" : "ErnestMoniz",
      "protected" : false,
      "id_str" : "1393155566",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793425933113954305\/f5Mxv7BK_normal.jpg",
      "id" : 1393155566,
      "verified" : true
    }
  },
  "id" : 510488237698453505,
  "created_at" : "2014-09-12 18:00:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Daily Show",
      "screen_name" : "TheDailyShow",
      "indices" : [ 126, 139 ],
      "id_str" : "158414847",
      "id" : 158414847
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamacareApocalypse",
      "indices" : [ 76, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/vRPYhsk2fW",
      "expanded_url" : "http:\/\/on.cc.com\/1pWaIRs",
      "display_url" : "on.cc.com\/1pWaIRs"
    } ]
  },
  "geo" : { },
  "id_str" : "510480418794377216",
  "text" : "Millions signed up for health coverage through the ACA. What came next? The #ObamacareApocalypse: http:\/\/t.co\/vRPYhsk2fW (via @TheDailyShow)",
  "id" : 510480418794377216,
  "created_at" : "2014-09-12 17:29:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AmeriCorps",
      "screen_name" : "AmeriCorps",
      "indices" : [ 125, 136 ],
      "id_str" : "17967675",
      "id" : 17967675
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510459007484821504",
  "text" : "\"They don\u2019t just believe in, but live out a fundamental truth...that people who love their country can change it.\" \u2014Obama on @AmeriCorps",
  "id" : 510459007484821504,
  "created_at" : "2014-09-12 16:04:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AmeriCorps20",
      "indices" : [ 121, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510458713556393985",
  "text" : "\"Citizens who perform national service are special. You want them on your team.\" \u2014Obama on Employers of National Service #AmeriCorps20",
  "id" : 510458713556393985,
  "created_at" : "2014-09-12 16:03:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510457995776757761",
  "text" : "RT @WHLive: \"They\u2019ve touched the lives of millions of their fellow citizens. And they\u2019ve helped America become stronger.\" \u2014Obama on #AmeriC\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AmeriCorps20",
        "indices" : [ 120, 133 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "510457895029583873",
    "text" : "\"They\u2019ve touched the lives of millions of their fellow citizens. And they\u2019ve helped America become stronger.\" \u2014Obama on #AmeriCorps20",
    "id" : 510457895029583873,
    "created_at" : "2014-09-12 16:00:20 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 510457995776757761,
  "created_at" : "2014-09-12 16:00:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510457472428310528",
  "text" : "RT @WHLive: \"Making a difference in other people\u2019s lives made a difference in mine.\" \u2014Obama on working as a community organizer in Chicago \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AmeriCorps20",
        "indices" : [ 127, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "510457444661997568",
    "text" : "\"Making a difference in other people\u2019s lives made a difference in mine.\" \u2014Obama on working as a community organizer in Chicago #AmeriCorps20",
    "id" : 510457444661997568,
    "created_at" : "2014-09-12 15:58:33 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 510457472428310528,
  "created_at" : "2014-09-12 15:58:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AmeriCorps20",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510457181016453120",
  "text" : "\"I would not be standing here if it were not for the service of others, and the purpose that service gave my own life.\" \u2014Obama #AmeriCorps20",
  "id" : 510457181016453120,
  "created_at" : "2014-09-12 15:57:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AmeriCorps",
      "screen_name" : "AmeriCorps",
      "indices" : [ 125, 136 ],
      "id_str" : "17967675",
      "id" : 17967675
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510455938210623488",
  "text" : "\"Thank all of you for living a life of active &amp; energetic...citizenship because it has made America stronger.\" \u2014Obama to @AmeriCorps members",
  "id" : 510455938210623488,
  "created_at" : "2014-09-12 15:52:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AmeriCorps",
      "screen_name" : "AmeriCorps",
      "indices" : [ 104, 115 ],
      "id_str" : "17967675",
      "id" : 17967675
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AmeriCorps20",
      "indices" : [ 125, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510455378199707648",
  "text" : "\"I want to thank all of you for joining President Clinton and me in celebrating the 20th anniversary of @AmeriCorps.\" \u2014Obama #AmeriCorps20",
  "id" : 510455378199707648,
  "created_at" : "2014-09-12 15:50:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AmeriCorps",
      "screen_name" : "AmeriCorps",
      "indices" : [ 65, 76 ],
      "id_str" : "17967675",
      "id" : 17967675
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/510455108170428416\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/BO3YVGlBps",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BxWANyuIYAAPqQJ.png",
      "id_str" : "510455107218333696",
      "id" : 510455107218333696,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxWANyuIYAAPqQJ.png",
      "sizes" : [ {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 478,
        "resize" : "fit",
        "w" : 852
      }, {
        "h" : 478,
        "resize" : "fit",
        "w" : 852
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/BO3YVGlBps"
    } ],
    "hashtags" : [ {
      "text" : "AmeriCorps20",
      "indices" : [ 102, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/FgPtNJRikG",
      "expanded_url" : "http:\/\/go.wh.gov\/n3vt8S",
      "display_url" : "go.wh.gov\/n3vt8S"
    } ]
  },
  "geo" : { },
  "id_str" : "510455108170428416",
  "text" : "Watch live: President Obama commemorates the 20th anniversary of @AmeriCorps \u2192 http:\/\/t.co\/FgPtNJRikG #AmeriCorps20 http:\/\/t.co\/BO3YVGlBps",
  "id" : 510455108170428416,
  "created_at" : "2014-09-12 15:49:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Bloomberg",
      "screen_name" : "MikeBloomberg",
      "indices" : [ 3, 17 ],
      "id_str" : "16581604",
      "id" : 16581604
    }, {
      "name" : "AmeriCorps",
      "screen_name" : "AmeriCorps",
      "indices" : [ 42, 53 ],
      "id_str" : "17967675",
      "id" : 17967675
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/MikeBloomberg\/status\/510443613768404992\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/L2GjsKfdCx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BxV1wolCUAAPXm7.jpg",
      "id_str" : "510443611163348992",
      "id" : 510443611163348992,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxV1wolCUAAPXm7.jpg",
      "sizes" : [ {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/L2GjsKfdCx"
    } ],
    "hashtags" : [ {
      "text" : "AmeriCorps20",
      "indices" : [ 101, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510453795407814656",
  "text" : "RT @MikeBloomberg: Happy 20th Birthday to @AmeriCorps - A great partner in encouraging local service #AmeriCorps20 http:\/\/t.co\/L2GjsKfdCx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "AmeriCorps",
        "screen_name" : "AmeriCorps",
        "indices" : [ 23, 34 ],
        "id_str" : "17967675",
        "id" : 17967675
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MikeBloomberg\/status\/510443613768404992\/photo\/1",
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/L2GjsKfdCx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BxV1wolCUAAPXm7.jpg",
        "id_str" : "510443611163348992",
        "id" : 510443611163348992,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxV1wolCUAAPXm7.jpg",
        "sizes" : [ {
          "h" : 1365,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/L2GjsKfdCx"
      } ],
      "hashtags" : [ {
        "text" : "AmeriCorps20",
        "indices" : [ 82, 95 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "510443613768404992",
    "text" : "Happy 20th Birthday to @AmeriCorps - A great partner in encouraging local service #AmeriCorps20 http:\/\/t.co\/L2GjsKfdCx",
    "id" : 510443613768404992,
    "created_at" : "2014-09-12 15:03:35 +0000",
    "user" : {
      "name" : "Mike Bloomberg",
      "screen_name" : "MikeBloomberg",
      "protected" : false,
      "id_str" : "16581604",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615510114447953920\/_1c4TTMM_normal.jpg",
      "id" : 16581604,
      "verified" : true
    }
  },
  "id" : 510453795407814656,
  "created_at" : "2014-09-12 15:44:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "indices" : [ 3, 15 ],
      "id_str" : "369232105",
      "id" : 369232105
    }, {
      "name" : "AmeriCorps",
      "screen_name" : "AmeriCorps",
      "indices" : [ 23, 34 ],
      "id_str" : "17967675",
      "id" : 17967675
    }, {
      "name" : "Bill Clinton",
      "screen_name" : "billclinton",
      "indices" : [ 68, 80 ],
      "id_str" : "1330457336",
      "id" : 1330457336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510450139442733056",
  "text" : "RT @PAniskoff44: Happy @AmeriCorps volunteers ready for POTUS &amp; @billclinton. Since 1994 they have served 1.2 billion hrs! http:\/\/t.co\/P5QV\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "AmeriCorps",
        "screen_name" : "AmeriCorps",
        "indices" : [ 6, 17 ],
        "id_str" : "17967675",
        "id" : 17967675
      }, {
        "name" : "Bill Clinton",
        "screen_name" : "billclinton",
        "indices" : [ 51, 63 ],
        "id_str" : "1330457336",
        "id" : 1330457336
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PAniskoff44\/status\/510449586612473856\/photo\/1",
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/P5QVV8j1jU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BxV7MQlCEAAU0uK.jpg",
        "id_str" : "510449583315357696",
        "id" : 510449583315357696,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxV7MQlCEAAU0uK.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/P5QVV8j1jU"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "510449586612473856",
    "text" : "Happy @AmeriCorps volunteers ready for POTUS &amp; @billclinton. Since 1994 they have served 1.2 billion hrs! http:\/\/t.co\/P5QVV8j1jU",
    "id" : 510449586612473856,
    "created_at" : "2014-09-12 15:27:19 +0000",
    "user" : {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "protected" : false,
      "id_str" : "369232105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623146355767140352\/58sqoVrw_normal.jpg",
      "id" : 369232105,
      "verified" : true
    }
  },
  "id" : 510450139442733056,
  "created_at" : "2014-09-12 15:29:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Clinton",
      "screen_name" : "billclinton",
      "indices" : [ 3, 15 ],
      "id_str" : "1330457336",
      "id" : 1330457336
    }, {
      "name" : "AmeriCorps",
      "screen_name" : "AmeriCorps",
      "indices" : [ 57, 68 ],
      "id_str" : "17967675",
      "id" : 17967675
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OTD",
      "indices" : [ 17, 21 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510444444760674305",
  "text" : "RT @billclinton: #OTD in '94 I welcomed the 1st class of @Americorps. Grateful to the 900K members who've kept the spirit of service alive \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "AmeriCorps",
        "screen_name" : "AmeriCorps",
        "indices" : [ 40, 51 ],
        "id_str" : "17967675",
        "id" : 17967675
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OTD",
        "indices" : [ 0, 4 ]
      }, {
        "text" : "Proud",
        "indices" : [ 134, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "510436027740483584",
    "text" : "#OTD in '94 I welcomed the 1st class of @Americorps. Grateful to the 900K members who've kept the spirit of service alive in the U.S. #Proud",
    "id" : 510436027740483584,
    "created_at" : "2014-09-12 14:33:27 +0000",
    "user" : {
      "name" : "Bill Clinton",
      "screen_name" : "billclinton",
      "protected" : false,
      "id_str" : "1330457336",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451207149478096896\/HoMUOmyu_normal.jpeg",
      "id" : 1330457336,
      "verified" : true
    }
  },
  "id" : 510444444760674305,
  "created_at" : "2014-09-12 15:06:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AmeriCorps",
      "screen_name" : "AmeriCorps",
      "indices" : [ 58, 69 ],
      "id_str" : "17967675",
      "id" : 17967675
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AmeriCorps20",
      "indices" : [ 109, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/UYfra8Agwn",
      "expanded_url" : "http:\/\/go.wh.gov\/XHnrcT",
      "display_url" : "go.wh.gov\/XHnrcT"
    } ]
  },
  "geo" : { },
  "id_str" : "510444042426257408",
  "text" : "Watch President Obama commemorate the 20th anniversary of @AmeriCorps at 11:20am ET \u2192 http:\/\/t.co\/UYfra8Agwn #AmeriCorps20",
  "id" : 510444042426257408,
  "created_at" : "2014-09-12 15:05:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CNCS",
      "screen_name" : "NationalService",
      "indices" : [ 3, 19 ],
      "id_str" : "17961886",
      "id" : 17961886
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 114, 125 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nationalservice",
      "indices" : [ 55, 71 ]
    }, {
      "text" : "AmeriCorps20",
      "indices" : [ 126, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510439048335597568",
  "text" : "RT @nationalservice: POTUS announces efforts to expand #nationalservice &amp; improve pipeline to jobs for alumni @WhiteHouse #AmeriCorps20 htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 93, 104 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "nationalservice",
        "indices" : [ 34, 50 ]
      }, {
        "text" : "AmeriCorps20",
        "indices" : [ 105, 118 ]
      } ],
      "urls" : [ {
        "indices" : [ 119, 141 ],
        "url" : "http:\/\/t.co\/gOOobydts3",
        "expanded_url" : "http:\/\/go.usa.gov\/V7Cz",
        "display_url" : "go.usa.gov\/V7Cz"
      } ]
    },
    "geo" : { },
    "id_str" : "510421408334479360",
    "text" : "POTUS announces efforts to expand #nationalservice &amp; improve pipeline to jobs for alumni @WhiteHouse #AmeriCorps20 http:\/\/t.co\/gOOobydts3",
    "id" : 510421408334479360,
    "created_at" : "2014-09-12 13:35:21 +0000",
    "user" : {
      "name" : "CNCS",
      "screen_name" : "NationalService",
      "protected" : false,
      "id_str" : "17961886",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/695658719045160961\/04v_MrsK_normal.jpg",
      "id" : 17961886,
      "verified" : false
    }
  },
  "id" : 510439048335597568,
  "created_at" : "2014-09-12 14:45:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "KaBOOM!",
      "screen_name" : "kaboom",
      "indices" : [ 113, 120 ],
      "id_str" : "14124614",
      "id" : 14124614
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Remember911",
      "indices" : [ 58, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510259795941527552",
  "text" : "RT @FLOTUS: The President &amp; FLOTUS joined millions to #Remember911 with service by assembling backpacks with @KaBOOM volunteers. http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "KaBOOM!",
        "screen_name" : "kaboom",
        "indices" : [ 101, 108 ],
        "id_str" : "14124614",
        "id" : 14124614
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/510252091911462912\/photo\/1",
        "indices" : [ 121, 143 ],
        "url" : "http:\/\/t.co\/OpIhhQLIlb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BxTHkrjIYAA5LD5.jpg",
        "id_str" : "510252090779000832",
        "id" : 510252090779000832,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxTHkrjIYAA5LD5.jpg",
        "sizes" : [ {
          "h" : 733,
          "resize" : "fit",
          "w" : 1100
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/OpIhhQLIlb"
      } ],
      "hashtags" : [ {
        "text" : "Remember911",
        "indices" : [ 46, 58 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "510252091911462912",
    "text" : "The President &amp; FLOTUS joined millions to #Remember911 with service by assembling backpacks with @KaBOOM volunteers. http:\/\/t.co\/OpIhhQLIlb",
    "id" : 510252091911462912,
    "created_at" : "2014-09-12 02:22:33 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 510259795941527552,
  "created_at" : "2014-09-12 02:53:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/510244060951740416\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/gR5vuI81Ok",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BxTAROeIYAANaA6.jpg",
      "id_str" : "510244059974492160",
      "id" : 510244059974492160,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxTAROeIYAANaA6.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      } ],
      "display_url" : "pic.twitter.com\/gR5vuI81Ok"
    } ],
    "hashtags" : [ {
      "text" : "DayOfService",
      "indices" : [ 94, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510244060951740416",
  "text" : "President Obama helps put the finishing touches on playground equipment as part of a National #DayOfService project. http:\/\/t.co\/gR5vuI81Ok",
  "id" : 510244060951740416,
  "created_at" : "2014-09-12 01:50:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Remember911",
      "indices" : [ 85, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/2W8Ojro6FW",
      "expanded_url" : "http:\/\/go.wh.gov\/dTJFTi",
      "display_url" : "go.wh.gov\/dTJFTi"
    } ]
  },
  "geo" : { },
  "id_str" : "510171987285929984",
  "text" : "RT @JoiningForces: The color guard preparing for this morning's moment of silence to #Remember911 \u2192 http:\/\/t.co\/2W8Ojro6FW http:\/\/t.co\/42Od\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JoiningForces\/status\/510162663213899777\/photo\/1",
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/42Od3CN6YP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BxR2PRjCYAA9IlK.jpg",
        "id_str" : "510162662580183040",
        "id" : 510162662580183040,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxR2PRjCYAA9IlK.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/42Od3CN6YP"
      } ],
      "hashtags" : [ {
        "text" : "Remember911",
        "indices" : [ 66, 78 ]
      } ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/2W8Ojro6FW",
        "expanded_url" : "http:\/\/go.wh.gov\/dTJFTi",
        "display_url" : "go.wh.gov\/dTJFTi"
      } ]
    },
    "geo" : { },
    "id_str" : "510162663213899777",
    "text" : "The color guard preparing for this morning's moment of silence to #Remember911 \u2192 http:\/\/t.co\/2W8Ojro6FW http:\/\/t.co\/42Od3CN6YP",
    "id" : 510162663213899777,
    "created_at" : "2014-09-11 20:27:11 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 510171987285929984,
  "created_at" : "2014-09-11 21:04:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510154418453774336",
  "text" : "RT @VP: The legacy of 9\/11 is that our spirit is mightier, the bonds that unite us are thicker, and our resolve is firmer. http:\/\/t.co\/Kt8h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/510131894055600128\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/Kt8hnLrgqi",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BxRaQBLCUAA-KvO.jpg",
        "id_str" : "510131889038839808",
        "id" : 510131889038839808,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxRaQBLCUAA-KvO.jpg",
        "sizes" : [ {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/Kt8hnLrgqi"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "510131894055600128",
    "text" : "The legacy of 9\/11 is that our spirit is mightier, the bonds that unite us are thicker, and our resolve is firmer. http:\/\/t.co\/Kt8hnLrgqi",
    "id" : 510131894055600128,
    "created_at" : "2014-09-11 18:24:56 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 510154418453774336,
  "created_at" : "2014-09-11 19:54:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/510117302290120705\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/gvXmSsoTFY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BxRM-3RIgAA7M4E.jpg",
      "id_str" : "510117300671119360",
      "id" : 510117300671119360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxRM-3RIgAA7M4E.jpg",
      "sizes" : [ {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/gvXmSsoTFY"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510117302290120705",
  "text" : "\"13 years after small and hateful minds conspired to break us, America stands tall and America stands proud.\" \u2014Obama http:\/\/t.co\/gvXmSsoTFY",
  "id" : 510117302290120705,
  "created_at" : "2014-09-11 17:26:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Sanctions",
      "indices" : [ 48, 58 ]
    }, {
      "text" : "Russia",
      "indices" : [ 70, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/keC424nD9b",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/the-press-office\/2014\/09\/11\/statement-president-new-sanctions-related-russia",
      "display_url" : "whitehouse.gov\/the-press-offi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "510111801611395073",
  "text" : "RT @NSCPress: Statement by the President on New #Sanctions Related to #Russia: http:\/\/t.co\/keC424nD9b",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Sanctions",
        "indices" : [ 34, 44 ]
      }, {
        "text" : "Russia",
        "indices" : [ 56, 63 ]
      } ],
      "urls" : [ {
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/keC424nD9b",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/the-press-office\/2014\/09\/11\/statement-president-new-sanctions-related-russia",
        "display_url" : "whitehouse.gov\/the-press-offi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "510111125460234241",
    "text" : "Statement by the President on New #Sanctions Related to #Russia: http:\/\/t.co\/keC424nD9b",
    "id" : 510111125460234241,
    "created_at" : "2014-09-11 17:02:24 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 510111801611395073,
  "created_at" : "2014-09-11 17:05:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    }, {
      "name" : "Flight 93",
      "screen_name" : "Flight93NPS",
      "indices" : [ 51, 63 ],
      "id_str" : "2416381123",
      "id" : 2416381123
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NeverForget",
      "indices" : [ 116, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510110767627374592",
  "text" : "RT @Interior: Candle lanterns at the Wall of Names @Flight93NPS in honor of the brave men &amp; women lost on 9\/11. #NeverForget http:\/\/t.co\/7s\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Flight 93",
        "screen_name" : "Flight93NPS",
        "indices" : [ 37, 49 ],
        "id_str" : "2416381123",
        "id" : 2416381123
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Interior\/status\/510085747315978241\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/7szn7Yw4Vm",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BxQwSJ6CQAAsjFZ.jpg",
        "id_str" : "510085746254823424",
        "id" : 510085746254823424,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxQwSJ6CQAAsjFZ.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 901,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1538,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 511,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1920,
          "resize" : "fit",
          "w" : 1278
        } ],
        "display_url" : "pic.twitter.com\/7szn7Yw4Vm"
      } ],
      "hashtags" : [ {
        "text" : "NeverForget",
        "indices" : [ 102, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "510085747315978241",
    "text" : "Candle lanterns at the Wall of Names @Flight93NPS in honor of the brave men &amp; women lost on 9\/11. #NeverForget http:\/\/t.co\/7szn7Yw4Vm",
    "id" : 510085747315978241,
    "created_at" : "2014-09-11 15:21:33 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 510110767627374592,
  "created_at" : "2014-09-11 17:00:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/510095527837319168\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/46gOzqLfIO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BxQ33OjIUAEA2_-.jpg",
      "id_str" : "510094079737483265",
      "id" : 510094079737483265,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxQ33OjIUAEA2_-.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/46gOzqLfIO"
    } ],
    "hashtags" : [ {
      "text" : "911Anniversary",
      "indices" : [ 94, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510095527837319168",
  "text" : "\"We carry on, because, as Americans, we do not give in to fear.\" \u2014President Obama marking the #911Anniversary http:\/\/t.co\/46gOzqLfIO",
  "id" : 510095527837319168,
  "created_at" : "2014-09-11 16:00:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 3, 11 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510090818733244416",
  "text" : "RT @DrBiden: To mark the 13th anniversary of the terrorist attacks, Dr. Biden visited the 9\/11 Memorial &amp; Museum in NYC this week. http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/DrBiden\/status\/510063570462457856\/photo\/1",
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/oaao8ANqyS",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BxQcHIaCQAArb_V.jpg",
        "id_str" : "510063566641053696",
        "id" : 510063566641053696,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxQcHIaCQAArb_V.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/oaao8ANqyS"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "510063570462457856",
    "text" : "To mark the 13th anniversary of the terrorist attacks, Dr. Biden visited the 9\/11 Memorial &amp; Museum in NYC this week. http:\/\/t.co\/oaao8ANqyS",
    "id" : 510063570462457856,
    "created_at" : "2014-09-11 13:53:26 +0000",
    "user" : {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "protected" : false,
      "id_str" : "1281405877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608687663034474496\/wvzVG_yt_normal.jpg",
      "id" : 1281405877,
      "verified" : true
    }
  },
  "id" : 510090818733244416,
  "created_at" : "2014-09-11 15:41:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 21, 24 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 30, 37 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/O2aGDG2Ilc",
      "expanded_url" : "http:\/\/youtu.be\/mrNsPutVne4",
      "display_url" : "youtu.be\/mrNsPutVne4"
    } ]
  },
  "geo" : { },
  "id_str" : "510084025416159232",
  "text" : "President Obama, the @VP, and @FLOTUS observe a moment of silence to mark the 13th anniversary of the 9\/11 attacks \u2192 http:\/\/t.co\/O2aGDG2Ilc",
  "id" : 510084025416159232,
  "created_at" : "2014-09-11 15:14:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/510077594197573632\/photo\/1",
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/eVIkr4k8fZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BxQo3kAIcAAzBbh.jpg",
      "id_str" : "510077592821854208",
      "id" : 510077592821854208,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxQo3kAIcAAzBbh.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/eVIkr4k8fZ"
    } ],
    "hashtags" : [ {
      "text" : "911Anniversary",
      "indices" : [ 28, 43 ]
    }, {
      "text" : "NeverForget",
      "indices" : [ 84, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510077594197573632",
  "text" : "President Obama attends the #911Anniversary wreath laying ceremony at the Pentagon. #NeverForget http:\/\/t.co\/eVIkr4k8fZ",
  "id" : 510077594197573632,
  "created_at" : "2014-09-11 14:49:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "911Anniversary",
      "indices" : [ 118, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510061413755535360",
  "text" : "\"Thirteen years after small and hateful minds conspired to break us, America stands tall and proud.\" \u2014President Obama #911Anniversary",
  "id" : 510061413755535360,
  "created_at" : "2014-09-11 13:44:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "911Anniversary",
      "indices" : [ 116, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510061177242931200",
  "text" : "\"Today, we honor all who have made the ultimate sacrifice these 13 years\u2014more than 6,800 American patriots.\" \u2014Obama #911Anniversary",
  "id" : 510061177242931200,
  "created_at" : "2014-09-11 13:43:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "911Anniversary",
      "indices" : [ 82, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510060887680765952",
  "text" : "\"We carry on, because, as Americans, we do not give in to fear.\" \u2014President Obama #911Anniversary",
  "id" : 510060887680765952,
  "created_at" : "2014-09-11 13:42:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510060605999697921",
  "text" : "\"Your love is the ultimate rebuke to the hatred of those who attacked us that bright, blue morning.\" \u2014Obama to families of 9\/11 victims",
  "id" : 510060605999697921,
  "created_at" : "2014-09-11 13:41:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "911Anniversary",
      "indices" : [ 117, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510060239472050176",
  "text" : "\"It has now been thirteen years. Thirteen years since the peace of an American morning was broken.\" \u2014President Obama #911Anniversary",
  "id" : 510060239472050176,
  "created_at" : "2014-09-11 13:40:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/b4tqL36eMn",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "510059897468514304",
  "text" : "Happening now: President Obama speaks at the September 11th Observance Ceremony at the Pentagon Memorial \u2192 http:\/\/t.co\/b4tqL36eMn",
  "id" : 510059897468514304,
  "created_at" : "2014-09-11 13:38:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/IdPh6gl0ou",
      "expanded_url" : "http:\/\/go.wh.gov\/vZ6bqL",
      "display_url" : "go.wh.gov\/vZ6bqL"
    } ]
  },
  "geo" : { },
  "id_str" : "510058744093618176",
  "text" : "President Obama and the First Lady attend the September 11th Observance Ceremony at the Pentagon Memorial: http:\/\/t.co\/IdPh6gl0ou",
  "id" : 510058744093618176,
  "created_at" : "2014-09-11 13:34:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 26, 29 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 34, 41 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510041781636182017",
  "text" : "Join President Obama, the @VP and @FLOTUS in a moment of silence at 8:46am ET to mark the 13th anniversary of the 9\/11 terrorist attacks.",
  "id" : 510041781636182017,
  "created_at" : "2014-09-11 12:26:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/509898761146212352\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/Pz8BwTSnGV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BxOGOJGIMAEEeNX.jpg",
      "id_str" : "509898760340910081",
      "id" : 509898760340910081,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxOGOJGIMAEEeNX.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/Pz8BwTSnGV"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/2brSeKHynS",
      "expanded_url" : "http:\/\/go.wh.gov\/hk2eWm",
      "display_url" : "go.wh.gov\/hk2eWm"
    } ]
  },
  "geo" : { },
  "id_str" : "509898761146212352",
  "text" : "Watch President Obama speak on our strategy to degrade and destroy the terrorist group ISIL \u2192 http:\/\/t.co\/2brSeKHynS http:\/\/t.co\/Pz8BwTSnGV",
  "id" : 509898761146212352,
  "created_at" : "2014-09-11 02:58:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/57MvbubxdB",
      "expanded_url" : "http:\/\/youtu.be\/KvRd17vXaXM",
      "display_url" : "youtu.be\/KvRd17vXaXM"
    } ]
  },
  "geo" : { },
  "id_str" : "509890854526652417",
  "text" : "\"Our endless blessings bestow an enduring burden. But as Americans, we welcome our responsibility to lead.\" \u2014Obama: http:\/\/t.co\/57MvbubxdB",
  "id" : 509890854526652417,
  "created_at" : "2014-09-11 02:27:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/57MvbubxdB",
      "expanded_url" : "http:\/\/youtu.be\/KvRd17vXaXM",
      "display_url" : "youtu.be\/KvRd17vXaXM"
    } ]
  },
  "geo" : { },
  "id_str" : "509885106371444736",
  "text" : "\"ISIL is not 'Islamic.' No religion condones the killing of innocents.\" \u2014President Obama\nWatch \u2192 http:\/\/t.co\/57MvbubxdB",
  "id" : 509885106371444736,
  "created_at" : "2014-09-11 02:04:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/509879926087254016\/photo\/1",
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/c7LiDand3O",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BxN1Fw5IcAEnTuN.jpg",
      "id_str" : "509879924707323905",
      "id" : 509879924707323905,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxN1Fw5IcAEnTuN.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/c7LiDand3O"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/57MvbubxdB",
      "expanded_url" : "http:\/\/youtu.be\/KvRd17vXaXM",
      "display_url" : "youtu.be\/KvRd17vXaXM"
    } ]
  },
  "geo" : { },
  "id_str" : "509879926087254016",
  "text" : "\"If you threaten America, you will find no safe-haven.\" \u2014President Obama: http:\/\/t.co\/57MvbubxdB http:\/\/t.co\/c7LiDand3O",
  "id" : 509879926087254016,
  "created_at" : "2014-09-11 01:43:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/57MvbubxdB",
      "expanded_url" : "http:\/\/youtu.be\/KvRd17vXaXM",
      "display_url" : "youtu.be\/KvRd17vXaXM"
    } ]
  },
  "geo" : { },
  "id_str" : "509876863922343936",
  "text" : "Watch President Obama address the nation on our strategy to degrade and destroy the terrorist group ISIL \u2192 http:\/\/t.co\/57MvbubxdB",
  "id" : 509876863922343936,
  "created_at" : "2014-09-11 01:31:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509872997650661377",
  "text" : "\"Our own security, depends upon our willingness to do what it takes to defend this nation and uphold the values that we stand for.\" \u2014Obama",
  "id" : 509872997650661377,
  "created_at" : "2014-09-11 01:16:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509872609375563776",
  "text" : "\"We stand for freedom, for justice, for dignity. These are values that have guided our nation since its founding.\" \u2014President Obama",
  "id" : 509872609375563776,
  "created_at" : "2014-09-11 01:14:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509872523111317504",
  "text" : "\"Our endless blessings bestow an enduring burden. But as Americans, we welcome our responsibility to lead.\" \u2014President Obama",
  "id" : 509872523111317504,
  "created_at" : "2014-09-11 01:14:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509872348330459136",
  "text" : "\"It is America that has the capacity and the will to mobilize the world against terrorists.\" \u2014President Obama",
  "id" : 509872348330459136,
  "created_at" : "2014-09-11 01:13:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509872260380119040",
  "text" : "\"Our businesses are in the longest uninterrupted stretch of job creation in our history.\" \u2014President Obama",
  "id" : 509872260380119040,
  "created_at" : "2014-09-11 01:13:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509871667578155008",
  "text" : "\"This is American leadership at its best: We stand with people who fight for their own freedom.\" \u2014President Obama",
  "id" : 509871667578155008,
  "created_at" : "2014-09-11 01:10:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509871329097830400",
  "text" : "RT @WHLive: \"We will continue to draw on our substantial counter-terrorism capabilities to prevent ISIL attacks.\" \u2014President Obama",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "509871203876872192",
    "text" : "\"We will continue to draw on our substantial counter-terrorism capabilities to prevent ISIL attacks.\" \u2014President Obama",
    "id" : 509871203876872192,
    "created_at" : "2014-09-11 01:09:02 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 509871329097830400,
  "created_at" : "2014-09-11 01:09:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ISIL",
      "indices" : [ 111, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509871236357566464",
  "text" : "RT @WHLive: \"We will increase our support to forces fighting these terrorists on the ground.\" \u2014President Obama #ISIL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ISIL",
        "indices" : [ 99, 104 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "509870969570476032",
    "text" : "\"We will increase our support to forces fighting these terrorists on the ground.\" \u2014President Obama #ISIL",
    "id" : 509870969570476032,
    "created_at" : "2014-09-11 01:08:06 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 509871236357566464,
  "created_at" : "2014-09-11 01:09:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ISIL",
      "indices" : [ 100, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/b4tqL36eMn",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "509871058900754432",
  "text" : "\"We will not get dragged into another ground war in Iraq.\" \u2014President Obama: http:\/\/t.co\/b4tqL36eMn #ISIL",
  "id" : 509871058900754432,
  "created_at" : "2014-09-11 01:08:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ISIL",
      "indices" : [ 116, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509870883834691584",
  "text" : "\"This is a core principle of my presidency: If you threaten America, you will find no safe-haven.\" \u2014President Obama #ISIL",
  "id" : 509870883834691584,
  "created_at" : "2014-09-11 01:07:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509870654741827584",
  "text" : "\"Our objective is clear: We will degrade and ultimately destroy ISIL through a comprehensive &amp; sustained counter-terrorism strategy.\" \u2014Obama",
  "id" : 509870654741827584,
  "created_at" : "2014-09-11 01:06:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ISIL",
      "indices" : [ 94, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509870599884513281",
  "text" : "\"America will lead a broad coalition to roll back this terrorist threat.\" \u2014President Obama on #ISIL",
  "id" : 509870599884513281,
  "created_at" : "2014-09-11 01:06:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509870518481461249",
  "text" : "\"American power can make a decisive difference, but we cannot do for Iraqis what they must do for themselves.\" \u2014President Obama",
  "id" : 509870518481461249,
  "created_at" : "2014-09-11 01:06:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ISIL",
      "indices" : [ 134, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509870360402345984",
  "text" : "\"Tonight, I want you to know that the United States of America is meeting them with strength and resolve.\" \u2014Obama on threats posed by #ISIL",
  "id" : 509870360402345984,
  "created_at" : "2014-09-11 01:05:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509870182693888001",
  "text" : "\"ISIL poses a threat to the people of Iraq &amp; Syria, and the broader Middle East\u2014including American citizens, personnel &amp; facilities.\" \u2014Obama",
  "id" : 509870182693888001,
  "created_at" : "2014-09-11 01:04:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ISIL",
      "indices" : [ 124, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509870118818807808",
  "text" : "\"In acts of barbarism, they took the lives of two American journalists\u2014James Foley and Steven Sotloff.\" \u2014President Obama on #ISIL",
  "id" : 509870118818807808,
  "created_at" : "2014-09-11 01:04:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509869954267873281",
  "text" : "\"It is recognized by no government, nor the people it subjugates. ISIL is a terrorist organization, pure and simple.\" \u2014President Obama",
  "id" : 509869954267873281,
  "created_at" : "2014-09-11 01:04:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509869872923545601",
  "text" : "\"ISIL is not 'Islamic.' No religion condones the killing of innocents, and the vast majority of ISIL\u2019s victims have been Muslim.\" \u2014Obama",
  "id" : 509869872923545601,
  "created_at" : "2014-09-11 01:03:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509869822046646272",
  "text" : "RT @WHLive: \"Thanks to our military and counter-terrorism professionals, America is safer.\" \u2014President Obama",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "509869677968113664",
    "text" : "\"Thanks to our military and counter-terrorism professionals, America is safer.\" \u2014President Obama",
    "id" : 509869677968113664,
    "created_at" : "2014-09-11 01:02:58 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 509869822046646272,
  "created_at" : "2014-09-11 01:03:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509869639116259328",
  "text" : "RT @WHLive: \"We took out Osama bin Laden and much of al Qaeda\u2019s leadership in Afghanistan and Pakistan.\" \u2014President Obama",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "509869551472103424",
    "text" : "\"We took out Osama bin Laden and much of al Qaeda\u2019s leadership in Afghanistan and Pakistan.\" \u2014President Obama",
    "id" : 509869551472103424,
    "created_at" : "2014-09-11 01:02:28 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 509869639116259328,
  "created_at" : "2014-09-11 01:02:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509869498405756928",
  "text" : "\"As Commander-in-Chief, my highest priority is the security of the American people.\" \u2014President Obama",
  "id" : 509869498405756928,
  "created_at" : "2014-09-11 01:02:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/t0GIfrsqcS",
      "expanded_url" : "http:\/\/go.wh.gov\/FbNcDp",
      "display_url" : "go.wh.gov\/FbNcDp"
    } ]
  },
  "geo" : { },
  "id_str" : "509869392721883136",
  "text" : "Happening now: President Obama addresses the nation on our strategy to degrade and destroy ISIL. Watch \u2192 http:\/\/t.co\/t0GIfrsqcS",
  "id" : 509869392721883136,
  "created_at" : "2014-09-11 01:01:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/509864537785647105\/photo\/1",
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/aAMCchkTUN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BxNnGFMIQAA8nX1.jpg",
      "id_str" : "509864536992923648",
      "id" : 509864536992923648,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxNnGFMIQAA8nX1.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/aAMCchkTUN"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/t0GIfrsqcS",
      "expanded_url" : "http:\/\/go.wh.gov\/FbNcDp",
      "display_url" : "go.wh.gov\/FbNcDp"
    } ]
  },
  "geo" : { },
  "id_str" : "509864537785647105",
  "text" : "Watch President Obama address the nation at 9pm ET on our strategy to degrade &amp; destroy ISIL: http:\/\/t.co\/t0GIfrsqcS http:\/\/t.co\/aAMCchkTUN",
  "id" : 509864537785647105,
  "created_at" : "2014-09-11 00:42:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ISIL",
      "indices" : [ 75, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/kqTTorcVNK",
      "expanded_url" : "http:\/\/wh.gov\/iqPRu",
      "display_url" : "wh.gov\/iqPRu"
    } ]
  },
  "geo" : { },
  "id_str" : "509844184019517440",
  "text" : "RT @NSCPress: Excerpts of the President\u2019s Address to the Nation Tonight on #ISIL: http:\/\/t.co\/kqTTorcVNK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ISIL",
        "indices" : [ 61, 66 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/kqTTorcVNK",
        "expanded_url" : "http:\/\/wh.gov\/iqPRu",
        "display_url" : "wh.gov\/iqPRu"
      } ]
    },
    "geo" : { },
    "id_str" : "509837467789176834",
    "text" : "Excerpts of the President\u2019s Address to the Nation Tonight on #ISIL: http:\/\/t.co\/kqTTorcVNK",
    "id" : 509837467789176834,
    "created_at" : "2014-09-10 22:54:59 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 509844184019517440,
  "created_at" : "2014-09-10 23:21:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/509814297816743936\/photo\/1",
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/zDp8j4u6ER",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BxM5Zt3IgAAAia-.jpg",
      "id_str" : "509814296793350144",
      "id" : 509814296793350144,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxM5Zt3IgAAAia-.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/zDp8j4u6ER"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/t0GIfrsqcS",
      "expanded_url" : "http:\/\/go.wh.gov\/FbNcDp",
      "display_url" : "go.wh.gov\/FbNcDp"
    } ]
  },
  "geo" : { },
  "id_str" : "509814297816743936",
  "text" : "At 9pm ET, President Obama will address the nation on our strategy to degrade &amp; destroy ISIL: http:\/\/t.co\/t0GIfrsqcS http:\/\/t.co\/zDp8j4u6ER",
  "id" : 509814297816743936,
  "created_at" : "2014-09-10 21:22:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 27, 30 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/509792597574180865\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/SDWvZ1sSnL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BxMlqfzIcAAkiKY.jpg",
      "id_str" : "509792594843693056",
      "id" : 509792594843693056,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxMlqfzIcAAkiKY.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/SDWvZ1sSnL"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509792597574180865",
  "text" : "President Obama meets with @VP Biden and members of his National Security Council in the Situation Room. http:\/\/t.co\/SDWvZ1sSnL",
  "id" : 509792597574180865,
  "created_at" : "2014-09-10 19:56:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/509782157108060160\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/g0sBrOvJOS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BxMUxnoIYAAmSy2.jpg",
      "id_str" : "509774025506447360",
      "id" : 509774025506447360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxMUxnoIYAAmSy2.jpg",
      "sizes" : [ {
        "h" : 163,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 478,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 287,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 478,
        "resize" : "fit",
        "w" : 1000
      } ],
      "display_url" : "pic.twitter.com\/g0sBrOvJOS"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/oZqdOxXAwx",
      "expanded_url" : "http:\/\/huff.to\/1CS8xZm",
      "display_url" : "huff.to\/1CS8xZm"
    } ]
  },
  "geo" : { },
  "id_str" : "509782157108060160",
  "text" : "Thanks in part to the Affordable Care Act, health care premiums are rising at a slower rate \u2192 http:\/\/t.co\/oZqdOxXAwx http:\/\/t.co\/g0sBrOvJOS",
  "id" : 509782157108060160,
  "created_at" : "2014-09-10 19:15:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "indices" : [ 3, 13 ],
      "id_str" : "15007149",
      "id" : 15007149
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509779412506923008",
  "text" : "RT @JohnKerry: As I announced earlier: we\u2019re providing $48M in addt'l humanitarian aid to help Iraqi internally displaced\/refugees \u2013 http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/RN9XKCJqCL",
        "expanded_url" : "http:\/\/go.usa.gov\/VRfw",
        "display_url" : "go.usa.gov\/VRfw"
      } ]
    },
    "geo" : { },
    "id_str" : "509773749999001600",
    "text" : "As I announced earlier: we\u2019re providing $48M in addt'l humanitarian aid to help Iraqi internally displaced\/refugees \u2013 http:\/\/t.co\/RN9XKCJqCL",
    "id" : 509773749999001600,
    "created_at" : "2014-09-10 18:41:47 +0000",
    "user" : {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "protected" : false,
      "id_str" : "15007149",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/482149339842617346\/l6b7LXjb_normal.jpeg",
      "id" : 15007149,
      "verified" : true
    }
  },
  "id" : 509779412506923008,
  "created_at" : "2014-09-10 19:04:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/509773591895089152\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/Bii4RS2FpY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BxMUYRjIMAIJLvD.jpg",
      "id_str" : "509773590083153922",
      "id" : 509773590083153922,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxMUYRjIMAIJLvD.jpg",
      "sizes" : [ {
        "h" : 500,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Bii4RS2FpY"
    } ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 105, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509773591895089152",
  "text" : "Whether it's private insurance, Medicare, or Medicaid, the growth in health care spending is going down. #ACAWorks http:\/\/t.co\/Bii4RS2FpY",
  "id" : 509773591895089152,
  "created_at" : "2014-09-10 18:41:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vox",
      "screen_name" : "voxdotcom",
      "indices" : [ 3, 13 ],
      "id_str" : "2347049341",
      "id" : 2347049341
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/2pkTysXeip",
      "expanded_url" : "http:\/\/vox.com\/e\/5885672",
      "display_url" : "vox.com\/e\/5885672"
    } ]
  },
  "geo" : { },
  "id_str" : "509772402709266432",
  "text" : "RT @voxdotcom: The \"pay less, get more\" era of health care http:\/\/t.co\/2pkTysXeip",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.sbnation.com\" rel=\"nofollow\"\u003ESB Nation\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 66 ],
        "url" : "http:\/\/t.co\/2pkTysXeip",
        "expanded_url" : "http:\/\/vox.com\/e\/5885672",
        "display_url" : "vox.com\/e\/5885672"
      } ]
    },
    "geo" : { },
    "id_str" : "509748152061407232",
    "text" : "The \"pay less, get more\" era of health care http:\/\/t.co\/2pkTysXeip",
    "id" : 509748152061407232,
    "created_at" : "2014-09-10 17:00:04 +0000",
    "user" : {
      "name" : "Vox",
      "screen_name" : "voxdotcom",
      "protected" : false,
      "id_str" : "2347049341",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/442785905246347265\/v6W3UuIL_normal.jpeg",
      "id" : 2347049341,
      "verified" : true
    }
  },
  "id" : 509772402709266432,
  "created_at" : "2014-09-10 18:36:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gov. Brown Press Ofc",
      "screen_name" : "GovPressOffice",
      "indices" : [ 3, 18 ],
      "id_str" : "1285266390",
      "id" : 1285266390
    }, {
      "name" : "Jerry Brown",
      "screen_name" : "JerryBrownGov",
      "indices" : [ 21, 35 ],
      "id_str" : "19418459",
      "id" : 19418459
    }, {
      "name" : "Lorena Gonzalez",
      "screen_name" : "LorenaSGonzalez",
      "indices" : [ 51, 67 ],
      "id_str" : "102179167",
      "id" : 102179167
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "paidsickdays",
      "indices" : [ 83, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/eOs4rmGOQv",
      "expanded_url" : "http:\/\/bit.ly\/Zh38vu",
      "display_url" : "bit.ly\/Zh38vu"
    } ]
  },
  "geo" : { },
  "id_str" : "509763365749932032",
  "text" : "RT @GovPressOffice: .@JerryBrownGov signs historic @LorenaSGonzalez bill providing #paidsickdays to millions in CA http:\/\/t.co\/eOs4rmGOQv h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jerry Brown",
        "screen_name" : "JerryBrownGov",
        "indices" : [ 1, 15 ],
        "id_str" : "19418459",
        "id" : 19418459
      }, {
        "name" : "Lorena Gonzalez",
        "screen_name" : "LorenaSGonzalez",
        "indices" : [ 31, 47 ],
        "id_str" : "102179167",
        "id" : 102179167
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/GovPressOffice\/status\/509755555410239488\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/QCOTJylfuo",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BxMD-dxCcAAxD2X.jpg",
        "id_str" : "509755554500079616",
        "id" : 509755554500079616,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxMD-dxCcAAxD2X.jpg",
        "sizes" : [ {
          "h" : 253,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1525,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 447,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 763,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/QCOTJylfuo"
      } ],
      "hashtags" : [ {
        "text" : "paidsickdays",
        "indices" : [ 63, 76 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/eOs4rmGOQv",
        "expanded_url" : "http:\/\/bit.ly\/Zh38vu",
        "display_url" : "bit.ly\/Zh38vu"
      } ]
    },
    "geo" : { },
    "id_str" : "509755555410239488",
    "text" : ".@JerryBrownGov signs historic @LorenaSGonzalez bill providing #paidsickdays to millions in CA http:\/\/t.co\/eOs4rmGOQv http:\/\/t.co\/QCOTJylfuo",
    "id" : 509755555410239488,
    "created_at" : "2014-09-10 17:29:29 +0000",
    "user" : {
      "name" : "Gov. Brown Press Ofc",
      "screen_name" : "GovPressOffice",
      "protected" : false,
      "id_str" : "1285266390",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3561342117\/ebc90cfb72b98861a13906d75d6fae75_normal.png",
      "id" : 1285266390,
      "verified" : true
    }
  },
  "id" : 509763365749932032,
  "created_at" : "2014-09-10 18:00:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/509753005810659328\/photo\/1",
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/yGCfo0JC85",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BxMBqElIEAAG6yo.jpg",
      "id_str" : "509753005118590976",
      "id" : 509753005118590976,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxMBqElIEAAG6yo.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/yGCfo0JC85"
    } ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 37, 46 ]
    }, {
      "text" : "PaycheckFairness",
      "indices" : [ 82, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/dYL3qDbT2U",
      "expanded_url" : "http:\/\/wh.gov\/equal-pay",
      "display_url" : "wh.gov\/equal-pay"
    } ]
  },
  "geo" : { },
  "id_str" : "509753005810659328",
  "text" : "RT if you agree: It's time to ensure #EqualPay for women \u2192 http:\/\/t.co\/dYL3qDbT2U #PaycheckFairness http:\/\/t.co\/yGCfo0JC85",
  "id" : 509753005810659328,
  "created_at" : "2014-09-10 17:19:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/509742201136750594\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/pS1qbuR1I3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BxL31HBIIAA4eap.jpg",
      "id_str" : "509742199635189760",
      "id" : 509742199635189760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxL31HBIIAA4eap.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/pS1qbuR1I3"
    } ],
    "hashtags" : [ {
      "text" : "WomenSucceed",
      "indices" : [ 5, 18 ]
    }, {
      "text" : "EqualPay",
      "indices" : [ 68, 77 ]
    }, {
      "text" : "PaycheckFairness",
      "indices" : [ 89, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509742201136750594",
  "text" : "When #WomenSucceed, America succeeds. It's long-past time to ensure #EqualPay for women. #PaycheckFairness http:\/\/t.co\/pS1qbuR1I3",
  "id" : 509742201136750594,
  "created_at" : "2014-09-10 16:36:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SuicideAwarenessDay",
      "indices" : [ 27, 47 ]
    }, {
      "text" : "PowerOf1",
      "indices" : [ 128, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/9RIbD6yLW3",
      "expanded_url" : "http:\/\/VeteransCrisisLine.net\/ThePowerOf1",
      "display_url" : "VeteransCrisisLine.net\/ThePowerOf1"
    } ]
  },
  "geo" : { },
  "id_str" : "509723578183733248",
  "text" : "RT @JoiningForces: On this #SuicideAwarenessDay, remember that it only takes one person to save a life \u2192 http:\/\/t.co\/9RIbD6yLW3 #PowerOf1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SuicideAwarenessDay",
        "indices" : [ 8, 28 ]
      }, {
        "text" : "PowerOf1",
        "indices" : [ 109, 118 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/9RIbD6yLW3",
        "expanded_url" : "http:\/\/VeteransCrisisLine.net\/ThePowerOf1",
        "display_url" : "VeteransCrisisLine.net\/ThePowerOf1"
      } ]
    },
    "geo" : { },
    "id_str" : "509721764738244609",
    "text" : "On this #SuicideAwarenessDay, remember that it only takes one person to save a life \u2192 http:\/\/t.co\/9RIbD6yLW3 #PowerOf1",
    "id" : 509721764738244609,
    "created_at" : "2014-09-10 15:15:13 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 509723578183733248,
  "created_at" : "2014-09-10 15:22:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "indices" : [ 3, 15 ],
      "id_str" : "369232105",
      "id" : 369232105
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Suicide",
      "indices" : [ 116, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509714601123250176",
  "text" : "RT @PAniskoff44: Today is Suicide Prevention Day. If you are in crisis, please call the Lifeline at 1-800-273-8255. #Suicide is preventable.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Suicide",
        "indices" : [ 99, 107 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "509709208837980160",
    "text" : "Today is Suicide Prevention Day. If you are in crisis, please call the Lifeline at 1-800-273-8255. #Suicide is preventable.",
    "id" : 509709208837980160,
    "created_at" : "2014-09-10 14:25:19 +0000",
    "user" : {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "protected" : false,
      "id_str" : "369232105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623146355767140352\/58sqoVrw_normal.jpg",
      "id" : 369232105,
      "verified" : true
    }
  },
  "id" : 509714601123250176,
  "created_at" : "2014-09-10 14:46:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ReachHigher",
      "indices" : [ 74, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/ETT9D5RHak",
      "expanded_url" : "http:\/\/go.wh.gov\/BfRfMb",
      "display_url" : "go.wh.gov\/BfRfMb"
    } ]
  },
  "geo" : { },
  "id_str" : "509482407875973120",
  "text" : "RT @FLOTUS: Heard of a \"Prep Rally\"? High schoolers in Atlanta prepare to #ReachHigher toward college \u2192 http:\/\/t.co\/ETT9D5RHak http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/509476455487508480\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/jozgo7GGnY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BxHZbwLIEAAtGLi.jpg",
        "id_str" : "509427303680839680",
        "id" : 509427303680839680,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxHZbwLIEAAtGLi.jpg",
        "sizes" : [ {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/jozgo7GGnY"
      } ],
      "hashtags" : [ {
        "text" : "ReachHigher",
        "indices" : [ 62, 74 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/ETT9D5RHak",
        "expanded_url" : "http:\/\/go.wh.gov\/BfRfMb",
        "display_url" : "go.wh.gov\/BfRfMb"
      } ]
    },
    "geo" : { },
    "id_str" : "509476455487508480",
    "text" : "Heard of a \"Prep Rally\"? High schoolers in Atlanta prepare to #ReachHigher toward college \u2192 http:\/\/t.co\/ETT9D5RHak http:\/\/t.co\/jozgo7GGnY",
    "id" : 509476455487508480,
    "created_at" : "2014-09-09 23:00:27 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 509482407875973120,
  "created_at" : "2014-09-09 23:24:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/VP\/status\/509474336466419712\/photo\/1",
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/SrosJoXjMQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BxIENOgIIAA2mS6.png",
      "id_str" : "509474333123944448",
      "id" : 509474333123944448,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxIENOgIIAA2mS6.png",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/SrosJoXjMQ"
    } ],
    "hashtags" : [ {
      "text" : "1Is2Many",
      "indices" : [ 75, 84 ]
    }, {
      "text" : "VAWA",
      "indices" : [ 85, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509474945030557696",
  "text" : "RT @VP: Every woman deserves to live her life free from violence and fear. #1Is2Many #VAWA http:\/\/t.co\/SrosJoXjMQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/509474336466419712\/photo\/1",
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/SrosJoXjMQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BxIENOgIIAA2mS6.png",
        "id_str" : "509474333123944448",
        "id" : 509474333123944448,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxIENOgIIAA2mS6.png",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/SrosJoXjMQ"
      } ],
      "hashtags" : [ {
        "text" : "1Is2Many",
        "indices" : [ 67, 76 ]
      }, {
        "text" : "VAWA",
        "indices" : [ 77, 82 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "509474336466419712",
    "text" : "Every woman deserves to live her life free from violence and fear. #1Is2Many #VAWA http:\/\/t.co\/SrosJoXjMQ",
    "id" : 509474336466419712,
    "created_at" : "2014-09-09 22:52:02 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 509474945030557696,
  "created_at" : "2014-09-09 22:54:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1Is2Many",
      "indices" : [ 99, 108 ]
    }, {
      "text" : "VAWA",
      "indices" : [ 133, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/wH3ckTAevi",
      "expanded_url" : "http:\/\/go.wh.gov\/gfWzP4",
      "display_url" : "go.wh.gov\/gfWzP4"
    } ]
  },
  "geo" : { },
  "id_str" : "509449969195945984",
  "text" : "FACT: Yearly domestic violence rates have \u2193 by 64% since 1993, but there's more work to do because #1Is2Many: http:\/\/t.co\/wH3ckTAevi #VAWA",
  "id" : 509449969195945984,
  "created_at" : "2014-09-09 21:15:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steny Hoyer",
      "screen_name" : "WhipHoyer",
      "indices" : [ 3, 13 ],
      "id_str" : "22012091",
      "id" : 22012091
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaisetheWage",
      "indices" : [ 40, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509449541071159296",
  "text" : "RT @WhipHoyer: 71% of Americans support #RaisetheWage, but House Rs have voted 6x against Fair Minimum Wage Act to raise min wage http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WhipHoyer\/status\/509447655307505665\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/PeObrSR6nB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BxHr8UmCMAE8puY.jpg",
        "id_str" : "509447654422491137",
        "id" : 509447654422491137,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxHr8UmCMAE8puY.jpg",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 617
        }, {
          "h" : 331,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 187,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 617
        } ],
        "display_url" : "pic.twitter.com\/PeObrSR6nB"
      } ],
      "hashtags" : [ {
        "text" : "RaisetheWage",
        "indices" : [ 25, 38 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "509447655307505665",
    "text" : "71% of Americans support #RaisetheWage, but House Rs have voted 6x against Fair Minimum Wage Act to raise min wage http:\/\/t.co\/PeObrSR6nB",
    "id" : 509447655307505665,
    "created_at" : "2014-09-09 21:06:00 +0000",
    "user" : {
      "name" : "Steny Hoyer",
      "screen_name" : "WhipHoyer",
      "protected" : false,
      "id_str" : "22012091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/742490369347203072\/WLvGn-ia_normal.jpg",
      "id" : 22012091,
      "verified" : true
    }
  },
  "id" : 509449541071159296,
  "created_at" : "2014-09-09 21:13:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1Is2Many",
      "indices" : [ 29, 38 ]
    }, {
      "text" : "VAWA",
      "indices" : [ 130, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/muLSDqCIMR",
      "expanded_url" : "http:\/\/go.wh.gov\/aTf3B5",
      "display_url" : "go.wh.gov\/aTf3B5"
    } ]
  },
  "geo" : { },
  "id_str" : "509439669344296960",
  "text" : "\"It has to end, because even #1Is2Many.\" \u2014Obama on the 20th anniversary of the Violence Against Women Act: http:\/\/t.co\/muLSDqCIMR #VAWA",
  "id" : 509439669344296960,
  "created_at" : "2014-09-09 20:34:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VAWA",
      "indices" : [ 129, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509427555867181056",
  "text" : "RT @VP: \"When we all understand that even one case is too many, that\u2019s when it will change.\" -VP Biden on violence against women #VAWA #1is\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "VAWA",
        "indices" : [ 121, 126 ]
      }, {
        "text" : "1is2Many",
        "indices" : [ 127, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "509422378343219201",
    "text" : "\"When we all understand that even one case is too many, that\u2019s when it will change.\" -VP Biden on violence against women #VAWA #1is2Many",
    "id" : 509422378343219201,
    "created_at" : "2014-09-09 19:25:34 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 509427555867181056,
  "created_at" : "2014-09-09 19:46:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/509419750472957952\/photo\/1",
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/0Vaz3bMCDB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BxHQQONIAAAH9l3.jpg",
      "id_str" : "509417209979207680",
      "id" : 509417209979207680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxHQQONIAAAH9l3.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/0Vaz3bMCDB"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509419750472957952",
  "text" : "The President's desk. http:\/\/t.co\/0Vaz3bMCDB",
  "id" : 509419750472957952,
  "created_at" : "2014-09-09 19:15:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VAWA",
      "indices" : [ 102, 107 ]
    }, {
      "text" : "1is2Many",
      "indices" : [ 108, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/E54aXpgvxZ",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/live\/vice-president-biden-delivers-remarks-commemorate-20th-anniversary-violence-against-women-act",
      "display_url" : "whitehouse.gov\/live\/vice-pres\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "509416581634342913",
  "text" : "RT @VP: \"The greatest abuse that can be committed by a man or woman is the abuse of power.\" -VP Biden #VAWA #1is2Many http:\/\/t.co\/E54aXpgvxZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "VAWA",
        "indices" : [ 94, 99 ]
      }, {
        "text" : "1is2Many",
        "indices" : [ 100, 109 ]
      } ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/E54aXpgvxZ",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/live\/vice-president-biden-delivers-remarks-commemorate-20th-anniversary-violence-against-women-act",
        "display_url" : "whitehouse.gov\/live\/vice-pres\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "509413910274138112",
    "text" : "\"The greatest abuse that can be committed by a man or woman is the abuse of power.\" -VP Biden #VAWA #1is2Many http:\/\/t.co\/E54aXpgvxZ",
    "id" : 509413910274138112,
    "created_at" : "2014-09-09 18:51:55 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 509416581634342913,
  "created_at" : "2014-09-09 19:02:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VAWA",
      "indices" : [ 131, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/E54aXpgvxZ",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/live\/vice-president-biden-delivers-remarks-commemorate-20th-anniversary-violence-against-women-act",
      "display_url" : "whitehouse.gov\/live\/vice-pres\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "509409430262132737",
  "text" : "RT @VP: Starting soon: VP Biden delivers remarks on the 20th anniversary of the Violence Against Women Act. http:\/\/t.co\/E54aXpgvxZ #VAWA #1\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "VAWA",
        "indices" : [ 123, 128 ]
      }, {
        "text" : "1is2Many",
        "indices" : [ 129, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/E54aXpgvxZ",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/live\/vice-president-biden-delivers-remarks-commemorate-20th-anniversary-violence-against-women-act",
        "display_url" : "whitehouse.gov\/live\/vice-pres\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "509407097348685825",
    "text" : "Starting soon: VP Biden delivers remarks on the 20th anniversary of the Violence Against Women Act. http:\/\/t.co\/E54aXpgvxZ #VAWA #1is2Many",
    "id" : 509407097348685825,
    "created_at" : "2014-09-09 18:24:50 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 509409430262132737,
  "created_at" : "2014-09-09 18:34:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "indices" : [ 3, 10 ],
      "id_str" : "166252256",
      "id" : 166252256
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ENERGY\/status\/509370918351929344\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/sFycOfRhbo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BxGmJr8IEAArKvg.jpg",
      "id_str" : "509370918213521408",
      "id" : 509370918213521408,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxGmJr8IEAArKvg.jpg",
      "sizes" : [ {
        "h" : 867,
        "resize" : "fit",
        "w" : 620
      }, {
        "h" : 475,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 839,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 867,
        "resize" : "fit",
        "w" : 620
      } ],
      "display_url" : "pic.twitter.com\/sFycOfRhbo"
    } ],
    "hashtags" : [ {
      "text" : "WomenInSTEM",
      "indices" : [ 71, 83 ]
    }, {
      "text" : "Trekkie",
      "indices" : [ 107, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/bu7QxD8MyX",
      "expanded_url" : "http:\/\/go.usa.gov\/VYwP",
      "display_url" : "go.usa.gov\/VYwP"
    } ]
  },
  "geo" : { },
  "id_str" : "509384937586577409",
  "text" : "RT @ENERGY: How a love for science led to a career in renewable energy #WomenInSTEM http:\/\/t.co\/bu7QxD8MyX #Trekkie http:\/\/t.co\/sFycOfRhbo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/measuredvoice.com\/\" rel=\"nofollow\"\u003EMeasured Voice\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ENERGY\/status\/509370918351929344\/photo\/1",
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/sFycOfRhbo",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BxGmJr8IEAArKvg.jpg",
        "id_str" : "509370918213521408",
        "id" : 509370918213521408,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxGmJr8IEAArKvg.jpg",
        "sizes" : [ {
          "h" : 867,
          "resize" : "fit",
          "w" : 620
        }, {
          "h" : 475,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 839,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 867,
          "resize" : "fit",
          "w" : 620
        } ],
        "display_url" : "pic.twitter.com\/sFycOfRhbo"
      } ],
      "hashtags" : [ {
        "text" : "WomenInSTEM",
        "indices" : [ 59, 71 ]
      }, {
        "text" : "Trekkie",
        "indices" : [ 95, 103 ]
      } ],
      "urls" : [ {
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/bu7QxD8MyX",
        "expanded_url" : "http:\/\/go.usa.gov\/VYwP",
        "display_url" : "go.usa.gov\/VYwP"
      } ]
    },
    "geo" : { },
    "id_str" : "509370918351929344",
    "text" : "How a love for science led to a career in renewable energy #WomenInSTEM http:\/\/t.co\/bu7QxD8MyX #Trekkie http:\/\/t.co\/sFycOfRhbo",
    "id" : 509370918351929344,
    "created_at" : "2014-09-09 16:01:05 +0000",
    "user" : {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "protected" : false,
      "id_str" : "166252256",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793425839694155781\/HRS6sfn4_normal.jpg",
      "id" : 166252256,
      "verified" : true
    }
  },
  "id" : 509384937586577409,
  "created_at" : "2014-09-09 16:56:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Associated Press",
      "screen_name" : "AP",
      "indices" : [ 18, 21 ],
      "id_str" : "51241574",
      "id" : 51241574
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/509374444528087040\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/N7PnTl4ulH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BxGnoBZIQAAXStE.jpg",
      "id_str" : "509372538880016384",
      "id" : 509372538880016384,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxGnoBZIQAAXStE.jpg",
      "sizes" : [ {
        "h" : 513,
        "resize" : "fit",
        "w" : 581
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 513,
        "resize" : "fit",
        "w" : 581
      }, {
        "h" : 513,
        "resize" : "fit",
        "w" : 581
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/N7PnTl4ulH"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/kcZEfCPNzw",
      "expanded_url" : "http:\/\/apne.ws\/1qBl5zt",
      "display_url" : "apne.ws\/1qBl5zt"
    } ]
  },
  "geo" : { },
  "id_str" : "509374444528087040",
  "text" : "Good news via the @AP:\n1. U.S. job openings are at a 13-year high\n2. Hiring continues to \u2191\nhttp:\/\/t.co\/kcZEfCPNzw http:\/\/t.co\/N7PnTl4ulH",
  "id" : 509374444528087040,
  "created_at" : "2014-09-09 16:15:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509366427049287681",
  "text" : "RT @pfeiffer44: President Obama will address the nation tomorrow night at 9 PM to lay out the strategy for degrading and ultimately destroy\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "509361930507943937",
    "text" : "President Obama will address the nation tomorrow night at 9 PM to lay out the strategy for degrading and ultimately destroying ISIL",
    "id" : 509361930507943937,
    "created_at" : "2014-09-09 15:25:22 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 509366427049287681,
  "created_at" : "2014-09-09 15:43:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/509363465572855808\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/HAPon2AWyD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BxGfXuoIAAAHvdT.png",
      "id_str" : "509363462871711744",
      "id" : 509363462871711744,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxGfXuoIAAAHvdT.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 196,
        "resize" : "fit",
        "w" : 756
      }, {
        "h" : 88,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 196,
        "resize" : "fit",
        "w" : 756
      }, {
        "h" : 156,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/HAPon2AWyD"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509363465572855808",
  "text" : "President Obama will address the nation from the State Floor at 9pm ET tomorrow on the threat posed by ISIL. http:\/\/t.co\/HAPon2AWyD",
  "id" : 509363465572855808,
  "created_at" : "2014-09-09 15:31:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "TODAY",
      "screen_name" : "TODAYshow",
      "indices" : [ 86, 96 ],
      "id_str" : "7744592",
      "id" : 7744592
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VAWA",
      "indices" : [ 120, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/4LjMEtQD8q",
      "expanded_url" : "http:\/\/www.today.com\/news\/joe-biden-ray-rice-suspension-nfl-ravens-did-right-thing-1D80136515",
      "display_url" : "today.com\/news\/joe-biden\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "509358114081374208",
  "text" : "RT @VP: \"No man has a right to raise a hand to a woman for any reason.\" -VP Biden via @TODAYshow http:\/\/t.co\/4LjMEtQD8q #VAWA http:\/\/t.co\/9\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "TODAY",
        "screen_name" : "TODAYshow",
        "indices" : [ 78, 88 ],
        "id_str" : "7744592",
        "id" : 7744592
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/509355218015092736\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/9CD03eE1Ki",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BxGX3l9CUAA0gGK.jpg",
        "id_str" : "509355214206291968",
        "id" : 509355214206291968,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxGX3l9CUAA0gGK.jpg",
        "sizes" : [ {
          "h" : 420,
          "resize" : "fit",
          "w" : 560
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 420,
          "resize" : "fit",
          "w" : 560
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 420,
          "resize" : "fit",
          "w" : 560
        } ],
        "display_url" : "pic.twitter.com\/9CD03eE1Ki"
      } ],
      "hashtags" : [ {
        "text" : "VAWA",
        "indices" : [ 112, 117 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/4LjMEtQD8q",
        "expanded_url" : "http:\/\/www.today.com\/news\/joe-biden-ray-rice-suspension-nfl-ravens-did-right-thing-1D80136515",
        "display_url" : "today.com\/news\/joe-biden\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "509355218015092736",
    "text" : "\"No man has a right to raise a hand to a woman for any reason.\" -VP Biden via @TODAYshow http:\/\/t.co\/4LjMEtQD8q #VAWA http:\/\/t.co\/9CD03eE1Ki",
    "id" : 509355218015092736,
    "created_at" : "2014-09-09 14:58:42 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 509358114081374208,
  "created_at" : "2014-09-09 15:10:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/509350153355272192\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/6VV4YQ97PL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BxGTQ90IIAA34A1.jpg",
      "id_str" : "509350152549965824",
      "id" : 509350152549965824,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxGTQ90IIAA34A1.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/6VV4YQ97PL"
    } ],
    "hashtags" : [ {
      "text" : "RebuildAmerica",
      "indices" : [ 71, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/sQ2GJCuVs0",
      "expanded_url" : "http:\/\/go.wh.gov\/mmT8BB",
      "display_url" : "go.wh.gov\/mmT8BB"
    } ]
  },
  "geo" : { },
  "id_str" : "509350153355272192",
  "text" : "Find out how President Obama's building public-private partnerships to #RebuildAmerica: http:\/\/t.co\/sQ2GJCuVs0 http:\/\/t.co\/6VV4YQ97PL",
  "id" : 509350153355272192,
  "created_at" : "2014-09-09 14:38:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/MYwpAzmEa3",
      "expanded_url" : "http:\/\/go.wh.gov\/hUK6Yw",
      "display_url" : "go.wh.gov\/hUK6Yw"
    } ]
  },
  "geo" : { },
  "id_str" : "509331218006282240",
  "text" : "RT @FLOTUS: \"If somebody tells you that you\u2019re not college material...prove them wrong.\" \u2014FLOTUS: http:\/\/t.co\/MYwpAzmEa3 http:\/\/t.co\/eaOc8v\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/509146781419331584\/photo\/1",
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/eaOc8vv3eJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BxDaTGlIUAAvJDP.jpg",
        "id_str" : "509146779611582464",
        "id" : 509146779611582464,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxDaTGlIUAAvJDP.jpg",
        "sizes" : [ {
          "h" : 235,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 415,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1730,
          "resize" : "fit",
          "w" : 2500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 709,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/eaOc8vv3eJ"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/MYwpAzmEa3",
        "expanded_url" : "http:\/\/go.wh.gov\/hUK6Yw",
        "display_url" : "go.wh.gov\/hUK6Yw"
      } ]
    },
    "geo" : { },
    "id_str" : "509146781419331584",
    "text" : "\"If somebody tells you that you\u2019re not college material...prove them wrong.\" \u2014FLOTUS: http:\/\/t.co\/MYwpAzmEa3 http:\/\/t.co\/eaOc8vv3eJ",
    "id" : 509146781419331584,
    "created_at" : "2014-09-09 01:10:26 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 509331218006282240,
  "created_at" : "2014-09-09 13:23:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 64, 73 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/509174411061370880\/photo\/1",
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/wKVjng3qQ6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BxDzbaXIIAAD5g5.jpg",
      "id_str" : "509174410151206912",
      "id" : 509174410151206912,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxDzbaXIIAAD5g5.jpg",
      "sizes" : [ {
        "h" : 92,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 163,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 171,
        "resize" : "fit",
        "w" : 631
      }, {
        "h" : 171,
        "resize" : "fit",
        "w" : 631
      } ],
      "display_url" : "pic.twitter.com\/wKVjng3qQ6"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509196335657271296",
  "text" : "RT @vj44: \"Hitting a woman is not something a real man does.\" - @PressSec http:\/\/t.co\/wKVjng3qQ6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Josh Earnest",
        "screen_name" : "PressSec",
        "indices" : [ 54, 63 ],
        "id_str" : "113420831",
        "id" : 113420831
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/509174411061370880\/photo\/1",
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/wKVjng3qQ6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BxDzbaXIIAAD5g5.jpg",
        "id_str" : "509174410151206912",
        "id" : 509174410151206912,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxDzbaXIIAAD5g5.jpg",
        "sizes" : [ {
          "h" : 92,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 163,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 171,
          "resize" : "fit",
          "w" : 631
        }, {
          "h" : 171,
          "resize" : "fit",
          "w" : 631
        } ],
        "display_url" : "pic.twitter.com\/wKVjng3qQ6"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "509174411061370880",
    "text" : "\"Hitting a woman is not something a real man does.\" - @PressSec http:\/\/t.co\/wKVjng3qQ6",
    "id" : 509174411061370880,
    "created_at" : "2014-09-09 03:00:14 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 509196335657271296,
  "created_at" : "2014-09-09 04:27:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/509113320411234306\/photo\/1",
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/gXojMuaRg1",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/BxC73ZDIIAAcZas.png",
      "id_str" : "509113318184067072",
      "id" : 509113318184067072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/BxC73ZDIIAAcZas.png",
      "sizes" : [ {
        "h" : 204,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 312,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 312,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 312,
        "resize" : "fit",
        "w" : 520
      } ],
      "display_url" : "pic.twitter.com\/gXojMuaRg1"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/2aHwTHOjeE",
      "expanded_url" : "http:\/\/go.wh.gov\/8yC5cu",
      "display_url" : "go.wh.gov\/8yC5cu"
    } ]
  },
  "geo" : { },
  "id_str" : "509113320411234306",
  "text" : "Check out how consumer spending has gone \u2191 under President Obama \u2192 http:\/\/t.co\/2aHwTHOjeE http:\/\/t.co\/gXojMuaRg1",
  "id" : 509113320411234306,
  "created_at" : "2014-09-08 22:57:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "indices" : [ 3, 12 ],
      "id_str" : "1604366701",
      "id" : 1604366701
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/LaborSec\/status\/509101630936346625\/photo\/1",
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/J6ri5TzxJ2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BxCxPEaIMAAw47B.png",
      "id_str" : "509101630332350464",
      "id" : 509101630332350464,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxCxPEaIMAAw47B.png",
      "sizes" : [ {
        "h" : 598,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1020,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 339,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 1205
      } ],
      "display_url" : "pic.twitter.com\/J6ri5TzxJ2"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 45, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509107050295881730",
  "text" : "RT @LaborSec: The graphic speaks for itself. #RaiseTheWage http:\/\/t.co\/J6ri5TzxJ2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/LaborSec\/status\/509101630936346625\/photo\/1",
        "indices" : [ 45, 67 ],
        "url" : "http:\/\/t.co\/J6ri5TzxJ2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BxCxPEaIMAAw47B.png",
        "id_str" : "509101630332350464",
        "id" : 509101630332350464,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxCxPEaIMAAw47B.png",
        "sizes" : [ {
          "h" : 598,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1020,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 339,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1205
        } ],
        "display_url" : "pic.twitter.com\/J6ri5TzxJ2"
      } ],
      "hashtags" : [ {
        "text" : "RaiseTheWage",
        "indices" : [ 31, 44 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "509101630936346625",
    "text" : "The graphic speaks for itself. #RaiseTheWage http:\/\/t.co\/J6ri5TzxJ2",
    "id" : 509101630936346625,
    "created_at" : "2014-09-08 22:11:02 +0000",
    "user" : {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "protected" : false,
      "id_str" : "1604366701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744887280666611712\/eEeyFjs6_normal.jpg",
      "id" : 1604366701,
      "verified" : true
    }
  },
  "id" : 509107050295881730,
  "created_at" : "2014-09-08 22:32:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/509077060921593856\/photo\/1",
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/gX0B1QGSIk",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/BxCa4zpIgAAVVKU.png",
      "id_str" : "509077058618949632",
      "id" : 509077058618949632,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/BxCa4zpIgAAVVKU.png",
      "sizes" : [ {
        "h" : 204,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 312,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 312,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 312,
        "resize" : "fit",
        "w" : 520
      } ],
      "display_url" : "pic.twitter.com\/gX0B1QGSIk"
    } ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 82, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/2aHwTHOjeE",
      "expanded_url" : "http:\/\/go.wh.gov\/8yC5cu",
      "display_url" : "go.wh.gov\/8yC5cu"
    } ]
  },
  "geo" : { },
  "id_str" : "509077060921593856",
  "text" : "FACT: We're building cars at the highest rate since 2002 \u2192 http:\/\/t.co\/2aHwTHOjeE #MadeInAmerica http:\/\/t.co\/gX0B1QGSIk",
  "id" : 509077060921593856,
  "created_at" : "2014-09-08 20:33:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/509059665460985857\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/Nn79Qp6inL",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/BxCLERWIgAAtxqg.png",
      "id_str" : "509059663384838144",
      "id" : 509059663384838144,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/BxCLERWIgAAtxqg.png",
      "sizes" : [ {
        "h" : 204,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 312,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 312,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 312,
        "resize" : "fit",
        "w" : 520
      } ],
      "display_url" : "pic.twitter.com\/Nn79Qp6inL"
    } ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 74, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/2aHwTHOjeE",
      "expanded_url" : "http:\/\/go.wh.gov\/8yC5cu",
      "display_url" : "go.wh.gov\/8yC5cu"
    } ]
  },
  "geo" : { },
  "id_str" : "509059665460985857",
  "text" : "We're selling more goods than ever before stamped with three proud words: #MadeInAmerica \u2192 http:\/\/t.co\/2aHwTHOjeE http:\/\/t.co\/Nn79Qp6inL",
  "id" : 509059665460985857,
  "created_at" : "2014-09-08 19:24:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ReachHigher",
      "indices" : [ 124, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509045525199749120",
  "text" : "RT @FLOTUS: \"If somebody tells you that you\u2019re not college material, brush them off and prove them wrong.\" - The First Lady #ReachHigher #e\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ReachHigher",
        "indices" : [ 112, 124 ]
      }, {
        "text" : "edtour14",
        "indices" : [ 125, 134 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "509045096877424640",
    "text" : "\"If somebody tells you that you\u2019re not college material, brush them off and prove them wrong.\" - The First Lady #ReachHigher #edtour14",
    "id" : 509045096877424640,
    "created_at" : "2014-09-08 18:26:23 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 509045525199749120,
  "created_at" : "2014-09-08 18:28:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 15, 22 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Upworthy",
      "screen_name" : "Upworthy",
      "indices" : [ 26, 35 ],
      "id_str" : "524396430",
      "id" : 524396430
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ReachHigher",
      "indices" : [ 121, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/lycSvi9QiA",
      "expanded_url" : "http:\/\/u.pw\/1oZ8q3z",
      "display_url" : "u.pw\/1oZ8q3z"
    } ]
  },
  "geo" : { },
  "id_str" : "509041006986403840",
  "text" : "Worth reading: @FLOTUS on @Upworthy about what it's like to be a 1st-generation college student \u2192 http:\/\/t.co\/lycSvi9QiA #ReachHigher",
  "id" : 509041006986403840,
  "created_at" : "2014-09-08 18:10:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Upworthy",
      "screen_name" : "Upworthy",
      "indices" : [ 3, 12 ],
      "id_str" : "524396430",
      "id" : 524396430
    }, {
      "name" : "Reach Higher",
      "screen_name" : "ReachHigher",
      "indices" : [ 80, 92 ],
      "id_str" : "2461821548",
      "id" : 2461821548
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 96, 103 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509032586963083264",
  "text" : "RT @Upworthy: \"It's up to all of us to make sure we're helping our young people @ReachHigher\" - @FLOTUS Michelle Obama http:\/\/t.co\/qCMpWc4C\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Reach Higher",
        "screen_name" : "ReachHigher",
        "indices" : [ 66, 78 ],
        "id_str" : "2461821548",
        "id" : 2461821548
      }, {
        "name" : "The First Lady",
        "screen_name" : "FLOTUS",
        "indices" : [ 82, 89 ],
        "id_str" : "1093090866",
        "id" : 1093090866
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/qCMpWc4CSO",
        "expanded_url" : "http:\/\/u.pw\/1oZ8q3z",
        "display_url" : "u.pw\/1oZ8q3z"
      } ]
    },
    "geo" : { },
    "id_str" : "509029988491079680",
    "text" : "\"It's up to all of us to make sure we're helping our young people @ReachHigher\" - @FLOTUS Michelle Obama http:\/\/t.co\/qCMpWc4CSO",
    "id" : 509029988491079680,
    "created_at" : "2014-09-08 17:26:21 +0000",
    "user" : {
      "name" : "Upworthy",
      "screen_name" : "Upworthy",
      "protected" : false,
      "id_str" : "524396430",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723597465941766144\/piclWuSr_normal.jpg",
      "id" : 524396430,
      "verified" : true
    }
  },
  "id" : 509032586963083264,
  "created_at" : "2014-09-08 17:36:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WestWingWeek",
      "indices" : [ 124, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/Rd8y2FYUrA",
      "expanded_url" : "http:\/\/youtu.be\/D27WHepVl5w",
      "display_url" : "youtu.be\/D27WHepVl5w"
    } ]
  },
  "geo" : { },
  "id_str" : "509008353628913664",
  "text" : "\"When I have the chance to help other people\u2026that gives me the most satisfaction.\" \u2014President Obama: http:\/\/t.co\/Rd8y2FYUrA #WestWingWeek",
  "id" : 509008353628913664,
  "created_at" : "2014-09-08 16:00:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WestWingWeek",
      "indices" : [ 91, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/c2Fk6WExBj",
      "expanded_url" : "http:\/\/youtu.be\/D27WHepVl5w",
      "display_url" : "youtu.be\/D27WHepVl5w"
    } ]
  },
  "geo" : { },
  "id_str" : "508998617399832576",
  "text" : "\"What's it feel like being President of the United States?\"\nWatch \u2192 http:\/\/t.co\/c2Fk6WExBj #WestWingWeek",
  "id" : 508998617399832576,
  "created_at" : "2014-09-08 15:21:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sylvia Burwell",
      "screen_name" : "SecBurwell",
      "indices" : [ 3, 14 ],
      "id_str" : "2458567464",
      "id" : 2458567464
    }, {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "indices" : [ 129, 136 ],
      "id_str" : "44783853",
      "id" : 44783853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "508971052199067648",
  "text" : "RT @SecBurwell: Morning Twitter-world! Excited to join the conversation and look forward to sharing updates with you from across @HHSGov! #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "HHS.gov",
        "screen_name" : "HHSGov",
        "indices" : [ 113, 120 ],
        "id_str" : "44783853",
        "id" : 44783853
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "impact",
        "indices" : [ 122, 129 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "508936236229070848",
    "text" : "Morning Twitter-world! Excited to join the conversation and look forward to sharing updates with you from across @HHSGov! #impact",
    "id" : 508936236229070848,
    "created_at" : "2014-09-08 11:13:48 +0000",
    "user" : {
      "name" : "Sylvia Burwell",
      "screen_name" : "SecBurwell",
      "protected" : false,
      "id_str" : "2458567464",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567351512351793152\/jMgeUhVq_normal.jpeg",
      "id" : 2458567464,
      "verified" : true
    }
  },
  "id" : 508971052199067648,
  "created_at" : "2014-09-08 13:32:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 100, 103 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/kG1nyWw8WM",
      "expanded_url" : "http:\/\/go.wh.gov\/6ZEnKd",
      "display_url" : "go.wh.gov\/6ZEnKd"
    } ]
  },
  "geo" : { },
  "id_str" : "508706301098987521",
  "text" : "\"It\u2019s time to close tax loopholes so we can reduce the deficit, and invest in rebuilding America.\" \u2014@VP Biden: http:\/\/t.co\/kG1nyWw8WM",
  "id" : 508706301098987521,
  "created_at" : "2014-09-07 20:00:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "508681878258593792",
  "text" : "RT @VP: \"Even just 20 yrs ago, violence against women in America was an epidemic few people wanted to talk about.\" -VP Biden http:\/\/t.co\/eV\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/eVniYigq01",
        "expanded_url" : "http:\/\/www.delawareonline.com\/story\/opinion\/contributors\/2014\/09\/06\/hard-fight-end-violence-women\/15199597\/",
        "display_url" : "delawareonline.com\/story\/opinion\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "508676433364152320",
    "text" : "\"Even just 20 yrs ago, violence against women in America was an epidemic few people wanted to talk about.\" -VP Biden http:\/\/t.co\/eVniYigq01",
    "id" : 508676433364152320,
    "created_at" : "2014-09-07 18:01:27 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 508681878258593792,
  "created_at" : "2014-09-07 18:23:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chuck Todd",
      "screen_name" : "chucktodd",
      "indices" : [ 30, 40 ],
      "id_str" : "50325797",
      "id" : 50325797
    }, {
      "name" : "Meet the Press",
      "screen_name" : "MeetThePress",
      "indices" : [ 44, 57 ],
      "id_str" : "11856892",
      "id" : 11856892
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/2Vy266AGR8",
      "expanded_url" : "http:\/\/nbcnews.to\/1xtJ0Wa",
      "display_url" : "nbcnews.to\/1xtJ0Wa"
    } ]
  },
  "geo" : { },
  "id_str" : "508673583480971264",
  "text" : "President Obama sat down with @ChuckTodd on @MeetThePress today. Watch the full interview \u2192 http:\/\/t.co\/2Vy266AGR8",
  "id" : 508673583480971264,
  "created_at" : "2014-09-07 17:50:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 92, 95 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/kG1nyWw8WM",
      "expanded_url" : "http:\/\/go.wh.gov\/6ZEnKd",
      "display_url" : "go.wh.gov\/6ZEnKd"
    } ]
  },
  "geo" : { },
  "id_str" : "508615714622562304",
  "text" : "\"When given a fair shot, the American worker has never, ever, ever, let his country down.\" \u2014@VP Biden: http:\/\/t.co\/kG1nyWw8WM",
  "id" : 508615714622562304,
  "created_at" : "2014-09-07 14:00:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WestWingWeek",
      "indices" : [ 3, 16 ]
    }, {
      "text" : "NATOSummitUK",
      "indices" : [ 94, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/dCOzzRHQ0m",
      "expanded_url" : "http:\/\/go.wh.gov\/mLxbuz",
      "display_url" : "go.wh.gov\/mLxbuz"
    } ]
  },
  "geo" : { },
  "id_str" : "508405812742479876",
  "text" : "In #WestWingWeek, President Obama celebrates Labor Day, travels to Estonia, and addresses the #NATOSummitUK. Watch \u2192 http:\/\/t.co\/dCOzzRHQ0m",
  "id" : 508405812742479876,
  "created_at" : "2014-09-07 00:06:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 87, 90 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 121, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/kG1nyWw8WM",
      "expanded_url" : "http:\/\/go.wh.gov\/6ZEnKd",
      "display_url" : "go.wh.gov\/6ZEnKd"
    } ]
  },
  "geo" : { },
  "id_str" : "508374140743454720",
  "text" : "\"For the first time since the 1990s, American manufacturing is steadily adding jobs.\" \u2014@VP Biden: http:\/\/t.co\/kG1nyWw8WM #MadeInAmerica",
  "id" : 508374140743454720,
  "created_at" : "2014-09-06 22:00:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 24, 27 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/507893954323705856\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/yagKBtGcEe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bwxm1uiIEAEZ9hc.jpg",
      "id_str" : "507893931196289025",
      "id" : 507893931196289025,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bwxm1uiIEAEZ9hc.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/yagKBtGcEe"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/E29MisCbku",
      "expanded_url" : "http:\/\/go.wh.gov\/dcLiVq",
      "display_url" : "go.wh.gov\/dcLiVq"
    } ]
  },
  "geo" : { },
  "id_str" : "508351469616001024",
  "text" : "In this week's address, @VP Biden discusses our continued economic recovery. Watch \u2192 http:\/\/t.co\/E29MisCbku, http:\/\/t.co\/yagKBtGcEe",
  "id" : 508351469616001024,
  "created_at" : "2014-09-06 20:30:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 98, 101 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/kG1nyWw8WM",
      "expanded_url" : "http:\/\/go.wh.gov\/6ZEnKd",
      "display_url" : "go.wh.gov\/6ZEnKd"
    } ]
  },
  "geo" : { },
  "id_str" : "508321285256925184",
  "text" : "\"We\u2019ve gone from losing 9 million jobs during the financial crisis to creating 10 million jobs.\" \u2014@VP Biden: http:\/\/t.co\/kG1nyWw8WM",
  "id" : 508321285256925184,
  "created_at" : "2014-09-06 18:30:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 115, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/dUVpAcu5SV",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=ITl9cwIiPDY",
      "display_url" : "youtube.com\/watch?v=ITl9cw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "508305591601987584",
  "text" : "RT @VP: \"It\u2019s long past due to increase the minimum wage.\" -VP Biden in the Weekly Address https:\/\/t.co\/dUVpAcu5SV #RaiseTheWage",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RaiseTheWage",
        "indices" : [ 107, 120 ]
      } ],
      "urls" : [ {
        "indices" : [ 83, 106 ],
        "url" : "https:\/\/t.co\/dUVpAcu5SV",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=ITl9cwIiPDY",
        "display_url" : "youtube.com\/watch?v=ITl9cw\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "508304402223235073",
    "text" : "\"It\u2019s long past due to increase the minimum wage.\" -VP Biden in the Weekly Address https:\/\/t.co\/dUVpAcu5SV #RaiseTheWage",
    "id" : 508304402223235073,
    "created_at" : "2014-09-06 17:23:07 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 508305591601987584,
  "created_at" : "2014-09-06 17:27:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/2XgwHOEztV",
      "expanded_url" : "http:\/\/go.wh.gov\/vLCXnh",
      "display_url" : "go.wh.gov\/vLCXnh"
    } ]
  },
  "geo" : { },
  "id_str" : "508087514918551552",
  "text" : "Today President Obama visited Stonehenge, his last stop on a trip to Estonia and the NATO Summit in Wales. Watch \u2192 http:\/\/t.co\/2XgwHOEztV",
  "id" : 508087514918551552,
  "created_at" : "2014-09-06 03:01:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "indices" : [ 3, 15 ],
      "id_str" : "15764644",
      "id" : 15764644
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 18, 29 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WomenSucceed",
      "indices" : [ 110, 123 ]
    }, {
      "text" : "MiddleClassFirst",
      "indices" : [ 124, 141 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/055LKtBGmv",
      "expanded_url" : "http:\/\/goo.gl\/yvoJoi",
      "display_url" : "goo.gl\/yvoJoi"
    } ]
  },
  "geo" : { },
  "id_str" : "508005597581942784",
  "text" : "RT @NancyPelosi: .@WhiteHouse: 5 Things You Need to Know about Women &amp; the Economy http:\/\/t.co\/055LKtBGmv #WomenSucceed #MiddleClassFirst",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 1, 12 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WomenSucceed",
        "indices" : [ 93, 106 ]
      }, {
        "text" : "MiddleClassFirst",
        "indices" : [ 107, 124 ]
      } ],
      "urls" : [ {
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/055LKtBGmv",
        "expanded_url" : "http:\/\/goo.gl\/yvoJoi",
        "display_url" : "goo.gl\/yvoJoi"
      } ]
    },
    "geo" : { },
    "id_str" : "507983785083039744",
    "text" : ".@WhiteHouse: 5 Things You Need to Know about Women &amp; the Economy http:\/\/t.co\/055LKtBGmv #WomenSucceed #MiddleClassFirst",
    "id" : 507983785083039744,
    "created_at" : "2014-09-05 20:09:06 +0000",
    "user" : {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "protected" : false,
      "id_str" : "15764644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571313158510223360\/wnSl3yXF_normal.jpeg",
      "id" : 15764644,
      "verified" : true
    }
  },
  "id" : 508005597581942784,
  "created_at" : "2014-09-05 21:35:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/508004221816299520\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/sME9F1rkzU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bwyxlm4IcAE3seE.jpg",
      "id_str" : "507976117635280897",
      "id" : 507976117635280897,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bwyxlm4IcAE3seE.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1250,
        "resize" : "fit",
        "w" : 2500
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/sME9F1rkzU"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/CH1orSj62L",
      "expanded_url" : "http:\/\/go.wh.gov\/DhXuXa",
      "display_url" : "go.wh.gov\/DhXuXa"
    } ]
  },
  "geo" : { },
  "id_str" : "508004221816299520",
  "text" : "Then and now: Homebuilders are breaking ground on 50,000 more homes each month than in 2009 \u2192 http:\/\/t.co\/CH1orSj62L http:\/\/t.co\/sME9F1rkzU",
  "id" : 508004221816299520,
  "created_at" : "2014-09-05 21:30:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/507996651395354625\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/C5eT7ha8Cd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BwyxHAUIAAA18X3.jpg",
      "id_str" : "507975591887634432",
      "id" : 507975591887634432,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwyxHAUIAAA18X3.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/C5eT7ha8Cd"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/CH1orSj62L",
      "expanded_url" : "http:\/\/go.wh.gov\/DhXuXa",
      "display_url" : "go.wh.gov\/DhXuXa"
    } ]
  },
  "geo" : { },
  "id_str" : "507996651395354625",
  "text" : "FACT: American businesses are selling $70 billion more in exports each month than in 2009 \u2192 http:\/\/t.co\/CH1orSj62L http:\/\/t.co\/C5eT7ha8Cd",
  "id" : 507996651395354625,
  "created_at" : "2014-09-05 21:00:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/507989086670295041\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/mOW0LunOtM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BwyxXIGIYAAR8Ct.jpg",
      "id_str" : "507975868854329344",
      "id" : 507975868854329344,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwyxXIGIYAAR8Ct.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1250,
        "resize" : "fit",
        "w" : 2500
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/mOW0LunOtM"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/CH1orSj62L",
      "expanded_url" : "http:\/\/go.wh.gov\/DhXuXa",
      "display_url" : "go.wh.gov\/DhXuXa"
    } ]
  },
  "geo" : { },
  "id_str" : "507989086670295041",
  "text" : "FACT: American consumers are spending $170 billion more each month than in 2009 \u2192 http:\/\/t.co\/CH1orSj62L http:\/\/t.co\/mOW0LunOtM",
  "id" : 507989086670295041,
  "created_at" : "2014-09-05 20:30:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/507981568841744386\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/mhjbqROSmv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BwywuYdIUAAzHt3.jpg",
      "id_str" : "507975168871124992",
      "id" : 507975168871124992,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwywuYdIUAAzHt3.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1250,
        "resize" : "fit",
        "w" : 2500
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/mhjbqROSmv"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/CH1orSj62L",
      "expanded_url" : "http:\/\/go.wh.gov\/DhXuXa",
      "display_url" : "go.wh.gov\/DhXuXa"
    } ]
  },
  "geo" : { },
  "id_str" : "507981568841744386",
  "text" : "Then and now: Auto workers are assembling nearly 800,000 more cars each month than in 2009 \u2192 http:\/\/t.co\/CH1orSj62L http:\/\/t.co\/mhjbqROSmv",
  "id" : 507981568841744386,
  "created_at" : "2014-09-05 20:00:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/507972902529282048\/photo\/1",
      "indices" : [ 120, 142 ],
      "url" : "http:\/\/t.co\/6CbmkJ09cf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BwyuqbmIQAA-2nr.jpg",
      "id_str" : "507972901971443712",
      "id" : 507972901971443712,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwyuqbmIQAA-2nr.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/6CbmkJ09cf"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "507972902529282048",
  "text" : "\"It's spectacular.\" \u2014President Obama at Stonehenge, his last stop on a trip to Estonia &amp; the NATO Summit in the UK. http:\/\/t.co\/6CbmkJ09cf",
  "id" : 507972902529282048,
  "created_at" : "2014-09-05 19:25:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/507893954323705856\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/yagKBtGcEe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bwxm1uiIEAEZ9hc.jpg",
      "id_str" : "507893931196289025",
      "id" : 507893931196289025,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bwxm1uiIEAEZ9hc.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/yagKBtGcEe"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/3OYnqV5NK3",
      "expanded_url" : "http:\/\/go.wh.gov\/DhXuXa",
      "display_url" : "go.wh.gov\/DhXuXa"
    } ]
  },
  "geo" : { },
  "id_str" : "507966313281884160",
  "text" : "The economy that built 10 million jobs: Check out how far we\u2019ve come over the past 5 years \u2192 http:\/\/t.co\/3OYnqV5NK3 http:\/\/t.co\/yagKBtGcEe",
  "id" : 507966313281884160,
  "created_at" : "2014-09-05 18:59:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "507919458841952257",
  "text" : "RT @WHLive: \"Here in Wales, we\u2019ve left absolutely no doubt\u2014we will defend every ally.\" \u2014President Obama on our NATO allies at the #NATOSumm\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NATOSummitUK",
        "indices" : [ 118, 131 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "507919259365027840",
    "text" : "\"Here in Wales, we\u2019ve left absolutely no doubt\u2014we will defend every ally.\" \u2014President Obama on our NATO allies at the #NATOSummitUK",
    "id" : 507919259365027840,
    "created_at" : "2014-09-05 15:52:42 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 507919458841952257,
  "created_at" : "2014-09-05 15:53:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NATOSummitUK",
      "indices" : [ 96, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "507919066116681728",
  "text" : "\"It\u2019s a great honor to be the first sitting U.S. President to visit Wales.\" \u2014President Obama at #NATOSummitUK",
  "id" : 507919066116681728,
  "created_at" : "2014-09-05 15:51:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NATOSummitUK",
      "indices" : [ 65, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "507918806799622144",
  "text" : "Happening now: President Obama holds a press conference from the #NATOSummitUK in Wales",
  "id" : 507918806799622144,
  "created_at" : "2014-09-05 15:50:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/507893954323705856\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/yagKBtGcEe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bwxm1uiIEAEZ9hc.jpg",
      "id_str" : "507893931196289025",
      "id" : 507893931196289025,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bwxm1uiIEAEZ9hc.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/yagKBtGcEe"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "507893954323705856",
  "text" : "Our businesses have added:\n10mil jobs over 54 months \u2714\n2.4mil over the past year \u2714\nThere's still more work to do \u2192 http:\/\/t.co\/yagKBtGcEe",
  "id" : 507893954323705856,
  "created_at" : "2014-09-05 14:12:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Furman",
      "screen_name" : "CEAChair",
      "indices" : [ 3, 12 ],
      "id_str" : "1861751828",
      "id" : 1861751828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/yJ0w9pDm7E",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2014\/09\/05\/employment-situation-august",
      "display_url" : "whitehouse.gov\/blog\/2014\/09\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "507889129678700544",
  "text" : "RT @CEAChair: Businesses have added 10 mil jobs over 54 straight months, extending longest streak on record http:\/\/t.co\/yJ0w9pDm7E http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/CEAChair\/status\/507887868845760512\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/9kSZqWTZwU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BwxhUweIQAAWwtS.jpg",
        "id_str" : "507887867222573056",
        "id" : 507887867222573056,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwxhUweIQAAWwtS.jpg",
        "sizes" : [ {
          "h" : 246,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 435,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 660,
          "resize" : "fit",
          "w" : 911
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 660,
          "resize" : "fit",
          "w" : 911
        } ],
        "display_url" : "pic.twitter.com\/9kSZqWTZwU"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/yJ0w9pDm7E",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2014\/09\/05\/employment-situation-august",
        "display_url" : "whitehouse.gov\/blog\/2014\/09\/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "507887868845760512",
    "text" : "Businesses have added 10 mil jobs over 54 straight months, extending longest streak on record http:\/\/t.co\/yJ0w9pDm7E http:\/\/t.co\/9kSZqWTZwU",
    "id" : 507887868845760512,
    "created_at" : "2014-09-05 13:47:58 +0000",
    "user" : {
      "name" : "Jason Furman",
      "screen_name" : "CEAChair",
      "protected" : false,
      "id_str" : "1861751828",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000628384447\/c9cb85dbdb73c8bac4f28ce4cc46f38b_normal.jpeg",
      "id" : 1861751828,
      "verified" : true
    }
  },
  "id" : 507889129678700544,
  "created_at" : "2014-09-05 13:52:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Labor Department",
      "screen_name" : "USDOL",
      "indices" : [ 3, 9 ],
      "id_str" : "20179628",
      "id" : 20179628
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/USDOL\/status\/507562378913804288\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/NcjI27wTtX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bws5SwoIEAA5RTF.jpg",
      "id_str" : "507562377462943744",
      "id" : 507562377462943744,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bws5SwoIEAA5RTF.jpg",
      "sizes" : [ {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/NcjI27wTtX"
    } ],
    "hashtags" : [ {
      "text" : "WomenSucceed",
      "indices" : [ 16, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "507588223502417920",
  "text" : "RT @USDOL: When #WomenSucceed, America succeeds. 60% of people who would benefit from raising the wage are women. http:\/\/t.co\/NcjI27wTtX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/USDOL\/status\/507562378913804288\/photo\/1",
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/NcjI27wTtX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bws5SwoIEAA5RTF.jpg",
        "id_str" : "507562377462943744",
        "id" : 507562377462943744,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bws5SwoIEAA5RTF.jpg",
        "sizes" : [ {
          "h" : 700,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 700,
          "resize" : "fit",
          "w" : 700
        } ],
        "display_url" : "pic.twitter.com\/NcjI27wTtX"
      } ],
      "hashtags" : [ {
        "text" : "WomenSucceed",
        "indices" : [ 5, 18 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "507562378913804288",
    "text" : "When #WomenSucceed, America succeeds. 60% of people who would benefit from raising the wage are women. http:\/\/t.co\/NcjI27wTtX",
    "id" : 507562378913804288,
    "created_at" : "2014-09-04 16:14:35 +0000",
    "user" : {
      "name" : "US Labor Department",
      "screen_name" : "USDOL",
      "protected" : false,
      "id_str" : "20179628",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655006480697978880\/Fom0f0nJ_normal.png",
      "id" : 20179628,
      "verified" : true
    }
  },
  "id" : 507588223502417920,
  "created_at" : "2014-09-04 17:57:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UK Prime Minister",
      "screen_name" : "Number10gov",
      "indices" : [ 27, 39 ],
      "id_str" : "14224719",
      "id" : 14224719
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/507581441555722242\/photo\/1",
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/Nx8YLexqCB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BwtEy8gIgAAd5MM.jpg",
      "id_str" : "507575025034362880",
      "id" : 507575025034362880,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwtEy8gIgAAd5MM.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Nx8YLexqCB"
    } ],
    "hashtags" : [ {
      "text" : "NATOSummitUK",
      "indices" : [ 47, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/i6PUvWz07n",
      "expanded_url" : "http:\/\/go.wh.gov\/c2TA7m",
      "display_url" : "go.wh.gov\/c2TA7m"
    } ]
  },
  "geo" : { },
  "id_str" : "507581441555722242",
  "text" : "President Obama meets with @Number10Gov at the #NATOSummitUK in Wales \u2192 http:\/\/t.co\/i6PUvWz07n http:\/\/t.co\/Nx8YLexqCB",
  "id" : 507581441555722242,
  "created_at" : "2014-09-04 17:30:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/507570495320240128\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/xAGmkFgDFR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BwtArPdIMAAqiCV.jpg",
      "id_str" : "507570494636568576",
      "id" : 507570494636568576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwtArPdIMAAqiCV.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/xAGmkFgDFR"
    } ],
    "hashtags" : [ {
      "text" : "NATOSummitUK",
      "indices" : [ 69, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/I3ENkjuQhB",
      "expanded_url" : "http:\/\/go.wh.gov\/c2TA7m",
      "display_url" : "go.wh.gov\/c2TA7m"
    } ]
  },
  "geo" : { },
  "id_str" : "507570495320240128",
  "text" : "Go behind the scenes for the latest on President Obama's trip to the #NATOSummitUK \u2192 http:\/\/t.co\/I3ENkjuQhB http:\/\/t.co\/xAGmkFgDFR",
  "id" : 507570495320240128,
  "created_at" : "2014-09-04 16:46:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phil Larson",
      "screen_name" : "Phil44",
      "indices" : [ 3, 10 ],
      "id_str" : "2525192749",
      "id" : 2525192749
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "507564769927516161",
  "text" : "RT @Phil44: So great to have both on board! President Obama names Megan Smith U.S. CTO, Alexander Macgillivray Deputy U.S. CTO http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/xjZeaW9j6J",
        "expanded_url" : "http:\/\/1.usa.gov\/1o1p6Ij",
        "display_url" : "1.usa.gov\/1o1p6Ij"
      } ]
    },
    "geo" : { },
    "id_str" : "507561759670927360",
    "text" : "So great to have both on board! President Obama names Megan Smith U.S. CTO, Alexander Macgillivray Deputy U.S. CTO http:\/\/t.co\/xjZeaW9j6J",
    "id" : 507561759670927360,
    "created_at" : "2014-09-04 16:12:08 +0000",
    "user" : {
      "name" : "Phil Larson",
      "screen_name" : "Phil44",
      "protected" : false,
      "id_str" : "2525192749",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/470938302095183874\/eFAyUNAe_normal.jpeg",
      "id" : 2525192749,
      "verified" : true
    }
  },
  "id" : 507564769927516161,
  "created_at" : "2014-09-04 16:24:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jake Heller",
      "screen_name" : "HellerJake",
      "indices" : [ 3, 14 ],
      "id_str" : "224045953",
      "id" : 224045953
    }, {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "indices" : [ 29, 39 ],
      "id_str" : "15007149",
      "id" : 15007149
    }, {
      "name" : "US Diplomacy Center",
      "screen_name" : "DiplomacyCenter",
      "indices" : [ 96, 112 ],
      "id_str" : "2648849144",
      "id" : 2648849144
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "507557023056400385",
  "text" : "RT @HellerJake: Great photo: @JohnKerry and five other Secretaries of State break ground on the @DiplomacyCenter in D.C. http:\/\/t.co\/6XS7BG\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Kerry",
        "screen_name" : "JohnKerry",
        "indices" : [ 13, 23 ],
        "id_str" : "15007149",
        "id" : 15007149
      }, {
        "name" : "US Diplomacy Center",
        "screen_name" : "DiplomacyCenter",
        "indices" : [ 80, 96 ],
        "id_str" : "2648849144",
        "id" : 2648849144
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/HellerJake\/status\/507262552838266880\/photo\/1",
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/6XS7BG5j1H",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BwoompPIIAAMfao.jpg",
        "id_str" : "507262552402042880",
        "id" : 507262552402042880,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwoompPIIAAMfao.jpg",
        "sizes" : [ {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 1351
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/6XS7BG5j1H"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "507262552838266880",
    "text" : "Great photo: @JohnKerry and five other Secretaries of State break ground on the @DiplomacyCenter in D.C. http:\/\/t.co\/6XS7BG5j1H",
    "id" : 507262552838266880,
    "created_at" : "2014-09-03 20:23:11 +0000",
    "user" : {
      "name" : "Jake Heller",
      "screen_name" : "HellerJake",
      "protected" : false,
      "id_str" : "224045953",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/669386249107546112\/8c9D1Qpk_normal.jpg",
      "id" : 224045953,
      "verified" : true
    }
  },
  "id" : 507557023056400385,
  "created_at" : "2014-09-04 15:53:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/b9zoPNriZs",
      "expanded_url" : "http:\/\/youtu.be\/02WuEbUq_6c",
      "display_url" : "youtu.be\/02WuEbUq_6c"
    } ]
  },
  "geo" : { },
  "id_str" : "507550142871117825",
  "text" : "\"Cynicism is a bad choice. Hope is the better choice.\" \u2014President Obama\nWatch \u2192 http:\/\/t.co\/b9zoPNriZs",
  "id" : 507550142871117825,
  "created_at" : "2014-09-04 15:25:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/wNVWicnGvW",
      "expanded_url" : "http:\/\/youtu.be\/bWAnzKtFPkE",
      "display_url" : "youtu.be\/bWAnzKtFPkE"
    } ]
  },
  "geo" : { },
  "id_str" : "507535383320887297",
  "text" : "\"If we are willing to work for it, if we stand together, the future can be different, tomorrow can be better\" \u2014Obama: http:\/\/t.co\/wNVWicnGvW",
  "id" : 507535383320887297,
  "created_at" : "2014-09-04 14:27:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0412\u0438\u043D\u043E\u0433\u0440\u0430\u0434\u043E\u0432   \u0421\u043F\u0438\u0440\u0438\u0434\u043E",
      "screen_name" : "john_dingell",
      "indices" : [ 3, 16 ],
      "id_str" : "2982226132",
      "id" : 2982226132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "507287975378845697",
  "text" : "RT @john_dingell: 50 yrs ago today, LBJ signed Wilderness Act. As lone remaining member to vote for it, I'm proud of all it did &amp; does. htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/john_dingell\/status\/507219906983899136\/photo\/1",
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/nRY5PXZ0iD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BwoB0UtIgAAZX4t.jpg",
        "id_str" : "507219906455437312",
        "id" : 507219906455437312,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwoB0UtIgAAZX4t.jpg",
        "sizes" : [ {
          "h" : 683,
          "resize" : "fit",
          "w" : 988
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 988
        }, {
          "h" : 415,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 235,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/nRY5PXZ0iD"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "507219906983899136",
    "text" : "50 yrs ago today, LBJ signed Wilderness Act. As lone remaining member to vote for it, I'm proud of all it did &amp; does. http:\/\/t.co\/nRY5PXZ0iD",
    "id" : 507219906983899136,
    "created_at" : "2014-09-03 17:33:44 +0000",
    "user" : {
      "name" : "John Dingell",
      "screen_name" : "JohnDingell",
      "protected" : false,
      "id_str" : "109025212",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/751796404864122880\/jiPHasvn_normal.jpg",
      "id" : 109025212,
      "verified" : true
    }
  },
  "id" : 507287975378845697,
  "created_at" : "2014-09-03 22:04:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Furman",
      "screen_name" : "CEAChair",
      "indices" : [ 3, 12 ],
      "id_str" : "1861751828",
      "id" : 1861751828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "507284105005109248",
  "text" : "RT @CEAChair: New Report Shows that Slow Health Care Spending Growth Continued in 2013, While Near-Term Trends Remain Encouraging  http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/t8M5zX9hyo",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2014\/09\/03\/new-report-shows-slow-health-care-spending-growth-continued-2013-while-near-term-tre",
        "display_url" : "whitehouse.gov\/blog\/2014\/09\/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "507283313997123584",
    "text" : "New Report Shows that Slow Health Care Spending Growth Continued in 2013, While Near-Term Trends Remain Encouraging  http:\/\/t.co\/t8M5zX9hyo",
    "id" : 507283313997123584,
    "created_at" : "2014-09-03 21:45:41 +0000",
    "user" : {
      "name" : "Jason Furman",
      "screen_name" : "CEAChair",
      "protected" : false,
      "id_str" : "1861751828",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000628384447\/c9cb85dbdb73c8bac4f28ce4cc46f38b_normal.jpeg",
      "id" : 1861751828,
      "verified" : true
    }
  },
  "id" : 507284105005109248,
  "created_at" : "2014-09-03 21:48:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/b9zoPNriZs",
      "expanded_url" : "http:\/\/youtu.be\/02WuEbUq_6c",
      "display_url" : "youtu.be\/02WuEbUq_6c"
    } ]
  },
  "geo" : { },
  "id_str" : "507277684532330496",
  "text" : "\"Cynicism didn\u2019t put anybody on the moon. Cynicism never won a war, it never cured a disease.\" \u2014President Obama: http:\/\/t.co\/b9zoPNriZs",
  "id" : 507277684532330496,
  "created_at" : "2014-09-03 21:23:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/507260257102729216\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/T6ZDNTqFem",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bwomg_IIUAAsq4n.jpg",
      "id_str" : "507260256175804416",
      "id" : 507260256175804416,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bwomg_IIUAAsq4n.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/T6ZDNTqFem"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/LyvWgth5Rb",
      "expanded_url" : "http:\/\/go.wh.gov\/T6uoFT",
      "display_url" : "go.wh.gov\/T6uoFT"
    } ]
  },
  "geo" : { },
  "id_str" : "507260257102729216",
  "text" : "\"When ordinary people stand together, great change is possible.\" \u2014President Obama in Estonia: http:\/\/t.co\/LyvWgth5Rb http:\/\/t.co\/T6ZDNTqFem",
  "id" : 507260257102729216,
  "created_at" : "2014-09-03 20:14:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WomenSucceed",
      "indices" : [ 110, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "507251157392445440",
  "text" : "RT @vj44: Good news: New economic trends show female short-term unemployment falling to pre-recession levels. #WomenSucceed http:\/\/t.co\/jqX\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/507250530947977216\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/jqXzsKiLuw",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BwodqycIMAAy8le.jpg",
        "id_str" : "507250528964063232",
        "id" : 507250528964063232,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwodqycIMAAy8le.jpg",
        "sizes" : [ {
          "h" : 432,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 245,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 607,
          "resize" : "fit",
          "w" : 844
        }, {
          "h" : 607,
          "resize" : "fit",
          "w" : 844
        } ],
        "display_url" : "pic.twitter.com\/jqXzsKiLuw"
      } ],
      "hashtags" : [ {
        "text" : "WomenSucceed",
        "indices" : [ 100, 113 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "507250530947977216",
    "text" : "Good news: New economic trends show female short-term unemployment falling to pre-recession levels. #WomenSucceed http:\/\/t.co\/jqXzsKiLuw",
    "id" : 507250530947977216,
    "created_at" : "2014-09-03 19:35:25 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 507251157392445440,
  "created_at" : "2014-09-03 19:37:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Wilderness50",
      "indices" : [ 109, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "507225753386483712",
  "text" : "RT @Interior: Happy 50th anniversary of the Wilderness Act! RT if you plan on getting outdoors this weekend. #Wilderness50 http:\/\/t.co\/Tsrd\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/507225342449582081\/photo\/1",
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/TsrdG00s5D",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BwoGwrsCcAAOg2Z.jpg",
        "id_str" : "507225341463523328",
        "id" : 507225341463523328,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwoGwrsCcAAOg2Z.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/TsrdG00s5D"
      } ],
      "hashtags" : [ {
        "text" : "Wilderness50",
        "indices" : [ 95, 108 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "507225342449582081",
    "text" : "Happy 50th anniversary of the Wilderness Act! RT if you plan on getting outdoors this weekend. #Wilderness50 http:\/\/t.co\/TsrdG00s5D",
    "id" : 507225342449582081,
    "created_at" : "2014-09-03 17:55:20 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 507225753386483712,
  "created_at" : "2014-09-03 17:56:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/507212830236753920\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/ImGSsjrjHj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bwn7YZyIEAI81Hx.jpg",
      "id_str" : "507212829712453634",
      "id" : 507212829712453634,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bwn7YZyIEAI81Hx.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/ImGSsjrjHj"
    } ],
    "hashtags" : [ {
      "text" : "Wilderness50",
      "indices" : [ 104, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "507212830236753920",
  "text" : "FACT: Visitors to public lands and waters contributed more than $50 billion to local economies in 2012. #Wilderness50 http:\/\/t.co\/ImGSsjrjHj",
  "id" : 507212830236753920,
  "created_at" : "2014-09-03 17:05:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/507202456389185537\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/agngvSIygx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bwnx8isIMAAfYV6.jpg",
      "id_str" : "507202455462227968",
      "id" : 507202455462227968,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bwnx8isIMAAfYV6.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/agngvSIygx"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "507202456389185537",
  "text" : "\"The currents of history ebb and flow, but over time they flow toward freedom.\" \u2014President Obama in Estonia http:\/\/t.co\/agngvSIygx",
  "id" : 507202456389185537,
  "created_at" : "2014-09-03 16:24:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "CVS Health",
      "screen_name" : "CVSHealth",
      "indices" : [ 26, 36 ],
      "id_str" : "122473388",
      "id" : 122473388
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "507192189542490113",
  "text" : "RT @vj44: Congratulations @cvshealth on ending all tobacco sales and creating a smoking cessation campaign. Thanks for leading the way! #On\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CVS Health",
        "screen_name" : "CVSHealth",
        "indices" : [ 16, 26 ],
        "id_str" : "122473388",
        "id" : 122473388
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OneGoodReason",
        "indices" : [ 126, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "507182737145753600",
    "text" : "Congratulations @cvshealth on ending all tobacco sales and creating a smoking cessation campaign. Thanks for leading the way! #OneGoodReason",
    "id" : 507182737145753600,
    "created_at" : "2014-09-03 15:06:02 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 507192189542490113,
  "created_at" : "2014-09-03 15:43:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CVS Pharmacy",
      "screen_name" : "CVS_Extra",
      "indices" : [ 3, 13 ],
      "id_str" : "110775353",
      "id" : 110775353
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OneGoodReason",
      "indices" : [ 64, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "507188920686497792",
  "text" : "RT @CVS_Extra: Today we removed all tobacco from our stores for #OneGoodReason: you! Stand with us &amp; share why you live tobacco free http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ads.twitter.com\" rel=\"nofollow\"\u003ETwitter Ads\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CVS_Extra\/status\/507135996274552832\/photo\/1",
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/ERh1httUOk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bwis7QLCcAEUS75.png",
        "id_str" : "506845092032704513",
        "id" : 506845092032704513,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bwis7QLCcAEUS75.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/ERh1httUOk"
      } ],
      "hashtags" : [ {
        "text" : "OneGoodReason",
        "indices" : [ 49, 63 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "507135996274552832",
    "text" : "Today we removed all tobacco from our stores for #OneGoodReason: you! Stand with us &amp; share why you live tobacco free http:\/\/t.co\/ERh1httUOk",
    "id" : 507135996274552832,
    "created_at" : "2014-09-03 12:00:18 +0000",
    "user" : {
      "name" : "CVS Pharmacy",
      "screen_name" : "CVS_Extra",
      "protected" : false,
      "id_str" : "110775353",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/700332233714966529\/b9iLIHtK_normal.png",
      "id" : 110775353,
      "verified" : true
    }
  },
  "id" : 507188920686497792,
  "created_at" : "2014-09-03 15:30:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "CVS Health",
      "screen_name" : "CVSHealth",
      "indices" : [ 43, 53 ],
      "id_str" : "122473388",
      "id" : 122473388
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OneGoodReason",
      "indices" : [ 110, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "507185558742126592",
  "text" : "RT @FLOTUS: Congratulations and thank you, @CVSHealth. Creating a healthier future for our next generation is #OneGoodReason to live tobacc\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CVS Health",
        "screen_name" : "CVSHealth",
        "indices" : [ 31, 41 ],
        "id_str" : "122473388",
        "id" : 122473388
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OneGoodReason",
        "indices" : [ 98, 112 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "507183013877538817",
    "text" : "Congratulations and thank you, @CVSHealth. Creating a healthier future for our next generation is #OneGoodReason to live tobacco free. \u2013mo",
    "id" : 507183013877538817,
    "created_at" : "2014-09-03 15:07:08 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 507185558742126592,
  "created_at" : "2014-09-03 15:17:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "CVS Health",
      "screen_name" : "CVSHealth",
      "indices" : [ 21, 31 ],
      "id_str" : "122473388",
      "id" : 122473388
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "507183281834831872",
  "text" : "RT @PressSec: Today, @CVSHealth stops the sale of tobacco products, improving the health and lives of millions of Americans. http:\/\/t.co\/Yw\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CVS Health",
        "screen_name" : "CVSHealth",
        "indices" : [ 7, 17 ],
        "id_str" : "122473388",
        "id" : 122473388
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PressSec\/status\/507183249211527168\/photo\/1",
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/YwsCu2STed",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BwngejVIcAAUhZi.png",
        "id_str" : "507183248540463104",
        "id" : 507183248540463104,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwngejVIcAAUhZi.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 141,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 248,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 423,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 436,
          "resize" : "fit",
          "w" : 1055
        } ],
        "display_url" : "pic.twitter.com\/YwsCu2STed"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "507183249211527168",
    "text" : "Today, @CVSHealth stops the sale of tobacco products, improving the health and lives of millions of Americans. http:\/\/t.co\/YwsCu2STed",
    "id" : 507183249211527168,
    "created_at" : "2014-09-03 15:08:04 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 507183281834831872,
  "created_at" : "2014-09-03 15:08:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "507177567259213824",
  "text" : "\"The prayers of the American people are with the family of a devoted and courageous journalist, Steven Sotloff.\" \u2014President Obama",
  "id" : 507177567259213824,
  "created_at" : "2014-09-03 14:45:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/b4tqL36eMn",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "507159165857722368",
  "text" : "\"The currents of history ebb and flow, but over time they flow toward freedom.\" \u2014President Obama in Estonia: http:\/\/t.co\/b4tqL36eMn",
  "id" : 507159165857722368,
  "created_at" : "2014-09-03 13:32:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "507158658963496961",
  "text" : "\"Do not give in to that cynicism. Do not lose the idealism and optimism that is at the root of all great change.\" \u2014President Obama",
  "id" : 507158658963496961,
  "created_at" : "2014-09-03 13:30:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "507157499691405312",
  "text" : "\"Russia\u2019s actions in Ukraine are weakening Russia. Russia\u2019s actions in Ukraine are hurting the Russian people.\" \u2014President Obama",
  "id" : 507157499691405312,
  "created_at" : "2014-09-03 13:25:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/AGvpbNmCcC",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "507157299358867457",
  "text" : "RT @WHLive: \"We must continue to stand united against Russia\u2019s aggression in Ukraine.\" \u2014President Obama: http:\/\/t.co\/AGvpbNmCcC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/AGvpbNmCcC",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "507157263325593600",
    "text" : "\"We must continue to stand united against Russia\u2019s aggression in Ukraine.\" \u2014President Obama: http:\/\/t.co\/AGvpbNmCcC",
    "id" : 507157263325593600,
    "created_at" : "2014-09-03 13:24:48 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 507157299358867457,
  "created_at" : "2014-09-03 13:24:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "507156866615771136",
  "text" : "RT @WHLive: \"Democracies cannot truly succeed until we root out bias and prejudice, both from our institutions and our hearts.\" \u2014President \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "507156830465048576",
    "text" : "\"Democracies cannot truly succeed until we root out bias and prejudice, both from our institutions and our hearts.\" \u2014President Obama",
    "id" : 507156830465048576,
    "created_at" : "2014-09-03 13:23:05 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 507156866615771136,
  "created_at" : "2014-09-03 13:23:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "507156690295611392",
  "text" : "RT @WHLive: \"We reject the idea that people cannot live and thrive together just because they have different backgrounds.\" \u2014President Obama",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "507156667830910976",
    "text" : "\"We reject the idea that people cannot live and thrive together just because they have different backgrounds.\" \u2014President Obama",
    "id" : 507156667830910976,
    "created_at" : "2014-09-03 13:22:26 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 507156690295611392,
  "created_at" : "2014-09-03 13:22:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "507155895735037952",
  "text" : "RT @WHLive: \"The United States is working to bolster the security of our NATO allies and further increase America\u2019s military presence in Eu\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "507155866752397312",
    "text" : "\"The United States is working to bolster the security of our NATO allies and further increase America\u2019s military presence in Europe.\" \u2014Obama",
    "id" : 507155866752397312,
    "created_at" : "2014-09-03 13:19:15 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 507155895735037952,
  "created_at" : "2014-09-03 13:19:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/b4tqL36eMn",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "507155088411226112",
  "text" : "\"We will not accept Russia\u2019s occupation and illegal annexation of Crimea\u2014or any part of Ukraine.\" \u2014President Obama: http:\/\/t.co\/b4tqL36eMn",
  "id" : 507155088411226112,
  "created_at" : "2014-09-03 13:16:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "507154876598853633",
  "text" : "\"Trying to reclaim lands 'lost' in the 19th century is not the way to secure Russia\u2019s greatness in the 21st century.\" \u2014President Obama",
  "id" : 507154876598853633,
  "created_at" : "2014-09-03 13:15:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "507154340034146304",
  "text" : "RT @WHLive: \"Ukrainians have a new democratically-elected president\u2014and I look forward to welcoming President Poroshenko to the Oval Office\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "507154316533444608",
    "text" : "\"Ukrainians have a new democratically-elected president\u2014and I look forward to welcoming President Poroshenko to the Oval Office.\" \u2014Obama",
    "id" : 507154316533444608,
    "created_at" : "2014-09-03 13:13:06 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 507154340034146304,
  "created_at" : "2014-09-03 13:13:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/b4tqL36eMn",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "507154031018799105",
  "text" : "\"Borders cannot be redrawn at the barrel of a gun.\" \u2014President Obama on Russian aggression against Ukraine: http:\/\/t.co\/b4tqL36eMn",
  "id" : 507154031018799105,
  "created_at" : "2014-09-03 13:11:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "507153808355762177",
  "text" : "RT @WHLive: \"Countries are more successful when citizens are free to think for themselves.\" \u2014President Obama in Estonia",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "507153776311275521",
    "text" : "\"Countries are more successful when citizens are free to think for themselves.\" \u2014President Obama in Estonia",
    "id" : 507153776311275521,
    "created_at" : "2014-09-03 13:10:57 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 507153808355762177,
  "created_at" : "2014-09-03 13:11:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "507153467182706689",
  "text" : "\"We\u2019re not afraid of free and fair elections because true legitimacy can only come from one source\u2014and that is the people.\" \u2014President Obama",
  "id" : 507153467182706689,
  "created_at" : "2014-09-03 13:09:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "507153279462432768",
  "text" : "RT @WHLive: \"The Baltics show the world what\u2019s possible when free peoples come together for the change they seek.\" \u2014President Obama in Esto\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "507153260302852096",
    "text" : "\"The Baltics show the world what\u2019s possible when free peoples come together for the change they seek.\" \u2014President Obama in Estonia",
    "id" : 507153260302852096,
    "created_at" : "2014-09-03 13:08:54 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 507153279462432768,
  "created_at" : "2014-09-03 13:08:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/507152558532886528\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/6mV3arc1L5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BwnEkHgIIAAUGnw.png",
      "id_str" : "507152557824024576",
      "id" : 507152557824024576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwnEkHgIIAAUGnw.png",
      "sizes" : [ {
        "h" : 526,
        "resize" : "fit",
        "w" : 939
      }, {
        "h" : 190,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 336,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 526,
        "resize" : "fit",
        "w" : 939
      } ],
      "display_url" : "pic.twitter.com\/6mV3arc1L5"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/b4tqL36eMn",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "507152558532886528",
  "text" : "\"When ordinary people stand together, great change is possible.\" \u2014President Obama in Estonia: http:\/\/t.co\/b4tqL36eMn http:\/\/t.co\/6mV3arc1L5",
  "id" : 507152558532886528,
  "created_at" : "2014-09-03 13:06:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/b4tqL36eMn",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "507151033748160512",
  "text" : "Happening now: President Obama delivers remarks at Nordea Concert Hall in Estonia. Watch \u2192 http:\/\/t.co\/b4tqL36eMn",
  "id" : 507151033748160512,
  "created_at" : "2014-09-03 13:00:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 104, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "506926367469211651",
  "text" : "RT @VP: U.S. goods exports supported 7.1 million American jobs last year. The world's best products are #MadeInAmerica. http:\/\/t.co\/328KUzD\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/506922501537288192\/photo\/1",
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/328KUzDtw6",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BwjzU2nCIAAjiSC.png",
        "id_str" : "506922497661345792",
        "id" : 506922497661345792,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwjzU2nCIAAjiSC.png",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/328KUzDtw6"
      } ],
      "hashtags" : [ {
        "text" : "MadeInAmerica",
        "indices" : [ 96, 110 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "506922501537288192",
    "text" : "U.S. goods exports supported 7.1 million American jobs last year. The world's best products are #MadeInAmerica. http:\/\/t.co\/328KUzDtw6",
    "id" : 506922501537288192,
    "created_at" : "2014-09-02 21:51:57 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 506926367469211651,
  "created_at" : "2014-09-02 22:07:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/506909499282579457\/photo\/1",
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/OnkANc5S3N",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bwjln5nIEAAdsu2.jpg",
      "id_str" : "506907431721766912",
      "id" : 506907431721766912,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bwjln5nIEAAdsu2.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/OnkANc5S3N"
    } ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 83, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "506909499282579457",
  "text" : "Share the news: Total U.S. exports supported 11.3 million American jobs last year. #MadeInAmerica http:\/\/t.co\/OnkANc5S3N",
  "id" : 506909499282579457,
  "created_at" : "2014-09-02 21:00:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Penny Pritzker",
      "screen_name" : "PennyPritzker",
      "indices" : [ 3, 17 ],
      "id_str" : "308573576",
      "id" : 308573576
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JobsThruExports",
      "indices" : [ 120, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "506904783400472576",
  "text" : "RT @PennyPritzker: 11.3 million Americans wake up and go to work in jobs supported by exports. Up 1.6 million from 2009 #JobsThruExports ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PennyPritzker\/status\/506866568635371520\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/tRfJuWjI8A",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BwjAcjbCAAAHU8D.jpg",
        "id_str" : "506866554856669184",
        "id" : 506866554856669184,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwjAcjbCAAAHU8D.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 144,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 433,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 507,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 254,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/tRfJuWjI8A"
      } ],
      "hashtags" : [ {
        "text" : "JobsThruExports",
        "indices" : [ 101, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "506866568635371520",
    "text" : "11.3 million Americans wake up and go to work in jobs supported by exports. Up 1.6 million from 2009 #JobsThruExports http:\/\/t.co\/tRfJuWjI8A",
    "id" : 506866568635371520,
    "created_at" : "2014-09-02 18:09:41 +0000",
    "user" : {
      "name" : "Penny Pritzker",
      "screen_name" : "PennyPritzker",
      "protected" : false,
      "id_str" : "308573576",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000260306047\/1faea5d057983d2f15a31efc6b696ab5_normal.jpeg",
      "id" : 308573576,
      "verified" : true
    }
  },
  "id" : 506904783400472576,
  "created_at" : "2014-09-02 20:41:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/506896401432080385\/photo\/1",
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/QhQecvUaTf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BwjblyKIgAEQf4u.jpg",
      "id_str" : "506896400245096449",
      "id" : 506896400245096449,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwjblyKIgAEQf4u.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/QhQecvUaTf"
    } ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 76, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "506896401432080385",
  "text" : "U.S. exports of goods are \u2191.\nAnd they supported 7.1 million jobs last year. #MadeInAmerica http:\/\/t.co\/QhQecvUaTf",
  "id" : 506896401432080385,
  "created_at" : "2014-09-02 20:08:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "-",
      "screen_name" : "LAMayorsOffice",
      "indices" : [ 103, 118 ],
      "id_str" : "3433610303",
      "id" : 3433610303
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 54, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "506842639657074689",
  "text" : "RT @VP: 13 states, DC, and cities have taken steps to #RaiseTheWage. Check out the latest example from @LAMayorsOffice \u2192 http:\/\/t.co\/gdx2Lk\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "-",
        "screen_name" : "LAMayorsOffice",
        "indices" : [ 95, 110 ],
        "id_str" : "3433610303",
        "id" : 3433610303
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RaiseTheWage",
        "indices" : [ 46, 59 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/gdx2LkMPke",
        "expanded_url" : "http:\/\/www.lamayor.org\/raisethewagela",
        "display_url" : "lamayor.org\/raisethewagela"
      } ]
    },
    "geo" : { },
    "id_str" : "506823871199457280",
    "text" : "13 states, DC, and cities have taken steps to #RaiseTheWage. Check out the latest example from @LAMayorsOffice \u2192 http:\/\/t.co\/gdx2LkMPke",
    "id" : 506823871199457280,
    "created_at" : "2014-09-02 15:20:01 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 506842639657074689,
  "created_at" : "2014-09-02 16:34:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Miss America Org",
      "screen_name" : "MissAmericaOrg",
      "indices" : [ 3, 18 ],
      "id_str" : "100277512",
      "id" : 100277512
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 87, 98 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "STEM",
      "indices" : [ 20, 25 ]
    }, {
      "text" : "ReachHigher",
      "indices" : [ 105, 117 ]
    }, {
      "text" : "WomeninSTEM",
      "indices" : [ 122, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "506837231290843137",
  "text" : "RT @MissAmericaOrg: #STEM scholarship finalists just concluded a great conversation at @WhiteHouse about #ReachHigher and #WomeninSTEM http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 67, 78 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/MissAmericaOrg\/status\/506835201180573696\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/ghQRCnwOtG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bwij7eoIQAAReCq.jpg",
        "id_str" : "506835200308166656",
        "id" : 506835200308166656,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bwij7eoIQAAReCq.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/ghQRCnwOtG"
      } ],
      "hashtags" : [ {
        "text" : "STEM",
        "indices" : [ 0, 5 ]
      }, {
        "text" : "ReachHigher",
        "indices" : [ 85, 97 ]
      }, {
        "text" : "WomeninSTEM",
        "indices" : [ 102, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "506835201180573696",
    "text" : "#STEM scholarship finalists just concluded a great conversation at @WhiteHouse about #ReachHigher and #WomeninSTEM http:\/\/t.co\/ghQRCnwOtG",
    "id" : 506835201180573696,
    "created_at" : "2014-09-02 16:05:03 +0000",
    "user" : {
      "name" : "Miss America Org",
      "screen_name" : "MissAmericaOrg",
      "protected" : false,
      "id_str" : "100277512",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/772563466783719425\/Q-crSUza_normal.jpg",
      "id" : 100277512,
      "verified" : true
    }
  },
  "id" : 506837231290843137,
  "created_at" : "2014-09-02 16:13:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 112, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/Cb0cgwef2q",
      "expanded_url" : "http:\/\/youtu.be\/4NntdCKpPeQ",
      "display_url" : "youtu.be\/4NntdCKpPeQ"
    } ]
  },
  "geo" : { },
  "id_str" : "506815236306108417",
  "text" : "\"There is no denying a simple truth: America deserves a raise.\" \u2014President Obama\nWatch \u2192 http:\/\/t.co\/Cb0cgwef2q #RaiseTheWage",
  "id" : 506815236306108417,
  "created_at" : "2014-09-02 14:45:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/506607520916320256\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/0CEyN6wo7Z",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bwez2HuIAAAXjVq.jpg",
      "id_str" : "506571225469288448",
      "id" : 506571225469288448,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bwez2HuIAAAXjVq.jpg",
      "sizes" : [ {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/0CEyN6wo7Z"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 103, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/pz7syFtbOH",
      "expanded_url" : "http:\/\/youtu.be\/4NntdCKpPeQ",
      "display_url" : "youtu.be\/4NntdCKpPeQ"
    } ]
  },
  "geo" : { },
  "id_str" : "506607520916320256",
  "text" : "\"If you work full-time in America, you shouldn\u2019t be living in poverty.\" \u2014Obama: http:\/\/t.co\/pz7syFtbOH #RaiseTheWage http:\/\/t.co\/0CEyN6wo7Z",
  "id" : 506607520916320256,
  "created_at" : "2014-09-02 01:00:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/506525178764201985\/photo\/1",
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/ISKNYMPdPw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BweJ9w-IAAAhhsO.jpg",
      "id_str" : "506525177312968704",
      "id" : 506525177312968704,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BweJ9w-IAAAhhsO.jpg",
      "sizes" : [ {
        "h" : 713,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 237,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 713,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 418,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/ISKNYMPdPw"
    } ],
    "hashtags" : [ {
      "text" : "Laborfest2014",
      "indices" : [ 86, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "506525178764201985",
  "text" : "\u201CCynicism is a bad choice. Hope is a better choice.\" \u2014President Obama in Milwaukee at #Laborfest2014 http:\/\/t.co\/ISKNYMPdPw",
  "id" : 506525178764201985,
  "created_at" : "2014-09-01 19:33:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "506523455949664256",
  "text" : "RT @WHLive: \"There are families with health insurance who didn\u2019t have it before. There are students in college who couldn\u2019t afford it befor\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "506523399599181825",
    "text" : "\"There are families with health insurance who didn\u2019t have it before. There are students in college who couldn\u2019t afford it before.\" \u2014Obama",
    "id" : 506523399599181825,
    "created_at" : "2014-09-01 19:26:03 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 506523455949664256,
  "created_at" : "2014-09-01 19:26:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "506522563158495232",
  "text" : "RT @WHLive: \"America is the autoworker who thought she\u2019d never make another car again, and now she can\u2019t make them fast enough.\" \u2014Obama #Ma\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MadeInAmerica",
        "indices" : [ 124, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "506522273944453120",
    "text" : "\"America is the autoworker who thought she\u2019d never make another car again, and now she can\u2019t make them fast enough.\" \u2014Obama #MadeInAmerica",
    "id" : 506522273944453120,
    "created_at" : "2014-09-01 19:21:35 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 506522563158495232,
  "created_at" : "2014-09-01 19:22:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "506521884603990016",
  "text" : "\"I\u2019m asking you to believe in you, because even when our politics just ain\u2019t right, there\u2019s a whole lot that\u2019s right with America.\u201D \u2014Obama",
  "id" : 506521884603990016,
  "created_at" : "2014-09-01 19:20:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 116, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "506521343517790208",
  "text" : "\"When the rest of the country is working to raise wages, but Republicans in Congress won\u2019t, it ain\u2019t right.\" \u2014Obama #RaiseTheWage",
  "id" : 506521343517790208,
  "created_at" : "2014-09-01 19:17:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/506519970441089025\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/KA4PvjCEqS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BweFOk-IYAAgYGJ.jpg",
      "id_str" : "506519968591405056",
      "id" : 506519968591405056,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BweFOk-IYAAgYGJ.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/KA4PvjCEqS"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 93, 106 ]
    }, {
      "text" : "LaborDay",
      "indices" : [ 107, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "506519970441089025",
  "text" : "\"No one who works full-time should ever have to raise a family in poverty.\" \u2014President Obama #RaiseTheWage #LaborDay http:\/\/t.co\/KA4PvjCEqS",
  "id" : 506519970441089025,
  "created_at" : "2014-09-01 19:12:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 129, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/ccgeYlodyu",
      "expanded_url" : "http:\/\/wh.gov\/year-of-action",
      "display_url" : "wh.gov\/year-of-action"
    } ]
  },
  "geo" : { },
  "id_str" : "506519650885459968",
  "text" : "\"I acted on my own to make sure more women have the protections they need to fight for fair pay.\" \u2014Obama: http:\/\/t.co\/ccgeYlodyu #EqualPay",
  "id" : 506519650885459968,
  "created_at" : "2014-09-01 19:11:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 117, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "506518134959140864",
  "text" : "\"I want to see the woman who\u2019s worked for 40 years have enough to retire with dignity and respect.\" \u2014President Obama #OpportunityForAll",
  "id" : 506518134959140864,
  "created_at" : "2014-09-01 19:05:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/506516736985006080\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/PIyY0rNc3L",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BweCSatIAAAtLXp.jpg",
      "id_str" : "506516736020316160",
      "id" : 506516736020316160,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BweCSatIAAAtLXp.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/PIyY0rNc3L"
    } ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 92, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "506516736985006080",
  "text" : "\"America is stronger because we...helped more middle-class families afford college.\" \u2014Obama #CollegeOpportunity http:\/\/t.co\/PIyY0rNc3L",
  "id" : 506516736985006080,
  "created_at" : "2014-09-01 18:59:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/506516298780930048\/photo\/1",
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/eDT3cK9dUN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BweB44tIUAE7wB4.jpg",
      "id_str" : "506516297396801537",
      "id" : 506516297396801537,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BweB44tIUAE7wB4.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/eDT3cK9dUN"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "506516298780930048",
  "text" : "\"America is stronger because of the decisions we made to rescue our economy &amp; rebuild it on a new foundation.\" \u2014Obama http:\/\/t.co\/eDT3cK9dUN",
  "id" : 506516298780930048,
  "created_at" : "2014-09-01 18:57:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 103, 121 ]
    }, {
      "text" : "HappyLaborDay",
      "indices" : [ 122, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "506516002696626176",
  "text" : "\"I didn\u2019t run for President to double down on top-down economics...I bet on America's workers.\" \u2014Obama #OpportunityForAll #HappyLaborDay",
  "id" : 506516002696626176,
  "created_at" : "2014-09-01 18:56:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 124, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "506515342911610880",
  "text" : "\"History shows that working families can get a fair shot in this country\u2014but only if we\u2019re willing to fight for it.\" \u2014Obama #RaiseTheWage",
  "id" : 506515342911610880,
  "created_at" : "2014-09-01 18:54:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "506515271390330880",
  "text" : "RT @WHLive: \"The 40-hour workweek, overtime pay, a minimum wage, weekends like this one\u2014all that didn\u2019t happen by accident.\" \u2014Obama #RaiseT\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RaiseTheWage",
        "indices" : [ 120, 133 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "506515192008966144",
    "text" : "\"The 40-hour workweek, overtime pay, a minimum wage, weekends like this one\u2014all that didn\u2019t happen by accident.\" \u2014Obama #RaiseTheWage",
    "id" : 506515192008966144,
    "created_at" : "2014-09-01 18:53:27 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 506515271390330880,
  "created_at" : "2014-09-01 18:53:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HappyLaborDay",
      "indices" : [ 130, 144 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "506514470257315841",
  "text" : "\"Today is a day that belongs to you\u2014the working men &amp; women who make America the greatest country on Earth.\" \u2014President Obama #HappyLaborDay",
  "id" : 506514470257315841,
  "created_at" : "2014-09-01 18:50:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HappyLaborDay",
      "indices" : [ 97, 111 ]
    }, {
      "text" : "RaiseTheWage",
      "indices" : [ 112, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/b4tqL36eMn",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "506514364258877440",
  "text" : "Happening now: President Obama speaks at the Milwaukee Laborfest. Watch \u2192 http:\/\/t.co\/b4tqL36eMn #HappyLaborDay #RaiseTheWage",
  "id" : 506514364258877440,
  "created_at" : "2014-09-01 18:50:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HappyLaborDay",
      "indices" : [ 93, 107 ]
    }, {
      "text" : "RaiseTheWage",
      "indices" : [ 108, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/b4tqL36eMn",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "506512272207134720",
  "text" : "Watch President Obama speak at the Milwaukee Laborfest at 2:55pm ET \u2192 http:\/\/t.co\/b4tqL36eMn #HappyLaborDay #RaiseTheWage",
  "id" : 506512272207134720,
  "created_at" : "2014-09-01 18:41:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "indices" : [ 3, 12 ],
      "id_str" : "1604366701",
      "id" : 1604366701
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Labor",
      "indices" : [ 30, 36 ]
    }, {
      "text" : "RaiseTheWage",
      "indices" : [ 90, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/C0XDurbxY2",
      "expanded_url" : "http:\/\/cjky.it\/1tVzaax",
      "display_url" : "cjky.it\/1tVzaax"
    } ]
  },
  "geo" : { },
  "id_str" : "506442897818779648",
  "text" : "RT @LaborSec: As we celebrate #Labor Day2014, let\u2019s honor workers in a meaningful way and #RaiseTheWage: http:\/\/t.co\/C0XDurbxY2 via @courie\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Courier-Journal.com",
        "screen_name" : "courierjournal",
        "indices" : [ 118, 133 ],
        "id_str" : "7972552",
        "id" : 7972552
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Labor",
        "indices" : [ 16, 22 ]
      }, {
        "text" : "RaiseTheWage",
        "indices" : [ 76, 89 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/C0XDurbxY2",
        "expanded_url" : "http:\/\/cjky.it\/1tVzaax",
        "display_url" : "cjky.it\/1tVzaax"
      } ]
    },
    "geo" : { },
    "id_str" : "506234640706072576",
    "text" : "As we celebrate #Labor Day2014, let\u2019s honor workers in a meaningful way and #RaiseTheWage: http:\/\/t.co\/C0XDurbxY2 via @courierjournal",
    "id" : 506234640706072576,
    "created_at" : "2014-09-01 00:18:38 +0000",
    "user" : {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "protected" : false,
      "id_str" : "1604366701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744887280666611712\/eEeyFjs6_normal.jpg",
      "id" : 1604366701,
      "verified" : true
    }
  },
  "id" : 506442897818779648,
  "created_at" : "2014-09-01 14:06:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
} ]