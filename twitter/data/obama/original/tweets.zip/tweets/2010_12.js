Grailbird.data.tweets_2010_12 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20933048962908161",
  "text" : "West Wing Week: Looking back at 2010, making loud TV ads chill out, answering the mailbag http:\/\/bit.ly\/dQJu4q",
  "id" : 20933048962908161,
  "created_at" : "2010-12-31 20:03:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 16, 26 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20610409954287616",
  "text" : "2010 in Photos: @petesouza captions his 75 favorite behind-the-scenes & key shots of the year http:\/\/bit.ly\/glv1il (url fixed)",
  "id" : 20610409954287616,
  "created_at" : "2010-12-30 22:41:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 16, 26 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20606125862821888",
  "text" : "2010 in Photos: @petesouza personally captions his 75 favorite behind-the-scenes & key shots of the year http:\/\/ow.ly\/3wm4f",
  "id" : 20606125862821888,
  "created_at" : "2010-12-30 22:24:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "20144193036886016",
  "text" : "Moving behind the scenes video from DADT repeal signing, w\/ Patrick Murphy, Capt Hopkins, Melody Barnes http:\/\/ow.ly\/3vGLh",
  "id" : 20144193036886016,
  "created_at" : "2010-12-29 15:48:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19848446202613760",
  "text" : "Behind-the-scenes w\/ Kennedy Center honorees Paul McCartney, Oprah & others before celebration airs tonight http:\/\/ow.ly\/3vm9N",
  "id" : 19848446202613760,
  "created_at" : "2010-12-28 20:13:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "19415114503426048",
  "text" : "Photo of the Day: Obama family at St. Michael's Chapel at Marine Corps Base Hawaii  http:\/\/twitpic.com\/3k8d9e",
  "id" : 19415114503426048,
  "created_at" : "2010-12-27 15:31:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18855491153166336",
  "text" : "The Vice President & Dr. Biden at Walter Reed on Christmas  http:\/\/twitpic.com\/3jqfep",
  "id" : 18855491153166336,
  "created_at" : "2010-12-26 02:27:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18771236502896640",
  "text" : "Weekly Address: The President & First Lady wish you a Merry Christmas & encourage all to support the troops. Video: http:\/\/bit.ly\/gvP86T",
  "id" : 18771236502896640,
  "created_at" : "2010-12-25 20:53:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18392273549004800",
  "text" : "A Christmas Eve West Wing Week. Burn it on to a CD for stocking stuffer. Or just watch now, merrily. http:\/\/ow.ly\/3uc1o",
  "id" : 18392273549004800,
  "created_at" : "2010-12-24 19:47:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 13, 24 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 62, 71 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "18336659363860480",
  "text" : "Have a ? for @whitehouse Spokesman Robert Gibbs? *** Reply to @PressSec ***, w\/your Q & he'll answer what he can over the next half hour",
  "id" : 18336659363860480,
  "created_at" : "2010-12-24 16:06:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17987122908631040",
  "text" : "5 key lame duck achievements: Ending DADT, New START, Middle Class Tax Cuts\/UI, Food Safety, 9\/11 Health http:\/\/ow.ly\/3tLMV",
  "id" : 17987122908631040,
  "created_at" : "2010-12-23 16:57:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "indices" : [ 3, 10 ],
      "id_str" : "166252256",
      "id" : 166252256
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17981065503178752",
  "text" : "RT @Energy: We'll be using the most advanced technology to keep track of Santa's flight path. An exclusive inside look: http:\/\/go.usa.go ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "17977099981692929",
    "text" : "We'll be using the most advanced technology to keep track of Santa's flight path. An exclusive inside look: http:\/\/go.usa.gov\/r1d",
    "id" : 17977099981692929,
    "created_at" : "2010-12-23 16:17:29 +0000",
    "user" : {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "protected" : false,
      "id_str" : "166252256",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793425839694155781\/HRS6sfn4_normal.jpg",
      "id" : 166252256,
      "verified" : true
    }
  },
  "id" : 17981065503178752,
  "created_at" : "2010-12-23 16:33:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17970723666530304",
  "text" : "The President shares a toast in the Oval w\/ members of his National Security Staff who worked New START  http:\/\/twitpic.com\/3irld8",
  "id" : 17970723666530304,
  "created_at" : "2010-12-23 15:52:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17691135954649088",
  "text" : "Obama: \u201Cmost productive post-election period we\u2019ve had in decades\u2026 most productive two years we\u2019ve had in generations\u201D",
  "id" : 17691135954649088,
  "created_at" : "2010-12-22 21:21:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17689050810945537",
  "text" : "Starting soon: The President\u2019s press conference looking back at lame duck, ahead to future http:\/\/wh.gov\/live",
  "id" : 17689050810945537,
  "created_at" : "2010-12-22 21:12:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17673121100210176",
  "text" : "4:15 EST: President holds a press conference on a big week, as always watch at http:\/\/wh.gov\/live or w\/ your WH iPhone app",
  "id" : 17673121100210176,
  "created_at" : "2010-12-22 20:09:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17672755650498560",
  "text" : "RT @PressSec: Senate (finally) passes 9\/11 health bill...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "17663917937401857",
    "text" : "Senate (finally) passes 9\/11 health bill...",
    "id" : 17663917937401857,
    "created_at" : "2010-12-22 19:33:00 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 17672755650498560,
  "created_at" : "2010-12-22 20:08:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RIPDADT",
      "indices" : [ 68, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17635296673800194",
  "text" : "\"Out of Many, We Are One\" President Obama\u2019s full remarks, photos at #RIPDADT signing:    http:\/\/ow.ly\/3tgK3",
  "id" : 17635296673800194,
  "created_at" : "2010-12-22 17:39:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RIPDADT",
      "indices" : [ 46, 54 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17629958046228480",
  "text" : "A handshake & a salute to the President after #RIPDADT signing  http:\/\/twitpic.com\/3ifus2",
  "id" : 17629958046228480,
  "created_at" : "2010-12-22 17:18:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "indices" : [ 3, 18 ],
      "id_str" : "19674502",
      "id" : 19674502
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UNYouth",
      "indices" : [ 117, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17386907637915650",
  "text" : "RT @AmbassadorRice: You spoke. The UN Security Council responded. Here's what I said (using many of your words) at a #UNYouth event toda ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UNYouth",
        "indices" : [ 97, 105 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "17363981236699136",
    "text" : "You spoke. The UN Security Council responded. Here's what I said (using many of your words) at a #UNYouth event today: http:\/\/bit.ly\/dU7Bef",
    "id" : 17363981236699136,
    "created_at" : "2010-12-21 23:41:10 +0000",
    "user" : {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "protected" : false,
      "id_str" : "19674502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2245433940\/297681_10150417294436240_295915266239_10074516_1895344954_n_normal.jpg",
      "id" : 19674502,
      "verified" : true
    }
  },
  "id" : 17386907637915650,
  "created_at" : "2010-12-22 01:12:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SBA",
      "screen_name" : "SBAgov",
      "indices" : [ 3, 10 ],
      "id_str" : "153149305",
      "id" : 153149305
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NewSBAgov",
      "indices" : [ 76, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17386709347995648",
  "text" : "RT @SBAgov: New blog from SBA Administrator Karen Mills: Take a tour of the #NewSBAgov website: http:\/\/ow.ly\/3sTLc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NewSBAgov",
        "indices" : [ 64, 74 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "17385671861739520",
    "text" : "New blog from SBA Administrator Karen Mills: Take a tour of the #NewSBAgov website: http:\/\/ow.ly\/3sTLc",
    "id" : 17385671861739520,
    "created_at" : "2010-12-22 01:07:21 +0000",
    "user" : {
      "name" : "SBA",
      "screen_name" : "SBAgov",
      "protected" : false,
      "id_str" : "153149305",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/637366120236756992\/ky6enEIv_normal.png",
      "id" : 153149305,
      "verified" : true
    }
  },
  "id" : 17386709347995648,
  "created_at" : "2010-12-22 01:11:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hcr",
      "indices" : [ 46, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17346800688041984",
  "text" : "Sebelius on the WH White Board to explain new #hcr Rate Review rules making ins cos justify big rate hikes http:\/\/ow.ly\/3sQxX",
  "id" : 17346800688041984,
  "created_at" : "2010-12-21 22:32:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 34, 43 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1Q",
      "indices" : [ 87, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17299717335547904",
  "text" : "...And in case you missed it, see @PressSec give his take on Twitter & govt in today's #1Q: http:\/\/wh.gov\/firstquestion",
  "id" : 17299717335547904,
  "created_at" : "2010-12-21 19:25:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Census Bureau",
      "screen_name" : "uscensusbureau",
      "indices" : [ 28, 43 ],
      "id_str" : "23092890",
      "id" : 23092890
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17254205106429953",
  "text" : "Lots of updates coming from @uscensusbureau, follow them for everything you need to know",
  "id" : 17254205106429953,
  "created_at" : "2010-12-21 16:24:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "Mike Hunt MD",
      "screen_name" : "drmikehunt",
      "indices" : [ 82, 93 ],
      "id_str" : "152848217",
      "id" : 152848217
    }, {
      "name" : "Jules",
      "screen_name" : "Ladyrumrunner",
      "indices" : [ 94, 108 ],
      "id_str" : "20851551",
      "id" : 20851551
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1Q",
      "indices" : [ 109, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17247035509964800",
  "text" : "RT @PressSec: First Question's fireside premiere: http:\/\/wh.gov\/firstquestion cc: @drmikehunt @Ladyrumrunner #1Q",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mike Hunt MD",
        "screen_name" : "drmikehunt",
        "indices" : [ 68, 79 ],
        "id_str" : "152848217",
        "id" : 152848217
      }, {
        "name" : "Jules",
        "screen_name" : "Ladyrumrunner",
        "indices" : [ 80, 94 ],
        "id_str" : "20851551",
        "id" : 20851551
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "1Q",
        "indices" : [ 95, 98 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "17246219642339329",
    "text" : "First Question's fireside premiere: http:\/\/wh.gov\/firstquestion cc: @drmikehunt @Ladyrumrunner #1Q",
    "id" : 17246219642339329,
    "created_at" : "2010-12-21 15:53:13 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 17247035509964800,
  "created_at" : "2010-12-21 15:56:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1Q",
      "indices" : [ 88, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "17204045957566464",
  "text" : "RT @PressSec: Let's get an early start on First Question, send your questions my way w\/ #1Q",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "1Q",
        "indices" : [ 74, 77 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "17203717388378113",
    "text" : "Let's get an early start on First Question, send your questions my way w\/ #1Q",
    "id" : 17203717388378113,
    "created_at" : "2010-12-21 13:04:20 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 17204045957566464,
  "created_at" : "2010-12-21 13:05:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16977627306795008",
  "text" : "White House Staff: It Gets Better. A good one: http:\/\/bit.ly\/gx5Kc2",
  "id" : 16977627306795008,
  "created_at" : "2010-12-20 22:05:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "16204526432296960",
  "text" : "A historic vote today on Don't Ask, Don't Tell Repeal Act & a statement by President Obama: http:\/\/www.wh.gov\/Ozg",
  "id" : 16204526432296960,
  "created_at" : "2010-12-18 18:53:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15867507210457088",
  "text" : "3:50 The President signs compromise on tax cuts, unemployment benefits & jobs, watch: http:\/\/wh.gov\/live",
  "id" : 15867507210457088,
  "created_at" : "2010-12-17 20:34:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "somethingaintright",
      "indices" : [ 8, 27 ]
    }, {
      "text" : "hcr",
      "indices" : [ 112, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15823708048330753",
  "text" : "Biggest #somethingaintright of 2010. Politifact names \"Govt Run Healthcare\" lie of the year: http:\/\/ow.ly\/3qWh6 #hcr",
  "id" : 15823708048330753,
  "created_at" : "2010-12-17 17:40:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15801628628090880",
  "text" : "Happening Now: President Obama reads to local elementary students. Watch Live: www.WH.gov\/live",
  "id" : 15801628628090880,
  "created_at" : "2010-12-17 16:12:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15789853362888704",
  "text" : "Fresh West Wing Week to dunk in your morning coffee: http:\/\/ow.ly\/3qPWX",
  "id" : 15789853362888704,
  "created_at" : "2010-12-17 15:26:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15519003623555072",
  "text" : "Ag Sec Tom Vilsack is the 6th top Obama official to weigh in on our blog series for the DREAM Act: http:\/\/ow.ly\/3qty8",
  "id" : 15519003623555072,
  "created_at" : "2010-12-16 21:29:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15512760192344064",
  "text" : "The case for New START from the Joint Chiefs: \"We need START and we need it badly\" Watch:  http:\/\/ow.ly\/3qsEm",
  "id" : 15512760192344064,
  "created_at" : "2010-12-16 21:05:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15482032343744513",
  "text" : "Another new way to follow your White House: http:\/\/digg.com\/whitehouse\/submissions",
  "id" : 15482032343744513,
  "created_at" : "2010-12-16 19:02:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15183357553934336",
  "text" : "Secretary Napolitano: Honoring the Memory of Border Patrol Agent Brian A. Terry \n http:\/\/ow.ly\/3pUC1",
  "id" : 15183357553934336,
  "created_at" : "2010-12-15 23:16:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15158498455191552",
  "text" : "White House Melon Dance premiere: Elmo & WH Chef Sam Kass talk about healthy school lunches: http:\/\/ow.ly\/3pRFM",
  "id" : 15158498455191552,
  "created_at" : "2010-12-15 21:37:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. EPA",
      "screen_name" : "EPAGov",
      "indices" : [ 71, 78 ],
      "id_str" : "1604108887",
      "id" : 1604108887
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "15105211051810816",
  "text" : "Happening Now: Live chat on Enviro Justice w\/ CEQ Chair Nancy Sutley & @epagov Admin Lisa Jackson. Watch & Ask Qs: wh.gov\/live",
  "id" : 15105211051810816,
  "created_at" : "2010-12-15 18:05:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 75, 85 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "14762489166168064",
  "text" : "A look inside the meeting on Afghanistan in the Situation Room courtesy of @petesouza  http:\/\/twitpic.com\/3fxqdx",
  "id" : 14762489166168064,
  "created_at" : "2010-12-14 19:23:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "becks  \u270C\uFE0F",
      "screen_name" : "becks58",
      "indices" : [ 109, 117 ],
      "id_str" : "14104290",
      "id" : 14104290
    }, {
      "name" : "Ryan Thompson",
      "screen_name" : "BardicKnowledge",
      "indices" : [ 118, 134 ],
      "id_str" : "31266667",
      "id" : 31266667
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1Q",
      "indices" : [ 14, 17 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "14751469991370752",
  "text" : "RT @PressSec: #1Q answers now available for your perusal on START & tax cuts http:\/\/wh.gov\/firstquestion cc: @becks58 @BardicKnowledge",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "becks  \u270C\uFE0F",
        "screen_name" : "becks58",
        "indices" : [ 95, 103 ],
        "id_str" : "14104290",
        "id" : 14104290
      }, {
        "name" : "Ryan Thompson",
        "screen_name" : "BardicKnowledge",
        "indices" : [ 104, 120 ],
        "id_str" : "31266667",
        "id" : 31266667
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "1Q",
        "indices" : [ 0, 3 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "14751379255992320",
    "text" : "#1Q answers now available for your perusal on START & tax cuts http:\/\/wh.gov\/firstquestion cc: @becks58 @BardicKnowledge",
    "id" : 14751379255992320,
    "created_at" : "2010-12-14 18:39:37 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 14751469991370752,
  "created_at" : "2010-12-14 18:39:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1Q",
      "indices" : [ 82, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "14693867613851648",
  "text" : "RT @PressSec: Good morning, First Question is open\u2026 now. Send your queries my way #1Q",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "1Q",
        "indices" : [ 68, 71 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "14693380026015744",
    "text" : "Good morning, First Question is open\u2026 now. Send your queries my way #1Q",
    "id" : 14693380026015744,
    "created_at" : "2010-12-14 14:49:09 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 14693867613851648,
  "created_at" : "2010-12-14 14:51:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "14451059237855232",
  "text" : "Everything you need on healthy kids bill: Video\/ photos of Obama & First Lady, fact sheet, sample menu http:\/\/ow.ly\/3oATD",
  "id" : 14451059237855232,
  "created_at" : "2010-12-13 22:46:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "14407168455348224",
  "text" : "WH on Health Care Law: \"History & facts are on our side...2 federal judges have agreed w\/ this argument\" http:\/\/ow.ly\/3ouNN",
  "id" : 14407168455348224,
  "created_at" : "2010-12-13 19:51:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "Mike Neff",
      "screen_name" : "mneff2",
      "indices" : [ 115, 122 ],
      "id_str" : "22671783",
      "id" : 22671783
    }, {
      "name" : "PikachuWhereAreYou",
      "screen_name" : "jimmiebjr",
      "indices" : [ 123, 133 ],
      "id_str" : "17609675",
      "id" : 17609675
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1Q",
      "indices" : [ 14, 17 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "14382135737581568",
  "text" : "RT @PressSec: #1Q answers up on the healthy kids bill & what comes after tax cuts: http:\/\/wh.gov\/firstquestion cc: @mneff2 @jimmiebjr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mike Neff",
        "screen_name" : "mneff2",
        "indices" : [ 101, 108 ],
        "id_str" : "22671783",
        "id" : 22671783
      }, {
        "name" : "PikachuWhereAreYou",
        "screen_name" : "jimmiebjr",
        "indices" : [ 109, 119 ],
        "id_str" : "17609675",
        "id" : 17609675
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "1Q",
        "indices" : [ 0, 3 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "14382052900077569",
    "text" : "#1Q answers up on the healthy kids bill & what comes after tax cuts: http:\/\/wh.gov\/firstquestion cc: @mneff2 @jimmiebjr",
    "id" : 14382052900077569,
    "created_at" : "2010-12-13 18:12:03 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 14382135737581568,
  "created_at" : "2010-12-13 18:12:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Neff",
      "screen_name" : "mneff2",
      "indices" : [ 101, 108 ],
      "id_str" : "22671783",
      "id" : 22671783
    }, {
      "name" : "PikachuWhereAreYou",
      "screen_name" : "jimmiebjr",
      "indices" : [ 109, 119 ],
      "id_str" : "17609675",
      "id" : 17609675
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1Q",
      "indices" : [ 0, 3 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "14382058444955648",
  "text" : "#1Q answers up on the healthy kids bill & what comes after tax cuts: http:\/\/wh.gov\/firstquestion cc: @mneff2 @jimmiebjr",
  "id" : 14382058444955648,
  "created_at" : "2010-12-13 18:12:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Drug Policy",
      "screen_name" : "ONDCP",
      "indices" : [ 3, 9 ],
      "id_str" : "15460572",
      "id" : 15460572
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "14355200303173632",
  "text" : "RT @ONDCP: Today is the last day to submit questions for the Live Recovery Roundtable http:\/\/bit.ly\/h7BRcs Watch the ONDCP\/A&E event liv ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Two O'clock",
        "screen_name" : "2pm",
        "indices" : [ 133, 137 ],
        "id_str" : "24420407",
        "id" : 24420407
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "14337879287275520",
    "text" : "Today is the last day to submit questions for the Live Recovery Roundtable http:\/\/bit.ly\/h7BRcs Watch the ONDCP\/A&E event live 12\/15 @2pm",
    "id" : 14337879287275520,
    "created_at" : "2010-12-13 15:16:31 +0000",
    "user" : {
      "name" : "U.S. Drug Policy",
      "screen_name" : "ONDCP",
      "protected" : false,
      "id_str" : "15460572",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/446652455552430080\/t6umtSs5_normal.png",
      "id" : 15460572,
      "verified" : true
    }
  },
  "id" : 14355200303173632,
  "created_at" : "2010-12-13 16:25:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1Q",
      "indices" : [ 108, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "14345781788020737",
  "text" : "RT @PressSec: President signing healthy kids bill as we tweet, let\u2019s kick off First Question. Send Qs using #1Q, I\u2019ll answer some in a bit",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "1Q",
        "indices" : [ 94, 97 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "14345307382882304",
    "text" : "President signing healthy kids bill as we tweet, let\u2019s kick off First Question. Send Qs using #1Q, I\u2019ll answer some in a bit",
    "id" : 14345307382882304,
    "created_at" : "2010-12-13 15:46:02 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 14345781788020737,
  "created_at" : "2010-12-13 15:47:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "14333119331049472",
  "text" : "10:25 President & First Lady at Healthy, Hunger-Free Kids Act signing, big step for healthy food in schools http:\/\/wh.gov\/live",
  "id" : 14333119331049472,
  "created_at" : "2010-12-13 14:57:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "13259593593397248",
  "text" : "Walk step-by-step with President Obama in West Wing Week: \"It's Alive!\" Video: http:\/\/wh.gov\/OvM",
  "id" : 13259593593397248,
  "created_at" : "2010-12-10 15:51:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12993169473929216",
  "text" : "Live: Watch the Nat\u2019l Christmas Tree Lighting w\/ the First Family. Musical performances & Obama speaks: http:\/\/bit.ly\/17Tu2K",
  "id" : 12993169473929216,
  "created_at" : "2010-12-09 22:13:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 17, 26 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "Calandra",
      "screen_name" : "2blessed2bst",
      "indices" : [ 104, 117 ],
      "id_str" : "96241379",
      "id" : 96241379
    }, {
      "name" : "Mark Killebrew",
      "screen_name" : "MKbrw",
      "indices" : [ 118, 124 ],
      "id_str" : "37270337",
      "id" : 37270337
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1Q",
      "indices" : [ 0, 3 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12922462228451329",
  "text" : "#1Q answers from @PressSec up on unemployment benefits & DC \u201Cbickering\u201D: http:\/\/wh.gov\/firstquestion cc @2blessed2bst @MKBRW",
  "id" : 12922462228451329,
  "created_at" : "2010-12-09 17:32:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1q",
      "indices" : [ 63, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12903238210682880",
  "text" : "RT @PressSec: It's that time again - what do you want to know? #1q",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "1q",
        "indices" : [ 49, 52 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "12892538948030465",
    "text" : "It's that time again - what do you want to know? #1q",
    "id" : 12892538948030465,
    "created_at" : "2010-12-09 15:33:15 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 12903238210682880,
  "created_at" : "2010-12-09 16:15:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12880718090739713",
  "text" : "White House White Board w\/ Austan Goolsbee: Tax Cuts, Unemployment Insurance & Jobs: http:\/\/wh.gov\/whiteboard",
  "id" : 12880718090739713,
  "created_at" : "2010-12-09 14:46:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12880526151000064",
  "text" : "White House White Board w\/ Austan Goolsbee: Tax Cuts, Unemployment Insurance & Jobs: wh.gov\/whiteboard",
  "id" : 12880526151000064,
  "created_at" : "2010-12-09 14:45:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12604806875062272",
  "text" : "Furman & Sperling: What the compromise means for working & middle class families, by the numbers http:\/\/bit.ly\/dJSrgk",
  "id" : 12604806875062272,
  "created_at" : "2010-12-08 20:29:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 8, 17 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1Q",
      "indices" : [ 29, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12596453708922880",
  "text" : "Now up: @PressSec takes your #1Q questions on rationale behind tax\/ ui\/ jobs compromise, DADT, DREAM wh.gov\/firstquestion",
  "id" : 12596453708922880,
  "created_at" : "2010-12-08 19:56:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12578739183423488",
  "text" : "2:00 Open for Questions: 1-Year Anniversary of Open Government Directive. Live chat via FB:  http:\/\/bit.ly\/bLTH91",
  "id" : 12578739183423488,
  "created_at" : "2010-12-08 18:46:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1q",
      "indices" : [ 78, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12529335122534401",
  "text" : "RT @PressSec: Alright, let's get started - Hit me back w\/your questions using #1q",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "1q",
        "indices" : [ 64, 67 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "12529268315656192",
    "text" : "Alright, let's get started - Hit me back w\/your questions using #1q",
    "id" : 12529268315656192,
    "created_at" : "2010-12-08 15:29:45 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 12529335122534401,
  "created_at" : "2010-12-08 15:30:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12286864979402752",
  "text" : "Full video of Obama\u2019s press conference on taxes, unemployment insurance & jobs http:\/\/bit.ly\/eh1IsN",
  "id" : 12286864979402752,
  "created_at" : "2010-12-07 23:26:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12226063077740544",
  "text" : "President\u2019s press conf on tax cuts\/UI\/jobs compromise starting now. Watch: http:\/\/wh.gov\/live Discuss: http:\/\/bit.ly\/bLTH91",
  "id" : 12226063077740544,
  "created_at" : "2010-12-07 19:24:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12218455520448512",
  "text" : "2:20 EST: President Obama holds news conference on tax cuts\/ UI\/ jobs compromise, watch: http:\/\/wh.gov\/live",
  "id" : 12218455520448512,
  "created_at" : "2010-12-07 18:54:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 9, 18 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1q",
      "indices" : [ 21, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12217404180402176",
  "text" : "Video of @PressSec's #1q answers: http:\/\/wh.gov\/1q - Don't miss President Obama's news conference @ 220pm @ wh.gov\/live",
  "id" : 12217404180402176,
  "created_at" : "2010-12-07 18:50:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12185278768746496",
  "text" : "Fact sheet on Tax cuts\/ UI\/ Jobs compromise: http:\/\/bit.ly\/fPkowh Video of Obama remarks last night: http:\/\/bit.ly\/ihuCPI",
  "id" : 12185278768746496,
  "created_at" : "2010-12-07 16:42:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FluGov",
      "screen_name" : "FluGov",
      "indices" : [ 66, 73 ],
      "id_str" : "44777959",
      "id" : 44777959
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12177784143093760",
  "text" : "Good way to recognize National Influenza Vaccination Week: follow @flugov",
  "id" : 12177784143093760,
  "created_at" : "2010-12-07 16:13:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1q",
      "indices" : [ 79, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "12169360047087616",
  "text" : "RT @PressSec: Hope everyone is having a great Tuesday - let's get started with #1q ... what do you want to know?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "1q",
        "indices" : [ 65, 68 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "12164791946706945",
    "text" : "Hope everyone is having a great Tuesday - let's get started with #1q ... what do you want to know?",
    "id" : 12164791946706945,
    "created_at" : "2010-12-07 15:21:27 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 12169360047087616,
  "created_at" : "2010-12-07 15:39:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11914540228804610",
  "text" : "6:10 EST: Obama speaks on tax cuts & unemployment insurance, watch: http:\/\/wh.gov\/live",
  "id" : 11914540228804610,
  "created_at" : "2010-12-06 22:47:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HCR",
      "indices" : [ 0, 4 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11859545504612352",
  "text" : "#HCR Director Nancy-Ann DeParle on how HCR empowered states to get premiums under control- like this 1: http:\/\/bit.ly\/dNMPU4",
  "id" : 11859545504612352,
  "created_at" : "2010-12-06 19:08:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11830600574967808",
  "text" : "Starting soon: Obama in NC on economy & America\u2019s new \u201CSputnik moment\u201D http:\/\/wh.gov\/live",
  "id" : 11830600574967808,
  "created_at" : "2010-12-06 17:13:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USTreasuryDept",
      "screen_name" : "USTreasuryDept",
      "indices" : [ 3, 18 ],
      "id_str" : "2484739350",
      "id" : 2484739350
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "treasury",
      "indices" : [ 88, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11790678732308480",
  "text" : "RT @USTreasuryDept: Catch a sneak peak of the new Treasury.gov: http:\/\/www.Treasury.gov #treasury",
  "id" : 11790678732308480,
  "created_at" : "2010-12-06 14:34:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USAID",
      "screen_name" : "USAID",
      "indices" : [ 3, 9 ],
      "id_str" : "36683668",
      "id" : 36683668
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10840052686913536",
  "text" : "RT @USAID: Nancy Lindborg, AA for Bureau of Democracy, Conflict & Humanitarian Assistance on Israel Fires http:\/\/go.usa.gov\/18v #caramel ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "caramelfire",
        "indices" : [ 117, 129 ]
      }, {
        "text" : "israel",
        "indices" : [ 130, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "10838300046655488",
    "text" : "Nancy Lindborg, AA for Bureau of Democracy, Conflict & Humanitarian Assistance on Israel Fires http:\/\/go.usa.gov\/18v #caramelfire #israel",
    "id" : 10838300046655488,
    "created_at" : "2010-12-03 23:30:26 +0000",
    "user" : {
      "name" : "USAID",
      "screen_name" : "USAID",
      "protected" : false,
      "id_str" : "36683668",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/717410574523564032\/ExeUofTG_normal.jpg",
      "id" : 36683668,
      "verified" : true
    }
  },
  "id" : 10840052686913536,
  "created_at" : "2010-12-03 23:37:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10820663111585792",
  "text" : "10 Reasons We Need The DREAM Act (#1: Like Ginkgo Biloba, It\u2019ll Make Us Smarter\u2026) http:\/\/bit.ly\/elNdOj",
  "id" : 10820663111585792,
  "created_at" : "2010-12-03 22:20:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10755640569896960",
  "text" : "Starting soon: President Obama speaks to the troops in surprise visit to Afghanistan, watch: http:\/\/wh.gov\/live",
  "id" : 10755640569896960,
  "created_at" : "2010-12-03 18:01:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MCSCS",
      "screen_name" : "ONsafety",
      "indices" : [ 3, 12 ],
      "id_str" : "2829887786",
      "id" : 2829887786
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10742217182289920",
  "text" : "RT @OnSafety: What will the Consumer Product Safety Information Database coming next year mean for you? A lot! Read here: http:\/\/ht.ly\/3 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "opengov",
        "indices" : [ 127, 135 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "10740371432677376",
    "text" : "What will the Consumer Product Safety Information Database coming next year mean for you? A lot! Read here: http:\/\/ht.ly\/3jwDQ #opengov",
    "id" : 10740371432677376,
    "created_at" : "2010-12-03 17:01:18 +0000",
    "user" : {
      "name" : "U.S. CPSC",
      "screen_name" : "USCPSC",
      "protected" : false,
      "id_str" : "18990471",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798283170315636736\/_XmUEklf_normal.jpg",
      "id" : 18990471,
      "verified" : true
    }
  },
  "id" : 10742217182289920,
  "created_at" : "2010-12-03 17:08:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10730730661351424",
  "text" : "RT @PressSec: Good morning...President just landed at Bagram AFB in Afghanistan..windy and cold here and about 9 pm here",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.ubertwitter.com\/bb\/download.php\" rel=\"nofollow\"\u003E\u00DCberSocialOrig\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "10729843503136768",
    "text" : "Good morning...President just landed at Bagram AFB in Afghanistan..windy and cold here and about 9 pm here",
    "id" : 10729843503136768,
    "created_at" : "2010-12-03 16:19:28 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 10730730661351424,
  "created_at" : "2010-12-03 16:23:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10407195388674048",
  "text" : "New CEA report from Goolsbee & Co: Not extending unemployment benefits could cost 600K jobs next year http:\/\/bit.ly\/gDmqTB",
  "id" : 10407195388674048,
  "created_at" : "2010-12-02 18:57:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10392696610881536",
  "text" : "\u201CHanukkah, Oh Hanukkah\u201D: Join us at 6:35PM EST for the President\u2019s remarks & lighting of the WH menorah http:\/\/wh.gov\/live",
  "id" : 10392696610881536,
  "created_at" : "2010-12-02 17:59:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10383965470859264",
  "text" : "4.5 days & 6,078 images in 69 secs: Behind-the-scenes time-lapse of WH Christmas tree from photo office http:\/\/bit.ly\/es2ef1",
  "id" : 10383965470859264,
  "created_at" : "2010-12-02 17:25:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10061655681536000",
  "text" : "World AIDS Day: Obama video on fighting HIV\/AIDS at home & around the world, photo of red ribboned WH: http:\/\/wh.gov\/O05",
  "id" : 10061655681536000,
  "created_at" : "2010-12-01 20:04:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1q",
      "indices" : [ 53, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10053224094498817",
  "text" : "RT @PressSec: Here are today's video answers to your #1q's http:\/\/youtu.be\/CtsBxhqYcLI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "1q",
        "indices" : [ 39, 42 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "10052473360224256",
    "text" : "Here are today's video answers to your #1q's http:\/\/youtu.be\/CtsBxhqYcLI",
    "id" : 10052473360224256,
    "created_at" : "2010-12-01 19:27:51 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 10053224094498817,
  "created_at" : "2010-12-01 19:30:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The FCC",
      "screen_name" : "FCC",
      "indices" : [ 25, 29 ],
      "id_str" : "66369206",
      "id" : 66369206
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "netneutrality",
      "indices" : [ 78, 92 ]
    }, {
      "text" : "openinternet",
      "indices" : [ 98, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10014234817593344",
  "text" : "US CTO Chopra on today's @FCC action & President Obama's strong commitment to #netneutrality & an #openinternet http:\/\/bit.ly\/hfeIGj",
  "id" : 10014234817593344,
  "created_at" : "2010-12-01 16:55:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
} ]