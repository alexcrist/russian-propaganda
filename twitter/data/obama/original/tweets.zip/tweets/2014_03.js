Grailbird.data.tweets_2014_03 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/450804834191421440\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/jm157eTTEg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BkGUm5zCUAEtr_v.jpg",
      "id_str" : "450804833784582145",
      "id" : 450804833784582145,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkGUm5zCUAEtr_v.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/jm157eTTEg"
    } ],
    "hashtags" : [ {
      "text" : "GetCoveredNow",
      "indices" : [ 99, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/0lwMLeJwkK",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "450804834191421440",
  "text" : "RT so your friends know it's the last day to sign up for health insurance \u2192 http:\/\/t.co\/0lwMLeJwkK #GetCoveredNow http:\/\/t.co\/jm157eTTEg",
  "id" : 450804834191421440,
  "created_at" : "2014-04-01 01:20:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HealthCare.gov",
      "screen_name" : "HealthCareGov",
      "indices" : [ 3, 17 ],
      "id_str" : "86697288",
      "id" : 86697288
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/oZaZC4p00C",
      "expanded_url" : "http:\/\/healthcare.gov",
      "display_url" : "healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "450783165280686081",
  "text" : "RT @HealthCareGov: Record traffic continues before deadline. 2M+ visits (3pm) to http:\/\/t.co\/oZaZC4p00C and 840k+ calls (4pm), beats Part D\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCoveredNow",
        "indices" : [ 122, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 62, 84 ],
        "url" : "http:\/\/t.co\/oZaZC4p00C",
        "expanded_url" : "http:\/\/healthcare.gov",
        "display_url" : "healthcare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "450774904963883008",
    "text" : "Record traffic continues before deadline. 2M+ visits (3pm) to http:\/\/t.co\/oZaZC4p00C and 840k+ calls (4pm), beats Part D. #GetCoveredNow",
    "id" : 450774904963883008,
    "created_at" : "2014-03-31 23:21:27 +0000",
    "user" : {
      "name" : "HealthCare.gov",
      "screen_name" : "HealthCareGov",
      "protected" : false,
      "id_str" : "86697288",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/528294497105350656\/OXpX0USe_normal.png",
      "id" : 86697288,
      "verified" : true
    }
  },
  "id" : 450783165280686081,
  "created_at" : "2014-03-31 23:54:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/450776891008368640\/photo\/1",
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/XPY8ULPkG3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BkF7MaFCQAAEPHW.jpg",
      "id_str" : "450776890802847744",
      "id" : 450776890802847744,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkF7MaFCQAAEPHW.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 683
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 683
      } ],
      "display_url" : "pic.twitter.com\/XPY8ULPkG3"
    } ],
    "hashtags" : [ {
      "text" : "GetCoveredNow",
      "indices" : [ 32, 46 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/0lwMLeJwkK",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "450776891008368640",
  "text" : "DEADLINE TONIGHT: You can still #GetCoveredNow if you hurry! http:\/\/t.co\/0lwMLeJwkK http:\/\/t.co\/XPY8ULPkG3",
  "id" : 450776891008368640,
  "created_at" : "2014-03-31 23:29:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ellen DeGeneres",
      "screen_name" : "TheEllenShow",
      "indices" : [ 3, 16 ],
      "id_str" : "15846407",
      "id" : 15846407
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 42, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450770800233431040",
  "text" : "RT @TheEllenShow: Today's the last day to #GetCovered. Everyone in my house is covered. We even have a covered garage. https:\/\/t.co\/TUI5Cwt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/adobe.com\" rel=\"nofollow\"\u003EAdobe\u00AE Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 24, 35 ]
      } ],
      "urls" : [ {
        "indices" : [ 101, 124 ],
        "url" : "https:\/\/t.co\/TUI5Cwt86l",
        "expanded_url" : "https:\/\/www.healthcare.gov\/",
        "display_url" : "healthcare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "450763139462606848",
    "text" : "Today's the last day to #GetCovered. Everyone in my house is covered. We even have a covered garage. https:\/\/t.co\/TUI5Cwt86l",
    "id" : 450763139462606848,
    "created_at" : "2014-03-31 22:34:41 +0000",
    "user" : {
      "name" : "Ellen DeGeneres",
      "screen_name" : "TheEllenShow",
      "protected" : false,
      "id_str" : "15846407",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/789558314191425539\/X_imv1vL_normal.jpg",
      "id" : 15846407,
      "verified" : true
    }
  },
  "id" : 450770800233431040,
  "created_at" : "2014-03-31 23:05:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/450766680143040512\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/p14TKgMPBJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BkFx6DzCYAABM0O.jpg",
      "id_str" : "450766679979483136",
      "id" : 450766679979483136,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkFx6DzCYAABM0O.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/p14TKgMPBJ"
    } ],
    "hashtags" : [ {
      "text" : "GetCoveredNow",
      "indices" : [ 76, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/0lwMLeJwkK",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "450766680143040512",
  "text" : "Spread the word! Today's the last day to sign up for 2014 health insurance. #GetCoveredNow \u2192 http:\/\/t.co\/0lwMLeJwkK, http:\/\/t.co\/p14TKgMPBJ",
  "id" : 450766680143040512,
  "created_at" : "2014-03-31 22:48:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elizabeth Banks",
      "screen_name" : "ElizabethBanks",
      "indices" : [ 3, 18 ],
      "id_str" : "20196258",
      "id" : 20196258
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 45, 56 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/cI9IG6Xb1X",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "450760912828645376",
  "text" : "RT @ElizabethBanks: TODAY is the Last Day to #GetCovered! Go to http:\/\/t.co\/cI9IG6Xb1X now.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 25, 36 ]
      } ],
      "urls" : [ {
        "indices" : [ 44, 66 ],
        "url" : "http:\/\/t.co\/cI9IG6Xb1X",
        "expanded_url" : "http:\/\/Healthcare.gov",
        "display_url" : "Healthcare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "450672461109923840",
    "text" : "TODAY is the Last Day to #GetCovered! Go to http:\/\/t.co\/cI9IG6Xb1X now.",
    "id" : 450672461109923840,
    "created_at" : "2014-03-31 16:34:22 +0000",
    "user" : {
      "name" : "Elizabeth Banks",
      "screen_name" : "ElizabethBanks",
      "protected" : false,
      "id_str" : "20196258",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791454824306880512\/YiAb44jE_normal.jpg",
      "id" : 20196258,
      "verified" : true
    }
  },
  "id" : 450760912828645376,
  "created_at" : "2014-03-31 22:25:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/450757880744910848\/photo\/1",
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/ZrGVpbAySQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BkFp526CAAAc72l.jpg",
      "id_str" : "450757880426135552",
      "id" : 450757880426135552,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkFp526CAAAc72l.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/ZrGVpbAySQ"
    } ],
    "hashtags" : [ {
      "text" : "GetCoveredNow",
      "indices" : [ 58, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/0lwMLeJwkK",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "450757880744910848",
  "text" : "Your window to sign up for health insurance is almost up. #GetCoveredNow \u2192 http:\/\/t.co\/0lwMLeJwkK http:\/\/t.co\/ZrGVpbAySQ",
  "id" : 450757880744910848,
  "created_at" : "2014-03-31 22:13:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 22, 26 ]
    }, {
      "text" : "GetCoveredNow",
      "indices" : [ 101, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450750010595237890",
  "text" : "RT @VP: Thanks to the #ACA, millions of Americans now have access to quality affordable health care. #GetCoveredNow at http:\/\/t.co\/RQmoUBbX\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ACA",
        "indices" : [ 14, 18 ]
      }, {
        "text" : "GetCoveredNow",
        "indices" : [ 93, 107 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/RQmoUBbXYv",
        "expanded_url" : "http:\/\/Healthcare.gov",
        "display_url" : "Healthcare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "450725710106464256",
    "text" : "Thanks to the #ACA, millions of Americans now have access to quality affordable health care. #GetCoveredNow at http:\/\/t.co\/RQmoUBbXYv -- VP",
    "id" : 450725710106464256,
    "created_at" : "2014-03-31 20:05:58 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 450750010595237890,
  "created_at" : "2014-03-31 21:42:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450747019829977088",
  "text" : "RT @VP: PHOTO: The VP met w\/ Rosie the Riveters today to highlight the positive example they've set for generations of women. http:\/\/t.co\/i\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/450730809851265024\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/iPCmDsgO73",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BkFRSJMCQAEBhJ2.jpg",
        "id_str" : "450730809859653633",
        "id" : 450730809859653633,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkFRSJMCQAEBhJ2.jpg",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        } ],
        "display_url" : "pic.twitter.com\/iPCmDsgO73"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "450730809851265024",
    "text" : "PHOTO: The VP met w\/ Rosie the Riveters today to highlight the positive example they've set for generations of women. http:\/\/t.co\/iPCmDsgO73",
    "id" : 450730809851265024,
    "created_at" : "2014-03-31 20:26:14 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 450747019829977088,
  "created_at" : "2014-03-31 21:30:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCoveredNow",
      "indices" : [ 124, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/CNqHfX7XGs",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "450746645605801984",
  "text" : "RT @FLOTUS: You deserve peace of mind. If you or a loved one still needs health insurance, go to http:\/\/t.co\/CNqHfX7XGs and #GetCoveredNow.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCoveredNow",
        "indices" : [ 112, 126 ]
      } ],
      "urls" : [ {
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/CNqHfX7XGs",
        "expanded_url" : "http:\/\/Healthcare.gov",
        "display_url" : "Healthcare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "450738261179502593",
    "text" : "You deserve peace of mind. If you or a loved one still needs health insurance, go to http:\/\/t.co\/CNqHfX7XGs and #GetCoveredNow. -mo",
    "id" : 450738261179502593,
    "created_at" : "2014-03-31 20:55:50 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 450746645605801984,
  "created_at" : "2014-03-31 21:29:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pharrell Williams",
      "screen_name" : "Pharrell",
      "indices" : [ 3, 12 ],
      "id_str" : "338084918",
      "id" : 338084918
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "getcovered",
      "indices" : [ 59, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/FTWbJI9sE5",
      "expanded_url" : "http:\/\/www.healthcare.gov",
      "display_url" : "healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "450740662720528384",
  "text" : "RT @Pharrell: Stay healthy, guys. Today is the last day to #getcovered at http:\/\/t.co\/FTWbJI9sE5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "getcovered",
        "indices" : [ 45, 56 ]
      } ],
      "urls" : [ {
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/FTWbJI9sE5",
        "expanded_url" : "http:\/\/www.healthcare.gov",
        "display_url" : "healthcare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "450730455672029184",
    "text" : "Stay healthy, guys. Today is the last day to #getcovered at http:\/\/t.co\/FTWbJI9sE5",
    "id" : 450730455672029184,
    "created_at" : "2014-03-31 20:24:49 +0000",
    "user" : {
      "name" : "Pharrell Williams",
      "screen_name" : "Pharrell",
      "protected" : false,
      "id_str" : "338084918",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/777892792328531968\/aRbbZcMo_normal.jpg",
      "id" : 338084918,
      "verified" : true
    }
  },
  "id" : 450740662720528384,
  "created_at" : "2014-03-31 21:05:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rashida Jones",
      "screen_name" : "iamrashidajones",
      "indices" : [ 3, 19 ],
      "id_str" : "562381032",
      "id" : 562381032
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 66, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/ps0FfNOKEb",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "450738342687436800",
  "text" : "RT @iamrashidajones: Come on, everybody! Today\u00A0is the Last Day to #GetCovered. Go to http:\/\/t.co\/ps0FfNOKEb\u00A0now and let's make this happen!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 45, 56 ]
      } ],
      "urls" : [ {
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/ps0FfNOKEb",
        "expanded_url" : "http:\/\/Healthcare.gov",
        "display_url" : "Healthcare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "450703533755482112",
    "text" : "Come on, everybody! Today\u00A0is the Last Day to #GetCovered. Go to http:\/\/t.co\/ps0FfNOKEb\u00A0now and let's make this happen!",
    "id" : 450703533755482112,
    "created_at" : "2014-03-31 18:37:50 +0000",
    "user" : {
      "name" : "Rashida Jones",
      "screen_name" : "iamrashidajones",
      "protected" : false,
      "id_str" : "562381032",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2168179158\/RJ_normal.png",
      "id" : 562381032,
      "verified" : true
    }
  },
  "id" : 450738342687436800,
  "created_at" : "2014-03-31 20:56:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCoveredNow",
      "indices" : [ 85, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/I3bqMOVMzN",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "450731460610523136",
  "text" : "RT @FLOTUS: No bones about it: Today's the last day to sign up for health insurance. #GetCoveredNow \u2192 http:\/\/t.co\/I3bqMOVMzN, http:\/\/t.co\/h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/450716351280070656\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/hg8OiUg1hb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BkFEIiNCUAAC54e.jpg",
        "id_str" : "450716351124885504",
        "id" : 450716351124885504,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkFEIiNCUAAC54e.jpg",
        "sizes" : [ {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 733,
          "resize" : "fit",
          "w" : 1100
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/hg8OiUg1hb"
      } ],
      "hashtags" : [ {
        "text" : "GetCoveredNow",
        "indices" : [ 73, 87 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/I3bqMOVMzN",
        "expanded_url" : "http:\/\/Healthcare.gov",
        "display_url" : "Healthcare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "450716351280070656",
    "text" : "No bones about it: Today's the last day to sign up for health insurance. #GetCoveredNow \u2192 http:\/\/t.co\/I3bqMOVMzN, http:\/\/t.co\/hg8OiUg1hb",
    "id" : 450716351280070656,
    "created_at" : "2014-03-31 19:28:46 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 450731460610523136,
  "created_at" : "2014-03-31 20:28:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 13, 17 ]
    }, {
      "text" : "GetCoveredNow",
      "indices" : [ 93, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/5zeR2RQuXe",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "450717046050152448",
  "text" : "I signed the #ACA so millions could know the peace of mind that comes with health insurance. #GetCoveredNow at http:\/\/t.co\/5zeR2RQuXe. -bo",
  "id" : 450717046050152448,
  "created_at" : "2014-03-31 19:31:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/450704650384052224\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/yMTB52KFqh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BkE5fclCcAAYYXN.jpg",
      "id_str" : "450704650124029952",
      "id" : 450704650124029952,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkE5fclCcAAYYXN.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 683
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 683
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/yMTB52KFqh"
    } ],
    "hashtags" : [ {
      "text" : "BeatTheBuzzer",
      "indices" : [ 25, 39 ]
    }, {
      "text" : "GetCoveredNow",
      "indices" : [ 74, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/0lwMLeJwkK",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "450704650384052224",
  "text" : "You've still got time to #BeatTheBuzzer and sign up for health insurance. #GetCoveredNow \u2192 http:\/\/t.co\/0lwMLeJwkK http:\/\/t.co\/yMTB52KFqh",
  "id" : 450704650384052224,
  "created_at" : "2014-03-31 18:42:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCoveredNow",
      "indices" : [ 101, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/0lwMLeJwkK",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "450694097104154626",
  "text" : "Happy Opening Day! Baseball's just begun, but it's the bottom of the 9th for health care enrollment. #GetCoveredNow \u2192 http:\/\/t.co\/0lwMLeJwkK",
  "id" : 450694097104154626,
  "created_at" : "2014-03-31 18:00:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Legend",
      "screen_name" : "johnlegend",
      "indices" : [ 3, 14 ],
      "id_str" : "18228898",
      "id" : 18228898
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 41, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/lCEKAcQ83C",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "450691949180497920",
  "text" : "RT @johnlegend: TODAY is the last day to #GetCovered! Go to http:\/\/t.co\/lCEKAcQ83C now.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 25, 36 ]
      } ],
      "urls" : [ {
        "indices" : [ 44, 66 ],
        "url" : "http:\/\/t.co\/lCEKAcQ83C",
        "expanded_url" : "http:\/\/Healthcare.gov",
        "display_url" : "Healthcare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "450673244429766656",
    "text" : "TODAY is the last day to #GetCovered! Go to http:\/\/t.co\/lCEKAcQ83C now.",
    "id" : 450673244429766656,
    "created_at" : "2014-03-31 16:37:29 +0000",
    "user" : {
      "name" : "John Legend",
      "screen_name" : "johnlegend",
      "protected" : false,
      "id_str" : "18228898",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/784250136176099328\/oTcy9_4A_normal.jpg",
      "id" : 18228898,
      "verified" : true
    }
  },
  "id" : 450691949180497920,
  "created_at" : "2014-03-31 17:51:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HealthCare.gov",
      "screen_name" : "HealthCareGov",
      "indices" : [ 3, 17 ],
      "id_str" : "86697288",
      "id" : 86697288
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450687848333996032",
  "text" : "RT @HealthCareGov: Record call volume as consumers enroll in coverage\u2013nearly 3x next biggest day. 350k calls through noon to 1-800-318-2596\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCoveredNow",
        "indices" : [ 123, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "450686356105486337",
    "text" : "Record call volume as consumers enroll in coverage\u2013nearly 3x next biggest day. 350k calls through noon to 1-800-318-2596.  #GetCoveredNow",
    "id" : 450686356105486337,
    "created_at" : "2014-03-31 17:29:35 +0000",
    "user" : {
      "name" : "HealthCare.gov",
      "screen_name" : "HealthCareGov",
      "protected" : false,
      "id_str" : "86697288",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/528294497105350656\/OXpX0USe_normal.png",
      "id" : 86697288,
      "verified" : true
    }
  },
  "id" : 450687848333996032,
  "created_at" : "2014-03-31 17:35:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hannah Hart",
      "screen_name" : "harto",
      "indices" : [ 3, 9 ],
      "id_str" : "14166096",
      "id" : 14166096
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 97, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450686252363579392",
  "text" : "RT @harto: Hey! Independent cool kid who thinks they will live forever! Today is the last day to #GetCovered just in case. http:\/\/t.co\/qnPx\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 86, 97 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/qnPxGlVK1u",
        "expanded_url" : "http:\/\/healthcare.gov",
        "display_url" : "healthcare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "450679841805717505",
    "text" : "Hey! Independent cool kid who thinks they will live forever! Today is the last day to #GetCovered just in case. http:\/\/t.co\/qnPxGlVK1u",
    "id" : 450679841805717505,
    "created_at" : "2014-03-31 17:03:42 +0000",
    "user" : {
      "name" : "Hannah Hart",
      "screen_name" : "harto",
      "protected" : false,
      "id_str" : "14166096",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/733421618794373120\/K9DVozfp_normal.jpg",
      "id" : 14166096,
      "verified" : true
    }
  },
  "id" : 450686252363579392,
  "created_at" : "2014-03-31 17:29:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RainnWilson",
      "screen_name" : "rainnwilson",
      "indices" : [ 3, 15 ],
      "id_str" : "19637934",
      "id" : 19637934
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCoveredNow",
      "indices" : [ 97, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/5zeR2RQuXe",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "450675293679026176",
  "text" : "MT @RainnWilson: HEY UNINSURED PEOPLE: Today's your last chance to get health insurance in 2014. #GetCoveredNow http:\/\/t.co\/5zeR2RQuXe",
  "id" : 450675293679026176,
  "created_at" : "2014-03-31 16:45:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JARED LETO",
      "screen_name" : "JaredLeto",
      "indices" : [ 3, 13 ],
      "id_str" : "27711339",
      "id" : 27711339
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 40, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/GFo1020iWd",
      "expanded_url" : "http:\/\/healthcare.gov",
      "display_url" : "healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "450670662290800640",
  "text" : "RT @JaredLeto: TODAY is the LAST DAY to #GetCovered. Visit http:\/\/t.co\/GFo1020iWd + apply now.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 25, 36 ]
      } ],
      "urls" : [ {
        "indices" : [ 44, 66 ],
        "url" : "http:\/\/t.co\/GFo1020iWd",
        "expanded_url" : "http:\/\/healthcare.gov",
        "display_url" : "healthcare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "450645101032009728",
    "text" : "TODAY is the LAST DAY to #GetCovered. Visit http:\/\/t.co\/GFo1020iWd + apply now.",
    "id" : 450645101032009728,
    "created_at" : "2014-03-31 14:45:39 +0000",
    "user" : {
      "name" : "JARED LETO",
      "screen_name" : "JaredLeto",
      "protected" : false,
      "id_str" : "27711339",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/785997002551144448\/a8SHvWB-_normal.jpg",
      "id" : 27711339,
      "verified" : true
    }
  },
  "id" : 450670662290800640,
  "created_at" : "2014-03-31 16:27:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Silverman",
      "screen_name" : "SarahKSilverman",
      "indices" : [ 3, 19 ],
      "id_str" : "30364057",
      "id" : 30364057
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 46, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/acwF4Jl63y",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "450665710277378048",
  "text" : "RT @SarahKSilverman: TODAY is the Last Day to #GetCovered y'all. Go to http:\/\/t.co\/acwF4Jl63y now",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.whosay.com\" rel=\"nofollow\"\u003EWhoSay\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 25, 36 ]
      } ],
      "urls" : [ {
        "indices" : [ 50, 72 ],
        "url" : "http:\/\/t.co\/acwF4Jl63y",
        "expanded_url" : "http:\/\/Healthcare.gov",
        "display_url" : "Healthcare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "450663867828699136",
    "text" : "TODAY is the Last Day to #GetCovered y'all. Go to http:\/\/t.co\/acwF4Jl63y now",
    "id" : 450663867828699136,
    "created_at" : "2014-03-31 16:00:13 +0000",
    "user" : {
      "name" : "Sarah Silverman",
      "screen_name" : "SarahKSilverman",
      "protected" : false,
      "id_str" : "30364057",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/533405266658615296\/ULwCXwFs_normal.jpeg",
      "id" : 30364057,
      "verified" : true
    }
  },
  "id" : 450665710277378048,
  "created_at" : "2014-03-31 16:07:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jerome Bettis",
      "screen_name" : "JeromeBettis36",
      "indices" : [ 3, 18 ],
      "id_str" : "87518270",
      "id" : 87518270
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/GoJYicxaxy",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "450663857326153728",
  "text" : "RT @JeromeBettis36: Today is the last day to help yourself with health care!! Go to  http:\/\/t.co\/GoJYicxaxy to sign -up",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/GoJYicxaxy",
        "expanded_url" : "http:\/\/Healthcare.gov",
        "display_url" : "Healthcare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "450654629458489344",
    "text" : "Today is the last day to help yourself with health care!! Go to  http:\/\/t.co\/GoJYicxaxy to sign -up",
    "id" : 450654629458489344,
    "created_at" : "2014-03-31 15:23:31 +0000",
    "user" : {
      "name" : "Jerome Bettis",
      "screen_name" : "JeromeBettis36",
      "protected" : false,
      "id_str" : "87518270",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/661569293381947392\/yn7gizb8_normal.jpg",
      "id" : 87518270,
      "verified" : true
    }
  },
  "id" : 450663857326153728,
  "created_at" : "2014-03-31 16:00:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe Ibarra",
      "screen_name" : "TheJbarr",
      "indices" : [ 26, 35 ],
      "id_str" : "1009864220",
      "id" : 1009864220
    }, {
      "name" : "Get Covered Texas",
      "screen_name" : "GetCoveredTX",
      "indices" : [ 88, 101 ],
      "id_str" : "1667971470",
      "id" : 1667971470
    }, {
      "name" : "EnrollSA",
      "screen_name" : "EnrollSA",
      "indices" : [ 102, 111 ],
      "id_str" : "2273678444",
      "id" : 2273678444
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/TheJbarr\/status\/450638907051241472\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/yH4saGH0wG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BkD9sbICAAIW8-g.jpg",
      "id_str" : "450638902374563842",
      "id" : 450638902374563842,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkD9sbICAAIW8-g.jpg",
      "sizes" : [ {
        "h" : 764,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 764,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/yH4saGH0wG"
    } ],
    "hashtags" : [ {
      "text" : "ACASurge",
      "indices" : [ 64, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/5zeR2RQuXe",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "450660671924240384",
  "text" : "http:\/\/t.co\/5zeR2RQuXe MT @TheJbarr: Lined up at the AlamoDome! #ACASurge let's get dis @GetCoveredTX @EnrollSA http:\/\/t.co\/yH4saGH0wG",
  "id" : 450660671924240384,
  "created_at" : "2014-03-31 15:47:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joaquin Castro",
      "screen_name" : "JoaquinCastrotx",
      "indices" : [ 3, 19 ],
      "id_str" : "231510077",
      "id" : 231510077
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 48, 52 ]
    }, {
      "text" : "GetCoveredNow",
      "indices" : [ 124, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450658342772703232",
  "text" : "RT @JoaquinCastrotx: San Antonians enrolling in #ACA at the Alamodome health fair right now. My staff will be there until 8 #GetCoveredNow \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/JoaquinCastrotx\/status\/450648334340849664\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/sk2d0paqWB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BkEGRb-CAAAIJ0p.jpg",
        "id_str" : "450648334349238272",
        "id" : 450648334349238272,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkEGRb-CAAAIJ0p.jpg",
        "sizes" : [ {
          "h" : 1280,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/sk2d0paqWB"
      } ],
      "hashtags" : [ {
        "text" : "ACA",
        "indices" : [ 27, 31 ]
      }, {
        "text" : "GetCoveredNow",
        "indices" : [ 103, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "450648334340849664",
    "text" : "San Antonians enrolling in #ACA at the Alamodome health fair right now. My staff will be there until 8 #GetCoveredNow http:\/\/t.co\/sk2d0paqWB",
    "id" : 450648334340849664,
    "created_at" : "2014-03-31 14:58:30 +0000",
    "user" : {
      "name" : "Joaquin Castro",
      "screen_name" : "JoaquinCastrotx",
      "protected" : false,
      "id_str" : "231510077",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1268126174\/Joaquin_Castro_in_2008_normal.jpg",
      "id" : 231510077,
      "verified" : true
    }
  },
  "id" : 450658342772703232,
  "created_at" : "2014-03-31 15:38:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kerry washington",
      "screen_name" : "kerrywashington",
      "indices" : [ 3, 19 ],
      "id_str" : "205302299",
      "id" : 205302299
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GETCOVERED",
      "indices" : [ 46, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/rhrVQI4sQj",
      "expanded_url" : "http:\/\/1.usa.gov\/HaCX0w",
      "display_url" : "1.usa.gov\/HaCX0w"
    } ]
  },
  "geo" : { },
  "id_str" : "450653034885152769",
  "text" : "RT @kerrywashington: Today is the last day to #GETCOVERED! RT + Sign up now. http:\/\/t.co\/rhrVQI4sQj -kw's krew",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GETCOVERED",
        "indices" : [ 25, 36 ]
      } ],
      "urls" : [ {
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/rhrVQI4sQj",
        "expanded_url" : "http:\/\/1.usa.gov\/HaCX0w",
        "display_url" : "1.usa.gov\/HaCX0w"
      } ]
    },
    "geo" : { },
    "id_str" : "450651617785044992",
    "text" : "Today is the last day to #GETCOVERED! RT + Sign up now. http:\/\/t.co\/rhrVQI4sQj -kw's krew",
    "id" : 450651617785044992,
    "created_at" : "2014-03-31 15:11:33 +0000",
    "user" : {
      "name" : "kerry washington",
      "screen_name" : "kerrywashington",
      "protected" : false,
      "id_str" : "205302299",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778641930536284160\/3-m-BwGQ_normal.jpg",
      "id" : 205302299,
      "verified" : true
    }
  },
  "id" : 450653034885152769,
  "created_at" : "2014-03-31 15:17:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zach Braff",
      "screen_name" : "zachbraff",
      "indices" : [ 3, 13 ],
      "id_str" : "76997832",
      "id" : 76997832
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 40, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/npcEHj9g8V",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "450650077607264256",
  "text" : "RT @zachbraff: TODAY is the Last Day to #GetCovered! Go to http:\/\/t.co\/npcEHj9g8V now.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 25, 36 ]
      } ],
      "urls" : [ {
        "indices" : [ 44, 66 ],
        "url" : "http:\/\/t.co\/npcEHj9g8V",
        "expanded_url" : "http:\/\/Healthcare.gov",
        "display_url" : "Healthcare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "450613263516962816",
    "text" : "TODAY is the Last Day to #GetCovered! Go to http:\/\/t.co\/npcEHj9g8V now.",
    "id" : 450613263516962816,
    "created_at" : "2014-03-31 12:39:08 +0000",
    "user" : {
      "name" : "Zach Braff",
      "screen_name" : "zachbraff",
      "protected" : false,
      "id_str" : "76997832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/588958455370625025\/xm8yowKs_normal.jpg",
      "id" : 76997832,
      "verified" : true
    }
  },
  "id" : 450650077607264256,
  "created_at" : "2014-03-31 15:05:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russell Simmons",
      "screen_name" : "UncleRUSH",
      "indices" : [ 3, 13 ],
      "id_str" : "25110374",
      "id" : 25110374
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 40, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/ZFPjHSk0ac",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "450647760052948992",
  "text" : "RT @UncleRUSH: Today is the last day to #GetCovered at http:\/\/t.co\/ZFPjHSk0ac!! If you do not healthcare, go to the site NOWWWWWW!!!!!!!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 25, 36 ]
      } ],
      "urls" : [ {
        "indices" : [ 40, 62 ],
        "url" : "http:\/\/t.co\/ZFPjHSk0ac",
        "expanded_url" : "http:\/\/Healthcare.gov",
        "display_url" : "Healthcare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "450636747135655936",
    "text" : "Today is the last day to #GetCovered at http:\/\/t.co\/ZFPjHSk0ac!! If you do not healthcare, go to the site NOWWWWWW!!!!!!!",
    "id" : 450636747135655936,
    "created_at" : "2014-03-31 14:12:27 +0000",
    "user" : {
      "name" : "Russell Simmons",
      "screen_name" : "UncleRUSH",
      "protected" : false,
      "id_str" : "25110374",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/748232081008959488\/0fWqh6-F_normal.jpg",
      "id" : 25110374,
      "verified" : true
    }
  },
  "id" : 450647760052948992,
  "created_at" : "2014-03-31 14:56:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/450643710598844416\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/biJwaIVigD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BkECESlCQAE1YoU.jpg",
      "id_str" : "450643710443667457",
      "id" : 450643710443667457,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkECESlCQAE1YoU.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/biJwaIVigD"
    } ],
    "hashtags" : [ {
      "text" : "GetCoveredNow",
      "indices" : [ 67, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/qBPoIpntFR",
      "expanded_url" : "http:\/\/hc.gov\/RUXFYn",
      "display_url" : "hc.gov\/RUXFYn"
    } ]
  },
  "geo" : { },
  "id_str" : "450643710598844416",
  "text" : "DON\u2019T WAIT: It's the last day to sign up for 2014 health coverage.\n#GetCoveredNow \u2192 http:\/\/t.co\/qBPoIpntFR, http:\/\/t.co\/biJwaIVigD",
  "id" : 450643710598844416,
  "created_at" : "2014-03-31 14:40:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HealthCare.gov",
      "screen_name" : "HealthCareGov",
      "indices" : [ 3, 17 ],
      "id_str" : "86697288",
      "id" : 86697288
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/eTfU7hBJUR",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "450632124035784704",
  "text" : "RT @HealthCareGov: http:\/\/t.co\/eTfU7hBJUR serving consumers. 1.7M+ visits and 364k calls Sunday. Deadline is today for coverage this year. \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCoveredNow",
        "indices" : [ 120, 134 ]
      } ],
      "urls" : [ {
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/eTfU7hBJUR",
        "expanded_url" : "http:\/\/HealthCare.gov",
        "display_url" : "HealthCare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "450618054683394048",
    "text" : "http:\/\/t.co\/eTfU7hBJUR serving consumers. 1.7M+ visits and 364k calls Sunday. Deadline is today for coverage this year. #GetCoveredNow",
    "id" : 450618054683394048,
    "created_at" : "2014-03-31 12:58:10 +0000",
    "user" : {
      "name" : "HealthCare.gov",
      "screen_name" : "HealthCareGov",
      "protected" : false,
      "id_str" : "86697288",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/528294497105350656\/OXpX0USe_normal.png",
      "id" : 86697288,
      "verified" : true
    }
  },
  "id" : 450632124035784704,
  "created_at" : "2014-03-31 13:54:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/450630879472132096\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/XN2Lfjx1xa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BkD2ZbFCQAAIk37.jpg",
      "id_str" : "450630879363088384",
      "id" : 450630879363088384,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkD2ZbFCQAAIk37.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/XN2Lfjx1xa"
    } ],
    "hashtags" : [ {
      "text" : "GetCoveredNow",
      "indices" : [ 68, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/qBPoIpntFR",
      "expanded_url" : "http:\/\/hc.gov\/RUXFYn",
      "display_url" : "hc.gov\/RUXFYn"
    } ]
  },
  "geo" : { },
  "id_str" : "450630879472132096",
  "text" : "DEADLINE DAY: Today's the last day to sign up for health insurance. #GetCoveredNow \u2192 http:\/\/t.co\/qBPoIpntFR, http:\/\/t.co\/XN2Lfjx1xa",
  "id" : 450630879472132096,
  "created_at" : "2014-03-31 13:49:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 110, 113 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/LMXPbjfg77",
      "expanded_url" : "http:\/\/go.wh.gov\/nHripF",
      "display_url" : "go.wh.gov\/nHripF"
    } ]
  },
  "geo" : { },
  "id_str" : "450437400552939520",
  "text" : "\"3 out of 4 Americans support raising the minimum wage. They know this is the right &amp; fair thing to do.\" \u2014@VP Biden: http:\/\/t.co\/LMXPbjfg77",
  "id" : 450437400552939520,
  "created_at" : "2014-03-31 01:00:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/450333157347188736\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/UvtGNw0lUG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bj_nntJCMAEZ0Kg.jpg",
      "id_str" : "450333157078740993",
      "id" : 450333157078740993,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bj_nntJCMAEZ0Kg.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/UvtGNw0lUG"
    } ],
    "hashtags" : [ {
      "text" : "GetCoveredNow",
      "indices" : [ 48, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/KBIyVVWOj6",
      "expanded_url" : "http:\/\/hc.gov\/ZD7ioe",
      "display_url" : "hc.gov\/ZD7ioe"
    } ]
  },
  "geo" : { },
  "id_str" : "450333157347188736",
  "text" : "Need health insurance? If you raised your hand, #GetCoveredNow before tomorrow's deadline \u2192 http:\/\/t.co\/KBIyVVWOj6, http:\/\/t.co\/UvtGNw0lUG",
  "id" : 450333157347188736,
  "created_at" : "2014-03-30 18:06:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/450317536135880706\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/RGVpNuBJzy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bj_Zab8CcAElNa1.jpg",
      "id_str" : "450317535959740417",
      "id" : 450317535959740417,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bj_Zab8CcAElNa1.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/RGVpNuBJzy"
    } ],
    "hashtags" : [ {
      "text" : "GetCoveredNow",
      "indices" : [ 74, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/FOp7QjKfFk",
      "expanded_url" : "http:\/\/hc.gov\/81jaZo",
      "display_url" : "hc.gov\/81jaZo"
    } ]
  },
  "geo" : { },
  "id_str" : "450317536135880706",
  "text" : "Spread the word! Tomorrow's the last day to sign up for health insurance. #GetCoveredNow \u2192 http:\/\/t.co\/FOp7QjKfFk, http:\/\/t.co\/RGVpNuBJzy",
  "id" : 450317536135880706,
  "created_at" : "2014-03-30 17:04:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 112, 115 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/LMXPbjfg77",
      "expanded_url" : "http:\/\/go.wh.gov\/nHripF",
      "display_url" : "go.wh.gov\/nHripF"
    } ]
  },
  "geo" : { },
  "id_str" : "450301504813948928",
  "text" : "\"Raising the minimum wage would generate an additional $19 billion in\u2026income for people who need it the most.\" \u2014@VP: http:\/\/t.co\/LMXPbjfg77",
  "id" : 450301504813948928,
  "created_at" : "2014-03-30 16:00:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 56, 59 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 86, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/LMXPbjfg77",
      "expanded_url" : "http:\/\/go.wh.gov\/nHripF",
      "display_url" : "go.wh.gov\/nHripF"
    } ]
  },
  "geo" : { },
  "id_str" : "450278854028824576",
  "text" : "\"It\u2019s time to act. It\u2019s time to give America a raise.\" \u2014@VP Biden on why it's time to #RaiseTheWage: http:\/\/t.co\/LMXPbjfg77",
  "id" : 450278854028824576,
  "created_at" : "2014-03-30 14:30:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Nye",
      "screen_name" : "thescienceguy",
      "indices" : [ 54, 68 ],
      "id_str" : "3028904482",
      "id" : 3028904482
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/TheScienceGuy\/status\/449734791999414272\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/JVXD4ckvlv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bj3HaQ6CAAAABjG.jpg",
      "id_str" : "449734791835811840",
      "id" : 449734791835811840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bj3HaQ6CAAAABjG.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/JVXD4ckvlv"
    } ],
    "hashtags" : [ {
      "text" : "GetCoveredNow",
      "indices" : [ 0, 14 ]
    }, {
      "text" : "2DaysLeft",
      "indices" : [ 40, 50 ]
    }, {
      "text" : "GeeksGetCovered",
      "indices" : [ 97, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/5zeR2RQuXe",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "450011383376388096",
  "text" : "#GetCoveredNow \u2192 http:\/\/t.co\/5zeR2RQuXe #2DaysLeft MT @TheScienceGuy: Sign up for the ACA today. #GeeksGetCovered http:\/\/t.co\/JVXD4ckvlv",
  "id" : 450011383376388096,
  "created_at" : "2014-03-29 20:47:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 92, 95 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 126, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/LMXPbjfg77",
      "expanded_url" : "http:\/\/go.wh.gov\/nHripF",
      "display_url" : "go.wh.gov\/nHripF"
    } ]
  },
  "geo" : { },
  "id_str" : "449976858742771712",
  "text" : "\"There's clear data that shows fair wages generate loyalty of workers to their employers.\" \u2014@VP Biden: http:\/\/t.co\/LMXPbjfg77 #RaiseTheWage",
  "id" : 449976858742771712,
  "created_at" : "2014-03-29 18:30:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Senator Harry Reid",
      "screen_name" : "SenatorReid",
      "indices" : [ 3, 15 ],
      "id_str" : "16789970",
      "id" : 16789970
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449976008259944448",
  "text" : "RT @SenatorReid: 2 days left to enroll for ACA! Glad to see Nevadans making efforts to sign up at the Cashman Center this morning. http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SenatorReid\/status\/449971231085711361\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/caJuOfEyvn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bj6ec0_CYAAQ7qR.jpg",
        "id_str" : "449971230880194560",
        "id" : 449971230880194560,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bj6ec0_CYAAQ7qR.jpg",
        "sizes" : [ {
          "h" : 360,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 360,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/caJuOfEyvn"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "449971231085711361",
    "text" : "2 days left to enroll for ACA! Glad to see Nevadans making efforts to sign up at the Cashman Center this morning. http:\/\/t.co\/caJuOfEyvn",
    "id" : 449971231085711361,
    "created_at" : "2014-03-29 18:07:56 +0000",
    "user" : {
      "name" : "Senator Harry Reid",
      "screen_name" : "SenatorReid",
      "protected" : false,
      "id_str" : "16789970",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/628307865065816064\/OUQh91yr_normal.jpg",
      "id" : 16789970,
      "verified" : true
    }
  },
  "id" : 449976008259944448,
  "created_at" : "2014-03-29 18:26:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041A\u0430\u0442\u0435\u043D\u0430 \u041D\u0438\u043A\u043E\u043D\u0435\u043D\u043A\u043E",
      "screen_name" : "HealthCareTara",
      "indices" : [ 3, 18 ],
      "id_str" : "9448842",
      "id" : 9448842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/Y8FRO7YfZN",
      "expanded_url" : "http:\/\/bit.ly\/1h6ejIe",
      "display_url" : "bit.ly\/1h6ejIe"
    } ]
  },
  "geo" : { },
  "id_str" : "449968028974088192",
  "text" : "RT @HealthCareTara: Take it from this 30 year old and cancer survivor.  Get covered by March 31st: http:\/\/t.co\/Y8FRO7YfZN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/Y8FRO7YfZN",
        "expanded_url" : "http:\/\/bit.ly\/1h6ejIe",
        "display_url" : "bit.ly\/1h6ejIe"
      } ]
    },
    "geo" : { },
    "id_str" : "449957828753891328",
    "text" : "Take it from this 30 year old and cancer survivor.  Get covered by March 31st: http:\/\/t.co\/Y8FRO7YfZN",
    "id" : 449957828753891328,
    "created_at" : "2014-03-29 17:14:40 +0000",
    "user" : {
      "name" : "Tara McGuinness",
      "screen_name" : "Tara44",
      "protected" : false,
      "id_str" : "1601549102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600334679951081472\/O9XyKAXl_normal.jpg",
      "id" : 1601549102,
      "verified" : true
    }
  },
  "id" : 449968028974088192,
  "created_at" : "2014-03-29 17:55:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 98, 101 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 126, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/LMXPbjfg77",
      "expanded_url" : "http:\/\/go.wh.gov\/nHripF",
      "display_url" : "go.wh.gov\/nHripF"
    } ]
  },
  "geo" : { },
  "id_str" : "449946658164310017",
  "text" : "\"There's no reason in the world why an American working 40 hours a week has to live in poverty.\" \u2014@VP: http:\/\/t.co\/LMXPbjfg77 #RaiseTheWage",
  "id" : 449946658164310017,
  "created_at" : "2014-03-29 16:30:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCoveredNow",
      "indices" : [ 67, 81 ]
    }, {
      "text" : "ACASurge",
      "indices" : [ 96, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449945594833154048",
  "text" : "RT @Simas44: Lines around the building in McAllen, Texas as people #GetCoveredNow \n\nTexas-sized #ACASurge through Monday! http:\/\/t.co\/pJcu0\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Simas44\/status\/449943611921035264\/photo\/1",
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/pJcu0H3WfS",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bj6FVMYCcAAM28M.png",
        "id_str" : "449943611929423872",
        "id" : 449943611929423872,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bj6FVMYCcAAM28M.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 472,
          "resize" : "fit",
          "w" : 644
        }, {
          "h" : 440,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 249,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 472,
          "resize" : "fit",
          "w" : 644
        } ],
        "display_url" : "pic.twitter.com\/pJcu0H3WfS"
      } ],
      "hashtags" : [ {
        "text" : "GetCoveredNow",
        "indices" : [ 54, 68 ]
      }, {
        "text" : "ACASurge",
        "indices" : [ 83, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "449943611921035264",
    "text" : "Lines around the building in McAllen, Texas as people #GetCoveredNow \n\nTexas-sized #ACASurge through Monday! http:\/\/t.co\/pJcu0H3WfS",
    "id" : 449943611921035264,
    "created_at" : "2014-03-29 16:18:11 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 449945594833154048,
  "created_at" : "2014-03-29 16:26:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/449937054785216512\/photo\/1",
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/16KRpbgnVG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bj5_XgrCYAEA9Rt.jpg",
      "id_str" : "449937054667792385",
      "id" : 449937054667792385,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bj5_XgrCYAEA9Rt.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/16KRpbgnVG"
    } ],
    "hashtags" : [ {
      "text" : "2DaysLeft",
      "indices" : [ 5, 15 ]
    }, {
      "text" : "GetCoveredNow",
      "indices" : [ 61, 75 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/QVnu402Dsc",
      "expanded_url" : "http:\/\/hc.gov\/FNMKDz",
      "display_url" : "hc.gov\/FNMKDz"
    } ]
  },
  "geo" : { },
  "id_str" : "449937054785216512",
  "text" : "Just #2DaysLeft to sign up for health insurance.\nDon't wait!\n#GetCoveredNow \u2192 http:\/\/t.co\/QVnu402Dsc, http:\/\/t.co\/16KRpbgnVG",
  "id" : 449937054785216512,
  "created_at" : "2014-03-29 15:52:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GettingCoveredNow",
      "indices" : [ 30, 48 ]
    }, {
      "text" : "ACASurge",
      "indices" : [ 110, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449935097660456960",
  "text" : "RT @Simas44: Folks in Houston #GettingCoveredNow\nHundreds of grassroots events all over America this weekend.\n#ACASurge is on! http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Simas44\/status\/449933404855738368\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/IQU8DQYvJP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bj58DEGCIAAGCeL.jpg",
        "id_str" : "449933404864126976",
        "id" : 449933404864126976,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bj58DEGCIAAGCeL.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/IQU8DQYvJP"
      } ],
      "hashtags" : [ {
        "text" : "GettingCoveredNow",
        "indices" : [ 17, 35 ]
      }, {
        "text" : "ACASurge",
        "indices" : [ 97, 106 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "449933404855738368",
    "text" : "Folks in Houston #GettingCoveredNow\nHundreds of grassroots events all over America this weekend.\n#ACASurge is on! http:\/\/t.co\/IQU8DQYvJP",
    "id" : 449933404855738368,
    "created_at" : "2014-03-29 15:37:37 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 449935097660456960,
  "created_at" : "2014-03-29 15:44:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 78, 81 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 112, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/q888OItGGF",
      "expanded_url" : "http:\/\/go.wh.gov\/nHripF",
      "display_url" : "go.wh.gov\/nHripF"
    } ]
  },
  "geo" : { },
  "id_str" : "449919272996077570",
  "text" : "\"Raising the minimum wage will help hardworking people rise out of poverty.\" \u2014@VP Biden: http:\/\/t.co\/q888OItGGF #RaiseTheWage",
  "id" : 449919272996077570,
  "created_at" : "2014-03-29 14:41:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/449701918210654209\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/MRovRw3mwT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bj2pgwhCAAAieq5.jpg",
      "id_str" : "449701918051270656",
      "id" : 449701918051270656,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bj2pgwhCAAAieq5.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/MRovRw3mwT"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 74, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/Rpc53idDeJ",
      "expanded_url" : "http:\/\/go.wh.gov\/Vhr1mC",
      "display_url" : "go.wh.gov\/Vhr1mC"
    } ]
  },
  "geo" : { },
  "id_str" : "449701918210654209",
  "text" : "For the sake of our kids and our planet's future, it's time to do more to #ActOnClimate \u2192 http:\/\/t.co\/Rpc53idDeJ, http:\/\/t.co\/MRovRw3mwT",
  "id" : 449701918210654209,
  "created_at" : "2014-03-29 00:17:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/449676282406526976\/photo\/1",
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/Jgzm70jTQ0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bj2SMjnCYAA6A4T.jpg",
      "id_str" : "449676282221977600",
      "id" : 449676282221977600,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bj2SMjnCYAA6A4T.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Jgzm70jTQ0"
    } ],
    "hashtags" : [ {
      "text" : "3DaysLeft",
      "indices" : [ 5, 15 ]
    }, {
      "text" : "GetCoveredNow",
      "indices" : [ 49, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/w0UOAd3e8I",
      "expanded_url" : "http:\/\/hc.gov\/4err7T",
      "display_url" : "hc.gov\/4err7T"
    } ]
  },
  "geo" : { },
  "id_str" : "449676282406526976",
  "text" : "Just #3DaysLeft to sign up for health insurance. #GetCoveredNow \u2192 http:\/\/t.co\/w0UOAd3e8I, http:\/\/t.co\/Jgzm70jTQ0",
  "id" : 449676282406526976,
  "created_at" : "2014-03-28 22:35:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ukraine",
      "indices" : [ 81, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/HlTbCumcLl",
      "expanded_url" : "http:\/\/go.wh.gov\/LkyfPw",
      "display_url" : "go.wh.gov\/LkyfPw"
    } ]
  },
  "geo" : { },
  "id_str" : "449659118933278721",
  "text" : "Here's a readout of President Obama's call with President Putin on the crisis in #Ukraine \u2192 http:\/\/t.co\/HlTbCumcLl",
  "id" : 449659118933278721,
  "created_at" : "2014-03-28 21:27:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/iB100mCwyk",
      "expanded_url" : "http:\/\/go.wh.gov\/enaTb7",
      "display_url" : "go.wh.gov\/enaTb7"
    } ]
  },
  "geo" : { },
  "id_str" : "449648438322286592",
  "text" : "\"I signed up for a plan for $62 a month. It's the best health care I have ever had.\" \u2014Mark B., a Republican from NC: http:\/\/t.co\/iB100mCwyk",
  "id" : 449648438322286592,
  "created_at" : "2014-03-28 20:45:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "indices" : [ 3, 15 ],
      "id_str" : "15764644",
      "id" : 15764644
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "getcoverednow",
      "indices" : [ 114, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449641873297395712",
  "text" : "RT @NancyPelosi: Health care is not a partisan issue, it's a personal necessity. Read this Republican's story and #getcoverednow: http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "getcoverednow",
        "indices" : [ 97, 111 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/XTzjl7twxE",
        "expanded_url" : "http:\/\/goo.gl\/1no1Lf",
        "display_url" : "goo.gl\/1no1Lf"
      } ]
    },
    "geo" : { },
    "id_str" : "449622696083869697",
    "text" : "Health care is not a partisan issue, it's a personal necessity. Read this Republican's story and #getcoverednow: http:\/\/t.co\/XTzjl7twxE",
    "id" : 449622696083869697,
    "created_at" : "2014-03-28 19:02:58 +0000",
    "user" : {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "protected" : false,
      "id_str" : "15764644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571313158510223360\/wnSl3yXF_normal.jpeg",
      "id" : 15764644,
      "verified" : true
    }
  },
  "id" : 449641873297395712,
  "created_at" : "2014-03-28 20:19:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Viagra n tayac. Dagr",
      "screen_name" : "DagVega44",
      "indices" : [ 3, 13 ],
      "id_str" : "2785789802",
      "id" : 2785789802
    }, {
      "name" : "Governor Dan Malloy",
      "screen_name" : "GovMalloyOffice",
      "indices" : [ 16, 32 ],
      "id_str" : "234141596",
      "id" : 234141596
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 120, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449637029098573824",
  "text" : "RT @DagVega44: .@GovMalloyOffice: Americans \"understand that nobody should work 40 hours a week &amp; live in poverty.\" #RaiseTheWage, http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Governor Dan Malloy",
        "screen_name" : "GovMalloyOffice",
        "indices" : [ 1, 17 ],
        "id_str" : "234141596",
        "id" : 234141596
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RaiseTheWage",
        "indices" : [ 105, 118 ]
      } ],
      "urls" : [ {
        "indices" : [ 120, 142 ],
        "url" : "http:\/\/t.co\/LGEmJucoHU",
        "expanded_url" : "http:\/\/on.msnbc.com\/1dzMblK",
        "display_url" : "on.msnbc.com\/1dzMblK"
      } ]
    },
    "geo" : { },
    "id_str" : "449599846157414400",
    "text" : ".@GovMalloyOffice: Americans \"understand that nobody should work 40 hours a week &amp; live in poverty.\" #RaiseTheWage, http:\/\/t.co\/LGEmJucoHU",
    "id" : 449599846157414400,
    "created_at" : "2014-03-28 17:32:11 +0000",
    "user" : {
      "name" : "Rob O'Donnell",
      "screen_name" : "RODonnell44",
      "protected" : false,
      "id_str" : "1873091689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/664483086738952192\/UukL2zFT_normal.jpg",
      "id" : 1873091689,
      "verified" : true
    }
  },
  "id" : 449637029098573824,
  "created_at" : "2014-03-28 19:59:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "indices" : [ 3, 13 ],
      "id_str" : "1613223313",
      "id" : 1613223313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449630605882322944",
  "text" : "RT @Cecilia44: \"Even though I regularly tune in to conservative pundits...they're getting it wrong. Obamacare works.\" \u2014Mark from NC: http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/6sBb1zrYGN",
        "expanded_url" : "http:\/\/go.wh.gov\/enaTb7",
        "display_url" : "go.wh.gov\/enaTb7"
      } ]
    },
    "geo" : { },
    "id_str" : "449630021259657216",
    "text" : "\"Even though I regularly tune in to conservative pundits...they're getting it wrong. Obamacare works.\" \u2014Mark from NC: http:\/\/t.co\/6sBb1zrYGN",
    "id" : 449630021259657216,
    "created_at" : "2014-03-28 19:32:05 +0000",
    "user" : {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "protected" : false,
      "id_str" : "1613223313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000172019215\/ed65eda76f51213f91b33edbaa62054c_normal.jpeg",
      "id" : 1613223313,
      "verified" : true
    }
  },
  "id" : 449630605882322944,
  "created_at" : "2014-03-28 19:34:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/Jn03yQBcnk",
      "expanded_url" : "http:\/\/go.wh.gov\/enaTb7",
      "display_url" : "go.wh.gov\/enaTb7"
    } ]
  },
  "geo" : { },
  "id_str" : "449624595671568386",
  "text" : "\"I am a staunch Republican, a self-proclaimed Fox News addict\u2026and I'm here to tell you that Obamacare works.\" http:\/\/t.co\/Jn03yQBcnk",
  "id" : 449624595671568386,
  "created_at" : "2014-03-28 19:10:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 91, 95 ]
    }, {
      "text" : "GetCoveredNow",
      "indices" : [ 121, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/8BV9YC0d8K",
      "expanded_url" : "http:\/\/hc.gov\/fXn9ad",
      "display_url" : "hc.gov\/fXn9ad"
    } ]
  },
  "geo" : { },
  "id_str" : "449606916692389888",
  "text" : "Join the more than 6 million Americans who have signed up for health insurance through the #ACA \u2192 http:\/\/t.co\/8BV9YC0d8K #GetCoveredNow",
  "id" : 449606916692389888,
  "created_at" : "2014-03-28 18:00:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 26, 39 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/heZQoIfFVQ",
      "expanded_url" : "http:\/\/go.wh.gov\/Vhr1mC",
      "display_url" : "go.wh.gov\/Vhr1mC"
    } ]
  },
  "geo" : { },
  "id_str" : "449600450632105984",
  "text" : "President Obama's plan to #ActOnClimate will reduce methane emissions from landfills, coal mining, and agriculture \u2192 http:\/\/t.co\/heZQoIfFVQ",
  "id" : 449600450632105984,
  "created_at" : "2014-03-28 17:34:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/449585835990458368\/photo\/1",
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/rqRY57qvt0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bj0_74cCIAEugij.jpg",
      "id_str" : "449585835801714689",
      "id" : 449585835801714689,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bj0_74cCIAEugij.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 247,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 799,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 744,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/rqRY57qvt0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449586934068051968",
  "text" : "RT @FLOTUS: Lunch time. http:\/\/t.co\/rqRY57qvt0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/449585835990458368\/photo\/1",
        "indices" : [ 12, 34 ],
        "url" : "http:\/\/t.co\/rqRY57qvt0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bj0_74cCIAEugij.jpg",
        "id_str" : "449585835801714689",
        "id" : 449585835801714689,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bj0_74cCIAEugij.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 247,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 436,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 799,
          "resize" : "fit",
          "w" : 1100
        }, {
          "h" : 744,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/rqRY57qvt0"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "449585835990458368",
    "text" : "Lunch time. http:\/\/t.co\/rqRY57qvt0",
    "id" : 449585835990458368,
    "created_at" : "2014-03-28 16:36:30 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 449586934068051968,
  "created_at" : "2014-03-28 16:40:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/449583729770373121\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/i3OQaiHODK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bj0-BSbCAAE5nwE.jpg",
      "id_str" : "449583729652924417",
      "id" : 449583729652924417,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bj0-BSbCAAE5nwE.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/i3OQaiHODK"
    } ],
    "hashtags" : [ {
      "text" : "3DaysLeft",
      "indices" : [ 0, 10 ]
    }, {
      "text" : "GetCoveredNow",
      "indices" : [ 44, 58 ]
    }, {
      "text" : "6MillionAndCounting",
      "indices" : [ 84, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/dqoXshLfWZ",
      "expanded_url" : "http:\/\/hc.gov\/AQ4SRA",
      "display_url" : "hc.gov\/AQ4SRA"
    } ]
  },
  "geo" : { },
  "id_str" : "449583729770373121",
  "text" : "#3DaysLeft to sign up for health insurance.\n#GetCoveredNow \u2192\nhttp:\/\/t.co\/dqoXshLfWZ\n#6MillionAndCounting, http:\/\/t.co\/i3OQaiHODK",
  "id" : 449583729770373121,
  "created_at" : "2014-03-28 16:28:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Maley",
      "screen_name" : "Maley44",
      "indices" : [ 3, 11 ],
      "id_str" : "1881128166",
      "id" : 1881128166
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Michigan",
      "indices" : [ 45, 54 ]
    }, {
      "text" : "RaiseTheWage",
      "indices" : [ 117, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449577363014033408",
  "text" : "RT @Maley44: Pres. Obama heads to Ann Arbor, #Michigan next Wed to continue talking with Americans about his plan to #RaiseTheWage http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Maley44\/status\/449576809105850368\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/jDyaGHAepU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bj03udaCAAAWKR5.jpg",
        "id_str" : "449576809114238976",
        "id" : 449576809114238976,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bj03udaCAAAWKR5.jpg",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/jDyaGHAepU"
      } ],
      "hashtags" : [ {
        "text" : "Michigan",
        "indices" : [ 32, 41 ]
      }, {
        "text" : "RaiseTheWage",
        "indices" : [ 104, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "449576809105850368",
    "text" : "Pres. Obama heads to Ann Arbor, #Michigan next Wed to continue talking with Americans about his plan to #RaiseTheWage http:\/\/t.co\/jDyaGHAepU",
    "id" : 449576809105850368,
    "created_at" : "2014-03-28 16:00:38 +0000",
    "user" : {
      "name" : "Keith Maley",
      "screen_name" : "Maley44",
      "protected" : false,
      "id_str" : "1881128166",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725086933961957376\/v5WvYCOW_normal.jpg",
      "id" : 1881128166,
      "verified" : true
    }
  },
  "id" : 449577363014033408,
  "created_at" : "2014-03-28 16:02:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CNNMoney",
      "screen_name" : "CNNMoney",
      "indices" : [ 32, 41 ],
      "id_str" : "16184358",
      "id" : 16184358
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "6MillionAndCounting",
      "indices" : [ 49, 69 ]
    }, {
      "text" : "GetCoveredNow",
      "indices" : [ 126, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/IzRaUQAtpT",
      "expanded_url" : "http:\/\/cnnmon.ie\/1dwLie1",
      "display_url" : "cnnmon.ie\/1dwLie1"
    } ]
  },
  "geo" : { },
  "id_str" : "449572941336821760",
  "text" : "\"Obamacare's amazing comeback\" \u2014@CNNMoney on the #6MillionAndCounting who have signed up for coverage: http:\/\/t.co\/IzRaUQAtpT #GetCoveredNow",
  "id" : 449572941336821760,
  "created_at" : "2014-03-28 15:45:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HealthCare.gov",
      "screen_name" : "HealthCareGov",
      "indices" : [ 3, 17 ],
      "id_str" : "86697288",
      "id" : 86697288
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/eTfU7hBJUR",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "449569937104072704",
  "text" : "RT @HealthCareGov: Volume remains high as consumers check out their options. 1.5M visits to http:\/\/t.co\/eTfU7hBJUR &amp; 430k calls Thurs. 3 da\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCoveredNow",
        "indices" : [ 130, 144 ]
      } ],
      "urls" : [ {
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/eTfU7hBJUR",
        "expanded_url" : "http:\/\/HealthCare.gov",
        "display_url" : "HealthCare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "449564606491820032",
    "text" : "Volume remains high as consumers check out their options. 1.5M visits to http:\/\/t.co\/eTfU7hBJUR &amp; 430k calls Thurs. 3 days to #GetCoveredNow",
    "id" : 449564606491820032,
    "created_at" : "2014-03-28 15:12:09 +0000",
    "user" : {
      "name" : "HealthCare.gov",
      "screen_name" : "HealthCareGov",
      "protected" : false,
      "id_str" : "86697288",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/528294497105350656\/OXpX0USe_normal.png",
      "id" : 86697288,
      "verified" : true
    }
  },
  "id" : 449569937104072704,
  "created_at" : "2014-03-28 15:33:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "POPSUGAR",
      "screen_name" : "POPSUGAR",
      "indices" : [ 3, 12 ],
      "id_str" : "14833304",
      "id" : 14833304
    }, {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 30, 35 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "BEYONC\u00C9",
      "screen_name" : "Beyonce",
      "indices" : [ 58, 66 ],
      "id_str" : "31239408",
      "id" : 31239408
    }, {
      "name" : "Tyler Oakley",
      "screen_name" : "tyleroakley",
      "indices" : [ 80, 92 ],
      "id_str" : "14222536",
      "id" : 14222536
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TopThat",
      "indices" : [ 70, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/hBbieSwpxT",
      "expanded_url" : "http:\/\/popsu.gr\/34453137",
      "display_url" : "popsu.gr\/34453137"
    } ]
  },
  "geo" : { },
  "id_str" : "449560977269596160",
  "text" : "RT @POPSUGAR: Valerie Jarrett @vj44 talks health care and @Beyonce on #TopThat! @tyleroakley http:\/\/t.co\/hBbieSwpxT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Valerie Jarrett",
        "screen_name" : "vj44",
        "indices" : [ 16, 21 ],
        "id_str" : "595515713",
        "id" : 595515713
      }, {
        "name" : "BEYONC\u00C9",
        "screen_name" : "Beyonce",
        "indices" : [ 44, 52 ],
        "id_str" : "31239408",
        "id" : 31239408
      }, {
        "name" : "Tyler Oakley",
        "screen_name" : "tyleroakley",
        "indices" : [ 66, 78 ],
        "id_str" : "14222536",
        "id" : 14222536
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TopThat",
        "indices" : [ 56, 64 ]
      } ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/hBbieSwpxT",
        "expanded_url" : "http:\/\/popsu.gr\/34453137",
        "display_url" : "popsu.gr\/34453137"
      } ]
    },
    "geo" : { },
    "id_str" : "449275388124884992",
    "text" : "Valerie Jarrett @vj44 talks health care and @Beyonce on #TopThat! @tyleroakley http:\/\/t.co\/hBbieSwpxT",
    "id" : 449275388124884992,
    "created_at" : "2014-03-27 20:02:54 +0000",
    "user" : {
      "name" : "POPSUGAR",
      "screen_name" : "POPSUGAR",
      "protected" : false,
      "id_str" : "14833304",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/675041876668522496\/K-XYT0pQ_normal.png",
      "id" : 14833304,
      "verified" : true
    }
  },
  "id" : 449560977269596160,
  "created_at" : "2014-03-28 14:57:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/449552557879209984\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/3fnPLccrzh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bj0hq1uCIAAmdJZ.jpg",
      "id_str" : "449552557665296384",
      "id" : 449552557665296384,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bj0hq1uCIAAmdJZ.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/3fnPLccrzh"
    } ],
    "hashtags" : [ {
      "text" : "3DaysLeft",
      "indices" : [ 0, 10 ]
    }, {
      "text" : "GetCoveredNow",
      "indices" : [ 72, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/wdid5l0izG",
      "expanded_url" : "http:\/\/hc.gov\/Tdjv6i",
      "display_url" : "hc.gov\/Tdjv6i"
    } ]
  },
  "geo" : { },
  "id_str" : "449552557879209984",
  "text" : "#3DaysLeft: If someone you know needs health insurance, here's where to #GetCoveredNow \u2192 http:\/\/t.co\/wdid5l0izG, http:\/\/t.co\/3fnPLccrzh",
  "id" : 449552557879209984,
  "created_at" : "2014-03-28 14:24:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/449221341502136320\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/s3XE4H0N4E",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bjv0bgfCUAA2VIU.jpg",
      "id_str" : "449221341267251200",
      "id" : 449221341267251200,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bjv0bgfCUAA2VIU.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/s3XE4H0N4E"
    } ],
    "hashtags" : [ {
      "text" : "GetCoveredNow",
      "indices" : [ 56, 70 ]
    }, {
      "text" : "4DaysLeft",
      "indices" : [ 96, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/Kuq7s5di8P",
      "expanded_url" : "http:\/\/hc.gov\/9726Yc",
      "display_url" : "hc.gov\/9726Yc"
    } ]
  },
  "geo" : { },
  "id_str" : "449355251250761731",
  "text" : "Don\u2019t have health insurance? Don\u2019t wait another minute. #GetCoveredNow \u2192 http:\/\/t.co\/Kuq7s5di8P #4DaysLeft, http:\/\/t.co\/s3XE4H0N4E",
  "id" : 449355251250761731,
  "created_at" : "2014-03-28 01:20:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 1, 4 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "4DaysLeft",
      "indices" : [ 106, 116 ]
    }, {
      "text" : "GetCoveredNow",
      "indices" : [ 117, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/9ZiaHLeHlq",
      "expanded_url" : "http:\/\/bzfd.it\/1fol6xk",
      "display_url" : "bzfd.it\/1fol6xk"
    } ]
  },
  "geo" : { },
  "id_str" : "449345184535298048",
  "text" : ".@VP Biden really wants you to get covered by March 31st. Here are 7 reasons why \u2192 http:\/\/t.co\/9ZiaHLeHlq #4DaysLeft #GetCoveredNow",
  "id" : 449345184535298048,
  "created_at" : "2014-03-28 00:40:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "rachael ray",
      "screen_name" : "rachaelray",
      "indices" : [ 3, 14 ],
      "id_str" : "28164096",
      "id" : 28164096
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 69, 72 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 73, 84 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/rachaelray\/status\/449313510791847936\/photo\/1",
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/BABA9iSqZN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BjxIQdzIYAEv75G.jpg",
      "id_str" : "449313510544400385",
      "id" : 449313510544400385,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjxIQdzIYAEv75G.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/BABA9iSqZN"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 57, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449335119778562049",
  "text" : "MT @RachaelRay: I was on set today reminding everyone to #GetCovered @VP @WhiteHouse http:\/\/t.co\/BABA9iSqZN",
  "id" : 449335119778562049,
  "created_at" : "2014-03-28 00:00:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Governor Dan Malloy",
      "screen_name" : "GovMalloyOffice",
      "indices" : [ 6, 22 ],
      "id_str" : "234141596",
      "id" : 234141596
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 126, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449325120352702464",
  "text" : "FACT: @GovMalloyOffice just signed a bill to raise the min wage in CT to $10.10\u2014which will benefit more than 228,000 workers. #RaiseTheWage",
  "id" : 449325120352702464,
  "created_at" : "2014-03-27 23:20:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Governor Dan Malloy",
      "screen_name" : "GovMalloyOffice",
      "indices" : [ 1, 17 ],
      "id_str" : "234141596",
      "id" : 234141596
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 105, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449316057233510400",
  "text" : ".@GovMalloyOffice just signed a bill to raise CT's minimum wage to $10.10.\n\nRT if you agree it's time to #RaiseTheWage for all Americans.",
  "id" : 449316057233510400,
  "created_at" : "2014-03-27 22:44:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Governor Dan Malloy",
      "screen_name" : "GovMalloyOffice",
      "indices" : [ 3, 19 ],
      "id_str" : "234141596",
      "id" : 234141596
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CT",
      "indices" : [ 21, 24 ]
    }, {
      "text" : "RaiseTheWage",
      "indices" : [ 87, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449310514548842496",
  "text" : "RT @GovMalloyOffice: #CT has acted. Now Congress should answer the President's call to #RaiseTheWage for all Americans. http:\/\/t.co\/DU3Vn4z\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/GovMalloyOffice\/status\/449309471072743424\/photo\/1",
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/DU3Vn4zZXk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BjxElVnCcAAoIgD.jpg",
        "id_str" : "449309471076937728",
        "id" : 449309471076937728,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjxElVnCcAAoIgD.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/DU3Vn4zZXk"
      } ],
      "hashtags" : [ {
        "text" : "CT",
        "indices" : [ 0, 3 ]
      }, {
        "text" : "RaiseTheWage",
        "indices" : [ 66, 79 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "449309471072743424",
    "text" : "#CT has acted. Now Congress should answer the President's call to #RaiseTheWage for all Americans. http:\/\/t.co\/DU3Vn4zZXk",
    "id" : 449309471072743424,
    "created_at" : "2014-03-27 22:18:20 +0000",
    "user" : {
      "name" : "Governor Dan Malloy",
      "screen_name" : "GovMalloyOffice",
      "protected" : false,
      "id_str" : "234141596",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738519424223858688\/_0xQvvKS_normal.jpg",
      "id" : 234141596,
      "verified" : true
    }
  },
  "id" : 449310514548842496,
  "created_at" : "2014-03-27 22:22:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "6MillionAndCounting",
      "indices" : [ 33, 53 ]
    }, {
      "text" : "GeeksGetCovered",
      "indices" : [ 88, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/S2nTpbrgLN",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2014\/03\/27\/geeksgetcovered-health-care-geek-gets-coverage-her-own",
      "display_url" : "whitehouse.gov\/blog\/2014\/03\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "449304680355872768",
  "text" : "RT @whitehouseostp: Gail is 1 of #6MillionAndCounting who just got covered \u2014 here's her #GeeksGetCovered story! http:\/\/t.co\/S2nTpbrgLN  htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/449257285227778048\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/PSVlZVsLrx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BjwVHtVCUAA9vyH.jpg",
        "id_str" : "449257285001302016",
        "id" : 449257285001302016,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjwVHtVCUAA9vyH.jpg",
        "sizes" : [ {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/PSVlZVsLrx"
      } ],
      "hashtags" : [ {
        "text" : "6MillionAndCounting",
        "indices" : [ 13, 33 ]
      }, {
        "text" : "GeeksGetCovered",
        "indices" : [ 68, 84 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/S2nTpbrgLN",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2014\/03\/27\/geeksgetcovered-health-care-geek-gets-coverage-her-own",
        "display_url" : "whitehouse.gov\/blog\/2014\/03\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "449294806704201729",
    "text" : "Gail is 1 of #6MillionAndCounting who just got covered \u2014 here's her #GeeksGetCovered story! http:\/\/t.co\/S2nTpbrgLN  http:\/\/t.co\/PSVlZVsLrx",
    "id" : 449294806704201729,
    "created_at" : "2014-03-27 21:20:04 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 449304680355872768,
  "created_at" : "2014-03-27 21:59:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pope Francis",
      "screen_name" : "Pontifex",
      "indices" : [ 103, 112 ],
      "id_str" : "500704345",
      "id" : 500704345
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/449298725064540160\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/FfPjHi9cN9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bjw6z1BCYAADjgK.jpg",
      "id_str" : "449298724909375488",
      "id" : 449298724909375488,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bjw6z1BCYAADjgK.jpg",
      "sizes" : [ {
        "h" : 891,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 829,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 275,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 486,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/FfPjHi9cN9"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449298725064540160",
  "text" : "\"Empathy, the ability to stand in somebody else\u2019s shoes...that's critical.\" \u2014Obama on his meeting with @Pontifex: http:\/\/t.co\/FfPjHi9cN9",
  "id" : 449298725064540160,
  "created_at" : "2014-03-27 21:35:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pope Francis",
      "screen_name" : "Pontifex",
      "indices" : [ 59, 68 ],
      "id_str" : "500704345",
      "id" : 500704345
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/w3GQCnxAXL",
      "expanded_url" : "http:\/\/youtu.be\/vTzIJL1EHKs",
      "display_url" : "youtu.be\/vTzIJL1EHKs"
    } ]
  },
  "geo" : { },
  "id_str" : "449287527678345217",
  "text" : "Go behind the scenes with President Obama as he meets with @Pontifex in Vatican City and stops by the Colosseum \u2192 http:\/\/t.co\/w3GQCnxAXL",
  "id" : 449287527678345217,
  "created_at" : "2014-03-27 20:51:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kathleen Sebelius",
      "screen_name" : "Sebelius",
      "indices" : [ 3, 12 ],
      "id_str" : "2556859698",
      "id" : 2556859698
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCoveredNow",
      "indices" : [ 105, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449274620655697922",
  "text" : "RT @Sebelius: 6 million isn\u2019t just a number\u2014this is about changing lives and health care for the better. #GetCoveredNow http:\/\/t.co\/tV6bLTn\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Sebelius\/status\/449255351838179328\/photo\/1",
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/tV6bLTnYzC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BjwTXLBCYAAf8yR.png",
        "id_str" : "449255351645265920",
        "id" : 449255351645265920,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjwTXLBCYAAf8yR.png",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/tV6bLTnYzC"
      } ],
      "hashtags" : [ {
        "text" : "GetCoveredNow",
        "indices" : [ 91, 105 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "449255351838179328",
    "text" : "6 million isn\u2019t just a number\u2014this is about changing lives and health care for the better. #GetCoveredNow http:\/\/t.co\/tV6bLTnYzC",
    "id" : 449255351838179328,
    "created_at" : "2014-03-27 18:43:17 +0000",
    "user" : {
      "name" : "Kathleen Sebelius",
      "screen_name" : "SecSebelius",
      "protected" : false,
      "id_str" : "1023020557",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000082519123\/6450b6c1fe4ad3432aacf01adf22ac37_normal.png",
      "id" : 1023020557,
      "verified" : true
    }
  },
  "id" : 449274620655697922,
  "created_at" : "2014-03-27 19:59:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/449257285227778048\/photo\/1",
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/satR5STZgU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BjwVHtVCUAA9vyH.jpg",
      "id_str" : "449257285001302016",
      "id" : 449257285001302016,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjwVHtVCUAA9vyH.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/satR5STZgU"
    } ],
    "hashtags" : [ {
      "text" : "4DaysLeft",
      "indices" : [ 0, 10 ]
    }, {
      "text" : "GetCoveredNow",
      "indices" : [ 35, 49 ]
    }, {
      "text" : "6MillionAndCounting",
      "indices" : [ 75, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/0fstLgRCLC",
      "expanded_url" : "http:\/\/hc.gov\/6sbuSw",
      "display_url" : "hc.gov\/6sbuSw"
    } ]
  },
  "geo" : { },
  "id_str" : "449257285227778048",
  "text" : "#4DaysLeft to get health coverage.\n#GetCoveredNow \u2192 http:\/\/t.co\/0fstLgRCLC\n#6MillionAndCounting, http:\/\/t.co\/satR5STZgU",
  "id" : 449257285227778048,
  "created_at" : "2014-03-27 18:50:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/449253977897459712\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/1Zn5kmhUw4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BjwSHM4CAAE1J9O.jpg",
      "id_str" : "449253977754828801",
      "id" : 449253977754828801,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjwSHM4CAAE1J9O.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/1Zn5kmhUw4"
    } ],
    "hashtags" : [ {
      "text" : "GetCoveredNow",
      "indices" : [ 78, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/0fstLgRCLC",
      "expanded_url" : "http:\/\/hc.gov\/6sbuSw",
      "display_url" : "hc.gov\/6sbuSw"
    } ]
  },
  "geo" : { },
  "id_str" : "449253977897459712",
  "text" : "BREAKING: More than 6 million people have signed up for private health plans. #GetCoveredNow: http:\/\/t.co\/0fstLgRCLC http:\/\/t.co\/1Zn5kmhUw4",
  "id" : 449253977897459712,
  "created_at" : "2014-03-27 18:37:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 45, 48 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "4DaysLeft",
      "indices" : [ 91, 101 ]
    }, {
      "text" : "GetCoveredNow",
      "indices" : [ 102, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/ZMMiwj4n2M",
      "expanded_url" : "http:\/\/bzfd.it\/1fol6xk",
      "display_url" : "bzfd.it\/1fol6xk"
    } ]
  },
  "geo" : { },
  "id_str" : "449250637596073985",
  "text" : "Need health insurance? Need more GIFs of the @VP? Look no further \u2192 http:\/\/t.co\/ZMMiwj4n2M #4DaysLeft #GetCoveredNow",
  "id" : 449250637596073985,
  "created_at" : "2014-03-27 18:24:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCoveredNow",
      "indices" : [ 112, 126 ]
    }, {
      "text" : "4daysleft",
      "indices" : [ 127, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/uDVIMjQOsW",
      "expanded_url" : "http:\/\/bzfd.it\/1fol6xk",
      "display_url" : "bzfd.it\/1fol6xk"
    } ]
  },
  "geo" : { },
  "id_str" : "449248844745035776",
  "text" : "RT @VP: Making sure you've got affordable health insurance is a BFD. Just ask VP Biden \u2192 http:\/\/t.co\/uDVIMjQOsW #GetCoveredNow #4daysleft",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCoveredNow",
        "indices" : [ 104, 118 ]
      }, {
        "text" : "4daysleft",
        "indices" : [ 119, 129 ]
      } ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/uDVIMjQOsW",
        "expanded_url" : "http:\/\/bzfd.it\/1fol6xk",
        "display_url" : "bzfd.it\/1fol6xk"
      } ]
    },
    "geo" : { },
    "id_str" : "449248758745018368",
    "text" : "Making sure you've got affordable health insurance is a BFD. Just ask VP Biden \u2192 http:\/\/t.co\/uDVIMjQOsW #GetCoveredNow #4daysleft",
    "id" : 449248758745018368,
    "created_at" : "2014-03-27 18:17:05 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 449248844745035776,
  "created_at" : "2014-03-27 18:17:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chuck Schumer",
      "screen_name" : "SenSchumer",
      "indices" : [ 3, 14 ],
      "id_str" : "17494010",
      "id" : 17494010
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 23, 27 ]
    }, {
      "text" : "ACAworks",
      "indices" : [ 119, 128 ]
    }, {
      "text" : "Tbt",
      "indices" : [ 129, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449237824429375488",
  "text" : "RT @SenSchumer: Before #ACA millions of women paid out of pocket for reproductive health care. They\u2019re covered because #ACAworks #Tbt http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SenSchumer\/status\/449235337508683777\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/wO2T2LJtwg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BjwBKMkCAAAUgrL.jpg",
        "id_str" : "449235337512878080",
        "id" : 449235337512878080,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjwBKMkCAAAUgrL.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/wO2T2LJtwg"
      } ],
      "hashtags" : [ {
        "text" : "ACA",
        "indices" : [ 7, 11 ]
      }, {
        "text" : "ACAworks",
        "indices" : [ 103, 112 ]
      }, {
        "text" : "Tbt",
        "indices" : [ 113, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "449235337508683777",
    "text" : "Before #ACA millions of women paid out of pocket for reproductive health care. They\u2019re covered because #ACAworks #Tbt http:\/\/t.co\/wO2T2LJtwg",
    "id" : 449235337508683777,
    "created_at" : "2014-03-27 17:23:45 +0000",
    "user" : {
      "name" : "Chuck Schumer",
      "screen_name" : "SenSchumer",
      "protected" : false,
      "id_str" : "17494010",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623955176131575808\/zWzgRP4C_normal.jpg",
      "id" : 17494010,
      "verified" : true
    }
  },
  "id" : 449237824429375488,
  "created_at" : "2014-03-27 17:33:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "indices" : [ 3, 15 ],
      "id_str" : "15764644",
      "id" : 15764644
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tbt",
      "indices" : [ 17, 21 ]
    }, {
      "text" : "ACA",
      "indices" : [ 32, 36 ]
    }, {
      "text" : "ACAworks",
      "indices" : [ 121, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "449232104262733824",
  "text" : "RT @NancyPelosi: #tbt to before #ACA when women were charged more than men for coverage. Now that\u2019s illegal. This is why #ACAworks: http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/NancyPelosi\/status\/449229991205552128\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/w4yYkGJ5yu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bjv8TADCQAAJCjT.png",
        "id_str" : "449229991213940736",
        "id" : 449229991213940736,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bjv8TADCQAAJCjT.png",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 612,
          "resize" : "fit",
          "w" : 612
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 612,
          "resize" : "fit",
          "w" : 612
        } ],
        "display_url" : "pic.twitter.com\/w4yYkGJ5yu"
      } ],
      "hashtags" : [ {
        "text" : "tbt",
        "indices" : [ 0, 4 ]
      }, {
        "text" : "ACA",
        "indices" : [ 15, 19 ]
      }, {
        "text" : "ACAworks",
        "indices" : [ 104, 113 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "449229991205552128",
    "text" : "#tbt to before #ACA when women were charged more than men for coverage. Now that\u2019s illegal. This is why #ACAworks: http:\/\/t.co\/w4yYkGJ5yu",
    "id" : 449229991205552128,
    "created_at" : "2014-03-27 17:02:31 +0000",
    "user" : {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "protected" : false,
      "id_str" : "15764644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571313158510223360\/wnSl3yXF_normal.jpeg",
      "id" : 15764644,
      "verified" : true
    }
  },
  "id" : 449232104262733824,
  "created_at" : "2014-03-27 17:10:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/449221341502136320\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/s3XE4H0N4E",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bjv0bgfCUAA2VIU.jpg",
      "id_str" : "449221341267251200",
      "id" : 449221341267251200,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bjv0bgfCUAA2VIU.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/s3XE4H0N4E"
    } ],
    "hashtags" : [ {
      "text" : "4DaysLeft",
      "indices" : [ 25, 35 ]
    }, {
      "text" : "GetCoveredNow",
      "indices" : [ 73, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/xm7VZ2Zf1M",
      "expanded_url" : "http:\/\/hc.gov\/dj1dow",
      "display_url" : "hc.gov\/dj1dow"
    } ]
  },
  "geo" : { },
  "id_str" : "449221341502136320",
  "text" : "Time's running out: Just #4DaysLeft to sign up for 2014 health coverage. #GetCoveredNow \u2192 http:\/\/t.co\/xm7VZ2Zf1M, http:\/\/t.co\/s3XE4H0N4E",
  "id" : 449221341502136320,
  "created_at" : "2014-03-27 16:28:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamainItaly",
      "indices" : [ 126, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/Sv7Q3AA59r",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "449207089546919937",
  "text" : "RT @NSCPress: The President's press conference with Prime Minister Renzi will begin shortly. Watch at http:\/\/t.co\/Sv7Q3AA59r. #ObamainItaly\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ObamainItaly",
        "indices" : [ 112, 125 ]
      }, {
        "text" : "ObamainItalia",
        "indices" : [ 126, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/Sv7Q3AA59r",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "449201020795510784",
    "text" : "The President's press conference with Prime Minister Renzi will begin shortly. Watch at http:\/\/t.co\/Sv7Q3AA59r. #ObamainItaly #ObamainItalia",
    "id" : 449201020795510784,
    "created_at" : "2014-03-27 15:07:23 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 449207089546919937,
  "created_at" : "2014-03-27 15:31:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/OWjkdl7rU5",
      "expanded_url" : "http:\/\/instagram.com\/p\/mDANAawijx\/",
      "display_url" : "instagram.com\/p\/mDANAawijx\/"
    } ]
  },
  "geo" : { },
  "id_str" : "449180121069805568",
  "text" : "Watch President Obama arrive at the Vatican on his way to meet with His Holiness, Pope Francis \u2192 http:\/\/t.co\/OWjkdl7rU5",
  "id" : 449180121069805568,
  "created_at" : "2014-03-27 13:44:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/448976497659744256\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/MygVXyg1Xw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BjsVvuPCQAAbWp3.jpg",
      "id_str" : "448976497462624256",
      "id" : 448976497462624256,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjsVvuPCQAAbWp3.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/MygVXyg1Xw"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 81, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448976497659744256",
  "text" : "CT just voted to raise its minimum wage to $10.10.\n\nRT if you agree it's time to #RaiseTheWage for all Americans. http:\/\/t.co\/MygVXyg1Xw",
  "id" : 448976497659744256,
  "created_at" : "2014-03-27 00:15:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 24, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448972117087100928",
  "text" : "Great to see CT vote to #RaiseTheWage. A hard day's work deserves a fair wage, and nobody who works full time should live in poverty. -bo",
  "id" : 448972117087100928,
  "created_at" : "2014-03-26 23:57:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/448959606606155776\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/MgtGYlJQ9i",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BjsGYhhCQAEiRo6.jpg",
      "id_str" : "448959606237052929",
      "id" : 448959606237052929,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjsGYhhCQAEiRo6.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/MgtGYlJQ9i"
    } ],
    "hashtags" : [ {
      "text" : "5DaysLeft",
      "indices" : [ 5, 15 ]
    }, {
      "text" : "GetCoveredNow",
      "indices" : [ 65, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/RKqa8gvoir",
      "expanded_url" : "http:\/\/hc.gov\/bs6Zrg",
      "display_url" : "hc.gov\/bs6Zrg"
    } ]
  },
  "geo" : { },
  "id_str" : "448959606606155776",
  "text" : "Just #5DaysLeft to sign up for 2014 health coverage: Don\u2019t wait, #GetCoveredNow \u2192 http:\/\/t.co\/RKqa8gvoir, http:\/\/t.co\/MgtGYlJQ9i",
  "id" : 448959606606155776,
  "created_at" : "2014-03-26 23:08:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/Gzze2ubcIH",
      "expanded_url" : "http:\/\/www.nasa.gov\/content\/nasa-supported-research-helps-redefine-solar-systems-edge\/index.html#.UzM9XRCwWSp",
      "display_url" : "nasa.gov\/content\/nasa-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "448955487997132800",
  "text" : "RT @NASA: Our solar system has a new most-distant family member: 2012 VP113, a possible dwarf planet! http:\/\/t.co\/Gzze2ubcIH\u00A0 http:\/\/t.co\/B\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.exacttarget.com\/social\" rel=\"nofollow\"\u003ESocialEngage\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NASA\/status\/448927474101919744\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/BZyGWQFZS5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BjrpKLkCcAAzvkD.jpg",
        "id_str" : "448927473988694016",
        "id" : 448927473988694016,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjrpKLkCcAAzvkD.jpg",
        "sizes" : [ {
          "h" : 97,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 204,
          "resize" : "fit",
          "w" : 718
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 204,
          "resize" : "fit",
          "w" : 718
        } ],
        "display_url" : "pic.twitter.com\/BZyGWQFZS5"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/Gzze2ubcIH",
        "expanded_url" : "http:\/\/www.nasa.gov\/content\/nasa-supported-research-helps-redefine-solar-systems-edge\/index.html#.UzM9XRCwWSp",
        "display_url" : "nasa.gov\/content\/nasa-s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "448927474101919744",
    "text" : "Our solar system has a new most-distant family member: 2012 VP113, a possible dwarf planet! http:\/\/t.co\/Gzze2ubcIH\u00A0 http:\/\/t.co\/BZyGWQFZS5",
    "id" : 448927474101919744,
    "created_at" : "2014-03-26 21:00:25 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 448955487997132800,
  "created_at" : "2014-03-26 22:51:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/448946059276873729\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/kM2S3yNZMf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bjr6D-bCMAAwg0T.jpg",
      "id_str" : "448946059079725056",
      "id" : 448946059079725056,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bjr6D-bCMAAwg0T.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/kM2S3yNZMf"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 102, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/HYcMr4G2Mz",
      "expanded_url" : "http:\/\/go.wh.gov\/tnsrnQ",
      "display_url" : "go.wh.gov\/tnsrnQ"
    } ]
  },
  "geo" : { },
  "id_str" : "448946059276873729",
  "text" : "FACT: Tipped workers are TWICE as likely to live in poverty as other workers \u2192 http:\/\/t.co\/HYcMr4G2Mz #RaiseTheWage, http:\/\/t.co\/kM2S3yNZMf",
  "id" : 448946059276873729,
  "created_at" : "2014-03-26 22:14:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/448929808466989056\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/LGbEjTBAg7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BjrrSDfCAAA3R5Q.jpg",
      "id_str" : "448929808282419200",
      "id" : 448929808282419200,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjrrSDfCAAA3R5Q.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/LGbEjTBAg7"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 103, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448929808466989056",
  "text" : "The min wage for tipped workers has been stuck at $2.13 for more than 20 years. It's time to raise it. #RaiseTheWage http:\/\/t.co\/LGbEjTBAg7",
  "id" : 448929808466989056,
  "created_at" : "2014-03-26 21:09:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/448923334479073280\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/qq9tF4igq8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BjrlZOVCEAAEovO.jpg",
      "id_str" : "448923334382587904",
      "id" : 448923334382587904,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjrlZOVCEAAEovO.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/qq9tF4igq8"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 95, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/KmcnD3M1Nj",
      "expanded_url" : "http:\/\/go.wh.gov\/fPRsf4",
      "display_url" : "go.wh.gov\/fPRsf4"
    } ]
  },
  "geo" : { },
  "id_str" : "448923334479073280",
  "text" : "Here's why raising the minimum wage is especially important for women \u2192 http:\/\/t.co\/KmcnD3M1Nj #RaiseTheWage http:\/\/t.co\/qq9tF4igq8",
  "id" : 448923334479073280,
  "created_at" : "2014-03-26 20:43:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 3, 13 ],
      "id_str" : "9624742",
      "id" : 9624742
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/StateDept\/status\/448913388521783296\/photo\/1",
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/7WYyV2pnLz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BjrcWTICAAA9XJy.jpg",
      "id_str" : "448913388525977600",
      "id" : 448913388525977600,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjrcWTICAAA9XJy.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/7WYyV2pnLz"
    } ],
    "hashtags" : [ {
      "text" : "UnitedForUkraine",
      "indices" : [ 71, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448916536968110081",
  "text" : "RT @StateDept: President Obama underscored the importance of remaining #UnitedForUkraine. http:\/\/t.co\/7WYyV2pnLz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/StateDept\/status\/448913388521783296\/photo\/1",
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/7WYyV2pnLz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BjrcWTICAAA9XJy.jpg",
        "id_str" : "448913388525977600",
        "id" : 448913388525977600,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjrcWTICAAA9XJy.jpg",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 700,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 700,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/7WYyV2pnLz"
      } ],
      "hashtags" : [ {
        "text" : "UnitedForUkraine",
        "indices" : [ 56, 73 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "448913388521783296",
    "text" : "President Obama underscored the importance of remaining #UnitedForUkraine. http:\/\/t.co\/7WYyV2pnLz",
    "id" : 448913388521783296,
    "created_at" : "2014-03-26 20:04:27 +0000",
    "user" : {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "protected" : false,
      "id_str" : "9624742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724612605185282048\/1rEfkXDZ_normal.jpg",
      "id" : 9624742,
      "verified" : true
    }
  },
  "id" : 448916536968110081,
  "created_at" : "2014-03-26 20:16:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kerry washington",
      "screen_name" : "kerrywashington",
      "indices" : [ 3, 19 ],
      "id_str" : "205302299",
      "id" : 205302299
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GETCOVERED",
      "indices" : [ 41, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/rhrVQI4sQj",
      "expanded_url" : "http:\/\/1.usa.gov\/HaCX0w",
      "display_url" : "1.usa.gov\/HaCX0w"
    } ]
  },
  "geo" : { },
  "id_str" : "448905874103603200",
  "text" : "RT @kerrywashington: Only 5 days left to #GETCOVERED!  Sign up now http:\/\/t.co\/rhrVQI4sQj -kw's krew",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GETCOVERED",
        "indices" : [ 20, 31 ]
      } ],
      "urls" : [ {
        "indices" : [ 46, 68 ],
        "url" : "http:\/\/t.co\/rhrVQI4sQj",
        "expanded_url" : "http:\/\/1.usa.gov\/HaCX0w",
        "display_url" : "1.usa.gov\/HaCX0w"
      } ]
    },
    "geo" : { },
    "id_str" : "448901117343440896",
    "text" : "Only 5 days left to #GETCOVERED!  Sign up now http:\/\/t.co\/rhrVQI4sQj -kw's krew",
    "id" : 448901117343440896,
    "created_at" : "2014-03-26 19:15:41 +0000",
    "user" : {
      "name" : "kerry washington",
      "screen_name" : "kerrywashington",
      "protected" : false,
      "id_str" : "205302299",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778641930536284160\/3-m-BwGQ_normal.jpg",
      "id" : 205302299,
      "verified" : true
    }
  },
  "id" : 448905874103603200,
  "created_at" : "2014-03-26 19:34:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/448899659994394624\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/CGH3IJdeia",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BjrP3L6CIAAxkU2.jpg",
      "id_str" : "448899659872739328",
      "id" : 448899659872739328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjrP3L6CIAAxkU2.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/CGH3IJdeia"
    } ],
    "hashtags" : [ {
      "text" : "GetCoveredNow",
      "indices" : [ 90, 104 ]
    }, {
      "text" : "5DaysLeft",
      "indices" : [ 105, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/rQ4IAJEs8b",
      "expanded_url" : "http:\/\/go.wh.gov\/QNupoz",
      "display_url" : "go.wh.gov\/QNupoz"
    } ]
  },
  "geo" : { },
  "id_str" : "448899659994394624",
  "text" : "\"It's last call for 2014. So get covered today.\" \u2014President Obama: http:\/\/t.co\/rQ4IAJEs8b #GetCoveredNow #5DaysLeft, http:\/\/t.co\/CGH3IJdeia",
  "id" : 448899659994394624,
  "created_at" : "2014-03-26 19:09:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448880862957174784",
  "text" : "RT @WHLive: Obama: \"Instead of defining ourselves in opposition to others, we can affirm the aspirations that we hold in common.\" #Opportun\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OpportunityForAll",
        "indices" : [ 118, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "448880051158024192",
    "text" : "Obama: \"Instead of defining ourselves in opposition to others, we can affirm the aspirations that we hold in common.\" #OpportunityForAll",
    "id" : 448880051158024192,
    "created_at" : "2014-03-26 17:51:58 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 448880862957174784,
  "created_at" : "2014-03-26 17:55:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448880090227941376",
  "text" : "RT @WHLive: President Obama: \"Instead of targeting our gay and lesbian brothers and sisters, we can use our laws to protect their rights.\" \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Equality",
        "indices" : [ 127, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "448879987882754048",
    "text" : "President Obama: \"Instead of targeting our gay and lesbian brothers and sisters, we can use our laws to protect their rights.\" #Equality",
    "id" : 448879987882754048,
    "created_at" : "2014-03-26 17:51:43 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 448880090227941376,
  "created_at" : "2014-03-26 17:52:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 86, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448879897537425408",
  "text" : "President Obama: \"We can insist on policies that benefit the many, not just the few.\" #OpportunityForAll",
  "id" : 448879897537425408,
  "created_at" : "2014-03-26 17:51:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448879789899001856",
  "text" : "Obama: \"The ideals that unite us matter equally to the young people of Boston or Brussels, or Jakarta or Nairobi, or Krakow or Kyiv.\"",
  "id" : 448879789899001856,
  "created_at" : "2014-03-26 17:50:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UnitedForUkraine",
      "indices" : [ 123, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448876234475573248",
  "text" : "Obama: \"What we want is for the Ukrainian people to make their own decisions\u2014just like other free people around the world\" #UnitedForUkraine",
  "id" : 448876234475573248,
  "created_at" : "2014-03-26 17:36:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448875798796460032",
  "text" : "RT @WHLive: Obama: \"Russia\u2019s violation of international law\u2014its assault on Ukraine\u2019s sovereignty &amp; territorial integrity\u2014must be met with c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "448875703665455104",
    "text" : "Obama: \"Russia\u2019s violation of international law\u2014its assault on Ukraine\u2019s sovereignty &amp; territorial integrity\u2014must be met with condemnation.\"",
    "id" : 448875703665455104,
    "created_at" : "2014-03-26 17:34:42 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 448875798796460032,
  "created_at" : "2014-03-26 17:35:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448875546618109952",
  "text" : "Obama: \"We believe in human dignity\u2014that every person is created equal, no matter who you are, or what you look like, or who you love.\"",
  "id" : 448875546618109952,
  "created_at" : "2014-03-26 17:34:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ukraine",
      "indices" : [ 131, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448874887118352384",
  "text" : "\"Their voices echo calls for human dignity that rang out in European streets and squares for generations.\" \u2014Obama on the people of #Ukraine",
  "id" : 448874887118352384,
  "created_at" : "2014-03-26 17:31:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448874096265555968",
  "text" : "Obama: \"I come here today to insist that we must never take for granted the progress that has been won...and advanced around the world.\"",
  "id" : 448874096265555968,
  "created_at" : "2014-03-26 17:28:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/IyvHEijPTE",
      "expanded_url" : "http:\/\/go.wh.gov\/U6F7R5",
      "display_url" : "go.wh.gov\/U6F7R5"
    } ]
  },
  "geo" : { },
  "id_str" : "448871398946406400",
  "text" : "Happening now: President Obama delivers remarks in Brussels, Belgium. Watch \u2192 http:\/\/t.co\/IyvHEijPTE",
  "id" : 448871398946406400,
  "created_at" : "2014-03-26 17:17:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 57, 75 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/5dgM40KNpM",
      "expanded_url" : "http:\/\/go.wh.gov\/FsMUdT",
      "display_url" : "go.wh.gov\/FsMUdT"
    } ]
  },
  "geo" : { },
  "id_str" : "448857468060594177",
  "text" : "\"I applaud the efforts of Democrats in the House to give #ImmigrationReform the yes-or-no vote it deserves.\" \u2014Obama: http:\/\/t.co\/5dgM40KNpM",
  "id" : 448857468060594177,
  "created_at" : "2014-03-26 16:22:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "indices" : [ 3, 13 ],
      "id_str" : "1613223313",
      "id" : 1613223313
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/448821154594033665\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/wOvFTziRtf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BjqIdkZCAAAh7hY.jpg",
      "id_str" : "448821154443034624",
      "id" : 448821154443034624,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjqIdkZCAAAh7hY.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/wOvFTziRtf"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 90, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448844378510221313",
  "text" : "RT @Cecilia44: FACT: More than half of all Americans who earn the minimum wage are women. #RaiseTheWage, http:\/\/t.co\/wOvFTziRtf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/448821154594033665\/photo\/1",
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/wOvFTziRtf",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BjqIdkZCAAAh7hY.jpg",
        "id_str" : "448821154443034624",
        "id" : 448821154443034624,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjqIdkZCAAAh7hY.jpg",
        "sizes" : [ {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/wOvFTziRtf"
      } ],
      "hashtags" : [ {
        "text" : "RaiseTheWage",
        "indices" : [ 75, 88 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "448844249065615360",
    "text" : "FACT: More than half of all Americans who earn the minimum wage are women. #RaiseTheWage, http:\/\/t.co\/wOvFTziRtf",
    "id" : 448844249065615360,
    "created_at" : "2014-03-26 15:29:42 +0000",
    "user" : {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "protected" : false,
      "id_str" : "1613223313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000172019215\/ed65eda76f51213f91b33edbaa62054c_normal.jpeg",
      "id" : 1613223313,
      "verified" : true
    }
  },
  "id" : 448844378510221313,
  "created_at" : "2014-03-26 15:30:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 122, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/ONs6NPpiAO",
      "expanded_url" : "http:\/\/go.wh.gov\/2z1Uw4",
      "display_url" : "go.wh.gov\/2z1Uw4"
    } ]
  },
  "geo" : { },
  "id_str" : "448826760474279936",
  "text" : "Here's how President Obama's plan to raise the minimum wage and tipped wages would benefit women \u2192 http:\/\/t.co\/ONs6NPpiAO #RaiseTheWage",
  "id" : 448826760474279936,
  "created_at" : "2014-03-26 14:20:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/448821154594033665\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/976spHZvt4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BjqIdkZCAAAh7hY.jpg",
      "id_str" : "448821154443034624",
      "id" : 448821154443034624,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjqIdkZCAAAh7hY.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/976spHZvt4"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 100, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448821154594033665",
  "text" : "Here's a look at some of the hardworking Americans who would benefit from raising the minimum wage. #RaiseTheWage http:\/\/t.co\/976spHZvt4",
  "id" : 448821154594033665,
  "created_at" : "2014-03-26 13:57:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gloria Steinem",
      "screen_name" : "GloriaSteinem",
      "indices" : [ 21, 35 ],
      "id_str" : "48269483",
      "id" : 48269483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/Trw8sFL6Ev",
      "expanded_url" : "http:\/\/youtu.be\/013zj1KNeIE",
      "display_url" : "youtu.be\/013zj1KNeIE"
    } ]
  },
  "geo" : { },
  "id_str" : "448612110239821824",
  "text" : "Happy 80th birthday, @GloriaSteinem! http:\/\/t.co\/Trw8sFL6Ev",
  "id" : 448612110239821824,
  "created_at" : "2014-03-26 00:07:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/448582132558884864\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/iPLCNHVyAi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BjmvEpxCQAA3PqP.jpg",
      "id_str" : "448582132365934592",
      "id" : 448582132365934592,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjmvEpxCQAA3PqP.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/iPLCNHVyAi"
    } ],
    "hashtags" : [ {
      "text" : "GetCoveredNow",
      "indices" : [ 63, 77 ]
    }, {
      "text" : "6DaysLeft",
      "indices" : [ 103, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/JlsjwSA7or",
      "expanded_url" : "http:\/\/hc.gov\/whGHYE",
      "display_url" : "hc.gov\/whGHYE"
    } ]
  },
  "geo" : { },
  "id_str" : "448582132558884864",
  "text" : "Need health insurance? You've got less than a week to sign up. #GetCoveredNow \u2192 http:\/\/t.co\/JlsjwSA7or #6DaysLeft, http:\/\/t.co\/iPLCNHVyAi",
  "id" : 448582132558884864,
  "created_at" : "2014-03-25 22:08:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/IpKgMOkqry",
      "expanded_url" : "http:\/\/www.washingtonpost.com\/blogs\/wonkblog\/wp\/2014\/03\/25\/young-adults-signing-up-at-higher-rates-off-obamacare-exchanges\/",
      "display_url" : "washingtonpost.com\/blogs\/wonkblog\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "448575418275467264",
  "text" : "RT @pfeiffer44: Young adults signing up at higher rates off Obamacare exchanges http:\/\/t.co\/IpKgMOkqry",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/IpKgMOkqry",
        "expanded_url" : "http:\/\/www.washingtonpost.com\/blogs\/wonkblog\/wp\/2014\/03\/25\/young-adults-signing-up-at-higher-rates-off-obamacare-exchanges\/",
        "display_url" : "washingtonpost.com\/blogs\/wonkblog\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "448572773321814017",
    "text" : "Young adults signing up at higher rates off Obamacare exchanges http:\/\/t.co\/IpKgMOkqry",
    "id" : 448572773321814017,
    "created_at" : "2014-03-25 21:30:57 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 448575418275467264,
  "created_at" : "2014-03-25 21:41:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCoveredNow",
      "indices" : [ 107, 121 ]
    }, {
      "text" : "StepBrothers",
      "indices" : [ 122, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/kGf4LiS2N6",
      "expanded_url" : "http:\/\/FunnyOrDie.com\/m\/8rbx",
      "display_url" : "FunnyOrDie.com\/m\/8rbx"
    } ]
  },
  "geo" : { },
  "id_str" : "448567540126842880",
  "text" : "Think you're invincible? Derek Huff did, too. And then he needed health insurance \u2192 http:\/\/t.co\/kGf4LiS2N6 #GetCoveredNow #StepBrothers",
  "id" : 448567540126842880,
  "created_at" : "2014-03-25 21:10:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448552085110677505",
  "text" : "RT @VP: Proud to be in NH today as the state legislature approves Medicaid expansion. Tens of thousands could gain access to health care. -\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "448549699310845952",
    "text" : "Proud to be in NH today as the state legislature approves Medicaid expansion. Tens of thousands could gain access to health care. -- VP",
    "id" : 448549699310845952,
    "created_at" : "2014-03-25 19:59:16 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 448552085110677505,
  "created_at" : "2014-03-25 20:08:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448534207825182720",
  "text" : "FACT: If Congress doesn't act, the min wage is projected to lose 1.7% of its value in 2014\u2014enough to buy a month of groceries. #RaiseTheWage",
  "id" : 448534207825182720,
  "created_at" : "2014-03-25 18:57:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "The Bump",
      "screen_name" : "thebump",
      "indices" : [ 104, 112 ],
      "id_str" : "16310534",
      "id" : 16310534
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/lql3vwBeRR",
      "expanded_url" : "http:\/\/spr.ly\/6013gsVx",
      "display_url" : "spr.ly\/6013gsVx"
    } ]
  },
  "geo" : { },
  "id_str" : "448524363726602241",
  "text" : "RT @FLOTUS: \"I\u2019ll never forget the joy Barack and I felt over the birth of our 2 daughters.\" \u2014FLOTUS on @TheBump: http:\/\/t.co\/lql3vwBeRR #G\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Bump",
        "screen_name" : "thebump",
        "indices" : [ 92, 100 ],
        "id_str" : "16310534",
        "id" : 16310534
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCoveredNow",
        "indices" : [ 125, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/lql3vwBeRR",
        "expanded_url" : "http:\/\/spr.ly\/6013gsVx",
        "display_url" : "spr.ly\/6013gsVx"
      } ]
    },
    "geo" : { },
    "id_str" : "448522360136941568",
    "text" : "\"I\u2019ll never forget the joy Barack and I felt over the birth of our 2 daughters.\" \u2014FLOTUS on @TheBump: http:\/\/t.co\/lql3vwBeRR #GetCoveredNow",
    "id" : 448522360136941568,
    "created_at" : "2014-03-25 18:10:38 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 448524363726602241,
  "created_at" : "2014-03-25 18:18:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/KDh5OYCIZJ",
      "expanded_url" : "http:\/\/qr.ae\/n627o",
      "display_url" : "qr.ae\/n627o"
    } ]
  },
  "geo" : { },
  "id_str" : "448509793154891776",
  "text" : "\"My hair's getting grayer, but I'd like to think I've still got a decent jump shot\" \u2014Obama on injuries &amp; health care: http:\/\/t.co\/KDh5OYCIZJ",
  "id" : 448509793154891776,
  "created_at" : "2014-03-25 17:20:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/448489666786770945\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/3Gx2qjfmGn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bjla-cBCYAEme93.jpg",
      "id_str" : "448489666619006977",
      "id" : 448489666619006977,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bjla-cBCYAEme93.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/3Gx2qjfmGn"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 100, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448489666786770945",
  "text" : "Who makes the minimum wage?\nMore than half \u2192 Women\nMore than half \u2192 Work full time\nAverage age \u2192 35\n#RaiseTheWage http:\/\/t.co\/3Gx2qjfmGn",
  "id" : 448489666786770945,
  "created_at" : "2014-03-25 16:00:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448479380562771968",
  "text" : "President Obama: \"I would ask all Americans to send their thoughts and prayers to Washington state and the community of Oso.\"",
  "id" : 448479380562771968,
  "created_at" : "2014-03-25 15:19:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/a9TutCIkK9",
      "expanded_url" : "http:\/\/go.wh.gov\/rHdKHQ",
      "display_url" : "go.wh.gov\/rHdKHQ"
    } ]
  },
  "geo" : { },
  "id_str" : "448477279837233152",
  "text" : "Watch live: President Obama holds a joint press conference with Prime Minister Rutte of the Netherlands \u2192 http:\/\/t.co\/a9TutCIkK9",
  "id" : 448477279837233152,
  "created_at" : "2014-03-25 15:11:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 122, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/LbZB65Hl9y",
      "expanded_url" : "http:\/\/go.wh.gov\/mftGgp",
      "display_url" : "go.wh.gov\/mftGgp"
    } ]
  },
  "geo" : { },
  "id_str" : "448475895112937472",
  "text" : "Raising the minimum wage would benefit millions. Share how it would help you or someone you know \u2192 http:\/\/t.co\/LbZB65Hl9y #RaiseTheWage",
  "id" : 448475895112937472,
  "created_at" : "2014-03-25 15:06:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HealthCare.gov",
      "screen_name" : "HealthCareGov",
      "indices" : [ 3, 17 ],
      "id_str" : "86697288",
      "id" : 86697288
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/eTfU7hBJUR",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "448467544236892160",
  "text" : "RT @HealthCareGov: Join the near record numbers seeking coverage. 1M+ visits to http:\/\/t.co\/eTfU7hBJUR and 350k calls on Monday. 6 days to \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCoveredNow",
        "indices" : [ 120, 134 ]
      } ],
      "urls" : [ {
        "indices" : [ 61, 83 ],
        "url" : "http:\/\/t.co\/eTfU7hBJUR",
        "expanded_url" : "http:\/\/HealthCare.gov",
        "display_url" : "HealthCare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "448458557227556864",
    "text" : "Join the near record numbers seeking coverage. 1M+ visits to http:\/\/t.co\/eTfU7hBJUR and 350k calls on Monday. 6 days to #GetCoveredNow",
    "id" : 448458557227556864,
    "created_at" : "2014-03-25 13:57:06 +0000",
    "user" : {
      "name" : "HealthCare.gov",
      "screen_name" : "HealthCareGov",
      "protected" : false,
      "id_str" : "86697288",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/528294497105350656\/OXpX0USe_normal.png",
      "id" : 86697288,
      "verified" : true
    }
  },
  "id" : 448467544236892160,
  "created_at" : "2014-03-25 14:32:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/448455718840983553\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/S6VyHIZBey",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bjk8GZpCAAAKPJn.jpg",
      "id_str" : "448455718559940608",
      "id" : 448455718559940608,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bjk8GZpCAAAKPJn.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/S6VyHIZBey"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/271DhWZqpR",
      "expanded_url" : "http:\/\/go.wh.gov\/2tJ8mT",
      "display_url" : "go.wh.gov\/2tJ8mT"
    } ]
  },
  "geo" : { },
  "id_str" : "448455718840983553",
  "text" : "President Obama and other world leaders held a G-7 meeting last night in The Hague \u2192 http:\/\/t.co\/271DhWZqpR, http:\/\/t.co\/S6VyHIZBey",
  "id" : 448455718840983553,
  "created_at" : "2014-03-25 13:45:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/8XQyMWYrXR",
      "expanded_url" : "http:\/\/youtu.be\/QwjrOh1As24",
      "display_url" : "youtu.be\/QwjrOh1As24"
    } ]
  },
  "geo" : { },
  "id_str" : "448252106097848320",
  "text" : "Here's a look at President Obama's day in Holland, where he met with world leaders at the Nuclear Security Summit \u2192 http:\/\/t.co\/8XQyMWYrXR",
  "id" : 448252106097848320,
  "created_at" : "2014-03-25 00:16:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448246581851336705",
  "text" : "RT @FLOTUS: \"In studying abroad, you're not just changing your own life, you are changing the lives of everyone you meet.\" -Mrs. Obama #Pow\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PowerOfEducation",
        "indices" : [ 123, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "448242901923799040",
    "text" : "\"In studying abroad, you're not just changing your own life, you are changing the lives of everyone you meet.\" -Mrs. Obama #PowerOfEducation",
    "id" : 448242901923799040,
    "created_at" : "2014-03-24 23:40:10 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 448246581851336705,
  "created_at" : "2014-03-24 23:54:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TIME",
      "screen_name" : "TIME",
      "indices" : [ 3, 8 ],
      "id_str" : "14293310",
      "id" : 14293310
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448224061303574528",
  "text" : "RT @TIME: President Obama has joined the question and answer site Quora to answer questions about the Affordable Care Act http:\/\/t.co\/uTZ5W\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/uTZ5WTZJvg",
        "expanded_url" : "http:\/\/ti.me\/1fVktdH",
        "display_url" : "ti.me\/1fVktdH"
      } ]
    },
    "geo" : { },
    "id_str" : "448213960966156290",
    "text" : "President Obama has joined the question and answer site Quora to answer questions about the Affordable Care Act http:\/\/t.co\/uTZ5WTZJvg",
    "id" : 448213960966156290,
    "created_at" : "2014-03-24 21:45:10 +0000",
    "user" : {
      "name" : "TIME",
      "screen_name" : "TIME",
      "protected" : false,
      "id_str" : "14293310",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1700796190\/Picture_24_normal.png",
      "id" : 14293310,
      "verified" : true
    }
  },
  "id" : 448224061303574528,
  "created_at" : "2014-03-24 22:25:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/448216336380854272\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/suyCCGrUS6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BjhiYgsCEAALY1-.jpg",
      "id_str" : "448216336154365952",
      "id" : 448216336154365952,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjhiYgsCEAALY1-.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/suyCCGrUS6"
    } ],
    "hashtags" : [ {
      "text" : "GetCoveredNow",
      "indices" : [ 67, 81 ]
    }, {
      "text" : "7DaysLeft",
      "indices" : [ 106, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/5u8Lvzq29W",
      "expanded_url" : "http:\/\/hc.gov\/iywYgM",
      "display_url" : "hc.gov\/iywYgM"
    } ]
  },
  "geo" : { },
  "id_str" : "448216336380854272",
  "text" : "We're 1 week out from the deadline to sign up for health coverage. #GetCoveredNow: http:\/\/t.co\/5u8Lvzq29W\n#7DaysLeft http:\/\/t.co\/suyCCGrUS6",
  "id" : 448216336380854272,
  "created_at" : "2014-03-24 21:54:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 121, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/RoSuZxkHMk",
      "expanded_url" : "http:\/\/go.wh.gov\/BPHx7U",
      "display_url" : "go.wh.gov\/BPHx7U"
    } ]
  },
  "geo" : { },
  "id_str" : "448208927386517504",
  "text" : "Millions of Americans stand to benefit if Congress raises the minimum wage. See where they live \u2192 http:\/\/t.co\/RoSuZxkHMk #RaiseTheWage",
  "id" : 448208927386517504,
  "created_at" : "2014-03-24 21:25:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Quora",
      "screen_name" : "Quora",
      "indices" : [ 3, 9 ],
      "id_str" : "33696409",
      "id" : 33696409
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Quora\/status\/448157009557217281\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/uszVGgTfqs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BjgsbP7CYAAUdbr.jpg",
      "id_str" : "448157009565605888",
      "id" : 448157009565605888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjgsbP7CYAAUdbr.jpg",
      "sizes" : [ {
        "h" : 213,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 376,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1283,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 642,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/uszVGgTfqs"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/xRaRAI7MRk",
      "expanded_url" : "http:\/\/blog.quora.com\/President-Barack-Obama-Answers-Affordable-Care-Act-Questions-on-Quora?share=1",
      "display_url" : "blog.quora.com\/President-Bara\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "448196713829109760",
  "text" : "RT @Quora: President Barack Obama answers questions about the Affordable Care Act on Quora. http:\/\/t.co\/xRaRAI7MRk http:\/\/t.co\/uszVGgTfqs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Quora\/status\/448157009557217281\/photo\/1",
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/uszVGgTfqs",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BjgsbP7CYAAUdbr.jpg",
        "id_str" : "448157009565605888",
        "id" : 448157009565605888,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjgsbP7CYAAUdbr.jpg",
        "sizes" : [ {
          "h" : 213,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 376,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1283,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 642,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/uszVGgTfqs"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/xRaRAI7MRk",
        "expanded_url" : "http:\/\/blog.quora.com\/President-Barack-Obama-Answers-Affordable-Care-Act-Questions-on-Quora?share=1",
        "display_url" : "blog.quora.com\/President-Bara\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "448157009557217281",
    "text" : "President Barack Obama answers questions about the Affordable Care Act on Quora. http:\/\/t.co\/xRaRAI7MRk http:\/\/t.co\/uszVGgTfqs",
    "id" : 448157009557217281,
    "created_at" : "2014-03-24 17:58:52 +0000",
    "user" : {
      "name" : "Quora",
      "screen_name" : "Quora",
      "protected" : false,
      "id_str" : "33696409",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615648367943651328\/51pM5n5v_normal.png",
      "id" : 33696409,
      "verified" : true
    }
  },
  "id" : 448196713829109760,
  "created_at" : "2014-03-24 20:36:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Lopez",
      "screen_name" : "JLo",
      "indices" : [ 3, 7 ],
      "id_str" : "85603854",
      "id" : 85603854
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 25, 32 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 49, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/awciXwwOX9",
      "expanded_url" : "http:\/\/bit.ly\/NdM2rH",
      "display_url" : "bit.ly\/NdM2rH"
    }, {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/aCGPG6eKiv",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "448192975278178304",
  "text" : "RT @JLo: Join my mom and @FLOTUS in helping kids #GetCovered by March 31 http:\/\/t.co\/awciXwwOX9! Click here: http:\/\/t.co\/aCGPG6eKiv #YourMo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The First Lady",
        "screen_name" : "FLOTUS",
        "indices" : [ 16, 23 ],
        "id_str" : "1093090866",
        "id" : 1093090866
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 40, 51 ]
      }, {
        "text" : "YourMomCares",
        "indices" : [ 123, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/awciXwwOX9",
        "expanded_url" : "http:\/\/bit.ly\/NdM2rH",
        "display_url" : "bit.ly\/NdM2rH"
      }, {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/aCGPG6eKiv",
        "expanded_url" : "http:\/\/Healthcare.gov",
        "display_url" : "Healthcare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "445213269025124352",
    "text" : "Join my mom and @FLOTUS in helping kids #GetCovered by March 31 http:\/\/t.co\/awciXwwOX9! Click here: http:\/\/t.co\/aCGPG6eKiv #YourMomCares",
    "id" : 445213269025124352,
    "created_at" : "2014-03-16 15:01:29 +0000",
    "user" : {
      "name" : "Jennifer Lopez",
      "screen_name" : "JLo",
      "protected" : false,
      "id_str" : "85603854",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/751268899333693442\/J1irknYA_normal.jpg",
      "id" : 85603854,
      "verified" : true
    }
  },
  "id" : 448192975278178304,
  "created_at" : "2014-03-24 20:21:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 25, 29 ]
    }, {
      "text" : "GetCoveredNow",
      "indices" : [ 121, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/IrhL0TesQl",
      "expanded_url" : "http:\/\/hc.gov\/fMpAXo",
      "display_url" : "hc.gov\/fMpAXo"
    } ]
  },
  "geo" : { },
  "id_str" : "448177284630200320",
  "text" : "Good news: Thanks to the #ACA, more than 700,000 New Yorkers have signed up for health coverage \u2192 http:\/\/t.co\/IrhL0TesQl #GetCoveredNow",
  "id" : 448177284630200320,
  "created_at" : "2014-03-24 19:19:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/448168406093529088\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/HzZVWMX8eI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bjg2ymZCYAA5fes.jpg",
      "id_str" : "448168405850284032",
      "id" : 448168405850284032,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bjg2ymZCYAA5fes.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/HzZVWMX8eI"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 96, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/Yuns0FQrqm",
      "expanded_url" : "http:\/\/go.wh.gov\/9KpFQv",
      "display_url" : "go.wh.gov\/9KpFQv"
    } ]
  },
  "geo" : { },
  "id_str" : "448168406093529088",
  "text" : "Share why you agree it's time to raise the minimum wage to $10.10\/hour \u2192 http:\/\/t.co\/Yuns0FQrqm #RaiseTheWage http:\/\/t.co\/HzZVWMX8eI",
  "id" : 448168406093529088,
  "created_at" : "2014-03-24 18:44:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "indices" : [ 3, 13 ],
      "id_str" : "1613223313",
      "id" : 1613223313
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCoveredNow",
      "indices" : [ 108, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448156586629169153",
  "text" : "RT @Cecilia44: 1 week left to sign up for 2014 health insurance. If you or someone you know needs coverage, #GetCoveredNow \u2192 http:\/\/t.co\/QB\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCoveredNow",
        "indices" : [ 93, 107 ]
      } ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/QBluXZKadt",
        "expanded_url" : "http:\/\/hc.gov\/ixfFek",
        "display_url" : "hc.gov\/ixfFek"
      } ]
    },
    "geo" : { },
    "id_str" : "448155611298275328",
    "text" : "1 week left to sign up for 2014 health insurance. If you or someone you know needs coverage, #GetCoveredNow \u2192 http:\/\/t.co\/QBluXZKadt",
    "id" : 448155611298275328,
    "created_at" : "2014-03-24 17:53:18 +0000",
    "user" : {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "protected" : false,
      "id_str" : "1613223313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000172019215\/ed65eda76f51213f91b33edbaa62054c_normal.jpeg",
      "id" : 1613223313,
      "verified" : true
    }
  },
  "id" : 448156586629169153,
  "created_at" : "2014-03-24 17:57:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Quora",
      "screen_name" : "Quora",
      "indices" : [ 28, 34 ],
      "id_str" : "33696409",
      "id" : 33696409
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 104, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/zD3esciLVY",
      "expanded_url" : "https:\/\/www.quora.com\/Barack-Obama",
      "display_url" : "quora.com\/Barack-Obama"
    }, {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/u4BBundSsw",
      "expanded_url" : "http:\/\/qr.ae\/nmzsJ",
      "display_url" : "qr.ae\/nmzsJ"
    } ]
  },
  "geo" : { },
  "id_str" : "448149654111531008",
  "text" : "President Obama just joined @Quora \u2192 https:\/\/t.co\/zD3esciLVY\n\nCheck out his answers to questions on the #ACA \u2192 http:\/\/t.co\/u4BBundSsw",
  "id" : 448149654111531008,
  "created_at" : "2014-03-24 17:29:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/448137441354870784\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/XcRZErHFeo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BjgaoOKCMAEWGHx.jpg",
      "id_str" : "448137441220636673",
      "id" : 448137441220636673,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjgaoOKCMAEWGHx.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/XcRZErHFeo"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448137441354870784",
  "text" : "Raising the minimum wage would help more than 28 million workers.\n\nRT if you agree it's time to make it happen. http:\/\/t.co\/XcRZErHFeo",
  "id" : 448137441354870784,
  "created_at" : "2014-03-24 16:41:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/448128233347637249\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/oAW4Sypc5K",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BjgSQPgCEAA3gAD.jpg",
      "id_str" : "448128233171456000",
      "id" : 448128233171456000,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjgSQPgCEAA3gAD.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/oAW4Sypc5K"
    } ],
    "hashtags" : [ {
      "text" : "GetCoveredNow",
      "indices" : [ 65, 79 ]
    }, {
      "text" : "7DaysLeft",
      "indices" : [ 105, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/mfNLupYl8J",
      "expanded_url" : "http:\/\/hc.gov\/NX9eEo",
      "display_url" : "hc.gov\/NX9eEo"
    } ]
  },
  "geo" : { },
  "id_str" : "448128233347637249",
  "text" : "The time to procrastinate is over.\nIf you need health insurance, #GetCoveredNow \u2192\nhttp:\/\/t.co\/mfNLupYl8J\n#7DaysLeft http:\/\/t.co\/oAW4Sypc5K",
  "id" : 448128233347637249,
  "created_at" : "2014-03-24 16:04:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USA TODAY",
      "screen_name" : "USATODAY",
      "indices" : [ 1, 10 ],
      "id_str" : "15754281",
      "id" : 15754281
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 89, 102 ]
    }, {
      "text" : "OpportunityForAll",
      "indices" : [ 103, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/e21xZtsvhk",
      "expanded_url" : "http:\/\/usat.ly\/1m1f0aL",
      "display_url" : "usat.ly\/1m1f0aL"
    } ]
  },
  "geo" : { },
  "id_str" : "448101725128626176",
  "text" : ".@USAToday on why it's time to raise the overtime pay threshold \u2192 http:\/\/t.co\/e21xZtsvhk #RaiseTheWage #OpportunityForAll",
  "id" : 448101725128626176,
  "created_at" : "2014-03-24 14:19:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448092543209992193",
  "text" : "RT @NSCPress: POTUS: We reaffirmed our shared determination to confront climate change and its effects, including rising sea levels.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "448036643061387264",
    "text" : "POTUS: We reaffirmed our shared determination to confront climate change and its effects, including rising sea levels.",
    "id" : 448036643061387264,
    "created_at" : "2014-03-24 10:00:34 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 448092543209992193,
  "created_at" : "2014-03-24 13:42:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ukrainian",
      "indices" : [ 73, 83 ]
    }, {
      "text" : "ObamainHolland",
      "indices" : [ 106, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "448092285151248384",
  "text" : "RT @NSCPress: POTUS: Europe and America are united in our support of the #Ukrainian government and people.#ObamainHolland",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Ukrainian",
        "indices" : [ 59, 69 ]
      }, {
        "text" : "ObamainHolland",
        "indices" : [ 92, 107 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "448035502269419520",
    "text" : "POTUS: Europe and America are united in our support of the #Ukrainian government and people.#ObamainHolland",
    "id" : 448035502269419520,
    "created_at" : "2014-03-24 09:56:02 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 448092285151248384,
  "created_at" : "2014-03-24 13:41:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 113, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/fNLhabOAGV",
      "expanded_url" : "http:\/\/go.wh.gov\/qpkVQ6",
      "display_url" : "go.wh.gov\/qpkVQ6"
    } ]
  },
  "geo" : { },
  "id_str" : "447885543733342208",
  "text" : "\"No woman who works full-time should ever have to raise her children in poverty.\" \u2014Obama: http:\/\/t.co\/fNLhabOAGV #RaiseTheWage",
  "id" : 447885543733342208,
  "created_at" : "2014-03-24 00:00:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/447820161018363904\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/sCU20SjRDd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bjb6EERCAAEQNBs.jpg",
      "id_str" : "447820160741539841",
      "id" : 447820160741539841,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bjb6EERCAAEQNBs.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/sCU20SjRDd"
    } ],
    "hashtags" : [ {
      "text" : "GetCoveredNow",
      "indices" : [ 0, 14 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/F3TkdvVAYv",
      "expanded_url" : "http:\/\/hc.gov\/XDzurn",
      "display_url" : "hc.gov\/XDzurn"
    } ]
  },
  "geo" : { },
  "id_str" : "447820161018363904",
  "text" : "#GetCoveredNow to join millions of Americans who have gained access to free preventive care: http:\/\/t.co\/F3TkdvVAYv, http:\/\/t.co\/sCU20SjRDd",
  "id" : 447820161018363904,
  "created_at" : "2014-03-23 19:40:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 36, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/kpXnFatUGy",
      "expanded_url" : "http:\/\/hc.gov\/KLwPze",
      "display_url" : "hc.gov\/KLwPze"
    } ]
  },
  "geo" : { },
  "id_str" : "447779845678698496",
  "text" : "\"If you\u2019re an American who wants to #GetCovered\u2014or...know someone who should\u2014it\u2019s now last call for 2014.\" \u2014Obama: http:\/\/t.co\/kpXnFatUGy",
  "id" : 447779845678698496,
  "created_at" : "2014-03-23 17:00:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/447767556951007233\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/RZbFBU2FKt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BjbKOG-CQAAyq9B.jpg",
      "id_str" : "447767556707729408",
      "id" : 447767556707729408,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjbKOG-CQAAyq9B.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/RZbFBU2FKt"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/0lwMLeJwkK",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "447767556951007233",
  "text" : "\"Check out http:\/\/t.co\/0lwMLeJwkK or call 1-800-318-2596 to see what new choices are available to you.\" \u2014Obama: http:\/\/t.co\/RZbFBU2FKt",
  "id" : 447767556951007233,
  "created_at" : "2014-03-23 16:11:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/447755675808964608\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/CC9FUSMSVz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bja_aieCUAAYUnO.jpg",
      "id_str" : "447755675620233216",
      "id" : 447755675620233216,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bja_aieCUAAYUnO.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/CC9FUSMSVz"
    } ],
    "hashtags" : [ {
      "text" : "GetCoveredNow",
      "indices" : [ 102, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "447755675808964608",
  "text" : "\"Since I signed the Affordable Care Act into law, the share of Americans with insurance is up\" \u2014Obama #GetCoveredNow http:\/\/t.co\/CC9FUSMSVz",
  "id" : 447755675808964608,
  "created_at" : "2014-03-23 15:24:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/447730633507209216\/photo\/1",
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/tRrmrn73eL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bjaoo4wCQAA7CY-.jpg",
      "id_str" : "447730633352036352",
      "id" : 447730633352036352,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bjaoo4wCQAA7CY-.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1050
      } ],
      "display_url" : "pic.twitter.com\/tRrmrn73eL"
    } ],
    "hashtags" : [ {
      "text" : "FLOTUSinChina",
      "indices" : [ 71, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/LyZlco0Xae",
      "expanded_url" : "http:\/\/wh.gov\/lpKi6",
      "display_url" : "wh.gov\/lpKi6"
    } ]
  },
  "geo" : { },
  "id_str" : "447745606455689216",
  "text" : "RT @FLOTUS: Sharing a moment at the Great Wall. http:\/\/t.co\/LyZlco0Xae #FLOTUSinChina http:\/\/t.co\/tRrmrn73eL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/447730633507209216\/photo\/1",
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/tRrmrn73eL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bjaoo4wCQAA7CY-.jpg",
        "id_str" : "447730633352036352",
        "id" : 447730633352036352,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bjaoo4wCQAA7CY-.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 700,
          "resize" : "fit",
          "w" : 1050
        } ],
        "display_url" : "pic.twitter.com\/tRrmrn73eL"
      } ],
      "hashtags" : [ {
        "text" : "FLOTUSinChina",
        "indices" : [ 59, 73 ]
      } ],
      "urls" : [ {
        "indices" : [ 36, 58 ],
        "url" : "http:\/\/t.co\/LyZlco0Xae",
        "expanded_url" : "http:\/\/wh.gov\/lpKi6",
        "display_url" : "wh.gov\/lpKi6"
      } ]
    },
    "geo" : { },
    "id_str" : "447730633507209216",
    "text" : "Sharing a moment at the Great Wall. http:\/\/t.co\/LyZlco0Xae #FLOTUSinChina http:\/\/t.co\/tRrmrn73eL",
    "id" : 447730633507209216,
    "created_at" : "2014-03-23 13:44:36 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 447745606455689216,
  "created_at" : "2014-03-23 14:44:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 100, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/eDKtGhDbLK",
      "expanded_url" : "http:\/\/go.wh.gov\/ve27in",
      "display_url" : "go.wh.gov\/ve27in"
    } ]
  },
  "geo" : { },
  "id_str" : "447742094220595202",
  "text" : "\"On average, a woman still earns just 77 cents for every dollar a man does.\" \u2014Obama on fighting for #EqualPay: http:\/\/t.co\/eDKtGhDbLK",
  "id" : 447742094220595202,
  "created_at" : "2014-03-23 14:30:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dayton Flyers",
      "screen_name" : "DaytonFlyers",
      "indices" : [ 16, 29 ],
      "id_str" : "143505435",
      "id" : 143505435
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "447553848304205824",
  "text" : "Congrats to the @DaytonFlyers on a huge upset win! Devin Oliver, I may need to take you up on that pick-up game one of these days. -bo",
  "id" : 447553848304205824,
  "created_at" : "2014-03-23 02:02:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/eDKtGhDbLK",
      "expanded_url" : "http:\/\/go.wh.gov\/ve27in",
      "display_url" : "go.wh.gov\/ve27in"
    } ]
  },
  "geo" : { },
  "id_str" : "447432550143627264",
  "text" : "\"Too many women face outdated workplace policies that hold them back\u2014which holds back...our entire economy.\" \u2014Obama: http:\/\/t.co\/eDKtGhDbLK",
  "id" : 447432550143627264,
  "created_at" : "2014-03-22 18:00:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 26, 35 ]
    }, {
      "text" : "WomenSucceed",
      "indices" : [ 99, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/p7GarHNMFk",
      "expanded_url" : "http:\/\/go.wh.gov\/SnSrDw",
      "display_url" : "go.wh.gov\/SnSrDw"
    } ]
  },
  "geo" : { },
  "id_str" : "447409900893659136",
  "text" : "\"A woman deserves to earn #EqualPay for equal work.\" \u2014President Obama on steps we can take to help #WomenSucceed: http:\/\/t.co\/p7GarHNMFk",
  "id" : 447409900893659136,
  "created_at" : "2014-03-22 16:30:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 111, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/nDADtPHYNv",
      "expanded_url" : "http:\/\/go.wh.gov\/v4cm5P",
      "display_url" : "go.wh.gov\/v4cm5P"
    } ]
  },
  "geo" : { },
  "id_str" : "447385765304365056",
  "text" : "President Obama's Weekly Address: Rewarding hard work and increasing the minimum wage \u2192 http:\/\/t.co\/nDADtPHYNv #RaiseTheWage",
  "id" : 447385765304365056,
  "created_at" : "2014-03-22 14:54:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "indices" : [ 1, 10 ],
      "id_str" : "1604366701",
      "id" : 1604366701
    }, {
      "name" : "SHAKE SHACK",
      "screen_name" : "shakeshack",
      "indices" : [ 24, 35 ],
      "id_str" : "212255045",
      "id" : 212255045
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/LaborSec\/status\/447117177183674368\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/obnJTzKfD3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BjR6tCeCIAAe0k3.jpg",
      "id_str" : "447117177192062976",
      "id" : 447117177192062976,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjR6tCeCIAAe0k3.jpg",
      "sizes" : [ {
        "h" : 494,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 494,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 463,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 262,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/obnJTzKfD3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "447174368247152640",
  "text" : ".@LaborSec stopped by a @ShakeShack to highlight how they're raising their employees' wages\u2014and eat a tasty burger. http:\/\/t.co\/obnJTzKfD3",
  "id" : 447174368247152640,
  "created_at" : "2014-03-22 00:54:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "America Ferrera",
      "screen_name" : "AmericaFerrera",
      "indices" : [ 74, 89 ],
      "id_str" : "531561605",
      "id" : 531561605
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCoveredNow",
      "indices" : [ 114, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/G6s5izNX1v",
      "expanded_url" : "http:\/\/youtu.be\/ZVVxp-dVHhI",
      "display_url" : "youtu.be\/ZVVxp-dVHhI"
    } ]
  },
  "geo" : { },
  "id_str" : "447135175156465664",
  "text" : "\"As a woman, having health care has been an enormous sense of security.\" \u2014@AmericaFerrera: http:\/\/t.co\/G6s5izNX1v #GetCoveredNow",
  "id" : 447135175156465664,
  "created_at" : "2014-03-21 22:18:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill de Blasio",
      "screen_name" : "BilldeBlasio",
      "indices" : [ 3, 16 ],
      "id_str" : "476193064",
      "id" : 476193064
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PaidSickDays",
      "indices" : [ 18, 31 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/9zbVFRfQql",
      "expanded_url" : "http:\/\/on.nyc.gov\/1j88YYc",
      "display_url" : "on.nyc.gov\/1j88YYc"
    } ]
  },
  "geo" : { },
  "id_str" : "447118369230442496",
  "text" : "RT @BilldeBlasio: #PaidSickDays law is the first of many steps we\u2019re taking to address inequality in this city. http:\/\/t.co\/9zbVFRfQql http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BilldeBlasio\/status\/446720116487503872\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/BJ1qkqNRnh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BjMRlCfCcAAlojg.jpg",
        "id_str" : "446720116059697152",
        "id" : 446720116059697152,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjMRlCfCcAAlojg.jpg",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/BJ1qkqNRnh"
      } ],
      "hashtags" : [ {
        "text" : "PaidSickDays",
        "indices" : [ 0, 13 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/9zbVFRfQql",
        "expanded_url" : "http:\/\/on.nyc.gov\/1j88YYc",
        "display_url" : "on.nyc.gov\/1j88YYc"
      } ]
    },
    "geo" : { },
    "id_str" : "446720116487503872",
    "text" : "#PaidSickDays law is the first of many steps we\u2019re taking to address inequality in this city. http:\/\/t.co\/9zbVFRfQql http:\/\/t.co\/BJ1qkqNRnh",
    "id" : 446720116487503872,
    "created_at" : "2014-03-20 18:49:10 +0000",
    "user" : {
      "name" : "Bill de Blasio",
      "screen_name" : "NYCMayor",
      "protected" : false,
      "id_str" : "19834403",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797104781974192128\/xv2CMcBu_normal.jpg",
      "id" : 19834403,
      "verified" : true
    }
  },
  "id" : 447118369230442496,
  "created_at" : "2014-03-21 21:11:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 110, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/ADqcPLt8yP",
      "expanded_url" : "http:\/\/go.wh.gov\/nTdjCG",
      "display_url" : "go.wh.gov\/nTdjCG"
    } ]
  },
  "geo" : { },
  "id_str" : "447102609196056576",
  "text" : "Good news: 7.9 million people with Medicare have saved nearly $10 billion on prescription drugs thanks to the #ACA \u2192 http:\/\/t.co\/ADqcPLt8yP",
  "id" : 447102609196056576,
  "created_at" : "2014-03-21 20:09:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/447086788276805632\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/M4WHiESyGL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BjRfEJ7CEAALFmY.jpg",
      "id_str" : "447086788004155392",
      "id" : 447086788004155392,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjRfEJ7CEAALFmY.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/M4WHiESyGL"
    } ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 14, 18 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/PLARIHrqKc",
      "expanded_url" : "http:\/\/hc.gov\/SSmVER",
      "display_url" : "hc.gov\/SSmVER"
    } ]
  },
  "geo" : { },
  "id_str" : "447086788276805632",
  "text" : "Thanks to the #ACA, more than 5 million Americans have signed up for private coverage \u2192 http:\/\/t.co\/PLARIHrqKc, http:\/\/t.co\/M4WHiESyGL",
  "id" : 447086788276805632,
  "created_at" : "2014-03-21 19:06:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/447062446604173312\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/ZRE3XtT6YQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BjRI7SJCIAEWH1x.jpg",
      "id_str" : "447062446335729665",
      "id" : 447062446335729665,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjRI7SJCIAEWH1x.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ZRE3XtT6YQ"
    } ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 14, 18 ]
    }, {
      "text" : "GetCoveredNow",
      "indices" : [ 46, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/PLARIHrqKc",
      "expanded_url" : "http:\/\/hc.gov\/SSmVER",
      "display_url" : "hc.gov\/SSmVER"
    } ]
  },
  "geo" : { },
  "id_str" : "447062446604173312",
  "text" : "Thanks to the #ACA, millions of Americans can #GetCoveredNow for $100\/month or less \u2192 http:\/\/t.co\/PLARIHrqKc, http:\/\/t.co\/ZRE3XtT6YQ",
  "id" : 447062446604173312,
  "created_at" : "2014-03-21 17:29:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/447042342185234433\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/euIA1SPeWa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BjQ2pDLCUAANfk-.jpg",
      "id_str" : "447042341870653440",
      "id" : 447042341870653440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjQ2pDLCUAANfk-.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/euIA1SPeWa"
    } ],
    "hashtags" : [ {
      "text" : "10DaysLeft",
      "indices" : [ 0, 11 ]
    }, {
      "text" : "GetCoveredNow",
      "indices" : [ 99, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/O6JK6yYQdy",
      "expanded_url" : "http:\/\/hc.gov\/BrutCg",
      "display_url" : "hc.gov\/BrutCg"
    } ]
  },
  "geo" : { },
  "id_str" : "447042342185234433",
  "text" : "#10DaysLeft to get 2014 health coverage.\nDon't wait!\n\u270D up for a plan here \u2192 http:\/\/t.co\/O6JK6yYQdy\n#GetCoveredNow, http:\/\/t.co\/euIA1SPeWa",
  "id" : 447042342185234433,
  "created_at" : "2014-03-21 16:09:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/447035601074679809\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/jqh3QIaIyE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BjQwgqlCcAAeucz.jpg",
      "id_str" : "447035600760107008",
      "id" : 447035600760107008,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjQwgqlCcAAeucz.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/jqh3QIaIyE"
    } ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 22, 26 ]
    }, {
      "text" : "GetCoveredNow",
      "indices" : [ 98, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/O6JK6yYQdy",
      "expanded_url" : "http:\/\/hc.gov\/BrutCg",
      "display_url" : "hc.gov\/BrutCg"
    } ]
  },
  "geo" : { },
  "id_str" : "447035601074679809",
  "text" : "Four years later, the #ACA is strengthening health coverage for millions \u2192 http:\/\/t.co\/O6JK6yYQdy #GetCoveredNow http:\/\/t.co\/jqh3QIaIyE",
  "id" : 447035601074679809,
  "created_at" : "2014-03-21 15:42:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "447023601183891456",
  "text" : "RT @FLOTUS: Go \"On Board\" with the First Lady in China as she visits a robotics class in Beijing &amp; tours the Forbidden City \u2192 http:\/\/t.co\/3\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/3EAAXO5kFl",
        "expanded_url" : "http:\/\/youtu.be\/s9f7IOWBPjM",
        "display_url" : "youtu.be\/s9f7IOWBPjM"
      } ]
    },
    "geo" : { },
    "id_str" : "447023186992173056",
    "text" : "Go \"On Board\" with the First Lady in China as she visits a robotics class in Beijing &amp; tours the Forbidden City \u2192 http:\/\/t.co\/3EAAXO5kFl",
    "id" : 447023186992173056,
    "created_at" : "2014-03-21 14:53:27 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 447023601183891456,
  "created_at" : "2014-03-21 14:55:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Viagra n tayac. Dagr",
      "screen_name" : "DagVega44",
      "indices" : [ 3, 13 ],
      "id_str" : "2785789802",
      "id" : 2785789802
    }, {
      "name" : "UConn Women's Hoops",
      "screen_name" : "UConnWBB",
      "indices" : [ 38, 47 ],
      "id_str" : "242785840",
      "id" : 242785840
    }, {
      "name" : "Rebecca Lobo",
      "screen_name" : "RebeccaLobo",
      "indices" : [ 96, 108 ],
      "id_str" : "22957302",
      "id" : 22957302
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WomenSucceed",
      "indices" : [ 63, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "447017329395003392",
  "text" : "RT @DagVega44: President Obama picked @UConnWBB to win it all. #WomenSucceed Watch interview w\/ @RebeccaLobo via ESPN \u2192 http:\/\/t.co\/WKMv0RM\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "UConn Women's Hoops",
        "screen_name" : "UConnWBB",
        "indices" : [ 23, 32 ],
        "id_str" : "242785840",
        "id" : 242785840
      }, {
        "name" : "Rebecca Lobo",
        "screen_name" : "RebeccaLobo",
        "indices" : [ 81, 93 ],
        "id_str" : "22957302",
        "id" : 22957302
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WomenSucceed",
        "indices" : [ 48, 61 ]
      } ],
      "urls" : [ {
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/WKMv0RMtlw",
        "expanded_url" : "http:\/\/es.pn\/1kPqPk7",
        "display_url" : "es.pn\/1kPqPk7"
      } ]
    },
    "geo" : { },
    "id_str" : "447016465502601216",
    "text" : "President Obama picked @UConnWBB to win it all. #WomenSucceed Watch interview w\/ @RebeccaLobo via ESPN \u2192 http:\/\/t.co\/WKMv0RMtlw",
    "id" : 447016465502601216,
    "created_at" : "2014-03-21 14:26:45 +0000",
    "user" : {
      "name" : "Rob O'Donnell",
      "screen_name" : "RODonnell44",
      "protected" : false,
      "id_str" : "1873091689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/664483086738952192\/UukL2zFT_normal.jpg",
      "id" : 1873091689,
      "verified" : true
    }
  },
  "id" : 447017329395003392,
  "created_at" : "2014-03-21 14:30:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SHAQ",
      "screen_name" : "SHAQ",
      "indices" : [ 3, 8 ],
      "id_str" : "17461978",
      "id" : 17461978
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCoveredNow",
      "indices" : [ 54, 68 ]
    } ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/oIZfnicjyb",
      "expanded_url" : "http:\/\/healthcare.gov",
      "display_url" : "healthcare.gov"
    }, {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/0QV3AchavJ",
      "expanded_url" : "http:\/\/instagram.com\/p\/lx-8M0C-Uo\/",
      "display_url" : "instagram.com\/p\/lx-8M0C-Uo\/"
    } ]
  },
  "geo" : { },
  "id_str" : "446835646133714944",
  "text" : "RT @SHAQ: Chuck has a message  http:\/\/t.co\/oIZfnicjyb #GetCoveredNow http:\/\/t.co\/0QV3AchavJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCoveredNow",
        "indices" : [ 44, 58 ]
      } ],
      "urls" : [ {
        "indices" : [ 21, 43 ],
        "url" : "http:\/\/t.co\/oIZfnicjyb",
        "expanded_url" : "http:\/\/healthcare.gov",
        "display_url" : "healthcare.gov"
      }, {
        "indices" : [ 59, 81 ],
        "url" : "http:\/\/t.co\/0QV3AchavJ",
        "expanded_url" : "http:\/\/instagram.com\/p\/lx-8M0C-Uo\/",
        "display_url" : "instagram.com\/p\/lx-8M0C-Uo\/"
      } ]
    },
    "geo" : { },
    "id_str" : "446807870395645953",
    "text" : "Chuck has a message  http:\/\/t.co\/oIZfnicjyb #GetCoveredNow http:\/\/t.co\/0QV3AchavJ",
    "id" : 446807870395645953,
    "created_at" : "2014-03-21 00:37:52 +0000",
    "user" : {
      "name" : "SHAQ",
      "screen_name" : "SHAQ",
      "protected" : false,
      "id_str" : "17461978",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1673907275\/image_normal.jpg",
      "id" : 17461978,
      "verified" : true
    }
  },
  "id" : 446835646133714944,
  "created_at" : "2014-03-21 02:28:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/446787905831190528\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/PPuw548vzq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BjNPO6VCMAARLQu.jpg",
      "id_str" : "446787905634054144",
      "id" : 446787905634054144,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjNPO6VCMAARLQu.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      } ],
      "display_url" : "pic.twitter.com\/PPuw548vzq"
    } ],
    "hashtags" : [ {
      "text" : "WomenSucceed",
      "indices" : [ 77, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/YD6JsEqsGt",
      "expanded_url" : "http:\/\/go.wh.gov\/W54KgV",
      "display_url" : "go.wh.gov\/W54KgV"
    } ]
  },
  "geo" : { },
  "id_str" : "446787905831190528",
  "text" : "\"If men were having babies, we'd have different policies.\" \u2014Obama on helping #WomenSucceed: http:\/\/t.co\/YD6JsEqsGt, http:\/\/t.co\/PPuw548vzq",
  "id" : 446787905831190528,
  "created_at" : "2014-03-20 23:18:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stevie Johnson",
      "screen_name" : "StevieJohnson13",
      "indices" : [ 3, 19 ],
      "id_str" : "119234601",
      "id" : 119234601
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCoveredNow",
      "indices" : [ 21, 35 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/d1K1bx2q4B",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "446766123145764864",
  "text" : "RT @StevieJohnson13: #GetCoveredNow because you just never know. Get here, now - http:\/\/t.co\/d1K1bx2q4B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCoveredNow",
        "indices" : [ 0, 14 ]
      } ],
      "urls" : [ {
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/d1K1bx2q4B",
        "expanded_url" : "http:\/\/Healthcare.gov",
        "display_url" : "Healthcare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "446713813664948224",
    "text" : "#GetCoveredNow because you just never know. Get here, now - http:\/\/t.co\/d1K1bx2q4B",
    "id" : 446713813664948224,
    "created_at" : "2014-03-20 18:24:07 +0000",
    "user" : {
      "name" : "Stevie Johnson",
      "screen_name" : "StevieJohnson13",
      "protected" : false,
      "id_str" : "119234601",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/792472441389846528\/CSjQm73c_normal.jpg",
      "id" : 119234601,
      "verified" : true
    }
  },
  "id" : 446766123145764864,
  "created_at" : "2014-03-20 21:51:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/446751391126544384\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/DFmUEEnQu5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BjMuBedCIAAOTk9.png",
      "id_str" : "446751390929395712",
      "id" : 446751390929395712,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjMuBedCIAAOTk9.png",
      "sizes" : [ {
        "h" : 623,
        "resize" : "fit",
        "w" : 761
      }, {
        "h" : 278,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 623,
        "resize" : "fit",
        "w" : 761
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 491,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/DFmUEEnQu5"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 27, 38 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/BU6bN2m0mi",
      "expanded_url" : "http:\/\/go.wh.gov\/bnYUFF",
      "display_url" : "go.wh.gov\/bnYUFF"
    } ]
  },
  "geo" : { },
  "id_str" : "446751391126544384",
  "text" : "The 16 sweetest reasons to #GetCovered have been narrowed down to 2. Vote to decide it all \u2192 http:\/\/t.co\/BU6bN2m0mi, http:\/\/t.co\/DFmUEEnQu5",
  "id" : 446751391126544384,
  "created_at" : "2014-03-20 20:53:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Wall",
      "screen_name" : "john_wall",
      "indices" : [ 3, 13 ],
      "id_str" : "2819975036",
      "id" : 2819975036
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCoveredNow",
      "indices" : [ 15, 29 ]
    } ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/kCAmpsQS3O",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "446739736695406592",
  "text" : "RT @John_Wall: #GetCoveredNow http:\/\/t.co\/kCAmpsQS3O",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCoveredNow",
        "indices" : [ 0, 14 ]
      } ],
      "urls" : [ {
        "indices" : [ 15, 37 ],
        "url" : "http:\/\/t.co\/kCAmpsQS3O",
        "expanded_url" : "http:\/\/Healthcare.gov",
        "display_url" : "Healthcare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "446727411976007680",
    "text" : "#GetCoveredNow http:\/\/t.co\/kCAmpsQS3O",
    "id" : 446727411976007680,
    "created_at" : "2014-03-20 19:18:09 +0000",
    "user" : {
      "name" : "John Wall",
      "screen_name" : "JohnWall",
      "protected" : false,
      "id_str" : "132389474",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/784977425331519488\/VnkNirZw_normal.jpg",
      "id" : 132389474,
      "verified" : true
    }
  },
  "id" : 446739736695406592,
  "created_at" : "2014-03-20 20:07:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DWade",
      "screen_name" : "DwyaneWade",
      "indices" : [ 3, 14 ],
      "id_str" : "33995409",
      "id" : 33995409
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCoveredNow",
      "indices" : [ 66, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/88lTzD61PB",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "446735475257397249",
  "text" : "RT @DwyaneWade: Don't let huge medical bills keep u on the bench. #GetCoveredNow by signing up for health coverage \u2192 http:\/\/t.co\/88lTzD61PB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCoveredNow",
        "indices" : [ 50, 64 ]
      } ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/88lTzD61PB",
        "expanded_url" : "http:\/\/Healthcare.gov",
        "display_url" : "Healthcare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "446731161700540416",
    "text" : "Don't let huge medical bills keep u on the bench. #GetCoveredNow by signing up for health coverage \u2192 http:\/\/t.co\/88lTzD61PB",
    "id" : 446731161700540416,
    "created_at" : "2014-03-20 19:33:03 +0000",
    "user" : {
      "name" : "DWade",
      "screen_name" : "DwyaneWade",
      "protected" : false,
      "id_str" : "33995409",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2722827188\/90ede922ff595304402c10221fb5f346_normal.jpeg",
      "id" : 33995409,
      "verified" : true
    }
  },
  "id" : 446735475257397249,
  "created_at" : "2014-03-20 19:50:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446731165748060160",
  "text" : "President Obama: \"Whether you\u2019re black, white, Latino, Asian, Native American, gay, straight...all of us have a place in the American story\"",
  "id" : 446731165748060160,
  "created_at" : "2014-03-20 19:33:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 100, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/B5fuar0clw",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "446729945252118528",
  "text" : "RT @WHLive: Obama: \"Check out your new choices at http:\/\/t.co\/B5fuar0clw\u2014many of you may be able to #GetCovered for $100\/month or less.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 88, 99 ]
      } ],
      "urls" : [ {
        "indices" : [ 38, 60 ],
        "url" : "http:\/\/t.co\/B5fuar0clw",
        "expanded_url" : "http:\/\/HealthCare.gov",
        "display_url" : "HealthCare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "446729321152266240",
    "text" : "Obama: \"Check out your new choices at http:\/\/t.co\/B5fuar0clw\u2014many of you may be able to #GetCovered for $100\/month or less.\"",
    "id" : 446729321152266240,
    "created_at" : "2014-03-20 19:25:44 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 446729945252118528,
  "created_at" : "2014-03-20 19:28:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCoveredNow",
      "indices" : [ 100, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446728321062416384",
  "text" : "\"No woman can ever again be charged more just for being a woman.\" \u2014Obama on the Affordable Care Act #GetCoveredNow",
  "id" : 446728321062416384,
  "created_at" : "2014-03-20 19:21:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WomenSucceed",
      "indices" : [ 91, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446727640683397120",
  "text" : "President Obama: \"It\u2019s time to give every woman the opportunity she deserves, because when #WomenSucceed, America succeeds.\"",
  "id" : 446727640683397120,
  "created_at" : "2014-03-20 19:19:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 116, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446727410147663872",
  "text" : "\"It\u2019s time to do away with workplace policies that belong in a \u201CMad Men\u201D episode.\" \u2014Obama on making sure women earn #EqualPay for equal work",
  "id" : 446727410147663872,
  "created_at" : "2014-03-20 19:18:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 128, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446726684054921216",
  "text" : "Obama: \"It\u2019s time for a women\u2019s economic agenda that grows our economy for everyone. That begins with making sure women receive #EqualPay.\"",
  "id" : 446726684054921216,
  "created_at" : "2014-03-20 19:15:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/446726274233290752\/photo\/1",
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/yMgNiR6H8q",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BjMXLexCQAAA80k.jpg",
      "id_str" : "446726274044542976",
      "id" : 446726274044542976,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjMXLexCQAAA80k.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/yMgNiR6H8q"
    } ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 77, 86 ]
    }, {
      "text" : "WomenSucceed",
      "indices" : [ 87, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446726274233290752",
  "text" : "President Obama: \"When women make less than men, that hurts their families.\" #EqualPay #WomenSucceed http:\/\/t.co\/yMgNiR6H8q",
  "id" : 446726274233290752,
  "created_at" : "2014-03-20 19:13:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 96, 105 ]
    }, {
      "text" : "WomenSucceed",
      "indices" : [ 106, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446725863342878720",
  "text" : "President Obama: \u201CI want to make sure our daughters are getting the same opportunities as men.\u201D #EqualPay #WomenSucceed",
  "id" : 446725863342878720,
  "created_at" : "2014-03-20 19:12:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WomenSucceed",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446725493745016832",
  "text" : "Obama: \u201CI\u2019ve got a personal stake in seeing women get ahead...women make up 80% of my household\u2014if you count my mother-in-law\u201D #WomenSucceed",
  "id" : 446725493745016832,
  "created_at" : "2014-03-20 19:10:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/446724445869060097\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/BBw3TTbY7N",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BjMVhDrCUAExbCL.jpg",
      "id_str" : "446724445705490433",
      "id" : 446724445705490433,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjMVhDrCUAExbCL.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/BBw3TTbY7N"
    } ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 96, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446724445869060097",
  "text" : "Obama: \"We\u2019ve seen our businesses create more than 8.7 million new jobs over the past 4 years.\" #OpportunityForAll http:\/\/t.co\/BBw3TTbY7N",
  "id" : 446724445869060097,
  "created_at" : "2014-03-20 19:06:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WomenSucceed",
      "indices" : [ 130, 143 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/ngeIEi1V1V",
      "expanded_url" : "http:\/\/go.wh.gov\/c8HgPo",
      "display_url" : "go.wh.gov\/c8HgPo"
    } ]
  },
  "geo" : { },
  "id_str" : "446723550750453760",
  "text" : "Happening now: President Obama speaks on improving economic opportunity for women &amp; working families \u2192 http:\/\/t.co\/ngeIEi1V1V #WomenSucceed",
  "id" : 446723550750453760,
  "created_at" : "2014-03-20 19:02:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "indices" : [ 3, 13 ],
      "id_str" : "1613223313",
      "id" : 1613223313
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446721097254592512",
  "text" : "RT @Cecilia44: Starting soon: Don't miss President Obama speak on improving opportunity for women &amp; working families \u2192 http:\/\/t.co\/zCS55d3H\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WomenSucceed",
        "indices" : [ 131, 144 ]
      } ],
      "urls" : [ {
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/zCS55d3Hk8",
        "expanded_url" : "http:\/\/go.wh.gov\/c8HgPo",
        "display_url" : "go.wh.gov\/c8HgPo"
      } ]
    },
    "geo" : { },
    "id_str" : "446719744830611456",
    "text" : "Starting soon: Don't miss President Obama speak on improving opportunity for women &amp; working families \u2192 http:\/\/t.co\/zCS55d3Hk8 #WomenSucceed",
    "id" : 446719744830611456,
    "created_at" : "2014-03-20 18:47:41 +0000",
    "user" : {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "protected" : false,
      "id_str" : "1613223313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000172019215\/ed65eda76f51213f91b33edbaa62054c_normal.jpeg",
      "id" : 1613223313,
      "verified" : true
    }
  },
  "id" : 446721097254592512,
  "created_at" : "2014-03-20 18:53:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emmitt Smith",
      "screen_name" : "EmmittSmith22",
      "indices" : [ 3, 17 ],
      "id_str" : "84092181",
      "id" : 84092181
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCoveredNow",
      "indices" : [ 104, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446719521186127872",
  "text" : "RT @EmmittSmith22: Gator fans, don't let an injury chomp on your bank acct. You are not indestructible. #GetCoveredNow http:\/\/t.co\/2FLY1lPb\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCoveredNow",
        "indices" : [ 85, 99 ]
      }, {
        "text" : "GatorsGetCovered",
        "indices" : [ 123, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/2FLY1lPbfF",
        "expanded_url" : "http:\/\/Healthcare.gov",
        "display_url" : "Healthcare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "446716318100639745",
    "text" : "Gator fans, don't let an injury chomp on your bank acct. You are not indestructible. #GetCoveredNow http:\/\/t.co\/2FLY1lPbfF #GatorsGetCovered",
    "id" : 446716318100639745,
    "created_at" : "2014-03-20 18:34:04 +0000",
    "user" : {
      "name" : "Emmitt Smith",
      "screen_name" : "EmmittSmith22",
      "protected" : false,
      "id_str" : "84092181",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725414852898910208\/6TMOokDX_normal.jpg",
      "id" : 84092181,
      "verified" : true
    }
  },
  "id" : 446719521186127872,
  "created_at" : "2014-03-20 18:46:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Ortiz",
      "screen_name" : "davidortiz",
      "indices" : [ 3, 14 ],
      "id_str" : "28153561",
      "id" : 28153561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/O0xuVdXgkU",
      "expanded_url" : "http:\/\/healthcare.gov",
      "display_url" : "healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "446715169197260800",
  "text" : "RT @davidortiz: Even the biggest stars in the game get injured. Make sure you're covered in case you do too, http:\/\/t.co\/O0xuVdXgkU #GetCov\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCoveredNow",
        "indices" : [ 116, 130 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/O0xuVdXgkU",
        "expanded_url" : "http:\/\/healthcare.gov",
        "display_url" : "healthcare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "446709408014544896",
    "text" : "Even the biggest stars in the game get injured. Make sure you're covered in case you do too, http:\/\/t.co\/O0xuVdXgkU #GetCoveredNow",
    "id" : 446709408014544896,
    "created_at" : "2014-03-20 18:06:36 +0000",
    "user" : {
      "name" : "David Ortiz",
      "screen_name" : "davidortiz",
      "protected" : false,
      "id_str" : "28153561",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738584752731521028\/-VzN6jfz_normal.jpg",
      "id" : 28153561,
      "verified" : true
    }
  },
  "id" : 446715169197260800,
  "created_at" : "2014-03-20 18:29:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carmelo Anthony",
      "screen_name" : "carmeloanthony",
      "indices" : [ 3, 18 ],
      "id_str" : "42384760",
      "id" : 42384760
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/carmeloanthony\/status\/446708107612127232\/photo\/1",
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/PG7UKFO0eu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BjMGqDkCAAAP6Ot.png",
      "id_str" : "446708107620515840",
      "id" : 446708107620515840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjMGqDkCAAAP6Ot.png",
      "sizes" : [ {
        "h" : 341,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 607,
        "resize" : "fit",
        "w" : 606
      }, {
        "h" : 601,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 607,
        "resize" : "fit",
        "w" : 606
      } ],
      "display_url" : "pic.twitter.com\/PG7UKFO0eu"
    } ],
    "hashtags" : [ {
      "text" : "GetCoveredNow",
      "indices" : [ 20, 34 ]
    } ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/0qaOncxWnU",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "446710667916345344",
  "text" : "RT @carmeloanthony: #GetCoveredNow http:\/\/t.co\/0qaOncxWnU http:\/\/t.co\/PG7UKFO0eu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/carmeloanthony\/status\/446708107612127232\/photo\/1",
        "indices" : [ 38, 60 ],
        "url" : "http:\/\/t.co\/PG7UKFO0eu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BjMGqDkCAAAP6Ot.png",
        "id_str" : "446708107620515840",
        "id" : 446708107620515840,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjMGqDkCAAAP6Ot.png",
        "sizes" : [ {
          "h" : 341,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 607,
          "resize" : "fit",
          "w" : 606
        }, {
          "h" : 601,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 607,
          "resize" : "fit",
          "w" : 606
        } ],
        "display_url" : "pic.twitter.com\/PG7UKFO0eu"
      } ],
      "hashtags" : [ {
        "text" : "GetCoveredNow",
        "indices" : [ 0, 14 ]
      } ],
      "urls" : [ {
        "indices" : [ 15, 37 ],
        "url" : "http:\/\/t.co\/0qaOncxWnU",
        "expanded_url" : "http:\/\/Healthcare.gov",
        "display_url" : "Healthcare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "446708107612127232",
    "text" : "#GetCoveredNow http:\/\/t.co\/0qaOncxWnU http:\/\/t.co\/PG7UKFO0eu",
    "id" : 446708107612127232,
    "created_at" : "2014-03-20 18:01:27 +0000",
    "user" : {
      "name" : "Carmelo Anthony",
      "screen_name" : "carmeloanthony",
      "protected" : false,
      "id_str" : "42384760",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/482353084727705600\/fHpCALIP_normal.jpeg",
      "id" : 42384760,
      "verified" : true
    }
  },
  "id" : 446710667916345344,
  "created_at" : "2014-03-20 18:11:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "11DaysLeft",
      "indices" : [ 74, 85 ]
    }, {
      "text" : "GetCoveredNow",
      "indices" : [ 89, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/6wbUjnMxuX",
      "expanded_url" : "http:\/\/bit.ly\/1kLPwxY",
      "display_url" : "bit.ly\/1kLPwxY"
    }, {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/OslrHF9ucM",
      "expanded_url" : "http:\/\/hc.gov\/kGhV4s",
      "display_url" : "hc.gov\/kGhV4s"
    } ]
  },
  "geo" : { },
  "id_str" : "446696898188304384",
  "text" : "\"Pro athletes come out in force for Obamacare.\" \u2192 http:\/\/t.co\/6wbUjnMxuX\n\n#11DaysLeft to #GetCoveredNow \u2192 http:\/\/t.co\/OslrHF9ucM",
  "id" : 446696898188304384,
  "created_at" : "2014-03-20 17:16:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "STEM",
      "indices" : [ 33, 38 ]
    }, {
      "text" : "WeTheGeeks",
      "indices" : [ 66, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446690438746234880",
  "text" : "RT @WHLive: No leading ladies in #STEM? Myth busted! Join today's #WeTheGeeks Hangout on Women Role Models at 1pm ET \u2192 http:\/\/t.co\/mVWsThbX\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "STEM",
        "indices" : [ 21, 26 ]
      }, {
        "text" : "WeTheGeeks",
        "indices" : [ 54, 65 ]
      } ],
      "urls" : [ {
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/mVWsThbXyS",
        "expanded_url" : "http:\/\/goo.gl\/NpvIjN",
        "display_url" : "goo.gl\/NpvIjN"
      } ]
    },
    "geo" : { },
    "id_str" : "446690368541958144",
    "text" : "No leading ladies in #STEM? Myth busted! Join today's #WeTheGeeks Hangout on Women Role Models at 1pm ET \u2192 http:\/\/t.co\/mVWsThbXyS",
    "id" : 446690368541958144,
    "created_at" : "2014-03-20 16:50:57 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 446690438746234880,
  "created_at" : "2014-03-20 16:51:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Collins",
      "screen_name" : "jasoncollins34",
      "indices" : [ 3, 18 ],
      "id_str" : "1278613015",
      "id" : 1278613015
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/mjoUu14Uc2",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "446686858886795264",
  "text" : "RT @jasoncollins34: Don't let huge medical bills keep you on the bench. Make sure you sign up for health coverage. http:\/\/t.co\/mjoUu14Uc2\u00A0#\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCoveredNow",
        "indices" : [ 118, 132 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/mjoUu14Uc2",
        "expanded_url" : "http:\/\/Healthcare.gov",
        "display_url" : "Healthcare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "446674246996344832",
    "text" : "Don't let huge medical bills keep you on the bench. Make sure you sign up for health coverage. http:\/\/t.co\/mjoUu14Uc2\u00A0#GetCoveredNow",
    "id" : 446674246996344832,
    "created_at" : "2014-03-20 15:46:53 +0000",
    "user" : {
      "name" : "Jason Collins",
      "screen_name" : "jasoncollins98",
      "protected" : false,
      "id_str" : "500436115",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/619210767976501248\/4qV6JHW2_normal.jpg",
      "id" : 500436115,
      "verified" : true
    }
  },
  "id" : 446686858886795264,
  "created_at" : "2014-03-20 16:37:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/446682038574120960\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/t5hKLFcM1P",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BjLu8n1CIAAvciS.png",
      "id_str" : "446682038314082304",
      "id" : 446682038314082304,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjLu8n1CIAAvciS.png",
      "sizes" : [ {
        "h" : 954,
        "resize" : "fit",
        "w" : 804
      }, {
        "h" : 712,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 954,
        "resize" : "fit",
        "w" : 804
      }, {
        "h" : 403,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/t5hKLFcM1P"
    } ],
    "hashtags" : [ {
      "text" : "GetCoveredNow",
      "indices" : [ 61, 75 ]
    }, {
      "text" : "MarchMadness",
      "indices" : [ 101, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/3JqJiKqgYX",
      "expanded_url" : "http:\/\/go.wh.gov\/T8grkv",
      "display_url" : "go.wh.gov\/T8grkv"
    } ]
  },
  "geo" : { },
  "id_str" : "446682038574120960",
  "text" : "Can't wait for the Final Four? Vote for the top 2 reasons to #GetCoveredNow \u2192 http:\/\/t.co\/3JqJiKqgYX #MarchMadness, http:\/\/t.co\/t5hKLFcM1P",
  "id" : 446682038574120960,
  "created_at" : "2014-03-20 16:17:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Durant",
      "screen_name" : "KDTrey5",
      "indices" : [ 3, 11 ],
      "id_str" : "35936474",
      "id" : 35936474
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MarchMadness",
      "indices" : [ 25, 38 ]
    }, {
      "text" : "GetCoveredNow",
      "indices" : [ 78, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/PZWLWRITnT",
      "expanded_url" : "http:\/\/whitehouse.gov\/ACABracket",
      "display_url" : "whitehouse.gov\/ACABracket"
    } ]
  },
  "geo" : { },
  "id_str" : "446678199721013248",
  "text" : "RT @KDTrey5: New kind of #MarchMadness - Check out the 16 sweetest reasons to #GetCoveredNow http:\/\/t.co\/PZWLWRITnT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MarchMadness",
        "indices" : [ 12, 25 ]
      }, {
        "text" : "GetCoveredNow",
        "indices" : [ 65, 79 ]
      } ],
      "urls" : [ {
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/PZWLWRITnT",
        "expanded_url" : "http:\/\/whitehouse.gov\/ACABracket",
        "display_url" : "whitehouse.gov\/ACABracket"
      } ]
    },
    "geo" : { },
    "id_str" : "446666165965058048",
    "text" : "New kind of #MarchMadness - Check out the 16 sweetest reasons to #GetCoveredNow http:\/\/t.co\/PZWLWRITnT",
    "id" : 446666165965058048,
    "created_at" : "2014-03-20 15:14:47 +0000",
    "user" : {
      "name" : "Kevin Durant",
      "screen_name" : "KDTrey5",
      "protected" : false,
      "id_str" : "35936474",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/677535982141333504\/nL7RupTY_normal.jpg",
      "id" : 35936474,
      "verified" : true
    }
  },
  "id" : 446678199721013248,
  "created_at" : "2014-03-20 16:02:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ukraine",
      "indices" : [ 80, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446665444087595008",
  "text" : "President Obama: \"We want the Ukrainian people to determine their own destiny.\" #Ukraine",
  "id" : 446665444087595008,
  "created_at" : "2014-03-20 15:11:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ukraine",
      "indices" : [ 112, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446665355600330752",
  "text" : "RT @WHLive: President Obama: \"Russia still has a different path available\u2014one that de-escalates the situation.\" #Ukraine",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Ukraine",
        "indices" : [ 100, 108 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "446665176612622336",
    "text" : "President Obama: \"Russia still has a different path available\u2014one that de-escalates the situation.\" #Ukraine",
    "id" : 446665176612622336,
    "created_at" : "2014-03-20 15:10:51 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 446665355600330752,
  "created_at" : "2014-03-20 15:11:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ukraine",
      "indices" : [ 123, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446664382752518144",
  "text" : "President Obama: \"Russia must know that further escalation will only isolate it further from the international community.\" #Ukraine",
  "id" : 446664382752518144,
  "created_at" : "2014-03-20 15:07:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ukraine",
      "indices" : [ 113, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446663932326195200",
  "text" : "President Obama: \"The United States is today moving, as we said we would, to impose additional costs on Russia.\" #Ukraine",
  "id" : 446663932326195200,
  "created_at" : "2014-03-20 15:05:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ukraine",
      "indices" : [ 58, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/wnMGtCxqvH",
      "expanded_url" : "http:\/\/go.wh.gov\/nBRTjD",
      "display_url" : "go.wh.gov\/nBRTjD"
    } ]
  },
  "geo" : { },
  "id_str" : "446663688947519489",
  "text" : "Happening now: President Obama speaks on the situation in #Ukraine. Watch \u2192 http:\/\/t.co\/wnMGtCxqvH",
  "id" : 446663688947519489,
  "created_at" : "2014-03-20 15:04:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ukraine",
      "indices" : [ 55, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/ZgwEzZpLda",
      "expanded_url" : "http:\/\/go.wh.gov\/nBRTjD",
      "display_url" : "go.wh.gov\/nBRTjD"
    } ]
  },
  "geo" : { },
  "id_str" : "446654916136669185",
  "text" : "At 11am ET, President Obama speaks on the situation in #Ukraine. Watch \u2192 http:\/\/t.co\/ZgwEzZpLda",
  "id" : 446654916136669185,
  "created_at" : "2014-03-20 14:30:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/446651456121487361\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/yzqv7paYgf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BjLTIfmIgAIZIw7.jpg",
      "id_str" : "446651455936954370",
      "id" : 446651455936954370,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjLTIfmIgAIZIw7.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/yzqv7paYgf"
    } ],
    "hashtags" : [ {
      "text" : "11DaysLeft",
      "indices" : [ 52, 63 ]
    }, {
      "text" : "GetCoveredNow",
      "indices" : [ 66, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/M7wU3HWMPB",
      "expanded_url" : "http:\/\/hc.gov\/sizN4U",
      "display_url" : "hc.gov\/sizN4U"
    } ]
  },
  "geo" : { },
  "id_str" : "446651456121487361",
  "text" : "If you need affordable health insurance, you've got #11DaysLeft.\n\n#GetCoveredNow \u2192 http:\/\/t.co\/M7wU3HWMPB, http:\/\/t.co\/yzqv7paYgf",
  "id" : 446651456121487361,
  "created_at" : "2014-03-20 14:16:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 123, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/7E4aEhPSS6",
      "expanded_url" : "http:\/\/go.wh.gov\/3iw427",
      "display_url" : "go.wh.gov\/3iw427"
    } ]
  },
  "geo" : { },
  "id_str" : "446433386291535872",
  "text" : "Raising the minimum wage would help more than 28 million workers. See how many live in your state \u2192 http:\/\/t.co\/7E4aEhPSS6 #RaiseTheWage",
  "id" : 446433386291535872,
  "created_at" : "2014-03-19 23:49:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jerry Stackhouse",
      "screen_name" : "jerrystackhouse",
      "indices" : [ 3, 19 ],
      "id_str" : "123479689",
      "id" : 123479689
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCoveredNow",
      "indices" : [ 67, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/LR16ON7Wil",
      "expanded_url" : "http:\/\/healthcare.gov",
      "display_url" : "healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "446424660012724224",
  "text" : "RT @jerrystackhouse: Coach Williams knows what he\u2019s talking about. #GetCoveredNow at http:\/\/t.co\/LR16ON7Wil and check out his new video at \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCoveredNow",
        "indices" : [ 46, 60 ]
      } ],
      "urls" : [ {
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/LR16ON7Wil",
        "expanded_url" : "http:\/\/healthcare.gov",
        "display_url" : "healthcare.gov"
      }, {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/o2jS808FCa",
        "expanded_url" : "http:\/\/whitehouse.gov\/ACABracket",
        "display_url" : "whitehouse.gov\/ACABracket"
      } ]
    },
    "geo" : { },
    "id_str" : "446298916607496192",
    "text" : "Coach Williams knows what he\u2019s talking about. #GetCoveredNow at http:\/\/t.co\/LR16ON7Wil and check out his new video at http:\/\/t.co\/o2jS808FCa",
    "id" : 446298916607496192,
    "created_at" : "2014-03-19 14:55:28 +0000",
    "user" : {
      "name" : "Jerry Stackhouse",
      "screen_name" : "jerrystackhouse",
      "protected" : false,
      "id_str" : "123479689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/677730590129569792\/d_hsD6BS_normal.jpg",
      "id" : 123479689,
      "verified" : true
    }
  },
  "id" : 446424660012724224,
  "created_at" : "2014-03-19 23:15:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/Ew9pglqq06",
      "expanded_url" : "http:\/\/go.wh.gov\/z36ZVd",
      "display_url" : "go.wh.gov\/z36ZVd"
    } ]
  },
  "geo" : { },
  "id_str" : "446418743833686016",
  "text" : "RT @Simas44: FACT: Since 1950, labor productivity has grown 278%, yet the real value of the minimum wage has fallen. http:\/\/t.co\/Ew9pglqq06\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RaiseTheWage",
        "indices" : [ 127, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/Ew9pglqq06",
        "expanded_url" : "http:\/\/go.wh.gov\/z36ZVd",
        "display_url" : "go.wh.gov\/z36ZVd"
      } ]
    },
    "geo" : { },
    "id_str" : "446400050177253376",
    "text" : "FACT: Since 1950, labor productivity has grown 278%, yet the real value of the minimum wage has fallen. http:\/\/t.co\/Ew9pglqq06 #RaiseTheWage",
    "id" : 446400050177253376,
    "created_at" : "2014-03-19 21:37:20 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 446418743833686016,
  "created_at" : "2014-03-19 22:51:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 29, 40 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/GmscwW06i2",
      "expanded_url" : "http:\/\/wh.gov\/lVuby",
      "display_url" : "wh.gov\/lVuby"
    } ]
  },
  "geo" : { },
  "id_str" : "446414475743473664",
  "text" : "RT @Lubin44: Next month, the @WhiteHouse will update its privacy policy. Check it out \u2192 http:\/\/t.co\/GmscwW06i2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 16, 27 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/GmscwW06i2",
        "expanded_url" : "http:\/\/wh.gov\/lVuby",
        "display_url" : "wh.gov\/lVuby"
      } ]
    },
    "geo" : { },
    "id_str" : "446414321900605441",
    "text" : "Next month, the @WhiteHouse will update its privacy policy. Check it out \u2192 http:\/\/t.co\/GmscwW06i2",
    "id" : 446414321900605441,
    "created_at" : "2014-03-19 22:34:02 +0000",
    "user" : {
      "name" : "Lindsay Holst",
      "screen_name" : "Holst44",
      "protected" : false,
      "id_str" : "1563426390",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615987325261082625\/QxtC65p2_normal.jpg",
      "id" : 1563426390,
      "verified" : true
    }
  },
  "id" : 446414475743473664,
  "created_at" : "2014-03-19 22:34:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446399823189921793",
  "text" : "FACT: If Congress doesn't act, the min wage is projected to lose 1.7% of its value in 2014\u2014enough to buy a month of groceries. #RaiseTheWage",
  "id" : 446399823189921793,
  "created_at" : "2014-03-19 21:36:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/446392373174493184\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/7gvyck4NOn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BjHnf4cCMAAsTww.jpg",
      "id_str" : "446392372998320128",
      "id" : 446392372998320128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjHnf4cCMAAsTww.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/7gvyck4NOn"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 93, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446392373174493184",
  "text" : "RT if you agree: It's time to help more than 28 million workers by raising the minimum wage. #RaiseTheWage, http:\/\/t.co\/7gvyck4NOn",
  "id" : 446392373174493184,
  "created_at" : "2014-03-19 21:06:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Bartolotta",
      "screen_name" : "andrewjpg",
      "indices" : [ 3, 13 ],
      "id_str" : "24120820",
      "id" : 24120820
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCoveredNow",
      "indices" : [ 106, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/ab4sJ7vhQs",
      "expanded_url" : "http:\/\/www.buzzfeed.com\/bigfish\/7-reasons-you-need-health-insurance-getcoverednow-guq3",
      "display_url" : "buzzfeed.com\/bigfish\/7-reas\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "446381914350706688",
  "text" : "RT @andrewjpg: Fetch happens. So do accidents. 7 Reasons to Have Health Insurance: http:\/\/t.co\/ab4sJ7vhQs #GetCoveredNow",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCoveredNow",
        "indices" : [ 91, 105 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/ab4sJ7vhQs",
        "expanded_url" : "http:\/\/www.buzzfeed.com\/bigfish\/7-reasons-you-need-health-insurance-getcoverednow-guq3",
        "display_url" : "buzzfeed.com\/bigfish\/7-reas\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "446361445991600129",
    "text" : "Fetch happens. So do accidents. 7 Reasons to Have Health Insurance: http:\/\/t.co\/ab4sJ7vhQs #GetCoveredNow",
    "id" : 446361445991600129,
    "created_at" : "2014-03-19 19:03:56 +0000",
    "user" : {
      "name" : "Andrew Bartolotta",
      "screen_name" : "andrewjpg",
      "protected" : false,
      "id_str" : "24120820",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/777199651246247936\/_X2f0GrZ_normal.jpg",
      "id" : 24120820,
      "verified" : false
    }
  },
  "id" : 446381914350706688,
  "created_at" : "2014-03-19 20:25:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HealthCare.gov",
      "screen_name" : "HealthCareGov",
      "indices" : [ 3, 17 ],
      "id_str" : "86697288",
      "id" : 86697288
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/Kam65j4lbD",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "446362033038950400",
  "text" : "RT @HealthCareGov: 895k visits to http:\/\/t.co\/Kam65j4lbD  and 200k calls to call center yesterday--biggest call rush since December. 12 day\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCoveredNow",
        "indices" : [ 125, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 15, 37 ],
        "url" : "http:\/\/t.co\/Kam65j4lbD",
        "expanded_url" : "http:\/\/HealthCare.gov",
        "display_url" : "HealthCare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "446360278645497856",
    "text" : "895k visits to http:\/\/t.co\/Kam65j4lbD  and 200k calls to call center yesterday--biggest call rush since December. 12 days to #GetCoveredNow",
    "id" : 446360278645497856,
    "created_at" : "2014-03-19 18:59:18 +0000",
    "user" : {
      "name" : "HealthCare.gov",
      "screen_name" : "HealthCareGov",
      "protected" : false,
      "id_str" : "86697288",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/528294497105350656\/OXpX0USe_normal.png",
      "id" : 86697288,
      "verified" : true
    }
  },
  "id" : 446362033038950400,
  "created_at" : "2014-03-19 19:06:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 96, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/rlUWBv5u1n",
      "expanded_url" : "http:\/\/go.wh.gov\/xV7nXW",
      "display_url" : "go.wh.gov\/xV7nXW"
    } ]
  },
  "geo" : { },
  "id_str" : "446350953911173122",
  "text" : "President Obama's calling on private-sector innovators to leverage open government resources to #ActOnClimate \u2192 http:\/\/t.co\/rlUWBv5u1n",
  "id" : 446350953911173122,
  "created_at" : "2014-03-19 18:22:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bobby Harrison ",
      "screen_name" : "bobby44",
      "indices" : [ 3, 11 ],
      "id_str" : "2806537362",
      "id" : 2806537362
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "moredough",
      "indices" : [ 91, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/21LXJJrUVu",
      "expanded_url" : "http:\/\/fox2now.com\/2014\/03\/19\/pi-pizzeria-to-raise-minimum-to-10-10-for-workers\/",
      "display_url" : "fox2now.com\/2014\/03\/19\/pi-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "446345377151594496",
  "text" : "RT @Bobby44: Good to see Pi Pizzeria raising the minimum wage to $10.10 for their workers. #moredough http:\/\/t.co\/21LXJJrUVu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "moredough",
        "indices" : [ 78, 88 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/21LXJJrUVu",
        "expanded_url" : "http:\/\/fox2now.com\/2014\/03\/19\/pi-pizzeria-to-raise-minimum-to-10-10-for-workers\/",
        "display_url" : "fox2now.com\/2014\/03\/19\/pi-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "446344634143608832",
    "text" : "Good to see Pi Pizzeria raising the minimum wage to $10.10 for their workers. #moredough http:\/\/t.co\/21LXJJrUVu",
    "id" : 446344634143608832,
    "created_at" : "2014-03-19 17:57:08 +0000",
    "user" : {
      "name" : "Brandi Hoffine",
      "screen_name" : "Hoffine44",
      "protected" : false,
      "id_str" : "1665298740",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/502212746134302720\/RqyFWrpZ_normal.jpeg",
      "id" : 1665298740,
      "verified" : true
    }
  },
  "id" : 446345377151594496,
  "created_at" : "2014-03-19 18:00:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/446330376210751488\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/VOW3kMVRA7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BjGvHL_CAAA7-uT.jpg",
      "id_str" : "446330376097497088",
      "id" : 446330376097497088,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjGvHL_CAAA7-uT.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 667,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 667,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/VOW3kMVRA7"
    } ],
    "hashtags" : [ {
      "text" : "GetCoveredNow",
      "indices" : [ 62, 76 ]
    }, {
      "text" : "Baracketology",
      "indices" : [ 102, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/HGHF1PeQkU",
      "expanded_url" : "http:\/\/go.wh.gov\/8doPfd",
      "display_url" : "go.wh.gov\/8doPfd"
    } ]
  },
  "geo" : { },
  "id_str" : "446330376210751488",
  "text" : "Check out Obama's NCAA bracket\u2014and vote on the top reasons to #GetCoveredNow \u2192 http:\/\/t.co\/HGHF1PeQkU #Baracketology http:\/\/t.co\/VOW3kMVRA7",
  "id" : 446330376210751488,
  "created_at" : "2014-03-19 17:00:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446317440285556736",
  "text" : "RT @JPalm44: Tomorrow in Orlando, POTUS kicks off regional events on women and the economy leading into the WH Working Families Summit. #Wo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WomenSucceed",
        "indices" : [ 123, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "446316926839840768",
    "text" : "Tomorrow in Orlando, POTUS kicks off regional events on women and the economy leading into the WH Working Families Summit. #WomenSucceed",
    "id" : 446316926839840768,
    "created_at" : "2014-03-19 16:07:02 +0000",
    "user" : {
      "name" : "Jen Psaki",
      "screen_name" : "Psaki44",
      "protected" : false,
      "id_str" : "1135388684",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/586965962370355200\/4NJkSnJN_normal.jpg",
      "id" : 1135388684,
      "verified" : true
    }
  },
  "id" : 446317440285556736,
  "created_at" : "2014-03-19 16:09:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446315704934232064",
  "text" : "RT @JPalm44: Hello Twitter! With so many of my colleagues tweeting, I couldn't miss out on the fun. Follow along for the latest from the @W\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 124, 135 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "446315591742525440",
    "text" : "Hello Twitter! With so many of my colleagues tweeting, I couldn't miss out on the fun. Follow along for the latest from the @WhiteHouse.",
    "id" : 446315591742525440,
    "created_at" : "2014-03-19 16:01:43 +0000",
    "user" : {
      "name" : "Jen Psaki",
      "screen_name" : "Psaki44",
      "protected" : false,
      "id_str" : "1135388684",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/586965962370355200\/4NJkSnJN_normal.jpg",
      "id" : 1135388684,
      "verified" : true
    }
  },
  "id" : 446315704934232064,
  "created_at" : "2014-03-19 16:02:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "indices" : [ 3, 11 ],
      "id_str" : "807095",
      "id" : 807095
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446313590904344576",
  "text" : "RT @nytimes: President Obama wants to make seeing how climate change will transform where you live as easy as opening a website http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/KOGcuU9xqj",
        "expanded_url" : "http:\/\/nyti.ms\/1gGd46A",
        "display_url" : "nyti.ms\/1gGd46A"
      } ]
    },
    "geo" : { },
    "id_str" : "446300089943080961",
    "text" : "President Obama wants to make seeing how climate change will transform where you live as easy as opening a website http:\/\/t.co\/KOGcuU9xqj",
    "id" : 446300089943080961,
    "created_at" : "2014-03-19 15:00:07 +0000",
    "user" : {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "protected" : false,
      "id_str" : "807095",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758384037589348352\/KB3RFwFm_normal.jpg",
      "id" : 807095,
      "verified" : true
    }
  },
  "id" : 446313590904344576,
  "created_at" : "2014-03-19 15:53:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/446302619460325378\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/GL75xR0dOO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BjGV3h0CQAEjiUv.jpg",
      "id_str" : "446302619288354817",
      "id" : 446302619288354817,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjGV3h0CQAEjiUv.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/GL75xR0dOO"
    } ],
    "hashtags" : [ {
      "text" : "12DaysLeft",
      "indices" : [ 15, 26 ]
    }, {
      "text" : "GetCoveredNow",
      "indices" : [ 77, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/tWanUWNBwM",
      "expanded_url" : "http:\/\/hc.gov\/aneAUU",
      "display_url" : "hc.gov\/aneAUU"
    } ]
  },
  "geo" : { },
  "id_str" : "446302619460325378",
  "text" : "There are just #12DaysLeft to sign up for 2014 health insurance. DON'T WAIT: #GetCoveredNow \u2192 http:\/\/t.co\/tWanUWNBwM http:\/\/t.co\/GL75xR0dOO",
  "id" : 446302619460325378,
  "created_at" : "2014-03-19 15:10:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ClimateData",
      "indices" : [ 108, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446297864508297216",
  "text" : "RT @Podesta44: We must help American communities prepare for the impacts of climate change. Learn about the #ClimateData Initiative: http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ClimateData",
        "indices" : [ 93, 105 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/3nDcwukBSk",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2014\/03\/19\/climate-data-initiative-launches-strong-public-and-private-sector-commitments",
        "display_url" : "whitehouse.gov\/blog\/2014\/03\/1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "446285470972915715",
    "text" : "We must help American communities prepare for the impacts of climate change. Learn about the #ClimateData Initiative: http:\/\/t.co\/3nDcwukBSk",
    "id" : 446285470972915715,
    "created_at" : "2014-03-19 14:02:02 +0000",
    "user" : {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "protected" : false,
      "id_str" : "2382117350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656551411145027584\/ArrSlGUP_normal.jpg",
      "id" : 2382117350,
      "verified" : true
    }
  },
  "id" : 446297864508297216,
  "created_at" : "2014-03-19 14:51:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MarchMadness",
      "indices" : [ 16, 29 ]
    }, {
      "text" : "Baracketology",
      "indices" : [ 120, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/vTOvdjM40c",
      "expanded_url" : "http:\/\/go.wh.gov\/FNJz7p",
      "display_url" : "go.wh.gov\/FNJz7p"
    } ]
  },
  "geo" : { },
  "id_str" : "446284845380284416",
  "text" : "Filled out your #MarchMadness bracket yet? See who President Obama's picking to go all the way \u2192 http:\/\/t.co\/vTOvdjM40c #Baracketology",
  "id" : 446284845380284416,
  "created_at" : "2014-03-19 13:59:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Valor24",
      "indices" : [ 131, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/EjNRQu9BJt",
      "expanded_url" : "http:\/\/instagram.com\/p\/ls-K7qQiq_\/",
      "display_url" : "instagram.com\/p\/ls-K7qQiq_\/"
    } ]
  },
  "geo" : { },
  "id_str" : "446071273140277248",
  "text" : "\"We all want to thank you for inspiring us...for your strength, your will, and your heroic hearts.\" \u2014Obama: http:\/\/t.co\/EjNRQu9BJt #Valor24",
  "id" : 446071273140277248,
  "created_at" : "2014-03-18 23:50:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/rCUOi6Zhcq",
      "expanded_url" : "http:\/\/youtu.be\/yCTcdtkBbdU",
      "display_url" : "youtu.be\/yCTcdtkBbdU"
    } ]
  },
  "geo" : { },
  "id_str" : "446046174785835008",
  "text" : "RT @FLOTUS: \"All Americans deserve the security of knowing that you\u2019ll have health care when you need it.\" \u2014FLOTUS: http:\/\/t.co\/rCUOi6Zhcq \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 127, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/rCUOi6Zhcq",
        "expanded_url" : "http:\/\/youtu.be\/yCTcdtkBbdU",
        "display_url" : "youtu.be\/yCTcdtkBbdU"
      } ]
    },
    "geo" : { },
    "id_str" : "446045755867148288",
    "text" : "\"All Americans deserve the security of knowing that you\u2019ll have health care when you need it.\" \u2014FLOTUS: http:\/\/t.co\/rCUOi6Zhcq #GetCovered",
    "id" : 446045755867148288,
    "created_at" : "2014-03-18 22:09:29 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 446046174785835008,
  "created_at" : "2014-03-18 22:11:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCoveredNow",
      "indices" : [ 27, 41 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/BYkojFOLPE",
      "expanded_url" : "http:\/\/go.wh.gov\/crweNY",
      "display_url" : "go.wh.gov\/crweNY"
    } ]
  },
  "geo" : { },
  "id_str" : "446033333638930432",
  "text" : "The 16 sweetest reasons to #GetCoveredNow have been narrowed down to 8. Vote on which ones get to the final four \u2192 http:\/\/t.co\/BYkojFOLPE",
  "id" : 446033333638930432,
  "created_at" : "2014-03-18 21:20:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Veterans Affairs",
      "screen_name" : "DeptVetAffairs",
      "indices" : [ 3, 18 ],
      "id_str" : "78408666",
      "id" : 78408666
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/DeptVetAffairs\/status\/446026739387346944\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/PjCuXksto2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BjCa9LICQAA6Hd3.jpg",
      "id_str" : "446026738858868736",
      "id" : 446026738858868736,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjCa9LICQAA6Hd3.jpg",
      "sizes" : [ {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 3264,
        "resize" : "fit",
        "w" : 2448
      } ],
      "display_url" : "pic.twitter.com\/PjCuXksto2"
    } ],
    "hashtags" : [ {
      "text" : "Valor24",
      "indices" : [ 84, 92 ]
    }, {
      "text" : "HonoringVets",
      "indices" : [ 93, 106 ]
    }, {
      "text" : "MOH",
      "indices" : [ 107, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446027997498576899",
  "text" : "RT @DeptVetAffairs: \"We are so grateful to them and their families\" President Obama #Valor24 #HonoringVets #MOH http:\/\/t.co\/PjCuXksto2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DeptVetAffairs\/status\/446026739387346944\/photo\/1",
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/PjCuXksto2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BjCa9LICQAA6Hd3.jpg",
        "id_str" : "446026738858868736",
        "id" : 446026738858868736,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjCa9LICQAA6Hd3.jpg",
        "sizes" : [ {
          "h" : 1365,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 3264,
          "resize" : "fit",
          "w" : 2448
        } ],
        "display_url" : "pic.twitter.com\/PjCuXksto2"
      } ],
      "hashtags" : [ {
        "text" : "Valor24",
        "indices" : [ 64, 72 ]
      }, {
        "text" : "HonoringVets",
        "indices" : [ 73, 86 ]
      }, {
        "text" : "MOH",
        "indices" : [ 87, 91 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "446026739387346944",
    "text" : "\"We are so grateful to them and their families\" President Obama #Valor24 #HonoringVets #MOH http:\/\/t.co\/PjCuXksto2",
    "id" : 446026739387346944,
    "created_at" : "2014-03-18 20:53:56 +0000",
    "user" : {
      "name" : "Veterans Affairs",
      "screen_name" : "DeptVetAffairs",
      "protected" : false,
      "id_str" : "78408666",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/344513261565984455\/a9fcce7feb947b2ec498491c6c6d6985_normal.png",
      "id" : 78408666,
      "verified" : true
    }
  },
  "id" : 446027997498576899,
  "created_at" : "2014-03-18 20:58:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Veterans Affairs",
      "screen_name" : "DeptVetAffairs",
      "indices" : [ 3, 18 ],
      "id_str" : "78408666",
      "id" : 78408666
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/DeptVetAffairs\/status\/446020004173975553\/photo\/1",
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/KdErvMbgc0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BjCU1HnCAAAg8Br.jpg",
      "id_str" : "446020003406413824",
      "id" : 446020003406413824,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjCU1HnCAAAg8Br.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2448,
        "resize" : "fit",
        "w" : 3264
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/KdErvMbgc0"
    } ],
    "hashtags" : [ {
      "text" : "Valor24",
      "indices" : [ 72, 80 ]
    }, {
      "text" : "MOH",
      "indices" : [ 81, 85 ]
    }, {
      "text" : "HonoringVets",
      "indices" : [ 86, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446020278196645888",
  "text" : "RT @DeptVetAffairs: Mike Pe\u00F1a's son accepts his father's Medal of Honor #Valor24 #MOH #HonoringVets http:\/\/t.co\/KdErvMbgc0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/DeptVetAffairs\/status\/446020004173975553\/photo\/1",
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/KdErvMbgc0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BjCU1HnCAAAg8Br.jpg",
        "id_str" : "446020003406413824",
        "id" : 446020003406413824,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjCU1HnCAAAg8Br.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2448,
          "resize" : "fit",
          "w" : 3264
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/KdErvMbgc0"
      } ],
      "hashtags" : [ {
        "text" : "Valor24",
        "indices" : [ 52, 60 ]
      }, {
        "text" : "MOH",
        "indices" : [ 61, 65 ]
      }, {
        "text" : "HonoringVets",
        "indices" : [ 66, 79 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "446020004173975553",
    "text" : "Mike Pe\u00F1a's son accepts his father's Medal of Honor #Valor24 #MOH #HonoringVets http:\/\/t.co\/KdErvMbgc0",
    "id" : 446020004173975553,
    "created_at" : "2014-03-18 20:27:10 +0000",
    "user" : {
      "name" : "Veterans Affairs",
      "screen_name" : "DeptVetAffairs",
      "protected" : false,
      "id_str" : "78408666",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/344513261565984455\/a9fcce7feb947b2ec498491c6c6d6985_normal.png",
      "id" : 78408666,
      "verified" : true
    }
  },
  "id" : 446020278196645888,
  "created_at" : "2014-03-18 20:28:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 67, 78 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalofHonor",
      "indices" : [ 98, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446014523712241664",
  "text" : "RT @NSCPress: One of the most moving things we get to witness here @WhiteHouse is awarding of the #MedalofHonor. Thank you to veterans &amp; th\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 53, 64 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MedalofHonor",
        "indices" : [ 84, 97 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "446014270267228161",
    "text" : "One of the most moving things we get to witness here @WhiteHouse is awarding of the #MedalofHonor. Thank you to veterans &amp; their families.",
    "id" : 446014270267228161,
    "created_at" : "2014-03-18 20:04:23 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 446014523712241664,
  "created_at" : "2014-03-18 20:05:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Veterans Affairs",
      "screen_name" : "DeptVetAffairs",
      "indices" : [ 3, 18 ],
      "id_str" : "78408666",
      "id" : 78408666
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MOH",
      "indices" : [ 45, 49 ]
    }, {
      "text" : "MOH",
      "indices" : [ 128, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446012454393614336",
  "text" : "RT @DeptVetAffairs: Jose Rodela receives the #MOH for his courageous actions against an armed enemy in Phuoc Long, Vietnam 1969 #MOH #Valor\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MOH",
        "indices" : [ 25, 29 ]
      }, {
        "text" : "MOH",
        "indices" : [ 108, 112 ]
      }, {
        "text" : "Valor24",
        "indices" : [ 113, 121 ]
      }, {
        "text" : "HonoringVets",
        "indices" : [ 122, 135 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "446012079095308288",
    "text" : "Jose Rodela receives the #MOH for his courageous actions against an armed enemy in Phuoc Long, Vietnam 1969 #MOH #Valor24 #HonoringVets",
    "id" : 446012079095308288,
    "created_at" : "2014-03-18 19:55:40 +0000",
    "user" : {
      "name" : "Veterans Affairs",
      "screen_name" : "DeptVetAffairs",
      "protected" : false,
      "id_str" : "78408666",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/344513261565984455\/a9fcce7feb947b2ec498491c6c6d6985_normal.png",
      "id" : 78408666,
      "verified" : true
    }
  },
  "id" : 446012454393614336,
  "created_at" : "2014-03-18 19:57:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Veterans Affairs",
      "screen_name" : "DeptVetAffairs",
      "indices" : [ 3, 18 ],
      "id_str" : "78408666",
      "id" : 78408666
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MOH",
      "indices" : [ 47, 51 ]
    }, {
      "text" : "MOH",
      "indices" : [ 121, 125 ]
    }, {
      "text" : "Valor24",
      "indices" : [ 126, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446012305609089024",
  "text" : "RT @DeptVetAffairs: Melvin Morris receives the #MOH for his courageous actions in the vicinity of Chi Lang, Vietnam 1969 #MOH #Valor24 #Hon\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MOH",
        "indices" : [ 27, 31 ]
      }, {
        "text" : "MOH",
        "indices" : [ 101, 105 ]
      }, {
        "text" : "Valor24",
        "indices" : [ 106, 114 ]
      }, {
        "text" : "HonoringVets",
        "indices" : [ 115, 128 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "446011476948422656",
    "text" : "Melvin Morris receives the #MOH for his courageous actions in the vicinity of Chi Lang, Vietnam 1969 #MOH #Valor24 #HonoringVets",
    "id" : 446011476948422656,
    "created_at" : "2014-03-18 19:53:17 +0000",
    "user" : {
      "name" : "Veterans Affairs",
      "screen_name" : "DeptVetAffairs",
      "protected" : false,
      "id_str" : "78408666",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/344513261565984455\/a9fcce7feb947b2ec498491c6c6d6985_normal.png",
      "id" : 78408666,
      "verified" : true
    }
  },
  "id" : 446012305609089024,
  "created_at" : "2014-03-18 19:56:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Veterans Affairs",
      "screen_name" : "DeptVetAffairs",
      "indices" : [ 3, 18 ],
      "id_str" : "78408666",
      "id" : 78408666
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MOH",
      "indices" : [ 93, 97 ]
    }, {
      "text" : "Valor24",
      "indices" : [ 107, 115 ]
    }, {
      "text" : "HonoringVets",
      "indices" : [ 116, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446011753298952192",
  "text" : "RT @DeptVetAffairs: Santiago J. Erevia stands with President Obama during the reading of his #MOH citation #Valor24 #HonoringVets http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DeptVetAffairs\/status\/446011679394910208\/photo\/1",
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/RedvtnOvm9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BjCNQkFCEAAcqeN.jpg",
        "id_str" : "446011678811885568",
        "id" : 446011678811885568,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjCNQkFCEAAcqeN.jpg",
        "sizes" : [ {
          "h" : 237,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 713,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1749,
          "resize" : "fit",
          "w" : 2512
        }, {
          "h" : 418,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/RedvtnOvm9"
      } ],
      "hashtags" : [ {
        "text" : "MOH",
        "indices" : [ 73, 77 ]
      }, {
        "text" : "Valor24",
        "indices" : [ 87, 95 ]
      }, {
        "text" : "HonoringVets",
        "indices" : [ 96, 109 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "446011679394910208",
    "text" : "Santiago J. Erevia stands with President Obama during the reading of his #MOH citation #Valor24 #HonoringVets http:\/\/t.co\/RedvtnOvm9",
    "id" : 446011679394910208,
    "created_at" : "2014-03-18 19:54:05 +0000",
    "user" : {
      "name" : "Veterans Affairs",
      "screen_name" : "DeptVetAffairs",
      "protected" : false,
      "id_str" : "78408666",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/344513261565984455\/a9fcce7feb947b2ec498491c6c6d6985_normal.png",
      "id" : 78408666,
      "verified" : true
    }
  },
  "id" : 446011753298952192,
  "created_at" : "2014-03-18 19:54:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Valor24",
      "indices" : [ 127, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446009005551652864",
  "text" : "President Obama: \"Because others laid down their lives for us, we\u2019ve been able to live ours in freedom and pursue our dreams.\" #Valor24",
  "id" : 446009005551652864,
  "created_at" : "2014-03-18 19:43:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "446007997220016128",
  "text" : "RT @WHLive: Obama: \"We keep striving to live up to our ideals of freedom &amp; equality and to recognize the dignity &amp; patriotism of every pers\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Valor24",
        "indices" : [ 140, 148 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "446007964819025920",
    "text" : "Obama: \"We keep striving to live up to our ideals of freedom &amp; equality and to recognize the dignity &amp; patriotism of every person.\" #Valor24",
    "id" : 446007964819025920,
    "created_at" : "2014-03-18 19:39:19 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 446007997220016128,
  "created_at" : "2014-03-18 19:39:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Army",
      "screen_name" : "USArmy",
      "indices" : [ 62, 69 ],
      "id_str" : "8775672",
      "id" : 8775672
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfHonor",
      "indices" : [ 42, 55 ]
    }, {
      "text" : "Valor24",
      "indices" : [ 111, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/eWf5D3MRIl",
      "expanded_url" : "http:\/\/go.wh.gov\/JxUnnJ",
      "display_url" : "go.wh.gov\/JxUnnJ"
    } ]
  },
  "geo" : { },
  "id_str" : "446006946672676864",
  "text" : "Happening now: President Obama awards the #MedalOfHonor to 24 @USArmy veterans. Watch \u2192 http:\/\/t.co\/eWf5D3MRIl #Valor24",
  "id" : 446006946672676864,
  "created_at" : "2014-03-18 19:35:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Army",
      "screen_name" : "USArmy",
      "indices" : [ 47, 54 ],
      "id_str" : "8775672",
      "id" : 8775672
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfHonor",
      "indices" : [ 27, 40 ]
    }, {
      "text" : "HonoringVets",
      "indices" : [ 109, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/eWf5D3MRIl",
      "expanded_url" : "http:\/\/go.wh.gov\/JxUnnJ",
      "display_url" : "go.wh.gov\/JxUnnJ"
    } ]
  },
  "geo" : { },
  "id_str" : "446004225076899842",
  "text" : "President Obama awards the #MedalOfHonor to 24 @USArmy veterans at 3:40pm ET. Watch \u2192 http:\/\/t.co\/eWf5D3MRIl #HonoringVets",
  "id" : 446004225076899842,
  "created_at" : "2014-03-18 19:24:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCoveredNow",
      "indices" : [ 126, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/Sjr1DjFN9d",
      "expanded_url" : "http:\/\/hc.gov\/mh48yx",
      "display_url" : "hc.gov\/mh48yx"
    } ]
  },
  "geo" : { },
  "id_str" : "445994298270834690",
  "text" : "Paying out-of-pocket to fix a broken leg could be a huge financial blow. Make sure you don't need to \u2192 http:\/\/t.co\/Sjr1DjFN9d #GetCoveredNow",
  "id" : 445994298270834690,
  "created_at" : "2014-03-18 18:45:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/445983843359924225\/photo\/1",
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/omyI2fRTRo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BjBz8UTIUAA3cVN.jpg",
      "id_str" : "445983843187970048",
      "id" : 445983843187970048,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjBz8UTIUAA3cVN.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/omyI2fRTRo"
    } ],
    "hashtags" : [ {
      "text" : "GetCoveredNow",
      "indices" : [ 48, 62 ]
    }, {
      "text" : "13DaysLeft",
      "indices" : [ 88, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 87 ],
      "url" : "http:\/\/t.co\/gbc71aTLmn",
      "expanded_url" : "http:\/\/hc.gov\/ZDpg3L",
      "display_url" : "hc.gov\/ZDpg3L"
    } ]
  },
  "geo" : { },
  "id_str" : "445983843359924225",
  "text" : "Don't let a hard hit cost you an arm and a leg. #GetCoveredNow \u2192 http:\/\/t.co\/gbc71aTLmn #13DaysLeft, http:\/\/t.co\/omyI2fRTRo",
  "id" : 445983843359924225,
  "created_at" : "2014-03-18 18:03:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harrison Barnes",
      "screen_name" : "hbarnes",
      "indices" : [ 3, 11 ],
      "id_str" : "555393138",
      "id" : 555393138
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCoveredNow",
      "indices" : [ 59, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/HtHN0GkvVS",
      "expanded_url" : "http:\/\/healthcare.gov",
      "display_url" : "healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "445981037781598208",
  "text" : "RT @HBarnes: Coach Williams knows what he\u2019s talking about. #GetCoveredNow at http:\/\/t.co\/HtHN0GkvVS and check out his new video - http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCoveredNow",
        "indices" : [ 46, 60 ]
      } ],
      "urls" : [ {
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/HtHN0GkvVS",
        "expanded_url" : "http:\/\/healthcare.gov",
        "display_url" : "healthcare.gov"
      }, {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/WLh1KtGDkA",
        "expanded_url" : "http:\/\/whitehouse.gov\/ACABracket",
        "display_url" : "whitehouse.gov\/ACABracket"
      } ]
    },
    "geo" : { },
    "id_str" : "445662704502444034",
    "text" : "Coach Williams knows what he\u2019s talking about. #GetCoveredNow at http:\/\/t.co\/HtHN0GkvVS and check out his new video - http:\/\/t.co\/WLh1KtGDkA",
    "id" : 445662704502444034,
    "created_at" : "2014-03-17 20:47:23 +0000",
    "user" : {
      "name" : "Harrison Barnes",
      "screen_name" : "hbarnes",
      "protected" : false,
      "id_str" : "555393138",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/769409727570677761\/DNyHRZ2H_normal.jpg",
      "id" : 555393138,
      "verified" : true
    }
  },
  "id" : 445981037781598208,
  "created_at" : "2014-03-18 17:52:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041A\u0430\u0442\u0435\u043D\u0430 \u041D\u0438\u043A\u043E\u043D\u0435\u043D\u043A\u043E",
      "screen_name" : "HealthCareTara",
      "indices" : [ 3, 18 ],
      "id_str" : "9448842",
      "id" : 9448842
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CRUSH",
      "indices" : [ 76, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/29cMYgr9Es",
      "expanded_url" : "http:\/\/go.wh.gov\/3aoa6P",
      "display_url" : "go.wh.gov\/3aoa6P"
    } ]
  },
  "geo" : { },
  "id_str" : "445973839135408128",
  "text" : "RT @HealthCareTara: This \"peace of mind for mom\" kitten is totally going to #CRUSH the bracket competition: http:\/\/t.co\/29cMYgr9Es #GetCove\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CRUSH",
        "indices" : [ 56, 62 ]
      }, {
        "text" : "GetCovered",
        "indices" : [ 111, 122 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/29cMYgr9Es",
        "expanded_url" : "http:\/\/go.wh.gov\/3aoa6P",
        "display_url" : "go.wh.gov\/3aoa6P"
      } ]
    },
    "geo" : { },
    "id_str" : "445972648376664064",
    "text" : "This \"peace of mind for mom\" kitten is totally going to #CRUSH the bracket competition: http:\/\/t.co\/29cMYgr9Es #GetCovered",
    "id" : 445972648376664064,
    "created_at" : "2014-03-18 17:18:59 +0000",
    "user" : {
      "name" : "Tara McGuinness",
      "screen_name" : "Tara44",
      "protected" : false,
      "id_str" : "1601549102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600334679951081472\/O9XyKAXl_normal.jpg",
      "id" : 1601549102,
      "verified" : true
    }
  },
  "id" : 445973839135408128,
  "created_at" : "2014-03-18 17:23:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCoveredNow",
      "indices" : [ 48, 62 ]
    }, {
      "text" : "MarchMadness",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/TgfX8skvUK",
      "expanded_url" : "http:\/\/go.wh.gov\/3aoa6P",
      "display_url" : "go.wh.gov\/3aoa6P"
    } ]
  },
  "geo" : { },
  "id_str" : "445969839547768832",
  "text" : "Get your votes in on the 16 sweetest reasons to #GetCoveredNow. The field shrinks to 8 this afternoon \u2192 http:\/\/t.co\/TgfX8skvUK #MarchMadness",
  "id" : 445969839547768832,
  "created_at" : "2014-03-18 17:07:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCoveredNow",
      "indices" : [ 88, 102 ]
    }, {
      "text" : "13DaysLeft",
      "indices" : [ 128, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/Q9PDNcH5cG",
      "expanded_url" : "http:\/\/hc.gov\/7kSBpv",
      "display_url" : "hc.gov\/7kSBpv"
    } ]
  },
  "geo" : { },
  "id_str" : "445958064890724352",
  "text" : "FACT: Without insurance, a sprained ankle could cost you $2,290. Don't let that be you: #GetCoveredNow \u2192 http:\/\/t.co\/Q9PDNcH5cG #13DaysLeft",
  "id" : 445958064890724352,
  "created_at" : "2014-03-18 16:21:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/445949373495513088\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/owpbd3WpWw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BjBUl58CUAEgS6C.jpg",
      "id_str" : "445949373294202881",
      "id" : 445949373294202881,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjBUl58CUAEgS6C.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/owpbd3WpWw"
    } ],
    "hashtags" : [ {
      "text" : "GetCoveredNow",
      "indices" : [ 57, 71 ]
    }, {
      "text" : "13DaysLeft",
      "indices" : [ 97, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/z1lPRET2f3",
      "expanded_url" : "http:\/\/hc.gov\/ZDpg3L",
      "display_url" : "hc.gov\/ZDpg3L"
    } ]
  },
  "geo" : { },
  "id_str" : "445949373495513088",
  "text" : "Don't let a hard foul put your bank account on the line. #GetCoveredNow \u2192 http:\/\/t.co\/z1lPRET2f3 #13DaysLeft http:\/\/t.co\/owpbd3WpWw",
  "id" : 445949373495513088,
  "created_at" : "2014-03-18 15:46:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/445929181155577856\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/pRhVNTj5ln",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BjBCOjwCUAEzjz9.jpg",
      "id_str" : "445929180992000001",
      "id" : 445929180992000001,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BjBCOjwCUAEzjz9.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/pRhVNTj5ln"
    } ],
    "hashtags" : [ {
      "text" : "13DaysLeft",
      "indices" : [ 0, 11 ]
    }, {
      "text" : "GetCoveredNow",
      "indices" : [ 74, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/Le1pGiRroT",
      "expanded_url" : "http:\/\/hc.gov\/8LzVoX",
      "display_url" : "hc.gov\/8LzVoX"
    } ]
  },
  "geo" : { },
  "id_str" : "445929181155577856",
  "text" : "#13DaysLeft to sign up for health coverage.\nTell your friends and family.\n#GetCoveredNow \u2192 http:\/\/t.co\/Le1pGiRroT, http:\/\/t.co\/pRhVNTj5ln",
  "id" : 445929181155577856,
  "created_at" : "2014-03-18 14:26:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCoveredNow",
      "indices" : [ 96, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/5zeR2RQuXe",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    }, {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/O1VhInUYy1",
      "expanded_url" : "http:\/\/go.wh.gov\/bwAjsb",
      "display_url" : "go.wh.gov\/bwAjsb"
    } ]
  },
  "geo" : { },
  "id_str" : "445690195745447936",
  "text" : "Need health insurance? Go to http:\/\/t.co\/5zeR2RQuXe. If not, vote on the 16 sweetest reasons to #GetCoveredNow: http:\/\/t.co\/O1VhInUYy1",
  "id" : 445690195745447936,
  "created_at" : "2014-03-17 22:36:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/445681445038604288\/photo\/1",
      "indices" : [ 25, 47 ],
      "url" : "http:\/\/t.co\/4wMbXWZn2Z",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bi9g6avCIAAAQHr.jpg",
      "id_str" : "445681444858241024",
      "id" : 445681444858241024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bi9g6avCIAAAQHr.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 223,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 394,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 673,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 723,
        "resize" : "fit",
        "w" : 1100
      } ],
      "display_url" : "pic.twitter.com\/4wMbXWZn2Z"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445681445038604288",
  "text" : "Happy St. Patrick's Day! http:\/\/t.co\/4wMbXWZn2Z",
  "id" : 445681445038604288,
  "created_at" : "2014-03-17 22:01:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "14DaysLeft",
      "indices" : [ 5, 16 ]
    }, {
      "text" : "ACA",
      "indices" : [ 111, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/hh17k9vV5p",
      "expanded_url" : "http:\/\/hc.gov\/WvhLVn",
      "display_url" : "hc.gov\/WvhLVn"
    } ]
  },
  "geo" : { },
  "id_str" : "445666134121930752",
  "text" : "Just #14DaysLeft to join the more than 5 million Americans who have signed up for private coverage through the #ACA \u2192 http:\/\/t.co\/hh17k9vV5p",
  "id" : 445666134121930752,
  "created_at" : "2014-03-17 21:01:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 93, 97 ]
    }, {
      "text" : "GetCoveredNow",
      "indices" : [ 123, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/r4CFMdRDSA",
      "expanded_url" : "http:\/\/go.wh.gov\/BSXd3a",
      "display_url" : "go.wh.gov\/BSXd3a"
    } ]
  },
  "geo" : { },
  "id_str" : "445659733480181760",
  "text" : "Good news: More than 5 million Americans have signed up for private health plans through the #ACA \u2192 http:\/\/t.co\/r4CFMdRDSA #GetCoveredNow",
  "id" : 445659733480181760,
  "created_at" : "2014-03-17 20:35:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/arneduncan\/status\/445626158894178304\/photo\/1",
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/Ups1dX9TRc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bi8uoWfCYAAw1v_.jpg",
      "id_str" : "445626158898372608",
      "id" : 445626158898372608,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bi8uoWfCYAAw1v_.jpg",
      "sizes" : [ {
        "h" : 490,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 990,
        "resize" : "fit",
        "w" : 1212
      }, {
        "h" : 278,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 836,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Ups1dX9TRc"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/stJiT3HFMr",
      "expanded_url" : "http:\/\/healthcare.gov",
      "display_url" : "healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "445644477332717568",
  "text" : "RT @arneduncan: #\u200EGetCovered because you never know when you're going to take a hard foul! --&gt; http:\/\/t.co\/stJiT3HFMr http:\/\/t.co\/Ups1dX9TRc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/arneduncan\/status\/445626158894178304\/photo\/1",
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/Ups1dX9TRc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bi8uoWfCYAAw1v_.jpg",
        "id_str" : "445626158898372608",
        "id" : 445626158898372608,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bi8uoWfCYAAw1v_.jpg",
        "sizes" : [ {
          "h" : 490,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 990,
          "resize" : "fit",
          "w" : 1212
        }, {
          "h" : 278,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 836,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/Ups1dX9TRc"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/stJiT3HFMr",
        "expanded_url" : "http:\/\/healthcare.gov",
        "display_url" : "healthcare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "445626158894178304",
    "text" : "#\u200EGetCovered because you never know when you're going to take a hard foul! --&gt; http:\/\/t.co\/stJiT3HFMr http:\/\/t.co\/Ups1dX9TRc",
    "id" : 445626158894178304,
    "created_at" : "2014-03-17 18:22:10 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 445644477332717568,
  "created_at" : "2014-03-17 19:34:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 93, 97 ]
    }, {
      "text" : "GetCoveredNow",
      "indices" : [ 122, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/OWqBilL0xt",
      "expanded_url" : "http:\/\/hc.gov\/nYx8W7",
      "display_url" : "hc.gov\/nYx8W7"
    } ]
  },
  "geo" : { },
  "id_str" : "445636380262412288",
  "text" : "RT the news: More than 1 million Californians have signed up for health coverage through the #ACA. http:\/\/t.co\/OWqBilL0xt #GetCoveredNow",
  "id" : 445636380262412288,
  "created_at" : "2014-03-17 19:02:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/445622639550148608\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/T0CayP41yg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bi8rbe3CMAAI7Yl.jpg",
      "id_str" : "445622639273324544",
      "id" : 445622639273324544,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bi8rbe3CMAAI7Yl.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/T0CayP41yg"
    } ],
    "hashtags" : [ {
      "text" : "14DaysLeft",
      "indices" : [ 0, 11 ]
    }, {
      "text" : "GetCoveredNow",
      "indices" : [ 76, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/D8X8heNtno",
      "expanded_url" : "http:\/\/hc.gov\/6AtTeq",
      "display_url" : "hc.gov\/6AtTeq"
    } ]
  },
  "geo" : { },
  "id_str" : "445622639550148608",
  "text" : "#14DaysLeft to sign up for affordable health insurance. Beat the buzzer and #GetCoveredNow \u2192 http:\/\/t.co\/D8X8heNtno, http:\/\/t.co\/T0CayP41yg",
  "id" : 445622639550148608,
  "created_at" : "2014-03-17 18:08:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Lehrich",
      "screen_name" : "Lehrich44",
      "indices" : [ 3, 13 ],
      "id_str" : "116324294",
      "id" : 116324294
    }, {
      "name" : "\u0428\u0435\u043D\u043A\u0443\u0440\u0441\u043A\u0430\u044F \u041B\u0430\u0434\u0430",
      "screen_name" : "JimAcostaCNN",
      "indices" : [ 56, 69 ],
      "id_str" : "2833413329",
      "id" : 2833413329
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "getcovered",
      "indices" : [ 41, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445618504482697218",
  "text" : "RT @Lehrich44: Don't wait. Sign up meow! #getcovered MT @JimAcostaCNN Cat GIFs on WH site to urge enrollment by March 31 deadline. http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u0428\u0435\u043D\u043A\u0443\u0440\u0441\u043A\u0430\u044F \u041B\u0430\u0434\u0430",
        "screen_name" : "JimAcostaCNN",
        "indices" : [ 41, 54 ],
        "id_str" : "2833413329",
        "id" : 2833413329
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "getcovered",
        "indices" : [ 26, 37 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/8JR0FZOHRs",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/\/acabracket?utm_source=twitter&utm_medium=social&utm_content=031714p2&utm_campaign=ACABracket",
        "display_url" : "whitehouse.gov\/\/acabracket?ut\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "445604029943803905",
    "geo" : { },
    "id_str" : "445606290975641600",
    "in_reply_to_user_id" : 22771961,
    "text" : "Don't wait. Sign up meow! #getcovered MT @JimAcostaCNN Cat GIFs on WH site to urge enrollment by March 31 deadline. http:\/\/t.co\/8JR0FZOHRs",
    "id" : 445606290975641600,
    "in_reply_to_status_id" : 445604029943803905,
    "created_at" : "2014-03-17 17:03:13 +0000",
    "in_reply_to_screen_name" : "Acosta",
    "in_reply_to_user_id_str" : "22771961",
    "user" : {
      "name" : "Patrick Rodenbush",
      "screen_name" : "Patrick44",
      "protected" : false,
      "id_str" : "1665386791",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798907223174946816\/KIC4Jq2Q_normal.jpg",
      "id" : 1665386791,
      "verified" : true
    }
  },
  "id" : 445618504482697218,
  "created_at" : "2014-03-17 17:51:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Durant",
      "screen_name" : "KDTrey5",
      "indices" : [ 3, 11 ],
      "id_str" : "35936474",
      "id" : 35936474
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCoveredNow",
      "indices" : [ 80, 94 ]
    }, {
      "text" : "HookEmHealthcare",
      "indices" : [ 118, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/gAut5GUR0L",
      "expanded_url" : "http:\/\/go.wh.gov\/tUv1S4",
      "display_url" : "go.wh.gov\/tUv1S4"
    } ]
  },
  "geo" : { },
  "id_str" : "445608799790194688",
  "text" : "RT @KDTrey5: Not usually a Tar Heels \/ Huskies fan, but Roy and Geno are right. #GetCoveredNow http:\/\/t.co\/gAut5GUR0L #HookEmHealthcare.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCoveredNow",
        "indices" : [ 67, 81 ]
      }, {
        "text" : "HookEmHealthcare",
        "indices" : [ 105, 122 ]
      } ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/gAut5GUR0L",
        "expanded_url" : "http:\/\/go.wh.gov\/tUv1S4",
        "display_url" : "go.wh.gov\/tUv1S4"
      } ]
    },
    "geo" : { },
    "id_str" : "445608489256517633",
    "text" : "Not usually a Tar Heels \/ Huskies fan, but Roy and Geno are right. #GetCoveredNow http:\/\/t.co\/gAut5GUR0L #HookEmHealthcare.",
    "id" : 445608489256517633,
    "created_at" : "2014-03-17 17:11:57 +0000",
    "user" : {
      "name" : "Kevin Durant",
      "screen_name" : "KDTrey5",
      "protected" : false,
      "id_str" : "35936474",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/677535982141333504\/nL7RupTY_normal.jpg",
      "id" : 35936474,
      "verified" : true
    }
  },
  "id" : 445608799790194688,
  "created_at" : "2014-03-17 17:13:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCoveredNow",
      "indices" : [ 92, 106 ]
    }, {
      "text" : "14DaysLeft",
      "indices" : [ 132, 143 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/CPdSUli151",
      "expanded_url" : "http:\/\/go.wh.gov\/9tcApZ",
      "display_url" : "go.wh.gov\/9tcApZ"
    } ]
  },
  "geo" : { },
  "id_str" : "445606277386096640",
  "text" : "Hey Tar Heels &amp; Huskies! Roy Williams and Geno Auriemma want you to beat the buzzer and #GetCoveredNow \u2192 http:\/\/t.co\/CPdSUli151 #14DaysLeft",
  "id" : 445606277386096640,
  "created_at" : "2014-03-17 17:03:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bracketology",
      "indices" : [ 26, 39 ]
    }, {
      "text" : "GetCoveredNow",
      "indices" : [ 76, 90 ]
    }, {
      "text" : "GIFsIncluded",
      "indices" : [ 116, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/Pn1zVmnRgV",
      "expanded_url" : "http:\/\/go.wh.gov\/c9PhVd",
      "display_url" : "go.wh.gov\/c9PhVd"
    } ]
  },
  "geo" : { },
  "id_str" : "445598183901503488",
  "text" : "Time for some health care #bracketology! Vote on the 16 sweetest reasons to #GetCoveredNow \u2192 http:\/\/t.co\/Pn1zVmnRgV #GIFsIncluded",
  "id" : 445598183901503488,
  "created_at" : "2014-03-17 16:31:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ukraine",
      "indices" : [ 62, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445572988822618112",
  "text" : "President Obama: \"The United States stands with the people of #Ukraine and their right to determine their own destiny.\"",
  "id" : 445572988822618112,
  "created_at" : "2014-03-17 14:50:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ukraine",
      "indices" : [ 129, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445572451653935104",
  "text" : "Obama: \"We\u2019ll continue to make clear to Russia that further provocations will achieve nothing except to further isolate Russia.\" #Ukraine",
  "id" : 445572451653935104,
  "created_at" : "2014-03-17 14:48:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ukraine",
      "indices" : [ 72, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/Xa4XmBKYqr",
      "expanded_url" : "http:\/\/whitehouse.gov\/live",
      "display_url" : "whitehouse.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "445570986336088064",
  "text" : "At 10:45am ET, President Obama delivers a statement on the situation in #Ukraine. Watch \u2192 http:\/\/t.co\/Xa4XmBKYqr",
  "id" : 445570986336088064,
  "created_at" : "2014-03-17 14:42:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 27, 36 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/NSCPress\/status\/445263974766899200\/photo\/1",
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/ZoPV7WUC5q",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bi3lOdeCcAAf5Pe.jpg",
      "id_str" : "445263974771093504",
      "id" : 445263974771093504,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bi3lOdeCcAAf5Pe.jpg",
      "sizes" : [ {
        "h" : 219,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 374,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 124,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 485,
        "resize" : "fit",
        "w" : 1327
      } ],
      "display_url" : "pic.twitter.com\/ZoPV7WUC5q"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445343191261523968",
  "text" : "RT @NSCPress: Statement by @PressSec about the \"referendum\" in Crimea today: http:\/\/t.co\/ZoPV7WUC5q",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Josh Earnest",
        "screen_name" : "PressSec",
        "indices" : [ 13, 22 ],
        "id_str" : "113420831",
        "id" : 113420831
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NSCPress\/status\/445263974766899200\/photo\/1",
        "indices" : [ 63, 85 ],
        "url" : "http:\/\/t.co\/ZoPV7WUC5q",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bi3lOdeCcAAf5Pe.jpg",
        "id_str" : "445263974771093504",
        "id" : 445263974771093504,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bi3lOdeCcAAf5Pe.jpg",
        "sizes" : [ {
          "h" : 219,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 374,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 124,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 485,
          "resize" : "fit",
          "w" : 1327
        } ],
        "display_url" : "pic.twitter.com\/ZoPV7WUC5q"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "445263974766899200",
    "text" : "Statement by @PressSec about the \"referendum\" in Crimea today: http:\/\/t.co\/ZoPV7WUC5q",
    "id" : 445263974766899200,
    "created_at" : "2014-03-16 18:22:58 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 445343191261523968,
  "created_at" : "2014-03-16 23:37:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "445343134059614210",
  "text" : "RT @NSCPress: We will not recognize result of poll held under threat of violence &amp; intimidation from Russian military intervention that vio\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "445264908637446146",
    "text" : "We will not recognize result of poll held under threat of violence &amp; intimidation from Russian military intervention that violates intl law.",
    "id" : 445264908637446146,
    "created_at" : "2014-03-16 18:26:41 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 445343134059614210,
  "created_at" : "2014-03-16 23:37:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/hv0B7P0BLu",
      "expanded_url" : "http:\/\/go.wh.gov\/8mHH54",
      "display_url" : "go.wh.gov\/8mHH54"
    } ]
  },
  "geo" : { },
  "id_str" : "445303736399699969",
  "text" : "\"Whenever I can make sure that our economy rewards hard work &amp; responsibility, that\u2019s what I\u2019m going to do.\" \u2014Obama: http:\/\/t.co\/hv0B7P0BLu",
  "id" : 445303736399699969,
  "created_at" : "2014-03-16 21:00:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WestWingWeek",
      "indices" : [ 14, 27 ]
    }, {
      "text" : "BetweenTwoFerns",
      "indices" : [ 50, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/QVV86EFVbu",
      "expanded_url" : "http:\/\/go.wh.gov\/hffvNu",
      "display_url" : "go.wh.gov\/hffvNu"
    } ]
  },
  "geo" : { },
  "id_str" : "445268173135572992",
  "text" : "In the latest #WestWingWeek, President Obama goes #BetweenTwoFerns to talk about health care &amp; more. Watch \u2192 http:\/\/t.co\/QVV86EFVbu",
  "id" : 445268173135572992,
  "created_at" : "2014-03-16 18:39:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 115, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/hv0B7P0BLu",
      "expanded_url" : "http:\/\/go.wh.gov\/8mHH54",
      "display_url" : "go.wh.gov\/8mHH54"
    } ]
  },
  "geo" : { },
  "id_str" : "445228237317099520",
  "text" : "\"We\u2019ve got to build an economy that works for everybody, not just a fortunate few.\" \u2014Obama: http:\/\/t.co\/hv0B7P0BLu #OpportunityForAll",
  "id" : 445228237317099520,
  "created_at" : "2014-03-16 16:00:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/445216220665503744\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/HFZdzML4E7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bi25yy4CEAAzbgU.jpg",
      "id_str" : "445216220480933888",
      "id" : 445216220480933888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bi25yy4CEAAzbgU.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/HFZdzML4E7"
    } ],
    "hashtags" : [ {
      "text" : "15DaysLeft",
      "indices" : [ 62, 73 ]
    }, {
      "text" : "GetCoveredNow",
      "indices" : [ 75, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/1TD5U6ViYe",
      "expanded_url" : "http:\/\/hc.gov\/o8wHMw",
      "display_url" : "hc.gov\/o8wHMw"
    } ]
  },
  "geo" : { },
  "id_str" : "445216220665503744",
  "text" : "If you or someone you know needs health insurance, you've got #15DaysLeft. #GetCoveredNow \u2192 http:\/\/t.co\/1TD5U6ViYe, http:\/\/t.co\/HFZdzML4E7",
  "id" : 445216220665503744,
  "created_at" : "2014-03-16 15:13:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 118, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/hv0B7P0BLu",
      "expanded_url" : "http:\/\/go.wh.gov\/8mHH54",
      "display_url" : "go.wh.gov\/8mHH54"
    } ]
  },
  "geo" : { },
  "id_str" : "445190488774037505",
  "text" : "President Obama's Weekly Address: Strengthening overtime protections for the American people \u2192 http:\/\/t.co\/hv0B7P0BLu #OpportunityForAll",
  "id" : 445190488774037505,
  "created_at" : "2014-03-16 13:30:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 22, 40 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/hv0B7P0BLu",
      "expanded_url" : "http:\/\/go.wh.gov\/8mHH54",
      "display_url" : "go.wh.gov\/8mHH54"
    } ]
  },
  "geo" : { },
  "id_str" : "444949646876479488",
  "text" : "\"We\u2019ve got to restore #OpportunityForAll\u2014the idea that with hard work and responsibility, you can get ahead.\" \u2014Obama: http:\/\/t.co\/hv0B7P0BLu",
  "id" : 444949646876479488,
  "created_at" : "2014-03-15 21:33:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCoveredNow",
      "indices" : [ 124, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/0lwMLeJwkK",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    }, {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/aeQtEPGNEn",
      "expanded_url" : "http:\/\/youtu.be\/OPMsZYyesRE",
      "display_url" : "youtu.be\/OPMsZYyesRE"
    } ]
  },
  "geo" : { },
  "id_str" : "444933793166528515",
  "text" : "\"We nag you because we love you. So go to http:\/\/t.co\/0lwMLeJwkK and enroll today.\" \u2014The First Lady: http:\/\/t.co\/aeQtEPGNEn #GetCoveredNow",
  "id" : 444933793166528515,
  "created_at" : "2014-03-15 20:30:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 112, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/hv0B7P0BLu",
      "expanded_url" : "http:\/\/go.wh.gov\/8mHH54",
      "display_url" : "go.wh.gov\/8mHH54"
    } ]
  },
  "geo" : { },
  "id_str" : "444918695085608960",
  "text" : "\"Our economy grows best from the middle out, when growth is more widely shared.\" \u2014Obama: http:\/\/t.co\/hv0B7P0BLu #OpportunityForAll",
  "id" : 444918695085608960,
  "created_at" : "2014-03-15 19:30:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/444901874479529984\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/rJXJHr3xjv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Biyb5LBCIAAwGUH.jpg",
      "id_str" : "444901869714808832",
      "id" : 444901869714808832,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Biyb5LBCIAAwGUH.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/rJXJHr3xjv"
    } ],
    "hashtags" : [ {
      "text" : "16DaysLeft",
      "indices" : [ 0, 11 ]
    }, {
      "text" : "GetCoveredNow",
      "indices" : [ 69, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/dOsK8lN2qv",
      "expanded_url" : "http:\/\/hc.gov\/Had2GP",
      "display_url" : "hc.gov\/Had2GP"
    } ]
  },
  "geo" : { },
  "id_str" : "444901874479529984",
  "text" : "#16DaysLeft: RT so anyone who needs to see this knows where they can #GetCoveredNow \u2192 http:\/\/t.co\/dOsK8lN2qv, http:\/\/t.co\/rJXJHr3xjv",
  "id" : 444901874479529984,
  "created_at" : "2014-03-15 18:24:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/Ev2zQF7K7j",
      "expanded_url" : "http:\/\/go.wh.gov\/8mHH54",
      "display_url" : "go.wh.gov\/8mHH54"
    } ]
  },
  "geo" : { },
  "id_str" : "444888732337176577",
  "text" : "\"If you have to work more, you should be able to earn more.\" \u2014President Obama on strengthening overtime protections: http:\/\/t.co\/Ev2zQF7K7j",
  "id" : 444888732337176577,
  "created_at" : "2014-03-15 17:31:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/444600541524410368\/photo\/1",
      "indices" : [ 8, 30 ],
      "url" : "http:\/\/t.co\/MNduvMlmQc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BiuJ1jcCAAAY--i.jpg",
      "id_str" : "444600541365010432",
      "id" : 444600541365010432,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BiuJ1jcCAAAY--i.jpg",
      "sizes" : [ {
        "h" : 386,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 987,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 658,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 218,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/MNduvMlmQc"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "444600541524410368",
  "text" : "Up top! http:\/\/t.co\/MNduvMlmQc",
  "id" : 444600541524410368,
  "created_at" : "2014-03-14 22:26:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Schultz",
      "screen_name" : "Schultz44",
      "indices" : [ 3, 13 ],
      "id_str" : "1603419038",
      "id" : 1603419038
    }, {
      "name" : "ABC News",
      "screen_name" : "ABC",
      "indices" : [ 103, 107 ],
      "id_str" : "28785486",
      "id" : 28785486
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/ZaIPgMVv10",
      "expanded_url" : "http:\/\/abcn.ws\/1cZWob4",
      "display_url" : "abcn.ws\/1cZWob4"
    } ]
  },
  "geo" : { },
  "id_str" : "444591669674250240",
  "text" : "RT @Schultz44: Obama's 'Funny or Die' Skit Over 15 Million Hits - ABC News http:\/\/t.co\/ZaIPgMVv10  via @ABC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ABC News",
        "screen_name" : "ABC",
        "indices" : [ 88, 92 ],
        "id_str" : "28785486",
        "id" : 28785486
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/ZaIPgMVv10",
        "expanded_url" : "http:\/\/abcn.ws\/1cZWob4",
        "display_url" : "abcn.ws\/1cZWob4"
      } ]
    },
    "geo" : { },
    "id_str" : "444589581971619841",
    "text" : "Obama's 'Funny or Die' Skit Over 15 Million Hits - ABC News http:\/\/t.co\/ZaIPgMVv10  via @ABC",
    "id" : 444589581971619841,
    "created_at" : "2014-03-14 21:43:11 +0000",
    "user" : {
      "name" : "Eric Schultz",
      "screen_name" : "Schultz44",
      "protected" : false,
      "id_str" : "1603419038",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/491941155815161856\/u0IdexM6_normal.jpeg",
      "id" : 1603419038,
      "verified" : true
    }
  },
  "id" : 444591669674250240,
  "created_at" : "2014-03-14 21:51:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russell Simmons",
      "screen_name" : "UncleRUSH",
      "indices" : [ 3, 13 ],
      "id_str" : "25110374",
      "id" : 25110374
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/UncleRUSH\/status\/444475352195141632\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/4oqcWJKdnl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BisX-ldCEAAXlLe.jpg",
      "id_str" : "444475352199335936",
      "id" : 444475352199335936,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BisX-ldCEAAXlLe.jpg",
      "sizes" : [ {
        "h" : 269,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 475,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 475,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 475,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/4oqcWJKdnl"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 43, 54 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/IYg5huJzwj",
      "expanded_url" : "http:\/\/healthcare.gov",
      "display_url" : "healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "444579139782463491",
  "text" : "RT @UncleRUSH: Are you invincible? If not, #GetCovered by March 31st! Sign up NOW at http:\/\/t.co\/IYg5huJzwj! RT! http:\/\/t.co\/4oqcWJKdnl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/UncleRUSH\/status\/444475352195141632\/photo\/1",
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/4oqcWJKdnl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BisX-ldCEAAXlLe.jpg",
        "id_str" : "444475352199335936",
        "id" : 444475352199335936,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BisX-ldCEAAXlLe.jpg",
        "sizes" : [ {
          "h" : 269,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 475,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 475,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 475,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/4oqcWJKdnl"
      } ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 28, 39 ]
      } ],
      "urls" : [ {
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/IYg5huJzwj",
        "expanded_url" : "http:\/\/healthcare.gov",
        "display_url" : "healthcare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "444475352195141632",
    "text" : "Are you invincible? If not, #GetCovered by March 31st! Sign up NOW at http:\/\/t.co\/IYg5huJzwj! RT! http:\/\/t.co\/4oqcWJKdnl",
    "id" : 444475352195141632,
    "created_at" : "2014-03-14 14:09:16 +0000",
    "user" : {
      "name" : "Russell Simmons",
      "screen_name" : "UncleRUSH",
      "protected" : false,
      "id_str" : "25110374",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/748232081008959488\/0fWqh6-F_normal.jpg",
      "id" : 25110374,
      "verified" : true
    }
  },
  "id" : 444579139782463491,
  "created_at" : "2014-03-14 21:01:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Questlove Gomez",
      "screen_name" : "questlove",
      "indices" : [ 3, 13 ],
      "id_str" : "14939981",
      "id" : 14939981
    }, {
      "name" : "HealthCare.gov",
      "screen_name" : "HealthCareGov",
      "indices" : [ 131, 145 ],
      "id_str" : "86697288",
      "id" : 86697288
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/sQBlrpnROp",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "444573365140193280",
  "text" : "RT @questlove: LEAST you can do is take time out for your sake (&amp; loved ones) &amp; see your options at http:\/\/t.co\/sQBlrpnROp @HealthCareGov #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "HealthCare.gov",
        "screen_name" : "HealthCareGov",
        "indices" : [ 116, 130 ],
        "id_str" : "86697288",
        "id" : 86697288
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 131, 142 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/sQBlrpnROp",
        "expanded_url" : "http:\/\/HealthCare.gov",
        "display_url" : "HealthCare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "444507384304910336",
    "text" : "LEAST you can do is take time out for your sake (&amp; loved ones) &amp; see your options at http:\/\/t.co\/sQBlrpnROp @HealthCareGov #GetCovered",
    "id" : 444507384304910336,
    "created_at" : "2014-03-14 16:16:33 +0000",
    "user" : {
      "name" : "Questlove Gomez",
      "screen_name" : "questlove",
      "protected" : false,
      "id_str" : "14939981",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796368697044692992\/dRIVbCqc_normal.jpg",
      "id" : 14939981,
      "verified" : true
    }
  },
  "id" : 444573365140193280,
  "created_at" : "2014-03-14 20:38:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LiveLongandProsper",
      "indices" : [ 35, 54 ]
    }, {
      "text" : "geeksgetcovered",
      "indices" : [ 121, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/gUhGcP8uxo",
      "expanded_url" : "http:\/\/healthcare.gov",
      "display_url" : "healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "444569041290936320",
  "text" : "RT @whitehouseostp: We want all to #LiveLongandProsper. Visit http:\/\/t.co\/gUhGcP8uxo by 3\/31, and share your story using #geeksgetcovered h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LiveLongandProsper",
        "indices" : [ 15, 34 ]
      }, {
        "text" : "geeksgetcovered",
        "indices" : [ 101, 117 ]
      } ],
      "urls" : [ {
        "indices" : [ 42, 64 ],
        "url" : "http:\/\/t.co\/gUhGcP8uxo",
        "expanded_url" : "http:\/\/healthcare.gov",
        "display_url" : "healthcare.gov"
      }, {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/0jCI2BkZAc",
        "expanded_url" : "http:\/\/twitpic.com\/95b6ki",
        "display_url" : "twitpic.com\/95b6ki"
      } ]
    },
    "geo" : { },
    "id_str" : "444518185698852864",
    "text" : "We want all to #LiveLongandProsper. Visit http:\/\/t.co\/gUhGcP8uxo by 3\/31, and share your story using #geeksgetcovered http:\/\/t.co\/0jCI2BkZAc",
    "id" : 444518185698852864,
    "created_at" : "2014-03-14 16:59:28 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 444569041290936320,
  "created_at" : "2014-03-14 20:21:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/444559892615921664\/photo\/1",
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/vUR8YYOCqm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bitk3edCUAAAFwH.jpg",
      "id_str" : "444559892456558592",
      "id" : 444559892456558592,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bitk3edCUAAAFwH.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/vUR8YYOCqm"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "444559892615921664",
  "text" : "Happy \u03C0 Day! http:\/\/t.co\/vUR8YYOCqm",
  "id" : 444559892615921664,
  "created_at" : "2014-03-14 19:45:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonah Hill",
      "screen_name" : "JonahHill",
      "indices" : [ 84, 94 ],
      "id_str" : "256573865",
      "id" : 256573865
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCoveredNow",
      "indices" : [ 125, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/aeQtEPGNEn",
      "expanded_url" : "http:\/\/youtu.be\/OPMsZYyesRE",
      "display_url" : "youtu.be\/OPMsZYyesRE"
    } ]
  },
  "geo" : { },
  "id_str" : "444543715042807812",
  "text" : "\"Do you want your mothers to have a nervous breakdown? You need health insurance.\" \u2014@JonahHill's mom: http:\/\/t.co\/aeQtEPGNEn #GetCoveredNow",
  "id" : 444543715042807812,
  "created_at" : "2014-03-14 18:40:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LeVar Burton",
      "screen_name" : "levarburton",
      "indices" : [ 3, 15 ],
      "id_str" : "18396070",
      "id" : 18396070
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "geeksgetcovered",
      "indices" : [ 82, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/dYTjvAcrL1",
      "expanded_url" : "http:\/\/healthcare.gov",
      "display_url" : "healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "444535328691736576",
  "text" : "RT @levarburton: Pi goes on forever, but the deadline to get covered is March 31. #geeksgetcovered http:\/\/t.co\/dYTjvAcrL1 \u03C0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "geeksgetcovered",
        "indices" : [ 65, 81 ]
      } ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/dYTjvAcrL1",
        "expanded_url" : "http:\/\/healthcare.gov",
        "display_url" : "healthcare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "444497236517335041",
    "text" : "Pi goes on forever, but the deadline to get covered is March 31. #geeksgetcovered http:\/\/t.co\/dYTjvAcrL1 \u03C0",
    "id" : 444497236517335041,
    "created_at" : "2014-03-14 15:36:14 +0000",
    "user" : {
      "name" : "LeVar Burton",
      "screen_name" : "levarburton",
      "protected" : false,
      "id_str" : "18396070",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796350503001137152\/XFySV_Qz_normal.jpg",
      "id" : 18396070,
      "verified" : true
    }
  },
  "id" : 444535328691736576,
  "created_at" : "2014-03-14 18:07:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LeBron James",
      "screen_name" : "KingJames",
      "indices" : [ 70, 80 ],
      "id_str" : "23083404",
      "id" : 23083404
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "17DaysLeft",
      "indices" : [ 5, 16 ]
    }, {
      "text" : "GetCoveredNow",
      "indices" : [ 85, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/Jcyd1GfPVu",
      "expanded_url" : "http:\/\/youtu.be\/Irkdx5iB0S0",
      "display_url" : "youtu.be\/Irkdx5iB0S0"
    } ]
  },
  "geo" : { },
  "id_str" : "444521066220638208",
  "text" : "Just #17DaysLeft to sign up for health insurance: Take an assist from @KingJames and #GetCoveredNow \u2192 http:\/\/t.co\/Jcyd1GfPVu",
  "id" : 444521066220638208,
  "created_at" : "2014-03-14 17:10:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alicia Keys",
      "screen_name" : "aliciakeys",
      "indices" : [ 3, 14 ],
      "id_str" : "35094637",
      "id" : 35094637
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 67, 74 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "YourMomCares",
      "indices" : [ 121, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "444515843251376128",
  "text" : "RT @aliciakeys: Calling all my people out there! Join my mom &amp; @FLOTUS in helping America\u2019s young adults get covered #YourMomCares http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The First Lady",
        "screen_name" : "FLOTUS",
        "indices" : [ 51, 58 ],
        "id_str" : "1093090866",
        "id" : 1093090866
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "YourMomCares",
        "indices" : [ 105, 118 ]
      } ],
      "urls" : [ {
        "indices" : [ 119, 141 ],
        "url" : "http:\/\/t.co\/eB7w0S4LZt",
        "expanded_url" : "http:\/\/youtu.be\/OPMsZYyesRE",
        "display_url" : "youtu.be\/OPMsZYyesRE"
      } ]
    },
    "geo" : { },
    "id_str" : "444479562433699840",
    "text" : "Calling all my people out there! Join my mom &amp; @FLOTUS in helping America\u2019s young adults get covered #YourMomCares http:\/\/t.co\/eB7w0S4LZt",
    "id" : 444479562433699840,
    "created_at" : "2014-03-14 14:26:00 +0000",
    "user" : {
      "name" : "Alicia Keys",
      "screen_name" : "aliciakeys",
      "protected" : false,
      "id_str" : "35094637",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/784235369906614272\/IyyZ25fR_normal.jpg",
      "id" : 35094637,
      "verified" : true
    }
  },
  "id" : 444515843251376128,
  "created_at" : "2014-03-14 16:50:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LeBron James",
      "screen_name" : "KingJames",
      "indices" : [ 84, 94 ],
      "id_str" : "23083404",
      "id" : 23083404
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 63, 74 ]
    }, {
      "text" : "17DaysLeft",
      "indices" : [ 119, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/Jcyd1GfPVu",
      "expanded_url" : "http:\/\/youtu.be\/Irkdx5iB0S0",
      "display_url" : "youtu.be\/Irkdx5iB0S0"
    } ]
  },
  "geo" : { },
  "id_str" : "444508482318774273",
  "text" : "\"You never know when you might take a hit. Spread the word and #GetCovered today.\" \u2014@KingJames: http:\/\/t.co\/Jcyd1GfPVu #17DaysLeft",
  "id" : 444508482318774273,
  "created_at" : "2014-03-14 16:20:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "17DaysLeft",
      "indices" : [ 38, 49 ]
    }, {
      "text" : "GetCoveredNow",
      "indices" : [ 83, 97 ]
    }, {
      "text" : "HappyPiDay",
      "indices" : [ 123, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/etwDPacfrL",
      "expanded_url" : "http:\/\/hc.gov\/iqUbFH",
      "display_url" : "hc.gov\/iqUbFH"
    } ]
  },
  "geo" : { },
  "id_str" : "444502981007142912",
  "text" : "\u03C0 goes on forever, but there are only #17DaysLeft to sign up for health insurance. #GetCoveredNow \u2192 http:\/\/t.co\/etwDPacfrL #HappyPiDay",
  "id" : 444502981007142912,
  "created_at" : "2014-03-14 15:59:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WebMD",
      "screen_name" : "WebMD",
      "indices" : [ 39, 45 ],
      "id_str" : "25928253",
      "id" : 25928253
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCoveredNow",
      "indices" : [ 125, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/3cF8MAWp5q",
      "expanded_url" : "http:\/\/go.wh.gov\/LN8Roi",
      "display_url" : "go.wh.gov\/LN8Roi"
    } ]
  },
  "geo" : { },
  "id_str" : "444498053056442368",
  "text" : "Watch President Obama's interview with @WebMD\u2014where he answers questions on the Affordable Care Act \u2192 http:\/\/t.co\/3cF8MAWp5q #GetCoveredNow",
  "id" : 444498053056442368,
  "created_at" : "2014-03-14 15:39:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/CNqHfX7XGs",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    }, {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/NxgwnqAhEW",
      "expanded_url" : "http:\/\/youtu.be\/OPMsZYyesRE",
      "display_url" : "youtu.be\/OPMsZYyesRE"
    } ]
  },
  "geo" : { },
  "id_str" : "444491618478227456",
  "text" : "RT @FLOTUS: \"We nag you because we love you. So go to http:\/\/t.co\/CNqHfX7XGs and enroll today.\" \u2014The First Lady: http:\/\/t.co\/NxgwnqAhEW #Ge\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCoveredNow",
        "indices" : [ 124, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 42, 64 ],
        "url" : "http:\/\/t.co\/CNqHfX7XGs",
        "expanded_url" : "http:\/\/Healthcare.gov",
        "display_url" : "Healthcare.gov"
      }, {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/NxgwnqAhEW",
        "expanded_url" : "http:\/\/youtu.be\/OPMsZYyesRE",
        "display_url" : "youtu.be\/OPMsZYyesRE"
      } ]
    },
    "geo" : { },
    "id_str" : "444490747308683264",
    "text" : "\"We nag you because we love you. So go to http:\/\/t.co\/CNqHfX7XGs and enroll today.\" \u2014The First Lady: http:\/\/t.co\/NxgwnqAhEW #GetCoveredNow",
    "id" : 444490747308683264,
    "created_at" : "2014-03-14 15:10:27 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 444491618478227456,
  "created_at" : "2014-03-14 15:13:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "POPSUGAR",
      "screen_name" : "POPSUGAR",
      "indices" : [ 3, 12 ],
      "id_str" : "14833304",
      "id" : 14833304
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "YourMomCares",
      "indices" : [ 104, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/EdcGmRUeG2",
      "expanded_url" : "http:\/\/popsu.gr\/34351304",
      "display_url" : "popsu.gr\/34351304"
    } ]
  },
  "geo" : { },
  "id_str" : "444486154990415872",
  "text" : "RT @POPSUGAR: Jonah Hill's mom is just like Jonah HIll + she wants you to sign up for health insurance! #YourMomCares http:\/\/t.co\/EdcGmRUeG2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.onsugar.com\" rel=\"nofollow\"\u003EOnSugar.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "YourMomCares",
        "indices" : [ 90, 103 ]
      } ],
      "urls" : [ {
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/EdcGmRUeG2",
        "expanded_url" : "http:\/\/popsu.gr\/34351304",
        "display_url" : "popsu.gr\/34351304"
      } ]
    },
    "geo" : { },
    "id_str" : "444415666796642305",
    "text" : "Jonah Hill's mom is just like Jonah HIll + she wants you to sign up for health insurance! #YourMomCares http:\/\/t.co\/EdcGmRUeG2",
    "id" : 444415666796642305,
    "created_at" : "2014-03-14 10:12:06 +0000",
    "user" : {
      "name" : "POPSUGAR",
      "screen_name" : "POPSUGAR",
      "protected" : false,
      "id_str" : "14833304",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/675041876668522496\/K-XYT0pQ_normal.png",
      "id" : 14833304,
      "verified" : true
    }
  },
  "id" : 444486154990415872,
  "created_at" : "2014-03-14 14:52:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/444266332020678658\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/NY15GAlsza",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BipZ4ACCEAAoYqM.jpg",
      "id_str" : "444266331865485312",
      "id" : 444266331865485312,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BipZ4ACCEAAoYqM.jpg",
      "sizes" : [ {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/NY15GAlsza"
    } ],
    "hashtags" : [ {
      "text" : "GetCoveredNow",
      "indices" : [ 0, 14 ]
    }, {
      "text" : "TBT",
      "indices" : [ 84, 88 ]
    }, {
      "text" : "ThrowbackThursday",
      "indices" : [ 89, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/AcUq7l24WE",
      "expanded_url" : "http:\/\/hc.gov\/rx87fN",
      "display_url" : "hc.gov\/rx87fN"
    } ]
  },
  "geo" : { },
  "id_str" : "444266332020678658",
  "text" : "#GetCoveredNow because all moms deserve that peace of mind \u2192 http:\/\/t.co\/AcUq7l24WE #TBT #ThrowbackThursday http:\/\/t.co\/NY15GAlsza",
  "id" : 444266332020678658,
  "created_at" : "2014-03-14 00:18:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 111, 120 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RenewUI",
      "indices" : [ 101, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/qfHP3DT5W2",
      "expanded_url" : "http:\/\/go.wh.gov\/xT4jSB",
      "display_url" : "go.wh.gov\/xT4jSB"
    } ]
  },
  "geo" : { },
  "id_str" : "444256369940905984",
  "text" : "\"We are pleased Democrats &amp; Republicans in the Senate have come together around an agreement to\" #RenewUI \u2014@PressSec: http:\/\/t.co\/qfHP3DT5W2",
  "id" : 444256369940905984,
  "created_at" : "2014-03-13 23:39:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bama Covered",
      "screen_name" : "BamaCovered",
      "indices" : [ 4, 16 ],
      "id_str" : "2204014950",
      "id" : 2204014950
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCoveredNow",
      "indices" : [ 67, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/KdPZhkW0wn",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "444247956594884608",
  "text" : "Hey @BamaCovered, thanks for all you're doing to help young people #GetCoveredNow at http:\/\/t.co\/KdPZhkW0wn. Keep it up! \u2013bo",
  "id" : 444247956594884608,
  "created_at" : "2014-03-13 23:05:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/444230993298202624\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/eDKjmbfsGK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bio5vA5CYAAIhPk.jpg",
      "id_str" : "444230993105281024",
      "id" : 444230993105281024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bio5vA5CYAAIhPk.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      } ],
      "display_url" : "pic.twitter.com\/eDKjmbfsGK"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "444230993298202624",
  "text" : "\"If you go above and beyond to help your employer...succeed, then you should share...in that success.\" \u2014Obama http:\/\/t.co\/eDKjmbfsGK",
  "id" : 444230993298202624,
  "created_at" : "2014-03-13 21:58:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/444211733297520640\/photo\/1",
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/LRp0jumMHy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BiooN8BCcAA350G.jpg",
      "id_str" : "444211733163307008",
      "id" : 444211733163307008,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BiooN8BCcAA350G.jpg",
      "sizes" : [ {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/LRp0jumMHy"
    } ],
    "hashtags" : [ {
      "text" : "GetCoveredNow",
      "indices" : [ 0, 14 ]
    }, {
      "text" : "BetweenTwoFerns",
      "indices" : [ 73, 89 ]
    }, {
      "text" : "18DaysLeft",
      "indices" : [ 90, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/rvGRHSkhhm",
      "expanded_url" : "http:\/\/youtu.be\/UnW3xkHxIEQ",
      "display_url" : "youtu.be\/UnW3xkHxIEQ"
    } ]
  },
  "geo" : { },
  "id_str" : "444211733297520640",
  "text" : "#GetCoveredNow because\u2026spider bites? Just watch \u2192 http:\/\/t.co\/rvGRHSkhhm #BetweenTwoFerns #18DaysLeft http:\/\/t.co\/LRp0jumMHy",
  "id" : 444211733297520640,
  "created_at" : "2014-03-13 20:41:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "indices" : [ 3, 12 ],
      "id_str" : "1604366701",
      "id" : 1604366701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "444190796032794624",
  "text" : "RT @LaborSec: By updating who qualifies for overtime pay, today\u2019s announcement will give millions a fair shot at getting ahead: http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/KgEmpdqfZT",
        "expanded_url" : "http:\/\/go.wh.gov\/4dhPcR",
        "display_url" : "go.wh.gov\/4dhPcR"
      } ]
    },
    "geo" : { },
    "id_str" : "444180969147617280",
    "text" : "By updating who qualifies for overtime pay, today\u2019s announcement will give millions a fair shot at getting ahead: http:\/\/t.co\/KgEmpdqfZT",
    "id" : 444180969147617280,
    "created_at" : "2014-03-13 18:39:30 +0000",
    "user" : {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "protected" : false,
      "id_str" : "1604366701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744887280666611712\/eEeyFjs6_normal.jpg",
      "id" : 1604366701,
      "verified" : true
    }
  },
  "id" : 444190796032794624,
  "created_at" : "2014-03-13 19:18:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "indices" : [ 3, 15 ],
      "id_str" : "15764644",
      "id" : 15764644
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "444186100186513410",
  "text" : "RT @NancyPelosi: Pres. Obama's action on overtime pay is a strong step in closing the opportunity gap. Now we must do our part in Congress \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "raisethewage",
        "indices" : [ 126, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "444183205848289280",
    "text" : "Pres. Obama's action on overtime pay is a strong step in closing the opportunity gap. Now we must do our part in Congress and #raisethewage.",
    "id" : 444183205848289280,
    "created_at" : "2014-03-13 18:48:23 +0000",
    "user" : {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "protected" : false,
      "id_str" : "15764644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571313158510223360\/wnSl3yXF_normal.jpeg",
      "id" : 15764644,
      "verified" : true
    }
  },
  "id" : 444186100186513410,
  "created_at" : "2014-03-13 18:59:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 125, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "444180055791783936",
  "text" : "Obama: \"If you go above and beyond to help your employer and your economy succeed, then you should share...in that success.\" #RaiseTheWage",
  "id" : 444180055791783936,
  "created_at" : "2014-03-13 18:35:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 117, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "444179706561437697",
  "text" : "RT @WHLive: President Obama: \"Overtime is a pretty simple idea: if you have to work more, you should get paid more.\" #RaiseTheWage",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RaiseTheWage",
        "indices" : [ 105, 118 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "444179538571177984",
    "text" : "President Obama: \"Overtime is a pretty simple idea: if you have to work more, you should get paid more.\" #RaiseTheWage",
    "id" : 444179538571177984,
    "created_at" : "2014-03-13 18:33:49 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 444179706561437697,
  "created_at" : "2014-03-13 18:34:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/444179287738834944\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/n7CZldE9Rp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BioKtWaCMAAoDOo.jpg",
      "id_str" : "444179287474581504",
      "id" : 444179287474581504,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BioKtWaCMAAoDOo.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/n7CZldE9Rp"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "444179287738834944",
  "text" : "President Obama: \"I\u2019ve now called on Congress to give America a raise by raising the minimum wage to $10.10\/hour.\" http:\/\/t.co\/n7CZldE9Rp",
  "id" : 444179287738834944,
  "created_at" : "2014-03-13 18:32:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "18DaysLeft",
      "indices" : [ 121, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/B5fuar0clw",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "444179072370102273",
  "text" : "RT @WHLive: Obama: \"If you know someone who\u2019s uninsured, help them get covered at http:\/\/t.co\/B5fuar0clw by March 31st.\" #18DaysLeft #GetCo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "18DaysLeft",
        "indices" : [ 109, 120 ]
      }, {
        "text" : "GetCoveredNow",
        "indices" : [ 121, 135 ]
      } ],
      "urls" : [ {
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/B5fuar0clw",
        "expanded_url" : "http:\/\/HealthCare.gov",
        "display_url" : "HealthCare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "444178873690120192",
    "text" : "Obama: \"If you know someone who\u2019s uninsured, help them get covered at http:\/\/t.co\/B5fuar0clw by March 31st.\" #18DaysLeft #GetCoveredNow",
    "id" : 444178873690120192,
    "created_at" : "2014-03-13 18:31:10 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 444179072370102273,
  "created_at" : "2014-03-13 18:31:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/444178735709683713\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/XhxNqe0a5S",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BioKNOTCYAEPnLj.jpg",
      "id_str" : "444178735541936129",
      "id" : 444178735541936129,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BioKNOTCYAEPnLj.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/XhxNqe0a5S"
    } ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 63, 72 ]
    }, {
      "text" : "WomenSucceed",
      "indices" : [ 90, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "444178735709683713",
  "text" : "President Obama: \"Making work pay means making sure women earn #EqualPay for equal work.\" #WomenSucceed http:\/\/t.co\/XhxNqe0a5S",
  "id" : 444178735709683713,
  "created_at" : "2014-03-13 18:30:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/444178365642059776\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/Ew8S9ueLEg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BioJ3qICUAA8_hy.jpg",
      "id_str" : "444178365054865408",
      "id" : 444178365054865408,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BioJ3qICUAA8_hy.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Ew8S9ueLEg"
    } ],
    "hashtags" : [ {
      "text" : "ActOnJobs",
      "indices" : [ 101, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "444178365642059776",
  "text" : "President Obama: \"Our businesses have created more than 8.5 million new jobs over the past 4 years.\" #ActOnJobs http:\/\/t.co\/Ew8S9ueLEg",
  "id" : 444178365642059776,
  "created_at" : "2014-03-13 18:29:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 122, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/kOFHxPTHzN",
      "expanded_url" : "http:\/\/go.wh.gov\/DirxvC",
      "display_url" : "go.wh.gov\/DirxvC"
    } ]
  },
  "geo" : { },
  "id_str" : "444175073906536448",
  "text" : "Watch President Obama speak on strengthening overtime protections for more Americans at 2:20pm ET: http:\/\/t.co\/kOFHxPTHzN #RaiseTheWage",
  "id" : 444175073906536448,
  "created_at" : "2014-03-13 18:16:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "indices" : [ 3, 12 ],
      "id_str" : "1604366701",
      "id" : 1604366701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "444167296345726976",
  "text" : "RT @LaborSec: Joining POTUS today to announce how we will strengthen overtime rules to help workers receive the pay they deserve: http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/KgEmpdqfZT",
        "expanded_url" : "http:\/\/go.wh.gov\/4dhPcR",
        "display_url" : "go.wh.gov\/4dhPcR"
      } ]
    },
    "geo" : { },
    "id_str" : "444155828950810625",
    "text" : "Joining POTUS today to announce how we will strengthen overtime rules to help workers receive the pay they deserve: http:\/\/t.co\/KgEmpdqfZT",
    "id" : 444155828950810625,
    "created_at" : "2014-03-13 16:59:36 +0000",
    "user" : {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "protected" : false,
      "id_str" : "1604366701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744887280666611712\/eEeyFjs6_normal.jpg",
      "id" : 1604366701,
      "verified" : true
    }
  },
  "id" : 444167296345726976,
  "created_at" : "2014-03-13 17:45:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "indices" : [ 4, 12 ],
      "id_str" : "807095",
      "id" : 807095
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 123, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/vNQ2Zkqq4c",
      "expanded_url" : "http:\/\/nyti.ms\/1qxUAta",
      "display_url" : "nyti.ms\/1qxUAta"
    } ]
  },
  "geo" : { },
  "id_str" : "444159930136657923",
  "text" : "The @NYTimes on how President Obama is helping more workers receive extra pay for working overtime: http:\/\/t.co\/vNQ2Zkqq4c #RaiseTheWage",
  "id" : 444159930136657923,
  "created_at" : "2014-03-13 17:15:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "indices" : [ 28, 37 ],
      "id_str" : "1604366701",
      "id" : 1604366701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/QCZUGhaNUE",
      "expanded_url" : "http:\/\/go.wh.gov\/4dhPcR",
      "display_url" : "go.wh.gov\/4dhPcR"
    } ]
  },
  "geo" : { },
  "id_str" : "444151139823783936",
  "text" : "President Obama will direct @LaborSec to strengthen overtime rules to help more workers receive the pay they deserve: http:\/\/t.co\/QCZUGhaNUE",
  "id" : 444151139823783936,
  "created_at" : "2014-03-13 16:40:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCoveredNow",
      "indices" : [ 96, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/g840b6cIP2",
      "expanded_url" : "http:\/\/hc.gov\/cp4pvx",
      "display_url" : "hc.gov\/cp4pvx"
    } ]
  },
  "geo" : { },
  "id_str" : "444145446949507072",
  "text" : "RT @VP: 18: The number of days left to sign up for affordable health insurance. Don\u2019t forget to #GetCoveredNow. http:\/\/t.co\/g840b6cIP2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCoveredNow",
        "indices" : [ 88, 102 ]
      } ],
      "urls" : [ {
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/g840b6cIP2",
        "expanded_url" : "http:\/\/hc.gov\/cp4pvx",
        "display_url" : "hc.gov\/cp4pvx"
      } ]
    },
    "geo" : { },
    "id_str" : "444138204686712832",
    "text" : "18: The number of days left to sign up for affordable health insurance. Don\u2019t forget to #GetCoveredNow. http:\/\/t.co\/g840b6cIP2",
    "id" : 444138204686712832,
    "created_at" : "2014-03-13 15:49:34 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 444145446949507072,
  "created_at" : "2014-03-13 16:18:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/444135082664534017\/photo\/1",
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/PEEopuwxpA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BinigRuCEAAJEAP.jpg",
      "id_str" : "444135082412871680",
      "id" : 444135082412871680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BinigRuCEAAJEAP.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/PEEopuwxpA"
    } ],
    "hashtags" : [ {
      "text" : "18DaysLeft",
      "indices" : [ 0, 11 ]
    }, {
      "text" : "GetCoveredNow",
      "indices" : [ 62, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/pL0DR5JlWW",
      "expanded_url" : "http:\/\/hc.gov\/cp4pvx",
      "display_url" : "hc.gov\/cp4pvx"
    } ]
  },
  "geo" : { },
  "id_str" : "444135082664534017",
  "text" : "#18DaysLeft: If someone you know is uninsured, make sure they #GetCoveredNow \u2192 http:\/\/t.co\/pL0DR5JlWW http:\/\/t.co\/PEEopuwxpA",
  "id" : 444135082664534017,
  "created_at" : "2014-03-13 15:37:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EnrollTide",
      "indices" : [ 119, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/5sVK9JoAdA",
      "expanded_url" : "http:\/\/nyti.ms\/1fVnIYh",
      "display_url" : "nyti.ms\/1fVnIYh"
    } ]
  },
  "geo" : { },
  "id_str" : "444111144996048896",
  "text" : "Some inspiration from students in Alabama who are helping people sign up for health insurance \u2192 http:\/\/t.co\/5sVK9JoAdA #EnrollTide",
  "id" : 444111144996048896,
  "created_at" : "2014-03-13 14:02:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443927991316660224",
  "text" : "RT @FLOTUS: \"I may not be a Marine\u2014but I am marine life. I salute you!\" \u2014Kermit honoring kids from military families with FLOTUS http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/FLOTUS\/status\/443926558181318657\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/6JSSrGvntB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bikk2jpCQAAr_oX.jpg",
        "id_str" : "443926557971595264",
        "id" : 443926557971595264,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bikk2jpCQAAr_oX.jpg",
        "sizes" : [ {
          "h" : 458,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 259,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 781,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 839,
          "resize" : "fit",
          "w" : 1100
        } ],
        "display_url" : "pic.twitter.com\/6JSSrGvntB"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "443926558181318657",
    "text" : "\"I may not be a Marine\u2014but I am marine life. I salute you!\" \u2014Kermit honoring kids from military families with FLOTUS http:\/\/t.co\/6JSSrGvntB",
    "id" : 443926558181318657,
    "created_at" : "2014-03-13 01:48:33 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 443927991316660224,
  "created_at" : "2014-03-13 01:54:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bobby Harrison ",
      "screen_name" : "bobby44",
      "indices" : [ 3, 11 ],
      "id_str" : "2806537362",
      "id" : 2806537362
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ASweetChoice4SBA",
      "indices" : [ 107, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443903188434178048",
  "text" : "RT @Bobby44: 700 small biz owners and organizations called on the Senate to confirm Maria Contreras-Sweet. #ASweetChoice4SBA --&gt; http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ASweetChoice4SBA",
        "indices" : [ 94, 111 ]
      } ],
      "urls" : [ {
        "indices" : [ 119, 141 ],
        "url" : "http:\/\/t.co\/vYNsixJMd6",
        "expanded_url" : "http:\/\/cnb.cx\/1iBd4Um",
        "display_url" : "cnb.cx\/1iBd4Um"
      } ]
    },
    "geo" : { },
    "id_str" : "443828329456869376",
    "text" : "700 small biz owners and organizations called on the Senate to confirm Maria Contreras-Sweet. #ASweetChoice4SBA --&gt; http:\/\/t.co\/vYNsixJMd6",
    "id" : 443828329456869376,
    "created_at" : "2014-03-12 19:18:14 +0000",
    "user" : {
      "name" : "Brandi Hoffine",
      "screen_name" : "Hoffine44",
      "protected" : false,
      "id_str" : "1665298740",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/502212746134302720\/RqyFWrpZ_normal.jpeg",
      "id" : 1665298740,
      "verified" : true
    }
  },
  "id" : 443903188434178048,
  "created_at" : "2014-03-13 00:15:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "indices" : [ 3, 15 ],
      "id_str" : "15764644",
      "id" : 15764644
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WomenSucceed",
      "indices" : [ 109, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/mDstpoQjUD",
      "expanded_url" : "http:\/\/go.wh.gov\/Aw5Ny2",
      "display_url" : "go.wh.gov\/Aw5Ny2"
    } ]
  },
  "geo" : { },
  "id_str" : "443864681166680064",
  "text" : "RT @NancyPelosi: An economic update on American women in the workforce, in 3 charts \u2192 http:\/\/t.co\/mDstpoQjUD #WomenSucceed",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WomenSucceed",
        "indices" : [ 92, 105 ]
      } ],
      "urls" : [ {
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/mDstpoQjUD",
        "expanded_url" : "http:\/\/go.wh.gov\/Aw5Ny2",
        "display_url" : "go.wh.gov\/Aw5Ny2"
      } ]
    },
    "geo" : { },
    "id_str" : "443824184897306624",
    "text" : "An economic update on American women in the workforce, in 3 charts \u2192 http:\/\/t.co\/mDstpoQjUD #WomenSucceed",
    "id" : 443824184897306624,
    "created_at" : "2014-03-12 19:01:46 +0000",
    "user" : {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "protected" : false,
      "id_str" : "15764644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571313158510223360\/wnSl3yXF_normal.jpeg",
      "id" : 15764644,
      "verified" : true
    }
  },
  "id" : 443864681166680064,
  "created_at" : "2014-03-12 21:42:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Senator Patty Murray",
      "screen_name" : "PattyMurray",
      "indices" : [ 3, 15 ],
      "id_str" : "293131808",
      "id" : 293131808
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 27, 38 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 58, 63 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 96, 109 ]
    }, {
      "text" : "PaycheckFairness",
      "indices" : [ 116, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443856341606871041",
  "text" : "RT @PattyMurray: Headed to @WhiteHouse to speak w\/ POTUS, @vj44 &amp; others about prioritizing #RaiseTheWage &amp; #PaycheckFairness. -PM #WomenSu\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 10, 21 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "Valerie Jarrett",
        "screen_name" : "vj44",
        "indices" : [ 41, 46 ],
        "id_str" : "595515713",
        "id" : 595515713
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RaiseTheWage",
        "indices" : [ 79, 92 ]
      }, {
        "text" : "PaycheckFairness",
        "indices" : [ 99, 116 ]
      }, {
        "text" : "WomenSucceed",
        "indices" : [ 122, 135 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "443840597632507904",
    "text" : "Headed to @WhiteHouse to speak w\/ POTUS, @vj44 &amp; others about prioritizing #RaiseTheWage &amp; #PaycheckFairness. -PM #WomenSucceed",
    "id" : 443840597632507904,
    "created_at" : "2014-03-12 20:06:59 +0000",
    "user" : {
      "name" : "Senator Patty Murray",
      "screen_name" : "PattyMurray",
      "protected" : false,
      "id_str" : "293131808",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430384292917555200\/ULj2LMsW_normal.jpeg",
      "id" : 293131808,
      "verified" : true
    }
  },
  "id" : 443856341606871041,
  "created_at" : "2014-03-12 21:09:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WomenSucceed",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/sCJesCCf5I",
      "expanded_url" : "http:\/\/go.wh.gov\/PoXSZM",
      "display_url" : "go.wh.gov\/PoXSZM"
    } ]
  },
  "geo" : { },
  "id_str" : "443849512000696321",
  "text" : "Women earn just $0.77 for every $1 men earn. Here's how raising the min wage would help close that gap: http:\/\/t.co\/sCJesCCf5I #WomenSucceed",
  "id" : 443849512000696321,
  "created_at" : "2014-03-12 20:42:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/443832552978014208\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/NuqKqu1vpL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BijPWvCCEAExAnY.jpg",
      "id_str" : "443832552785055745",
      "id" : 443832552785055745,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BijPWvCCEAExAnY.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/NuqKqu1vpL"
    } ],
    "hashtags" : [ {
      "text" : "WomenSucceed",
      "indices" : [ 103, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443832552978014208",
  "text" : "FACT: The average woman loses $431,000 in earnings due to the wage gap.\n\nRT if you agree that's wrong. #WomenSucceed http:\/\/t.co\/NuqKqu1vpL",
  "id" : 443832552978014208,
  "created_at" : "2014-03-12 19:35:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/443822263121358848\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/GzNS6V1GHj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BijF_yCCcAAVHNH.jpg",
      "id_str" : "443822262848745472",
      "id" : 443822262848745472,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BijF_yCCcAAVHNH.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/GzNS6V1GHj"
    } ],
    "hashtags" : [ {
      "text" : "WomenSucceed",
      "indices" : [ 47, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/y3z0BLsPJf",
      "expanded_url" : "http:\/\/go.wh.gov\/Aw5Ny2",
      "display_url" : "go.wh.gov\/Aw5Ny2"
    } ]
  },
  "geo" : { },
  "id_str" : "443822263121358848",
  "text" : "Here's how raising the minimum wage would help #WomenSucceed by closing the wage gap \u2192 http:\/\/t.co\/y3z0BLsPJf, http:\/\/t.co\/GzNS6V1GHj",
  "id" : 443822263121358848,
  "created_at" : "2014-03-12 18:54:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WomenSucceed",
      "indices" : [ 5, 18 ]
    }, {
      "text" : "EqualPay",
      "indices" : [ 78, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/57q03WuYzT",
      "expanded_url" : "http:\/\/go.wh.gov\/Aw5Ny2",
      "display_url" : "go.wh.gov\/Aw5Ny2"
    } ]
  },
  "geo" : { },
  "id_str" : "443816125407961088",
  "text" : "When #WomenSucceed, America succeeds. Here's why we need to keep fighting for #EqualPay for women \u2192 http:\/\/t.co\/57q03WuYzT",
  "id" : 443816125407961088,
  "created_at" : "2014-03-12 18:29:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Cosmo For Latinas",
      "screen_name" : "CosmoForLatinas",
      "indices" : [ 22, 38 ],
      "id_str" : "540053944",
      "id" : 540053944
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/lacasablanca\/status\/443064265285451777\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/zph46yvMe1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BiYUmhGCQAE85h-.jpg",
      "id_str" : "443064265293840385",
      "id" : 443064265293840385,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BiYUmhGCQAE85h-.jpg",
      "sizes" : [ {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/zph46yvMe1"
    } ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 89, 93 ]
    }, {
      "text" : "WHCosmoChat",
      "indices" : [ 103, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443811414567059456",
  "text" : "RT @vj44: I'm joining @CosmoforLatinas today @ 3ET for a live chat on Google+. Send your #ACA Q's with #WHCosmoChat http:\/\/t.co\/zph46yvMe1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Cosmo For Latinas",
        "screen_name" : "CosmoForLatinas",
        "indices" : [ 12, 28 ],
        "id_str" : "540053944",
        "id" : 540053944
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/lacasablanca\/status\/443064265285451777\/photo\/1",
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/zph46yvMe1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BiYUmhGCQAE85h-.jpg",
        "id_str" : "443064265293840385",
        "id" : 443064265293840385,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BiYUmhGCQAE85h-.jpg",
        "sizes" : [ {
          "h" : 500,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/zph46yvMe1"
      } ],
      "hashtags" : [ {
        "text" : "ACA",
        "indices" : [ 79, 83 ]
      }, {
        "text" : "WHCosmoChat",
        "indices" : [ 93, 105 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "443810922650664960",
    "text" : "I'm joining @CosmoforLatinas today @ 3ET for a live chat on Google+. Send your #ACA Q's with #WHCosmoChat http:\/\/t.co\/zph46yvMe1",
    "id" : 443810922650664960,
    "created_at" : "2014-03-12 18:09:04 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 443811414567059456,
  "created_at" : "2014-03-12 18:11:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCoveredNow",
      "indices" : [ 42, 56 ]
    }, {
      "text" : "19DaysLeft",
      "indices" : [ 129, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/0fETDz0tuo",
      "expanded_url" : "http:\/\/hc.gov\/gnS2XP",
      "display_url" : "hc.gov\/gnS2XP"
    } ]
  },
  "geo" : { },
  "id_str" : "443804363962974208",
  "text" : "FACT: Many people can fill out the app to #GetCoveredNow in 19 mins or less so they can shop for a plan \u2192 http:\/\/t.co\/0fETDz0tuo #19DaysLeft",
  "id" : 443804363962974208,
  "created_at" : "2014-03-12 17:43:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Washington Post",
      "screen_name" : "washingtonpost",
      "indices" : [ 4, 19 ],
      "id_str" : "2467791",
      "id" : 2467791
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BetweenTwoFerns",
      "indices" : [ 21, 37 ]
    }, {
      "text" : "GetCoveredNow",
      "indices" : [ 120, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/0lwMLeJwkK",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    }, {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/o5dC0CEwDc",
      "expanded_url" : "http:\/\/wapo.st\/1qvJ9lO",
      "display_url" : "wapo.st\/1qvJ9lO"
    } ]
  },
  "geo" : { },
  "id_str" : "443793760439132160",
  "text" : "The @WashingtonPost: #BetweenTwoFerns video leads to 40% more visits to http:\/\/t.co\/0lwMLeJwkK \u2192 http:\/\/t.co\/o5dC0CEwDc #GetCoveredNow",
  "id" : 443793760439132160,
  "created_at" : "2014-03-12 17:00:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/443784220775682048\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/e2NuJqiP9I",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BiijZbhCQAAX513.jpg",
      "id_str" : "443784220574367744",
      "id" : 443784220574367744,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BiijZbhCQAAX513.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/e2NuJqiP9I"
    } ],
    "hashtags" : [ {
      "text" : "19DaysLeft",
      "indices" : [ 5, 16 ]
    }, {
      "text" : "GetCoveredNow",
      "indices" : [ 75, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/MkGmWP7Wvo",
      "expanded_url" : "http:\/\/hc.gov\/gnS2XP",
      "display_url" : "hc.gov\/gnS2XP"
    } ]
  },
  "geo" : { },
  "id_str" : "443784220775682048",
  "text" : "Only #19DaysLeft to sign up for affordable health insurance. Make sure you #GetCoveredNow \u2192 http:\/\/t.co\/MkGmWP7Wvo, http:\/\/t.co\/e2NuJqiP9I",
  "id" : 443784220775682048,
  "created_at" : "2014-03-12 16:22:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cosmo For Latinas",
      "screen_name" : "CosmoForLatinas",
      "indices" : [ 3, 19 ],
      "id_str" : "540053944",
      "id" : 540053944
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 73, 84 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443782756271927296",
  "text" : "RT @CosmoForLatinas: Don't forget to join to our live chat tomorrow! The @WhiteHouse will answer all your ?'s about health care! https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 52, 63 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/0xjpy2q7KQ",
        "expanded_url" : "https:\/\/plus.google.com\/events\/cbpiv19vm8752ehr5o30svrfl2o",
        "display_url" : "plus.google.com\/events\/cbpiv19\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "443495935633399808",
    "text" : "Don't forget to join to our live chat tomorrow! The @WhiteHouse will answer all your ?'s about health care! https:\/\/t.co\/0xjpy2q7KQ",
    "id" : 443495935633399808,
    "created_at" : "2014-03-11 21:17:25 +0000",
    "user" : {
      "name" : "Cosmo For Latinas",
      "screen_name" : "CosmoForLatinas",
      "protected" : false,
      "id_str" : "540053944",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/561244363649318912\/mCsel1c8_normal.jpeg",
      "id" : 540053944,
      "verified" : true
    }
  },
  "id" : 443782756271927296,
  "created_at" : "2014-03-12 16:17:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Russia",
      "indices" : [ 34, 41 ]
    }, {
      "text" : "Crimea",
      "indices" : [ 87, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443758397151006720",
  "text" : "RT @NSCPress: G-7 Leaders call on #Russia to cease all efforts to change the status of #Crimea contrary to Ukrainian law &amp; in violation of \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Russia",
        "indices" : [ 20, 27 ]
      }, {
        "text" : "Crimea",
        "indices" : [ 73, 80 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "443728632004227072",
    "text" : "G-7 Leaders call on #Russia to cease all efforts to change the status of #Crimea contrary to Ukrainian law &amp; in violation of int'l law.",
    "id" : 443728632004227072,
    "created_at" : "2014-03-12 12:42:04 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 443758397151006720,
  "created_at" : "2014-03-12 14:40:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Schultz",
      "screen_name" : "Schultz44",
      "indices" : [ 3, 13 ],
      "id_str" : "1603419038",
      "id" : 1603419038
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/8RF6ElUHDM",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    }, {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/0VbD64bHvC",
      "expanded_url" : "http:\/\/wapo.st\/1qvJ9lO",
      "display_url" : "wapo.st\/1qvJ9lO"
    } ]
  },
  "geo" : { },
  "id_str" : "443751479527366656",
  "text" : "RT @Schultz44: \u2018Between Two Ferns\u2019 video leads to 40 percent more visits to http:\/\/t.co\/8RF6ElUHDM http:\/\/t.co\/0VbD64bHvC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 83 ],
        "url" : "http:\/\/t.co\/8RF6ElUHDM",
        "expanded_url" : "http:\/\/HealthCare.gov",
        "display_url" : "HealthCare.gov"
      }, {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/0VbD64bHvC",
        "expanded_url" : "http:\/\/wapo.st\/1qvJ9lO",
        "display_url" : "wapo.st\/1qvJ9lO"
      } ]
    },
    "geo" : { },
    "id_str" : "443743537750757376",
    "text" : "\u2018Between Two Ferns\u2019 video leads to 40 percent more visits to http:\/\/t.co\/8RF6ElUHDM http:\/\/t.co\/0VbD64bHvC",
    "id" : 443743537750757376,
    "created_at" : "2014-03-12 13:41:18 +0000",
    "user" : {
      "name" : "Eric Schultz",
      "screen_name" : "Schultz44",
      "protected" : false,
      "id_str" : "1603419038",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/491941155815161856\/u0IdexM6_normal.jpeg",
      "id" : 1603419038,
      "verified" : true
    }
  },
  "id" : 443751479527366656,
  "created_at" : "2014-03-12 14:12:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HealthCare.gov",
      "screen_name" : "HealthCareGov",
      "indices" : [ 3, 17 ],
      "id_str" : "86697288",
      "id" : 86697288
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/zGLCNOxaSv",
      "expanded_url" : "http:\/\/HC.gov",
      "display_url" : "HC.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "443745569895616512",
  "text" : "RT @HealthCareGov: 890k+ visits to http:\/\/t.co\/zGLCNOxaSv on Tues, up 40% from Mon. Lots of consumers shopping to get covered before 3\/31. \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCoveredNow",
        "indices" : [ 120, 134 ]
      } ],
      "urls" : [ {
        "indices" : [ 16, 38 ],
        "url" : "http:\/\/t.co\/zGLCNOxaSv",
        "expanded_url" : "http:\/\/HC.gov",
        "display_url" : "HC.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "443718048609239042",
    "text" : "890k+ visits to http:\/\/t.co\/zGLCNOxaSv on Tues, up 40% from Mon. Lots of consumers shopping to get covered before 3\/31. #GetCoveredNow",
    "id" : 443718048609239042,
    "created_at" : "2014-03-12 12:00:01 +0000",
    "user" : {
      "name" : "HealthCare.gov",
      "screen_name" : "HealthCareGov",
      "protected" : false,
      "id_str" : "86697288",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/528294497105350656\/OXpX0USe_normal.png",
      "id" : 86697288,
      "verified" : true
    }
  },
  "id" : 443745569895616512,
  "created_at" : "2014-03-12 13:49:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gap",
      "screen_name" : "Gap",
      "indices" : [ 31, 35 ],
      "id_str" : "18462157",
      "id" : 18462157
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/443547807148810241\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/5L8Dz5oJkQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BifMYWKCQAEn8W0.jpg",
      "id_str" : "443547806955880449",
      "id" : 443547806955880449,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BifMYWKCQAEn8W0.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/5L8Dz5oJkQ"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 99, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443547807148810241",
  "text" : "President Obama stopped by The @Gap today to highlight how they're raising their employees' wages. #RaiseTheWage, http:\/\/t.co\/5L8Dz5oJkQ",
  "id" : 443547807148810241,
  "created_at" : "2014-03-12 00:43:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/443511860676276225\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/v7qsh20O8a",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bierr_BIQAAqb2j.jpg",
      "id_str" : "443511860458176512",
      "id" : 443511860458176512,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bierr_BIQAAqb2j.jpg",
      "sizes" : [ {
        "h" : 714,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 237,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 418,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 714,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/v7qsh20O8a"
    } ],
    "hashtags" : [ {
      "text" : "California",
      "indices" : [ 98, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443513866409213953",
  "text" : "RT @Interior: Here is a gorgeous photo America's newest National Monument: Point Arena-Stornetta. #California http:\/\/t.co\/v7qsh20O8a",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/443511860676276225\/photo\/1",
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/v7qsh20O8a",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bierr_BIQAAqb2j.jpg",
        "id_str" : "443511860458176512",
        "id" : 443511860458176512,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bierr_BIQAAqb2j.jpg",
        "sizes" : [ {
          "h" : 714,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 237,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 418,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 714,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/v7qsh20O8a"
      } ],
      "hashtags" : [ {
        "text" : "California",
        "indices" : [ 84, 95 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "443511860676276225",
    "text" : "Here is a gorgeous photo America's newest National Monument: Point Arena-Stornetta. #California http:\/\/t.co\/v7qsh20O8a",
    "id" : 443511860676276225,
    "created_at" : "2014-03-11 22:20:42 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 443513866409213953,
  "created_at" : "2014-03-11 22:28:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/443501171198529536\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/GLjPO27X0F",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bieh9x0CIAA_eLw.jpg",
      "id_str" : "443501171034955776",
      "id" : 443501171034955776,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bieh9x0CIAA_eLw.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/GLjPO27X0F"
    } ],
    "hashtags" : [ {
      "text" : "GetCoveredNow",
      "indices" : [ 0, 14 ]
    }, {
      "text" : "20DaysLeft",
      "indices" : [ 103, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/iWit9TRhKm",
      "expanded_url" : "http:\/\/hc.gov\/uZBSgi",
      "display_url" : "hc.gov\/uZBSgi"
    } ]
  },
  "geo" : { },
  "id_str" : "443501171198529536",
  "text" : "#GetCoveredNow because no one deserves to go broke just because they get sick \u2192 http:\/\/t.co\/iWit9TRhKm #20DaysLeft, http:\/\/t.co\/GLjPO27X0F",
  "id" : 443501171198529536,
  "created_at" : "2014-03-11 21:38:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "indices" : [ 3, 14 ],
      "id_str" : "816653",
      "id" : 816653
    }, {
      "name" : "Vacation Alex",
      "screen_name" : "alex",
      "indices" : [ 111, 116 ],
      "id_str" : "7380362",
      "id" : 7380362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/RX68swKbo1",
      "expanded_url" : "http:\/\/tcrn.ch\/1dMTO6d",
      "display_url" : "tcrn.ch\/1dMTO6d"
    } ]
  },
  "geo" : { },
  "id_str" : "443493661960306688",
  "text" : "RT @TechCrunch: Zach Galifianakis Is Now The Top Driver Of Traffic To HealthCare\u2024gov http:\/\/t.co\/RX68swKbo1 by @alex",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/10up.com\" rel=\"nofollow\"\u003E10up Publish Tweet\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vacation Alex",
        "screen_name" : "alex",
        "indices" : [ 95, 100 ],
        "id_str" : "7380362",
        "id" : 7380362
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/RX68swKbo1",
        "expanded_url" : "http:\/\/tcrn.ch\/1dMTO6d",
        "display_url" : "tcrn.ch\/1dMTO6d"
      } ]
    },
    "geo" : { },
    "id_str" : "443442374555889664",
    "text" : "Zach Galifianakis Is Now The Top Driver Of Traffic To HealthCare\u2024gov http:\/\/t.co\/RX68swKbo1 by @alex",
    "id" : 443442374555889664,
    "created_at" : "2014-03-11 17:44:35 +0000",
    "user" : {
      "name" : "TechCrunch",
      "screen_name" : "TechCrunch",
      "protected" : false,
      "id_str" : "816653",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615392662233808896\/EtxjSSKk_normal.jpg",
      "id" : 816653,
      "verified" : true
    }
  },
  "id" : 443493661960306688,
  "created_at" : "2014-03-11 21:08:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/443477819192909824\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/pZUxI9Soyo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BieMugxCYAAkWyG.jpg",
      "id_str" : "443477819016765440",
      "id" : 443477819016765440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BieMugxCYAAkWyG.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/pZUxI9Soyo"
    } ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 107, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443477819192909824",
  "text" : "Share the news: Through February, more than 4.2 million Americans have signed up for private health plans. #ACA http:\/\/t.co\/pZUxI9Soyo",
  "id" : 443477819192909824,
  "created_at" : "2014-03-11 20:05:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "zach galifianakis",
      "screen_name" : "galifianakisz",
      "indices" : [ 4, 18 ],
      "id_str" : "36686415",
      "id" : 36686415
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCoveredNow",
      "indices" : [ 56, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/5zeR2RQuXe",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "443465506541301761",
  "text" : "Hey @galifianakisz, thanks for sending so many folks to #GetCoveredNow at http:\/\/t.co\/5zeR2RQuXe. And good luck with those spider bites. -bo",
  "id" : 443465506541301761,
  "created_at" : "2014-03-11 19:16:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rep. Jared Huffman",
      "screen_name" : "RepHuffman",
      "indices" : [ 3, 14 ],
      "id_str" : "1071102246",
      "id" : 1071102246
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443462175450222592",
  "text" : "RT @RepHuffman: Pres. Obama honoring Teddy Roosevelt's legacy by using Antiquities Act to protect this coastal jewel on Mendo Coast #PointA\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PointArena",
        "indices" : [ 116, 127 ]
      }, {
        "text" : "Stornetta",
        "indices" : [ 128, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "443410824334688256",
    "text" : "Pres. Obama honoring Teddy Roosevelt's legacy by using Antiquities Act to protect this coastal jewel on Mendo Coast #PointArena #Stornetta",
    "id" : 443410824334688256,
    "created_at" : "2014-03-11 15:39:13 +0000",
    "user" : {
      "name" : "Rep. Jared Huffman",
      "screen_name" : "RepHuffman",
      "protected" : false,
      "id_str" : "1071102246",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/651435990100279296\/5lQBk2Ut_normal.png",
      "id" : 1071102246,
      "verified" : true
    }
  },
  "id" : 443462175450222592,
  "created_at" : "2014-03-11 19:03:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCoveredNow",
      "indices" : [ 73, 87 ]
    }, {
      "text" : "20DaysLeft",
      "indices" : [ 113, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/FRKvzHFaq1",
      "expanded_url" : "http:\/\/hc.gov\/uZBSgi",
      "display_url" : "hc.gov\/uZBSgi"
    } ]
  },
  "geo" : { },
  "id_str" : "443444717020520448",
  "text" : "DON'T WAIT: If you or someone you know needs affordable health coverage, #GetCoveredNow \u2192 http:\/\/t.co\/FRKvzHFaq1 #20DaysLeft",
  "id" : 443444717020520448,
  "created_at" : "2014-03-11 17:53:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCoveredNow",
      "indices" : [ 0, 14 ]
    }, {
      "text" : "20DaysLeft",
      "indices" : [ 123, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/FRKvzHFaq1",
      "expanded_url" : "http:\/\/hc.gov\/uZBSgi",
      "display_url" : "hc.gov\/uZBSgi"
    } ]
  },
  "geo" : { },
  "id_str" : "443432535415357441",
  "text" : "#GetCoveredNow because preventive care like cancer screenings will cost you nothing out of pocket \u2192 http:\/\/t.co\/FRKvzHFaq1 #20DaysLeft",
  "id" : 443432535415357441,
  "created_at" : "2014-03-11 17:05:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041A\u0430\u0442\u0435\u043D\u0430 \u041D\u0438\u043A\u043E\u043D\u0435\u043D\u043A\u043E",
      "screen_name" : "HealthCareTara",
      "indices" : [ 3, 18 ],
      "id_str" : "9448842",
      "id" : 9448842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/FrO24hdvcA",
      "expanded_url" : "http:\/\/FunnyorDie.com",
      "display_url" : "FunnyorDie.com"
    }, {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/0r93BavlrV",
      "expanded_url" : "http:\/\/HealthCare.gov",
      "display_url" : "HealthCare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "443423299025264640",
  "text" : "RT @HealthCareTara: http:\/\/t.co\/FrO24hdvcA is the #1 source of referrals to http:\/\/t.co\/0r93BavlrV right now.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/FrO24hdvcA",
        "expanded_url" : "http:\/\/FunnyorDie.com",
        "display_url" : "FunnyorDie.com"
      }, {
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/0r93BavlrV",
        "expanded_url" : "http:\/\/HealthCare.gov",
        "display_url" : "HealthCare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "443421401903820800",
    "text" : "http:\/\/t.co\/FrO24hdvcA is the #1 source of referrals to http:\/\/t.co\/0r93BavlrV right now.",
    "id" : 443421401903820800,
    "created_at" : "2014-03-11 16:21:15 +0000",
    "user" : {
      "name" : "Tara McGuinness",
      "screen_name" : "Tara44",
      "protected" : false,
      "id_str" : "1601549102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600334679951081472\/O9XyKAXl_normal.jpg",
      "id" : 1601549102,
      "verified" : true
    }
  },
  "id" : 443423299025264640,
  "created_at" : "2014-03-11 16:28:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/443420859936419840\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/xf9Jvo6J48",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BidY7DFCIAAgsiY.jpg",
      "id_str" : "443420859781226496",
      "id" : 443420859781226496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BidY7DFCIAAgsiY.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/xf9Jvo6J48"
    } ],
    "hashtags" : [ {
      "text" : "20DaysLeft",
      "indices" : [ 0, 11 ]
    }, {
      "text" : "GetCoveredNow",
      "indices" : [ 93, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/iWit9TRhKm",
      "expanded_url" : "http:\/\/hc.gov\/uZBSgi",
      "display_url" : "hc.gov\/uZBSgi"
    } ]
  },
  "geo" : { },
  "id_str" : "443420859936419840",
  "text" : "#20DaysLeft to sign up for affordable health insurance.\nDon't wait! \u2192 http:\/\/t.co\/iWit9TRhKm\n#GetCoveredNow, http:\/\/t.co\/xf9Jvo6J48",
  "id" : 443420859936419840,
  "created_at" : "2014-03-11 16:19:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Funny Or Die",
      "screen_name" : "funnyordie",
      "indices" : [ 3, 14 ],
      "id_str" : "15693493",
      "id" : 15693493
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443414973554118656",
  "text" : "RT @funnyordie: President Barack Obama sits Between Two Ferns with Zach Galifianakis for his most memorable interview yet: http:\/\/t.co\/6K2t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/6K2t1y7oFg",
        "expanded_url" : "http:\/\/ow.ly\/utjxX",
        "display_url" : "ow.ly\/utjxX"
      } ]
    },
    "geo" : { },
    "id_str" : "443412753207025664",
    "text" : "President Barack Obama sits Between Two Ferns with Zach Galifianakis for his most memorable interview yet: http:\/\/t.co\/6K2t1y7oFg",
    "id" : 443412753207025664,
    "created_at" : "2014-03-11 15:46:53 +0000",
    "user" : {
      "name" : "Funny Or Die",
      "screen_name" : "funnyordie",
      "protected" : false,
      "id_str" : "15693493",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796062959185182720\/FN6QGp0H_normal.jpg",
      "id" : 15693493,
      "verified" : true
    }
  },
  "id" : 443414973554118656,
  "created_at" : "2014-03-11 15:55:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "20DaysLeft",
      "indices" : [ 10, 21 ]
    }, {
      "text" : "GetCoveredNow",
      "indices" : [ 100, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/TdcPPVxLIC",
      "expanded_url" : "http:\/\/go.wh.gov\/Gn3ewV",
      "display_url" : "go.wh.gov\/Gn3ewV"
    } ]
  },
  "geo" : { },
  "id_str" : "443410720571813888",
  "text" : "With just #20DaysLeft to sign up for affordable health coverage, here are 20 reasons why you should #GetCoveredNow \u2192 http:\/\/t.co\/TdcPPVxLIC",
  "id" : 443410720571813888,
  "created_at" : "2014-03-11 15:38:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "publiclands",
      "indices" : [ 70, 82 ]
    }, {
      "text" : "PointArena",
      "indices" : [ 109, 120 ]
    }, {
      "text" : "Stornetta",
      "indices" : [ 121, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443408188281745408",
  "text" : "RT @Podesta44: Keeping SOTU pledge, POTUS will protect 1,665 acres of #publiclands for future generations at #PointArena #Stornetta http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Podesta44\/status\/443387529778061314\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/Rp2pl9W4eZ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bic6m-0CYAAzPaQ.jpg",
        "id_str" : "443387529689980928",
        "id" : 443387529689980928,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bic6m-0CYAAzPaQ.jpg",
        "sizes" : [ {
          "h" : 529,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 317,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 180,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 529,
          "resize" : "fit",
          "w" : 1000
        } ],
        "display_url" : "pic.twitter.com\/Rp2pl9W4eZ"
      } ],
      "hashtags" : [ {
        "text" : "publiclands",
        "indices" : [ 55, 67 ]
      }, {
        "text" : "PointArena",
        "indices" : [ 94, 105 ]
      }, {
        "text" : "Stornetta",
        "indices" : [ 106, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "443387529778061314",
    "text" : "Keeping SOTU pledge, POTUS will protect 1,665 acres of #publiclands for future generations at #PointArena #Stornetta http:\/\/t.co\/Rp2pl9W4eZ",
    "id" : 443387529778061314,
    "created_at" : "2014-03-11 14:06:39 +0000",
    "user" : {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "protected" : false,
      "id_str" : "2382117350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656551411145027584\/ArrSlGUP_normal.jpg",
      "id" : 2382117350,
      "verified" : true
    }
  },
  "id" : 443408188281745408,
  "created_at" : "2014-03-11 15:28:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BetweenTwoFerns",
      "indices" : [ 108, 124 ]
    }, {
      "text" : "GetCoveredNow",
      "indices" : [ 125, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/3rqPCmOjF9",
      "expanded_url" : "http:\/\/FunnyOrDie.com\/m\/8omu",
      "display_url" : "FunnyOrDie.com\/m\/8omu"
    } ]
  },
  "geo" : { },
  "id_str" : "443395282756456450",
  "text" : "\u2022 President Obama\n\u2022 Zach Galifianakis\n\u2022 Spider bites\nAll things you can find here \u2192  http:\/\/t.co\/3rqPCmOjF9 #BetweenTwoFerns #GetCoveredNow",
  "id" : 443395282756456450,
  "created_at" : "2014-03-11 14:37:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "20DaysLeft",
      "indices" : [ 5, 16 ]
    }, {
      "text" : "GetCoveredNow",
      "indices" : [ 126, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/5zeR2RQuXe",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    }, {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/3rqPCmOjF9",
      "expanded_url" : "http:\/\/FunnyOrDie.com\/m\/8omu",
      "display_url" : "FunnyOrDie.com\/m\/8omu"
    } ]
  },
  "geo" : { },
  "id_str" : "443382311678390272",
  "text" : "Just #20DaysLeft to sign up for health coverage: http:\/\/t.co\/5zeR2RQuXe\n\nNeed inspiration? Watch this: http:\/\/t.co\/3rqPCmOjF9 #GetCoveredNow",
  "id" : 443382311678390272,
  "created_at" : "2014-03-11 13:45:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Up4Climate",
      "indices" : [ 129, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/yllOGisuqd",
      "expanded_url" : "http:\/\/go.wh.gov\/Dkds4u",
      "display_url" : "go.wh.gov\/Dkds4u"
    } ]
  },
  "geo" : { },
  "id_str" : "443219972416753664",
  "text" : "Sea level rise exacerbated by climate change increases the frequency &amp; severity of coastal flooding \u2192 http:\/\/t.co\/yllOGisuqd #Up4Climate",
  "id" : 443219972416753664,
  "created_at" : "2014-03-11 03:00:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 93, 106 ]
    }, {
      "text" : "Up4Climate",
      "indices" : [ 107, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/yllOGisuqd",
      "expanded_url" : "http:\/\/go.wh.gov\/Dkds4u",
      "display_url" : "go.wh.gov\/Dkds4u"
    } ]
  },
  "geo" : { },
  "id_str" : "443204870862934016",
  "text" : "FACT: Every 4 minutes, another American home or business goes solar \u2192 http:\/\/t.co\/yllOGisuqd #ActOnClimate #Up4Climate",
  "id" : 443204870862934016,
  "created_at" : "2014-03-11 02:00:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Up4Climate",
      "indices" : [ 128, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443189774715604992",
  "text" : "FACT: Thanks to President Obama, our cars will be twice as efficient by 2025\u2014saving the average driver more than $8,000 on gas. #Up4Climate",
  "id" : 443189774715604992,
  "created_at" : "2014-03-11 01:00:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/443173379822989313\/photo\/1",
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/wCJHkCMtXV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BiZ31zvCAAEiGxh.jpg",
      "id_str" : "443173379646816257",
      "id" : 443173379646816257,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BiZ31zvCAAEiGxh.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/wCJHkCMtXV"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 87, 100 ]
    }, {
      "text" : "Up4Climate",
      "indices" : [ 109, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443173379822989313",
  "text" : "RT if you agree: For the sake of our kids &amp; the future of our planet, it's time to #ActOnClimate change. #Up4Climate http:\/\/t.co\/wCJHkCMtXV",
  "id" : 443173379822989313,
  "created_at" : "2014-03-10 23:55:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kirsten Gillibrand",
      "screen_name" : "SenGillibrand",
      "indices" : [ 3, 17 ],
      "id_str" : "72198806",
      "id" : 72198806
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443165437011169280",
  "text" : "RT @SenGillibrand: We don't have to wait for evidence of climate change. It's all around us: rising seas, disappearing coastlines, longer d\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Up4Climate",
        "indices" : [ 129, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "443163887320702976",
    "text" : "We don't have to wait for evidence of climate change. It's all around us: rising seas, disappearing coastlines, longer droughts. #Up4Climate",
    "id" : 443163887320702976,
    "created_at" : "2014-03-10 23:17:58 +0000",
    "user" : {
      "name" : "Kirsten Gillibrand",
      "screen_name" : "SenGillibrand",
      "protected" : false,
      "id_str" : "72198806",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/748266569323659264\/Kv9U6DgK_normal.jpg",
      "id" : 72198806,
      "verified" : true
    }
  },
  "id" : 443165437011169280,
  "created_at" : "2014-03-10 23:24:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/443158788510474240\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/4NK5Npa78l",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BiZqke_CYAAHzaY.jpg",
      "id_str" : "443158788367867904",
      "id" : 443158788367867904,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BiZqke_CYAAHzaY.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/4NK5Npa78l"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 48, 61 ]
    }, {
      "text" : "Up4Climate",
      "indices" : [ 94, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/yllOGisuqd",
      "expanded_url" : "http:\/\/go.wh.gov\/Dkds4u",
      "display_url" : "go.wh.gov\/Dkds4u"
    } ]
  },
  "geo" : { },
  "id_str" : "443158788510474240",
  "text" : "Worth sharing: Here's President Obama's plan to #ActOnClimate change \u2192 http:\/\/t.co\/yllOGisuqd #Up4Climate http:\/\/t.co\/4NK5Npa78l",
  "id" : 443158788510474240,
  "created_at" : "2014-03-10 22:57:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/443152739879505921\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/4W1OzvoULp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BiZlEaACcAABPjV.jpg",
      "id_str" : "443152739715936256",
      "id" : 443152739715936256,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BiZlEaACcAABPjV.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/4W1OzvoULp"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 70, 83 ]
    }, {
      "text" : "Up4Climate",
      "indices" : [ 92, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443152739879505921",
  "text" : "We've seen 12 of the hottest years on record since 1998. It's time to #ActOnClimate change. #Up4Climate, http:\/\/t.co\/4W1OzvoULp",
  "id" : 443152739879505921,
  "created_at" : "2014-03-10 22:33:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Senator Patty Murray",
      "screen_name" : "PattyMurray",
      "indices" : [ 3, 15 ],
      "id_str" : "293131808",
      "id" : 293131808
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Up4Climate",
      "indices" : [ 43, 54 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443144191812829184",
  "text" : "RT @PattyMurray: Sen. Murray will join her #Up4Climate colleagues at approx. 6:15PM ET to urge action on climate change. WATCH LIVE: http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Up4Climate",
        "indices" : [ 26, 37 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/q327bF91pd",
        "expanded_url" : "http:\/\/www.c-span.org\/live\/?channel=c-span-2",
        "display_url" : "c-span.org\/live\/?channel=\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "443104769289515008",
    "text" : "Sen. Murray will join her #Up4Climate colleagues at approx. 6:15PM ET to urge action on climate change. WATCH LIVE: http:\/\/t.co\/q327bF91pd",
    "id" : 443104769289515008,
    "created_at" : "2014-03-10 19:23:04 +0000",
    "user" : {
      "name" : "Senator Patty Murray",
      "screen_name" : "PattyMurray",
      "protected" : false,
      "id_str" : "293131808",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430384292917555200\/ULj2LMsW_normal.jpeg",
      "id" : 293131808,
      "verified" : true
    }
  },
  "id" : 443144191812829184,
  "created_at" : "2014-03-10 21:59:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BanBossy",
      "indices" : [ 117, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443139497015115776",
  "text" : "RT @FLOTUS: \u201CEvery time you stretch your mind, you boost your confidence.\u201D \u2014The First Lady encouraging girls to lead #BanBossy http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/443131243656257536\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/mHOhf4VVWz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BiZRhKaCAAAtHxo.jpg",
        "id_str" : "443131243513643008",
        "id" : 443131243513643008,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BiZRhKaCAAAtHxo.jpg",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/mHOhf4VVWz"
      } ],
      "hashtags" : [ {
        "text" : "BanBossy",
        "indices" : [ 105, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "443131243656257536",
    "text" : "\u201CEvery time you stretch your mind, you boost your confidence.\u201D \u2014The First Lady encouraging girls to lead #BanBossy http:\/\/t.co\/mHOhf4VVWz",
    "id" : 443131243656257536,
    "created_at" : "2014-03-10 21:08:16 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 443139497015115776,
  "created_at" : "2014-03-10 21:41:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Heinrich",
      "screen_name" : "MartinHeinrich",
      "indices" : [ 3, 18 ],
      "id_str" : "1099199839",
      "id" : 1099199839
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Up4Climate",
      "indices" : [ 41, 52 ]
    }, {
      "text" : "climatechange",
      "indices" : [ 78, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443129465972215808",
  "text" : "RT @MartinHeinrich: Tonight, I will stay #Up4Climate &amp; call for action on #climatechange. RT If you believe it's time to act. http:\/\/t.co\/s\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Up4Climate",
        "indices" : [ 21, 32 ]
      }, {
        "text" : "climatechange",
        "indices" : [ 58, 72 ]
      } ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/swMQGVBal7",
        "expanded_url" : "http:\/\/www.huffingtonpost.com\/2014\/03\/07\/senate-climate-speeches_n_4921663.html",
        "display_url" : "huffingtonpost.com\/2014\/03\/07\/sen\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "443038674130042882",
    "text" : "Tonight, I will stay #Up4Climate &amp; call for action on #climatechange. RT If you believe it's time to act. http:\/\/t.co\/swMQGVBal7",
    "id" : 443038674130042882,
    "created_at" : "2014-03-10 15:00:25 +0000",
    "user" : {
      "name" : "Martin Heinrich",
      "screen_name" : "MartinHeinrich",
      "protected" : false,
      "id_str" : "1099199839",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/472115942248308737\/BjSCAw32_normal.jpeg",
      "id" : 1099199839,
      "verified" : true
    }
  },
  "id" : 443129465972215808,
  "created_at" : "2014-03-10 21:01:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Up4Climate",
      "indices" : [ 106, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443127766054350848",
  "text" : "RT @Podesta44: Climate deniers have closed their eyes (and minds) to what\u2019s happening to our planet. Stay #Up4Climate all night tonight wit\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Senate Democrats",
        "screen_name" : "SenateDems",
        "indices" : [ 126, 137 ],
        "id_str" : "73238146",
        "id" : 73238146
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Up4Climate",
        "indices" : [ 91, 102 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "443110244751667200",
    "text" : "Climate deniers have closed their eyes (and minds) to what\u2019s happening to our planet. Stay #Up4Climate all night tonight with @SenateDems",
    "id" : 443110244751667200,
    "created_at" : "2014-03-10 19:44:49 +0000",
    "user" : {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "protected" : false,
      "id_str" : "2382117350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656551411145027584\/ArrSlGUP_normal.jpg",
      "id" : 2382117350,
      "verified" : true
    }
  },
  "id" : 443127766054350848,
  "created_at" : "2014-03-10 20:54:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Senate Democrats",
      "screen_name" : "SenateDems",
      "indices" : [ 3, 14 ],
      "id_str" : "73238146",
      "id" : 73238146
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Up4Climate",
      "indices" : [ 83, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/CZCkdoUBMm",
      "expanded_url" : "http:\/\/www.nytimes.com\/2014\/03\/11\/us\/politics\/26-democrats-plan-a-senate-all-nighter-on-climate-change.html?partner=bloomberg&_r=0",
      "display_url" : "nytimes.com\/2014\/03\/11\/us\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "443123230921216000",
  "text" : "RT @SenateDems: TONIGHT: 26 Democrats Plan a Senate All-Nighter on Climate Change. #Up4Climate http:\/\/t.co\/CZCkdoUBMm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Up4Climate",
        "indices" : [ 67, 78 ]
      } ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/CZCkdoUBMm",
        "expanded_url" : "http:\/\/www.nytimes.com\/2014\/03\/11\/us\/politics\/26-democrats-plan-a-senate-all-nighter-on-climate-change.html?partner=bloomberg&_r=0",
        "display_url" : "nytimes.com\/2014\/03\/11\/us\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "443103342815117313",
    "text" : "TONIGHT: 26 Democrats Plan a Senate All-Nighter on Climate Change. #Up4Climate http:\/\/t.co\/CZCkdoUBMm",
    "id" : 443103342815117313,
    "created_at" : "2014-03-10 19:17:24 +0000",
    "user" : {
      "name" : "Senate Democrats",
      "screen_name" : "SenateDems",
      "protected" : false,
      "id_str" : "73238146",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1214915758\/Reid_and_Dem_Senate_leadership_normal.jpg",
      "id" : 73238146,
      "verified" : true
    }
  },
  "id" : 443123230921216000,
  "created_at" : "2014-03-10 20:36:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "post2015",
      "indices" : [ 128, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443100277080866816",
  "text" : "RT @Podesta44: Hello, Twitter! Excited to be joining you from my post as Counselor to POTUS. Stay tuned for all things climate, #post2015, \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "post2015",
        "indices" : [ 113, 122 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "443099652058263553",
    "text" : "Hello, Twitter! Excited to be joining you from my post as Counselor to POTUS. Stay tuned for all things climate, #post2015, big data &amp; more.",
    "id" : 443099652058263553,
    "created_at" : "2014-03-10 19:02:44 +0000",
    "user" : {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "protected" : false,
      "id_str" : "2382117350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656551411145027584\/ArrSlGUP_normal.jpg",
      "id" : 2382117350,
      "verified" : true
    }
  },
  "id" : 443100277080866816,
  "created_at" : "2014-03-10 19:05:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/443096926250991617\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/XsOaMq8p5M",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BiYyTn9CQAE6njd.jpg",
      "id_str" : "443096926066458625",
      "id" : 443096926066458625,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BiYyTn9CQAE6njd.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 833,
        "resize" : "fit",
        "w" : 1667
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/XsOaMq8p5M"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443096926250991617",
  "text" : "President Obama's budget cuts taxes to help families:\n\u2022 Afford child care\n\u2022 Pay for college\n\u2022 Save for retirement\n\u2192 http:\/\/t.co\/XsOaMq8p5M",
  "id" : 443096926250991617,
  "created_at" : "2014-03-10 18:51:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/443080597393522688\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/k2u2zI9VFi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BiYjdKXCEAAGSA3.jpg",
      "id_str" : "443080597246709760",
      "id" : 443080597246709760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BiYjdKXCEAAGSA3.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/k2u2zI9VFi"
    } ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 92, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443080597393522688",
  "text" : "President Obama's budget:\n1. Continues to \u2704 the deficit\n2. Begins to \u2193 our debt after 2015.\n#OpportunityForAll http:\/\/t.co\/k2u2zI9VFi",
  "id" : 443080597393522688,
  "created_at" : "2014-03-10 17:47:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 70, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/Rzi3Aw4wI8",
      "expanded_url" : "http:\/\/go.wh.gov\/MLpvo9",
      "display_url" : "go.wh.gov\/MLpvo9"
    } ]
  },
  "geo" : { },
  "id_str" : "443060965714972672",
  "text" : "Here's how President Obama's budget would grow our economy and expand #OpportunityForAll hardworking Americans \u2192 http:\/\/t.co\/Rzi3Aw4wI8",
  "id" : 443060965714972672,
  "created_at" : "2014-03-10 16:29:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Furman",
      "screen_name" : "CEAChair",
      "indices" : [ 3, 12 ],
      "id_str" : "1861751828",
      "id" : 1861751828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/PJ02E0wYQw",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2014\/03\/10\/2014-economic-report-president",
      "display_url" : "whitehouse.gov\/blog\/2014\/03\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "443057016211525632",
  "text" : "RT @CEAChair: U.S. is 1 of 2 countries where output per working-age person is back to pre-crisis levels http:\/\/t.co\/PJ02E0wYQw http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CEAChair\/status\/443031650889240576\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/8HsChANjDv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BiX28HACEAA8pCl.jpg",
        "id_str" : "443031650897629184",
        "id" : 443031650897629184,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BiX28HACEAA8pCl.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 307,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 363,
          "resize" : "fit",
          "w" : 402
        }, {
          "h" : 363,
          "resize" : "fit",
          "w" : 402
        }, {
          "h" : 363,
          "resize" : "fit",
          "w" : 402
        } ],
        "display_url" : "pic.twitter.com\/8HsChANjDv"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/PJ02E0wYQw",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2014\/03\/10\/2014-economic-report-president",
        "display_url" : "whitehouse.gov\/blog\/2014\/03\/1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "443031650889240576",
    "text" : "U.S. is 1 of 2 countries where output per working-age person is back to pre-crisis levels http:\/\/t.co\/PJ02E0wYQw http:\/\/t.co\/8HsChANjDv",
    "id" : 443031650889240576,
    "created_at" : "2014-03-10 14:32:31 +0000",
    "user" : {
      "name" : "Jason Furman",
      "screen_name" : "CEAChair",
      "protected" : false,
      "id_str" : "1861751828",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000628384447\/c9cb85dbdb73c8bac4f28ce4cc46f38b_normal.jpeg",
      "id" : 1861751828,
      "verified" : true
    }
  },
  "id" : 443057016211525632,
  "created_at" : "2014-03-10 16:13:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 104, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/SzinLjEpfm",
      "expanded_url" : "http:\/\/bit.ly\/1h6I9y2",
      "display_url" : "bit.ly\/1h6I9y2"
    }, {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/5zeR2RQuXe",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "443045790949593088",
  "text" : "FACT: The U.S. uninsured rate continues to drop: http:\/\/t.co\/SzinLjEpfm\n\nRT to help even more Americans #GetCovered \u2192 http:\/\/t.co\/5zeR2RQuXe",
  "id" : 443045790949593088,
  "created_at" : "2014-03-10 15:28:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Stein",
      "screen_name" : "samsteinhp",
      "indices" : [ 3, 14 ],
      "id_str" : "15463671",
      "id" : 15463671
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/samsteinhp\/status\/443035083751301121\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/TNVjCmKXug",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BiX6D61IEAAdCfw.png",
      "id_str" : "443035083604496384",
      "id" : 443035083604496384,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BiX6D61IEAAdCfw.png",
      "sizes" : [ {
        "h" : 321,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 321,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 273,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 321,
        "resize" : "fit",
        "w" : 400
      } ],
      "display_url" : "pic.twitter.com\/TNVjCmKXug"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "443040501403758593",
  "text" : "RT @samsteinhp: Our recovery from the recession went better than anyone's, other than perhaps Germany, per WH http:\/\/t.co\/TNVjCmKXug",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/samsteinhp\/status\/443035083751301121\/photo\/1",
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/TNVjCmKXug",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BiX6D61IEAAdCfw.png",
        "id_str" : "443035083604496384",
        "id" : 443035083604496384,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BiX6D61IEAAdCfw.png",
        "sizes" : [ {
          "h" : 321,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 321,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 273,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 321,
          "resize" : "fit",
          "w" : 400
        } ],
        "display_url" : "pic.twitter.com\/TNVjCmKXug"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "443035083751301121",
    "text" : "Our recovery from the recession went better than anyone's, other than perhaps Germany, per WH http:\/\/t.co\/TNVjCmKXug",
    "id" : 443035083751301121,
    "created_at" : "2014-03-10 14:46:09 +0000",
    "user" : {
      "name" : "Sam Stein",
      "screen_name" : "samsteinhp",
      "protected" : false,
      "id_str" : "15463671",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750786172327198720\/HJsxpBoQ_normal.jpg",
      "id" : 15463671,
      "verified" : true
    }
  },
  "id" : 443040501403758593,
  "created_at" : "2014-03-10 15:07:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 109, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/nHxLOjXgIl",
      "expanded_url" : "http:\/\/go.wh.gov\/oaES1z",
      "display_url" : "go.wh.gov\/oaES1z"
    } ]
  },
  "geo" : { },
  "id_str" : "443036983263494144",
  "text" : "Go inside the numbers on why America is poised for stronger economic growth in 2014 \u2192 http:\/\/t.co\/nHxLOjXgIl #OpportunityForAll",
  "id" : 443036983263494144,
  "created_at" : "2014-03-10 14:53:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Cosmos",
      "indices" : [ 61, 68 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/fGyAIkxrRk",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=3Gg07hpof5o",
      "display_url" : "youtube.com\/watch?v=3Gg07h\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "443028264203067392",
  "text" : "RT @whitehouseostp: Here's President Obama's introduction to #Cosmos http:\/\/t.co\/fGyAIkxrRk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Cosmos",
        "indices" : [ 41, 48 ]
      } ],
      "urls" : [ {
        "indices" : [ 49, 71 ],
        "url" : "http:\/\/t.co\/fGyAIkxrRk",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=3Gg07hpof5o",
        "display_url" : "youtube.com\/watch?v=3Gg07h\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "442830503348293632",
    "text" : "Here's President Obama's introduction to #Cosmos http:\/\/t.co\/fGyAIkxrRk",
    "id" : 442830503348293632,
    "created_at" : "2014-03-10 01:13:14 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 443028264203067392,
  "created_at" : "2014-03-10 14:19:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "P. Jacobs",
      "screen_name" : "ScienceGuy",
      "indices" : [ 63, 74 ],
      "id_str" : "13400322",
      "id" : 13400322
    }, {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "indices" : [ 75, 85 ],
      "id_str" : "19725644",
      "id" : 19725644
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/442825064010883072\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/zBVmwdune3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BiU7DKcCMAAi0N3.jpg",
      "id_str" : "442825063893446656",
      "id" : 442825063893446656,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BiU7DKcCMAAi0N3.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/zBVmwdune3"
    } ],
    "hashtags" : [ {
      "text" : "WestWingWeek",
      "indices" : [ 6, 19 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/yzFJ12BvH0",
      "expanded_url" : "http:\/\/go.wh.gov\/e3k75c",
      "display_url" : "go.wh.gov\/e3k75c"
    } ]
  },
  "geo" : { },
  "id_str" : "442825064010883072",
  "text" : "Watch #WestWingWeek for a behind-the-scenes peek at this POTUS @ScienceGuy @neiltyson selfie \u2192 http:\/\/t.co\/yzFJ12BvH0 http:\/\/t.co\/zBVmwdune3",
  "id" : 442825064010883072,
  "created_at" : "2014-03-10 00:51:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 120, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/hhw63MUQ41",
      "expanded_url" : "http:\/\/go.wh.gov\/WMZEMQ",
      "display_url" : "go.wh.gov\/WMZEMQ"
    } ]
  },
  "geo" : { },
  "id_str" : "442804223005057024",
  "text" : "\"What business leaders and everyday Americans are doing to raise wages is so important.\" \u2014Obama: http:\/\/t.co\/hhw63MUQ41 #RaiseTheWage",
  "id" : 442804223005057024,
  "created_at" : "2014-03-09 23:28:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 43, 50 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WestWingWeek",
      "indices" : [ 0, 13 ]
    }, {
      "text" : "WHFilmFest",
      "indices" : [ 30, 41 ]
    }, {
      "text" : "IWOC",
      "indices" : [ 62, 67 ]
    }, {
      "text" : "OpportunityforAll",
      "indices" : [ 100, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/sHkZBWOiSX",
      "expanded_url" : "http:\/\/go.wh.gov\/qcCrJS",
      "display_url" : "go.wh.gov\/qcCrJS"
    } ]
  },
  "geo" : { },
  "id_str" : "442770491258830850",
  "text" : "#WestWingWeek: The first-ever #WHFilmFest, @FLOTUS celebrates #IWOC &amp; POTUS speaks on restoring #OpportunityforAll \u2192 http:\/\/t.co\/sHkZBWOiSX",
  "id" : 442770491258830850,
  "created_at" : "2014-03-09 21:14:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 107, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/At8KYWjQU9",
      "expanded_url" : "http:\/\/go.wh.gov\/aEZ51Q",
      "display_url" : "go.wh.gov\/aEZ51Q"
    } ]
  },
  "geo" : { },
  "id_str" : "442698273451552768",
  "text" : "\"A clear majority of Americans support raising the minimum wage.\" \u2014President Obama: http:\/\/t.co\/At8KYWjQU9 #RaiseTheWage",
  "id" : 442698273451552768,
  "created_at" : "2014-03-09 16:27:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/xBqPFT8zDw",
      "expanded_url" : "http:\/\/go.wh.gov\/CJWMEB",
      "display_url" : "go.wh.gov\/CJWMEB"
    } ]
  },
  "geo" : { },
  "id_str" : "442657504514678785",
  "text" : "President Obama's Weekly Address: Time for Congress to raise the minimum wage for the American people \u2192 http:\/\/t.co\/xBqPFT8zDw #RaiseTheWage",
  "id" : 442657504514678785,
  "created_at" : "2014-03-09 13:45:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TimeFor1010",
      "indices" : [ 6, 18 ]
    }, {
      "text" : "RaiseTheWage",
      "indices" : [ 119, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/GWN14PzkrK",
      "expanded_url" : "http:\/\/go.wh.gov\/37AgFD",
      "display_url" : "go.wh.gov\/37AgFD"
    } ]
  },
  "geo" : { },
  "id_str" : "442402066472787968",
  "text" : "\"It\u2019s #TimeFor1010. It\u2019s time to give America a raise.\" \u2014President Obama in his Weekly Address: http:\/\/t.co\/GWN14PzkrK #RaiseTheWage",
  "id" : 442402066472787968,
  "created_at" : "2014-03-08 20:50:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/sHWCKPYWPP",
      "expanded_url" : "http:\/\/go.wh.gov\/6rejZA",
      "display_url" : "go.wh.gov\/6rejZA"
    } ]
  },
  "geo" : { },
  "id_str" : "442365575679844352",
  "text" : "Obama: \"Half of all Republicans support raising the minimum wage...it\u2019s just too bad they don\u2019t serve in Congress.\" http:\/\/t.co\/sHWCKPYWPP",
  "id" : 442365575679844352,
  "created_at" : "2014-03-08 18:25:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 98, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/dPJCeFzkDt",
      "expanded_url" : "http:\/\/go.wh.gov\/y7Hc1G",
      "display_url" : "go.wh.gov\/y7Hc1G"
    } ]
  },
  "geo" : { },
  "id_str" : "442317760693936129",
  "text" : "\"Nobody who works full-time should have to live in poverty.\" \u2014President Obama on why it's time to #RaiseTheWage: http:\/\/t.co\/dPJCeFzkDt",
  "id" : 442317760693936129,
  "created_at" : "2014-03-08 15:15:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/442098387274313728\/photo\/1",
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/aw7DM6hTbv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BiKmJAUCYAAbuHt.jpg",
      "id_str" : "442098387068805120",
      "id" : 442098387068805120,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BiKmJAUCYAAbuHt.jpg",
      "sizes" : [ {
        "h" : 669,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 222,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 392,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 948,
        "resize" : "fit",
        "w" : 1451
      } ],
      "display_url" : "pic.twitter.com\/aw7DM6hTbv"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "442098387274313728",
  "text" : "\"If you are responsible &amp; put in the effort, you can succeed. There\u2019s no limit to what you can do.\" \u2014President Obama http:\/\/t.co\/aw7DM6hTbv",
  "id" : 442098387274313728,
  "created_at" : "2014-03-08 00:44:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WomensDay",
      "indices" : [ 122, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "442079018444394497",
  "text" : "RT @FLOTUS: \"Now is the time to tap into the deep well of...compassion &amp; strength that we all have as women.\" \u2014FLOTUS #WomensDay http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/FLOTUS\/status\/442078173803462657\/photo\/1",
        "indices" : [ 121, 143 ],
        "url" : "http:\/\/t.co\/87oam1wVzB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BiKTwbRCMAALnEB.jpg",
        "id_str" : "442078173597937664",
        "id" : 442078173597937664,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BiKTwbRCMAALnEB.jpg",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/87oam1wVzB"
      } ],
      "hashtags" : [ {
        "text" : "WomensDay",
        "indices" : [ 110, 120 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "442078173803462657",
    "text" : "\"Now is the time to tap into the deep well of...compassion &amp; strength that we all have as women.\" \u2014FLOTUS #WomensDay http:\/\/t.co\/87oam1wVzB",
    "id" : 442078173803462657,
    "created_at" : "2014-03-07 23:23:44 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 442079018444394497,
  "created_at" : "2014-03-07 23:27:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Todd Park",
      "screen_name" : "todd_park",
      "indices" : [ 3, 13 ],
      "id_str" : "200176600",
      "id" : 200176600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/TAB0ME9m2W",
      "expanded_url" : "http:\/\/wh.gov\/lyYNR",
      "display_url" : "wh.gov\/lyYNR"
    }, {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/V8o9nASS6o",
      "expanded_url" : "http:\/\/pif.gsa.gov",
      "display_url" : "pif.gsa.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "442057092602806272",
  "text" : "RT @todd_park: Excited to announce Presidential Innovation Fellows Round 3 http:\/\/t.co\/TAB0ME9m2W! Apply now http:\/\/t.co\/V8o9nASS6o #innova\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "innovategov",
        "indices" : [ 117, 129 ]
      }, {
        "text" : "opendata",
        "indices" : [ 130, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/TAB0ME9m2W",
        "expanded_url" : "http:\/\/wh.gov\/lyYNR",
        "display_url" : "wh.gov\/lyYNR"
      }, {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/V8o9nASS6o",
        "expanded_url" : "http:\/\/pif.gsa.gov",
        "display_url" : "pif.gsa.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "442056103774674944",
    "text" : "Excited to announce Presidential Innovation Fellows Round 3 http:\/\/t.co\/TAB0ME9m2W! Apply now http:\/\/t.co\/V8o9nASS6o #innovategov #opendata",
    "id" : 442056103774674944,
    "created_at" : "2014-03-07 21:56:02 +0000",
    "user" : {
      "name" : "Todd Park",
      "screen_name" : "todd_park",
      "protected" : false,
      "id_str" : "200176600",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1140157375\/toddpark_normal.jpg",
      "id" : 200176600,
      "verified" : false
    }
  },
  "id" : 442057092602806272,
  "created_at" : "2014-03-07 21:59:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Erin",
      "screen_name" : "Erin44",
      "indices" : [ 3, 10 ],
      "id_str" : "41044637",
      "id" : 41044637
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 75, 86 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/Y8gFl4cQvC",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/EasterEggRoll",
      "display_url" : "whitehouse.gov\/EasterEggRoll"
    } ]
  },
  "geo" : { },
  "id_str" : "442049227758514176",
  "text" : "RT @Erin44: \u201CHop into Healthy, Swing into Shape!\u201D Apply to attend the 2014 @WhiteHouse Easter Egg Roll \u2192 http:\/\/t.co\/Y8gFl4cQvC http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 63, 74 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Erin44\/status\/441980728260050944\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/9Fascd5ypG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BiI7IXHCQAAezFe.jpg",
        "id_str" : "441980728264245248",
        "id" : 441980728264245248,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BiI7IXHCQAAezFe.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/9Fascd5ypG"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/Y8gFl4cQvC",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/EasterEggRoll",
        "display_url" : "whitehouse.gov\/EasterEggRoll"
      } ]
    },
    "geo" : { },
    "id_str" : "441980728260050944",
    "text" : "\u201CHop into Healthy, Swing into Shape!\u201D Apply to attend the 2014 @WhiteHouse Easter Egg Roll \u2192 http:\/\/t.co\/Y8gFl4cQvC http:\/\/t.co\/9Fascd5ypG",
    "id" : 441980728260050944,
    "created_at" : "2014-03-07 16:56:31 +0000",
    "user" : {
      "name" : "Alex Wall",
      "screen_name" : "Alex44",
      "protected" : false,
      "id_str" : "2169098419",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/632215085256081409\/_vjZ92WM_normal.jpg",
      "id" : 2169098419,
      "verified" : true
    }
  },
  "id" : 442049227758514176,
  "created_at" : "2014-03-07 21:28:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Federal Student Aid",
      "screen_name" : "FAFSA",
      "indices" : [ 77, 83 ],
      "id_str" : "188001904",
      "id" : 188001904
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/442043534971912193\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/RisFcusXRi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BiJ0QL1CMAEYqvO.jpg",
      "id_str" : "442043534837690369",
      "id" : 442043534837690369,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BiJ0QL1CMAEYqvO.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/RisFcusXRi"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/DnSO3G9I7U",
      "expanded_url" : "http:\/\/go.wh.gov\/MuvoL7",
      "display_url" : "go.wh.gov\/MuvoL7"
    } ]
  },
  "geo" : { },
  "id_str" : "442043534971912193",
  "text" : "Don't leave money on the table: Maximize your student aid by filling out the @FAFSA \u2192 http:\/\/t.co\/DnSO3G9I7U http:\/\/t.co\/RisFcusXRi",
  "id" : 442043534971912193,
  "created_at" : "2014-03-07 21:06:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "442037711890034690",
  "text" : "RT @VP: RT if you agree: All Americans deserve to afford and graduate college w\/ the skills that today's workforce demand. #CollegeOpportun\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CollegeOpportunity",
        "indices" : [ 115, 134 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "442035552804929536",
    "text" : "RT if you agree: All Americans deserve to afford and graduate college w\/ the skills that today's workforce demand. #CollegeOpportunity",
    "id" : 442035552804929536,
    "created_at" : "2014-03-07 20:34:23 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 442037711890034690,
  "created_at" : "2014-03-07 20:42:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Federal Student Aid",
      "screen_name" : "FAFSA",
      "indices" : [ 13, 19 ],
      "id_str" : "188001904",
      "id" : 188001904
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 119, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/gS4pHD0N5U",
      "expanded_url" : "http:\/\/go.wh.gov\/MuvoL7",
      "display_url" : "go.wh.gov\/MuvoL7"
    } ]
  },
  "geo" : { },
  "id_str" : "442032325954928640",
  "text" : "Obama on the @FAFSA: \"My challenge to every high school student in America: Fill out the form.\" http:\/\/t.co\/gS4pHD0N5U #CollegeOpportunity",
  "id" : 442032325954928640,
  "created_at" : "2014-03-07 20:21:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "442032003882704896",
  "text" : "\"No striving, hard-working young American should ever be denied a college education just because they can\u2019t afford it.\" \u2014President Obama",
  "id" : 442032003882704896,
  "created_at" : "2014-03-07 20:20:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PreKForAll",
      "indices" : [ 116, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "442031031009697792",
  "text" : "RT @WHLive: \"We\u2019re trying to help more states make high-quality preschool...available to the youngest kids.\" \u2014Obama #PreKForAll http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WHLive\/status\/442030786057744384\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/p8mVqiu78o",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BiJoqGWCAAASmbH.jpg",
        "id_str" : "442030785902542848",
        "id" : 442030785902542848,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BiJoqGWCAAASmbH.jpg",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/p8mVqiu78o"
      } ],
      "hashtags" : [ {
        "text" : "PreKForAll",
        "indices" : [ 104, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "442030786057744384",
    "text" : "\"We\u2019re trying to help more states make high-quality preschool...available to the youngest kids.\" \u2014Obama #PreKForAll http:\/\/t.co\/p8mVqiu78o",
    "id" : 442030786057744384,
    "created_at" : "2014-03-07 20:15:26 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 442031031009697792,
  "created_at" : "2014-03-07 20:16:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 121, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "442030410726653953",
  "text" : "\"If you are responsible and put in the effort, you can succeed...there is no limit to what you can do.\" \u2014President Obama #OpportunityForAll",
  "id" : 442030410726653953,
  "created_at" : "2014-03-07 20:13:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "442029666988482560",
  "text" : "\"We didn\u2019t have a lot of money, but she was determined to see that my sister and I would get the best education we could.\" \u2014Obama on his mom",
  "id" : 442029666988482560,
  "created_at" : "2014-03-07 20:10:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 125, 144 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "442029568149708800",
  "text" : "\"Michelle &amp; I are only here today because of the education we received. That was our ticket to success\" \u2014President Obama #CollegeOpportunity",
  "id" : 442029568149708800,
  "created_at" : "2014-03-07 20:10:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 120, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "442029409198157824",
  "text" : "\"By working hard every single day, every single night\u2014you\u2019re making the best investment there is in your future\" \u2014Obama #CollegeOpportunity",
  "id" : 442029409198157824,
  "created_at" : "2014-03-07 20:09:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 56, 75 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/rmaTeI1jHr",
      "expanded_url" : "http:\/\/go.wh.gov\/W5AhAP",
      "display_url" : "go.wh.gov\/W5AhAP"
    } ]
  },
  "geo" : { },
  "id_str" : "442021572812234752",
  "text" : "Don't miss President Obama speak on new steps to expand #CollegeOpportunity for more Americans at 2:40pm ET \u2192 http:\/\/t.co\/rmaTeI1jHr",
  "id" : 442021572812234752,
  "created_at" : "2014-03-07 19:38:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ConnectED",
      "indices" : [ 122, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/3YP0gdkwl1",
      "expanded_url" : "http:\/\/go.wh.gov\/Mccnm9",
      "display_url" : "go.wh.gov\/Mccnm9"
    } ]
  },
  "geo" : { },
  "id_str" : "442017167014629376",
  "text" : "FACT: Obama's budget calls for helping teachers integrate digital learning into their classrooms \u2192 http:\/\/t.co\/3YP0gdkwl1 #ConnectED",
  "id" : 442017167014629376,
  "created_at" : "2014-03-07 19:21:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Federal Student Aid",
      "screen_name" : "FAFSA",
      "indices" : [ 80, 86 ],
      "id_str" : "188001904",
      "id" : 188001904
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/442006979645808640\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/mjLvF2WF9Y",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BiJTAYlIAAE9Gx3.jpg",
      "id_str" : "442006979498999809",
      "id" : 442006979498999809,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BiJTAYlIAAE9Gx3.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/mjLvF2WF9Y"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/gS4pHD0N5U",
      "expanded_url" : "http:\/\/go.wh.gov\/MuvoL7",
      "display_url" : "go.wh.gov\/MuvoL7"
    } ]
  },
  "geo" : { },
  "id_str" : "442006979645808640",
  "text" : "Hey students: Take the first step toward success in college by filling out your @FAFSA \u2192 http:\/\/t.co\/gS4pHD0N5U http:\/\/t.co\/mjLvF2WF9Y",
  "id" : 442006979645808640,
  "created_at" : "2014-03-07 18:40:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 115, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/ud6xr15Fzm",
      "expanded_url" : "http:\/\/go.wh.gov\/Fuzfth",
      "display_url" : "go.wh.gov\/Fuzfth"
    } ]
  },
  "geo" : { },
  "id_str" : "441993254100533248",
  "text" : "President Obama's launching a new initiative to help more Americans graduate from college \u2192 http:\/\/t.co\/ud6xr15Fzm #CollegeOpportunity",
  "id" : 441993254100533248,
  "created_at" : "2014-03-07 17:46:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 3, 11 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    }, {
      "name" : "Jon Lujan",
      "screen_name" : "JonnyVolcano44",
      "indices" : [ 34, 49 ],
      "id_str" : "400986711",
      "id" : 400986711
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TeamUSA",
      "indices" : [ 67, 75 ]
    }, {
      "text" : "Sochi2014",
      "indices" : [ 85, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441991349165117440",
  "text" : "RT @DrBiden: Marine Corps veteran @JonnyVolcano44 is about to lead #TeamUSA into the #Sochi2014 Paralympic Games! Good luck to all of our a\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jon Lujan",
        "screen_name" : "JonnyVolcano44",
        "indices" : [ 21, 36 ],
        "id_str" : "400986711",
        "id" : 400986711
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TeamUSA",
        "indices" : [ 54, 62 ]
      }, {
        "text" : "Sochi2014",
        "indices" : [ 72, 82 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "441964741477797888",
    "text" : "Marine Corps veteran @JonnyVolcano44 is about to lead #TeamUSA into the #Sochi2014 Paralympic Games! Good luck to all of our athletes!",
    "id" : 441964741477797888,
    "created_at" : "2014-03-07 15:53:00 +0000",
    "user" : {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "protected" : false,
      "id_str" : "1281405877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608687663034474496\/wvzVG_yt_normal.jpg",
      "id" : 1281405877,
      "verified" : true
    }
  },
  "id" : 441991349165117440,
  "created_at" : "2014-03-07 17:38:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WebMD",
      "screen_name" : "WebMD",
      "indices" : [ 3, 9 ],
      "id_str" : "25928253",
      "id" : 25928253
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 125, 136 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 19, 23 ]
    }, {
      "text" : "WebMDAsksObama",
      "indices" : [ 54, 69 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/MJAAbuWouZ",
      "expanded_url" : "http:\/\/wb.md\/1dTaZ2z",
      "display_url" : "wb.md\/1dTaZ2z"
    } ]
  },
  "geo" : { },
  "id_str" : "441985081234964480",
  "text" : "RT @WebMD: Have an #ACA question for President Obama? #WebMDAsksObama for you. Submit questions here: http:\/\/t.co\/MJAAbuWouZ @WhiteHouse",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 114, 125 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ACA",
        "indices" : [ 8, 12 ]
      }, {
        "text" : "WebMDAsksObama",
        "indices" : [ 43, 58 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/MJAAbuWouZ",
        "expanded_url" : "http:\/\/wb.md\/1dTaZ2z",
        "display_url" : "wb.md\/1dTaZ2z"
      } ]
    },
    "geo" : { },
    "id_str" : "441977869284442112",
    "text" : "Have an #ACA question for President Obama? #WebMDAsksObama for you. Submit questions here: http:\/\/t.co\/MJAAbuWouZ @WhiteHouse",
    "id" : 441977869284442112,
    "created_at" : "2014-03-07 16:45:10 +0000",
    "user" : {
      "name" : "WebMD",
      "screen_name" : "WebMD",
      "protected" : false,
      "id_str" : "25928253",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771386734760386562\/-cRW6ixT_normal.jpg",
      "id" : 25928253,
      "verified" : true
    }
  },
  "id" : 441985081234964480,
  "created_at" : "2014-03-07 17:13:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WebMD",
      "screen_name" : "WebMD",
      "indices" : [ 90, 96 ],
      "id_str" : "25928253",
      "id" : 25928253
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 35, 39 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/t59EuLxFJd",
      "expanded_url" : "http:\/\/WebMD.com\/AskObama",
      "display_url" : "WebMD.com\/AskObama"
    } ]
  },
  "geo" : { },
  "id_str" : "441976692505325568",
  "text" : "RT @Lubin44: Have questions on the #ACA? Get them in for President Obama's interview with @WebMD next week \u2192 http:\/\/t.co\/t59EuLxFJd #WebMDA\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "WebMD",
        "screen_name" : "WebMD",
        "indices" : [ 77, 83 ],
        "id_str" : "25928253",
        "id" : 25928253
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ACA",
        "indices" : [ 22, 26 ]
      }, {
        "text" : "WebMDAsksObama",
        "indices" : [ 119, 134 ]
      } ],
      "urls" : [ {
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/t59EuLxFJd",
        "expanded_url" : "http:\/\/WebMD.com\/AskObama",
        "display_url" : "WebMD.com\/AskObama"
      } ]
    },
    "geo" : { },
    "id_str" : "441974317673635840",
    "text" : "Have questions on the #ACA? Get them in for President Obama's interview with @WebMD next week \u2192 http:\/\/t.co\/t59EuLxFJd #WebMDAsksObama",
    "id" : 441974317673635840,
    "created_at" : "2014-03-07 16:31:03 +0000",
    "user" : {
      "name" : "Lindsay Holst",
      "screen_name" : "Holst44",
      "protected" : false,
      "id_str" : "1563426390",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615987325261082625\/QxtC65p2_normal.jpg",
      "id" : 1563426390,
      "verified" : true
    }
  },
  "id" : 441976692505325568,
  "created_at" : "2014-03-07 16:40:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WebMD",
      "screen_name" : "WebMD",
      "indices" : [ 76, 82 ],
      "id_str" : "25928253",
      "id" : 25928253
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/441971304288104448\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/8oqJUZDDb1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BiIyjzRCUAEQlSP.jpg",
      "id_str" : "441971304074203137",
      "id" : 441971304074203137,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BiIyjzRCUAEQlSP.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/8oqJUZDDb1"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/t0bxtPnqJW",
      "expanded_url" : "http:\/\/go.wh.gov\/ojNbfY",
      "display_url" : "go.wh.gov\/ojNbfY"
    } ]
  },
  "geo" : { },
  "id_str" : "441971304288104448",
  "text" : "Don't miss your chance to ask President Obama your health care questions on @WebMD next week: http:\/\/t.co\/t0bxtPnqJW http:\/\/t.co\/8oqJUZDDb1",
  "id" : 441971304288104448,
  "created_at" : "2014-03-07 16:19:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/441963483626614784\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/jJ3tMi62Lg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BiIrclVCAAAWuKP.jpg",
      "id_str" : "441963483492384768",
      "id" : 441963483492384768,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BiIrclVCAAAWuKP.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/jJ3tMi62Lg"
    } ],
    "hashtags" : [ {
      "text" : "ActOnJobs",
      "indices" : [ 104, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/Nt7R6jfHeS",
      "expanded_url" : "http:\/\/go.wh.gov\/WpN4nU",
      "display_url" : "go.wh.gov\/WpN4nU"
    } ]
  },
  "geo" : { },
  "id_str" : "441963483626614784",
  "text" : "FACT: Our businesses added 162,000 jobs in February\u2014but there's more work to do: http:\/\/t.co\/Nt7R6jfHeS #ActOnJobs, http:\/\/t.co\/jJ3tMi62Lg",
  "id" : 441963483626614784,
  "created_at" : "2014-03-07 15:48:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/441953817504931840\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/BmmrWp0aam",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BiIip76CEAAtPlS.jpg",
      "id_str" : "441953817286807552",
      "id" : 441953817286807552,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BiIip76CEAAtPlS.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/BmmrWp0aam"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441953817504931840",
  "text" : "Our businesses have added:\n\u2022 8.7 million jobs over 4 years\n\u2022 2.2 million in the past year\n\u2022 162,000 in February\n\u2192 http:\/\/t.co\/BmmrWp0aam",
  "id" : 441953817504931840,
  "created_at" : "2014-03-07 15:09:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 126, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/7qRkvGKIik",
      "expanded_url" : "http:\/\/go.wh.gov\/pHw8vV",
      "display_url" : "go.wh.gov\/pHw8vV"
    } ]
  },
  "geo" : { },
  "id_str" : "441735162196291586",
  "text" : "Whether you need health coverage or have it already, here's how the Affordable Care Act benefits you \u2192 http:\/\/t.co\/7qRkvGKIik #GetCovered",
  "id" : 441735162196291586,
  "created_at" : "2014-03-07 00:40:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ukraine",
      "indices" : [ 96, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/GUlyjfKquf",
      "expanded_url" : "http:\/\/go.wh.gov\/e8JJJQ",
      "display_url" : "go.wh.gov\/e8JJJQ"
    } ]
  },
  "geo" : { },
  "id_str" : "441722685970591744",
  "text" : "Here's the readout of President Obama's call with President Putin of Russia on the situation in #Ukraine \u2192 http:\/\/t.co\/GUlyjfKquf",
  "id" : 441722685970591744,
  "created_at" : "2014-03-06 23:51:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyler Oakley",
      "screen_name" : "tyleroakley",
      "indices" : [ 99, 111 ],
      "id_str" : "14222536",
      "id" : 14222536
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/3YmBRgXc05",
      "expanded_url" : "http:\/\/go.wh.gov\/a1bepb",
      "display_url" : "go.wh.gov\/a1bepb"
    } ]
  },
  "geo" : { },
  "id_str" : "441703636453036032",
  "text" : "\"My friend and I, we talked about how he doesn't have insurance\u2026all you have to do is go online.\" \u2014@TylerOakley: http:\/\/t.co\/3YmBRgXc05",
  "id" : 441703636453036032,
  "created_at" : "2014-03-06 22:35:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyler Oakley",
      "screen_name" : "tyleroakley",
      "indices" : [ 9, 21 ],
      "id_str" : "14222536",
      "id" : 14222536
    }, {
      "name" : "Hannah Hart",
      "screen_name" : "harto",
      "indices" : [ 23, 29 ],
      "id_str" : "14166096",
      "id" : 14166096
    }, {
      "name" : "Iman Crosson",
      "screen_name" : "Alphacat",
      "indices" : [ 31, 40 ],
      "id_str" : "16533079",
      "id" : 16533079
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 115, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/3YmBRgXc05",
      "expanded_url" : "http:\/\/go.wh.gov\/a1bepb",
      "display_url" : "go.wh.gov\/a1bepb"
    } ]
  },
  "geo" : { },
  "id_str" : "441689577020223488",
  "text" : "In which @TylerOakley, @Harto, @Alphacat and others talk health care with President Obama \u2192 http:\/\/t.co\/3YmBRgXc05 #GetCovered",
  "id" : 441689577020223488,
  "created_at" : "2014-03-06 21:39:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ukraine",
      "indices" : [ 63, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/soaXWy8W5z",
      "expanded_url" : "http:\/\/go.wh.gov\/bfv42v",
      "display_url" : "go.wh.gov\/bfv42v"
    } ]
  },
  "geo" : { },
  "id_str" : "441673683892187136",
  "text" : "Watch President Obama discuss efforts to address the crisis in #Ukraine \u2192 http:\/\/t.co\/soaXWy8W5z",
  "id" : 441673683892187136,
  "created_at" : "2014-03-06 20:36:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/441657558936207360\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/VS6EJv0kKZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BiEVNbDCUAACiJ4.jpg",
      "id_str" : "441657558801993728",
      "id" : 441657558801993728,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BiEVNbDCUAACiJ4.jpg",
      "sizes" : [ {
        "h" : 301,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 409,
        "resize" : "fit",
        "w" : 816
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 409,
        "resize" : "fit",
        "w" : 816
      } ],
      "display_url" : "pic.twitter.com\/VS6EJv0kKZ"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 105, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441657558936207360",
  "text" : "FACT: Preventive care is now covered at no extra cost for 4.9 million Latinas with private health plans. #GetCovered http:\/\/t.co\/VS6EJv0kKZ",
  "id" : 441657558936207360,
  "created_at" : "2014-03-06 19:32:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/441644760285986816\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/BpjK2ILL8C",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BiEJkcYCYAEqpqv.jpg",
      "id_str" : "441644760155971585",
      "id" : 441644760155971585,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BiEJkcYCYAEqpqv.jpg",
      "sizes" : [ {
        "h" : 409,
        "resize" : "fit",
        "w" : 816
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 409,
        "resize" : "fit",
        "w" : 816
      }, {
        "h" : 301,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/BpjK2ILL8C"
    } ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 25, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441644760285986816",
  "text" : "Good news: Thanks to the #ACA, 11.8 million Latinos no longer have lifetime limits on their health coverage. http:\/\/t.co\/BpjK2ILL8C",
  "id" : 441644760285986816,
  "created_at" : "2014-03-06 18:41:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ukraine",
      "indices" : [ 131, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441636924722532352",
  "text" : "President Obama: \"The world can see that the United States is united with our allies and partners in upholding international law.\" #Ukraine",
  "id" : 441636924722532352,
  "created_at" : "2014-03-06 18:10:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ukraine",
      "indices" : [ 128, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441635955070742528",
  "text" : "\"We have been mobilizing the international community to condemn this violation of international law\" \u2014Obama on the situation in #Ukraine",
  "id" : 441635955070742528,
  "created_at" : "2014-03-06 18:06:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ukraine",
      "indices" : [ 75, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/Hqt6gmnOMv",
      "expanded_url" : "http:\/\/go.wh.gov\/habXne",
      "display_url" : "go.wh.gov\/habXne"
    } ]
  },
  "geo" : { },
  "id_str" : "441633734715248640",
  "text" : "At 1:05pm ET, President Obama will deliver a statement on the situation in #Ukraine. Watch \u2192 http:\/\/t.co\/Hqt6gmnOMv",
  "id" : 441633734715248640,
  "created_at" : "2014-03-06 17:57:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Asegurate",
      "indices" : [ 111, 121 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 122, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/FEepCRHE6o",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "441622042195263488",
  "text" : "RT @WHLive: \u201CYou still have a month to sign up, and it doesn\u2019t take that long.\u201D \u2014Obama: http:\/\/t.co\/FEepCRHE6o #Asegurate #GetCovered #TuSa\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Asegurate",
        "indices" : [ 99, 109 ]
      }, {
        "text" : "GetCovered",
        "indices" : [ 110, 121 ]
      }, {
        "text" : "TuSaludyObama",
        "indices" : [ 122, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/FEepCRHE6o",
        "expanded_url" : "http:\/\/Healthcare.gov",
        "display_url" : "Healthcare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "441621146078031872",
    "text" : "\u201CYou still have a month to sign up, and it doesn\u2019t take that long.\u201D \u2014Obama: http:\/\/t.co\/FEepCRHE6o #Asegurate #GetCovered #TuSaludyObama",
    "id" : 441621146078031872,
    "created_at" : "2014-03-06 17:07:40 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 441622042195263488,
  "created_at" : "2014-03-06 17:11:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Asegurate",
      "indices" : [ 99, 109 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 110, 121 ]
    }, {
      "text" : "TuSaludyObama",
      "indices" : [ 122, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/FEepCRHE6o",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "441620455385202689",
  "text" : "RT @WHLive: \u201CWe have seen over 4 million people sign up.\u201D \u2014President Obama: http:\/\/t.co\/FEepCRHE6o #Asegurate #GetCovered #TuSaludyObama",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Asegurate",
        "indices" : [ 87, 97 ]
      }, {
        "text" : "GetCovered",
        "indices" : [ 98, 109 ]
      }, {
        "text" : "TuSaludyObama",
        "indices" : [ 110, 124 ]
      } ],
      "urls" : [ {
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/FEepCRHE6o",
        "expanded_url" : "http:\/\/Healthcare.gov",
        "display_url" : "Healthcare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "441620385873027072",
    "text" : "\u201CWe have seen over 4 million people sign up.\u201D \u2014President Obama: http:\/\/t.co\/FEepCRHE6o #Asegurate #GetCovered #TuSaludyObama",
    "id" : 441620385873027072,
    "created_at" : "2014-03-06 17:04:39 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 441620455385202689,
  "created_at" : "2014-03-06 17:04:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TuSaludyObama",
      "indices" : [ 120, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/5zeR2RQuXe",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "441618506300526592",
  "text" : "Obama: \u201CA large portion of people will be able to find health insurance for $100\/month or less.\u201D http:\/\/t.co\/5zeR2RQuXe #TuSaludyObama",
  "id" : 441618506300526592,
  "created_at" : "2014-03-06 16:57:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Asegurate",
      "indices" : [ 111, 121 ]
    }, {
      "text" : "TuSaludyObama",
      "indices" : [ 122, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/xq99LcgPJX",
      "expanded_url" : "http:\/\/wh.gov\/LatinoTownHall",
      "display_url" : "wh.gov\/LatinoTownHall"
    } ]
  },
  "geo" : { },
  "id_str" : "441614937111425024",
  "text" : "Starting now: Watch President Obama's townhall on Latinos and the Affordable Care Act \u2192 http:\/\/t.co\/xq99LcgPJX #Asegurate #TuSaludyObama",
  "id" : 441614937111425024,
  "created_at" : "2014-03-06 16:43:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Asegurate",
      "indices" : [ 130, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/xq99LcgPJX",
      "expanded_url" : "http:\/\/wh.gov\/LatinoTownHall",
      "display_url" : "wh.gov\/LatinoTownHall"
    } ]
  },
  "geo" : { },
  "id_str" : "441610271208271872",
  "text" : "Don't miss President Obama's townhall on how the Affordable Care Act is benefiting Latinos at 11:30am ET \u2192 http:\/\/t.co\/xq99LcgPJX #Asegurate",
  "id" : 441610271208271872,
  "created_at" : "2014-03-06 16:24:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/441604675872124928\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/sbkm49pV7H",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BiDlHOFCQAAqv7o.jpg",
      "id_str" : "441604675683368960",
      "id" : 441604675683368960,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BiDlHOFCQAAqv7o.jpg",
      "sizes" : [ {
        "h" : 409,
        "resize" : "fit",
        "w" : 816
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 409,
        "resize" : "fit",
        "w" : 816
      }, {
        "h" : 301,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/sbkm49pV7H"
    } ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 32, 36 ]
    }, {
      "text" : "GetCovered",
      "indices" : [ 105, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441604675872124928",
  "text" : "Spread the word: Here's how the #ACA is helping millions of Americans who already have health insurance. #GetCovered http:\/\/t.co\/sbkm49pV7H",
  "id" : 441604675872124928,
  "created_at" : "2014-03-06 16:02:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "indices" : [ 3, 16 ],
      "id_str" : "78138151",
      "id" : 78138151
    }, {
      "name" : "Univision",
      "screen_name" : "Univision",
      "indices" : [ 59, 69 ],
      "id_str" : "40924038",
      "id" : 40924038
    }, {
      "name" : "Noticias Telemundo",
      "screen_name" : "TelemundoNews",
      "indices" : [ 71, 85 ],
      "id_str" : "152142811",
      "id" : 152142811
    }, {
      "name" : "La Opini\u00F3n",
      "screen_name" : "LaOpinionLA",
      "indices" : [ 86, 98 ],
      "id_str" : "41416662",
      "id" : 41416662
    }, {
      "name" : "California Endowment",
      "screen_name" : "CalEndow",
      "indices" : [ 100, 109 ],
      "id_str" : "132254256",
      "id" : 132254256
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441589675393048576",
  "text" : "RT @lacasablanca: Tune in: Townhall with the President and @Univision, @TelemundoNews @LaOpinionLA, @CalEndow today at 11:30am ET: http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Univision",
        "screen_name" : "Univision",
        "indices" : [ 41, 51 ],
        "id_str" : "40924038",
        "id" : 40924038
      }, {
        "name" : "Noticias Telemundo",
        "screen_name" : "TelemundoNews",
        "indices" : [ 53, 67 ],
        "id_str" : "152142811",
        "id" : 152142811
      }, {
        "name" : "La Opini\u00F3n",
        "screen_name" : "LaOpinionLA",
        "indices" : [ 68, 80 ],
        "id_str" : "41416662",
        "id" : 41416662
      }, {
        "name" : "California Endowment",
        "screen_name" : "CalEndow",
        "indices" : [ 82, 91 ],
        "id_str" : "132254256",
        "id" : 132254256
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/QGVSyoIo7v",
        "expanded_url" : "http:\/\/WhiteHouse.gov\/LatinoTownHall",
        "display_url" : "WhiteHouse.gov\/LatinoTownHall"
      } ]
    },
    "geo" : { },
    "id_str" : "441576850369024000",
    "text" : "Tune in: Townhall with the President and @Univision, @TelemundoNews @LaOpinionLA, @CalEndow today at 11:30am ET: http:\/\/t.co\/QGVSyoIo7v",
    "id" : 441576850369024000,
    "created_at" : "2014-03-06 14:11:39 +0000",
    "user" : {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "protected" : false,
      "id_str" : "78138151",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616360382911754241\/4Tfqcfie_normal.png",
      "id" : 78138151,
      "verified" : true
    }
  },
  "id" : 441589675393048576,
  "created_at" : "2014-03-06 15:02:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/pN5RHJTXtV",
      "expanded_url" : "http:\/\/go.wh.gov\/vvd2vT",
      "display_url" : "go.wh.gov\/vvd2vT"
    } ]
  },
  "geo" : { },
  "id_str" : "441392901474373633",
  "text" : "\"Michelle and I join our fellow Christians in the United States &amp; around the world in marking Ash Wednesday.\" \u2014Obama: http:\/\/t.co\/pN5RHJTXtV",
  "id" : 441392901474373633,
  "created_at" : "2014-03-06 02:00:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 95, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/d4ORXJOjUE",
      "expanded_url" : "http:\/\/go.wh.gov\/6AKobs",
      "display_url" : "go.wh.gov\/6AKobs"
    } ]
  },
  "geo" : { },
  "id_str" : "441379636824797184",
  "text" : "\"This is not about politics. This is about common sense.\" \u2014President Obama on why it's time to #RaiseTheWage: http:\/\/t.co\/d4ORXJOjUE",
  "id" : 441379636824797184,
  "created_at" : "2014-03-06 01:08:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 33, 44 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441376000073814016",
  "text" : "RT @VP: Important funding in the @WhiteHouse budget invests in efforts to clear the country\u2019s backlog of unanalyzed rape kits http:\/\/t.co\/G\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 25, 36 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/GuEU8pGbv3",
        "expanded_url" : "http:\/\/hosted.ap.org\/dynamic\/stories\/U\/US_SEXUAL_ASSAULT_VICTIMS?SITE=AP&SECTION=HOME&TEMPLATE=DEFAULT",
        "display_url" : "hosted.ap.org\/dynamic\/storie\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "441371707077849088",
    "text" : "Important funding in the @WhiteHouse budget invests in efforts to clear the country\u2019s backlog of unanalyzed rape kits http:\/\/t.co\/GuEU8pGbv3",
    "id" : 441371707077849088,
    "created_at" : "2014-03-06 00:36:29 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 441376000073814016,
  "created_at" : "2014-03-06 00:53:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/441368589090557952\/photo\/1",
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/xRVgP4oNgP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BiAOZKOCcAAhRoj.jpg",
      "id_str" : "441368588885061632",
      "id" : 441368588885061632,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BiAOZKOCcAAhRoj.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 733
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 733
      } ],
      "display_url" : "pic.twitter.com\/xRVgP4oNgP"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 12, 23 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/I3bqMOVMzN",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "441369998461005825",
  "text" : "RT @FLOTUS: #GetCovered because moms know kids aren't invincible \u2192 http:\/\/t.co\/I3bqMOVMzN, http:\/\/t.co\/xRVgP4oNgP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/441368589090557952\/photo\/1",
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/xRVgP4oNgP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BiAOZKOCcAAhRoj.jpg",
        "id_str" : "441368588885061632",
        "id" : 441368588885061632,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BiAOZKOCcAAhRoj.jpg",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 733,
          "resize" : "fit",
          "w" : 733
        }, {
          "h" : 733,
          "resize" : "fit",
          "w" : 733
        } ],
        "display_url" : "pic.twitter.com\/xRVgP4oNgP"
      } ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 0, 11 ]
      } ],
      "urls" : [ {
        "indices" : [ 55, 77 ],
        "url" : "http:\/\/t.co\/I3bqMOVMzN",
        "expanded_url" : "http:\/\/Healthcare.gov",
        "display_url" : "Healthcare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "441368589090557952",
    "text" : "#GetCovered because moms know kids aren't invincible \u2192 http:\/\/t.co\/I3bqMOVMzN, http:\/\/t.co\/xRVgP4oNgP",
    "id" : 441368589090557952,
    "created_at" : "2014-03-06 00:24:06 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 441369998461005825,
  "created_at" : "2014-03-06 00:29:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 121, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/ZLi6oQSj50",
      "expanded_url" : "http:\/\/go.wh.gov\/R8ZeZL",
      "display_url" : "go.wh.gov\/R8ZeZL"
    } ]
  },
  "geo" : { },
  "id_str" : "441359000022827008",
  "text" : "Add your name if you agree it's time to raise the minimum wage\u2014then RT so your friends can, too \u2192 http:\/\/t.co\/ZLi6oQSj50 #RaiseTheWage",
  "id" : 441359000022827008,
  "created_at" : "2014-03-05 23:46:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "indices" : [ 61, 68 ],
      "id_str" : "166252256",
      "id" : 166252256
    }, {
      "name" : "PPPL",
      "screen_name" : "PPPLab",
      "indices" : [ 75, 82 ],
      "id_str" : "96213352",
      "id" : 96213352
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 108, 121 ]
    }, {
      "text" : "SpaceWeek",
      "indices" : [ 122, 132 ]
    }, {
      "text" : "Fusion",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/x9RpKESsqO",
      "expanded_url" : "http:\/\/go.usa.gov\/KYVC",
      "display_url" : "go.usa.gov\/KYVC"
    } ]
  },
  "geo" : { },
  "id_str" : "441332501412188166",
  "text" : "Want to learn how to create a star on Earth? Watch this from @Energy &amp; @PPPLab \u2192 http:\/\/t.co\/x9RpKESsqO #ActOnClimate #SpaceWeek #Fusion",
  "id" : 441332501412188166,
  "created_at" : "2014-03-05 22:00:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 92, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/I3bqMOVMzN",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "441320982155128832",
  "text" : "RT @FLOTUS: Jessie Trice Community Health Center in FL is doing great work to help families #GetCovered: http:\/\/t.co\/I3bqMOVMzN http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/FLOTUS\/status\/441320487113601024\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/xe2FIkNYMx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bh_ipQpCcAAXwNZ.jpg",
        "id_str" : "441320486975205376",
        "id" : 441320486975205376,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bh_ipQpCcAAXwNZ.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/xe2FIkNYMx"
      } ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 80, 91 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/I3bqMOVMzN",
        "expanded_url" : "http:\/\/Healthcare.gov",
        "display_url" : "Healthcare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "441320487113601024",
    "text" : "Jessie Trice Community Health Center in FL is doing great work to help families #GetCovered: http:\/\/t.co\/I3bqMOVMzN http:\/\/t.co\/xe2FIkNYMx",
    "id" : 441320487113601024,
    "created_at" : "2014-03-05 21:12:58 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 441320982155128832,
  "created_at" : "2014-03-05 21:14:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Schultz",
      "screen_name" : "Schultz44",
      "indices" : [ 3, 13 ],
      "id_str" : "1603419038",
      "id" : 1603419038
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441317067707654144",
  "text" : "RT @Schultz44: Obama: The Senate's \"failure to confirm Debo Adegbile...is a travesty based on wildly unfair character attacks.\" http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/DcUdswtXaa",
        "expanded_url" : "http:\/\/wh.gov\/lmo9T",
        "display_url" : "wh.gov\/lmo9T"
      } ]
    },
    "geo" : { },
    "id_str" : "441311552184922113",
    "text" : "Obama: The Senate's \"failure to confirm Debo Adegbile...is a travesty based on wildly unfair character attacks.\" http:\/\/t.co\/DcUdswtXaa",
    "id" : 441311552184922113,
    "created_at" : "2014-03-05 20:37:27 +0000",
    "user" : {
      "name" : "Eric Schultz",
      "screen_name" : "Schultz44",
      "protected" : false,
      "id_str" : "1603419038",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/491941155815161856\/u0IdexM6_normal.jpeg",
      "id" : 1603419038,
      "verified" : true
    }
  },
  "id" : 441317067707654144,
  "created_at" : "2014-03-05 20:59:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Governor Dan Malloy",
      "screen_name" : "GovMalloyOffice",
      "indices" : [ 3, 19 ],
      "id_str" : "234141596",
      "id" : 234141596
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 82, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441311281342328832",
  "text" : "RT @GovMalloyOffice: If you work 40 hours a week, you should not live in poverty. #RaiseTheWage",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RaiseTheWage",
        "indices" : [ 61, 74 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "441291729027616768",
    "text" : "If you work 40 hours a week, you should not live in poverty. #RaiseTheWage",
    "id" : 441291729027616768,
    "created_at" : "2014-03-05 19:18:41 +0000",
    "user" : {
      "name" : "Governor Dan Malloy",
      "screen_name" : "GovMalloyOffice",
      "protected" : false,
      "id_str" : "234141596",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738519424223858688\/_0xQvvKS_normal.jpg",
      "id" : 234141596,
      "verified" : true
    }
  },
  "id" : 441311281342328832,
  "created_at" : "2014-03-05 20:36:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charlie Baker",
      "screen_name" : "MassGovernor",
      "indices" : [ 3, 16 ],
      "id_str" : "18023868",
      "id" : 18023868
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441307287698038784",
  "text" : "RT @MassGovernor: To those who are reluctant to raise the minimum wage, before you resolve to oppose it, consider whether you could live on\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RaiseTheWage",
        "indices" : [ 126, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "441286184832991232",
    "text" : "To those who are reluctant to raise the minimum wage, before you resolve to oppose it, consider whether you could live on it. #RaiseTheWage",
    "id" : 441286184832991232,
    "created_at" : "2014-03-05 18:56:39 +0000",
    "user" : {
      "name" : "Charlie Baker",
      "screen_name" : "MassGovernor",
      "protected" : false,
      "id_str" : "18023868",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/588540751430033408\/5rOCtVsL_normal.jpg",
      "id" : 18023868,
      "verified" : true
    }
  },
  "id" : 441307287698038784,
  "created_at" : "2014-03-05 20:20:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TimeFor1010",
      "indices" : [ 35, 47 ]
    }, {
      "text" : "RaiseTheWage",
      "indices" : [ 85, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441300348477919232",
  "text" : "RT @WHLive: President Obama: \"It\u2019s #TimeFor1010. It\u2019s time to give America a raise.\" #RaiseTheWage",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TimeFor1010",
        "indices" : [ 23, 35 ]
      }, {
        "text" : "RaiseTheWage",
        "indices" : [ 73, 86 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "441299542219431938",
    "text" : "President Obama: \"It\u2019s #TimeFor1010. It\u2019s time to give America a raise.\" #RaiseTheWage",
    "id" : 441299542219431938,
    "created_at" : "2014-03-05 19:49:44 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 441300348477919232,
  "created_at" : "2014-03-05 19:52:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/441298206610051072\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/YekbVGDWbh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bh_OYXDCIAADNbZ.jpg",
      "id_str" : "441298206404517888",
      "id" : 441298206404517888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bh_OYXDCIAADNbZ.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/YekbVGDWbh"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 101, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441298206610051072",
  "text" : "\"If we\u2019re going to finish the job, Congress has to get on board.\" \u2014Obama on raising the minimum wage #RaiseTheWage http:\/\/t.co\/YekbVGDWbh",
  "id" : 441298206610051072,
  "created_at" : "2014-03-05 19:44:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 119, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441297802715742208",
  "text" : "\"They deserve an honest day\u2019s pay for an honest day\u2019s work.\" \u2014Obama on hardworking Americans who make the minimum wage #RaiseTheWage",
  "id" : 441297802715742208,
  "created_at" : "2014-03-05 19:42:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 119, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441296065539891201",
  "text" : "Obama: \"Nobody who works full-time should ever have to raise a family in poverty...it's time to give America a raise.\" #RaiseTheWage",
  "id" : 441296065539891201,
  "created_at" : "2014-03-05 19:35:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 91, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/FEepCRHE6o",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "441295862053232640",
  "text" : "RT @WHLive: President Obama: \"If any of you know a young person who\u2019s uninsured, help them #GetCovered at http:\/\/t.co\/FEepCRHE6o by March 3\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GetCovered",
        "indices" : [ 79, 90 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/FEepCRHE6o",
        "expanded_url" : "http:\/\/Healthcare.gov",
        "display_url" : "Healthcare.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "441295731845246976",
    "text" : "President Obama: \"If any of you know a young person who\u2019s uninsured, help them #GetCovered at http:\/\/t.co\/FEepCRHE6o by March 31st.\"",
    "id" : 441295731845246976,
    "created_at" : "2014-03-05 19:34:36 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 441295862053232640,
  "created_at" : "2014-03-05 19:35:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 19, 37 ]
    }, {
      "text" : "EqualPay",
      "indices" : [ 77, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441295584667107328",
  "text" : "President Obama on #OpportunityForAll: \"That means making sure women receive #EqualPay for equal work. When women succeed, America succeeds\"",
  "id" : 441295584667107328,
  "created_at" : "2014-03-05 19:34:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 102, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/apuVnhd3G8",
      "expanded_url" : "http:\/\/StudentAid.gov",
      "display_url" : "StudentAid.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "441295311525670912",
  "text" : "President Obama: \"No young person should be priced out of a higher education.\" http:\/\/t.co\/apuVnhd3G8 #CollegeOpportunity",
  "id" : 441295311525670912,
  "created_at" : "2014-03-05 19:32:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441295199839748097",
  "text" : "RT @WHLive: Obama in CT: \"We\u2019re offering millions...the chance to cap their monthly student loan payments at 10% of their income\" http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/AJ4vlXpQUP",
        "expanded_url" : "http:\/\/go.wh.gov\/eWTL9X",
        "display_url" : "go.wh.gov\/eWTL9X"
      } ]
    },
    "geo" : { },
    "id_str" : "441295022789787648",
    "text" : "Obama in CT: \"We\u2019re offering millions...the chance to cap their monthly student loan payments at 10% of their income\" http:\/\/t.co\/AJ4vlXpQUP",
    "id" : 441295022789787648,
    "created_at" : "2014-03-05 19:31:46 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 441295199839748097,
  "created_at" : "2014-03-05 19:32:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/441294818275102720\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/9fupTXMYbP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bh_LTIjCYAAhJje.jpg",
      "id_str" : "441294818077990912",
      "id" : 441294818077990912,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bh_LTIjCYAAhJje.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/9fupTXMYbP"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441294818275102720",
  "text" : "Obama: \"We\u2019ve got to rebuild our economy so it creates a steady stream of good jobs today and well into the future.\" http:\/\/t.co\/9fupTXMYbP",
  "id" : 441294818275102720,
  "created_at" : "2014-03-05 19:30:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 114, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/7w68yiIEie",
      "expanded_url" : "http:\/\/go.wh.gov\/YVgK7C",
      "display_url" : "go.wh.gov\/YVgK7C"
    } ]
  },
  "geo" : { },
  "id_str" : "441290621144535040",
  "text" : "Don't miss President Obama speak at 2:30pm ET on why it's time to raise the minimum wage \u2192 http:\/\/t.co\/7w68yiIEie #RaiseTheWage",
  "id" : 441290621144535040,
  "created_at" : "2014-03-05 19:14:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sherrod Brown",
      "screen_name" : "SenSherrodBrown",
      "indices" : [ 3, 19 ],
      "id_str" : "43910797",
      "id" : 43910797
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "raisethewage",
      "indices" : [ 78, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/w6OF0XckJL",
      "expanded_url" : "http:\/\/ow.ly\/ugWr3",
      "display_url" : "ow.ly\/ugWr3"
    } ]
  },
  "geo" : { },
  "id_str" : "441281364768600064",
  "text" : "RT @SenSherrodBrown: Nearly 88,600 Ohioans would no longer rely on SNAP if we #raisethewage to $10.10 per hour http:\/\/t.co\/w6OF0XckJL @ampr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "American Progress",
        "screen_name" : "amprog",
        "indices" : [ 113, 120 ],
        "id_str" : "17171111",
        "id" : 17171111
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "raisethewage",
        "indices" : [ 57, 70 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/w6OF0XckJL",
        "expanded_url" : "http:\/\/ow.ly\/ugWr3",
        "display_url" : "ow.ly\/ugWr3"
      } ]
    },
    "geo" : { },
    "id_str" : "441272162234941440",
    "text" : "Nearly 88,600 Ohioans would no longer rely on SNAP if we #raisethewage to $10.10 per hour http:\/\/t.co\/w6OF0XckJL @amprog",
    "id" : 441272162234941440,
    "created_at" : "2014-03-05 18:00:56 +0000",
    "user" : {
      "name" : "Sherrod Brown",
      "screen_name" : "SenSherrodBrown",
      "protected" : false,
      "id_str" : "43910797",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/523158370333638657\/cLmYIfYa_normal.jpeg",
      "id" : 43910797,
      "verified" : true
    }
  },
  "id" : 441281364768600064,
  "created_at" : "2014-03-05 18:37:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/441272176637796353\/photo\/1",
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/FAfCVqbsal",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bh-2tN_CUAArSvi.jpg",
      "id_str" : "441272176470020096",
      "id" : 441272176470020096,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bh-2tN_CUAArSvi.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/FAfCVqbsal"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 81, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441272176637796353",
  "text" : "RT if you agree: Nobody who works full-time should live in poverty. It's time to #RaiseTheWage. http:\/\/t.co\/FAfCVqbsal",
  "id" : 441272176637796353,
  "created_at" : "2014-03-05 18:01:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 120, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/4XsBMmFEur",
      "expanded_url" : "http:\/\/go.wh.gov\/rmuiNf",
      "display_url" : "go.wh.gov\/rmuiNf"
    } ]
  },
  "geo" : { },
  "id_str" : "441260779493281793",
  "text" : "FACT: Raising the federal minimum wage to $10.10\/hour would lift wages for 28 million Americans. http:\/\/t.co\/4XsBMmFEur #RaiseTheWage",
  "id" : 441260779493281793,
  "created_at" : "2014-03-05 17:15:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Governor Dan Malloy",
      "screen_name" : "GovMalloyOffice",
      "indices" : [ 67, 83 ],
      "id_str" : "234141596",
      "id" : 234141596
    }, {
      "name" : "Peter Shumlin",
      "screen_name" : "GovPeterShumlin",
      "indices" : [ 90, 106 ],
      "id_str" : "231854033",
      "id" : 231854033
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 131, 144 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/4hfZLFR6QT",
      "expanded_url" : "http:\/\/cnn.it\/1lyIQGb",
      "display_url" : "cnn.it\/1lyIQGb"
    } ]
  },
  "geo" : { },
  "id_str" : "441253826528833536",
  "text" : "\"No brainer: 3 reasons why a $10.10 min wage is good for America\" \u2014@GovMalloyOffice &amp; @GovPeterShumlin: http:\/\/t.co\/4hfZLFR6QT #RaiseTheWage",
  "id" : 441253826528833536,
  "created_at" : "2014-03-05 16:48:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/441245831094484992\/photo\/1",
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/Va6ZuVRtoJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bh-evtSCEAEkGR_.png",
      "id_str" : "441245830951866369",
      "id" : 441245830951866369,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bh-evtSCEAEkGR_.png",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Va6ZuVRtoJ"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 13, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441245831094484992",
  "text" : "It's time to #RaiseTheWage because nobody who works full-time should live in poverty. http:\/\/t.co\/Va6ZuVRtoJ",
  "id" : 441245831094484992,
  "created_at" : "2014-03-05 16:16:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 131, 144 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/7O8uCmmUpz",
      "expanded_url" : "http:\/\/bloom.bg\/1nb1Ngf",
      "display_url" : "bloom.bg\/1nb1Ngf"
    } ]
  },
  "geo" : { },
  "id_str" : "441223345770856449",
  "text" : "Washington state has the highest min wage in the country &amp; their job growth beats the national average: http:\/\/t.co\/7O8uCmmUpz #RaiseTheWage",
  "id" : 441223345770856449,
  "created_at" : "2014-03-05 14:46:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/petesouza\/status\/441014006405660672\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/zIDeVH8mp5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bh7L5vKIIAAeOo1.jpg",
      "id_str" : "441014006300811264",
      "id" : 441014006300811264,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bh7L5vKIIAAeOo1.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 682
      }, {
        "h" : 901,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 682
      } ],
      "display_url" : "pic.twitter.com\/zIDeVH8mp5"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "441039483161812992",
  "text" : "RT @petesouza: A young student uses a stethoscope on President Obama at Powell Elementary School in DC today. http:\/\/t.co\/zIDeVH8mp5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/petesouza\/status\/441014006405660672\/photo\/1",
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/zIDeVH8mp5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bh7L5vKIIAAeOo1.jpg",
        "id_str" : "441014006300811264",
        "id" : 441014006300811264,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bh7L5vKIIAAeOo1.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 682
        }, {
          "h" : 901,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 682
        } ],
        "display_url" : "pic.twitter.com\/zIDeVH8mp5"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "441014006405660672",
    "text" : "A young student uses a stethoscope on President Obama at Powell Elementary School in DC today. http:\/\/t.co\/zIDeVH8mp5",
    "id" : 441014006405660672,
    "created_at" : "2014-03-05 00:55:07 +0000",
    "user" : {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "protected" : false,
      "id_str" : "18215973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771916869808844800\/7d_poH48_normal.jpg",
      "id" : 18215973,
      "verified" : true
    }
  },
  "id" : 441039483161812992,
  "created_at" : "2014-03-05 02:36:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 112, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440991276758880256",
  "text" : "RT @VP: VP signs a wall at Atlanta's BD Ad Group, which now pays at least $10.10 thanks to the CEO's support to #RaiseTheWage http:\/\/t.co\/o\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/440987563252129793\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/oc4tDiSxAj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bh6z2jKCIAAJXTK.jpg",
        "id_str" : "440987563260518400",
        "id" : 440987563260518400,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bh6z2jKCIAAJXTK.jpg",
        "sizes" : [ {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/oc4tDiSxAj"
      } ],
      "hashtags" : [ {
        "text" : "RaiseTheWage",
        "indices" : [ 104, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "440987563252129793",
    "text" : "VP signs a wall at Atlanta's BD Ad Group, which now pays at least $10.10 thanks to the CEO's support to #RaiseTheWage http:\/\/t.co\/oc4tDiSxAj",
    "id" : 440987563252129793,
    "created_at" : "2014-03-04 23:10:03 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 440991276758880256,
  "created_at" : "2014-03-04 23:24:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440971204107591681",
  "text" : "RT @FLOTUS: No matter where you're from, millions around the world share the same hopes and dreams and struggles as you. http:\/\/t.co\/xB3y03\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/440965176360050688\/photo\/1",
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/xB3y03LXvB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bh6ffceCYAEfYFY.jpg",
        "id_str" : "440965176095825921",
        "id" : 440965176095825921,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bh6ffceCYAEfYFY.jpg",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/xB3y03LXvB"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "440965176360050688",
    "text" : "No matter where you're from, millions around the world share the same hopes and dreams and struggles as you. http:\/\/t.co\/xB3y03LXvB",
    "id" : 440965176360050688,
    "created_at" : "2014-03-04 21:41:05 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 440971204107591681,
  "created_at" : "2014-03-04 22:05:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440962206193045504",
  "text" : "RT @pfeiffer44: GOP criticism of Pres Obama jumped the shark today when they started saying Benghazi is one of the reasons for what is happ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "440934819107586048",
    "text" : "GOP criticism of Pres Obama jumped the shark today when they started saying Benghazi is one of the reasons for what is happening in Crimea",
    "id" : 440934819107586048,
    "created_at" : "2014-03-04 19:40:27 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 440962206193045504,
  "created_at" : "2014-03-04 21:29:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/440940724671221760\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/m5ZPwiZUEU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bh6JQLVIYAALq-i.jpg",
      "id_str" : "440940724541218816",
      "id" : 440940724541218816,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bh6JQLVIYAALq-i.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/m5ZPwiZUEU"
    } ],
    "hashtags" : [ {
      "text" : "budget",
      "indices" : [ 18, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440940724671221760",
  "text" : "President Obama's #budget invests in his vision of giving every 4-year-old in America access to quality preschool. http:\/\/t.co\/m5ZPwiZUEU",
  "id" : 440940724671221760,
  "created_at" : "2014-03-04 20:03:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "indices" : [ 3, 12 ],
      "id_str" : "337742544",
      "id" : 337742544
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BudgetChat",
      "indices" : [ 119, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440929978004561920",
  "text" : "RT @OMBPress: Interesting picture from our Budget numbers...deficits as a share of our economy fall to 1.6% by 2024... #BudgetChat http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/OMBPress\/status\/440929853081014272\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/8VzE5DkBlp",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bh5_XYACUAAQ0ol.jpg",
        "id_str" : "440929853085208576",
        "id" : 440929853085208576,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bh5_XYACUAAQ0ol.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/8VzE5DkBlp"
      } ],
      "hashtags" : [ {
        "text" : "BudgetChat",
        "indices" : [ 105, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "440929853081014272",
    "text" : "Interesting picture from our Budget numbers...deficits as a share of our economy fall to 1.6% by 2024... #BudgetChat http:\/\/t.co\/8VzE5DkBlp",
    "id" : 440929853081014272,
    "created_at" : "2014-03-04 19:20:43 +0000",
    "user" : {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "protected" : false,
      "id_str" : "337742544",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1449289379\/OMB_Seal_normal.jpg",
      "id" : 337742544,
      "verified" : true
    }
  },
  "id" : 440929978004561920,
  "created_at" : "2014-03-04 19:21:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "indices" : [ 52, 61 ],
      "id_str" : "337742544",
      "id" : 337742544
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "budget",
      "indices" : [ 36, 43 ]
    }, {
      "text" : "BudgetChat",
      "indices" : [ 129, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440920982086500352",
  "text" : "Have questions on President Obama's #budget? Follow @OMBPress at 2pm ET for a Q&amp;A with Brian Deese. Ask your questions using #BudgetChat.",
  "id" : 440920982086500352,
  "created_at" : "2014-03-04 18:45:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/440918098456379392\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/ktN1LnMRTH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bh50rJ6IAAAJunM.jpg",
      "id_str" : "440918098271797248",
      "id" : 440918098271797248,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bh50rJ6IAAAJunM.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ktN1LnMRTH"
    } ],
    "hashtags" : [ {
      "text" : "budget",
      "indices" : [ 18, 25 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/THbmoHGXUB",
      "expanded_url" : "http:\/\/go.wh.gov\/wMPGob",
      "display_url" : "go.wh.gov\/wMPGob"
    } ]
  },
  "geo" : { },
  "id_str" : "440918098456379392",
  "text" : "President Obama's #budget, ready for his signature before it gets sent to Congress \u2192 http:\/\/t.co\/THbmoHGXUB, http:\/\/t.co\/ktN1LnMRTH",
  "id" : 440918098456379392,
  "created_at" : "2014-03-04 18:34:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "budget",
      "indices" : [ 18, 25 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/eQj4Y6n3Cf",
      "expanded_url" : "http:\/\/go.wh.gov\/PGAX16",
      "display_url" : "go.wh.gov\/PGAX16"
    } ]
  },
  "geo" : { },
  "id_str" : "440913485547843584",
  "text" : "President Obama's #budget closes unfair tax loopholes so we can invest in things that strengthen the middle class \u2192 http:\/\/t.co\/eQj4Y6n3Cf",
  "id" : 440913485547843584,
  "created_at" : "2014-03-04 18:15:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "indices" : [ 3, 12 ],
      "id_str" : "337742544",
      "id" : 337742544
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "budget",
      "indices" : [ 105, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440907266095841280",
  "text" : "RT @OMBPress: At 2pm ET, OMB Deputy Director Brian Deese will answer your questions on President Obama's #budget. Ask away using #BudgetCha\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "budget",
        "indices" : [ 91, 98 ]
      }, {
        "text" : "BudgetChat",
        "indices" : [ 115, 126 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "440905935213449217",
    "text" : "At 2pm ET, OMB Deputy Director Brian Deese will answer your questions on President Obama's #budget. Ask away using #BudgetChat.",
    "id" : 440905935213449217,
    "created_at" : "2014-03-04 17:45:41 +0000",
    "user" : {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "protected" : false,
      "id_str" : "337742544",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1449289379\/OMB_Seal_normal.jpg",
      "id" : 337742544,
      "verified" : true
    }
  },
  "id" : 440907266095841280,
  "created_at" : "2014-03-04 17:50:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "budget",
      "indices" : [ 14, 21 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/pAz2m55A9z",
      "expanded_url" : "http:\/\/go.wh.gov\/HGTARF",
      "display_url" : "go.wh.gov\/HGTARF"
    } ]
  },
  "geo" : { },
  "id_str" : "440900378813800448",
  "text" : "FACT: Obama's #budget expands the Earned Income Tax Credit\u2014which would cut taxes for 13.5 million working Americans \u2192 http:\/\/t.co\/pAz2m55A9z",
  "id" : 440900378813800448,
  "created_at" : "2014-03-04 17:23:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440890830510096384",
  "text" : "RT @WHLive: President Obama: \"We\u2019re going to continue to reduce our deficits responsibly, while taking steps to grow and strengthen the mid\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "440890722519355392",
    "text" : "President Obama: \"We\u2019re going to continue to reduce our deficits responsibly, while taking steps to grow and strengthen the middle class.\"",
    "id" : 440890722519355392,
    "created_at" : "2014-03-04 16:45:14 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 440890830510096384,
  "created_at" : "2014-03-04 16:45:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "budget",
      "indices" : [ 25, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440890387201536000",
  "text" : "RT @WHLive: Obama: \"This #budget creates 45 high-tech manufacturing hubs where businesses &amp; universities will...turn groundbreaking researc\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "budget",
        "indices" : [ 13, 20 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "440890084867723264",
    "text" : "Obama: \"This #budget creates 45 high-tech manufacturing hubs where businesses &amp; universities will...turn groundbreaking research into jobs.\"",
    "id" : 440890084867723264,
    "created_at" : "2014-03-04 16:42:42 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 440890387201536000,
  "created_at" : "2014-03-04 16:43:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "budget",
      "indices" : [ 13, 20 ]
    }, {
      "text" : "OpportunityForAll",
      "indices" : [ 119, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440889732852383744",
  "text" : "Obama on his #budget: \"It\u2019s a roadmap for creating jobs with good wages and expanding opportunity for every American.\" #OpportunityForAll",
  "id" : 440889732852383744,
  "created_at" : "2014-03-04 16:41:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "budget",
      "indices" : [ 25, 32 ]
    }, {
      "text" : "OpportunityForAll",
      "indices" : [ 56, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440889642922287104",
  "text" : "RT @WHLive: Obama on his #budget: \"An agenda to restore #OpportunityForAll, the idea that no matter who you are...you can make it if you tr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "budget",
        "indices" : [ 13, 20 ]
      }, {
        "text" : "OpportunityForAll",
        "indices" : [ 44, 62 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "440889566296555520",
    "text" : "Obama on his #budget: \"An agenda to restore #OpportunityForAll, the idea that no matter who you are...you can make it if you try.\"",
    "id" : 440889566296555520,
    "created_at" : "2014-03-04 16:40:38 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 440889642922287104,
  "created_at" : "2014-03-04 16:40:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "budget",
      "indices" : [ 18, 25 ]
    }, {
      "text" : "OpportunityForAll",
      "indices" : [ 71, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/77BQWDUEYk",
      "expanded_url" : "http:\/\/go.wh.gov\/mddQd4",
      "display_url" : "go.wh.gov\/mddQd4"
    } ]
  },
  "geo" : { },
  "id_str" : "440888584342867968",
  "text" : "President Obama's #budget shows how we can grow our economy and expand #OpportunityForAll hardworking Americans: http:\/\/t.co\/77BQWDUEYk",
  "id" : 440888584342867968,
  "created_at" : "2014-03-04 16:36:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "budget",
      "indices" : [ 54, 61 ]
    }, {
      "text" : "OpportunityForAll",
      "indices" : [ 96, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/YGHRyMmcuP",
      "expanded_url" : "http:\/\/go.wh.gov\/x9NA1s",
      "display_url" : "go.wh.gov\/x9NA1s"
    } ]
  },
  "geo" : { },
  "id_str" : "440880393345310720",
  "text" : "Watch President Obama speak at 11:30am ET on his FY15 #budget, which lays out how we can expand #OpportunityForAll \u2192 http:\/\/t.co\/YGHRyMmcuP",
  "id" : 440880393345310720,
  "created_at" : "2014-03-04 16:04:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/440625280193794048\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/NA60wsGsPf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bh1qW40CMAAqQ8O.jpg",
      "id_str" : "440625279992475648",
      "id" : 440625279992475648,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bh1qW40CMAAqQ8O.jpg",
      "sizes" : [ {
        "h" : 610,
        "resize" : "fit",
        "w" : 818
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 610,
        "resize" : "fit",
        "w" : 818
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 447,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/NA60wsGsPf"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 63, 74 ]
    }, {
      "text" : "TimeToEnroll",
      "indices" : [ 100, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/SFw5DUo7C0",
      "expanded_url" : "http:\/\/hc.gov\/ARcRxi",
      "display_url" : "hc.gov\/ARcRxi"
    } ]
  },
  "geo" : { },
  "id_str" : "440625280193794048",
  "text" : "Let's help more Americans who need affordable health insurance #GetCovered \u2192 http:\/\/t.co\/SFw5DUo7C0 #TimeToEnroll, http:\/\/t.co\/NA60wsGsPf",
  "id" : 440625280193794048,
  "created_at" : "2014-03-03 23:10:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/440609878852108288\/photo\/1",
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/typadKh7MC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bh1cWawCcAAqzFA.png",
      "id_str" : "440609878759862272",
      "id" : 440609878759862272,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bh1cWawCcAAqzFA.png",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/typadKh7MC"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 0, 11 ]
    }, {
      "text" : "TimeToEnroll",
      "indices" : [ 61, 74 ]
    } ],
    "urls" : [ {
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/cooLdi6fO7",
      "expanded_url" : "http:\/\/hc.gov\/KK8oyk",
      "display_url" : "hc.gov\/KK8oyk"
    } ]
  },
  "geo" : { },
  "id_str" : "440609878852108288",
  "text" : "#GetCovered because accidents happen: http:\/\/t.co\/cooLdi6fO7 #TimeToEnroll, http:\/\/t.co\/typadKh7MC",
  "id" : 440609878852108288,
  "created_at" : "2014-03-03 22:09:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440600555623559168",
  "text" : "RT @Interior: Fact: America's National Parks support 243K jobs and pump $26.75 billion into local economies. Please RT http:\/\/t.co\/TXuTWxrh\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Interior\/status\/440561369251721216\/photo\/1",
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/TXuTWxrhn3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bh0wOyyCMAASh8T.jpg",
        "id_str" : "440561369260109824",
        "id" : 440561369260109824,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bh0wOyyCMAASh8T.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1365
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/TXuTWxrhn3"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "440561369251721216",
    "text" : "Fact: America's National Parks support 243K jobs and pump $26.75 billion into local economies. Please RT http:\/\/t.co\/TXuTWxrhn3",
    "id" : 440561369251721216,
    "created_at" : "2014-03-03 18:56:30 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 440600555623559168,
  "created_at" : "2014-03-03 21:32:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 99, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/afW5YTsec0",
      "expanded_url" : "http:\/\/hc.gov\/ytGPrx",
      "display_url" : "hc.gov\/ytGPrx"
    } ]
  },
  "geo" : { },
  "id_str" : "440592614358659072",
  "text" : "DON'T WAIT: Just 4 weeks left to make sure you've got quality, affordable health coverage in 2014. #GetCovered today: http:\/\/t.co\/afW5YTsec0",
  "id" : 440592614358659072,
  "created_at" : "2014-03-03 21:00:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. EPA",
      "screen_name" : "EPA",
      "indices" : [ 1, 5 ],
      "id_str" : "14615871",
      "id" : 14615871
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440582547429285888",
  "text" : ".@EPA's clean fuel standards will cost refineries less than 1 penny\/gallon, while preventing 50,000 respiratory illnesses in kids each year.",
  "id" : 440582547429285888,
  "created_at" : "2014-03-03 20:20:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/440571927359283200\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/DUbzHXzT8e",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bh051WMCEAASG2l.jpg",
      "id_str" : "440571927204073472",
      "id" : 440571927204073472,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bh051WMCEAASG2l.jpg",
      "sizes" : [ {
        "h" : 565,
        "resize" : "fit",
        "w" : 565
      }, {
        "h" : 565,
        "resize" : "fit",
        "w" : 565
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 565,
        "resize" : "fit",
        "w" : 565
      } ],
      "display_url" : "pic.twitter.com\/DUbzHXzT8e"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440571927359283200",
  "text" : "FACT: New clean fuel standards are expected to provide up to $13 in health benefits for every $1 spent to meet them. http:\/\/t.co\/DUbzHXzT8e",
  "id" : 440571927359283200,
  "created_at" : "2014-03-03 19:38:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/440560244138065920\/photo\/1",
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/797UZexbAR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bh0vNS6CUAEfTu-.jpg",
      "id_str" : "440560244012240897",
      "id" : 440560244012240897,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bh0vNS6CUAEfTu-.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/797UZexbAR"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 0, 11 ]
    }, {
      "text" : "TimeToEnroll",
      "indices" : [ 74, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/Alolb5rsVw",
      "expanded_url" : "http:\/\/hc.gov\/iUyEYT",
      "display_url" : "hc.gov\/iUyEYT"
    } ]
  },
  "geo" : { },
  "id_str" : "440560244138065920",
  "text" : "#GetCovered so you don't go broke if you get sick: http:\/\/t.co\/Alolb5rsVw #TimeToEnroll, http:\/\/t.co\/797UZexbAR",
  "id" : 440560244138065920,
  "created_at" : "2014-03-03 18:52:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 108, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/5zeR2RQuXe",
      "expanded_url" : "http:\/\/Healthcare.gov",
      "display_url" : "Healthcare.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "440549241673764864",
  "text" : "Spread the word: Just 4 weeks left to sign up for 2014 health coverage. Make sure your friends &amp; family #GetCovered \u2192 http:\/\/t.co\/5zeR2RQuXe",
  "id" : 440549241673764864,
  "created_at" : "2014-03-03 18:08:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/440538317939949568\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/7EWfHU6Je9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bh0bRBoCYAAnH_U.jpg",
      "id_str" : "440538317860265984",
      "id" : 440538317860265984,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bh0bRBoCYAAnH_U.jpg",
      "sizes" : [ {
        "h" : 565,
        "resize" : "fit",
        "w" : 565
      }, {
        "h" : 565,
        "resize" : "fit",
        "w" : 565
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 565,
        "resize" : "fit",
        "w" : 565
      } ],
      "display_url" : "pic.twitter.com\/7EWfHU6Je9"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 94, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "440538317939949568",
  "text" : "FACT: By 2030, new clean fuel standards will prevent up to 2,000 premature deaths EVERY YEAR. #ActOnClimate, http:\/\/t.co\/7EWfHU6Je9",
  "id" : 440538317939949568,
  "created_at" : "2014-03-03 17:24:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/j0DZwSA1sH",
      "expanded_url" : "http:\/\/go.wh.gov\/5zMuY2",
      "display_url" : "go.wh.gov\/5zMuY2"
    } ]
  },
  "geo" : { },
  "id_str" : "440522297661988865",
  "text" : "President Obama's clean fuel standards will:\n\u2193 harmful emissions\nPrevent illnesses\nEncourage innovation\nhttp:\/\/t.co\/j0DZwSA1sH #ActOnClimate",
  "id" : 440522297661988865,
  "created_at" : "2014-03-03 16:21:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "indices" : [ 3, 11 ],
      "id_str" : "1530850933",
      "id" : 1530850933
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 142 ],
      "url" : "http:\/\/t.co\/Dp5CGlZIdz",
      "expanded_url" : "http:\/\/www.epa.gov\/otaq\/tier3.htm",
      "display_url" : "epa.gov\/otaq\/tier3.htm"
    } ]
  },
  "geo" : { },
  "id_str" : "440504982216122369",
  "text" : "RT @GinaEPA: Today we\u2019re announcing new standards for cars &amp; fuels to make air cleaner, American families healthier http:\/\/t.co\/Dp5CGlZIdz \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "cleancars",
        "indices" : [ 130, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/Dp5CGlZIdz",
        "expanded_url" : "http:\/\/www.epa.gov\/otaq\/tier3.htm",
        "display_url" : "epa.gov\/otaq\/tier3.htm"
      } ]
    },
    "geo" : { },
    "id_str" : "440495673964654592",
    "text" : "Today we\u2019re announcing new standards for cars &amp; fuels to make air cleaner, American families healthier http:\/\/t.co\/Dp5CGlZIdz #cleancars",
    "id" : 440495673964654592,
    "created_at" : "2014-03-03 14:35:27 +0000",
    "user" : {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "protected" : false,
      "id_str" : "1530850933",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/632229333130604548\/Bb4I34DU_normal.jpg",
      "id" : 1530850933,
      "verified" : true
    }
  },
  "id" : 440504982216122369,
  "created_at" : "2014-03-03 15:12:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ukraine",
      "indices" : [ 53, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/vifFjrezFa",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/the-press-office\/2014\/03\/02\/g-7-leaders-statement",
      "display_url" : "whitehouse.gov\/the-press-offi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "440295518951186433",
  "text" : "RT @NSCPress: Statement by the Leaders of the G-7 on #Ukraine: \u00A0http:\/\/t.co\/vifFjrezFa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Ukraine",
        "indices" : [ 39, 47 ]
      } ],
      "urls" : [ {
        "indices" : [ 50, 72 ],
        "url" : "http:\/\/t.co\/vifFjrezFa",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/the-press-office\/2014\/03\/02\/g-7-leaders-statement",
        "display_url" : "whitehouse.gov\/the-press-offi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "440286695787749376",
    "text" : "Statement by the Leaders of the G-7 on #Ukraine: \u00A0http:\/\/t.co\/vifFjrezFa",
    "id" : 440286695787749376,
    "created_at" : "2014-03-03 00:45:03 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 440295518951186433,
  "created_at" : "2014-03-03 01:20:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/c3AI8wA1eO",
      "expanded_url" : "http:\/\/go.wh.gov\/gMCEHN",
      "display_url" : "go.wh.gov\/gMCEHN"
    } ]
  },
  "geo" : { },
  "id_str" : "440275520903589888",
  "text" : "Obama: \"Next week, I\u2019ll send Congress a budget that will rebuild...transportation systems &amp; support millions of jobs\" http:\/\/t.co\/c3AI8wA1eO",
  "id" : 440275520903589888,
  "created_at" : "2014-03-03 00:00:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/c3AI8wA1eO",
      "expanded_url" : "http:\/\/go.wh.gov\/gMCEHN",
      "display_url" : "go.wh.gov\/gMCEHN"
    } ]
  },
  "geo" : { },
  "id_str" : "440260419786006530",
  "text" : "Obama: \"Rebuilding America won\u2019t just attract new businesses\u2014it will create...jobs that can\u2019t be shipped overseas.\" http:\/\/t.co\/c3AI8wA1eO",
  "id" : 440260419786006530,
  "created_at" : "2014-03-02 23:00:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/1rVx8RgTjq",
      "expanded_url" : "http:\/\/go.wh.gov\/gMCEHN",
      "display_url" : "go.wh.gov\/gMCEHN"
    } ]
  },
  "geo" : { },
  "id_str" : "440229106433945600",
  "text" : "Obama: \"If we want to attract more...manufacturing jobs to America, we\u2019ve got to make sure we\u2019re on the cutting edge\" http:\/\/t.co\/1rVx8RgTjq",
  "id" : 440229106433945600,
  "created_at" : "2014-03-02 20:56:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 120, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/c3AI8wA1eO",
      "expanded_url" : "http:\/\/go.wh.gov\/gMCEHN",
      "display_url" : "go.wh.gov\/gMCEHN"
    } ]
  },
  "geo" : { },
  "id_str" : "439882927548026882",
  "text" : "President Obama: \"Our manufacturers have added more than 620,000 jobs over the last four years.\" http:\/\/t.co\/c3AI8wA1eO #MadeInAmerica",
  "id" : 439882927548026882,
  "created_at" : "2014-03-01 22:00:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RebuildAmerica",
      "indices" : [ 123, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/c3AI8wA1eO",
      "expanded_url" : "http:\/\/go.wh.gov\/gMCEHN",
      "display_url" : "go.wh.gov\/gMCEHN"
    } ]
  },
  "geo" : { },
  "id_str" : "439837626590191621",
  "text" : "President Obama: \"In today\u2019s global economy, 1st-class jobs gravitate to 1st-class infrastructure.\" http:\/\/t.co\/c3AI8wA1eO #RebuildAmerica",
  "id" : 439837626590191621,
  "created_at" : "2014-03-01 19:00:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    }, {
      "name" : "YellowstoneNPS",
      "screen_name" : "YellowstoneNPS",
      "indices" : [ 35, 50 ],
      "id_str" : "44992488",
      "id" : 44992488
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "439800914946576385",
  "text" : "RT @Interior: 142 years ago today, @YellowstoneNPS became America's first national park. RT to wish them a very happy birthday! http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "YellowstoneNPS",
        "screen_name" : "YellowstoneNPS",
        "indices" : [ 21, 36 ],
        "id_str" : "44992488",
        "id" : 44992488
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/439798246064787456\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/drka6iq0Tc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bhp6LKqIMAAOTCU.jpg",
        "id_str" : "439798245880246272",
        "id" : 439798245880246272,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bhp6LKqIMAAOTCU.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 682
        }, {
          "h" : 901,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 682
        } ],
        "display_url" : "pic.twitter.com\/drka6iq0Tc"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "439798246064787456",
    "text" : "142 years ago today, @YellowstoneNPS became America's first national park. RT to wish them a very happy birthday! http:\/\/t.co\/drka6iq0Tc",
    "id" : 439798246064787456,
    "created_at" : "2014-03-01 16:24:07 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 439800914946576385,
  "created_at" : "2014-03-01 16:34:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RebuildAmerica",
      "indices" : [ 117, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/1rVx8RgTjq",
      "expanded_url" : "http:\/\/go.wh.gov\/gMCEHN",
      "display_url" : "go.wh.gov\/gMCEHN"
    } ]
  },
  "geo" : { },
  "id_str" : "439781957015437312",
  "text" : "President Obama's Weekly Address: Investing in technology and infrastructure to create jobs \u2192 http:\/\/t.co\/1rVx8RgTjq #RebuildAmerica",
  "id" : 439781957015437312,
  "created_at" : "2014-03-01 15:19:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
} ]