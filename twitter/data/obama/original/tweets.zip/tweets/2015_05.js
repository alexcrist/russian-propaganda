Grailbird.data.tweets_2015_05 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/605036619947778048\/photo\/1",
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/mLBc0amPKs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGWE4OUXIAA2mIr.jpg",
      "id_str" : "605035826402238464",
      "id" : 605035826402238464,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGWE4OUXIAA2mIr.jpg",
      "sizes" : [ {
        "h" : 399,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 639,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 639,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/mLBc0amPKs"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/t6s7IwEo90",
      "expanded_url" : "http:\/\/go.wh.gov\/JP4WUv",
      "display_url" : "go.wh.gov\/JP4WUv"
    } ]
  },
  "geo" : { },
  "id_str" : "605036619947778048",
  "text" : "\"Beau Biden was, quite simply, the finest man any of us have ever known.\" http:\/\/t.co\/t6s7IwEo90 http:\/\/t.co\/mLBc0amPKs",
  "id" : 605036619947778048,
  "created_at" : "2015-05-31 15:42:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 34, 37 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/Wpb48cYgK9",
      "expanded_url" : "https:\/\/youtu.be\/CEtbBSwR7SE",
      "display_url" : "youtu.be\/CEtbBSwR7SE"
    } ]
  },
  "geo" : { },
  "id_str" : "604837061020028928",
  "text" : "Our thoughts and prayers are with @VP Biden and his family after the passing of his beloved son, Beau Biden. https:\/\/t.co\/Wpb48cYgK9",
  "id" : 604837061020028928,
  "created_at" : "2015-05-31 02:29:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 114, 120 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/604830376649965568\/photo\/1",
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/KilnFEDbN4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGTJ9GvXIAIaFie.png",
      "id_str" : "604830301592952834",
      "id" : 604830301592952834,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGTJ9GvXIAIaFie.png",
      "sizes" : [ {
        "h" : 521,
        "resize" : "fit",
        "w" : 807
      }, {
        "h" : 220,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 387,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 521,
        "resize" : "fit",
        "w" : 807
      } ],
      "display_url" : "pic.twitter.com\/KilnFEDbN4"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "604830376649965568",
  "text" : "\"Michelle and I humbly pray for the good Lord to watch over Beau Biden, and to protect &amp; comfort his family\" \u2014@POTUS http:\/\/t.co\/KilnFEDbN4",
  "id" : 604830376649965568,
  "created_at" : "2015-05-31 02:02:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 108, 111 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/604829194636378113\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/wayhHq78hx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGTIqK2WcAAioPt.png",
      "id_str" : "604828876766867456",
      "id" : 604828876766867456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGTIqK2WcAAioPt.png",
      "sizes" : [ {
        "h" : 313,
        "resize" : "fit",
        "w" : 752
      }, {
        "h" : 142,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 313,
        "resize" : "fit",
        "w" : 752
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 250,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/wayhHq78hx"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "604829194636378113",
  "text" : "\"In the words of the Biden family: Beau Biden was, quite simply, the finest man any of us have ever known\" \u2014@VP Biden http:\/\/t.co\/wayhHq78hx",
  "id" : 604829194636378113,
  "created_at" : "2015-05-31 01:58:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/kEDKnukYqd",
      "expanded_url" : "http:\/\/go.wh.gov\/jQ2g3Y",
      "display_url" : "go.wh.gov\/jQ2g3Y"
    } ]
  },
  "geo" : { },
  "id_str" : "604777074700607489",
  "text" : "Surprise! 97-year-old Vivian Bailey ran into President Obama and Vice President Biden on her White House tour: http:\/\/t.co\/kEDKnukYqd",
  "id" : 604777074700607489,
  "created_at" : "2015-05-30 22:31:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 109, 115 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/GJUzOBvNTo",
      "expanded_url" : "http:\/\/go.wh.gov\/pdkxvn",
      "display_url" : "go.wh.gov\/pdkxvn"
    } ]
  },
  "geo" : { },
  "id_str" : "604736056278130688",
  "text" : "\"We shouldn\u2019t surrender the tools that help keep us safe. It would be irresponsible. It would be reckless.\" \u2014@POTUS: http:\/\/t.co\/GJUzOBvNTo",
  "id" : 604736056278130688,
  "created_at" : "2015-05-30 19:48:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WestWingWeek",
      "indices" : [ 83, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/kEDKnukYqd",
      "expanded_url" : "http:\/\/go.wh.gov\/jQ2g3Y",
      "display_url" : "go.wh.gov\/jQ2g3Y"
    } ]
  },
  "geo" : { },
  "id_str" : "604712148430774274",
  "text" : "\"High fives for everybody!\" Take a look behind the scenes in the latest edition of #WestWingWeek: http:\/\/t.co\/kEDKnukYqd",
  "id" : 604712148430774274,
  "created_at" : "2015-05-30 18:13:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 86, 92 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/1nba2RBYxH",
      "expanded_url" : "http:\/\/go.wh.gov\/8p14a2",
      "display_url" : "go.wh.gov\/8p14a2"
    } ]
  },
  "geo" : { },
  "id_str" : "604688020533440512",
  "text" : "\"This shouldn\u2019t and can't be about politics. This is a matter of national security.\" \u2014@POTUS on the USA Freedom Act: http:\/\/t.co\/1nba2RBYxH",
  "id" : 604688020533440512,
  "created_at" : "2015-05-30 16:37:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "indices" : [ 19, 29 ],
      "id_str" : "15007149",
      "id" : 15007149
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/ehXLhvejiA",
      "expanded_url" : "http:\/\/go.wh.gov\/puTGAg",
      "display_url" : "go.wh.gov\/puTGAg"
    } ]
  },
  "geo" : { },
  "id_str" : "604330916601667584",
  "text" : "Secretary of State @JohnKerry just rescinded Cuba\u2019s designation as a State Sponsor of Terrorism: http:\/\/t.co\/ehXLhvejiA",
  "id" : 604330916601667584,
  "created_at" : "2015-05-29 16:58:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 3, 13 ],
      "id_str" : "9624742",
      "id" : 9624742
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Cuba",
      "indices" : [ 65, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "604322700987752450",
  "text" : "RT @StateDept: Secretary of State made final decision to rescind #Cuba\u2019s designation as State Sponsor of Terrorism, effective 5\/29. http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Cuba",
        "indices" : [ 50, 55 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/BtYymJY45L",
        "expanded_url" : "http:\/\/go.usa.gov\/3XChW",
        "display_url" : "go.usa.gov\/3XChW"
      } ]
    },
    "geo" : { },
    "id_str" : "604306619904708608",
    "text" : "Secretary of State made final decision to rescind #Cuba\u2019s designation as State Sponsor of Terrorism, effective 5\/29. http:\/\/t.co\/BtYymJY45L",
    "id" : 604306619904708608,
    "created_at" : "2015-05-29 15:21:40 +0000",
    "user" : {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "protected" : false,
      "id_str" : "9624742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724612605185282048\/1rEfkXDZ_normal.jpg",
      "id" : 9624742,
      "verified" : true
    }
  },
  "id" : 604322700987752450,
  "created_at" : "2015-05-29 16:25:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/604318955130347520\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/KJLg2h7xTB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGL4VNUWwAAuhn8.jpg",
      "id_str" : "604318343257047040",
      "id" : 604318343257047040,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGL4VNUWwAAuhn8.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1866,
        "resize" : "fit",
        "w" : 2800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/KJLg2h7xTB"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "604318955130347520",
  "text" : ".@POTUS paid his respects to the Cuban Americans who worship at the Shrine of Our Lady of Charity in Miami yesterday. http:\/\/t.co\/KJLg2h7xTB",
  "id" : 604318955130347520,
  "created_at" : "2015-05-29 16:10:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/5uH8eFvZ1G",
      "expanded_url" : "https:\/\/youtu.be\/zs9OMrlqZVs",
      "display_url" : "youtu.be\/zs9OMrlqZVs"
    } ]
  },
  "geo" : { },
  "id_str" : "604309302401048576",
  "text" : "President John F. Kennedy would have turned 98 today.\nHere's a behind-the-scenes look at his presidential portrait: https:\/\/t.co\/5uH8eFvZ1G",
  "id" : 604309302401048576,
  "created_at" : "2015-05-29 15:32:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/604291764397031425\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/jgzUj0sPyH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGLfrSUWQAAuAvY.jpg",
      "id_str" : "604291234765619200",
      "id" : 604291234765619200,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGLfrSUWQAAuAvY.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1867,
        "resize" : "fit",
        "w" : 2800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/jgzUj0sPyH"
    } ],
    "hashtags" : [ {
      "text" : "AskPOTUS",
      "indices" : [ 22, 31 ]
    }, {
      "text" : "ActOnClimate",
      "indices" : [ 71, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/vdm8SQrTW6",
      "expanded_url" : "http:\/\/go.wh.gov\/L7y7LU",
      "display_url" : "go.wh.gov\/L7y7LU"
    } ]
  },
  "geo" : { },
  "id_str" : "604291764397031425",
  "text" : "Check out yesterday's #AskPOTUS Q&amp;A and share what you're doing to #ActOnClimate \u2192 http:\/\/t.co\/vdm8SQrTW6 http:\/\/t.co\/jgzUj0sPyH",
  "id" : 604291764397031425,
  "created_at" : "2015-05-29 14:22:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pete McNeil (MadSci)",
      "screen_name" : "codedweller",
      "indices" : [ 3, 15 ],
      "id_str" : "97761197",
      "id" : 97761197
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 17, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "604027029755813888",
  "text" : "RT @codedweller: #ActOnClimate * Converted entire Lab to LED lighting. * Optimizing software to save power. * Exploring solar to offset alw\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 0, 13 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "603996421763833857",
    "text" : "#ActOnClimate * Converted entire Lab to LED lighting. * Optimizing software to save power. * Exploring solar to offset always-on systems.",
    "id" : 603996421763833857,
    "created_at" : "2015-05-28 18:49:03 +0000",
    "user" : {
      "name" : "Pete McNeil (MadSci)",
      "screen_name" : "codedweller",
      "protected" : false,
      "id_str" : "97761197",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/436601506452619264\/ifEgRCpb_normal.png",
      "id" : 97761197,
      "verified" : false
    }
  },
  "id" : 604027029755813888,
  "created_at" : "2015-05-28 20:50:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/604004581165543424\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/ZqAwYZdDpw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGHa56FWUAEdzVM.jpg",
      "id_str" : "604004513423446017",
      "id" : 604004513423446017,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGHa56FWUAEdzVM.jpg",
      "sizes" : [ {
        "h" : 299,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 399,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 399,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/ZqAwYZdDpw"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 78, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/lU2sqP1U2v",
      "expanded_url" : "http:\/\/go.wh.gov\/LLZ1Ag",
      "display_url" : "go.wh.gov\/LLZ1Ag"
    } ]
  },
  "geo" : { },
  "id_str" : "604004581165543424",
  "text" : "A sea level rise of just 1 foot could cost America $200 billion. It's time to #ActOnClimate: http:\/\/t.co\/lU2sqP1U2v http:\/\/t.co\/ZqAwYZdDpw",
  "id" : 604004581165543424,
  "created_at" : "2015-05-28 19:21:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valarie Mobley",
      "screen_name" : "Goddeez1027",
      "indices" : [ 3, 15 ],
      "id_str" : "387300413",
      "id" : 387300413
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 97, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "604002506159468544",
  "text" : "RT @Goddeez1027: Find a way 2 Invest in solar energy for home 2 reap the benefits in the longrun #ActOnClimate",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 80, 93 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "603983700301217792",
    "text" : "Find a way 2 Invest in solar energy for home 2 reap the benefits in the longrun #ActOnClimate",
    "id" : 603983700301217792,
    "created_at" : "2015-05-28 17:58:30 +0000",
    "user" : {
      "name" : "Valarie Mobley",
      "screen_name" : "Goddeez1027",
      "protected" : false,
      "id_str" : "387300413",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571866539260964864\/3Bq6mQEw_normal.jpeg",
      "id" : 387300413,
      "verified" : false
    }
  },
  "id" : 604002506159468544,
  "created_at" : "2015-05-28 19:13:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "george odindo",
      "screen_name" : "georgejah",
      "indices" : [ 3, 13 ],
      "id_str" : "418780629",
      "id" : 418780629
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 15, 21 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603991597915623424",
  "text" : "RT @georgejah: @potus, i ride to and from work on a bike which is environmental friendly apart from the physical fitness exercise. #ActOnCl\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 0, 6 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 116, 129 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "603976385044971520",
    "geo" : { },
    "id_str" : "603983938525200384",
    "in_reply_to_user_id" : 1536791610,
    "text" : "@potus, i ride to and from work on a bike which is environmental friendly apart from the physical fitness exercise. #ActOnClimate.",
    "id" : 603983938525200384,
    "in_reply_to_status_id" : 603976385044971520,
    "created_at" : "2015-05-28 17:59:27 +0000",
    "in_reply_to_screen_name" : "POTUS",
    "in_reply_to_user_id_str" : "1536791610",
    "user" : {
      "name" : "george odindo",
      "screen_name" : "georgejah",
      "protected" : false,
      "id_str" : "418780629",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/634237090310541312\/0ELvMxXI_normal.jpg",
      "id" : 418780629,
      "verified" : false
    }
  },
  "id" : 603991597915623424,
  "created_at" : "2015-05-28 18:29:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 125, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603979898911227904",
  "text" : "RT @POTUS: Thanks for the questions! This was fun. I've got to run, but let\u2019s do it again soon. Tell me what you're doing to #ActOnClimate.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 114, 127 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "603976385044971520",
    "text" : "Thanks for the questions! This was fun. I've got to run, but let\u2019s do it again soon. Tell me what you're doing to #ActOnClimate.",
    "id" : 603976385044971520,
    "created_at" : "2015-05-28 17:29:26 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 603979898911227904,
  "created_at" : "2015-05-28 17:43:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Akshar Patel",
      "screen_name" : "apat246",
      "indices" : [ 12, 20 ],
      "id_str" : "390825318",
      "id" : 390825318
    }, {
      "name" : "Chicago Bulls",
      "screen_name" : "chicagobulls",
      "indices" : [ 21, 34 ],
      "id_str" : "16212685",
      "id" : 16212685
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603979870926802944",
  "text" : "RT @POTUS: .@apat246 @chicagobulls love thibs and think he did a great job. Sorry to see him go but expect he will be snatched up soon by a\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Akshar Patel",
        "screen_name" : "apat246",
        "indices" : [ 1, 9 ],
        "id_str" : "390825318",
        "id" : 390825318
      }, {
        "name" : "Chicago Bulls",
        "screen_name" : "chicagobulls",
        "indices" : [ 10, 23 ],
        "id_str" : "16212685",
        "id" : 16212685
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "603962271732215808",
    "geo" : { },
    "id_str" : "603976299246321664",
    "in_reply_to_user_id" : 390825318,
    "text" : ".@apat246 @chicagobulls love thibs and think he did a great job. Sorry to see him go but expect he will be snatched up soon by another team.",
    "id" : 603976299246321664,
    "in_reply_to_status_id" : 603962271732215808,
    "created_at" : "2015-05-28 17:29:05 +0000",
    "in_reply_to_screen_name" : "apat246",
    "in_reply_to_user_id_str" : "390825318",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 603979870926802944,
  "created_at" : "2015-05-28 17:43:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Akshar Patel",
      "screen_name" : "apat246",
      "indices" : [ 3, 11 ],
      "id_str" : "390825318",
      "id" : 390825318
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 13, 19 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Chicago Bulls",
      "screen_name" : "chicagobulls",
      "indices" : [ 109, 122 ],
      "id_str" : "16212685",
      "id" : 16212685
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AskPOTUS",
      "indices" : [ 99, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603979858201292802",
  "text" : "RT @apat246: @POTUS the climate is great, how do you feel about the firing of coach Tom Thibodeau? #AskPOTUS @chicagobulls",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 0, 6 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "Chicago Bulls",
        "screen_name" : "chicagobulls",
        "indices" : [ 96, 109 ],
        "id_str" : "16212685",
        "id" : 16212685
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AskPOTUS",
        "indices" : [ 86, 95 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "603962271732215808",
    "in_reply_to_user_id" : 1536791610,
    "text" : "@POTUS the climate is great, how do you feel about the firing of coach Tom Thibodeau? #AskPOTUS @chicagobulls",
    "id" : 603962271732215808,
    "created_at" : "2015-05-28 16:33:21 +0000",
    "in_reply_to_screen_name" : "POTUS",
    "in_reply_to_user_id_str" : "1536791610",
    "user" : {
      "name" : "Akshar Patel",
      "screen_name" : "apat246",
      "protected" : false,
      "id_str" : "390825318",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/772670763358883840\/CFWk6FoA_normal.jpg",
      "id" : 390825318,
      "verified" : false
    }
  },
  "id" : 603979858201292802,
  "created_at" : "2015-05-28 17:43:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Zebulon Carlander",
      "screen_name" : "ZCarlander",
      "indices" : [ 12, 23 ],
      "id_str" : "1322284950",
      "id" : 1322284950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603975939136090113",
  "text" : "RT @POTUS: .@ZCarlander agreement with China big and will be working w Brazil to develop their plans. We will all need to do more with US l\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Zebulon Carlander",
        "screen_name" : "ZCarlander",
        "indices" : [ 1, 12 ],
        "id_str" : "1322284950",
        "id" : 1322284950
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "603968816289292289",
    "geo" : { },
    "id_str" : "603975856466198528",
    "in_reply_to_user_id" : 1322284950,
    "text" : ".@ZCarlander agreement with China big and will be working w Brazil to develop their plans. We will all need to do more with US leading",
    "id" : 603975856466198528,
    "in_reply_to_status_id" : 603968816289292289,
    "created_at" : "2015-05-28 17:27:20 +0000",
    "in_reply_to_screen_name" : "ZCarlander",
    "in_reply_to_user_id_str" : "1322284950",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 603975939136090113,
  "created_at" : "2015-05-28 17:27:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zebulon Carlander",
      "screen_name" : "ZCarlander",
      "indices" : [ 3, 14 ],
      "id_str" : "1322284950",
      "id" : 1322284950
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 19, 25 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AskPOTUS",
      "indices" : [ 128, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603975903769669632",
  "text" : "RT @ZCarlander: Mr @POTUS, do you believe that big polluters like China and Brazil are doing enough on fighting climate change? #AskPOTUS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 3, 9 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AskPOTUS",
        "indices" : [ 112, 121 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "603968816289292289",
    "text" : "Mr @POTUS, do you believe that big polluters like China and Brazil are doing enough on fighting climate change? #AskPOTUS",
    "id" : 603968816289292289,
    "created_at" : "2015-05-28 16:59:21 +0000",
    "user" : {
      "name" : "Zebulon Carlander",
      "screen_name" : "ZCarlander",
      "protected" : false,
      "id_str" : "1322284950",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794586248237248512\/dB6MAEeF_normal.jpg",
      "id" : 1322284950,
      "verified" : false
    }
  },
  "id" : 603975903769669632,
  "created_at" : "2015-05-28 17:27:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Ariana Stover",
      "screen_name" : "arianastover",
      "indices" : [ 12, 25 ],
      "id_str" : "37115355",
      "id" : 37115355
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603975402063814656",
  "text" : "RT @POTUS: .@arianastover Kids instinctively understand importance of environment, impact on animals, health. Weave it into science and soc\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ariana Stover",
        "screen_name" : "arianastover",
        "indices" : [ 1, 14 ],
        "id_str" : "37115355",
        "id" : 37115355
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "603960787011543040",
    "geo" : { },
    "id_str" : "603975267422380033",
    "in_reply_to_user_id" : 37115355,
    "text" : ".@arianastover Kids instinctively understand importance of environment, impact on animals, health. Weave it into science and social studies",
    "id" : 603975267422380033,
    "in_reply_to_status_id" : 603960787011543040,
    "created_at" : "2015-05-28 17:24:59 +0000",
    "in_reply_to_screen_name" : "arianastover",
    "in_reply_to_user_id_str" : "37115355",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 603975402063814656,
  "created_at" : "2015-05-28 17:25:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Htet Wint",
      "screen_name" : "HtetWint",
      "indices" : [ 12, 21 ],
      "id_str" : "629103290",
      "id" : 629103290
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603974733827338241",
  "text" : "RT @POTUS: .@HtetWint renewable energy key, already increased solar 10x and wind 3x, now need to invest more in r&amp;d and provide regulatory \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Htet Wint",
        "screen_name" : "HtetWint",
        "indices" : [ 1, 10 ],
        "id_str" : "629103290",
        "id" : 629103290
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "603972023216312321",
    "geo" : { },
    "id_str" : "603974634510233600",
    "in_reply_to_user_id" : 629103290,
    "text" : ".@HtetWint renewable energy key, already increased solar 10x and wind 3x, now need to invest more in r&amp;d and provide regulatory incentives",
    "id" : 603974634510233600,
    "in_reply_to_status_id" : 603972023216312321,
    "created_at" : "2015-05-28 17:22:28 +0000",
    "in_reply_to_screen_name" : "HtetWint",
    "in_reply_to_user_id_str" : "629103290",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 603974733827338241,
  "created_at" : "2015-05-28 17:22:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Htet Wint",
      "screen_name" : "HtetWint",
      "indices" : [ 3, 12 ],
      "id_str" : "629103290",
      "id" : 629103290
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 14, 20 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AskPOTUS",
      "indices" : [ 109, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603974609302609921",
  "text" : "RT @HtetWint: @POTUS What role does renewable energy play as a long term solution to solving climate change? #AskPOTUS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 0, 6 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AskPOTUS",
        "indices" : [ 95, 104 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "603966058462973953",
    "geo" : { },
    "id_str" : "603972023216312321",
    "in_reply_to_user_id" : 1536791610,
    "text" : "@POTUS What role does renewable energy play as a long term solution to solving climate change? #AskPOTUS",
    "id" : 603972023216312321,
    "in_reply_to_status_id" : 603966058462973953,
    "created_at" : "2015-05-28 17:12:06 +0000",
    "in_reply_to_screen_name" : "POTUS",
    "in_reply_to_user_id_str" : "1536791610",
    "user" : {
      "name" : "Htet Wint",
      "screen_name" : "HtetWint",
      "protected" : false,
      "id_str" : "629103290",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797914585940381696\/UH1kdbx7_normal.jpg",
      "id" : 629103290,
      "verified" : false
    }
  },
  "id" : 603974609302609921,
  "created_at" : "2015-05-28 17:22:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "James L.",
      "screen_name" : "jamesthe4tress",
      "indices" : [ 13, 28 ],
      "id_str" : "312459288",
      "id" : 312459288
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603973860745154560",
  "text" : "RT @POTUS: . @Jamesthe4tress Already expanded Pell Grants and capped student loan interest rates; now want to make 2 yrs of community colle\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "James L.",
        "screen_name" : "jamesthe4tress",
        "indices" : [ 2, 17 ],
        "id_str" : "312459288",
        "id" : 312459288
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "603961385710526464",
    "geo" : { },
    "id_str" : "603973676975939585",
    "in_reply_to_user_id" : 312459288,
    "text" : ". @Jamesthe4tress Already expanded Pell Grants and capped student loan interest rates; now want to make 2 yrs of community college free.",
    "id" : 603973676975939585,
    "in_reply_to_status_id" : 603961385710526464,
    "created_at" : "2015-05-28 17:18:40 +0000",
    "in_reply_to_screen_name" : "jamesthe4tress",
    "in_reply_to_user_id_str" : "312459288",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 603973860745154560,
  "created_at" : "2015-05-28 17:19:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Cory D.",
      "screen_name" : "HLF3267",
      "indices" : [ 11, 19 ],
      "id_str" : "2295625259",
      "id" : 2295625259
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603973546608611328",
  "text" : "RT @POTUS: @HLF3267 In fact new trade deal with have the strongest enforceable environmental provisions in history, raising standards acros\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Cory D.",
        "screen_name" : "HLF3267",
        "indices" : [ 0, 8 ],
        "id_str" : "2295625259",
        "id" : 2295625259
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "603961258912653314",
    "geo" : { },
    "id_str" : "603973127383580672",
    "in_reply_to_user_id" : 2295625259,
    "text" : "@HLF3267 In fact new trade deal with have the strongest enforceable environmental provisions in history, raising standards across Asia.",
    "id" : 603973127383580672,
    "in_reply_to_status_id" : 603961258912653314,
    "created_at" : "2015-05-28 17:16:29 +0000",
    "in_reply_to_screen_name" : "HLF3267",
    "in_reply_to_user_id_str" : "2295625259",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 603973546608611328,
  "created_at" : "2015-05-28 17:18:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cory D.",
      "screen_name" : "HLF3267",
      "indices" : [ 3, 11 ],
      "id_str" : "2295625259",
      "id" : 2295625259
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 13, 19 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603973464123416576",
  "text" : "RT @HLF3267: @POTUS if climate change is so critical, why are we not imposing stricter environmental regulations through our trade deals #t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 0, 6 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "tpp",
        "indices" : [ 124, 128 ]
      }, {
        "text" : "askpotus",
        "indices" : [ 129, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "603961258912653314",
    "in_reply_to_user_id" : 1536791610,
    "text" : "@POTUS if climate change is so critical, why are we not imposing stricter environmental regulations through our trade deals #tpp #askpotus",
    "id" : 603961258912653314,
    "created_at" : "2015-05-28 16:29:19 +0000",
    "in_reply_to_screen_name" : "POTUS",
    "in_reply_to_user_id_str" : "1536791610",
    "user" : {
      "name" : "Cory D.",
      "screen_name" : "HLF3267",
      "protected" : false,
      "id_str" : "2295625259",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/601898991912095744\/UvIkbqw3_normal.jpg",
      "id" : 2295625259,
      "verified" : false
    }
  },
  "id" : 603973464123416576,
  "created_at" : "2015-05-28 17:17:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Zebulon Carlander",
      "screen_name" : "ZCarlander",
      "indices" : [ 12, 23 ],
      "id_str" : "1322284950",
      "id" : 1322284950
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603972970487410689",
  "text" : "RT @POTUS: .@ZCarlander more severe weather events lead to displacement, scarcity, stressed populations; all increase likelihood of global \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Zebulon Carlander",
        "screen_name" : "ZCarlander",
        "indices" : [ 1, 12 ],
        "id_str" : "1322284950",
        "id" : 1322284950
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "603960838026821634",
    "geo" : { },
    "id_str" : "603972926287708160",
    "in_reply_to_user_id" : 1322284950,
    "text" : ".@ZCarlander more severe weather events lead to displacement, scarcity, stressed populations; all increase likelihood of global conflict.",
    "id" : 603972926287708160,
    "in_reply_to_status_id" : 603960838026821634,
    "created_at" : "2015-05-28 17:15:41 +0000",
    "in_reply_to_screen_name" : "ZCarlander",
    "in_reply_to_user_id_str" : "1322284950",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 603972970487410689,
  "created_at" : "2015-05-28 17:15:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zebulon Carlander",
      "screen_name" : "ZCarlander",
      "indices" : [ 3, 14 ],
      "id_str" : "1322284950",
      "id" : 1322284950
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 19, 25 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603972848584130560",
  "text" : "RT @ZCarlander: Mr @POTUS, in the state of the union speech you said that climate change is a national security issue. Can you explain why \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 3, 9 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AskPOTUS",
        "indices" : [ 130, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "603960838026821634",
    "text" : "Mr @POTUS, in the state of the union speech you said that climate change is a national security issue. Can you explain why it is? #AskPOTUS",
    "id" : 603960838026821634,
    "created_at" : "2015-05-28 16:27:39 +0000",
    "user" : {
      "name" : "Zebulon Carlander",
      "screen_name" : "ZCarlander",
      "protected" : false,
      "id_str" : "1322284950",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794586248237248512\/dB6MAEeF_normal.jpg",
      "id" : 1322284950,
      "verified" : false
    }
  },
  "id" : 603972848584130560,
  "created_at" : "2015-05-28 17:15:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Nathen Vieira",
      "screen_name" : "NathenVieira",
      "indices" : [ 12, 25 ],
      "id_str" : "162090984",
      "id" : 162090984
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603972045697904640",
  "text" : "RT @POTUS: .@NathenVieira jr smith having a great season but the heart of the Cavs is Lebron. And no one can outshoot Curry - maybe Korver \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nathen Vieira",
        "screen_name" : "NathenVieira",
        "indices" : [ 1, 14 ],
        "id_str" : "162090984",
        "id" : 162090984
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "603960256067194880",
    "geo" : { },
    "id_str" : "603971948180176896",
    "in_reply_to_user_id" : 162090984,
    "text" : ".@NathenVieira jr smith having a great season but the heart of the Cavs is Lebron. And no one can outshoot Curry - maybe Korver if wide open",
    "id" : 603971948180176896,
    "in_reply_to_status_id" : 603960256067194880,
    "created_at" : "2015-05-28 17:11:48 +0000",
    "in_reply_to_screen_name" : "NathenVieira",
    "in_reply_to_user_id_str" : "162090984",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 603972045697904640,
  "created_at" : "2015-05-28 17:12:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603971397040349185",
  "text" : "RT @POTUS: @.gkermmm 2\/ after I sign agreement, Congress will have months of debate before a vote. Nothing secret about it.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "603971215372361728",
    "text" : "@.gkermmm 2\/ after I sign agreement, Congress will have months of debate before a vote. Nothing secret about it.",
    "id" : 603971215372361728,
    "created_at" : "2015-05-28 17:08:53 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 603971397040349185,
  "created_at" : "2015-05-28 17:09:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Grant Kermec",
      "screen_name" : "gkermmm",
      "indices" : [ 12, 20 ],
      "id_str" : "465076617",
      "id" : 465076617
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603971099781689344",
  "text" : "RT @POTUS: .@gkermmm 1\/ TPP is still being negotiated! But legislation requires the full text for 60 days before I sign.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Grant Kermec",
        "screen_name" : "gkermmm",
        "indices" : [ 1, 9 ],
        "id_str" : "465076617",
        "id" : 465076617
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "603959975652691968",
    "geo" : { },
    "id_str" : "603971008328957953",
    "in_reply_to_user_id" : 465076617,
    "text" : ".@gkermmm 1\/ TPP is still being negotiated! But legislation requires the full text for 60 days before I sign.",
    "id" : 603971008328957953,
    "in_reply_to_status_id" : 603959975652691968,
    "created_at" : "2015-05-28 17:08:04 +0000",
    "in_reply_to_screen_name" : "gkermmm",
    "in_reply_to_user_id_str" : "465076617",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 603971099781689344,
  "created_at" : "2015-05-28 17:08:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eric Schultz",
      "screen_name" : "Schultz44",
      "indices" : [ 3, 13 ],
      "id_str" : "1603419038",
      "id" : 1603419038
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 20, 26 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "indices" : [ 31, 39 ],
      "id_str" : "2382117350",
      "id" : 2382117350
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AskPOTUS",
      "indices" : [ 115, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603970822236151808",
  "text" : "RT @Schultz44: With @POTUS and @Deese44 at the National Hurricane Center in Miami for the President's Twitter Q\/A. #AskPOTUS http:\/\/t.co\/LE\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 5, 11 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "Brian Deese",
        "screen_name" : "Deese44",
        "indices" : [ 16, 24 ],
        "id_str" : "2382117350",
        "id" : 2382117350
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Schultz44\/status\/603969119764017153\/photo\/1",
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/LEtPfre8qr",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CGG6sNAWgAARjt4.jpg",
        "id_str" : "603969093612503040",
        "id" : 603969093612503040,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGG6sNAWgAARjt4.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 577
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 603,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 577
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 577
        } ],
        "display_url" : "pic.twitter.com\/LEtPfre8qr"
      } ],
      "hashtags" : [ {
        "text" : "AskPOTUS",
        "indices" : [ 100, 109 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "603969119764017153",
    "text" : "With @POTUS and @Deese44 at the National Hurricane Center in Miami for the President's Twitter Q\/A. #AskPOTUS http:\/\/t.co\/LEtPfre8qr",
    "id" : 603969119764017153,
    "created_at" : "2015-05-28 17:00:34 +0000",
    "user" : {
      "name" : "Eric Schultz",
      "screen_name" : "Schultz44",
      "protected" : false,
      "id_str" : "1603419038",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/491941155815161856\/u0IdexM6_normal.jpeg",
      "id" : 1603419038,
      "verified" : true
    }
  },
  "id" : 603970822236151808,
  "created_at" : "2015-05-28 17:07:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Derrick Neuner",
      "screen_name" : "drock89",
      "indices" : [ 12, 20 ],
      "id_str" : "28640463",
      "id" : 28640463
    }, {
      "name" : "Pope Francis",
      "screen_name" : "Pontifex",
      "indices" : [ 24, 33 ],
      "id_str" : "500704345",
      "id" : 500704345
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603970523538784256",
  "text" : "RT @POTUS: .@drock89 as @Pontifex and other religious leaders have stated we have a moral obligation to the most vulnerable and the next ge\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Derrick Neuner",
        "screen_name" : "drock89",
        "indices" : [ 1, 9 ],
        "id_str" : "28640463",
        "id" : 28640463
      }, {
        "name" : "Pope Francis",
        "screen_name" : "Pontifex",
        "indices" : [ 13, 22 ],
        "id_str" : "500704345",
        "id" : 500704345
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "603959452337770497",
    "geo" : { },
    "id_str" : "603970422636290048",
    "in_reply_to_user_id" : 28640463,
    "text" : ".@drock89 as @Pontifex and other religious leaders have stated we have a moral obligation to the most vulnerable and the next generation.",
    "id" : 603970422636290048,
    "in_reply_to_status_id" : 603959452337770497,
    "created_at" : "2015-05-28 17:05:44 +0000",
    "in_reply_to_screen_name" : "drock89",
    "in_reply_to_user_id_str" : "28640463",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 603970523538784256,
  "created_at" : "2015-05-28 17:06:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Ben Alexander",
      "screen_name" : "BigBennyFL",
      "indices" : [ 12, 23 ],
      "id_str" : "1007173664",
      "id" : 1007173664
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603970016845914112",
  "text" : "RT @POTUS: .@BigBennyFL 3\/ already rejected Shell's original proposal as inadequate which shows we're serious.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ben Alexander",
        "screen_name" : "BigBennyFL",
        "indices" : [ 1, 12 ],
        "id_str" : "1007173664",
        "id" : 1007173664
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "603959664385064961",
    "geo" : { },
    "id_str" : "603969986730708992",
    "in_reply_to_user_id" : 1007173664,
    "text" : ".@BigBennyFL 3\/ already rejected Shell's original proposal as inadequate which shows we're serious.",
    "id" : 603969986730708992,
    "in_reply_to_status_id" : 603959664385064961,
    "created_at" : "2015-05-28 17:04:00 +0000",
    "in_reply_to_screen_name" : "BigBennyFL",
    "in_reply_to_user_id_str" : "1007173664",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 603970016845914112,
  "created_at" : "2015-05-28 17:04:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Ben Alexander",
      "screen_name" : "BigBennyFL",
      "indices" : [ 12, 23 ],
      "id_str" : "1007173664",
      "id" : 1007173664
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603969755595210753",
  "text" : "RT @POTUS: .@BigBennyFL 2\/ But since we can't prevent oil exploration completely in region we're setting the highest possible standards",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ben Alexander",
        "screen_name" : "BigBennyFL",
        "indices" : [ 1, 12 ],
        "id_str" : "1007173664",
        "id" : 1007173664
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "603959664385064961",
    "geo" : { },
    "id_str" : "603969716261036032",
    "in_reply_to_user_id" : 1007173664,
    "text" : ".@BigBennyFL 2\/ But since we can't prevent oil exploration completely in region we're setting the highest possible standards",
    "id" : 603969716261036032,
    "in_reply_to_status_id" : 603959664385064961,
    "created_at" : "2015-05-28 17:02:56 +0000",
    "in_reply_to_screen_name" : "BigBennyFL",
    "in_reply_to_user_id_str" : "1007173664",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 603969755595210753,
  "created_at" : "2015-05-28 17:03:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Ben Alexander",
      "screen_name" : "BigBennyFL",
      "indices" : [ 11, 22 ],
      "id_str" : "1007173664",
      "id" : 1007173664
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603969670266363904",
  "text" : "RT @POTUS: @BigBennyFL 1\/ We've shut off drilling in the most sensitive arctic areas, including Bristol Bay.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ben Alexander",
        "screen_name" : "BigBennyFL",
        "indices" : [ 0, 11 ],
        "id_str" : "1007173664",
        "id" : 1007173664
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "603959664385064961",
    "geo" : { },
    "id_str" : "603968878058676225",
    "in_reply_to_user_id" : 1007173664,
    "text" : "@BigBennyFL 1\/ We've shut off drilling in the most sensitive arctic areas, including Bristol Bay.",
    "id" : 603968878058676225,
    "in_reply_to_status_id" : 603959664385064961,
    "created_at" : "2015-05-28 16:59:36 +0000",
    "in_reply_to_screen_name" : "BigBennyFL",
    "in_reply_to_user_id_str" : "1007173664",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 603969670266363904,
  "created_at" : "2015-05-28 17:02:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Caleb",
      "screen_name" : "calebmegajew",
      "indices" : [ 12, 25 ],
      "id_str" : "360324412",
      "id" : 360324412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603968104100667393",
  "text" : "RT @POTUS: .@calebmegajew the science is overwhelming but what will move Congress will be public opinion. Your voices will make them open t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Caleb",
        "screen_name" : "calebmegajew",
        "indices" : [ 1, 14 ],
        "id_str" : "360324412",
        "id" : 360324412
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "603959889497559040",
    "geo" : { },
    "id_str" : "603968065240313859",
    "in_reply_to_user_id" : 360324412,
    "text" : ".@calebmegajew the science is overwhelming but what will move Congress will be public opinion. Your voices will make them open to facts.",
    "id" : 603968065240313859,
    "in_reply_to_status_id" : 603959889497559040,
    "created_at" : "2015-05-28 16:56:22 +0000",
    "in_reply_to_screen_name" : "calebmegajew",
    "in_reply_to_user_id_str" : "360324412",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 603968104100667393,
  "created_at" : "2015-05-28 16:56:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/POTUS\/status\/603966058462973953\/photo\/1",
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/5KrIb5jL6S",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGG32TMUMAAQWeg.jpg",
      "id_str" : "603965968537104384",
      "id" : 603965968537104384,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGG32TMUMAAQWeg.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/5KrIb5jL6S"
    } ],
    "hashtags" : [ {
      "text" : "AskPOTUS",
      "indices" : [ 76, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603966210368221184",
  "text" : "RT @POTUS: Ready to answer your questions on climate change. Let's do this! #AskPOTUS http:\/\/t.co\/5KrIb5jL6S",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/POTUS\/status\/603966058462973953\/photo\/1",
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/5KrIb5jL6S",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CGG32TMUMAAQWeg.jpg",
        "id_str" : "603965968537104384",
        "id" : 603965968537104384,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGG32TMUMAAQWeg.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/5KrIb5jL6S"
      } ],
      "hashtags" : [ {
        "text" : "AskPOTUS",
        "indices" : [ 65, 74 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "603966058462973953",
    "text" : "Ready to answer your questions on climate change. Let's do this! #AskPOTUS http:\/\/t.co\/5KrIb5jL6S",
    "id" : 603966058462973953,
    "created_at" : "2015-05-28 16:48:24 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 603966210368221184,
  "created_at" : "2015-05-28 16:49:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 46, 52 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/603965134873075712\/photo\/1",
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/fcfUnwUNQA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGG3CDTWgAATtfO.jpg",
      "id_str" : "603965070918451200",
      "id" : 603965070918451200,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGG3CDTWgAATtfO.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/fcfUnwUNQA"
    } ],
    "hashtags" : [ {
      "text" : "AskPOTUS",
      "indices" : [ 87, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603965134873075712",
  "text" : "Keep your climate change questions coming for @POTUS. He'll start answering at 1pm ET. #AskPOTUS http:\/\/t.co\/fcfUnwUNQA",
  "id" : 603965134873075712,
  "created_at" : "2015-05-28 16:44:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 34, 40 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AskPOTUS",
      "indices" : [ 46, 55 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/q1evkGazkL",
      "expanded_url" : "https:\/\/twitter.com\/POTUS\/status\/603959253334822913",
      "display_url" : "twitter.com\/POTUS\/status\/6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "603960909476864001",
  "text" : "Have climate change questions for @POTUS? Use #AskPOTUS and he'll start answering at 1pm ET. https:\/\/t.co\/q1evkGazkL",
  "id" : 603960909476864001,
  "created_at" : "2015-05-28 16:27:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603959315838402560",
  "text" : "RT @POTUS: Just got a hurricane preparedness briefing in Miami. Acting on climate change is critical. Got climate Qs? I'll answer at 1pm ET\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AskPOTUS",
        "indices" : [ 130, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "603959253334822913",
    "text" : "Just got a hurricane preparedness briefing in Miami. Acting on climate change is critical. Got climate Qs? I'll answer at 1pm ET. #AskPOTUS",
    "id" : 603959253334822913,
    "created_at" : "2015-05-28 16:21:21 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 603959315838402560,
  "created_at" : "2015-05-28 16:21:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 25, 31 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 107, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/lU2sqP1U2v",
      "expanded_url" : "http:\/\/go.wh.gov\/LLZ1Ag",
      "display_url" : "go.wh.gov\/LLZ1Ag"
    } ]
  },
  "geo" : { },
  "id_str" : "603946029071802369",
  "text" : "Worth a read: Here\u2019s why @POTUS is in Miami for a hurricane preparedness briefing \u2192 http:\/\/t.co\/lU2sqP1U2v #ActOnClimate",
  "id" : 603946029071802369,
  "created_at" : "2015-05-28 15:28:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    }, {
      "name" : "Miami Herald",
      "screen_name" : "MiamiHerald",
      "indices" : [ 54, 66 ],
      "id_str" : "14085040",
      "id" : 14085040
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Simas44\/status\/603936621424156672\/photo\/1",
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/hq2eFMGGYA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGGdHx_W0AA9H-l.jpg",
      "id_str" : "603936582048075776",
      "id" : 603936582048075776,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGGdHx_W0AA9H-l.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/hq2eFMGGYA"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/Simas44\/status\/603936621424156672\/photo\/1",
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/hq2eFMGGYA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGGdHx0WEAEVYha.jpg",
      "id_str" : "603936582001889281",
      "id" : 603936582001889281,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGGdHx0WEAEVYha.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/hq2eFMGGYA"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/Simas44\/status\/603936621424156672\/photo\/1",
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/hq2eFMGGYA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGGdHyGW8AA7nOe.jpg",
      "id_str" : "603936582077444096",
      "id" : 603936582077444096,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGGdHyGW8AA7nOe.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/hq2eFMGGYA"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/Simas44\/status\/603936621424156672\/photo\/1",
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/hq2eFMGGYA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGGdHyUWoAMGffL.jpg",
      "id_str" : "603936582136143875",
      "id" : 603936582136143875,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGGdHyUWoAMGffL.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/hq2eFMGGYA"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603938857491501056",
  "text" : "RT @Simas44: Amazing clips of hurricane coverage from @MiamiHerald at the National Hurricane Center. http:\/\/t.co\/hq2eFMGGYA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Miami Herald",
        "screen_name" : "MiamiHerald",
        "indices" : [ 41, 53 ],
        "id_str" : "14085040",
        "id" : 14085040
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Simas44\/status\/603936621424156672\/photo\/1",
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/hq2eFMGGYA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CGGdHx_W0AA9H-l.jpg",
        "id_str" : "603936582048075776",
        "id" : 603936582048075776,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGGdHx_W0AA9H-l.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/hq2eFMGGYA"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/Simas44\/status\/603936621424156672\/photo\/1",
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/hq2eFMGGYA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CGGdHx0WEAEVYha.jpg",
        "id_str" : "603936582001889281",
        "id" : 603936582001889281,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGGdHx0WEAEVYha.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/hq2eFMGGYA"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/Simas44\/status\/603936621424156672\/photo\/1",
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/hq2eFMGGYA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CGGdHyGW8AA7nOe.jpg",
        "id_str" : "603936582077444096",
        "id" : 603936582077444096,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGGdHyGW8AA7nOe.jpg",
        "sizes" : [ {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        } ],
        "display_url" : "pic.twitter.com\/hq2eFMGGYA"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/Simas44\/status\/603936621424156672\/photo\/1",
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/hq2eFMGGYA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CGGdHyUWoAMGffL.jpg",
        "id_str" : "603936582136143875",
        "id" : 603936582136143875,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGGdHyUWoAMGffL.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/hq2eFMGGYA"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "603936621424156672",
    "text" : "Amazing clips of hurricane coverage from @MiamiHerald at the National Hurricane Center. http:\/\/t.co\/hq2eFMGGYA",
    "id" : 603936621424156672,
    "created_at" : "2015-05-28 14:51:25 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 603938857491501056,
  "created_at" : "2015-05-28 15:00:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "indices" : [ 3, 10 ],
      "id_str" : "44783853",
      "id" : 44783853
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHCOA",
      "indices" : [ 31, 37 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/iJ9ZJqyVwS",
      "expanded_url" : "http:\/\/bit.ly\/1IUFx4Z",
      "display_url" : "bit.ly\/1IUFx4Z"
    } ]
  },
  "geo" : { },
  "id_str" : "603930555508457473",
  "text" : "RT @HHSGov: SAVE THE DATE: The #WHCOA will be on July 13, 2015. Find out how you can get involved \u2192 http:\/\/t.co\/iJ9ZJqyVwS http:\/\/t.co\/DTOQ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/HHSGov\/status\/603909842290413568\/photo\/1",
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/DTOQU8K2Vr",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CGGEzUSUgAAT9jX.jpg",
        "id_str" : "603909842198102016",
        "id" : 603909842198102016,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGGEzUSUgAAT9jX.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 320,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 320,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/DTOQU8K2Vr"
      } ],
      "hashtags" : [ {
        "text" : "WHCOA",
        "indices" : [ 19, 25 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/iJ9ZJqyVwS",
        "expanded_url" : "http:\/\/bit.ly\/1IUFx4Z",
        "display_url" : "bit.ly\/1IUFx4Z"
      } ]
    },
    "geo" : { },
    "id_str" : "603909842290413568",
    "text" : "SAVE THE DATE: The #WHCOA will be on July 13, 2015. Find out how you can get involved \u2192 http:\/\/t.co\/iJ9ZJqyVwS http:\/\/t.co\/DTOQU8K2Vr",
    "id" : 603909842290413568,
    "created_at" : "2015-05-28 13:05:01 +0000",
    "user" : {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "protected" : false,
      "id_str" : "44783853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567350542326718464\/FXOsgyA7_normal.jpeg",
      "id" : 44783853,
      "verified" : true
    }
  },
  "id" : 603930555508457473,
  "created_at" : "2015-05-28 14:27:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "indices" : [ 3, 13 ],
      "id_str" : "1613223313",
      "id" : 1613223313
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHCOA",
      "indices" : [ 126, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/fmYgjGG6VA",
      "expanded_url" : "http:\/\/bit.ly\/1IUFx4Z",
      "display_url" : "bit.ly\/1IUFx4Z"
    } ]
  },
  "geo" : { },
  "id_str" : "603915396329136128",
  "text" : "RT @Cecilia44: The 2015 White House Conference on Aging will be on July 13! Have you shared your story?http:\/\/t.co\/fmYgjGG6VA #WHCOA http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Cecilia44\/status\/603911935948632065\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/t1fteoFFhm",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CGGGtIeUIAIQKp5.jpg",
        "id_str" : "603911934971224066",
        "id" : 603911934971224066,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGGGtIeUIAIQKp5.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1406
        }, {
          "h" : 186,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 559,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 328,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/t1fteoFFhm"
      } ],
      "hashtags" : [ {
        "text" : "WHCOA",
        "indices" : [ 111, 117 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/fmYgjGG6VA",
        "expanded_url" : "http:\/\/bit.ly\/1IUFx4Z",
        "display_url" : "bit.ly\/1IUFx4Z"
      } ]
    },
    "geo" : { },
    "id_str" : "603911935948632065",
    "text" : "The 2015 White House Conference on Aging will be on July 13! Have you shared your story?http:\/\/t.co\/fmYgjGG6VA #WHCOA http:\/\/t.co\/t1fteoFFhm",
    "id" : 603911935948632065,
    "created_at" : "2015-05-28 13:13:20 +0000",
    "user" : {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "protected" : false,
      "id_str" : "1613223313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000172019215\/ed65eda76f51213f91b33edbaa62054c_normal.jpeg",
      "id" : 1613223313,
      "verified" : true
    }
  },
  "id" : 603915396329136128,
  "created_at" : "2015-05-28 13:27:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CleanWaterRules",
      "indices" : [ 95, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/TSH5emm79k",
      "expanded_url" : "http:\/\/go.wh.gov\/ht23hX",
      "display_url" : "go.wh.gov\/ht23hX"
    }, {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/pgB07cyXtF",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/2de5f8d1-3681-40be-82e0-553398acb631",
      "display_url" : "amp.twimg.com\/v\/2de5f8d1-368\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "603712455185858560",
  "text" : "Look who supports today's new steps to protect America's water sources! http:\/\/t.co\/TSH5emm79k #CleanWaterRules\nhttps:\/\/t.co\/pgB07cyXtF",
  "id" : 603712455185858560,
  "created_at" : "2015-05-28 00:00:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 30, 36 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 38, 45 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/603671769837338625\/photo\/1",
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/A9FswXfBCh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGCsKAcUgAARJi2.jpg",
      "id_str" : "603671637985099776",
      "id" : 603671637985099776,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGCsKAcUgAARJi2.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1867,
        "resize" : "fit",
        "w" : 2800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/A9FswXfBCh"
    } ],
    "hashtags" : [ {
      "text" : "HuggerInChief",
      "indices" : [ 4, 18 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/pDAkZtwbDS",
      "expanded_url" : "http:\/\/go.wh.gov\/HuggerInChief",
      "display_url" : "go.wh.gov\/HuggerInChief"
    } ]
  },
  "geo" : { },
  "id_str" : "603671769837338625",
  "text" : "The #HuggerInChief? Move over @POTUS. @FLOTUS takes the title: http:\/\/t.co\/pDAkZtwbDS http:\/\/t.co\/A9FswXfBCh",
  "id" : 603671769837338625,
  "created_at" : "2015-05-27 21:19:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USTR",
      "screen_name" : "USTradeRep",
      "indices" : [ 3, 14 ],
      "id_str" : "44615672",
      "id" : 44615672
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StandingUpForTheEnvironment",
      "indices" : [ 105, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/hQdPv4fUqS",
      "expanded_url" : "https:\/\/ustr.gov\/about-us\/policy-offices\/press-office\/reports-and-publications\/2015\/standing-environment-trade",
      "display_url" : "ustr.gov\/about-us\/polic\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "603663109010681856",
  "text" : "RT @USTradeRep: Expanded ivory demand has led to a dramatic uptick in poaching \u2192 https:\/\/t.co\/hQdPv4fUqS #StandingUpForTheEnvironment http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/USTradeRep\/status\/601084693950390272\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/Twhc0UWeyB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CFd7VFzWgAA-Hrn.png",
        "id_str" : "601084677542281216",
        "id" : 601084677542281216,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFd7VFzWgAA-Hrn.png",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/Twhc0UWeyB"
      } ],
      "hashtags" : [ {
        "text" : "StandingUpForTheEnvironment",
        "indices" : [ 89, 117 ]
      } ],
      "urls" : [ {
        "indices" : [ 65, 88 ],
        "url" : "https:\/\/t.co\/hQdPv4fUqS",
        "expanded_url" : "https:\/\/ustr.gov\/about-us\/policy-offices\/press-office\/reports-and-publications\/2015\/standing-environment-trade",
        "display_url" : "ustr.gov\/about-us\/polic\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "601084693950390272",
    "text" : "Expanded ivory demand has led to a dramatic uptick in poaching \u2192 https:\/\/t.co\/hQdPv4fUqS #StandingUpForTheEnvironment http:\/\/t.co\/Twhc0UWeyB",
    "id" : 601084693950390272,
    "created_at" : "2015-05-20 17:58:53 +0000",
    "user" : {
      "name" : "USTR",
      "screen_name" : "USTradeRep",
      "protected" : false,
      "id_str" : "44615672",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662636758509596672\/O-ShXHZB_normal.png",
      "id" : 44615672,
      "verified" : true
    }
  },
  "id" : 603663109010681856,
  "created_at" : "2015-05-27 20:44:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "indices" : [ 14, 22 ],
      "id_str" : "1530850933",
      "id" : 1530850933
    }, {
      "name" : "USACE HQ",
      "screen_name" : "USACEHQ",
      "indices" : [ 27, 35 ],
      "id_str" : "161329769",
      "id" : 161329769
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/603638495668731904\/photo\/1",
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/65axZyTiIP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGCN-SmVEAAuSuJ.jpg",
      "id_str" : "603638451351654400",
      "id" : 603638451351654400,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGCN-SmVEAAuSuJ.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/65axZyTiIP"
    } ],
    "hashtags" : [ {
      "text" : "CleanWaterRules",
      "indices" : [ 51, 67 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/fOI342oMxJ",
      "expanded_url" : "http:\/\/go.wh.gov\/wREUWt",
      "display_url" : "go.wh.gov\/wREUWt"
    } ]
  },
  "geo" : { },
  "id_str" : "603638495668731904",
  "text" : "Worth a read: @GinaEPA and @USACEHQ on why we need #CleanWaterRules \u2192 http:\/\/t.co\/fOI342oMxJ http:\/\/t.co\/65axZyTiIP",
  "id" : 603638495668731904,
  "created_at" : "2015-05-27 19:06:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 23, 29 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/603617464463859712\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/DZF0SM0lhb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGB63waVIAMTldJ.jpg",
      "id_str" : "603617448374378499",
      "id" : 603617448374378499,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGB63waVIAMTldJ.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/DZF0SM0lhb"
    } ],
    "hashtags" : [ {
      "text" : "CleanWaterRules",
      "indices" : [ 82, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603617464463859712",
  "text" : "RT to spread the word: @POTUS is taking steps to protect America's water sources. #CleanWaterRules http:\/\/t.co\/DZF0SM0lhb",
  "id" : 603617464463859712,
  "created_at" : "2015-05-27 17:43:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "indices" : [ 3, 11 ],
      "id_str" : "2382117350",
      "id" : 2382117350
    }, {
      "name" : "Better Buildings",
      "screen_name" : "BetterBldgsDOE",
      "indices" : [ 25, 40 ],
      "id_str" : "1340140518",
      "id" : 1340140518
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 115, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603592760818532352",
  "text" : "RT @Deese44: Great to be @BetterBldgsDOE this AM. Energy efficiency is a win-win-win: creates jobs, saves $, helps #ActOnClimate https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Better Buildings",
        "screen_name" : "BetterBldgsDOE",
        "indices" : [ 12, 27 ],
        "id_str" : "1340140518",
        "id" : 1340140518
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 102, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/XdZI6lNr6v",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/blog\/2015\/05\/27\/4-years-building-energy-efficiency-across-america",
        "display_url" : "whitehouse.gov\/blog\/2015\/05\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "603589648863076353",
    "text" : "Great to be @BetterBldgsDOE this AM. Energy efficiency is a win-win-win: creates jobs, saves $, helps #ActOnClimate https:\/\/t.co\/XdZI6lNr6v",
    "id" : 603589648863076353,
    "created_at" : "2015-05-27 15:52:41 +0000",
    "user" : {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "protected" : false,
      "id_str" : "2382117350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656551411145027584\/ArrSlGUP_normal.jpg",
      "id" : 2382117350,
      "verified" : true
    }
  },
  "id" : 603592760818532352,
  "created_at" : "2015-05-27 16:05:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 99, 105 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/603586189690535937\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/qVIPNoIDz2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGBeZsiWIAAUkLX.png",
      "id_str" : "603586145612603392",
      "id" : 603586145612603392,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGBeZsiWIAAUkLX.png",
      "sizes" : [ {
        "h" : 370,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 734
      }, {
        "h" : 210,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 734
      } ],
      "display_url" : "pic.twitter.com\/qVIPNoIDz2"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603586189690535937",
  "text" : "\"With today\u2019s rule, we take another step towards protecting the waters that belong to all of us.\" \u2014@POTUS: http:\/\/t.co\/qVIPNoIDz2",
  "id" : 603586189690535937,
  "created_at" : "2015-05-27 15:38:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "indices" : [ 3, 11 ],
      "id_str" : "1530850933",
      "id" : 1530850933
    }, {
      "name" : "USACE HQ",
      "screen_name" : "USACEHQ",
      "indices" : [ 109, 117 ],
      "id_str" : "161329769",
      "id" : 161329769
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CleanWaterRules",
      "indices" : [ 118, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603579049655566337",
  "text" : "RT @GinaEPA: Big news: Clean Water Rule now finalized. Great news for our health, environment &amp; economy! @USACEHQ #CleanWaterRules http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "USACE HQ",
        "screen_name" : "USACEHQ",
        "indices" : [ 96, 104 ],
        "id_str" : "161329769",
        "id" : 161329769
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CleanWaterRules",
        "indices" : [ 105, 121 ]
      } ],
      "urls" : [ {
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/BdB2fDMaah",
        "expanded_url" : "http:\/\/blog.epa.gov\/blog\/2015\/05\/reasons-we-need-the-clean-water-rule\/",
        "display_url" : "blog.epa.gov\/blog\/2015\/05\/r\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "603566060521021440",
    "text" : "Big news: Clean Water Rule now finalized. Great news for our health, environment &amp; economy! @USACEHQ #CleanWaterRules http:\/\/t.co\/BdB2fDMaah",
    "id" : 603566060521021440,
    "created_at" : "2015-05-27 14:18:57 +0000",
    "user" : {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "protected" : false,
      "id_str" : "1530850933",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/632229333130604548\/Bb4I34DU_normal.jpg",
      "id" : 1530850933,
      "verified" : true
    }
  },
  "id" : 603579049655566337,
  "created_at" : "2015-05-27 15:10:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. EPA",
      "screen_name" : "EPA",
      "indices" : [ 3, 7 ],
      "id_str" : "14615871",
      "id" : 14615871
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/k58D7iTOXZ",
      "expanded_url" : "https:\/\/youtu.be\/gFyf0XseWrI",
      "display_url" : "youtu.be\/gFyf0XseWrI"
    }, {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/CLM6JSQq2L",
      "expanded_url" : "http:\/\/go.usa.gov\/39ANk",
      "display_url" : "go.usa.gov\/39ANk"
    } ]
  },
  "geo" : { },
  "id_str" : "603572345295532032",
  "text" : "RT @EPA: BREAKING NEWS: Our Clean Water Rule has been finalized. https:\/\/t.co\/k58D7iTOXZ Learn more: http:\/\/t.co\/CLM6JSQq2L. #CleanWaterRul\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CleanWaterRules",
        "indices" : [ 116, 132 ]
      } ],
      "urls" : [ {
        "indices" : [ 56, 79 ],
        "url" : "https:\/\/t.co\/k58D7iTOXZ",
        "expanded_url" : "https:\/\/youtu.be\/gFyf0XseWrI",
        "display_url" : "youtu.be\/gFyf0XseWrI"
      }, {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/CLM6JSQq2L",
        "expanded_url" : "http:\/\/go.usa.gov\/39ANk",
        "display_url" : "go.usa.gov\/39ANk"
      } ]
    },
    "geo" : { },
    "id_str" : "603568668925173760",
    "text" : "BREAKING NEWS: Our Clean Water Rule has been finalized. https:\/\/t.co\/k58D7iTOXZ Learn more: http:\/\/t.co\/CLM6JSQq2L. #CleanWaterRules",
    "id" : 603568668925173760,
    "created_at" : "2015-05-27 14:29:19 +0000",
    "user" : {
      "name" : "U.S. EPA",
      "screen_name" : "EPA",
      "protected" : false,
      "id_str" : "14615871",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/632228259879628800\/-gvVhzPn_normal.png",
      "id" : 14615871,
      "verified" : true
    }
  },
  "id" : 603572345295532032,
  "created_at" : "2015-05-27 14:43:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NYU Wagner",
      "screen_name" : "NYUWagner",
      "indices" : [ 104, 114 ],
      "id_str" : "14054949",
      "id" : 14054949
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/2M0gw65iUT",
      "expanded_url" : "http:\/\/go.wh.gov\/d4Aqj2",
      "display_url" : "go.wh.gov\/d4Aqj2"
    } ]
  },
  "geo" : { },
  "id_str" : "603357931137069056",
  "text" : "\"Cynicism is easy. Anyone can do it. Change is hard. That takes us.\" \u2014Chief Speechwriter Cody Keenan at @NYUWagner: http:\/\/t.co\/2M0gw65iUT",
  "id" : 603357931137069056,
  "created_at" : "2015-05-27 00:31:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603353310423285760",
  "text" : "RT @petesouza: Pres Obama and VP Biden w 97-yr-old Vivian Bailey, who raises money so kids from local school can take field trips http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/petesouza\/status\/603347929621999616\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/bU9Kyd1bYm",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CF-FvdcWgAArASg.jpg",
        "id_str" : "603347925494824960",
        "id" : 603347925494824960,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CF-FvdcWgAArASg.jpg",
        "sizes" : [ {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/bU9Kyd1bYm"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "603347929621999616",
    "text" : "Pres Obama and VP Biden w 97-yr-old Vivian Bailey, who raises money so kids from local school can take field trips http:\/\/t.co\/bU9Kyd1bYm",
    "id" : 603347929621999616,
    "created_at" : "2015-05-26 23:52:10 +0000",
    "user" : {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "protected" : false,
      "id_str" : "18215973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771916869808844800\/7d_poH48_normal.jpg",
      "id" : 18215973,
      "verified" : true
    }
  },
  "id" : 603353310423285760,
  "created_at" : "2015-05-27 00:13:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Kelly",
      "screen_name" : "StationCDRKelly",
      "indices" : [ 47, 63 ],
      "id_str" : "65647594",
      "id" : 65647594
    }, {
      "name" : "Intl. Space Station",
      "screen_name" : "Space_Station",
      "indices" : [ 93, 107 ],
      "id_str" : "1451773004",
      "id" : 1451773004
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/603331416580038658\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/IoIRYU51iw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CF92s4mWgAASa0X.jpg",
      "id_str" : "603331388570501120",
      "id" : 603331388570501120,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CF92s4mWgAASa0X.jpg",
      "sizes" : [ {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 399,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1331,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 681,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/IoIRYU51iw"
    } ],
    "hashtags" : [ {
      "text" : "YearInSpace",
      "indices" : [ 26, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603331416580038658",
  "text" : "Thanks for the incredible #YearInSpace photos, @StationCDRKelly! Great view of D.C. from the @Space_Station. http:\/\/t.co\/IoIRYU51iw",
  "id" : 603331416580038658,
  "created_at" : "2015-05-26 22:46:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Oberlin College",
      "screen_name" : "oberlincollege",
      "indices" : [ 77, 92 ],
      "id_str" : "225052010",
      "id" : 225052010
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/FGcWSDfZNo",
      "expanded_url" : "http:\/\/go.wh.gov\/UDrr1e",
      "display_url" : "go.wh.gov\/UDrr1e"
    } ]
  },
  "geo" : { },
  "id_str" : "603278458505043969",
  "text" : "RT @FLOTUS: \u201CPlay your part in our great American story.\u201D \u2014The First Lady to @OberlinCollege graduates: http:\/\/t.co\/FGcWSDfZNo http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Oberlin College",
        "screen_name" : "oberlincollege",
        "indices" : [ 65, 80 ],
        "id_str" : "225052010",
        "id" : 225052010
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/603278197132668928\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/RXgpCZUc0A",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CF9BjWyXIAA4Jdb.jpg",
        "id_str" : "603272950758973440",
        "id" : 603272950758973440,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CF9BjWyXIAA4Jdb.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1866,
          "resize" : "fit",
          "w" : 2800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/RXgpCZUc0A"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/FGcWSDfZNo",
        "expanded_url" : "http:\/\/go.wh.gov\/UDrr1e",
        "display_url" : "go.wh.gov\/UDrr1e"
      } ]
    },
    "geo" : { },
    "id_str" : "603278197132668928",
    "text" : "\u201CPlay your part in our great American story.\u201D \u2014The First Lady to @OberlinCollege graduates: http:\/\/t.co\/FGcWSDfZNo http:\/\/t.co\/RXgpCZUc0A",
    "id" : 603278197132668928,
    "created_at" : "2015-05-26 19:15:05 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 603278458505043969,
  "created_at" : "2015-05-26 19:16:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/603243883124887552\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/LOslxQiIgd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CF8mBRsWoAAJxTG.jpg",
      "id_str" : "603242678462095360",
      "id" : 603242678462095360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CF8mBRsWoAAJxTG.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/LOslxQiIgd"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/hTKHwdxQ8w",
      "expanded_url" : "http:\/\/go.wh.gov\/p5ana3",
      "display_url" : "go.wh.gov\/p5ana3"
    } ]
  },
  "geo" : { },
  "id_str" : "603243883124887552",
  "text" : "Sally Ride would've been 64 today.\nHere's how she inspired us to reach for the stars \u2192 http:\/\/t.co\/hTKHwdxQ8w http:\/\/t.co\/LOslxQiIgd",
  "id" : 603243883124887552,
  "created_at" : "2015-05-26 16:58:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Kelly",
      "screen_name" : "StationCDRKelly",
      "indices" : [ 3, 19 ],
      "id_str" : "65647594",
      "id" : 65647594
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SallyRide",
      "indices" : [ 50, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603238923834400769",
  "text" : "RT @StationCDRKelly: Remembering former colleague #SallyRide on her birthday. 1st American woman to fly into space. You inspired many. http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/StationCDRKelly\/status\/603200827994419200\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/WZEphK24vV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CF7_9P9UIAAPbSQ.jpg",
        "id_str" : "603200827835031552",
        "id" : 603200827835031552,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CF7_9P9UIAAPbSQ.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/WZEphK24vV"
      } ],
      "hashtags" : [ {
        "text" : "SallyRide",
        "indices" : [ 29, 39 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "603200827994419200",
    "text" : "Remembering former colleague #SallyRide on her birthday. 1st American woman to fly into space. You inspired many. http:\/\/t.co\/WZEphK24vV",
    "id" : 603200827994419200,
    "created_at" : "2015-05-26 14:07:38 +0000",
    "user" : {
      "name" : "Scott Kelly",
      "screen_name" : "StationCDRKelly",
      "protected" : false,
      "id_str" : "65647594",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/558447158597136385\/P9TpCaRn_normal.jpeg",
      "id" : 65647594,
      "verified" : true
    }
  },
  "id" : 603238923834400769,
  "created_at" : "2015-05-26 16:39:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 3, 11 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    }, {
      "name" : "The Daily Show",
      "screen_name" : "TheDailyShow",
      "indices" : [ 80, 93 ],
      "id_str" : "158414847",
      "id" : 158414847
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603228032447438849",
  "text" : "RT @DrBiden: I love a good joke but good deeds are even better. Jon Stewart and @TheDailyShow step up for our Veterans \u2192 http:\/\/t.co\/4YU2gX\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Daily Show",
        "screen_name" : "TheDailyShow",
        "indices" : [ 67, 80 ],
        "id_str" : "158414847",
        "id" : 158414847
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/4YU2gXTm5s",
        "expanded_url" : "http:\/\/nyti.ms\/1HFqBun",
        "display_url" : "nyti.ms\/1HFqBun"
      } ]
    },
    "geo" : { },
    "id_str" : "603225675231731712",
    "text" : "I love a good joke but good deeds are even better. Jon Stewart and @TheDailyShow step up for our Veterans \u2192 http:\/\/t.co\/4YU2gXTm5s \u2013Jill",
    "id" : 603225675231731712,
    "created_at" : "2015-05-26 15:46:23 +0000",
    "user" : {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "protected" : false,
      "id_str" : "1281405877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608687663034474496\/wvzVG_yt_normal.jpg",
      "id" : 1281405877,
      "verified" : true
    }
  },
  "id" : 603228032447438849,
  "created_at" : "2015-05-26 15:55:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 13, 19 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "603210165542871040",
  "text" : "RT @vj44: As @POTUS says, real change happens outside DC. Thx to state &amp; local officials who are creating opportunity for all: http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 3, 9 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 121, 143 ],
        "url" : "http:\/\/t.co\/4a82pojMTS",
        "expanded_url" : "http:\/\/usat.ly\/1HsNrzP",
        "display_url" : "usat.ly\/1HsNrzP"
      } ]
    },
    "geo" : { },
    "id_str" : "603202802219880448",
    "text" : "As @POTUS says, real change happens outside DC. Thx to state &amp; local officials who are creating opportunity for all: http:\/\/t.co\/4a82pojMTS",
    "id" : 603202802219880448,
    "created_at" : "2015-05-26 14:15:29 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 603210165542871040,
  "created_at" : "2015-05-26 14:44:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/603199756429557761\/photo\/1",
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/nSYg5ij4vj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CF7-4P7WAAAtLi4.jpg",
      "id_str" : "603199642415792128",
      "id" : 603199642415792128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CF7-4P7WAAAtLi4.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1022
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 401,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1022
      } ],
      "display_url" : "pic.twitter.com\/nSYg5ij4vj"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 64, 77 ]
    }, {
      "text" : "LeadOnLeave",
      "indices" : [ 84, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/VE5KKijqro",
      "expanded_url" : "http:\/\/usat.ly\/1HsNrzP",
      "display_url" : "usat.ly\/1HsNrzP"
    } ]
  },
  "geo" : { },
  "id_str" : "603199756429557761",
  "text" : "Cities around the U.S. are answering President Obama's calls to #RaiseTheWage &amp; #LeadOnLeave \u2192 http:\/\/t.co\/VE5KKijqro http:\/\/t.co\/nSYg5ij4vj",
  "id" : 603199756429557761,
  "created_at" : "2015-05-26 14:03:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 74, 80 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/603005834482819072\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/Eo916i2ua9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CF5OUMYWIAAK3sf.jpg",
      "id_str" : "603005508941914112",
      "id" : 603005508941914112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CF5OUMYWIAAK3sf.jpg",
      "sizes" : [ {
        "h" : 445,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 759,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 252,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2075,
        "resize" : "fit",
        "w" : 2800
      } ],
      "display_url" : "pic.twitter.com\/Eo916i2ua9"
    } ],
    "hashtags" : [ {
      "text" : "MemorialDay",
      "indices" : [ 105, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/iyrZvoPdH7",
      "expanded_url" : "http:\/\/go.wh.gov\/mUX3Uo",
      "display_url" : "go.wh.gov\/mUX3Uo"
    } ]
  },
  "geo" : { },
  "id_str" : "603005834482819072",
  "text" : "\"May God bless our fallen heroes and their families, and all who serve.\" \u2014@POTUS: http:\/\/t.co\/iyrZvoPdH7 #MemorialDay http:\/\/t.co\/Eo916i2ua9",
  "id" : 603005834482819072,
  "created_at" : "2015-05-26 01:12:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602940227846545408",
  "text" : "RT @FLOTUS: So proud to honor the heroes who sacrificed their lives for our freedom. We remember them and their loved ones today, and every\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "602937090523934720",
    "text" : "So proud to honor the heroes who sacrificed their lives for our freedom. We remember them and their loved ones today, and every day. -mo",
    "id" : 602937090523934720,
    "created_at" : "2015-05-25 20:39:39 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 602940227846545408,
  "created_at" : "2015-05-25 20:52:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/petesouza\/status\/602925774316929025\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/qg5KlRs7Bo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CF4Fy1SWgAAfBVM.jpg",
      "id_str" : "602925770969874432",
      "id" : 602925770969874432,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CF4Fy1SWgAAfBVM.jpg",
      "sizes" : [ {
        "h" : 444,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 758,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 252,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 758,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/qg5KlRs7Bo"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602935188461592576",
  "text" : "RT @petesouza: Pres Obama greets WW2 veteran, 107-yr-old retired Army Lt Col Luta Mae Cornelius McGrath http:\/\/t.co\/qg5KlRs7Bo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/petesouza\/status\/602925774316929025\/photo\/1",
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/qg5KlRs7Bo",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CF4Fy1SWgAAfBVM.jpg",
        "id_str" : "602925770969874432",
        "id" : 602925770969874432,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CF4Fy1SWgAAfBVM.jpg",
        "sizes" : [ {
          "h" : 444,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 758,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 252,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 758,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/qg5KlRs7Bo"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "602925774316929025",
    "text" : "Pres Obama greets WW2 veteran, 107-yr-old retired Army Lt Col Luta Mae Cornelius McGrath http:\/\/t.co\/qg5KlRs7Bo",
    "id" : 602925774316929025,
    "created_at" : "2015-05-25 19:54:41 +0000",
    "user" : {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "protected" : false,
      "id_str" : "18215973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771916869808844800\/7d_poH48_normal.jpg",
      "id" : 18215973,
      "verified" : true
    }
  },
  "id" : 602935188461592576,
  "created_at" : "2015-05-25 20:32:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602879594333663232",
  "text" : "RT @POTUS: Spent the morning at Arlington. Take time today to honor our fallen heroes. We're forever indebted to their families. http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/POTUS\/status\/602878130362146816\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/hChhhOVCS3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CF3adi7WoAArHvU.jpg",
        "id_str" : "602878126264328192",
        "id" : 602878126264328192,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CF3adi7WoAArHvU.jpg",
        "sizes" : [ {
          "h" : 700,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 410,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 700,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 232,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/hChhhOVCS3"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "602878130362146816",
    "text" : "Spent the morning at Arlington. Take time today to honor our fallen heroes. We're forever indebted to their families. http:\/\/t.co\/hChhhOVCS3",
    "id" : 602878130362146816,
    "created_at" : "2015-05-25 16:45:21 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 602879594333663232,
  "created_at" : "2015-05-25 16:51:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 130, 136 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602863249281970177",
  "text" : "\"The Americans who rest beneath these beautiful hills, and in sacred ground...around the world\u2014they are why our nation endures.\" \u2014@POTUS",
  "id" : 602863249281970177,
  "created_at" : "2015-05-25 15:46:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 123, 129 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MemorialDay",
      "indices" : [ 22, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602862704752209920",
  "text" : "\"For many of us, this #MemorialDay is especially meaningful\u2014it is the first since our war in Afghanistan came to an end.\" \u2014@POTUS",
  "id" : 602862704752209920,
  "created_at" : "2015-05-25 15:44:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 102, 108 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MemorialDay",
      "indices" : [ 109, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602862397242658816",
  "text" : "RT @WHLive: \"This year, we mark an historic anniversary\u201470 years since our victory in World War II.\" \u2014@POTUS #MemorialDay",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 90, 96 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MemorialDay",
        "indices" : [ 97, 109 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "602862359892402176",
    "text" : "\"This year, we mark an historic anniversary\u201470 years since our victory in World War II.\" \u2014@POTUS #MemorialDay",
    "id" : 602862359892402176,
    "created_at" : "2015-05-25 15:42:41 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 602862397242658816,
  "created_at" : "2015-05-25 15:42:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 114, 120 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MemorialDay",
      "indices" : [ 121, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602860308940619776",
  "text" : "\"Honor. Courage. Selflessness. Those values lived in the hearts of everyday heroes who risked everything for us\" \u2014@POTUS #MemorialDay",
  "id" : 602860308940619776,
  "created_at" : "2015-05-25 15:34:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 133, 139 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602860058213507072",
  "text" : "\"Our nation has set aside this day to pay solemn tribute to patriots who gave their last full measure of devotion for this country\" \u2014@POTUS",
  "id" : 602860058213507072,
  "created_at" : "2015-05-25 15:33:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MemorialDay",
      "indices" : [ 38, 50 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/vUssNvn1AA",
      "expanded_url" : "http:\/\/go.wh.gov\/uTarnb",
      "display_url" : "go.wh.gov\/uTarnb"
    } ]
  },
  "geo" : { },
  "id_str" : "602859704222654464",
  "text" : "Watch live: President Obama speaks on #MemorialDay at Arlington National Cemetery \u2192 http:\/\/t.co\/vUssNvn1AA",
  "id" : 602859704222654464,
  "created_at" : "2015-05-25 15:32:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/602849062107353088\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/ECDU6D3v1x",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CF2_-GIWAAAZonP.jpg",
      "id_str" : "602848998655918080",
      "id" : 602848998655918080,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CF2_-GIWAAAZonP.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/ECDU6D3v1x"
    } ],
    "hashtags" : [ {
      "text" : "MemorialDay",
      "indices" : [ 46, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/vUssNvn1AA",
      "expanded_url" : "http:\/\/go.wh.gov\/uTarnb",
      "display_url" : "go.wh.gov\/uTarnb"
    } ]
  },
  "geo" : { },
  "id_str" : "602849062107353088",
  "text" : "At 11:20am ET, watch President Obama speak on #MemorialDay at Arlington National Cemetery \u2192 http:\/\/t.co\/vUssNvn1AA http:\/\/t.co\/ECDU6D3v1x",
  "id" : 602849062107353088,
  "created_at" : "2015-05-25 14:49:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WestWingWeek",
      "indices" : [ 73, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/amaotQlxp8",
      "expanded_url" : "http:\/\/go.wh.gov\/Pi5wuF",
      "display_url" : "go.wh.gov\/Pi5wuF"
    } ]
  },
  "geo" : { },
  "id_str" : "602584118874877952",
  "text" : "Got 4 minutes? Check out a recap of President Obama's week in the latest #WestWingWeek: http:\/\/t.co\/amaotQlxp8",
  "id" : 602584118874877952,
  "created_at" : "2015-05-24 21:17:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MemorialDay",
      "indices" : [ 118, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/KTdfx584nO",
      "expanded_url" : "http:\/\/go.wh.gov\/kb7du1",
      "display_url" : "go.wh.gov\/kb7du1"
    } ]
  },
  "geo" : { },
  "id_str" : "602566012278427648",
  "text" : "Let's honor the men and women in uniform who have given their lives in service to our country: http:\/\/t.co\/KTdfx584nO #MemorialDay",
  "id" : 602566012278427648,
  "created_at" : "2015-05-24 20:05:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 25, 31 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WestWingWeek",
      "indices" : [ 87, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/amaotQlxp8",
      "expanded_url" : "http:\/\/go.wh.gov\/Pi5wuF",
      "display_url" : "go.wh.gov\/Pi5wuF"
    } ]
  },
  "geo" : { },
  "id_str" : "602546373729210368",
  "text" : "President Obama launched @POTUS with a tweet from the Oval Office. Watch in the latest #WestWingWeek: http:\/\/t.co\/amaotQlxp8",
  "id" : 602546373729210368,
  "created_at" : "2015-05-24 18:47:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MemorialDay",
      "indices" : [ 121, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/KTdfx5pFMo",
      "expanded_url" : "http:\/\/go.wh.gov\/kb7du1",
      "display_url" : "go.wh.gov\/kb7du1"
    } ]
  },
  "geo" : { },
  "id_str" : "602518931170004992",
  "text" : "\"As a nation, we have to remain worthy of their sacrifice.\" \u2014Obama on honoring our fallen heroes: http:\/\/t.co\/KTdfx5pFMo #MemorialDay",
  "id" : 602518931170004992,
  "created_at" : "2015-05-24 16:58:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/KTdfx584nO",
      "expanded_url" : "http:\/\/go.wh.gov\/kb7du1",
      "display_url" : "go.wh.gov\/kb7du1"
    } ]
  },
  "geo" : { },
  "id_str" : "602202602181267456",
  "text" : "\"We have to honor their memory. We have to care for their families, and our veterans who served with them.\" \u2014Obama: http:\/\/t.co\/KTdfx584nO",
  "id" : 602202602181267456,
  "created_at" : "2015-05-23 20:01:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/602146362730360832\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/kELgqYjIdO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CFtAwPVWMAA-8qL.png",
      "id_str" : "602146172678057984",
      "id" : 602146172678057984,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFtAwPVWMAA-8qL.png",
      "sizes" : [ {
        "h" : 465,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 658
      }, {
        "h" : 264,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 658
      } ],
      "display_url" : "pic.twitter.com\/kELgqYjIdO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "602146362730360832",
  "text" : "\"Archbishop Romero was an inspiration for people in El Salvador and across the Americas.\" \u2014President Obama: http:\/\/t.co\/kELgqYjIdO",
  "id" : 602146362730360832,
  "created_at" : "2015-05-23 16:17:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/KTdfx5pFMo",
      "expanded_url" : "http:\/\/go.wh.gov\/kb7du1",
      "display_url" : "go.wh.gov\/kb7du1"
    } ]
  },
  "geo" : { },
  "id_str" : "602138518295552000",
  "text" : "Let's honor the men and women in uniform who have ever given their lives so we can live in freedom and security: http:\/\/t.co\/KTdfx5pFMo",
  "id" : 602138518295552000,
  "created_at" : "2015-05-23 15:46:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/601929112358379520\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/MsVtbuRAbE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CFp7U3-XIAEBTv1.png",
      "id_str" : "601929098760495105",
      "id" : 601929098760495105,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFp7U3-XIAEBTv1.png",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 529
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 529
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 529
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 257,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/MsVtbuRAbE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601929112358379520",
  "text" : "\"I want to thank Senators of both parties for sticking up for American workers by supporting smart trade\" \u2014Obama http:\/\/t.co\/MsVtbuRAbE",
  "id" : 601929112358379520,
  "created_at" : "2015-05-23 01:54:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Dr Z",
      "screen_name" : "DrFahmida",
      "indices" : [ 12, 22 ],
      "id_str" : "211171360",
      "id" : 211171360
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601845889200746497",
  "text" : "RT @POTUS: .@DrFahmida tell your niece I really like her letter. Couldn't agree more!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dr Z",
        "screen_name" : "DrFahmida",
        "indices" : [ 1, 11 ],
        "id_str" : "211171360",
        "id" : 211171360
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "601808287529455616",
    "geo" : { },
    "id_str" : "601844801672257536",
    "in_reply_to_user_id" : 211171360,
    "text" : ".@DrFahmida tell your niece I really like her letter. Couldn't agree more!",
    "id" : 601844801672257536,
    "in_reply_to_status_id" : 601808287529455616,
    "created_at" : "2015-05-22 20:19:17 +0000",
    "in_reply_to_screen_name" : "DrFahmida",
    "in_reply_to_user_id_str" : "211171360",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 601845889200746497,
  "created_at" : "2015-05-22 20:23:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Rabbi Steven Wernick",
      "screen_name" : "rebsteve",
      "indices" : [ 12, 21 ],
      "id_str" : "43697249",
      "id" : 43697249
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601841883988492289",
  "text" : "RT @POTUS: .@rebsteve really enjoyed stopping by today. I had fun singing Shabbat Shalom with the PreK class downstairs, too! http:\/\/t.co\/6\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Rabbi Steven Wernick",
        "screen_name" : "rebsteve",
        "indices" : [ 1, 10 ],
        "id_str" : "43697249",
        "id" : 43697249
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/POTUS\/status\/601841646020464640\/video\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/6b8CrXSgMt",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/601841156528418816\/pu\/img\/NOPCDy9EcMYKQ45J.jpg",
        "id_str" : "601841156528418816",
        "id" : 601841156528418816,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/601841156528418816\/pu\/img\/NOPCDy9EcMYKQ45J.jpg",
        "sizes" : [ {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/6b8CrXSgMt"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "601770783443124224",
    "geo" : { },
    "id_str" : "601841646020464640",
    "in_reply_to_user_id" : 43697249,
    "text" : ".@rebsteve really enjoyed stopping by today. I had fun singing Shabbat Shalom with the PreK class downstairs, too! http:\/\/t.co\/6b8CrXSgMt",
    "id" : 601841646020464640,
    "in_reply_to_status_id" : 601770783443124224,
    "created_at" : "2015-05-22 20:06:44 +0000",
    "in_reply_to_screen_name" : "rebsteve",
    "in_reply_to_user_id_str" : "43697249",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 601841883988492289,
  "created_at" : "2015-05-22 20:07:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601832384187731968",
  "text" : "RT @VP: Land of the free. Home of the brave. Thank you to all who serve in the finest military in the history of the world. http:\/\/t.co\/XFn\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/601826756132143104\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/XFnHDpmSgH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CFoePsNVEAAC_28.jpg",
        "id_str" : "601826755121319936",
        "id" : 601826755121319936,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFoePsNVEAAC_28.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/XFnHDpmSgH"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "601826756132143104",
    "text" : "Land of the free. Home of the brave. Thank you to all who serve in the finest military in the history of the world. http:\/\/t.co\/XFnHDpmSgH",
    "id" : 601826756132143104,
    "created_at" : "2015-05-22 19:07:34 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 601832384187731968,
  "created_at" : "2015-05-22 19:29:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 96, 102 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/OfzZY7o2nM",
      "expanded_url" : "http:\/\/snpy.tv\/1K9kE6r",
      "display_url" : "snpy.tv\/1K9kE6r"
    } ]
  },
  "geo" : { },
  "id_str" : "601805247061852160",
  "text" : "\"I'm interested in a deal that blocks every single one of Iran\u2019s pathways to a nuclear weapon\" \u2014@POTUS http:\/\/t.co\/OfzZY7o2nM",
  "id" : 601805247061852160,
  "created_at" : "2015-05-22 17:42:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 104, 110 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601771638854680576",
  "text" : "\"May we always choose faith over nihilism, and courage over despair, and hope over cynicism and fear.\" \u2014@POTUS",
  "id" : 601771638854680576,
  "created_at" : "2015-05-22 15:28:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 101, 107 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601770157728505856",
  "text" : "\"Anti-Semitism is and always will be a threat to broader human values to which we all must aspire.\" \u2014@POTUS",
  "id" : 601770157728505856,
  "created_at" : "2015-05-22 15:22:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 93, 99 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601769634547765249",
  "text" : "\u201CTwo states for two people. Israel and Palestine living side by side in peace and security\u201D \u2014@POTUS on the path to long-term security",
  "id" : 601769634547765249,
  "created_at" : "2015-05-22 15:20:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 77, 83 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601768055790772224",
  "text" : "\"Iran must not under any circumstances be allowed to get a nuclear weapon.\" \u2014@POTUS on securing a nuclear deal with Iran",
  "id" : 601768055790772224,
  "created_at" : "2015-05-22 15:14:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 91, 97 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Adas Israel",
      "screen_name" : "adasisraeldc",
      "indices" : [ 101, 114 ],
      "id_str" : "216070308",
      "id" : 216070308
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601767434945765376",
  "text" : "\u201CNo Administration has done more to ensure that Israel can protect itself than this one.\u201D \u2014@POTUS at @AdasIsraelDC",
  "id" : 601767434945765376,
  "created_at" : "2015-05-22 15:11:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 113, 119 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Adas Israel",
      "screen_name" : "adasisraeldc",
      "indices" : [ 123, 136 ],
      "id_str" : "216070308",
      "id" : 216070308
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601766729061130240",
  "text" : "\"Our commitment to Israel\u2019s security\u2014and my commitment to Israel\u2019s security\u2014is and always will be unshakeable.\" \u2014@POTUS at @AdasIsraelDC",
  "id" : 601766729061130240,
  "created_at" : "2015-05-22 15:09:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 105, 111 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Adas Israel",
      "screen_name" : "adasisraeldc",
      "indices" : [ 115, 128 ],
      "id_str" : "216070308",
      "id" : 216070308
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601766163048194048",
  "text" : "\"The heritage we celebrate this month is a testament to the power of hope...it's a rebuke to cynicism.\" \u2014@POTUS at @AdasIsraelDC",
  "id" : 601766163048194048,
  "created_at" : "2015-05-22 15:06:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/vM5i76oLnN",
      "expanded_url" : "http:\/\/go.wh.gov\/mos4UP",
      "display_url" : "go.wh.gov\/mos4UP"
    } ]
  },
  "geo" : { },
  "id_str" : "601763749993779200",
  "text" : "Happening now: Watch President Obama speak at a celebration of Jewish American Heritage Month \u2192 http:\/\/t.co\/vM5i76oLnN",
  "id" : 601763749993779200,
  "created_at" : "2015-05-22 14:57:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 18, 24 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/4Sn97ghbrR",
      "expanded_url" : "http:\/\/go.wh.gov\/mos4UP",
      "display_url" : "go.wh.gov\/mos4UP"
    } ]
  },
  "geo" : { },
  "id_str" : "601761870161272832",
  "text" : "RT @WHLive: Watch @POTUS speak at a celebration of Jewish American Heritage Month at 11am ET \u2192 http:\/\/t.co\/4Sn97ghbrR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 6, 12 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/4Sn97ghbrR",
        "expanded_url" : "http:\/\/go.wh.gov\/mos4UP",
        "display_url" : "go.wh.gov\/mos4UP"
      } ]
    },
    "geo" : { },
    "id_str" : "601761842587955200",
    "text" : "Watch @POTUS speak at a celebration of Jewish American Heritage Month at 11am ET \u2192 http:\/\/t.co\/4Sn97ghbrR",
    "id" : 601761842587955200,
    "created_at" : "2015-05-22 14:49:38 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 601761870161272832,
  "created_at" : "2015-05-22 14:49:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EIA",
      "screen_name" : "EIAgov",
      "indices" : [ 3, 10 ],
      "id_str" : "57111966",
      "id" : 57111966
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Energy",
      "indices" : [ 21, 28 ]
    }, {
      "text" : "gasoline",
      "indices" : [ 37, 46 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/6MOWj38rg5",
      "expanded_url" : "http:\/\/go.usa.gov\/394sP",
      "display_url" : "go.usa.gov\/394sP"
    } ]
  },
  "geo" : { },
  "id_str" : "601746660973240320",
  "text" : "RT @EIAgov: Today in #Energy: Retail #gasoline prices lowest since 2009 heading into Memorial Day weekend http:\/\/t.co\/6MOWj38rg5 http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/EIAgov\/status\/601722223909597184\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/rpd699hjME",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CFm_LI7UEAEnzFZ.png",
        "id_str" : "601722223326400513",
        "id" : 601722223326400513,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFm_LI7UEAEnzFZ.png",
        "sizes" : [ {
          "h" : 291,
          "resize" : "fit",
          "w" : 577
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 171,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 291,
          "resize" : "fit",
          "w" : 577
        }, {
          "h" : 291,
          "resize" : "fit",
          "w" : 577
        } ],
        "display_url" : "pic.twitter.com\/rpd699hjME"
      } ],
      "hashtags" : [ {
        "text" : "Energy",
        "indices" : [ 9, 16 ]
      }, {
        "text" : "gasoline",
        "indices" : [ 25, 34 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/6MOWj38rg5",
        "expanded_url" : "http:\/\/go.usa.gov\/394sP",
        "display_url" : "go.usa.gov\/394sP"
      } ]
    },
    "geo" : { },
    "id_str" : "601722223909597184",
    "text" : "Today in #Energy: Retail #gasoline prices lowest since 2009 heading into Memorial Day weekend http:\/\/t.co\/6MOWj38rg5 http:\/\/t.co\/rpd699hjME",
    "id" : 601722223909597184,
    "created_at" : "2015-05-22 12:12:12 +0000",
    "user" : {
      "name" : "EIA",
      "screen_name" : "EIAgov",
      "protected" : false,
      "id_str" : "57111966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/489460437214171136\/x9Ca1CfZ_normal.jpeg",
      "id" : 57111966,
      "verified" : true
    }
  },
  "id" : 601746660973240320,
  "created_at" : "2015-05-22 13:49:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/601560268934672386\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/YA0stl9Fp2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CFkrwYJW0AAhN2F.png",
      "id_str" : "601560135346081792",
      "id" : 601560135346081792,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFkrwYJW0AAhN2F.png",
      "sizes" : [ {
        "h" : 104,
        "resize" : "crop",
        "w" : 104
      }, {
        "h" : 104,
        "resize" : "fit",
        "w" : 630
      }, {
        "h" : 104,
        "resize" : "fit",
        "w" : 630
      }, {
        "h" : 99,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 56,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/YA0stl9Fp2"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/jZ8n9jg6Vu",
      "expanded_url" : "http:\/\/go.wh.gov\/6WYWYC",
      "display_url" : "go.wh.gov\/6WYWYC"
    } ]
  },
  "geo" : { },
  "id_str" : "601560268934672386",
  "text" : ".@POTUS praised the bipartisan Senate vote to advance a trade agenda benefiting U.S. workers: http:\/\/t.co\/jZ8n9jg6Vu http:\/\/t.co\/YA0stl9Fp2",
  "id" : 601560268934672386,
  "created_at" : "2015-05-22 01:28:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/601492077948620800\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/BajkHdfKbO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CFjtIvZWEAAuyz-.jpg",
      "id_str" : "601491284671467520",
      "id" : 601491284671467520,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFjtIvZWEAAuyz-.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/BajkHdfKbO"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 104, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/AtmPqUkfJ5",
      "expanded_url" : "http:\/\/go.wh.gov\/CAtne3",
      "display_url" : "go.wh.gov\/CAtne3"
    } ]
  },
  "geo" : { },
  "id_str" : "601492077948620800",
  "text" : "Here's what military leaders are saying about the need to combat climate change: http:\/\/t.co\/AtmPqUkfJ5 #ActOnClimate http:\/\/t.co\/BajkHdfKbO",
  "id" : 601492077948620800,
  "created_at" : "2015-05-21 20:57:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/601482019458129921\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/V5OGblPZad",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CFjkYm_WEAAwEi5.jpg",
      "id_str" : "601481661688188928",
      "id" : 601481661688188928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFjkYm_WEAAwEi5.jpg",
      "sizes" : [ {
        "h" : 722,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 722,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 423,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/V5OGblPZad"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/Y7oXdn8wAq",
      "expanded_url" : "http:\/\/go.wh.gov\/LZAPW3",
      "display_url" : "go.wh.gov\/LZAPW3"
    } ]
  },
  "geo" : { },
  "id_str" : "601482019458129921",
  "text" : "Thanks for choosing to serve.\nFor stepping up.\nFor putting on that uniform.\nhttp:\/\/t.co\/Y7oXdn8wAq http:\/\/t.co\/V5OGblPZad",
  "id" : 601482019458129921,
  "created_at" : "2015-05-21 20:17:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 57, 63 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/601456868242825216\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/ws8dRwFjqC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CFjMknBUMAE85kT.jpg",
      "id_str" : "601455479575818241",
      "id" : 601455479575818241,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFjMknBUMAE85kT.jpg",
      "sizes" : [ {
        "h" : 770,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 256,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 451,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 770,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/ws8dRwFjqC"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/Y7oXdmQVbQ",
      "expanded_url" : "http:\/\/go.wh.gov\/LZAPW3",
      "display_url" : "go.wh.gov\/LZAPW3"
    } ]
  },
  "geo" : { },
  "id_str" : "601456868242825216",
  "text" : "Your graduation photo probably isn't this cool.\nSee what @POTUS said to graduating cadets \u2192 http:\/\/t.co\/Y7oXdmQVbQ http:\/\/t.co\/ws8dRwFjqC",
  "id" : 601456868242825216,
  "created_at" : "2015-05-21 18:37:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Megan Smith",
      "screen_name" : "USCTO",
      "indices" : [ 3, 9 ],
      "id_str" : "2888895350",
      "id" : 2888895350
    }, {
      "name" : "TheMSTeacher",
      "screen_name" : "cogunshakin",
      "indices" : [ 119, 131 ],
      "id_str" : "1885137019",
      "id" : 1885137019
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHMapathon",
      "indices" : [ 54, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601452315824947200",
  "text" : "RT @USCTO: Found the two youngest star mappers at the #WHMapathon--Charlie, 12 &amp; Mia,14 with their amazing teacher @cogunshakin http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "TheMSTeacher",
        "screen_name" : "cogunshakin",
        "indices" : [ 108, 120 ],
        "id_str" : "1885137019",
        "id" : 1885137019
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/USCTO\/status\/601451404696297472\/photo\/1",
        "indices" : [ 121, 143 ],
        "url" : "http:\/\/t.co\/Xm5UAJSU25",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CFjIwRmUIAEvVI3.jpg",
        "id_str" : "601451281937342465",
        "id" : 601451281937342465,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFjIwRmUIAEvVI3.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/Xm5UAJSU25"
      } ],
      "hashtags" : [ {
        "text" : "WHMapathon",
        "indices" : [ 43, 54 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "601451404696297472",
    "text" : "Found the two youngest star mappers at the #WHMapathon--Charlie, 12 &amp; Mia,14 with their amazing teacher @cogunshakin http:\/\/t.co\/Xm5UAJSU25",
    "id" : 601451404696297472,
    "created_at" : "2015-05-21 18:16:03 +0000",
    "user" : {
      "name" : "Megan Smith",
      "screen_name" : "USCTO",
      "protected" : false,
      "id_str" : "2888895350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/534373591228219392\/Ewzw--q6_normal.jpeg",
      "id" : 2888895350,
      "verified" : true
    }
  },
  "id" : 601452315824947200,
  "created_at" : "2015-05-21 18:19:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Atlantic",
      "screen_name" : "TheAtlantic",
      "indices" : [ 3, 15 ],
      "id_str" : "35773039",
      "id" : 35773039
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/NHWjjF15Cp",
      "expanded_url" : "http:\/\/theatln.tc\/1K5sjCs",
      "display_url" : "theatln.tc\/1K5sjCs"
    } ]
  },
  "geo" : { },
  "id_str" : "601438848065798144",
  "text" : "RT @TheAtlantic: The Mideast Interview: An exclusive conversation with Barack Obama on ISIS, Israel, and Iran http:\/\/t.co\/NHWjjF15Cp http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TheAtlantic\/status\/601415800273121280\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/46GGGPBDmu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CFioe67VEAEVVGU.jpg",
        "id_str" : "601415799421603841",
        "id" : 601415799421603841,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFioe67VEAEVVGU.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1280,
          "resize" : "fit",
          "w" : 1920
        } ],
        "display_url" : "pic.twitter.com\/46GGGPBDmu"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/NHWjjF15Cp",
        "expanded_url" : "http:\/\/theatln.tc\/1K5sjCs",
        "display_url" : "theatln.tc\/1K5sjCs"
      } ]
    },
    "geo" : { },
    "id_str" : "601415800273121280",
    "text" : "The Mideast Interview: An exclusive conversation with Barack Obama on ISIS, Israel, and Iran http:\/\/t.co\/NHWjjF15Cp http:\/\/t.co\/46GGGPBDmu",
    "id" : 601415800273121280,
    "created_at" : "2015-05-21 15:54:35 +0000",
    "user" : {
      "name" : "The Atlantic",
      "screen_name" : "TheAtlantic",
      "protected" : false,
      "id_str" : "35773039",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1268207868\/twitter-icon-main_normal.png",
      "id" : 35773039,
      "verified" : true
    }
  },
  "id" : 601438848065798144,
  "created_at" : "2015-05-21 17:26:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 14, 20 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Jeffrey Goldberg",
      "screen_name" : "JeffreyGoldberg",
      "indices" : [ 25, 41 ],
      "id_str" : "47448886",
      "id" : 47448886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/oS4SHEQABS",
      "expanded_url" : "http:\/\/theatln.tc\/1cQdfxG",
      "display_url" : "theatln.tc\/1cQdfxG"
    }, {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/ckdB70FWtq",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/e3bedf92-5545-44f3-a0de-59f2dc20c890",
      "display_url" : "amp.twimg.com\/v\/e3bedf92-554\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "601418406131204096",
  "text" : "Worth a read: @POTUS and @JeffreyGoldberg discuss the Iran nuclear deal, Israel, and more \u2192 http:\/\/t.co\/oS4SHEQABS\nhttps:\/\/t.co\/ckdB70FWtq",
  "id" : 601418406131204096,
  "created_at" : "2015-05-21 16:04:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeffrey Goldberg",
      "screen_name" : "JeffreyGoldberg",
      "indices" : [ 3, 19 ],
      "id_str" : "47448886",
      "id" : 47448886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/sIPp9CwMEs",
      "expanded_url" : "http:\/\/www.theatlantic.com\/international\/archive\/2015\/05\/obama-interview-iran-isis-israel\/393782\/",
      "display_url" : "theatlantic.com\/international\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "601414995478454272",
  "text" : "RT @JeffreyGoldberg: Here's my interview with President Obama on the Iran deal, ISIS, Iraq and Israel: http:\/\/t.co\/sIPp9CwMEs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/sIPp9CwMEs",
        "expanded_url" : "http:\/\/www.theatlantic.com\/international\/archive\/2015\/05\/obama-interview-iran-isis-israel\/393782\/",
        "display_url" : "theatlantic.com\/international\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "601411491439517696",
    "text" : "Here's my interview with President Obama on the Iran deal, ISIS, Iraq and Israel: http:\/\/t.co\/sIPp9CwMEs",
    "id" : 601411491439517696,
    "created_at" : "2015-05-21 15:37:27 +0000",
    "user" : {
      "name" : "Jeffrey Goldberg",
      "screen_name" : "JeffreyGoldberg",
      "protected" : false,
      "id_str" : "47448886",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/503725514494730240\/PFkR-eVX_normal.jpeg",
      "id" : 47448886,
      "verified" : true
    }
  },
  "id" : 601414995478454272,
  "created_at" : "2015-05-21 15:51:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/601401738676043776\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/iSO9GY3NNT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CFiaNllWYAAfIbd.jpg",
      "id_str" : "601400108471705600",
      "id" : 601400108471705600,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFiaNllWYAAfIbd.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1202
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 511,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/iSO9GY3NNT"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 79, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/K5YxkHO9qw",
      "expanded_url" : "http:\/\/go.wh.gov\/8pmXiE",
      "display_url" : "go.wh.gov\/8pmXiE"
    } ]
  },
  "geo" : { },
  "id_str" : "601401738676043776",
  "text" : "A sea level rise of just 1 foot could cost America $200 billion.\n\nIt's time to #ActOnClimate: http:\/\/t.co\/K5YxkHO9qw http:\/\/t.co\/iSO9GY3NNT",
  "id" : 601401738676043776,
  "created_at" : "2015-05-21 14:58:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 59, 65 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Letterman",
      "screen_name" : "Letterman",
      "indices" : [ 69, 79 ],
      "id_str" : "25140900",
      "id" : 25140900
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThanksDave",
      "indices" : [ 104, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/YVsk21IBgm",
      "expanded_url" : "http:\/\/go.wh.gov\/Mgzpnn",
      "display_url" : "go.wh.gov\/Mgzpnn"
    }, {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/JJOOufuMR1",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/ea22a315-dfa0-401a-99f7-bf3a96410c31",
      "display_url" : "amp.twimg.com\/v\/ea22a315-dfa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "601235170344046592",
  "text" : "\"Sometimes cranky, often self-deprecating, always funny.\" \u2014@POTUS on @Letterman: http:\/\/t.co\/YVsk21IBgm #ThanksDave\nhttps:\/\/t.co\/JJOOufuMR1",
  "id" : 601235170344046592,
  "created_at" : "2015-05-21 03:56:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    }, {
      "name" : "Reclamation",
      "screen_name" : "usbr",
      "indices" : [ 30, 35 ],
      "id_str" : "18209334",
      "id" : 18209334
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "conservation",
      "indices" : [ 60, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/GThBiOGxPl",
      "expanded_url" : "http:\/\/on.doi.gov\/1Hvk4lS",
      "display_url" : "on.doi.gov\/1Hvk4lS"
    } ]
  },
  "geo" : { },
  "id_str" : "601158468494589954",
  "text" : "RT @Interior: Just Announced: @usbr to invest $50M in water #conservation to help drought-stricken states http:\/\/t.co\/GThBiOGxPl http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Reclamation",
        "screen_name" : "usbr",
        "indices" : [ 16, 21 ],
        "id_str" : "18209334",
        "id" : 18209334
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/601155322191941633\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/MmCQ890wky",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CFe7lGqWMAAUWwR.jpg",
        "id_str" : "601155321395032064",
        "id" : 601155321395032064,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFe7lGqWMAAUWwR.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/MmCQ890wky"
      } ],
      "hashtags" : [ {
        "text" : "conservation",
        "indices" : [ 46, 59 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/GThBiOGxPl",
        "expanded_url" : "http:\/\/on.doi.gov\/1Hvk4lS",
        "display_url" : "on.doi.gov\/1Hvk4lS"
      } ]
    },
    "geo" : { },
    "id_str" : "601155322191941633",
    "text" : "Just Announced: @usbr to invest $50M in water #conservation to help drought-stricken states http:\/\/t.co\/GThBiOGxPl http:\/\/t.co\/MmCQ890wky",
    "id" : 601155322191941633,
    "created_at" : "2015-05-20 22:39:32 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 601158468494589954,
  "created_at" : "2015-05-20 22:52:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/601146050469060608\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/9nnHOgzsib",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CFevDMuWMAE5pN9.jpg",
      "id_str" : "601141544767336449",
      "id" : 601141544767336449,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFevDMuWMAE5pN9.jpg",
      "sizes" : [ {
        "h" : 439,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 750,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 750,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 249,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/9nnHOgzsib"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/K5YxkHO9qw",
      "expanded_url" : "http:\/\/go.wh.gov\/8pmXiE",
      "display_url" : "go.wh.gov\/8pmXiE"
    } ]
  },
  "geo" : { },
  "id_str" : "601146050469060608",
  "text" : "\"You will rise to meet the challenges that not only face our country, but face our planet.\" http:\/\/t.co\/K5YxkHO9qw http:\/\/t.co\/9nnHOgzsib",
  "id" : 601146050469060608,
  "created_at" : "2015-05-20 22:02:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "indices" : [ 3, 11 ],
      "id_str" : "2382117350",
      "id" : 2382117350
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 23, 29 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Coast Guard Academy",
      "screen_name" : "USCGAcademy",
      "indices" : [ 38, 50 ],
      "id_str" : "55584584",
      "id" : 55584584
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 54, 67 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/XCCsKfQuAd",
      "expanded_url" : "https:\/\/medium.com\/@WhiteHouse\/president-obama-s-remarks-at-the-united-states-coast-guard-academy-commencement-121c2ba6f0c0",
      "display_url" : "medium.com\/@WhiteHouse\/pr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "601124023955775488",
  "text" : "RT @Deese44: Check out @POTUS remarks @USCGAcademy on #ActOnClimate is key to our national security: https:\/\/t.co\/XCCsKfQuAd http:\/\/t.co\/Jo\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 10, 16 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "Coast Guard Academy",
        "screen_name" : "USCGAcademy",
        "indices" : [ 25, 37 ],
        "id_str" : "55584584",
        "id" : 55584584
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Deese44\/status\/601123026759983104\/photo\/1",
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/JoEbMITMBA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CFedJg4WYAA_STU.jpg",
        "id_str" : "601121862047916032",
        "id" : 601121862047916032,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFedJg4WYAA_STU.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1202
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 511,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/JoEbMITMBA"
      } ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 41, 54 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/XCCsKfQuAd",
        "expanded_url" : "https:\/\/medium.com\/@WhiteHouse\/president-obama-s-remarks-at-the-united-states-coast-guard-academy-commencement-121c2ba6f0c0",
        "display_url" : "medium.com\/@WhiteHouse\/pr\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "601123026759983104",
    "text" : "Check out @POTUS remarks @USCGAcademy on #ActOnClimate is key to our national security: https:\/\/t.co\/XCCsKfQuAd http:\/\/t.co\/JoEbMITMBA",
    "id" : 601123026759983104,
    "created_at" : "2015-05-20 20:31:12 +0000",
    "user" : {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "protected" : false,
      "id_str" : "2382117350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656551411145027584\/ArrSlGUP_normal.jpg",
      "id" : 2382117350,
      "verified" : true
    }
  },
  "id" : 601124023955775488,
  "created_at" : "2015-05-20 20:35:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 66, 72 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/601117643546984449\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/MoNg6jjbUW",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CFeZRjBWIAAjgjl.png",
      "id_str" : "601117602014961664",
      "id" : 601117602014961664,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CFeZRjBWIAAjgjl.png",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/MoNg6jjbUW"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 97, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/K5YxkHO9qw",
      "expanded_url" : "http:\/\/go.wh.gov\/8pmXiE",
      "display_url" : "go.wh.gov\/8pmXiE"
    } ]
  },
  "geo" : { },
  "id_str" : "601117643546984449",
  "text" : "\"Climate change constitutes a serious threat to global security\" \u2014@POTUS: http:\/\/t.co\/K5YxkHO9qw #ActOnClimate http:\/\/t.co\/MoNg6jjbUW",
  "id" : 601117643546984449,
  "created_at" : "2015-05-20 20:09:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernest Moniz",
      "screen_name" : "ErnestMoniz",
      "indices" : [ 3, 15 ],
      "id_str" : "1393155566",
      "id" : 1393155566
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 18, 24 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ClimateChange",
      "indices" : [ 35, 49 ]
    }, {
      "text" : "EnergySecurity",
      "indices" : [ 72, 87 ]
    }, {
      "text" : "NationalSecurity",
      "indices" : [ 108, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601106549176725504",
  "text" : "RT @ErnestMoniz: .@POTUS is right: #ClimateChange poses a threat to our #EnergySecurity. That\u2019s a matter of #NationalSecurity. http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/measuredvoice.com\/\" rel=\"nofollow\"\u003EMeasured Voice\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 1, 7 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ErnestMoniz\/status\/601058297685368833\/photo\/1",
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/5RSZjj3ms0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CFdjVjCWIAAMn0b.png",
        "id_str" : "601058297110732800",
        "id" : 601058297110732800,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFdjVjCWIAAMn0b.png",
        "sizes" : [ {
          "h" : 370,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 210,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 571,
          "resize" : "fit",
          "w" : 925
        }, {
          "h" : 571,
          "resize" : "fit",
          "w" : 925
        } ],
        "display_url" : "pic.twitter.com\/5RSZjj3ms0"
      } ],
      "hashtags" : [ {
        "text" : "ClimateChange",
        "indices" : [ 18, 32 ]
      }, {
        "text" : "EnergySecurity",
        "indices" : [ 55, 70 ]
      }, {
        "text" : "NationalSecurity",
        "indices" : [ 91, 108 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "601058297685368833",
    "text" : ".@POTUS is right: #ClimateChange poses a threat to our #EnergySecurity. That\u2019s a matter of #NationalSecurity. http:\/\/t.co\/5RSZjj3ms0",
    "id" : 601058297685368833,
    "created_at" : "2015-05-20 16:13:59 +0000",
    "user" : {
      "name" : "Ernest Moniz",
      "screen_name" : "ErnestMoniz",
      "protected" : false,
      "id_str" : "1393155566",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793425933113954305\/f5Mxv7BK_normal.jpg",
      "id" : 1393155566,
      "verified" : true
    }
  },
  "id" : 601106549176725504,
  "created_at" : "2015-05-20 19:25:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DJ Patil",
      "screen_name" : "DJ44",
      "indices" : [ 3, 8 ],
      "id_str" : "3030922321",
      "id" : 3030922321
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PoliceData",
      "indices" : [ 107, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601104952681955330",
  "text" : "RT @DJ44: Start asking your questions on the Police Data Initiative! We'll be answering them today at 4pm. #PoliceData",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PoliceData",
        "indices" : [ 97, 108 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "601064002924486656",
    "geo" : { },
    "id_str" : "601091519014117376",
    "in_reply_to_user_id" : 3030922321,
    "text" : "Start asking your questions on the Police Data Initiative! We'll be answering them today at 4pm. #PoliceData",
    "id" : 601091519014117376,
    "in_reply_to_status_id" : 601064002924486656,
    "created_at" : "2015-05-20 18:26:00 +0000",
    "in_reply_to_screen_name" : "DJ44",
    "in_reply_to_user_id_str" : "3030922321",
    "user" : {
      "name" : "DJ Patil",
      "screen_name" : "DJ44",
      "protected" : false,
      "id_str" : "3030922321",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/570697565977313280\/aoCw1bC5_normal.jpeg",
      "id" : 3030922321,
      "verified" : true
    }
  },
  "id" : 601104952681955330,
  "created_at" : "2015-05-20 19:19:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "indices" : [ 3, 13 ],
      "id_str" : "15007149",
      "id" : 15007149
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 105, 111 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "climatechange",
      "indices" : [ 85, 99 ]
    }, {
      "text" : "ActOnClimate",
      "indices" : [ 118, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601090659974537216",
  "text" : "RT @JohnKerry: No president in US history has done more to advance our leadership on #climatechange than @POTUS Obama #ActOnClimate https:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 90, 96 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "climatechange",
        "indices" : [ 70, 84 ]
      }, {
        "text" : "ActOnClimate",
        "indices" : [ 103, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/OyXJrzqN29",
        "expanded_url" : "https:\/\/twitter.com\/WHLive\/status\/601057632544239616",
        "display_url" : "twitter.com\/WHLive\/status\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "601086707606368258",
    "text" : "No president in US history has done more to advance our leadership on #climatechange than @POTUS Obama #ActOnClimate https:\/\/t.co\/OyXJrzqN29",
    "id" : 601086707606368258,
    "created_at" : "2015-05-20 18:06:53 +0000",
    "user" : {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "protected" : false,
      "id_str" : "15007149",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/482149339842617346\/l6b7LXjb_normal.jpeg",
      "id" : 15007149,
      "verified" : true
    }
  },
  "id" : 601090659974537216,
  "created_at" : "2015-05-20 18:22:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601086462537420800",
  "text" : "RT @POTUS: An honor to address the Coast Guard class of 2015. Confident they'll help us meet big challenges like climate change. http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/POTUS\/status\/601082858497830913\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/1z4fteA1YJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CFd5oe-W8AAxM5Y.jpg",
        "id_str" : "601082811693592576",
        "id" : 601082811693592576,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFd5oe-W8AAxM5Y.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/1z4fteA1YJ"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "601082858497830913",
    "text" : "An honor to address the Coast Guard class of 2015. Confident they'll help us meet big challenges like climate change. http:\/\/t.co\/1z4fteA1YJ",
    "id" : 601082858497830913,
    "created_at" : "2015-05-20 17:51:35 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 601086462537420800,
  "created_at" : "2015-05-20 18:05:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 103, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/FWBk6dVVtt",
      "expanded_url" : "http:\/\/snpy.tv\/1PWKg8d",
      "display_url" : "snpy.tv\/1PWKg8d"
    } ]
  },
  "geo" : { },
  "id_str" : "601074941690191873",
  "text" : "Climate change threatens every country on the planet.\nNo nation is immune.\n\nRT if you agree we need to #ActOnClimate. http:\/\/t.co\/FWBk6dVVtt",
  "id" : 601074941690191873,
  "created_at" : "2015-05-20 17:20:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 89, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/l1rKJK5KQH",
      "expanded_url" : "http:\/\/snpy.tv\/1PWJdFi",
      "display_url" : "snpy.tv\/1PWJdFi"
    } ]
  },
  "geo" : { },
  "id_str" : "601068930518654976",
  "text" : "The planet is getting warmer.\nGlaciers are melting.\nSea levels are rising.\n\nIt's time to #ActOnClimate. http:\/\/t.co\/l1rKJK5KQH",
  "id" : 601068930518654976,
  "created_at" : "2015-05-20 16:56:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 110, 116 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/p67ktklCiP",
      "expanded_url" : "http:\/\/snpy.tv\/1Lbpd0d",
      "display_url" : "snpy.tv\/1Lbpd0d"
    } ]
  },
  "geo" : { },
  "id_str" : "601062066905096192",
  "text" : "\"Climate change constitutes a serious threat to global security\u2014an immediate risk to our national security.\" \u2014@POTUS http:\/\/t.co\/p67ktklCiP",
  "id" : 601062066905096192,
  "created_at" : "2015-05-20 16:28:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 103, 109 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "U.S. Coast Guard",
      "screen_name" : "uscoastguard",
      "indices" : [ 113, 126 ],
      "id_str" : "17409240",
      "id" : 17409240
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601058735562326016",
  "text" : "\"I am confident you will truly go where few dare; you will rise to meet the challenges to our planet\" \u2014@POTUS to @USCoastGuard graduates",
  "id" : 601058735562326016,
  "created_at" : "2015-05-20 16:15:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 118, 124 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 125, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601058262218334209",
  "text" : "\"We cannot know how many days each of us will walk this Earth...but what we can do is live each day to its fullest.\" \u2014@POTUS #ActOnClimate",
  "id" : 601058262218334209,
  "created_at" : "2015-05-20 16:13:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 85, 91 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WHLive\/status\/601057632544239616\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/q2ZFQCPKk2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CFdisd6WEAA2AAC.jpg",
      "id_str" : "601057591360360448",
      "id" : 601057591360360448,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFdisd6WEAA2AAC.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/q2ZFQCPKk2"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 92, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601057675447771136",
  "text" : "RT @WHLive: \"I\u2019ve committed to doubling the pace at which we cut carbon pollution.\" \u2014@POTUS #ActOnClimate http:\/\/t.co\/q2ZFQCPKk2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 73, 79 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/WHLive\/status\/601057632544239616\/photo\/1",
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/q2ZFQCPKk2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CFdisd6WEAA2AAC.jpg",
        "id_str" : "601057591360360448",
        "id" : 601057591360360448,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFdisd6WEAA2AAC.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/q2ZFQCPKk2"
      } ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 80, 93 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "601057632544239616",
    "text" : "\"I\u2019ve committed to doubling the pace at which we cut carbon pollution.\" \u2014@POTUS #ActOnClimate http:\/\/t.co\/q2ZFQCPKk2",
    "id" : 601057632544239616,
    "created_at" : "2015-05-20 16:11:21 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 601057675447771136,
  "created_at" : "2015-05-20 16:11:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 120, 126 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601057266549301248",
  "text" : "\"We all know what needs to happen. It\u2019s no secret. The world has to finally start reducing its carbon emissions, now.\" \u2014@POTUS #ActOnClimate",
  "id" : 601057266549301248,
  "created_at" : "2015-05-20 16:09:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 92, 98 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 114, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601057099603410946",
  "text" : "\"There comes a point when the worst effects will be irreversible\u2014and time is running out.\" \u2014@POTUS on the need to #ActOnClimate",
  "id" : 601057099603410946,
  "created_at" : "2015-05-20 16:09:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601056873211678720",
  "text" : "RT @WHLive: \"The only way the world is going to prevent the worst effects of climate change is to slow down the warming of the planet.\" \u2014@P\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 125, 131 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "601056851422216192",
    "text" : "\"The only way the world is going to prevent the worst effects of climate change is to slow down the warming of the planet.\" \u2014@POTUS",
    "id" : 601056851422216192,
    "created_at" : "2015-05-20 16:08:15 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 601056873211678720,
  "created_at" : "2015-05-20 16:08:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 63, 69 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/601054659378335744\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/IbNgN9w61I",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CFdf6X6WMAAiJaL.jpg",
      "id_str" : "601054531733041152",
      "id" : 601054531733041152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFdf6X6WMAAiJaL.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1202
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 511,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/IbNgN9w61I"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 84, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601054659378335744",
  "text" : "\"We need to act\u2014and we need to act now.\"\n\nRT if you agree with @POTUS: It's time to #ActOnClimate. http:\/\/t.co\/IbNgN9w61I",
  "id" : 601054659378335744,
  "created_at" : "2015-05-20 15:59:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 94, 100 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/601054235334156288\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/0cGOYfTG4n",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CFdfnO3XIAAUPOt.jpg",
      "id_str" : "601054202887086080",
      "id" : 601054202887086080,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFdfnO3XIAAUPOt.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/0cGOYfTG4n"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 101, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601054235334156288",
  "text" : "\"I am here today to say that climate change constitutes a serious threat to global security\" \u2014@POTUS #ActOnClimate http:\/\/t.co\/0cGOYfTG4n",
  "id" : 601054235334156288,
  "created_at" : "2015-05-20 15:57:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 80, 86 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/601054120842285057\/photo\/1",
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/po1iaxdjsq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CFdfh_3WAAAYJyd.jpg",
      "id_str" : "601054112961134592",
      "id" : 601054112961134592,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFdfh_3WAAAYJyd.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/po1iaxdjsq"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 87, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601054120842285057",
  "text" : "\"Climate change will impact every country on the planet. No nation is immune.\" \u2014@POTUS #ActOnClimate http:\/\/t.co\/po1iaxdjsq",
  "id" : 601054120842285057,
  "created_at" : "2015-05-20 15:57:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 58, 64 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/601053645480849408\/photo\/1",
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/nOCtCEl3Wh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CFdfF9sWgAAnzj4.jpg",
      "id_str" : "601053631341821952",
      "id" : 601053631341821952,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFdfF9sWgAAnzj4.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/nOCtCEl3Wh"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 65, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601053645480849408",
  "text" : "\"Last year was the planet\u2019s warmest year ever recorded.\" \u2014@POTUS #ActOnClimate http:\/\/t.co\/nOCtCEl3Wh",
  "id" : 601053645480849408,
  "created_at" : "2015-05-20 15:55:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 88, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601053534247907328",
  "text" : "\"14 of the 15 hottest years on record have been in the past 15 years.\" \u2014President Obama #ActOnClimate",
  "id" : 601053534247907328,
  "created_at" : "2015-05-20 15:55:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 113, 119 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 120, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601053334712246273",
  "text" : "\"Even as we meet threats like terrorism, we cannot and we must not ignore a peril that can affect generations.\" \u2014@POTUS #ActOnClimate",
  "id" : 601053334712246273,
  "created_at" : "2015-05-20 15:54:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 118, 124 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601052666089893889",
  "text" : "RT @WHLive: \"Class of 2015, I\u2019m here as your Commander in Chief, on behalf of the American people, to say thank you\" \u2014@POTUS to @USCoastGua\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 106, 112 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "U.S. Coast Guard",
        "screen_name" : "uscoastguard",
        "indices" : [ 116, 129 ],
        "id_str" : "17409240",
        "id" : 17409240
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "601052643763605505",
    "text" : "\"Class of 2015, I\u2019m here as your Commander in Chief, on behalf of the American people, to say thank you\" \u2014@POTUS to @USCoastGuard graduates",
    "id" : 601052643763605505,
    "created_at" : "2015-05-20 15:51:31 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 601052666089893889,
  "created_at" : "2015-05-20 15:51:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Coast Guard",
      "screen_name" : "uscoastguard",
      "indices" : [ 95, 108 ],
      "id_str" : "17409240",
      "id" : 17409240
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601051911530381312",
  "text" : "\"The graduating Class of 2015 is the most diverse in Academy history.\" \u2014President Obama at the @USCoastGuard Academy",
  "id" : 601051911530381312,
  "created_at" : "2015-05-20 15:48:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 104, 110 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "U.S. Coast Guard",
      "screen_name" : "uscoastguard",
      "indices" : [ 118, 131 ],
      "id_str" : "17409240",
      "id" : 17409240
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "601051374437146624",
  "text" : "\"It is a great honor...to salute the newest ensigns of America\u2019s oldest, continuous maritime service.\" \u2014@POTUS at the @USCoastGuard Academy",
  "id" : 601051374437146624,
  "created_at" : "2015-05-20 15:46:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "U.S. Coast Guard",
      "screen_name" : "uscoastguard",
      "indices" : [ 54, 67 ],
      "id_str" : "17409240",
      "id" : 17409240
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/qQ2JbRg9UN",
      "expanded_url" : "http:\/\/go.wh.gov\/r8gaZV",
      "display_url" : "go.wh.gov\/r8gaZV"
    } ]
  },
  "geo" : { },
  "id_str" : "601050533043032064",
  "text" : "RT @WHLive: Watch live: President Obama speaks at the @USCoastGuard Academy commencement \u2192 http:\/\/t.co\/qQ2JbRg9UN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "U.S. Coast Guard",
        "screen_name" : "uscoastguard",
        "indices" : [ 42, 55 ],
        "id_str" : "17409240",
        "id" : 17409240
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/qQ2JbRg9UN",
        "expanded_url" : "http:\/\/go.wh.gov\/r8gaZV",
        "display_url" : "go.wh.gov\/r8gaZV"
      } ]
    },
    "geo" : { },
    "id_str" : "601050506367213568",
    "text" : "Watch live: President Obama speaks at the @USCoastGuard Academy commencement \u2192 http:\/\/t.co\/qQ2JbRg9UN",
    "id" : 601050506367213568,
    "created_at" : "2015-05-20 15:43:02 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 601050533043032064,
  "created_at" : "2015-05-20 15:43:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/601038827503919104\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/l6ebztVczK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CFdRXb_WMAAe4JC.jpg",
      "id_str" : "601038538369544192",
      "id" : 601038538369544192,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFdRXb_WMAAe4JC.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/l6ebztVczK"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/M6OYZLgkSB",
      "expanded_url" : "http:\/\/go.wh.gov\/r8gaZV",
      "display_url" : "go.wh.gov\/r8gaZV"
    } ]
  },
  "geo" : { },
  "id_str" : "601038827503919104",
  "text" : "Watch President Obama speak at the Coast Guard Academy commencement at 11:35am ET \u2192 http:\/\/t.co\/M6OYZLgkSB http:\/\/t.co\/l6ebztVczK",
  "id" : 601038827503919104,
  "created_at" : "2015-05-20 14:56:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 17, 23 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GimmeFive",
      "indices" : [ 41, 51 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 90 ],
      "url" : "https:\/\/t.co\/YF8nEtjUIA",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/40babd2e-9320-4fec-b94d-f769d6690fd6",
      "display_url" : "amp.twimg.com\/v\/40babd2e-932\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "600862896789266432",
  "text" : "RT @FLOTUS: Hey, @POTUS! This is how you #GimmeFive, FLOTUS-style\u2026\nhttps:\/\/t.co\/YF8nEtjUIA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 5, 11 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GimmeFive",
        "indices" : [ 29, 39 ]
      } ],
      "urls" : [ {
        "indices" : [ 55, 78 ],
        "url" : "https:\/\/t.co\/YF8nEtjUIA",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/40babd2e-9320-4fec-b94d-f769d6690fd6",
        "display_url" : "amp.twimg.com\/v\/40babd2e-932\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "600837307919302656",
    "text" : "Hey, @POTUS! This is how you #GimmeFive, FLOTUS-style\u2026\nhttps:\/\/t.co\/YF8nEtjUIA",
    "id" : 600837307919302656,
    "created_at" : "2015-05-20 01:35:51 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 600862896789266432,
  "created_at" : "2015-05-20 03:17:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/600809892501450752\/photo\/1",
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/RrdcMrK4t7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CFaBUgUWgAAUWpn.jpg",
      "id_str" : "600809789573201920",
      "id" : 600809789573201920,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFaBUgUWgAAUWpn.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/RrdcMrK4t7"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 30, 43 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/YD9G6URXN6",
      "expanded_url" : "http:\/\/go.wh.gov\/g6FVit",
      "display_url" : "go.wh.gov\/g6FVit"
    } ]
  },
  "geo" : { },
  "id_str" : "600809892501450752",
  "text" : "RT if you agree: It's time to #ActOnClimate by investing in clean energy \u2192 http:\/\/t.co\/YD9G6URXN6 http:\/\/t.co\/RrdcMrK4t7",
  "id" : 600809892501450752,
  "created_at" : "2015-05-19 23:46:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 47, 53 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/n5sJDWgV5w",
      "expanded_url" : "http:\/\/snpy.tv\/1JXpGTk",
      "display_url" : "snpy.tv\/1JXpGTk"
    } ]
  },
  "geo" : { },
  "id_str" : "600797284205461504",
  "text" : "\"If it\u2019s working here, it can work anywhere.\" \u2014@POTUS in Camden on steps we can take to improve community policing http:\/\/t.co\/n5sJDWgV5w",
  "id" : 600797284205461504,
  "created_at" : "2015-05-19 22:56:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Eric Garcetti",
      "screen_name" : "ericgarcetti",
      "indices" : [ 114, 127 ],
      "id_str" : "17358750",
      "id" : 17358750
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 43, 56 ]
    }, {
      "text" : "LA",
      "indices" : [ 60, 63 ]
    }, {
      "text" : "FamiliesSucceed",
      "indices" : [ 87, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600774129948762112",
  "text" : "RT @vj44: RT if you agree: Today\u2019s vote to #RaiseTheWage in #LA is a huge step to help #FamiliesSucceed. Congrats @ericgarcetti!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Eric Garcetti",
        "screen_name" : "ericgarcetti",
        "indices" : [ 104, 117 ],
        "id_str" : "17358750",
        "id" : 17358750
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RaiseTheWage",
        "indices" : [ 33, 46 ]
      }, {
        "text" : "LA",
        "indices" : [ 50, 53 ]
      }, {
        "text" : "FamiliesSucceed",
        "indices" : [ 77, 93 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "600770238020329472",
    "text" : "RT if you agree: Today\u2019s vote to #RaiseTheWage in #LA is a huge step to help #FamiliesSucceed. Congrats @ericgarcetti!",
    "id" : 600770238020329472,
    "created_at" : "2015-05-19 21:09:21 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 600774129948762112,
  "created_at" : "2015-05-19 21:24:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DJ Patil",
      "screen_name" : "DJ44",
      "indices" : [ 3, 8 ],
      "id_str" : "3030922321",
      "id" : 3030922321
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 70, 81 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600760576558505985",
  "text" : "RT @DJ44: Tomorrow @ 4pm Est. I'll be doing a Twitter Q\/A here at the @WhiteHouse on the Police Data Initiative. Let's talk data &amp; communit\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 60, 71 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "600732537670017024",
    "text" : "Tomorrow @ 4pm Est. I'll be doing a Twitter Q\/A here at the @WhiteHouse on the Police Data Initiative. Let's talk data &amp; community policing!",
    "id" : 600732537670017024,
    "created_at" : "2015-05-19 18:39:32 +0000",
    "user" : {
      "name" : "DJ Patil",
      "screen_name" : "DJ44",
      "protected" : false,
      "id_str" : "3030922321",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/570697565977313280\/aoCw1bC5_normal.jpeg",
      "id" : 3030922321,
      "verified" : true
    }
  },
  "id" : 600760576558505985,
  "created_at" : "2015-05-19 20:30:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Kelly",
      "screen_name" : "StationCDRKelly",
      "indices" : [ 3, 19 ],
      "id_str" : "65647594",
      "id" : 65647594
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 22, 28 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 40, 48 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IG",
      "indices" : [ 80, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600757183639195648",
  "text" : "RT @StationCDRKelly: .@POTUS Welcome to @Twitter, Mr. President. You told me to #IG my mission up here Glad to see you tweeting down there \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 1, 7 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "Twitter",
        "screen_name" : "twitter",
        "indices" : [ 19, 27 ],
        "id_str" : "783214",
        "id" : 783214
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/StationCDRKelly\/status\/600738668798726144\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/ahJtvgldsa",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CFZAorfUUAAlLsT.jpg",
        "id_str" : "600738667913564160",
        "id" : 600738667913564160,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFZAorfUUAAlLsT.jpg",
        "sizes" : [ {
          "h" : 1065,
          "resize" : "fit",
          "w" : 1600
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/ahJtvgldsa"
      } ],
      "hashtags" : [ {
        "text" : "IG",
        "indices" : [ 59, 62 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "600738668798726144",
    "text" : ".@POTUS Welcome to @Twitter, Mr. President. You told me to #IG my mission up here Glad to see you tweeting down there http:\/\/t.co\/ahJtvgldsa",
    "id" : 600738668798726144,
    "created_at" : "2015-05-19 19:03:54 +0000",
    "user" : {
      "name" : "Scott Kelly",
      "screen_name" : "StationCDRKelly",
      "protected" : false,
      "id_str" : "65647594",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/558447158597136385\/P9TpCaRn_normal.jpeg",
      "id" : 65647594,
      "verified" : true
    }
  },
  "id" : 600757183639195648,
  "created_at" : "2015-05-19 20:17:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600713980676612097",
  "text" : "RT @VP: No matter what you do or where you go, we're all striving for the sweet spot that satisfies both success &amp; happiness https:\/\/t.co\/5\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/5gFDdjAhlo",
        "expanded_url" : "https:\/\/medium.com\/@VPOTUS\/what-i-told-college-graduates-55c941fd1272",
        "display_url" : "medium.com\/@VPOTUS\/what-i\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "600713594985132032",
    "text" : "No matter what you do or where you go, we're all striving for the sweet spot that satisfies both success &amp; happiness https:\/\/t.co\/5gFDdjAhlo",
    "id" : 600713594985132032,
    "created_at" : "2015-05-19 17:24:16 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 600713980676612097,
  "created_at" : "2015-05-19 17:25:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/600686844112740352\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/7VgxVI4VCn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CFYRNaCW8AEgV15.jpg",
      "id_str" : "600686522325725185",
      "id" : 600686522325725185,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFYRNaCW8AEgV15.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1867,
        "resize" : "fit",
        "w" : 2800
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/7VgxVI4VCn"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/BKFzWuIAjy",
      "expanded_url" : "http:\/\/go.wh.gov\/G2vAMy",
      "display_url" : "go.wh.gov\/G2vAMy"
    } ]
  },
  "geo" : { },
  "id_str" : "600686844112740352",
  "text" : "\"Kids who grow up here\u2014they're America\u2019s children. Just like children everyplace else\" \u2014Obama: http:\/\/t.co\/BKFzWuIAjy http:\/\/t.co\/7VgxVI4VCn",
  "id" : 600686844112740352,
  "created_at" : "2015-05-19 15:37:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouseostp\/status\/600649093287784448\/photo\/1",
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/CmDUbDTvjr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CFXvKp2UgAEiOCf.jpg",
      "id_str" : "600649091635249153",
      "id" : 600649091635249153,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFXvKp2UgAEiOCf.jpg",
      "sizes" : [ {
        "h" : 295,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 889,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2344,
        "resize" : "fit",
        "w" : 2700
      }, {
        "h" : 521,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/CmDUbDTvjr"
    } ],
    "hashtags" : [ {
      "text" : "PollinatorHealth",
      "indices" : [ 52, 69 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/GdDafMvKhY",
      "expanded_url" : "http:\/\/wh.gov\/iKpjr",
      "display_url" : "wh.gov\/iKpjr"
    } ]
  },
  "geo" : { },
  "id_str" : "600660194880856065",
  "text" : "RT @whitehouseostp: Announcing New Steps to Promote #PollinatorHealth \u2192 http:\/\/t.co\/GdDafMvKhY http:\/\/t.co\/CmDUbDTvjr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/whitehouseostp\/status\/600649093287784448\/photo\/1",
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/CmDUbDTvjr",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CFXvKp2UgAEiOCf.jpg",
        "id_str" : "600649091635249153",
        "id" : 600649091635249153,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFXvKp2UgAEiOCf.jpg",
        "sizes" : [ {
          "h" : 295,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 889,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 2344,
          "resize" : "fit",
          "w" : 2700
        }, {
          "h" : 521,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/CmDUbDTvjr"
      } ],
      "hashtags" : [ {
        "text" : "PollinatorHealth",
        "indices" : [ 32, 49 ]
      } ],
      "urls" : [ {
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/GdDafMvKhY",
        "expanded_url" : "http:\/\/wh.gov\/iKpjr",
        "display_url" : "wh.gov\/iKpjr"
      } ]
    },
    "geo" : { },
    "id_str" : "600649093287784448",
    "text" : "Announcing New Steps to Promote #PollinatorHealth \u2192 http:\/\/t.co\/GdDafMvKhY http:\/\/t.co\/CmDUbDTvjr",
    "id" : 600649093287784448,
    "created_at" : "2015-05-19 13:07:58 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 600660194880856065,
  "created_at" : "2015-05-19 13:52:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Office of Head Start",
      "screen_name" : "HeadStartgov",
      "indices" : [ 22, 35 ],
      "id_str" : "369697377",
      "id" : 369697377
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/5r9Ip9gxWi",
      "expanded_url" : "http:\/\/go.wh.gov\/p7i4AR",
      "display_url" : "go.wh.gov\/p7i4AR"
    }, {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/eNvogDQSTe",
      "expanded_url" : "https:\/\/youtu.be\/_5FpGEtMqyE",
      "display_url" : "youtu.be\/_5FpGEtMqyE"
    } ]
  },
  "geo" : { },
  "id_str" : "600447430052683777",
  "text" : "Celebrate 50 years of @HeadStartGov with President Obama and these cute kids from Kansas \u2192 http:\/\/t.co\/5r9Ip9gxWi https:\/\/t.co\/eNvogDQSTe",
  "id" : 600447430052683777,
  "created_at" : "2015-05-18 23:46:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chicago Bulls",
      "screen_name" : "chicagobulls",
      "indices" : [ 3, 16 ],
      "id_str" : "16212685",
      "id" : 16212685
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 38, 44 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/chicagobulls\/status\/600364178142986240\/photo\/1",
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/kvrHzczKNT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CFTsCdpW0AAqQq2.jpg",
      "id_str" : "600364177409101824",
      "id" : 600364177409101824,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFTsCdpW0AAqQq2.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 2731,
        "resize" : "fit",
        "w" : 4096
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/kvrHzczKNT"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600429224273391617",
  "text" : "RT @chicagobulls: Welcome to Twitter, @POTUS. Thanks for the follow! http:\/\/t.co\/kvrHzczKNT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 20, 26 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/chicagobulls\/status\/600364178142986240\/photo\/1",
        "indices" : [ 51, 73 ],
        "url" : "http:\/\/t.co\/kvrHzczKNT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CFTsCdpW0AAqQq2.jpg",
        "id_str" : "600364177409101824",
        "id" : 600364177409101824,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFTsCdpW0AAqQq2.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 2731,
          "resize" : "fit",
          "w" : 4096
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/kvrHzczKNT"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "600364178142986240",
    "text" : "Welcome to Twitter, @POTUS. Thanks for the follow! http:\/\/t.co\/kvrHzczKNT",
    "id" : 600364178142986240,
    "created_at" : "2015-05-18 18:15:48 +0000",
    "user" : {
      "name" : "Chicago Bulls",
      "screen_name" : "chicagobulls",
      "protected" : false,
      "id_str" : "16212685",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/720996654459916288\/b1UOVsPt_normal.jpg",
      "id" : 16212685,
      "verified" : true
    }
  },
  "id" : 600429224273391617,
  "created_at" : "2015-05-18 22:34:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/POTUS\/status\/600388258665787392\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/3MiWk43c8g",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CFUB5piUkAADw6g.jpg",
      "id_str" : "600388215237808128",
      "id" : 600388215237808128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFUB5piUkAADw6g.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/3MiWk43c8g"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600388564430540800",
  "text" : "RT @POTUS: In Camden today, seeing first-hand how smart policing is making the community safer while building trust. http:\/\/t.co\/3MiWk43c8g",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/POTUS\/status\/600388258665787392\/photo\/1",
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/3MiWk43c8g",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CFUB5piUkAADw6g.jpg",
        "id_str" : "600388215237808128",
        "id" : 600388215237808128,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFUB5piUkAADw6g.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/3MiWk43c8g"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "600388258665787392",
    "text" : "In Camden today, seeing first-hand how smart policing is making the community safer while building trust. http:\/\/t.co\/3MiWk43c8g",
    "id" : 600388258665787392,
    "created_at" : "2015-05-18 19:51:30 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 600388564430540800,
  "created_at" : "2015-05-18 19:52:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 48, 54 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FollowTheTweets",
      "indices" : [ 56, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/N8JxY8kQIE",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/75525a97-9045-453a-bea3-49b9576e7ca0",
      "display_url" : "amp.twimg.com\/v\/75525a97-904\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "600387003503415296",
  "text" : "Watch President Obama send his first tweet from @POTUS. #FollowTheTweets\nhttps:\/\/t.co\/N8JxY8kQIE",
  "id" : 600387003503415296,
  "created_at" : "2015-05-18 19:46:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chicago Bears",
      "screen_name" : "ChicagoBears",
      "indices" : [ 3, 16 ],
      "id_str" : "47964412",
      "id" : 47964412
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 57, 63 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600385049737994240",
  "text" : "RT @ChicagoBears: Thanks for the follow and your loyalty @POTUS ... Hope to see you (again) at Oval Office after 2015 NFL season! http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 39, 45 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ChicagoBears\/status\/600373712601358336\/photo\/1",
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/pWPE0t8xJd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CFT0tc2XIAAN2Dd.jpg",
        "id_str" : "600373712022609920",
        "id" : 600373712022609920,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFT0tc2XIAAN2Dd.jpg",
        "sizes" : [ {
          "h" : 214,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 479,
          "resize" : "fit",
          "w" : 760
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 378,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 479,
          "resize" : "fit",
          "w" : 760
        } ],
        "display_url" : "pic.twitter.com\/pWPE0t8xJd"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "600373712601358336",
    "text" : "Thanks for the follow and your loyalty @POTUS ... Hope to see you (again) at Oval Office after 2015 NFL season! http:\/\/t.co\/pWPE0t8xJd",
    "id" : 600373712601358336,
    "created_at" : "2015-05-18 18:53:42 +0000",
    "user" : {
      "name" : "Chicago Bears",
      "screen_name" : "ChicagoBears",
      "protected" : false,
      "id_str" : "47964412",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794258369552977921\/XEa5g9FK_normal.jpg",
      "id" : 47964412,
      "verified" : true
    }
  },
  "id" : 600385049737994240,
  "created_at" : "2015-05-18 19:38:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 76, 82 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600379602595401728",
  "text" : "\"That\u2019s how we\u2019re going to measure change. Rising prospects for our kids.\" \u2014@POTUS in Camden",
  "id" : 600379602595401728,
  "created_at" : "2015-05-18 19:17:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600374992090595328",
  "text" : "\"The kids who grow up here, they\u2019re America\u2019s children, too.\" \u2014Obama in Camden, NJ on the need to expand opportunity in every community",
  "id" : 600374992090595328,
  "created_at" : "2015-05-18 18:58:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600373959603920896",
  "text" : "\"We cannot ask the police to contain and control problems that the rest of us are unwilling to face.\" \u2014President Obama in Camden",
  "id" : 600373959603920896,
  "created_at" : "2015-05-18 18:54:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600373489426681858",
  "text" : "\"The overwhelming majority of police officers are good and honest and fair. They care deeply about their communities.\" \u2014President Obama",
  "id" : 600373489426681858,
  "created_at" : "2015-05-18 18:52:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600372205273403392",
  "text" : "RT @WHLive: \"Nobody is suggesting that the job is done...Camden and its people still face some big challenges. But this city is on to somet\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "600372157533835264",
    "text" : "\"Nobody is suggesting that the job is done...Camden and its people still face some big challenges. But this city is on to something.\" \u2014Obama",
    "id" : 600372157533835264,
    "created_at" : "2015-05-18 18:47:31 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 600372205273403392,
  "created_at" : "2015-05-18 18:47:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600371911646978048",
  "text" : "\"Violent crime in Camden is down 24%. Murder is down 47%. Open-air drug markets have been cut by 65%\" \u2014President Obama on progress in Camden",
  "id" : 600371911646978048,
  "created_at" : "2015-05-18 18:46:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600371523384410112",
  "text" : "RT @WHLive: \"I\u2019ve come to Camden today to...hold you up as a symbol of promise for the nation.\" \u2014President Obama on the progress that Camde\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "600371492979879936",
    "text" : "\"I\u2019ve come to Camden today to...hold you up as a symbol of promise for the nation.\" \u2014President Obama on the progress that Camden has made",
    "id" : 600371492979879936,
    "created_at" : "2015-05-18 18:44:52 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 600371523384410112,
  "created_at" : "2015-05-18 18:45:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/CJuYNYGGAL",
      "expanded_url" : "http:\/\/go.wh.gov\/8bUzdL",
      "display_url" : "go.wh.gov\/8bUzdL"
    } ]
  },
  "geo" : { },
  "id_str" : "600371088292454400",
  "text" : "Watch live: President Obama speaks at a community policing event in Camden, NJ \u2192 http:\/\/t.co\/CJuYNYGGAL",
  "id" : 600371088292454400,
  "created_at" : "2015-05-18 18:43:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chicago White Sox",
      "screen_name" : "whitesox",
      "indices" : [ 3, 12 ],
      "id_str" : "53197137",
      "id" : 53197137
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 15, 21 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitesox\/status\/600336652796612610\/photo\/1",
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/Ou0VvCf5G8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CFTTAIrWoAAHei0.jpg",
      "id_str" : "600336649629900800",
      "id" : 600336649629900800,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFTTAIrWoAAHei0.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 682
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 682
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 901,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/Ou0VvCf5G8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600369558399029248",
  "text" : "RT @whitesox: .@POTUS thanks for the follow! \uD83D\uDC4D http:\/\/t.co\/Ou0VvCf5G8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 1, 7 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/whitesox\/status\/600336652796612610\/photo\/1",
        "indices" : [ 33, 55 ],
        "url" : "http:\/\/t.co\/Ou0VvCf5G8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CFTTAIrWoAAHei0.jpg",
        "id_str" : "600336649629900800",
        "id" : 600336649629900800,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFTTAIrWoAAHei0.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 682
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 682
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 901,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/Ou0VvCf5G8"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "600336652796612610",
    "text" : ".@POTUS thanks for the follow! \uD83D\uDC4D http:\/\/t.co\/Ou0VvCf5G8",
    "id" : 600336652796612610,
    "created_at" : "2015-05-18 16:26:26 +0000",
    "user" : {
      "name" : "Chicago White Sox",
      "screen_name" : "whitesox",
      "protected" : false,
      "id_str" : "53197137",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/789484084456194049\/236roEHv_normal.jpg",
      "id" : 53197137,
      "verified" : true
    }
  },
  "id" : 600369558399029248,
  "created_at" : "2015-05-18 18:37:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 3, 11 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/JXHxgJNVdB",
      "expanded_url" : "https:\/\/twitter.com\/POTUS\/status\/600324682190053376",
      "display_url" : "twitter.com\/POTUS\/status\/6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "600367120296386562",
  "text" : "RT @twitter: Welcome, Mr. President! \uD83C\uDDFA\uD83C\uDDF8 https:\/\/t.co\/JXHxgJNVdB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 27, 50 ],
        "url" : "https:\/\/t.co\/JXHxgJNVdB",
        "expanded_url" : "https:\/\/twitter.com\/POTUS\/status\/600324682190053376",
        "display_url" : "twitter.com\/POTUS\/status\/6\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "600359093128208385",
    "text" : "Welcome, Mr. President! \uD83C\uDDFA\uD83C\uDDF8 https:\/\/t.co\/JXHxgJNVdB",
    "id" : 600359093128208385,
    "created_at" : "2015-05-18 17:55:36 +0000",
    "user" : {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "protected" : false,
      "id_str" : "783214",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/767879603977191425\/29zfZY6I_normal.jpg",
      "id" : 783214,
      "verified" : true
    }
  },
  "id" : 600367120296386562,
  "created_at" : "2015-05-18 18:27:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Camden County Police",
      "screen_name" : "CamdenCountyPD",
      "indices" : [ 3, 18 ],
      "id_str" : "1117740558",
      "id" : 1117740558
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 57, 63 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600358882523947010",
  "text" : "RT @CamdenCountyPD: We're honored and excited to welcome @POTUS to Camden this afternoon to talk about community policing. http:\/\/t.co\/RpBK\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 37, 43 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CamdenCountyPD\/status\/600337588864421889\/photo\/1",
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/RpBK69GAEc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CFTT0KqVAAAGV5d.jpg",
        "id_str" : "600337543515668480",
        "id" : 600337543515668480,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFTT0KqVAAAGV5d.jpg",
        "sizes" : [ {
          "h" : 866,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 491,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 914,
          "resize" : "fit",
          "w" : 633
        }, {
          "h" : 914,
          "resize" : "fit",
          "w" : 633
        } ],
        "display_url" : "pic.twitter.com\/RpBK69GAEc"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/CamdenCountyPD\/status\/600337588864421889\/photo\/1",
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/RpBK69GAEc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CFTT2t8VIAA6rOL.jpg",
        "id_str" : "600337587346153472",
        "id" : 600337587346153472,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFTT2t8VIAA6rOL.jpg",
        "sizes" : [ {
          "h" : 758,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 252,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 444,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2591,
          "resize" : "fit",
          "w" : 3500
        } ],
        "display_url" : "pic.twitter.com\/RpBK69GAEc"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/CamdenCountyPD\/status\/600337588864421889\/photo\/1",
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/RpBK69GAEc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CFTT1ZyUsAAa0fQ.jpg",
        "id_str" : "600337564755603456",
        "id" : 600337564755603456,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFTT1ZyUsAAa0fQ.jpg",
        "sizes" : [ {
          "h" : 464,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 263,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 2105,
          "resize" : "fit",
          "w" : 2721
        }, {
          "h" : 792,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/RpBK69GAEc"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/CamdenCountyPD\/status\/600337588864421889\/photo\/1",
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/RpBK69GAEc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CFTT0AdUMAA4TCY.jpg",
        "id_str" : "600337540776734720",
        "id" : 600337540776734720,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFTT0AdUMAA4TCY.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 810,
          "resize" : "fit",
          "w" : 1080
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/RpBK69GAEc"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "600337588864421889",
    "text" : "We're honored and excited to welcome @POTUS to Camden this afternoon to talk about community policing. http:\/\/t.co\/RpBK69GAEc",
    "id" : 600337588864421889,
    "created_at" : "2015-05-18 16:30:09 +0000",
    "user" : {
      "name" : "Camden County Police",
      "screen_name" : "CamdenCountyPD",
      "protected" : false,
      "id_str" : "1117740558",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/754653028423196672\/JpWgn-FQ_normal.jpg",
      "id" : 1117740558,
      "verified" : false
    }
  },
  "id" : 600358882523947010,
  "created_at" : "2015-05-18 17:54:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 66, 72 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/600349047329857537\/photo\/1",
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/ce4DurwYXj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CFTd1Q6WIAA1Bvl.jpg",
      "id_str" : "600348557489610752",
      "id" : 600348557489610752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFTd1Q6WIAA1Bvl.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1867,
        "resize" : "fit",
        "w" : 2800
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/ce4DurwYXj"
    } ],
    "hashtags" : [ {
      "text" : "WelcomeToTwitter",
      "indices" : [ 47, 64 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/SzWXltjNK0",
      "expanded_url" : "http:\/\/go.wh.gov\/POTUS-twitter",
      "display_url" : "go.wh.gov\/POTUS-twitter"
    } ]
  },
  "geo" : { },
  "id_str" : "600349047329857537",
  "text" : "President Obama.\nIn the Oval Office.\nTweeting.\n#WelcomeToTwitter, @POTUS!\nhttp:\/\/t.co\/SzWXltjNK0 http:\/\/t.co\/ce4DurwYXj",
  "id" : 600349047329857537,
  "created_at" : "2015-05-18 17:15:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 29, 35 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600346308218638337",
  "text" : "RT @FLOTUS: It's about time, @POTUS! \u2013mo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 17, 23 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "600345440647778305",
    "text" : "It's about time, @POTUS! \u2013mo",
    "id" : 600345440647778305,
    "created_at" : "2015-05-18 17:01:21 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 600346308218638337,
  "created_at" : "2015-05-18 17:04:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/SrlAbK3rfK",
      "expanded_url" : "https:\/\/twitter.com\/potus\/status\/600324682190053376",
      "display_url" : "twitter.com\/potus\/status\/6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "600333775395004416",
  "text" : "RT @vj44: The bear is loose on the Twittersphere!  Welcome to the interwebs, Mr. President. https:\/\/t.co\/SrlAbK3rfK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/SrlAbK3rfK",
        "expanded_url" : "https:\/\/twitter.com\/potus\/status\/600324682190053376",
        "display_url" : "twitter.com\/potus\/status\/6\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "600333148648566785",
    "text" : "The bear is loose on the Twittersphere!  Welcome to the interwebs, Mr. President. https:\/\/t.co\/SrlAbK3rfK",
    "id" : 600333148648566785,
    "created_at" : "2015-05-18 16:12:30 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 600333775395004416,
  "created_at" : "2015-05-18 16:15:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 12, 18 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/VP\/status\/600331188847251456\/photo\/1",
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/iaUVFtQVpk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CFTOCI3VAAIRw4D.jpg",
      "id_str" : "600331186481725442",
      "id" : 600331186481725442,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFTOCI3VAAIRw4D.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1867,
        "resize" : "fit",
        "w" : 2800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/iaUVFtQVpk"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600331892030857216",
  "text" : "RT @VP: Hey @POTUS \u2013 Welcome to Twitter. See you around the neighborhood. \u2013vp http:\/\/t.co\/iaUVFtQVpk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 4, 10 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/600331188847251456\/photo\/1",
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/iaUVFtQVpk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CFTOCI3VAAIRw4D.jpg",
        "id_str" : "600331186481725442",
        "id" : 600331186481725442,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFTOCI3VAAIRw4D.jpg",
        "sizes" : [ {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1867,
          "resize" : "fit",
          "w" : 2800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/iaUVFtQVpk"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "600331188847251456",
    "text" : "Hey @POTUS \u2013 Welcome to Twitter. See you around the neighborhood. \u2013vp http:\/\/t.co\/iaUVFtQVpk",
    "id" : 600331188847251456,
    "created_at" : "2015-05-18 16:04:43 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 600331892030857216,
  "created_at" : "2015-05-18 16:07:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 40, 46 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WelcomeToTwitter",
      "indices" : [ 99, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/oMsgvV55i1",
      "expanded_url" : "https:\/\/twitter.com\/POTUS\/status\/600324682190053376",
      "display_url" : "twitter.com\/POTUS\/status\/6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "600325094200778753",
  "text" : "BREAKING: President Obama just launched @POTUS with a tweet from the Oval Office. It's really him! #WelcomeToTwitter https:\/\/t.co\/oMsgvV55i1",
  "id" : 600325094200778753,
  "created_at" : "2015-05-18 15:40:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600324735876993024",
  "text" : "RT @POTUS: Hello, Twitter! It's Barack. Really! Six years in, they're finally giving me my own account.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "600324682190053376",
    "text" : "Hello, Twitter! It's Barack. Really! Six years in, they're finally giving me my own account.",
    "id" : 600324682190053376,
    "created_at" : "2015-05-18 15:38:52 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 600324735876993024,
  "created_at" : "2015-05-18 15:39:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WestWingWeek",
      "indices" : [ 121, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/SOkI16xamT",
      "expanded_url" : "https:\/\/youtu.be\/lPDnklPKWUE",
      "display_url" : "youtu.be\/lPDnklPKWUE"
    } ]
  },
  "geo" : { },
  "id_str" : "600088456891531264",
  "text" : "\"I didn\u2019t come here to inspire you. I came here because you, the graduates, inspire me.\" \u2014Obama: https:\/\/t.co\/SOkI16xamT #WestWingWeek",
  "id" : 600088456891531264,
  "created_at" : "2015-05-18 00:00:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600055625540853760",
  "text" : "RT @VP: \"No one is better than you, everyone is your equal and deserves to be treated with dignity &amp; respect.\" -VP Biden to college graduat\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "600018453508923393",
    "text" : "\"No one is better than you, everyone is your equal and deserves to be treated with dignity &amp; respect.\" -VP Biden to college graduates",
    "id" : 600018453508923393,
    "created_at" : "2015-05-17 19:22:01 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 600055625540853760,
  "created_at" : "2015-05-17 21:49:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "600051291562311680",
  "text" : "RT @VP: \"You can absolutely succeed in life without ever sacrificing your ideals or your commitment to others &amp; family.\" -VP Biden to colle\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "600022011499442178",
    "text" : "\"You can absolutely succeed in life without ever sacrificing your ideals or your commitment to others &amp; family.\" -VP Biden to college grads",
    "id" : 600022011499442178,
    "created_at" : "2015-05-17 19:36:10 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 600051291562311680,
  "created_at" : "2015-05-17 21:32:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 80, 87 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GimmeFive",
      "indices" : [ 18, 28 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/H9uBo6nlkj",
      "expanded_url" : "http:\/\/go.wh.gov\/TvKhkV",
      "display_url" : "go.wh.gov\/TvKhkV"
    } ]
  },
  "geo" : { },
  "id_str" : "599958328622612480",
  "text" : "RT @FLOTUS: Got a #GimmeFive challenge for the First Lady? Let\u2019s hear it! Tweet @FLOTUS today \u2192 http:\/\/t.co\/H9uBo6nlkj https:\/\/t.co\/Bs0MbXR\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The First Lady",
        "screen_name" : "FLOTUS",
        "indices" : [ 68, 75 ],
        "id_str" : "1093090866",
        "id" : 1093090866
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GimmeFive",
        "indices" : [ 6, 16 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/H9uBo6nlkj",
        "expanded_url" : "http:\/\/go.wh.gov\/TvKhkV",
        "display_url" : "go.wh.gov\/TvKhkV"
      }, {
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/Bs0MbXRhNg",
        "expanded_url" : "https:\/\/youtu.be\/g5FMvvKNH1I",
        "display_url" : "youtu.be\/g5FMvvKNH1I"
      } ]
    },
    "geo" : { },
    "id_str" : "599950470518591489",
    "text" : "Got a #GimmeFive challenge for the First Lady? Let\u2019s hear it! Tweet @FLOTUS today \u2192 http:\/\/t.co\/H9uBo6nlkj https:\/\/t.co\/Bs0MbXRhNg",
    "id" : 599950470518591489,
    "created_at" : "2015-05-17 14:51:53 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 599958328622612480,
  "created_at" : "2015-05-17 15:23:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/599678546404057088\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/oDe79ccSEp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CFJ67UIW0AEcMXF.png",
      "id_str" : "599676859828326401",
      "id" : 599676859828326401,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFJ67UIW0AEcMXF.png",
      "sizes" : [ {
        "h" : 324,
        "resize" : "fit",
        "w" : 852
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 228,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 129,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 324,
        "resize" : "fit",
        "w" : 852
      } ],
      "display_url" : "pic.twitter.com\/oDe79ccSEp"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "599678546404057088",
  "text" : "RT if you agree: All people deserve to live free from fear, violence and discrimination, regardless of who they love. http:\/\/t.co\/oDe79ccSEp",
  "id" : 599678546404057088,
  "created_at" : "2015-05-16 20:51:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ArmedForcesDay",
      "indices" : [ 113, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "599676469367992320",
  "text" : "RT @VP: America salutes the men &amp; women of the armed forces for their honorable service to our great nation. #ArmedForcesDay http:\/\/t.co\/4o\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/VP\/status\/599671146175287296\/photo\/1",
        "indices" : [ 121, 143 ],
        "url" : "http:\/\/t.co\/4o7pDIV9Qs",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CFJ1um_UIAA9Ct6.jpg",
        "id_str" : "599671143994236928",
        "id" : 599671143994236928,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFJ1um_UIAA9Ct6.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1333,
          "resize" : "fit",
          "w" : 2000
        } ],
        "display_url" : "pic.twitter.com\/4o7pDIV9Qs"
      } ],
      "hashtags" : [ {
        "text" : "ArmedForcesDay",
        "indices" : [ 105, 120 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "599671146175287296",
    "text" : "America salutes the men &amp; women of the armed forces for their honorable service to our great nation. #ArmedForcesDay http:\/\/t.co\/4o7pDIV9Qs",
    "id" : 599671146175287296,
    "created_at" : "2015-05-16 20:21:57 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 599676469367992320,
  "created_at" : "2015-05-16 20:43:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 113, 120 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GimmeFive",
      "indices" : [ 59, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "599669226631241728",
  "text" : "RT @FLOTUS: The President has challenged the First Lady to #GimmeFive \u201CFLOTUS-style.\u201D Tell us your challenge for @FLOTUS \u2192 https:\/\/t.co\/Bs0\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The First Lady",
        "screen_name" : "FLOTUS",
        "indices" : [ 101, 108 ],
        "id_str" : "1093090866",
        "id" : 1093090866
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GimmeFive",
        "indices" : [ 47, 57 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/Bs0MbY8SEO",
        "expanded_url" : "https:\/\/youtu.be\/g5FMvvKNH1I",
        "display_url" : "youtu.be\/g5FMvvKNH1I"
      } ]
    },
    "geo" : { },
    "id_str" : "599664380976836608",
    "text" : "The President has challenged the First Lady to #GimmeFive \u201CFLOTUS-style.\u201D Tell us your challenge for @FLOTUS \u2192 https:\/\/t.co\/Bs0MbY8SEO",
    "id" : 599664380976836608,
    "created_at" : "2015-05-16 19:55:04 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 599669226631241728,
  "created_at" : "2015-05-16 20:14:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Syria",
      "indices" : [ 65, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/R8nD5oNL6S",
      "expanded_url" : "http:\/\/wh.gov\/iKQPE",
      "display_url" : "wh.gov\/iKQPE"
    } ]
  },
  "geo" : { },
  "id_str" : "599628557179031552",
  "text" : "RT @NSCPress: White House statement on counter-ISIL operation in #Syria http:\/\/t.co\/R8nD5oNL6S",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Syria",
        "indices" : [ 51, 57 ]
      } ],
      "urls" : [ {
        "indices" : [ 58, 80 ],
        "url" : "http:\/\/t.co\/R8nD5oNL6S",
        "expanded_url" : "http:\/\/wh.gov\/iKQPE",
        "display_url" : "wh.gov\/iKQPE"
      } ]
    },
    "geo" : { },
    "id_str" : "599558660717678593",
    "text" : "White House statement on counter-ISIL operation in #Syria http:\/\/t.co\/R8nD5oNL6S",
    "id" : 599558660717678593,
    "created_at" : "2015-05-16 12:54:58 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 599628557179031552,
  "created_at" : "2015-05-16 17:32:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/Bza8ukrwpO",
      "expanded_url" : "http:\/\/go.wh.gov\/ZcGv6w",
      "display_url" : "go.wh.gov\/ZcGv6w"
    } ]
  },
  "geo" : { },
  "id_str" : "599605300736368641",
  "text" : "\"We have to do everything in our power to make this country\u2019s promise real for everyone willing to work for it.\" http:\/\/t.co\/Bza8ukrwpO",
  "id" : 599605300736368641,
  "created_at" : "2015-05-16 16:00:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Dept of Defense",
      "screen_name" : "DeptofDefense",
      "indices" : [ 3, 17 ],
      "id_str" : "66369181",
      "id" : 66369181
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ArmedForcesDay",
      "indices" : [ 25, 40 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/KuIue9CpWG",
      "expanded_url" : "http:\/\/go.usa.gov\/383QT",
      "display_url" : "go.usa.gov\/383QT"
    } ]
  },
  "geo" : { },
  "id_str" : "599594049666973698",
  "text" : "RT @DeptofDefense: Happy #ArmedForcesDay to those who answered the call to serve. We thank you today &amp; everyday. http:\/\/t.co\/KuIue9CpWG htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DeptofDefense\/status\/599544855988084736\/photo\/1",
        "indices" : [ 121, 143 ],
        "url" : "http:\/\/t.co\/dU06JKygMC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CFDpFNyXIAAbINA.jpg",
        "id_str" : "599235026249785344",
        "id" : 599235026249785344,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFDpFNyXIAAbINA.jpg",
        "sizes" : [ {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 575,
          "resize" : "fit",
          "w" : 1023
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 575,
          "resize" : "fit",
          "w" : 1023
        } ],
        "display_url" : "pic.twitter.com\/dU06JKygMC"
      } ],
      "hashtags" : [ {
        "text" : "ArmedForcesDay",
        "indices" : [ 6, 21 ]
      } ],
      "urls" : [ {
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/KuIue9CpWG",
        "expanded_url" : "http:\/\/go.usa.gov\/383QT",
        "display_url" : "go.usa.gov\/383QT"
      } ]
    },
    "geo" : { },
    "id_str" : "599544855988084736",
    "text" : "Happy #ArmedForcesDay to those who answered the call to serve. We thank you today &amp; everyday. http:\/\/t.co\/KuIue9CpWG http:\/\/t.co\/dU06JKygMC",
    "id" : 599544855988084736,
    "created_at" : "2015-05-16 12:00:07 +0000",
    "user" : {
      "name" : "U.S. Dept of Defense",
      "screen_name" : "DeptofDefense",
      "protected" : false,
      "id_str" : "66369181",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/533350546027995137\/b84VANoF_normal.png",
      "id" : 66369181,
      "verified" : true
    }
  },
  "id" : 599594049666973698,
  "created_at" : "2015-05-16 15:15:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/Bza8uk9Vyg",
      "expanded_url" : "http:\/\/go.wh.gov\/ZcGv6w",
      "display_url" : "go.wh.gov\/ZcGv6w"
    } ]
  },
  "geo" : { },
  "id_str" : "599585462249005057",
  "text" : "\"We all want our country to be one where hard work pays off and responsibility is rewarded.\" \u2014President Obama: http:\/\/t.co\/Bza8uk9Vyg",
  "id" : 599585462249005057,
  "created_at" : "2015-05-16 14:41:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/599351235267973120\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/3F9h7soH9h",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CFFR5wuW8AESO94.jpg",
      "id_str" : "599350278190723073",
      "id" : 599350278190723073,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFFR5wuW8AESO94.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1867,
        "resize" : "fit",
        "w" : 2800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/3F9h7soH9h"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/qu10CTjFZy",
      "expanded_url" : "http:\/\/go.wh.gov\/MaN9h5",
      "display_url" : "go.wh.gov\/MaN9h5"
    } ]
  },
  "geo" : { },
  "id_str" : "599351235267973120",
  "text" : "\u201CWe are here to honor heroes who lost their lives in the line of duty\" \u2014President Obama: http:\/\/t.co\/qu10CTjFZy http:\/\/t.co\/3F9h7soH9h",
  "id" : 599351235267973120,
  "created_at" : "2015-05-15 23:10:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KidsToParks",
      "indices" : [ 24, 36 ]
    }, {
      "text" : "FindYourPark",
      "indices" : [ 42, 55 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/uyaHiQvsgP",
      "expanded_url" : "http:\/\/FindYourPark.com",
      "display_url" : "FindYourPark.com"
    } ]
  },
  "geo" : { },
  "id_str" : "599345092533428224",
  "text" : "RT @FLOTUS: Tomorrow is #KidsToParks Day! #FindYourPark with your family and enjoy the great outdoors! http:\/\/t.co\/uyaHiQvsgP http:\/\/t.co\/r\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/FLOTUS\/status\/599343269714087936\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/rvAFXG04kd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CFFCY38WIAEUPxE.jpg",
        "id_str" : "599333220518338561",
        "id" : 599333220518338561,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFFCY38WIAEUPxE.jpg",
        "sizes" : [ {
          "h" : 260,
          "resize" : "fit",
          "w" : 520
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 260,
          "resize" : "fit",
          "w" : 520
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 260,
          "resize" : "fit",
          "w" : 520
        } ],
        "display_url" : "pic.twitter.com\/rvAFXG04kd"
      } ],
      "hashtags" : [ {
        "text" : "KidsToParks",
        "indices" : [ 12, 24 ]
      }, {
        "text" : "FindYourPark",
        "indices" : [ 30, 43 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/uyaHiQvsgP",
        "expanded_url" : "http:\/\/FindYourPark.com",
        "display_url" : "FindYourPark.com"
      } ]
    },
    "geo" : { },
    "id_str" : "599343269714087936",
    "text" : "Tomorrow is #KidsToParks Day! #FindYourPark with your family and enjoy the great outdoors! http:\/\/t.co\/uyaHiQvsgP http:\/\/t.co\/rvAFXG04kd",
    "id" : 599343269714087936,
    "created_at" : "2015-05-15 22:39:05 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 599345092533428224,
  "created_at" : "2015-05-15 22:46:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BBKing",
      "indices" : [ 75, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/ASs9ovvWrf",
      "expanded_url" : "http:\/\/go.wh.gov\/HRuGNp",
      "display_url" : "go.wh.gov\/HRuGNp"
    }, {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/e18l7Kf2Of",
      "expanded_url" : "https:\/\/youtu.be\/Z7x4ZS7ZZWc",
      "display_url" : "youtu.be\/Z7x4ZS7ZZWc"
    } ]
  },
  "geo" : { },
  "id_str" : "599240500227354624",
  "text" : "\"There's going to be one killer blues session in heaven tonight\" \u2014Obama on #BBKing's passing: http:\/\/t.co\/ASs9ovvWrf https:\/\/t.co\/e18l7Kf2Of",
  "id" : 599240500227354624,
  "created_at" : "2015-05-15 15:50:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "599234429278560256",
  "text" : "\"We can work harder\u2014as a nation\u2014to heal the rifts that still exist in some places between law enforcement &amp; the people you...protect\" \u2014Obama",
  "id" : 599234429278560256,
  "created_at" : "2015-05-15 15:26:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "599234214546931712",
  "text" : "\"We cannot erase every darkness or danger from the duty you\u2019ve chosen. We can offer you the support you need to be safer\" \u2014Obama to officers",
  "id" : 599234214546931712,
  "created_at" : "2015-05-15 15:25:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "599232635743834112",
  "text" : "\"Know how deeply grateful we are for your loved one\u2019s sacrifice\" \u2014President Obama to the families of officers who died in the line of duty",
  "id" : 599232635743834112,
  "created_at" : "2015-05-15 15:19:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "599232279165083649",
  "text" : "RT @WHLive: \"We are here to honor heroes who lost their lives in the line of duty; men and women who put themselves in the way of danger\" \u2014\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "599232252753543169",
    "text" : "\"We are here to honor heroes who lost their lives in the line of duty; men and women who put themselves in the way of danger\" \u2014Obama",
    "id" : 599232252753543169,
    "created_at" : "2015-05-15 15:17:56 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 599232279165083649,
  "created_at" : "2015-05-15 15:18:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/gSAHL2qVsh",
      "expanded_url" : "http:\/\/go.wh.gov\/yjyUvy",
      "display_url" : "go.wh.gov\/yjyUvy"
    } ]
  },
  "geo" : { },
  "id_str" : "599231768051388416",
  "text" : "Watch live: President Obama speaks at the National Peace Officers Memorial Service \u2192 http:\/\/t.co\/gSAHL2qVsh",
  "id" : 599231768051388416,
  "created_at" : "2015-05-15 15:16:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/599223874497064960\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/JWAl3vsFPQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CFDegMhWYAIcQtY.jpg",
      "id_str" : "599223395138560002",
      "id" : 599223395138560002,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CFDegMhWYAIcQtY.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      } ],
      "display_url" : "pic.twitter.com\/JWAl3vsFPQ"
    } ],
    "hashtags" : [ {
      "text" : "BBKing",
      "indices" : [ 86, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/ASs9ovvWrf",
      "expanded_url" : "http:\/\/go.wh.gov\/HRuGNp",
      "display_url" : "go.wh.gov\/HRuGNp"
    } ]
  },
  "geo" : { },
  "id_str" : "599223874497064960",
  "text" : "\"The blues has lost its king, and America has lost a legend\" \u2014Obama on the passing of #BBKing: http:\/\/t.co\/ASs9ovvWrf http:\/\/t.co\/JWAl3vsFPQ",
  "id" : 599223874497064960,
  "created_at" : "2015-05-15 14:44:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 3, 11 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    }, {
      "name" : "Charlotte Observer",
      "screen_name" : "theobserver",
      "indices" : [ 101, 113 ],
      "id_str" : "8695932",
      "id" : 8695932
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/1Q94yYUb3M",
      "expanded_url" : "http:\/\/bit.ly\/1bUbte5",
      "display_url" : "bit.ly\/1bUbte5"
    } ]
  },
  "geo" : { },
  "id_str" : "599210876093116417",
  "text" : "RT @DrBiden: RT if you agree \u2192  \"Jill Biden at CPCC: Community colleges are gateways to success\" via @theobserver http:\/\/t.co\/1Q94yYUb3M",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Charlotte Observer",
        "screen_name" : "theobserver",
        "indices" : [ 88, 100 ],
        "id_str" : "8695932",
        "id" : 8695932
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/1Q94yYUb3M",
        "expanded_url" : "http:\/\/bit.ly\/1bUbte5",
        "display_url" : "bit.ly\/1bUbte5"
      } ]
    },
    "geo" : { },
    "id_str" : "599207916885843969",
    "text" : "RT if you agree \u2192  \"Jill Biden at CPCC: Community colleges are gateways to success\" via @theobserver http:\/\/t.co\/1Q94yYUb3M",
    "id" : 599207916885843969,
    "created_at" : "2015-05-15 13:41:14 +0000",
    "user" : {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "protected" : false,
      "id_str" : "1281405877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608687663034474496\/wvzVG_yt_normal.jpg",
      "id" : 1281405877,
      "verified" : true
    }
  },
  "id" : 599210876093116417,
  "created_at" : "2015-05-15 13:53:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "indices" : [ 3, 13 ],
      "id_str" : "1613223313",
      "id" : 1613223313
    }, {
      "name" : "The Cabinet",
      "screen_name" : "Cabinet",
      "indices" : [ 45, 53 ],
      "id_str" : "1854981890",
      "id" : 1854981890
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "599015679245701121",
  "text" : "RT @Cecilia44: Proud of friend and colleague @Cabinet Secretary Broderick Johnson for his hard work &amp; his commitment to Baltimore. http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Cabinet",
        "screen_name" : "Cabinet",
        "indices" : [ 30, 38 ],
        "id_str" : "1854981890",
        "id" : 1854981890
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 142 ],
        "url" : "http:\/\/t.co\/xLcaSBOwPd",
        "expanded_url" : "http:\/\/goo.gl\/JvqBRZ",
        "display_url" : "goo.gl\/JvqBRZ"
      } ]
    },
    "geo" : { },
    "id_str" : "598878068514680832",
    "text" : "Proud of friend and colleague @Cabinet Secretary Broderick Johnson for his hard work &amp; his commitment to Baltimore. http:\/\/t.co\/xLcaSBOwPd",
    "id" : 598878068514680832,
    "created_at" : "2015-05-14 15:50:32 +0000",
    "user" : {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "protected" : false,
      "id_str" : "1613223313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000172019215\/ed65eda76f51213f91b33edbaa62054c_normal.jpeg",
      "id" : 1613223313,
      "verified" : true
    }
  },
  "id" : 599015679245701121,
  "created_at" : "2015-05-15 00:57:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/FpnK64PyiI",
      "expanded_url" : "http:\/\/snpy.tv\/1HjRPGw",
      "display_url" : "snpy.tv\/1HjRPGw"
    } ]
  },
  "geo" : { },
  "id_str" : "599000107992780800",
  "text" : "President Obama applauds the Senate on taking an important step toward a trade deal that benefits American workers. http:\/\/t.co\/FpnK64PyiI",
  "id" : 599000107992780800,
  "created_at" : "2015-05-14 23:55:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/598979871298101248\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/28mKR5M4fi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CE__eR5VEAAy6Uc.png",
      "id_str" : "598978171128582144",
      "id" : 598978171128582144,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CE__eR5VEAAy6Uc.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 526,
        "resize" : "fit",
        "w" : 935
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 526,
        "resize" : "fit",
        "w" : 935
      } ],
      "display_url" : "pic.twitter.com\/28mKR5M4fi"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598979871298101248",
  "text" : "\u201CI continue to believe that a two-state solution is absolutely vital\u201D \u2014Obama on the Israelis and Palestinians http:\/\/t.co\/28mKR5M4fi",
  "id" : 598979871298101248,
  "created_at" : "2015-05-14 22:35:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/598976792481824769\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/cGIoJy3t9s",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CE_-KGlUkAA3Woo.png",
      "id_str" : "598976724982861824",
      "id" : 598976724982861824,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CE_-KGlUkAA3Woo.png",
      "sizes" : [ {
        "h" : 524,
        "resize" : "fit",
        "w" : 935
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 336,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 524,
        "resize" : "fit",
        "w" : 935
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/cGIoJy3t9s"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 101, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598976792481824769",
  "text" : "\u201CI believe that we are going to have to transition off of fossil fuels as a planet\u201D \u2014President Obama #ActOnClimate http:\/\/t.co\/cGIoJy3t9s",
  "id" : 598976792481824769,
  "created_at" : "2015-05-14 22:22:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598969829345730560",
  "text" : "RT @WHLive: \"The United States and our GCC partners cooperate extensively, countering terrorist groups like al Qaeda and now ISIL\" \u2014Obama #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GCCSummit",
        "indices" : [ 126, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "598969800304435200",
    "text" : "\"The United States and our GCC partners cooperate extensively, countering terrorist groups like al Qaeda and now ISIL\" \u2014Obama #GCCSummit",
    "id" : 598969800304435200,
    "created_at" : "2015-05-14 21:55:03 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 598969829345730560,
  "created_at" : "2015-05-14 21:55:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598969514055704576",
  "text" : "\"We are a growing country with a growing economy. We need to invest in the infrastructure that keeps us that way.\" \u2014President Obama",
  "id" : 598969514055704576,
  "created_at" : "2015-05-14 21:53:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598969377132662784",
  "text" : "\"I want to express my deepest condolences to the families of those who died in Tuesday's train derailment outside Philadelphia.\" \u2014Obama",
  "id" : 598969377132662784,
  "created_at" : "2015-05-14 21:53:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GCCSummit",
      "indices" : [ 64, 74 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/fTMFEnOESi",
      "expanded_url" : "http:\/\/go.wh.gov\/rupNjm",
      "display_url" : "go.wh.gov\/rupNjm"
    } ]
  },
  "geo" : { },
  "id_str" : "598969236845826048",
  "text" : "Watch live: President Obama speaks at a press conference at the #GCCSummit \u2192 http:\/\/t.co\/fTMFEnOESi",
  "id" : 598969236845826048,
  "created_at" : "2015-05-14 21:52:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/petesouza\/status\/598935122780512257\/photo\/1",
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/OmaTY7ENO0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CE_YTMkVAAAuOBu.jpg",
      "id_str" : "598935099766276096",
      "id" : 598935099766276096,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CE_YTMkVAAAuOBu.jpg",
      "sizes" : [ {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/OmaTY7ENO0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598938670503227395",
  "text" : "RT @petesouza: President Obama hosts GCC meeting at Camp David http:\/\/t.co\/OmaTY7ENO0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/petesouza\/status\/598935122780512257\/photo\/1",
        "indices" : [ 48, 70 ],
        "url" : "http:\/\/t.co\/OmaTY7ENO0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CE_YTMkVAAAuOBu.jpg",
        "id_str" : "598935099766276096",
        "id" : 598935099766276096,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CE_YTMkVAAAuOBu.jpg",
        "sizes" : [ {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/OmaTY7ENO0"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "598935122780512257",
    "text" : "President Obama hosts GCC meeting at Camp David http:\/\/t.co\/OmaTY7ENO0",
    "id" : 598935122780512257,
    "created_at" : "2015-05-14 19:37:15 +0000",
    "user" : {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "protected" : false,
      "id_str" : "18215973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771916869808844800\/7d_poH48_normal.jpg",
      "id" : 18215973,
      "verified" : true
    }
  },
  "id" : 598938670503227395,
  "created_at" : "2015-05-14 19:51:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/598922388240236545\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/WTuAeafL8D",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CE_LVIuUkAAdnJ9.jpg",
      "id_str" : "598920839443025920",
      "id" : 598920839443025920,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CE_LVIuUkAAdnJ9.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/WTuAeafL8D"
    } ],
    "hashtags" : [ {
      "text" : "CommunityCollege",
      "indices" : [ 28, 45 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/0zSo1K2HiC",
      "expanded_url" : "http:\/\/go.wh.gov\/bvrseh",
      "display_url" : "go.wh.gov\/bvrseh"
    } ]
  },
  "geo" : { },
  "id_str" : "598922388240236545",
  "text" : "RT if you agree: 2 years of #CommunityCollege should be as free and universal as high school. http:\/\/t.co\/0zSo1K2HiC http:\/\/t.co\/WTuAeafL8D",
  "id" : 598922388240236545,
  "created_at" : "2015-05-14 18:46:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/598915433526202368\/photo\/1",
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/I5ASHhPbS3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CE_GTSVUMAEdAC_.jpg",
      "id_str" : "598915310104621057",
      "id" : 598915310104621057,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CE_GTSVUMAEdAC_.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/I5ASHhPbS3"
    } ],
    "hashtags" : [ {
      "text" : "GCCSummit",
      "indices" : [ 82, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598915433526202368",
  "text" : "Tea time at Camp David.\nPresident Obama is meeting with Gulf state leaders at the #GCCSummit. http:\/\/t.co\/I5ASHhPbS3",
  "id" : 598915433526202368,
  "created_at" : "2015-05-14 18:19:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "womensucceed",
      "indices" : [ 20, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598881867027189760",
  "text" : "RT @vj44: Even when #womensucceed, too often false stereotypes still try to hold them back. Let's leave behind Mad Men era mindsets and mov\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "womensucceed",
        "indices" : [ 10, 23 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "598880983471890432",
    "text" : "Even when #womensucceed, too often false stereotypes still try to hold them back. Let's leave behind Mad Men era mindsets and move into 2015",
    "id" : 598880983471890432,
    "created_at" : "2015-05-14 16:02:07 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 598881867027189760,
  "created_at" : "2015-05-14 16:05:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Camden County Police",
      "screen_name" : "CamdenCountyPD",
      "indices" : [ 3, 18 ],
      "id_str" : "1117740558",
      "id" : 1117740558
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598878130154151936",
  "text" : "RT @CamdenCountyPD: Honored to welcome Pres. Barack Obama to Camden next Monday, where he will visit our community and officers.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "598864058260000768",
    "text" : "Honored to welcome Pres. Barack Obama to Camden next Monday, where he will visit our community and officers.",
    "id" : 598864058260000768,
    "created_at" : "2015-05-14 14:54:52 +0000",
    "user" : {
      "name" : "Camden County Police",
      "screen_name" : "CamdenCountyPD",
      "protected" : false,
      "id_str" : "1117740558",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/754653028423196672\/JpWgn-FQ_normal.jpg",
      "id" : 1117740558,
      "verified" : false
    }
  },
  "id" : 598878130154151936,
  "created_at" : "2015-05-14 15:50:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/598846261358252032\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/fV591qDKJd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CE-HTJMUsAA3-t3.jpg",
      "id_str" : "598846038418436096",
      "id" : 598846038418436096,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CE-HTJMUsAA3-t3.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/fV591qDKJd"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/D6H0NrKfiJ",
      "expanded_url" : "http:\/\/go.wh.gov\/quHZYv",
      "display_url" : "go.wh.gov\/quHZYv"
    } ]
  },
  "geo" : { },
  "id_str" : "598846261358252032",
  "text" : "Millions of women are now guaranteed free preventive care thanks to the Affordable Care Act \u2192 http:\/\/t.co\/D6H0NrKfiJ http:\/\/t.co\/fV591qDKJd",
  "id" : 598846261358252032,
  "created_at" : "2015-05-14 13:44:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/598619995627741185\/photo\/1",
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/tAIp84Oi2j",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CE64SYvUUAAAqHz.jpg",
      "id_str" : "598618426504925184",
      "id" : 598618426504925184,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CE64SYvUUAAAqHz.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/tAIp84Oi2j"
    } ],
    "hashtags" : [ {
      "text" : "NWHW",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598619995627741185",
  "text" : "RT if you agree: Personal health care decisions should be made between a woman and her doctor. #NWHW http:\/\/t.co\/tAIp84Oi2j",
  "id" : 598619995627741185,
  "created_at" : "2015-05-13 22:45:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/598613716569952256\/photo\/1",
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/GTIedmyF3c",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CE6wrM5VAAEl8Pq.jpg",
      "id_str" : "598610056729395201",
      "id" : 598610056729395201,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CE6wrM5VAAEl8Pq.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      } ],
      "display_url" : "pic.twitter.com\/GTIedmyF3c"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/eNJz2uaM7e",
      "expanded_url" : "http:\/\/go.wh.gov\/QUQrXY",
      "display_url" : "go.wh.gov\/QUQrXY"
    } ]
  },
  "geo" : { },
  "id_str" : "598613716569952256",
  "text" : "Happy Birthday, Stevie Wonder! http:\/\/t.co\/eNJz2uaM7e http:\/\/t.co\/GTIedmyF3c",
  "id" : 598613716569952256,
  "created_at" : "2015-05-13 22:20:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 5, 12 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GimmeFive",
      "indices" : [ 55, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/Wh6ZYONbVU",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/fcc6427d-6098-4604-b62e-484ede4d4b88",
      "display_url" : "amp.twimg.com\/v\/fcc6427d-609\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "598604556587511808",
  "text" : "Hey, @FLOTUS! The President has a challenge for you... #GimmeFive\nhttps:\/\/t.co\/Wh6ZYONbVU",
  "id" : 598604556587511808,
  "created_at" : "2015-05-13 21:43:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/598587362348650496\/photo\/1",
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/HQQQbXjnwW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CE6bxo6UUAE_33a.jpg",
      "id_str" : "598587077584769025",
      "id" : 598587077584769025,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CE6bxo6UUAE_33a.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/HQQQbXjnwW"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/AHS3HMZFcp",
      "expanded_url" : "http:\/\/go.wh.gov\/dJKo6m",
      "display_url" : "go.wh.gov\/dJKo6m"
    } ]
  },
  "geo" : { },
  "id_str" : "598587362348650496",
  "text" : "Check out our 5 favorite commencement addresses from the Obama administration \u2192 http:\/\/t.co\/AHS3HMZFcp http:\/\/t.co\/HQQQbXjnwW",
  "id" : 598587362348650496,
  "created_at" : "2015-05-13 20:35:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Tumblr",
      "screen_name" : "tumblr",
      "indices" : [ 88, 95 ],
      "id_str" : "52484614",
      "id" : 52484614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/NPrjFowda1",
      "expanded_url" : "http:\/\/tmblr.co\/ZW21es1kipROM",
      "display_url" : "tmblr.co\/ZW21es1kipROM"
    } ]
  },
  "geo" : { },
  "id_str" : "598547766453743616",
  "text" : "RT @VP: We all play a role in ending sexual assault. Stand up. Speak out. Learn more on @tumblr \u2192 http:\/\/t.co\/NPrjFowda1 http:\/\/t.co\/GCnpGq\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tumblr",
        "screen_name" : "tumblr",
        "indices" : [ 80, 87 ],
        "id_str" : "52484614",
        "id" : 52484614
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/598545566033907713\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/GCnpGqLRRX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CE52BEsVEAEX_hH.jpg",
        "id_str" : "598545561298472961",
        "id" : 598545561298472961,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CE52BEsVEAEX_hH.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/GCnpGqLRRX"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/NPrjFowda1",
        "expanded_url" : "http:\/\/tmblr.co\/ZW21es1kipROM",
        "display_url" : "tmblr.co\/ZW21es1kipROM"
      } ]
    },
    "geo" : { },
    "id_str" : "598545566033907713",
    "text" : "We all play a role in ending sexual assault. Stand up. Speak out. Learn more on @tumblr \u2192 http:\/\/t.co\/NPrjFowda1 http:\/\/t.co\/GCnpGqLRRX",
    "id" : 598545566033907713,
    "created_at" : "2015-05-13 17:49:18 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 598547766453743616,
  "created_at" : "2015-05-13 17:58:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "TUSKEGEE UNIVERSITY",
      "screen_name" : "TuskegeeUniv",
      "indices" : [ 77, 90 ],
      "id_str" : "56280035",
      "id" : 56280035
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/D7aVJaX06b",
      "expanded_url" : "https:\/\/youtu.be\/i0kX3wBHd4Y",
      "display_url" : "youtu.be\/i0kX3wBHd4Y"
    } ]
  },
  "geo" : { },
  "id_str" : "598538058934329344",
  "text" : "RT @FLOTUS: \u201CAct with both your mind and your heart.\u201D \u2014The First Lady to the @TuskegeeUniv Class of 2015: https:\/\/t.co\/D7aVJaX06b",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "TUSKEGEE UNIVERSITY",
        "screen_name" : "TuskegeeUniv",
        "indices" : [ 65, 78 ],
        "id_str" : "56280035",
        "id" : 56280035
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/D7aVJaX06b",
        "expanded_url" : "https:\/\/youtu.be\/i0kX3wBHd4Y",
        "display_url" : "youtu.be\/i0kX3wBHd4Y"
      } ]
    },
    "geo" : { },
    "id_str" : "598537465612218368",
    "text" : "\u201CAct with both your mind and your heart.\u201D \u2014The First Lady to the @TuskegeeUniv Class of 2015: https:\/\/t.co\/D7aVJaX06b",
    "id" : 598537465612218368,
    "created_at" : "2015-05-13 17:17:06 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 598538058934329344,
  "created_at" : "2015-05-13 17:19:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598531568970301440",
  "text" : "RT @VP: \"The victims could have been one of our children or someone from one of our communities.\" -VP on Amtrak incident http:\/\/t.co\/PaAcRv\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/598521291902070784\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/PaAcRvxqYz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CE5f8XXUsAAlMfL.jpg",
        "id_str" : "598521291155484672",
        "id" : 598521291155484672,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CE5f8XXUsAAlMfL.jpg",
        "sizes" : [ {
          "h" : 165,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 291,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 695
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 695
        } ],
        "display_url" : "pic.twitter.com\/PaAcRvxqYz"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "598521291902070784",
    "text" : "\"The victims could have been one of our children or someone from one of our communities.\" -VP on Amtrak incident http:\/\/t.co\/PaAcRvxqYz",
    "id" : 598521291902070784,
    "created_at" : "2015-05-13 16:12:50 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 598531568970301440,
  "created_at" : "2015-05-13 16:53:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amtrak",
      "screen_name" : "Amtrak",
      "indices" : [ 93, 100 ],
      "id_str" : "119166791",
      "id" : 119166791
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/598508615310315520\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/3hk4GqL7o6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CE5UaghW0AAfDD7.png",
      "id_str" : "598508614870028288",
      "id" : 598508614870028288,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CE5UaghW0AAfDD7.png",
      "sizes" : [ {
        "h" : 174,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 279,
        "resize" : "fit",
        "w" : 964
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 279,
        "resize" : "fit",
        "w" : 964
      }, {
        "h" : 98,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/3hk4GqL7o6"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598508615310315520",
  "text" : "\"Our thoughts and prayers go out to the families and friends of those we lost\" \u2014Obama on the @Amtrak train derailment http:\/\/t.co\/3hk4GqL7o6",
  "id" : 598508615310315520,
  "created_at" : "2015-05-13 15:22:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Facebook",
      "screen_name" : "facebook",
      "indices" : [ 19, 28 ],
      "id_str" : "2425151",
      "id" : 2425151
    }, {
      "name" : "Sheryl Sandberg",
      "screen_name" : "sherylsandberg",
      "indices" : [ 106, 121 ],
      "id_str" : "19506790",
      "id" : 19506790
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598494021418254336",
  "text" : "RT @vj44: Just in: @facebook is now requiring contractors\/vendors to \u2B06\uFE0F pay &amp; paid leave for workers. @sherylsandberg thx for helping FB #L\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Facebook",
        "screen_name" : "facebook",
        "indices" : [ 9, 18 ],
        "id_str" : "2425151",
        "id" : 2425151
      }, {
        "name" : "Sheryl Sandberg",
        "screen_name" : "sherylsandberg",
        "indices" : [ 96, 111 ],
        "id_str" : "19506790",
        "id" : 19506790
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LeadOnLeave",
        "indices" : [ 131, 143 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "598493831194095616",
    "text" : "Just in: @facebook is now requiring contractors\/vendors to \u2B06\uFE0F pay &amp; paid leave for workers. @sherylsandberg thx for helping FB #LeadOnLeave",
    "id" : 598493831194095616,
    "created_at" : "2015-05-13 14:23:43 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 598494021418254336,
  "created_at" : "2015-05-13 14:24:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Labor Department",
      "screen_name" : "USDOL",
      "indices" : [ 3, 9 ],
      "id_str" : "20179628",
      "id" : 20179628
    }, {
      "name" : "Facebook",
      "screen_name" : "facebook",
      "indices" : [ 12, 21 ],
      "id_str" : "2425151",
      "id" : 2425151
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LeadOnLeave",
      "indices" : [ 44, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598491792393142272",
  "text" : "RT @USDOL: .@Facebook continues to take the #LeadOnLeave by announcing improved benefits for U.S. contractors and vendors. http:\/\/t.co\/HeWX\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Facebook",
        "screen_name" : "facebook",
        "indices" : [ 1, 10 ],
        "id_str" : "2425151",
        "id" : 2425151
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/USDOL\/status\/598491576038481921\/photo\/1",
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/HeWXQUuTRM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CE5E6s2WEAArmf0.png",
        "id_str" : "598491575749054464",
        "id" : 598491575749054464,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CE5E6s2WEAArmf0.png",
        "sizes" : [ {
          "h" : 800,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/HeWXQUuTRM"
      } ],
      "hashtags" : [ {
        "text" : "LeadOnLeave",
        "indices" : [ 33, 45 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "598491576038481921",
    "text" : ".@Facebook continues to take the #LeadOnLeave by announcing improved benefits for U.S. contractors and vendors. http:\/\/t.co\/HeWXQUuTRM",
    "id" : 598491576038481921,
    "created_at" : "2015-05-13 14:14:45 +0000",
    "user" : {
      "name" : "US Labor Department",
      "screen_name" : "USDOL",
      "protected" : false,
      "id_str" : "20179628",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655006480697978880\/Fom0f0nJ_normal.png",
      "id" : 20179628,
      "verified" : true
    }
  },
  "id" : 598491792393142272,
  "created_at" : "2015-05-13 14:15:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PovertySummit",
      "indices" : [ 93, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/OJc8DsAuC1",
      "expanded_url" : "http:\/\/snpy.tv\/1Fc4Hwf",
      "display_url" : "snpy.tv\/1Fc4Hwf"
    } ]
  },
  "geo" : { },
  "id_str" : "598237999789416448",
  "text" : "President Obama on the need to make common investments that expand opportunity for our kids. #PovertySummit http:\/\/t.co\/OJc8DsAuC1",
  "id" : 598237999789416448,
  "created_at" : "2015-05-12 21:27:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/598230514693115904\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/5L0tJj7IhT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CE1Xa-oWAAE4Fzw.jpg",
      "id_str" : "598230446510571521",
      "id" : 598230446510571521,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CE1Xa-oWAAE4Fzw.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/5L0tJj7IhT"
    } ],
    "hashtags" : [ {
      "text" : "NWHW",
      "indices" : [ 100, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/D6H0NrKfiJ",
      "expanded_url" : "http:\/\/go.wh.gov\/quHZYv",
      "display_url" : "go.wh.gov\/quHZYv"
    } ]
  },
  "geo" : { },
  "id_str" : "598230514693115904",
  "text" : "RT to spread the word about the new guidance for insurers on birth control \u2192 http:\/\/t.co\/D6H0NrKfiJ #NWHW http:\/\/t.co\/5L0tJj7IhT",
  "id" : 598230514693115904,
  "created_at" : "2015-05-12 20:57:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 3, 13 ],
      "id_str" : "9624742",
      "id" : 9624742
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StartTheSpark",
      "indices" : [ 48, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598223134903283712",
  "text" : "RT @StateDept: Answer President Obama\u2019s call to #StartTheSpark. Make your pledge to invest in emerging global entrepreneurs at http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "StartTheSpark",
        "indices" : [ 33, 47 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/z3iQtmInMK",
        "expanded_url" : "http:\/\/go.usa.gov\/3kBn5",
        "display_url" : "go.usa.gov\/3kBn5"
      } ]
    },
    "geo" : { },
    "id_str" : "598156330424111105",
    "text" : "Answer President Obama\u2019s call to #StartTheSpark. Make your pledge to invest in emerging global entrepreneurs at http:\/\/t.co\/z3iQtmInMK.",
    "id" : 598156330424111105,
    "created_at" : "2015-05-12 16:02:37 +0000",
    "user" : {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "protected" : false,
      "id_str" : "9624742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724612605185282048\/1rEfkXDZ_normal.jpg",
      "id" : 9624742,
      "verified" : true
    }
  },
  "id" : 598223134903283712,
  "created_at" : "2015-05-12 20:28:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PovertySummit",
      "indices" : [ 97, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/nxijdV7Nmf",
      "expanded_url" : "http:\/\/snpy.tv\/1FbMNtm",
      "display_url" : "snpy.tv\/1FbMNtm"
    } ]
  },
  "geo" : { },
  "id_str" : "598205670572302337",
  "text" : "\u201CIt would be powerful for our faith-based organizations to speak out on this.\u201D \u2014Obama on poverty #PovertySummit http:\/\/t.co\/nxijdV7Nmf",
  "id" : 598205670572302337,
  "created_at" : "2015-05-12 19:18:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PovertySummit",
      "indices" : [ 125, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598170764332953600",
  "text" : "\u201COur faith-based groups have the capacity to frame this, and nobody\u2019s shown that better than Pope Francis.\u201D \u2014President Obama #PovertySummit",
  "id" : 598170764332953600,
  "created_at" : "2015-05-12 16:59:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PovertySummit",
      "indices" : [ 99, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/Q8xoMilr7U",
      "expanded_url" : "http:\/\/snpy.tv\/1HbU5No",
      "display_url" : "snpy.tv\/1HbU5No"
    } ]
  },
  "geo" : { },
  "id_str" : "598167623843639296",
  "text" : "\u201CI am a black man who grew up without a father, and I know the costs that I paid for that.\" \u2014Obama #PovertySummit http:\/\/t.co\/Q8xoMilr7U",
  "id" : 598167623843639296,
  "created_at" : "2015-05-12 16:47:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PovertySummit",
      "indices" : [ 122, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598165486522740736",
  "text" : "\u201CIf a young kid...is hearing a lot of words, the science tells us that they\u2019re going to be more likely to succeed\u201D \u2014Obama #PovertySummit",
  "id" : 598165486522740736,
  "created_at" : "2015-05-12 16:39:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/598158088739389441\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/jGFM67ogN5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CE0VcVzWIAAmC7e.jpg",
      "id_str" : "598157902143168512",
      "id" : 598157902143168512,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CE0VcVzWIAAmC7e.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/jGFM67ogN5"
    } ],
    "hashtags" : [ {
      "text" : "PovertySummit",
      "indices" : [ 92, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598158088739389441",
  "text" : "RT if you agree: It\u2019s time to expand opportunity by investing in early childhood education. #PovertySummit http:\/\/t.co\/jGFM67ogN5",
  "id" : 598158088739389441,
  "created_at" : "2015-05-12 16:09:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598157092302823424",
  "text" : "RT @WHLive: \"You can't have a conversation about poverty without talking about ladders of opportunity into the middle class\" \u2014Obama #Povert\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PovertySummit",
        "indices" : [ 120, 134 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "598157068034568193",
    "text" : "\"You can't have a conversation about poverty without talking about ladders of opportunity into the middle class\" \u2014Obama #PovertySummit",
    "id" : 598157068034568193,
    "created_at" : "2015-05-12 16:05:32 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 598157092302823424,
  "created_at" : "2015-05-12 16:05:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/598156767558762496\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/3bdyr7JbGm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CE0URDPWMAAhzWq.jpg",
      "id_str" : "598156608670150656",
      "id" : 598156608670150656,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CE0URDPWMAAhzWq.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/3bdyr7JbGm"
    } ],
    "hashtags" : [ {
      "text" : "PovertySummit",
      "indices" : [ 96, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598156767558762496",
  "text" : "\"The best anti-poverty program is a job\" \u2014Obama on the need to build on the progress we've made #PovertySummit http:\/\/t.co\/3bdyr7JbGm",
  "id" : 598156767558762496,
  "created_at" : "2015-05-12 16:04:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joy Reid",
      "screen_name" : "JoyAnnReid",
      "indices" : [ 3, 14 ],
      "id_str" : "49698134",
      "id" : 49698134
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598154590954074112",
  "text" : "RT @JoyAnnReid: President Obama says we must have a \"both, and\" not an \"either, or\" conversation on the individual vs governmental approach\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "598152936544342016",
    "text" : "President Obama says we must have a \"both, and\" not an \"either, or\" conversation on the individual vs governmental approach to poverty.",
    "id" : 598152936544342016,
    "created_at" : "2015-05-12 15:49:07 +0000",
    "user" : {
      "name" : "Joy Reid",
      "screen_name" : "JoyAnnReid",
      "protected" : false,
      "id_str" : "49698134",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796364947517161472\/O7jPbVMJ_normal.jpg",
      "id" : 49698134,
      "verified" : true
    }
  },
  "id" : 598154590954074112,
  "created_at" : "2015-05-12 15:55:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "598153438447427584",
  "text" : "RT @WHLive: \u201CThere\u2019s a lot we can do. The question is, do we have the political will\u2014the communal will\u2014to do something about it?\u201D \u2014Obama #P\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PovertySummit",
        "indices" : [ 125, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "598153390930132992",
    "text" : "\u201CThere\u2019s a lot we can do. The question is, do we have the political will\u2014the communal will\u2014to do something about it?\u201D \u2014Obama #PovertySummit",
    "id" : 598153390930132992,
    "created_at" : "2015-05-12 15:50:56 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 598153438447427584,
  "created_at" : "2015-05-12 15:51:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgetown Univ.",
      "screen_name" : "Georgetown",
      "indices" : [ 86, 97 ],
      "id_str" : "7856542",
      "id" : 7856542
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PovertySummit",
      "indices" : [ 98, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/UwVQ48UvYv",
      "expanded_url" : "http:\/\/go.wh.gov\/pFJRQN",
      "display_url" : "go.wh.gov\/pFJRQN"
    } ]
  },
  "geo" : { },
  "id_str" : "598150342359031809",
  "text" : "Watch live: President Obama participates in a discussion on overcoming poverty at the @Georgetown #PovertySummit \u2192 http:\/\/t.co\/UwVQ48UvYv",
  "id" : 598150342359031809,
  "created_at" : "2015-05-12 15:38:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Georgetown Univ.",
      "screen_name" : "Georgetown",
      "indices" : [ 78, 89 ],
      "id_str" : "7856542",
      "id" : 7856542
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PovertySummit",
      "indices" : [ 90, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/UwVQ48UvYv",
      "expanded_url" : "http:\/\/go.wh.gov\/pFJRQN",
      "display_url" : "go.wh.gov\/pFJRQN"
    } ]
  },
  "geo" : { },
  "id_str" : "598144772356886528",
  "text" : "Watch President Obama's discussion at 11:30am ET on overcoming poverty at the @Georgetown #PovertySummit \u2192 http:\/\/t.co\/UwVQ48UvYv",
  "id" : 598144772356886528,
  "created_at" : "2015-05-12 15:16:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "TUSKEGEE UNIVERSITY",
      "screen_name" : "TuskegeeUniv",
      "indices" : [ 63, 76 ],
      "id_str" : "56280035",
      "id" : 56280035
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/7lmkZ3jEvc",
      "expanded_url" : "http:\/\/go.wh.gov\/RXpfML",
      "display_url" : "go.wh.gov\/RXpfML"
    } ]
  },
  "geo" : { },
  "id_str" : "598120528352825344",
  "text" : "RT @FLOTUS: Worth a read: The First Lady\u2019s Powerful Remarks to @TuskegeeUniv Class of 2015  http:\/\/t.co\/7lmkZ3jEvc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "TUSKEGEE UNIVERSITY",
        "screen_name" : "TuskegeeUniv",
        "indices" : [ 51, 64 ],
        "id_str" : "56280035",
        "id" : 56280035
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/7lmkZ3jEvc",
        "expanded_url" : "http:\/\/go.wh.gov\/RXpfML",
        "display_url" : "go.wh.gov\/RXpfML"
      } ]
    },
    "geo" : { },
    "id_str" : "597954646049726464",
    "text" : "Worth a read: The First Lady\u2019s Powerful Remarks to @TuskegeeUniv Class of 2015  http:\/\/t.co\/7lmkZ3jEvc",
    "id" : 597954646049726464,
    "created_at" : "2015-05-12 02:41:11 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 598120528352825344,
  "created_at" : "2015-05-12 13:40:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StartTheSpark",
      "indices" : [ 102, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/UUZzo2VVfD",
      "expanded_url" : "http:\/\/go.wh.gov\/uqpxNE",
      "display_url" : "go.wh.gov\/uqpxNE"
    }, {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/rcjLsenJFa",
      "expanded_url" : "http:\/\/snpy.tv\/1RwtO26",
      "display_url" : "snpy.tv\/1RwtO26"
    } ]
  },
  "geo" : { },
  "id_str" : "597869119967461377",
  "text" : "\"To all the young entrepreneurs out here, you are the face of change.\" \u2014Obama: http:\/\/t.co\/UUZzo2VVfD #StartTheSpark http:\/\/t.co\/rcjLsenJFa",
  "id" : 597869119967461377,
  "created_at" : "2015-05-11 21:01:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ed Felten",
      "screen_name" : "EdFelten44",
      "indices" : [ 3, 14 ],
      "id_str" : "3240625473",
      "id" : 3240625473
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 32, 43 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "Ed Felten",
      "screen_name" : "EdFelten44",
      "indices" : [ 71, 82 ],
      "id_str" : "3240625473",
      "id" : 3240625473
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/Hr4XGc1irz",
      "expanded_url" : "https:\/\/www.whitehouse.gov\/blog\/2015\/05\/11\/white-house-names-dr-ed-felten-deputy-us-chief-technology-officer",
      "display_url" : "whitehouse.gov\/blog\/2015\/05\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "597861291395428352",
  "text" : "RT @EdFelten44: Excited to join @whitehouse as Deputy U.S. CTO. Follow @edfelten44 for official tweets. https:\/\/t.co\/Hr4XGc1irz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 16, 27 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "Ed Felten",
        "screen_name" : "EdFelten44",
        "indices" : [ 55, 66 ],
        "id_str" : "3240625473",
        "id" : 3240625473
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/Hr4XGc1irz",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/blog\/2015\/05\/11\/white-house-names-dr-ed-felten-deputy-us-chief-technology-officer",
        "display_url" : "whitehouse.gov\/blog\/2015\/05\/1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "597825280745541632",
    "text" : "Excited to join @whitehouse as Deputy U.S. CTO. Follow @edfelten44 for official tweets. https:\/\/t.co\/Hr4XGc1irz",
    "id" : 597825280745541632,
    "created_at" : "2015-05-11 18:07:08 +0000",
    "user" : {
      "name" : "Ed Felten",
      "screen_name" : "EdFelten44",
      "protected" : false,
      "id_str" : "3240625473",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/597792170360213504\/EhJAOe02_normal.jpg",
      "id" : 3240625473,
      "verified" : false
    }
  },
  "id" : 597861291395428352,
  "created_at" : "2015-05-11 20:30:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StartTheSpark",
      "indices" : [ 120, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/UUZzo2VVfD",
      "expanded_url" : "http:\/\/go.wh.gov\/uqpxNE",
      "display_url" : "go.wh.gov\/uqpxNE"
    } ]
  },
  "geo" : { },
  "id_str" : "597848530049441793",
  "text" : "\"We\u2019re going to step up our efforts to support young entrepreneurs and women.\" \u2014President Obama: http:\/\/t.co\/UUZzo2VVfD #StartTheSpark",
  "id" : 597848530049441793,
  "created_at" : "2015-05-11 19:39:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597847797380026368",
  "text" : "RT @WHLive: \"We\u2019ve set a goal of generating $1 billion in new investment for emerging entrepreneurs worldwide by 2017\" \u2014President Obama #St\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "StartTheSpark",
        "indices" : [ 124, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "597847764316323841",
    "text" : "\"We\u2019ve set a goal of generating $1 billion in new investment for emerging entrepreneurs worldwide by 2017\" \u2014President Obama #StartTheSpark",
    "id" : 597847764316323841,
    "created_at" : "2015-05-11 19:36:29 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 597847797380026368,
  "created_at" : "2015-05-11 19:36:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StartTheSpark",
      "indices" : [ 126, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597847293073694720",
  "text" : "\"Investments in youth entrepreneurship and education are ultimately some of our best antidotes to violence.\" \u2014President Obama #StartTheSpark",
  "id" : 597847293073694720,
  "created_at" : "2015-05-11 19:34:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597847061019648000",
  "text" : "RT @WHLive: \"Encouraging the spirit of entrepreneurship can help us tackle some of the greatest challenges we face around the world.\" \u2014Pres\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "597847030665469952",
    "text" : "\"Encouraging the spirit of entrepreneurship can help us tackle some of the greatest challenges we face around the world.\" \u2014President Obama",
    "id" : 597847030665469952,
    "created_at" : "2015-05-11 19:33:34 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 597847061019648000,
  "created_at" : "2015-05-11 19:33:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StartTheSpark",
      "indices" : [ 99, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/vzSizrVpok",
      "expanded_url" : "http:\/\/go.wh.gov\/6Le9vt",
      "display_url" : "go.wh.gov\/6Le9vt"
    } ]
  },
  "geo" : { },
  "id_str" : "597846420410990593",
  "text" : "Watch live: President Obama speaks on encouraging global entrepreneurship \u2192 http:\/\/t.co\/vzSizrVpok #StartTheSpark",
  "id" : 597846420410990593,
  "created_at" : "2015-05-11 19:31:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/597806720925171712\/photo\/1",
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/RrY0TEOeU6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEvV1M_WEAA0UYg.jpg",
      "id_str" : "597806485553418240",
      "id" : 597806485553418240,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEvV1M_WEAA0UYg.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/RrY0TEOeU6"
    } ],
    "hashtags" : [ {
      "text" : "CheckUpForWhat",
      "indices" : [ 81, 96 ]
    }, {
      "text" : "NWHW",
      "indices" : [ 97, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597806720925171712",
  "text" : "Millions of women have gained health coverage thanks to the Affordable Care Act. #CheckUpForWhat #NWHW http:\/\/t.co\/RrY0TEOeU6",
  "id" : 597806720925171712,
  "created_at" : "2015-05-11 16:53:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NWHW",
      "indices" : [ 125, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597797315034882048",
  "text" : "RT @vj44: Happy National Women\u2019s Health Week! Whether you\u2019re in your 20's or 90's, take steps this week for a healthier you. #NWHW #CheckUp\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NWHW",
        "indices" : [ 115, 120 ]
      }, {
        "text" : "CheckUpForWhat",
        "indices" : [ 121, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "597797259372142592",
    "text" : "Happy National Women\u2019s Health Week! Whether you\u2019re in your 20's or 90's, take steps this week for a healthier you. #NWHW #CheckUpForWhat",
    "id" : 597797259372142592,
    "created_at" : "2015-05-11 16:15:47 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 597797315034882048,
  "created_at" : "2015-05-11 16:16:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/MJJitBvhAI",
      "expanded_url" : "https:\/\/www.whitehouse.gov\/live\/vice-president-biden-speaks-importance-investing-our-nations-infrastructure-1",
      "display_url" : "whitehouse.gov\/live\/vice-pres\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "597788944084897792",
  "text" : "RT @VP: \"Our economy has gone from crisis to recovery to resurgence.\" -VP Biden speaking right now https:\/\/t.co\/MJJitBvhAI http:\/\/t.co\/s53L\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/VP\/status\/597788720406736896\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/s53LGFUw1K",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CEvFrClWoAAqWXp.jpg",
        "id_str" : "597788718775312384",
        "id" : 597788718775312384,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEvFrClWoAAqWXp.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 700,
          "resize" : "fit",
          "w" : 1400
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/s53LGFUw1K"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/MJJitBvhAI",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/live\/vice-president-biden-speaks-importance-investing-our-nations-infrastructure-1",
        "display_url" : "whitehouse.gov\/live\/vice-pres\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "597788720406736896",
    "text" : "\"Our economy has gone from crisis to recovery to resurgence.\" -VP Biden speaking right now https:\/\/t.co\/MJJitBvhAI http:\/\/t.co\/s53LGFUw1K",
    "id" : 597788720406736896,
    "created_at" : "2015-05-11 15:41:51 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 597788944084897792,
  "created_at" : "2015-05-11 15:42:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Oliver",
      "screen_name" : "iamjohnoliver",
      "indices" : [ 3, 17 ],
      "id_str" : "316389142",
      "id" : 316389142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/AVWSesiya8",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=zIhKAQX5izw",
      "display_url" : "youtube.com\/watch?v=zIhKAQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "597774352822738945",
  "text" : "RT @iamjohnoliver: Here's our piece on Paid Family Leave in the US. Happy belated Mother's Day! https:\/\/t.co\/AVWSesiya8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/AVWSesiya8",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=zIhKAQX5izw",
        "display_url" : "youtube.com\/watch?v=zIhKAQ\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "597740662923075585",
    "text" : "Here's our piece on Paid Family Leave in the US. Happy belated Mother's Day! https:\/\/t.co\/AVWSesiya8",
    "id" : 597740662923075585,
    "created_at" : "2015-05-11 12:30:54 +0000",
    "user" : {
      "name" : "John Oliver",
      "screen_name" : "iamjohnoliver",
      "protected" : false,
      "id_str" : "316389142",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1393958859\/main_normal.jpg",
      "id" : 316389142,
      "verified" : true
    }
  },
  "id" : 597774352822738945,
  "created_at" : "2015-05-11 14:44:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Furman",
      "screen_name" : "CEAChair",
      "indices" : [ 14, 23 ],
      "id_str" : "1861751828",
      "id" : 1861751828
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/597763104584376321\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/5Abzjuv25S",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEutUxHWoAAbO4L.jpg",
      "id_str" : "597761947849891840",
      "id" : 597761947849891840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEutUxHWoAAbO4L.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/5Abzjuv25S"
    } ],
    "hashtags" : [ {
      "text" : "FamiliesSucceed",
      "indices" : [ 101, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/AAppU2nmG4",
      "expanded_url" : "http:\/\/nyti.ms\/1IvXS9S",
      "display_url" : "nyti.ms\/1IvXS9S"
    } ]
  },
  "geo" : { },
  "id_str" : "597763104584376321",
  "text" : "Worth a read: @CEAChair on why investing in families benefits all Americans \u2192 http:\/\/t.co\/AAppU2nmG4 #FamiliesSucceed http:\/\/t.co\/5Abzjuv25S",
  "id" : 597763104584376321,
  "created_at" : "2015-05-11 14:00:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/597557632350744576\/photo\/1",
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/6Xa9W9k0du",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CErze1bWgAA-Ylx.jpg",
      "id_str" : "597557611643437056",
      "id" : 597557611643437056,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CErze1bWgAA-Ylx.jpg",
      "sizes" : [ {
        "h" : 793,
        "resize" : "fit",
        "w" : 999
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 270,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 476,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 793,
        "resize" : "fit",
        "w" : 999
      } ],
      "display_url" : "pic.twitter.com\/6Xa9W9k0du"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597557632350744576",
  "text" : "Happy Mother's Day! http:\/\/t.co\/6Xa9W9k0du",
  "id" : 597557632350744576,
  "created_at" : "2015-05-11 00:23:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HappyMothersDay",
      "indices" : [ 70, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/PVRIZ389Oh",
      "expanded_url" : "https:\/\/youtu.be\/4Hcrx0uwluk",
      "display_url" : "youtu.be\/4Hcrx0uwluk"
    } ]
  },
  "geo" : { },
  "id_str" : "597491336967688194",
  "text" : "Watch President Obama surprise moms across the country to wish them a #HappyMothersDay: https:\/\/t.co\/PVRIZ389Oh",
  "id" : 597491336967688194,
  "created_at" : "2015-05-10 20:00:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HappyMothersDay",
      "indices" : [ 82, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/PVRIZ389Oh",
      "expanded_url" : "https:\/\/youtu.be\/4Hcrx0uwluk",
      "display_url" : "youtu.be\/4Hcrx0uwluk"
    } ]
  },
  "geo" : { },
  "id_str" : "597461178332282880",
  "text" : "\"Congratulations on being a great mom.\" \u2014President Obama: https:\/\/t.co\/PVRIZ389Oh #HappyMothersDay",
  "id" : 597461178332282880,
  "created_at" : "2015-05-10 18:00:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FOX 9",
      "screen_name" : "MyFOX9",
      "indices" : [ 3, 10 ],
      "id_str" : "9229732",
      "id" : 9229732
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/ILqZy4Nl3e",
      "expanded_url" : "http:\/\/www.myfoxtwincities.com\/story\/29023122\/president-obama-surprises-coon-rapids-mom-with-a-phone-call",
      "display_url" : "myfoxtwincities.com\/story\/29023122\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "597449581304119296",
  "text" : "RT @MyFOX9: This mom is already having the best mother's day http:\/\/t.co\/ILqZy4Nl3e",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 71 ],
        "url" : "http:\/\/t.co\/ILqZy4Nl3e",
        "expanded_url" : "http:\/\/www.myfoxtwincities.com\/story\/29023122\/president-obama-surprises-coon-rapids-mom-with-a-phone-call",
        "display_url" : "myfoxtwincities.com\/story\/29023122\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "597204633296056320",
    "text" : "This mom is already having the best mother's day http:\/\/t.co\/ILqZy4Nl3e",
    "id" : 597204633296056320,
    "created_at" : "2015-05-10 01:00:54 +0000",
    "user" : {
      "name" : "FOX 9",
      "screen_name" : "MyFOX9",
      "protected" : false,
      "id_str" : "9229732",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727232256373223425\/Xy0CGWIG_normal.jpg",
      "id" : 9229732,
      "verified" : true
    }
  },
  "id" : 597449581304119296,
  "created_at" : "2015-05-10 17:14:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HappyMothersDay",
      "indices" : [ 27, 43 ]
    } ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/PVRIZ3pLcR",
      "expanded_url" : "https:\/\/youtu.be\/4Hcrx0uwluk",
      "display_url" : "youtu.be\/4Hcrx0uwluk"
    } ]
  },
  "geo" : { },
  "id_str" : "597442959982907392",
  "text" : "To all the moms out there, #HappyMothersDay! https:\/\/t.co\/PVRIZ3pLcR",
  "id" : 597442959982907392,
  "created_at" : "2015-05-10 16:47:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HappyMothersDay",
      "indices" : [ 109, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597423034182565889",
  "text" : "RT @FLOTUS: Every day I am thankful for your love and support, Mom. Wishing all the amazing moms out there a #HappyMothersDay \u2013mo http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/597422240473358336\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/4ooYdoOP8E",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CEp4CjzWYAAOA9K.jpg",
        "id_str" : "597421885945700352",
        "id" : 597421885945700352,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEp4CjzWYAAOA9K.jpg",
        "sizes" : [ {
          "h" : 647,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 950
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 950
        }, {
          "h" : 366,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/4ooYdoOP8E"
      } ],
      "hashtags" : [ {
        "text" : "HappyMothersDay",
        "indices" : [ 97, 113 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "597422240473358336",
    "text" : "Every day I am thankful for your love and support, Mom. Wishing all the amazing moms out there a #HappyMothersDay \u2013mo http:\/\/t.co\/4ooYdoOP8E",
    "id" : 597422240473358336,
    "created_at" : "2015-05-10 15:25:36 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 597423034182565889,
  "created_at" : "2015-05-10 15:28:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jerry Abramson",
      "screen_name" : "Abramson44",
      "indices" : [ 3, 14 ],
      "id_str" : "562385224",
      "id" : 562385224
    }, {
      "name" : "Mayor Marty Walsh",
      "screen_name" : "marty_walsh",
      "indices" : [ 90, 102 ],
      "id_str" : "77764733",
      "id" : 77764733
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyBrothersKeeper",
      "indices" : [ 26, 43 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/LMGo9puWXg",
      "expanded_url" : "http:\/\/www.bostonglobe.com\/metro\/2015\/05\/08\/mayor-martin-walsh-outlines-recommendation-for-brother-keeper\/Wne0DtpriWhcMLbV1bHd6J\/story.html",
      "display_url" : "bostonglobe.com\/metro\/2015\/05\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "597193038990077953",
  "text" : "RT @Abramson44: Are you a #MyBrothersKeeper challenge city? Check out the great work from @marty_walsh: http:\/\/t.co\/LMGo9puWXg Well done, M\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mayor Marty Walsh",
        "screen_name" : "marty_walsh",
        "indices" : [ 74, 86 ],
        "id_str" : "77764733",
        "id" : 77764733
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MyBrothersKeeper",
        "indices" : [ 10, 27 ]
      }, {
        "text" : "MBKBoston",
        "indices" : [ 129, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/LMGo9puWXg",
        "expanded_url" : "http:\/\/www.bostonglobe.com\/metro\/2015\/05\/08\/mayor-martin-walsh-outlines-recommendation-for-brother-keeper\/Wne0DtpriWhcMLbV1bHd6J\/story.html",
        "display_url" : "bostonglobe.com\/metro\/2015\/05\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "597107636115533824",
    "text" : "Are you a #MyBrothersKeeper challenge city? Check out the great work from @marty_walsh: http:\/\/t.co\/LMGo9puWXg Well done, Mayor! #MBKBoston",
    "id" : 597107636115533824,
    "created_at" : "2015-05-09 18:35:28 +0000",
    "user" : {
      "name" : "Jerry Abramson",
      "screen_name" : "Abramson44",
      "protected" : false,
      "id_str" : "562385224",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/763586545911734272\/N3LaqB4d_normal.jpg",
      "id" : 562385224,
      "verified" : true
    }
  },
  "id" : 597193038990077953,
  "created_at" : "2015-05-10 00:14:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mayor Marty Walsh",
      "screen_name" : "marty_walsh",
      "indices" : [ 15, 27 ],
      "id_str" : "77764733",
      "id" : 77764733
    }, {
      "name" : "The Boston Globe",
      "screen_name" : "BostonGlobe",
      "indices" : [ 69, 81 ],
      "id_str" : "95431448",
      "id" : 95431448
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyBrothersKeeper",
      "indices" : [ 106, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/DkvIT3edO5",
      "expanded_url" : "http:\/\/bit.ly\/1Is803k",
      "display_url" : "bit.ly\/1Is803k"
    } ]
  },
  "geo" : { },
  "id_str" : "597192632184545280",
  "text" : "Worth a read: \"@Marty_Walsh seeks 1000 mentors for young men\" by the @BostonGlobe: http:\/\/t.co\/DkvIT3edO5 #MyBrothersKeeper",
  "id" : 597192632184545280,
  "created_at" : "2015-05-10 00:13:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Bai",
      "screen_name" : "mattbai",
      "indices" : [ 36, 44 ],
      "id_str" : "16340501",
      "id" : 16340501
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/T2uD1oFhPp",
      "expanded_url" : "http:\/\/yhoo.it\/obamainterview",
      "display_url" : "yhoo.it\/obamainterview"
    } ]
  },
  "geo" : { },
  "id_str" : "597128976948011008",
  "text" : "Watch President Obama sit down with @MattBai to talk about how his trade deal will benefit American workers: http:\/\/t.co\/T2uD1oFhPp",
  "id" : 597128976948011008,
  "created_at" : "2015-05-09 20:00:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Bai",
      "screen_name" : "mattbai",
      "indices" : [ 3, 11 ],
      "id_str" : "16340501",
      "id" : 16340501
    }, {
      "name" : "Yahoo Politics",
      "screen_name" : "YahooPolitics",
      "indices" : [ 25, 39 ],
      "id_str" : "3015101849",
      "id" : 3015101849
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/1RVoSXWk5e",
      "expanded_url" : "https:\/\/www.yahoo.com\/politics\/why-obama-is-happy-to-fight-elizabeth-warren-on-118537612596.html?soc_src=unv-sh&soc_trk=tw",
      "display_url" : "yahoo.com\/politics\/why-o\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "597121052712574976",
  "text" : "RT @mattbai: Live now on @YahooPolitics, my column and interview with the president. https:\/\/t.co\/1RVoSXWk5e",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Yahoo Politics",
        "screen_name" : "YahooPolitics",
        "indices" : [ 12, 26 ],
        "id_str" : "3015101849",
        "id" : 3015101849
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/1RVoSXWk5e",
        "expanded_url" : "https:\/\/www.yahoo.com\/politics\/why-obama-is-happy-to-fight-elizabeth-warren-on-118537612596.html?soc_src=unv-sh&soc_trk=tw",
        "display_url" : "yahoo.com\/politics\/why-o\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "597101901587427328",
    "text" : "Live now on @YahooPolitics, my column and interview with the president. https:\/\/t.co\/1RVoSXWk5e",
    "id" : 597101901587427328,
    "created_at" : "2015-05-09 18:12:41 +0000",
    "user" : {
      "name" : "Matt Bai",
      "screen_name" : "mattbai",
      "protected" : false,
      "id_str" : "16340501",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/422425798570561536\/QlfCl84h_normal.jpeg",
      "id" : 16340501,
      "verified" : true
    }
  },
  "id" : 597121052712574976,
  "created_at" : "2015-05-09 19:28:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 106, 115 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/597069762615709696\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/3aVFRUpsKq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEk3x9MWAAI66jF.png",
      "id_str" : "597069756982755330",
      "id" : 597069756982755330,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEk3x9MWAAI66jF.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 321,
        "resize" : "fit",
        "w" : 725
      }, {
        "h" : 321,
        "resize" : "fit",
        "w" : 725
      }, {
        "h" : 151,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 266,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/3aVFRUpsKq"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "597069762615709696",
  "text" : "\"The Republic of Liberia reached the important milestone of 42 days without reporting a new Ebola case.\" \u2014@PressSec: http:\/\/t.co\/3aVFRUpsKq",
  "id" : 597069762615709696,
  "created_at" : "2015-05-09 16:04:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596812336352100353",
  "text" : "\"'The road to freedom,' he said, 'Here and everywhere on earth, begins in the classroom.'\" \u2014President Obama quoting Hubert Humphrey",
  "id" : 596812336352100353,
  "created_at" : "2015-05-08 23:02:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CommunityCollege",
      "indices" : [ 30, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/NuLv1VtCzz",
      "expanded_url" : "http:\/\/go.wh.gov\/eQTEaU",
      "display_url" : "go.wh.gov\/eQTEaU"
    } ]
  },
  "geo" : { },
  "id_str" : "596811336237060096",
  "text" : "\"We need to make two years of #CommunityCollege as free and universal as high school is today.\" \u2014President Obama: http:\/\/t.co\/NuLv1VtCzz",
  "id" : 596811336237060096,
  "created_at" : "2015-05-08 22:58:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/596811078182555649\/photo\/1",
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/8bZ1RnJl1O",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEhMe5OWMAAO1vo.jpg",
      "id_str" : "596811044267372544",
      "id" : 596811044267372544,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEhMe5OWMAAO1vo.jpg",
      "sizes" : [ {
        "h" : 1327,
        "resize" : "fit",
        "w" : 1991
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/8bZ1RnJl1O"
    } ],
    "hashtags" : [ {
      "text" : "CommunityCollege",
      "indices" : [ 15, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596811078182555649",
  "text" : "\"We could make #CommunityCollege free for an entire generation of young Americans.\" \u2014President Obama http:\/\/t.co\/8bZ1RnJl1O",
  "id" : 596811078182555649,
  "created_at" : "2015-05-08 22:57:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/596810937237164032\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/2qpbLLNCQd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEhMWVyXIAA872S.jpg",
      "id_str" : "596810897315799040",
      "id" : 596810897315799040,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEhMWVyXIAA872S.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/2qpbLLNCQd"
    } ],
    "hashtags" : [ {
      "text" : "CommunityCollege",
      "indices" : [ 29, 46 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/NuLv1VtCzz",
      "expanded_url" : "http:\/\/go.wh.gov\/eQTEaU",
      "display_url" : "go.wh.gov\/eQTEaU"
    } ]
  },
  "geo" : { },
  "id_str" : "596810937237164032",
  "text" : "\"I want to lower the cost of #CommunityCollege in America to zero.\" \u2014President Obama: http:\/\/t.co\/NuLv1VtCzz http:\/\/t.co\/2qpbLLNCQd",
  "id" : 596810937237164032,
  "created_at" : "2015-05-08 22:56:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596810640653742081",
  "text" : "RT @WHLive: \"We should have faith in people like you. We should invest in people like you.\" \u2014President Obama to the graduates at @LakeAreaT\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "LakeAreaTech",
        "screen_name" : "LakeAreaTech",
        "indices" : [ 117, 130 ],
        "id_str" : "18902057",
        "id" : 18902057
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "596810616033124352",
    "text" : "\"We should have faith in people like you. We should invest in people like you.\" \u2014President Obama to the graduates at @LakeAreaTech",
    "id" : 596810616033124352,
    "created_at" : "2015-05-08 22:55:13 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 596810640653742081,
  "created_at" : "2015-05-08 22:55:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LakeAreaTech",
      "screen_name" : "LakeAreaTech",
      "indices" : [ 109, 122 ],
      "id_str" : "18902057",
      "id" : 18902057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596810250642169858",
  "text" : "\"I didn\u2019t come here to inspire you. I came here because you, the graduates, inspire me.\" \u2014President Obama at @LakeAreaTech",
  "id" : 596810250642169858,
  "created_at" : "2015-05-08 22:53:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596810041048625153",
  "text" : "RT @WHLive: \"All of us are better off when our businesses have access to the best-trained workers in the world.\" \u2014President Obama #Communit\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CommunityCollege",
        "indices" : [ 118, 135 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "596810007091482624",
    "text" : "\"All of us are better off when our businesses have access to the best-trained workers in the world.\" \u2014President Obama #CommunityCollege",
    "id" : 596810007091482624,
    "created_at" : "2015-05-08 22:52:48 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 596810041048625153,
  "created_at" : "2015-05-08 22:52:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "LakeAreaTech",
      "screen_name" : "LakeAreaTech",
      "indices" : [ 87, 100 ],
      "id_str" : "18902057",
      "id" : 18902057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596809803806150656",
  "text" : "RT @WHLive: \"Sergeant Wiskur is one of 35 service members and veterans graduating from @LakeAreaTech today...I couldn\u2019t be prouder of you.\"\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "LakeAreaTech",
        "screen_name" : "LakeAreaTech",
        "indices" : [ 75, 88 ],
        "id_str" : "18902057",
        "id" : 18902057
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "596809777692422144",
    "text" : "\"Sergeant Wiskur is one of 35 service members and veterans graduating from @LakeAreaTech today...I couldn\u2019t be prouder of you.\" \u2014Obama",
    "id" : 596809777692422144,
    "created_at" : "2015-05-08 22:51:53 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 596809803806150656,
  "created_at" : "2015-05-08 22:52:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596807399471751169",
  "text" : "RT @WHLive: \"Few institutions are more important to America\u2019s economic future than community colleges\" \u2014President Obama: http:\/\/t.co\/cUnDrd\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/cUnDrdyBW2",
        "expanded_url" : "http:\/\/go.wh.gov\/eQTEaU",
        "display_url" : "go.wh.gov\/eQTEaU"
      } ]
    },
    "geo" : { },
    "id_str" : "596807377028050944",
    "text" : "\"Few institutions are more important to America\u2019s economic future than community colleges\" \u2014President Obama: http:\/\/t.co\/cUnDrdyBW2",
    "id" : 596807377028050944,
    "created_at" : "2015-05-08 22:42:21 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 596807399471751169,
  "created_at" : "2015-05-08 22:42:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LakeAreaTech",
      "screen_name" : "LakeAreaTech",
      "indices" : [ 105, 118 ],
      "id_str" : "18902057",
      "id" : 18902057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596806316728909825",
  "text" : "\"I have now been to all 50 states as President, and I was saving the best for last!\" \u2014President Obama at @LakeAreaTech in South Dakota",
  "id" : 596806316728909825,
  "created_at" : "2015-05-08 22:38:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LakeAreaTech",
      "screen_name" : "LakeAreaTech",
      "indices" : [ 73, 86 ],
      "id_str" : "18902057",
      "id" : 18902057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/NuLv1VtCzz",
      "expanded_url" : "http:\/\/go.wh.gov\/eQTEaU",
      "display_url" : "go.wh.gov\/eQTEaU"
    } ]
  },
  "geo" : { },
  "id_str" : "596806118669742081",
  "text" : "\"Hello, Watertown! It's good to be in South Dakota!\" \u2014President Obama at @LakeAreaTech.\nWatch \u2192 http:\/\/t.co\/NuLv1VtCzz",
  "id" : 596806118669742081,
  "created_at" : "2015-05-08 22:37:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Simas44\/status\/596804507721400320\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/m4DVR66yt8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEhGgoNUkAAD_gg.jpg",
      "id_str" : "596804476989640704",
      "id" : 596804476989640704,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEhGgoNUkAAD_gg.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/m4DVR66yt8"
    } ],
    "hashtags" : [ {
      "text" : "BestforLast",
      "indices" : [ 98, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596804747824332800",
  "text" : "RT @Simas44: So great to be in Watertown, SD to honor Lake Area Tech grads!    POTUS' 50th state. #BestforLast http:\/\/t.co\/m4DVR66yt8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Simas44\/status\/596804507721400320\/photo\/1",
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/m4DVR66yt8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CEhGgoNUkAAD_gg.jpg",
        "id_str" : "596804476989640704",
        "id" : 596804476989640704,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEhGgoNUkAAD_gg.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/m4DVR66yt8"
      } ],
      "hashtags" : [ {
        "text" : "BestforLast",
        "indices" : [ 85, 97 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "596804507721400320",
    "text" : "So great to be in Watertown, SD to honor Lake Area Tech grads!    POTUS' 50th state. #BestforLast http:\/\/t.co\/m4DVR66yt8",
    "id" : 596804507721400320,
    "created_at" : "2015-05-08 22:30:57 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 596804747824332800,
  "created_at" : "2015-05-08 22:31:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/596793085792751617\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/IvgsRGHp0N",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEg7zwKWoAMlaa3.jpg",
      "id_str" : "596792710914285571",
      "id" : 596792710914285571,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEg7zwKWoAMlaa3.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/IvgsRGHp0N"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/6EVM3UqPsS",
      "expanded_url" : "http:\/\/go.wh.gov\/50States",
      "display_url" : "go.wh.gov\/50States"
    } ]
  },
  "geo" : { },
  "id_str" : "596793085792751617",
  "text" : "Wheels down in South Dakota\u2014the 50th state President Obama has visited since taking office. http:\/\/t.co\/6EVM3UqPsS http:\/\/t.co\/IvgsRGHp0N",
  "id" : 596793085792751617,
  "created_at" : "2015-05-08 21:45:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/596788470275842049\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/hvKzAPqJDb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEg2zNOWEAAyK3B.jpg",
      "id_str" : "596787203977646080",
      "id" : 596787203977646080,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEg2zNOWEAAyK3B.jpg",
      "sizes" : [ {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/hvKzAPqJDb"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/49OXOAjjQF",
      "expanded_url" : "http:\/\/go.wh.gov\/50states",
      "display_url" : "go.wh.gov\/50states"
    } ]
  },
  "geo" : { },
  "id_str" : "596788470275842049",
  "text" : "President Obama has now visited all 50 states since taking office.\nCheck out the highlights: http:\/\/t.co\/49OXOAjjQF http:\/\/t.co\/hvKzAPqJDb",
  "id" : 596788470275842049,
  "created_at" : "2015-05-08 21:27:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LakeAreaTech",
      "screen_name" : "LakeAreaTech",
      "indices" : [ 3, 16 ],
      "id_str" : "18902057",
      "id" : 18902057
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/LakeAreaTech\/status\/596762975878295552\/photo\/1",
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/3yafRppDbn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEggw2AUEAAHac8.jpg",
      "id_str" : "596762974129229824",
      "id" : 596762974129229824,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEggw2AUEAAHac8.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/3yafRppDbn"
    } ],
    "hashtags" : [ {
      "text" : "LATI",
      "indices" : [ 39, 44 ]
    }, {
      "text" : "Graduation",
      "indices" : [ 45, 56 ]
    }, {
      "text" : "ObamaAtLATI",
      "indices" : [ 57, 69 ]
    }, {
      "text" : "POTUS",
      "indices" : [ 70, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596783092922060800",
  "text" : "RT @LakeAreaTech: Starting to fill up. #LATI #Graduation #ObamaAtLATI #POTUS http:\/\/t.co\/3yafRppDbn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/LakeAreaTech\/status\/596762975878295552\/photo\/1",
        "indices" : [ 59, 81 ],
        "url" : "http:\/\/t.co\/3yafRppDbn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CEggw2AUEAAHac8.jpg",
        "id_str" : "596762974129229824",
        "id" : 596762974129229824,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEggw2AUEAAHac8.jpg",
        "sizes" : [ {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/3yafRppDbn"
      } ],
      "hashtags" : [ {
        "text" : "LATI",
        "indices" : [ 21, 26 ]
      }, {
        "text" : "Graduation",
        "indices" : [ 27, 38 ]
      }, {
        "text" : "ObamaAtLATI",
        "indices" : [ 39, 51 ]
      }, {
        "text" : "POTUS",
        "indices" : [ 52, 58 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "596762975878295552",
    "text" : "Starting to fill up. #LATI #Graduation #ObamaAtLATI #POTUS http:\/\/t.co\/3yafRppDbn",
    "id" : 596762975878295552,
    "created_at" : "2015-05-08 19:45:55 +0000",
    "user" : {
      "name" : "LakeAreaTech",
      "screen_name" : "LakeAreaTech",
      "protected" : false,
      "id_str" : "18902057",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1541148623\/lati_normal.jpg",
      "id" : 18902057,
      "verified" : false
    }
  },
  "id" : 596783092922060800,
  "created_at" : "2015-05-08 21:05:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LakeAreaTech",
      "screen_name" : "LakeAreaTech",
      "indices" : [ 67, 80 ],
      "id_str" : "18902057",
      "id" : 18902057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/j3tF5N8F7P",
      "expanded_url" : "http:\/\/go.wh.gov\/LakeAreaTech",
      "display_url" : "go.wh.gov\/LakeAreaTech"
    } ]
  },
  "geo" : { },
  "id_str" : "596771578890727425",
  "text" : "President Obama's headed to SD to give the commencement address at @LakeAreaTech.\nHear from the graduating class: http:\/\/t.co\/j3tF5N8F7P",
  "id" : 596771578890727425,
  "created_at" : "2015-05-08 20:20:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Hanks",
      "screen_name" : "tomhanks",
      "indices" : [ 39, 48 ],
      "id_str" : "50374439",
      "id" : 50374439
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/596763845990973440\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/8ibV5YcA9g",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEgg_V2W8AEuXBx.jpg",
      "id_str" : "596763223195578369",
      "id" : 596763223195578369,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEgg_V2W8AEuXBx.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/8ibV5YcA9g"
    } ],
    "hashtags" : [ {
      "text" : "CommunityCollege",
      "indices" : [ 70, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/iwsEpNwFDY",
      "expanded_url" : "http:\/\/go.wh.gov\/ZK7Kbn",
      "display_url" : "go.wh.gov\/ZK7Kbn"
    } ]
  },
  "geo" : { },
  "id_str" : "596763845990973440",
  "text" : "\"That place made me what I am today.\" \u2014@TomHanks on the importance of #CommunityCollege: http:\/\/t.co\/iwsEpNwFDY http:\/\/t.co\/8ibV5YcA9g",
  "id" : 596763845990973440,
  "created_at" : "2015-05-08 19:49:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LeadOnTrade",
      "indices" : [ 13, 25 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/6DWm9JG7yc",
      "expanded_url" : "http:\/\/snpy.tv\/1H4fGqN",
      "display_url" : "snpy.tv\/1H4fGqN"
    } ]
  },
  "geo" : { },
  "id_str" : "596754860806111232",
  "text" : "It's time to #LeadOnTrade and pass a trade deal that helps Americans get ahead. http:\/\/t.co\/6DWm9JG7yc",
  "id" : 596754860806111232,
  "created_at" : "2015-05-08 19:13:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/596725524002709504\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/ao7JI15X8d",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEf-kWGWAAAq9c7.jpg",
      "id_str" : "596725376010813440",
      "id" : 596725376010813440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEf-kWGWAAAq9c7.jpg",
      "sizes" : [ {
        "h" : 700,
        "resize" : "fit",
        "w" : 1050
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ao7JI15X8d"
    } ],
    "hashtags" : [ {
      "text" : "LeadOnTrade",
      "indices" : [ 95, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596725524002709504",
  "text" : "\u201CWhen the playing field is level, nobody beats the United States of America.\u201D \u2014President Obama #LeadOnTrade http:\/\/t.co\/ao7JI15X8d",
  "id" : 596725524002709504,
  "created_at" : "2015-05-08 17:17:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596724364378296322",
  "text" : "RT @WHLive: \u201CIf any agreement undercuts working families, I won\u2019t sign it. I ran for office to expand opportunity for everybody.\u201D \u2014Obama #L\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LeadOnTrade",
        "indices" : [ 125, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "596724341519339521",
    "text" : "\u201CIf any agreement undercuts working families, I won\u2019t sign it. I ran for office to expand opportunity for everybody.\u201D \u2014Obama #LeadOnTrade",
    "id" : 596724341519339521,
    "created_at" : "2015-05-08 17:12:24 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 596724364378296322,
  "created_at" : "2015-05-08 17:12:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nike",
      "screen_name" : "Nike",
      "indices" : [ 68, 73 ],
      "id_str" : "415859364",
      "id" : 415859364
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/596724029375000576\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/mFatKykmNG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEf9QI0WgAEyfTB.jpg",
      "id_str" : "596723929336676353",
      "id" : 596723929336676353,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEf9QI0WgAEyfTB.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/mFatKykmNG"
    } ],
    "hashtags" : [ {
      "text" : "LeadOnTrade",
      "indices" : [ 98, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/mpl8VkXIqG",
      "expanded_url" : "http:\/\/go.wh.gov\/RgLLfc",
      "display_url" : "go.wh.gov\/RgLLfc"
    } ]
  },
  "geo" : { },
  "id_str" : "596724029375000576",
  "text" : "\"This deal would be a good thing. So let\u2019s 'just do it.'\" \u2014Obama at @Nike: http:\/\/t.co\/mpl8VkXIqG #LeadOnTrade http:\/\/t.co\/mFatKykmNG",
  "id" : 596724029375000576,
  "created_at" : "2015-05-08 17:11:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/596721324103507969\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/53Gv4E3el1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEf6xfgXIAA1Vjj.jpg",
      "id_str" : "596721203827646464",
      "id" : 596721203827646464,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEf6xfgXIAA1Vjj.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/53Gv4E3el1"
    } ],
    "hashtags" : [ {
      "text" : "LeadOnTrade",
      "indices" : [ 98, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596721324103507969",
  "text" : "\u201CBeef\u2019s really expensive in Japan. Let\u2019s make sure they try some Oregon steaks.\u201D \u2014President Obama #LeadOnTrade http:\/\/t.co\/53Gv4E3el1",
  "id" : 596721324103507969,
  "created_at" : "2015-05-08 17:00:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/596720419064967168\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/h9lEkS5i1L",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEf5_RJWAAAp0KP.jpg",
      "id_str" : "596720340979548160",
      "id" : 596720340979548160,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEf5_RJWAAAp0KP.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/h9lEkS5i1L"
    } ],
    "hashtags" : [ {
      "text" : "LeadOnTrade",
      "indices" : [ 104, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596720419064967168",
  "text" : "\"It\u2019s the highest-standard, most progressive trade deal in history.\u201D \u2014President Obama on his trade deal #LeadOnTrade http:\/\/t.co\/h9lEkS5i1L",
  "id" : 596720419064967168,
  "created_at" : "2015-05-08 16:56:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/596719954608693248\/photo\/1",
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/neI5uRp4Ud",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEf5XOwWYAEdILo.jpg",
      "id_str" : "596719653143076865",
      "id" : 596719653143076865,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEf5XOwWYAEdILo.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/neI5uRp4Ud"
    } ],
    "hashtags" : [ {
      "text" : "LeadOnTrade",
      "indices" : [ 64, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/g22IRK7AwH",
      "expanded_url" : "http:\/\/go.wh.gov\/ObamaAtNike",
      "display_url" : "go.wh.gov\/ObamaAtNike"
    } ]
  },
  "geo" : { },
  "id_str" : "596719954608693248",
  "text" : "If we don't write the rules for trade, China will.\nIt's time to #LeadOnTrade: http:\/\/t.co\/g22IRK7AwH http:\/\/t.co\/neI5uRp4Ud",
  "id" : 596719954608693248,
  "created_at" : "2015-05-08 16:54:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/596719509672689664\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/uGUCS6dqK5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEf5N21W0AAp2ho.jpg",
      "id_str" : "596719492102803456",
      "id" : 596719492102803456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEf5N21W0AAp2ho.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/uGUCS6dqK5"
    } ],
    "hashtags" : [ {
      "text" : "LeadOnTrade",
      "indices" : [ 92, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596719509672689664",
  "text" : "\"I view smart trade agreements as a vital piece of middle-class economics\" \u2014President Obama #LeadOnTrade http:\/\/t.co\/uGUCS6dqK5",
  "id" : 596719509672689664,
  "created_at" : "2015-05-08 16:53:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/596719282676989952\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/iJssfMEZTf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEf471dWIAAHdpC.jpg",
      "id_str" : "596719182496014336",
      "id" : 596719182496014336,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEf471dWIAAHdpC.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      } ],
      "display_url" : "pic.twitter.com\/iJssfMEZTf"
    } ],
    "hashtags" : [ {
      "text" : "LeadOnTrade",
      "indices" : [ 92, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596719282676989952",
  "text" : "\"Small businesses have created nearly 2 out of every 3 new American jobs.\" \u2014President Obama #LeadOnTrade http:\/\/t.co\/iJssfMEZTf",
  "id" : 596719282676989952,
  "created_at" : "2015-05-08 16:52:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/596718733671936002\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/yHt3UWSs9a",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEf4TmaXIAAPqD8.jpg",
      "id_str" : "596718491262197760",
      "id" : 596718491262197760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEf4TmaXIAAPqD8.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/yHt3UWSs9a"
    } ],
    "hashtags" : [ {
      "text" : "LeadOnTrade",
      "indices" : [ 99, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596718733671936002",
  "text" : "\"The unemployment rate ticked down again to 5.4%...the lowest it\u2019s been in almost 7 years.\" \u2014Obama #LeadOnTrade http:\/\/t.co\/yHt3UWSs9a",
  "id" : 596718733671936002,
  "created_at" : "2015-05-08 16:50:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nike",
      "screen_name" : "Nike",
      "indices" : [ 61, 66 ],
      "id_str" : "415859364",
      "id" : 415859364
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/596718363574935553\/photo\/1",
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/xVU1ZME7gO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEf4LRgWYAAeteF.jpg",
      "id_str" : "596718348211216384",
      "id" : 596718348211216384,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEf4LRgWYAAeteF.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/xVU1ZME7gO"
    } ],
    "hashtags" : [ {
      "text" : "LeadOnTrade",
      "indices" : [ 67, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596718363574935553",
  "text" : "\"98% of exporters are small businesses.\" \u2014President Obama at @Nike #LeadOnTrade http:\/\/t.co\/xVU1ZME7gO",
  "id" : 596718363574935553,
  "created_at" : "2015-05-08 16:48:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nike",
      "screen_name" : "Nike",
      "indices" : [ 92, 97 ],
      "id_str" : "415859364",
      "id" : 415859364
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LeadOnTrade",
      "indices" : [ 122, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/g22IRK7AwH",
      "expanded_url" : "http:\/\/go.wh.gov\/ObamaAtNike",
      "display_url" : "go.wh.gov\/ObamaAtNike"
    } ]
  },
  "geo" : { },
  "id_str" : "596717865568440320",
  "text" : "\"It is great to be at the world headquarters of such an iconic company\" \u2014President Obama at @Nike: http:\/\/t.co\/g22IRK7AwH #LeadOnTrade",
  "id" : 596717865568440320,
  "created_at" : "2015-05-08 16:46:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nike",
      "screen_name" : "Nike",
      "indices" : [ 38, 43 ],
      "id_str" : "415859364",
      "id" : 415859364
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LeadOnTrade",
      "indices" : [ 121, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/g22IRK7AwH",
      "expanded_url" : "http:\/\/go.wh.gov\/ObamaAtNike",
      "display_url" : "go.wh.gov\/ObamaAtNike"
    } ]
  },
  "geo" : { },
  "id_str" : "596717168563224577",
  "text" : "Watch live: President Obama speaks at @Nike on how his trade deal will benefit American workers \u2192 http:\/\/t.co\/g22IRK7AwH #LeadOnTrade",
  "id" : 596717168563224577,
  "created_at" : "2015-05-08 16:43:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nike",
      "screen_name" : "Nike",
      "indices" : [ 16, 21 ],
      "id_str" : "415859364",
      "id" : 415859364
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/596704859556028416\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/ADExsVilyr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEfphbhWoAAzLM8.jpg",
      "id_str" : "596702236182487040",
      "id" : 596702236182487040,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEfphbhWoAAzLM8.jpg",
      "sizes" : [ {
        "h" : 869,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 999,
        "resize" : "fit",
        "w" : 690
      }, {
        "h" : 492,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 999,
        "resize" : "fit",
        "w" : 690
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/ADExsVilyr"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/g22IRK7AwH",
      "expanded_url" : "http:\/\/go.wh.gov\/ObamaAtNike",
      "display_url" : "go.wh.gov\/ObamaAtNike"
    } ]
  },
  "geo" : { },
  "id_str" : "596704859556028416",
  "text" : "Air POTUS is at @Nike today to speak on why his trade deal would benefit U.S. workers.\nWatch \u2192 http:\/\/t.co\/g22IRK7AwH http:\/\/t.co\/ADExsVilyr",
  "id" : 596704859556028416,
  "created_at" : "2015-05-08 15:54:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UK Prime Minister",
      "screen_name" : "Number10gov",
      "indices" : [ 35, 47 ],
      "id_str" : "14224719",
      "id" : 14224719
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/596698464777539585\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/WbyV574Gj8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEflSnMWAAArn_t.png",
      "id_str" : "596697583571042304",
      "id" : 596697583571042304,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEflSnMWAAArn_t.png",
      "sizes" : [ {
        "h" : 238,
        "resize" : "fit",
        "w" : 962
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 84,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 148,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 238,
        "resize" : "fit",
        "w" : 962
      } ],
      "display_url" : "pic.twitter.com\/WbyV574Gj8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596698464777539585",
  "text" : "President Obama just congratulated @Number10Gov on his impressive victory in yesterday's election. http:\/\/t.co\/WbyV574Gj8",
  "id" : 596698464777539585,
  "created_at" : "2015-05-08 15:29:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/596692271216603138\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/JU8lGkKIZ8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEfftGBW8AEfE-B.jpg",
      "id_str" : "596691441453297665",
      "id" : 596691441453297665,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEfftGBW8AEfE-B.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/JU8lGkKIZ8"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/4Vc0cDsSdZ",
      "expanded_url" : "http:\/\/go.wh.gov\/AprilJobs",
      "display_url" : "go.wh.gov\/AprilJobs"
    } ]
  },
  "geo" : { },
  "id_str" : "596692271216603138",
  "text" : "Worth a retweet: The unemployment rate has fallen to the lowest level since May 2008 \u2192 http:\/\/t.co\/4Vc0cDsSdZ http:\/\/t.co\/JU8lGkKIZ8",
  "id" : 596692271216603138,
  "created_at" : "2015-05-08 15:04:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/596677541211021312\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/xTevHCo9ZC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEfRqHFXIAAc7Eg.jpg",
      "id_str" : "596675997036126208",
      "id" : 596675997036126208,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEfRqHFXIAAc7Eg.jpg",
      "sizes" : [ {
        "h" : 818,
        "resize" : "fit",
        "w" : 637
      }, {
        "h" : 818,
        "resize" : "fit",
        "w" : 637
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 437,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 770,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/xTevHCo9ZC"
    } ],
    "hashtags" : [ {
      "text" : "VEDay70",
      "indices" : [ 108, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/mmZ9rP0gQ3",
      "expanded_url" : "http:\/\/go.wh.gov\/VEDay70",
      "display_url" : "go.wh.gov\/VEDay70"
    } ]
  },
  "geo" : { },
  "id_str" : "596677541211021312",
  "text" : "Ernest painted B-17s during World War II.\nCheck out his exchange with the President: http:\/\/t.co\/mmZ9rP0gQ3 #VEDay70 http:\/\/t.co\/xTevHCo9ZC",
  "id" : 596677541211021312,
  "created_at" : "2015-05-08 14:06:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/596670138415489024\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/ecLrykOQ9n",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEfMCI6WEAA3zIf.png",
      "id_str" : "596669812773883904",
      "id" : 596669812773883904,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEfMCI6WEAA3zIf.png",
      "sizes" : [ {
        "h" : 313,
        "resize" : "fit",
        "w" : 1208
      }, {
        "h" : 265,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 88,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 155,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/ecLrykOQ9n"
    } ],
    "hashtags" : [ {
      "text" : "VEDay70",
      "indices" : [ 108, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596670138415489024",
  "text" : "\"70 years ago today, the Allied Forces declared victory in Europe over tyranny during World War II.\" \u2014Obama #VEDay70 http:\/\/t.co\/ecLrykOQ9n",
  "id" : 596670138415489024,
  "created_at" : "2015-05-08 13:37:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VEDay70",
      "indices" : [ 94, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/zsWg16fewm",
      "expanded_url" : "http:\/\/go.wh.gov\/vQgxEW",
      "display_url" : "go.wh.gov\/vQgxEW"
    } ]
  },
  "geo" : { },
  "id_str" : "596665291473555456",
  "text" : "\"We will be forever grateful for what these remarkable men and women did\" \u2014President Obama on #VEDay70: http:\/\/t.co\/zsWg16fewm",
  "id" : 596665291473555456,
  "created_at" : "2015-05-08 13:17:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/596492936923058176\/photo\/1",
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/OLWSrENznG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEcqzzUXIAI3o3a.jpg",
      "id_str" : "596492545087184898",
      "id" : 596492545087184898,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEcqzzUXIAI3o3a.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/OLWSrENznG"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596492936923058176",
  "text" : "Mount Hood \uD83D\uDDFB from Air Force One \u2708 http:\/\/t.co\/OLWSrENznG",
  "id" : 596492936923058176,
  "created_at" : "2015-05-08 01:52:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 99, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596464361792638976",
  "text" : "RT @FLOTUS: Every student in America should have access to a quality, affordable higher education. #CollegeOpportunity http:\/\/t.co\/MVFstkpl\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/596460091852873729\/photo\/1",
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/MVFstkplkA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CEcNSgwWoAAUMTD.jpg",
        "id_str" : "596460087331430400",
        "id" : 596460087331430400,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEcNSgwWoAAUMTD.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/MVFstkplkA"
      } ],
      "hashtags" : [ {
        "text" : "CollegeOpportunity",
        "indices" : [ 87, 106 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "596460091852873729",
    "text" : "Every student in America should have access to a quality, affordable higher education. #CollegeOpportunity http:\/\/t.co\/MVFstkplkA",
    "id" : 596460091852873729,
    "created_at" : "2015-05-07 23:42:22 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 596464361792638976,
  "created_at" : "2015-05-07 23:59:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kid President",
      "screen_name" : "iamkidpresident",
      "indices" : [ 3, 19 ],
      "id_str" : "627799297",
      "id" : 627799297
    }, {
      "name" : "Kid President",
      "screen_name" : "iamkidpresident",
      "indices" : [ 81, 97 ],
      "id_str" : "627799297",
      "id" : 627799297
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/5TOxumJjsq",
      "expanded_url" : "http:\/\/bit.ly\/1H4iPd7",
      "display_url" : "bit.ly\/1H4iPd7"
    } ]
  },
  "geo" : { },
  "id_str" : "596458289157640192",
  "text" : "RT @iamkidpresident: We made a new video! Dear Graduates, a special message from @iamkidpresident: http:\/\/t.co\/5TOxumJjsq http:\/\/t.co\/wexA7\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kid President",
        "screen_name" : "iamkidpresident",
        "indices" : [ 60, 76 ],
        "id_str" : "627799297",
        "id" : 627799297
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/iamkidpresident\/status\/596378171676561408\/photo\/1",
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/wexA7P2mjX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CEbCyPJWAAITU6k.jpg",
        "id_str" : "596378168988139522",
        "id" : 596378168988139522,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEbCyPJWAAITU6k.jpg",
        "sizes" : [ {
          "h" : 141,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 426,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 250,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 426,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/wexA7P2mjX"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/5TOxumJjsq",
        "expanded_url" : "http:\/\/bit.ly\/1H4iPd7",
        "display_url" : "bit.ly\/1H4iPd7"
      } ]
    },
    "geo" : { },
    "id_str" : "596378171676561408",
    "text" : "We made a new video! Dear Graduates, a special message from @iamkidpresident: http:\/\/t.co\/5TOxumJjsq http:\/\/t.co\/wexA7P2mjX",
    "id" : 596378171676561408,
    "created_at" : "2015-05-07 18:16:50 +0000",
    "user" : {
      "name" : "Kid President",
      "screen_name" : "iamkidpresident",
      "protected" : false,
      "id_str" : "627799297",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2373000215\/qkp8f7490xr28uznmnkq_normal.jpeg",
      "id" : 627799297,
      "verified" : false
    }
  },
  "id" : 596458289157640192,
  "created_at" : "2015-05-07 23:35:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsay Holst",
      "screen_name" : "Holst44",
      "indices" : [ 3, 11 ],
      "id_str" : "1563426390",
      "id" : 1563426390
    }, {
      "name" : "LakeAreaTech",
      "screen_name" : "LakeAreaTech",
      "indices" : [ 42, 55 ],
      "id_str" : "18902057",
      "id" : 18902057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596452958356709376",
  "text" : "RT @Holst44: Before tomorrow's address at @LakeAreaTech: Meet the 11-year-old whose heart the President is about to un-break \u2192 http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "LakeAreaTech",
        "screen_name" : "LakeAreaTech",
        "indices" : [ 29, 42 ],
        "id_str" : "18902057",
        "id" : 18902057
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/Xpw5P7EesR",
        "expanded_url" : "http:\/\/go.wh.gov\/AvdE7j",
        "display_url" : "go.wh.gov\/AvdE7j"
      } ]
    },
    "geo" : { },
    "id_str" : "596452656010240000",
    "text" : "Before tomorrow's address at @LakeAreaTech: Meet the 11-year-old whose heart the President is about to un-break \u2192 http:\/\/t.co\/Xpw5P7EesR",
    "id" : 596452656010240000,
    "created_at" : "2015-05-07 23:12:49 +0000",
    "user" : {
      "name" : "Lindsay Holst",
      "screen_name" : "Holst44",
      "protected" : false,
      "id_str" : "1563426390",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615987325261082625\/QxtC65p2_normal.jpg",
      "id" : 1563426390,
      "verified" : true
    }
  },
  "id" : 596452958356709376,
  "created_at" : "2015-05-07 23:14:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Esri",
      "screen_name" : "Esri",
      "indices" : [ 3, 8 ],
      "id_str" : "16132791",
      "id" : 16132791
    }, {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 35, 45 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Esri\/status\/596411672799027200\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/wl7GVqKkCQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEbhQWzUgAA7X3H.jpg",
      "id_str" : "596411671788158976",
      "id" : 596411671788158976,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEbhQWzUgAA7X3H.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 314,
        "resize" : "fit",
        "w" : 558
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 314,
        "resize" : "fit",
        "w" : 558
      }, {
        "h" : 314,
        "resize" : "fit",
        "w" : 558
      } ],
      "display_url" : "pic.twitter.com\/wl7GVqKkCQ"
    } ],
    "hashtags" : [ {
      "text" : "WhiteHouse",
      "indices" : [ 10, 21 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/CstH0v4Tj8",
      "expanded_url" : "http:\/\/story.maps.arcgis.com\/apps\/MapTour\/?appid=85fab35a73e149dea8507f0c749165fa#",
      "display_url" : "story.maps.arcgis.com\/apps\/MapTour\/?\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "596421438984298496",
  "text" : "RT @Esri: #WhiteHouse photographer @petesouza travels across the U.S. with President Obama http:\/\/t.co\/CstH0v4Tj8 http:\/\/t.co\/wl7GVqKkCQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "petesouza",
        "screen_name" : "petesouza",
        "indices" : [ 25, 35 ],
        "id_str" : "18215973",
        "id" : 18215973
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Esri\/status\/596411672799027200\/photo\/1",
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/wl7GVqKkCQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CEbhQWzUgAA7X3H.jpg",
        "id_str" : "596411671788158976",
        "id" : 596411671788158976,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEbhQWzUgAA7X3H.jpg",
        "sizes" : [ {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 314,
          "resize" : "fit",
          "w" : 558
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 314,
          "resize" : "fit",
          "w" : 558
        }, {
          "h" : 314,
          "resize" : "fit",
          "w" : 558
        } ],
        "display_url" : "pic.twitter.com\/wl7GVqKkCQ"
      } ],
      "hashtags" : [ {
        "text" : "WhiteHouse",
        "indices" : [ 0, 11 ]
      } ],
      "urls" : [ {
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/CstH0v4Tj8",
        "expanded_url" : "http:\/\/story.maps.arcgis.com\/apps\/MapTour\/?appid=85fab35a73e149dea8507f0c749165fa#",
        "display_url" : "story.maps.arcgis.com\/apps\/MapTour\/?\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "596411672799027200",
    "text" : "#WhiteHouse photographer @petesouza travels across the U.S. with President Obama http:\/\/t.co\/CstH0v4Tj8 http:\/\/t.co\/wl7GVqKkCQ",
    "id" : 596411672799027200,
    "created_at" : "2015-05-07 20:29:58 +0000",
    "user" : {
      "name" : "Esri",
      "screen_name" : "Esri",
      "protected" : false,
      "id_str" : "16132791",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/575037640224854017\/MudLFJqh_normal.png",
      "id" : 16132791,
      "verified" : true
    }
  },
  "id" : 596421438984298496,
  "created_at" : "2015-05-07 21:08:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/596416920573849602\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/FNsposqhaT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEbl26zWMAAYYL2.jpg",
      "id_str" : "596416732333486080",
      "id" : 596416732333486080,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEbl26zWMAAYYL2.jpg",
      "sizes" : [ {
        "h" : 643,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 643,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 420,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 643,
        "resize" : "fit",
        "w" : 520
      } ],
      "display_url" : "pic.twitter.com\/FNsposqhaT"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/Cm9KnTEfDR",
      "expanded_url" : "http:\/\/go.wh.gov\/AvdE7j",
      "display_url" : "go.wh.gov\/AvdE7j"
    } ]
  },
  "geo" : { },
  "id_str" : "596416920573849602",
  "text" : "Rebecca's heart can officially mend when President Obama visits South Dakota tomorrow \u2192 http:\/\/t.co\/Cm9KnTEfDR http:\/\/t.co\/FNsposqhaT",
  "id" : 596416920573849602,
  "created_at" : "2015-05-07 20:50:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 3, 11 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    }, {
      "name" : "Stephen Colbert",
      "screen_name" : "StephenAtHome",
      "indices" : [ 14, 28 ],
      "id_str" : "16303106",
      "id" : 16303106
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThankATeacher",
      "indices" : [ 50, 64 ]
    }, {
      "text" : "TeacherAppreciationWeek",
      "indices" : [ 114, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/L7bARtCFfe",
      "expanded_url" : "http:\/\/www.greenvilleonline.com\/story\/news\/local\/2015\/05\/07\/stephen-colbert-funding-grant-requests-south-carolina-public-school-teachers-donorschoose-crowdfunding-site\/70938100\/",
      "display_url" : "greenvilleonline.com\/story\/news\/loc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "596405300971745280",
  "text" : "RT @DrBiden: .@StephenAtHome answered the call to #ThankATeacher. Many teachers, in fact \u2192 http:\/\/t.co\/L7bARtCFfe #TeacherAppreciationWeek",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen Colbert",
        "screen_name" : "StephenAtHome",
        "indices" : [ 1, 15 ],
        "id_str" : "16303106",
        "id" : 16303106
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ThankATeacher",
        "indices" : [ 37, 51 ]
      }, {
        "text" : "TeacherAppreciationWeek",
        "indices" : [ 101, 125 ]
      } ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/L7bARtCFfe",
        "expanded_url" : "http:\/\/www.greenvilleonline.com\/story\/news\/local\/2015\/05\/07\/stephen-colbert-funding-grant-requests-south-carolina-public-school-teachers-donorschoose-crowdfunding-site\/70938100\/",
        "display_url" : "greenvilleonline.com\/story\/news\/loc\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "596404952349675520",
    "text" : ".@StephenAtHome answered the call to #ThankATeacher. Many teachers, in fact \u2192 http:\/\/t.co\/L7bARtCFfe #TeacherAppreciationWeek",
    "id" : 596404952349675520,
    "created_at" : "2015-05-07 20:03:15 +0000",
    "user" : {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "protected" : false,
      "id_str" : "1281405877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608687663034474496\/wvzVG_yt_normal.jpg",
      "id" : 1281405877,
      "verified" : true
    }
  },
  "id" : 596405300971745280,
  "created_at" : "2015-05-07 20:04:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/596400281610518531\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/gOSJs6oy7d",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEbWvo9W0AANLhG.jpg",
      "id_str" : "596400114610130944",
      "id" : 596400114610130944,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEbWvo9W0AANLhG.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/gOSJs6oy7d"
    } ],
    "hashtags" : [ {
      "text" : "CollegeOpportunity",
      "indices" : [ 86, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/Y6fFTZTkof",
      "expanded_url" : "http:\/\/go.wh.gov\/RWKLEH",
      "display_url" : "go.wh.gov\/RWKLEH"
    } ]
  },
  "geo" : { },
  "id_str" : "596400281610518531",
  "text" : "Here's how President Obama is making college more affordable \u2192 http:\/\/t.co\/Y6fFTZTkof #CollegeOpportunity http:\/\/t.co\/gOSJs6oy7d",
  "id" : 596400281610518531,
  "created_at" : "2015-05-07 19:44:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MothersDay",
      "indices" : [ 94, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596380482780147713",
  "text" : "RT @vj44: Have you or a mom in your life benefited from preventive health services since last #MothersDay? \n\nTweet your story using #Health\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MothersDay",
        "indices" : [ 84, 95 ]
      }, {
        "text" : "HealthyMoms",
        "indices" : [ 122, 134 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "596380266039365632",
    "text" : "Have you or a mom in your life benefited from preventive health services since last #MothersDay? \n\nTweet your story using #HealthyMoms",
    "id" : 596380266039365632,
    "created_at" : "2015-05-07 18:25:10 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 596380482780147713,
  "created_at" : "2015-05-07 18:26:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "USAFA (Official)",
      "screen_name" : "AF_Academy",
      "indices" : [ 127, 138 ],
      "id_str" : "69073724",
      "id" : 69073724
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596377748169330688",
  "text" : "RT @WHLive: \"I have no higher honor or greater responsibility than serving as your Commander-in-Chief\" \u2014President Obama to the @AF_Academy \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "USAFA (Official)",
        "screen_name" : "AF_Academy",
        "indices" : [ 115, 126 ],
        "id_str" : "69073724",
        "id" : 69073724
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "596377709955026944",
    "text" : "\"I have no higher honor or greater responsibility than serving as your Commander-in-Chief\" \u2014President Obama to the @AF_Academy football team",
    "id" : 596377709955026944,
    "created_at" : "2015-05-07 18:15:00 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 596377748169330688,
  "created_at" : "2015-05-07 18:15:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596376142937886720",
  "text" : "RT @WHLive: \"Congratulations to this year\u2019s winners of the Commander-in-Chief\u2019s Trophy, the Air Force Fighting Falcons!\" \u2014Obama: http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/mSjnYx99UB",
        "expanded_url" : "http:\/\/go.wh.gov\/sA2Apf",
        "display_url" : "go.wh.gov\/sA2Apf"
      } ]
    },
    "geo" : { },
    "id_str" : "596376093499662336",
    "text" : "\"Congratulations to this year\u2019s winners of the Commander-in-Chief\u2019s Trophy, the Air Force Fighting Falcons!\" \u2014Obama: http:\/\/t.co\/mSjnYx99UB",
    "id" : 596376093499662336,
    "created_at" : "2015-05-07 18:08:35 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 596376142937886720,
  "created_at" : "2015-05-07 18:08:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/596374741415497728\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/h7q1Pay5xw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEa_EmPWoAEdApR.jpg",
      "id_str" : "596374086378496001",
      "id" : 596374086378496001,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEa_EmPWoAEdApR.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/h7q1Pay5xw"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596374741415497728",
  "text" : "President Obama's action on student loans will help millions of Americans lower their monthly loan payments. http:\/\/t.co\/h7q1Pay5xw",
  "id" : 596374741415497728,
  "created_at" : "2015-05-07 18:03:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernest Moniz",
      "screen_name" : "ErnestMoniz",
      "indices" : [ 3, 15 ],
      "id_str" : "1393155566",
      "id" : 1393155566
    }, {
      "name" : "The Daily Show",
      "screen_name" : "TheDailyShow",
      "indices" : [ 35, 48 ],
      "id_str" : "158414847",
      "id" : 158414847
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranTalks",
      "indices" : [ 70, 80 ]
    }, {
      "text" : "QER",
      "indices" : [ 96, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/BErCBZa8ez",
      "expanded_url" : "http:\/\/on.cc.com\/1KOOQnM",
      "display_url" : "on.cc.com\/1KOOQnM"
    } ]
  },
  "geo" : { },
  "id_str" : "596368310205227008",
  "text" : "RT @ErnestMoniz: Watch video of my @TheDailyShow interview, including #IranTalks, vehicles, the #QER &amp; more. http:\/\/t.co\/BErCBZa8ez http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/measuredvoice.com\/\" rel=\"nofollow\"\u003EMeasured Voice\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Daily Show",
        "screen_name" : "TheDailyShow",
        "indices" : [ 18, 31 ],
        "id_str" : "158414847",
        "id" : 158414847
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ErnestMoniz\/status\/596362690802626561\/photo\/1",
        "indices" : [ 119, 141 ],
        "url" : "http:\/\/t.co\/AuzRhnRdtz",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CEa0tRhWoAAdol2.png",
        "id_str" : "596362690563579904",
        "id" : 596362690563579904,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEa0tRhWoAAdol2.png",
        "sizes" : [ {
          "h" : 398,
          "resize" : "fit",
          "w" : 835
        }, {
          "h" : 398,
          "resize" : "fit",
          "w" : 835
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 286,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 162,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/AuzRhnRdtz"
      } ],
      "hashtags" : [ {
        "text" : "IranTalks",
        "indices" : [ 53, 63 ]
      }, {
        "text" : "QER",
        "indices" : [ 79, 83 ]
      } ],
      "urls" : [ {
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/BErCBZa8ez",
        "expanded_url" : "http:\/\/on.cc.com\/1KOOQnM",
        "display_url" : "on.cc.com\/1KOOQnM"
      } ]
    },
    "geo" : { },
    "id_str" : "596362690802626561",
    "text" : "Watch video of my @TheDailyShow interview, including #IranTalks, vehicles, the #QER &amp; more. http:\/\/t.co\/BErCBZa8ez http:\/\/t.co\/AuzRhnRdtz",
    "id" : 596362690802626561,
    "created_at" : "2015-05-07 17:15:20 +0000",
    "user" : {
      "name" : "Ernest Moniz",
      "screen_name" : "ErnestMoniz",
      "protected" : false,
      "id_str" : "1393155566",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793425933113954305\/f5Mxv7BK_normal.jpg",
      "id" : 1393155566,
      "verified" : true
    }
  },
  "id" : 596368310205227008,
  "created_at" : "2015-05-07 17:37:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/596359707926790145\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/9k74tXHWrn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEax1G3W0AAQ6Ke.jpg",
      "id_str" : "596359526607147008",
      "id" : 596359526607147008,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEax1G3W0AAQ6Ke.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/9k74tXHWrn"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/Y6fFU0aVfN",
      "expanded_url" : "http:\/\/go.wh.gov\/RWKLEH",
      "display_url" : "go.wh.gov\/RWKLEH"
    } ]
  },
  "geo" : { },
  "id_str" : "596359707926790145",
  "text" : "RT if you agree: Every student deserves access to a quality, affordable higher education. http:\/\/t.co\/Y6fFU0aVfN http:\/\/t.co\/9k74tXHWrn",
  "id" : 596359707926790145,
  "created_at" : "2015-05-07 17:03:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/596351086509694977\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/E5LPvlA8Kq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEapzMhW0AAvltv.jpg",
      "id_str" : "596350697672724480",
      "id" : 596350697672724480,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEapzMhW0AAvltv.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      } ],
      "display_url" : "pic.twitter.com\/E5LPvlA8Kq"
    } ],
    "hashtags" : [ {
      "text" : "50States50Photos",
      "indices" : [ 92, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/6EVM3U9e4i",
      "expanded_url" : "http:\/\/go.wh.gov\/50States",
      "display_url" : "go.wh.gov\/50States"
    } ]
  },
  "geo" : { },
  "id_str" : "596351086509694977",
  "text" : "\"We are still more than a collection of red states and blue states.\"\nhttp:\/\/t.co\/6EVM3U9e4i #50States50Photos http:\/\/t.co\/E5LPvlA8Kq",
  "id" : 596351086509694977,
  "created_at" : "2015-05-07 16:29:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/596338147409047554\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/GKC7ptsMi5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEaeBSpW8AAeeWf.jpg",
      "id_str" : "596337745695535104",
      "id" : 596337745695535104,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEaeBSpW8AAeeWf.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      } ],
      "display_url" : "pic.twitter.com\/GKC7ptsMi5"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/6EVM3U9e4i",
      "expanded_url" : "http:\/\/go.wh.gov\/50States",
      "display_url" : "go.wh.gov\/50States"
    } ]
  },
  "geo" : { },
  "id_str" : "596338147409047554",
  "text" : "Go behind the lens for photos of President Obama in 49 states (tomorrow, it will be 50) \u2192 http:\/\/t.co\/6EVM3U9e4i http:\/\/t.co\/GKC7ptsMi5",
  "id" : 596338147409047554,
  "created_at" : "2015-05-07 15:37:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sen. Tammy Baldwin",
      "screen_name" : "SenatorBaldwin",
      "indices" : [ 3, 18 ],
      "id_str" : "1074518754",
      "id" : 1074518754
    }, {
      "name" : "Smith College Tweets",
      "screen_name" : "smithcollege",
      "indices" : [ 88, 101 ],
      "id_str" : "17025399",
      "id" : 17025399
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SenatorBaldwin\/status\/596314235501686784\/photo\/1",
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/3122XduDDA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEaIfXbXIAA9Bvm.jpg",
      "id_str" : "596314073119268864",
      "id" : 596314073119268864,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEaIfXbXIAA9Bvm.jpg",
      "sizes" : [ {
        "h" : 840,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 840,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 840,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 476,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/3122XduDDA"
    } ],
    "hashtags" : [ {
      "text" : "CollegeIn5Words",
      "indices" : [ 20, 36 ]
    }, {
      "text" : "ReachHigher",
      "indices" : [ 70, 82 ]
    }, {
      "text" : "TBT",
      "indices" : [ 83, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596326932079226881",
  "text" : "RT @SenatorBaldwin: #CollegeIn5Words\n\nInvest\nin\nopportunity\nfor\nall.\n\n#ReachHigher #TBT @smithcollege http:\/\/t.co\/3122XduDDA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Smith College Tweets",
        "screen_name" : "smithcollege",
        "indices" : [ 68, 81 ],
        "id_str" : "17025399",
        "id" : 17025399
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SenatorBaldwin\/status\/596314235501686784\/photo\/1",
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/3122XduDDA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CEaIfXbXIAA9Bvm.jpg",
        "id_str" : "596314073119268864",
        "id" : 596314073119268864,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEaIfXbXIAA9Bvm.jpg",
        "sizes" : [ {
          "h" : 840,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 840,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 840,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 476,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/3122XduDDA"
      } ],
      "hashtags" : [ {
        "text" : "CollegeIn5Words",
        "indices" : [ 0, 16 ]
      }, {
        "text" : "ReachHigher",
        "indices" : [ 50, 62 ]
      }, {
        "text" : "TBT",
        "indices" : [ 63, 67 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "596314235501686784",
    "text" : "#CollegeIn5Words\n\nInvest\nin\nopportunity\nfor\nall.\n\n#ReachHigher #TBT @smithcollege http:\/\/t.co\/3122XduDDA",
    "id" : 596314235501686784,
    "created_at" : "2015-05-07 14:02:47 +0000",
    "user" : {
      "name" : "Sen. Tammy Baldwin",
      "screen_name" : "SenatorBaldwin",
      "protected" : false,
      "id_str" : "1074518754",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656152457756692481\/jq9YvUuw_normal.jpg",
      "id" : 1074518754,
      "verified" : true
    }
  },
  "id" : 596326932079226881,
  "created_at" : "2015-05-07 14:53:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Maley",
      "screen_name" : "Maley44",
      "indices" : [ 3, 11 ],
      "id_str" : "1881128166",
      "id" : 1881128166
    }, {
      "name" : "argusleader",
      "screen_name" : "argusleader",
      "indices" : [ 75, 87 ],
      "id_str" : "15436545",
      "id" : 15436545
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Maley44\/status\/596318802612199424\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/zvJDZKjq9X",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEaMyoJWYAEPvIW.jpg",
      "id_str" : "596318802071150593",
      "id" : 596318802071150593,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEaMyoJWYAEPvIW.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/zvJDZKjq9X"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/3k973CmXLL",
      "expanded_url" : "http:\/\/goo.gl\/cGFlMK",
      "display_url" : "goo.gl\/cGFlMK"
    } ]
  },
  "geo" : { },
  "id_str" : "596324125137772544",
  "text" : "RT @Maley44: South Dakota has epic T-shirt game - great photo gallery from @argusleader http:\/\/t.co\/3k973CmXLL http:\/\/t.co\/zvJDZKjq9X",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "argusleader",
        "screen_name" : "argusleader",
        "indices" : [ 62, 74 ],
        "id_str" : "15436545",
        "id" : 15436545
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Maley44\/status\/596318802612199424\/photo\/1",
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/zvJDZKjq9X",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CEaMyoJWYAEPvIW.jpg",
        "id_str" : "596318802071150593",
        "id" : 596318802071150593,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEaMyoJWYAEPvIW.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 510,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/zvJDZKjq9X"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/3k973CmXLL",
        "expanded_url" : "http:\/\/goo.gl\/cGFlMK",
        "display_url" : "goo.gl\/cGFlMK"
      } ]
    },
    "geo" : { },
    "id_str" : "596318802612199424",
    "text" : "South Dakota has epic T-shirt game - great photo gallery from @argusleader http:\/\/t.co\/3k973CmXLL http:\/\/t.co\/zvJDZKjq9X",
    "id" : 596318802612199424,
    "created_at" : "2015-05-07 14:20:56 +0000",
    "user" : {
      "name" : "Keith Maley",
      "screen_name" : "Maley44",
      "protected" : false,
      "id_str" : "1881128166",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725086933961957376\/v5WvYCOW_normal.jpg",
      "id" : 1881128166,
      "verified" : true
    }
  },
  "id" : 596324125137772544,
  "created_at" : "2015-05-07 14:42:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 3, 11 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    }, {
      "name" : "Rachael Ray Show",
      "screen_name" : "RachaelRayShow",
      "indices" : [ 112, 127 ],
      "id_str" : "56736161",
      "id" : 56736161
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TeacherAppreciationWeek",
      "indices" : [ 19, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596308464068005888",
  "text" : "RT @DrBiden: Happy #TeacherAppreciationWeek! Watch Dr. Biden &amp; the 2015 National Teacher of the Year on the @RachaelRayShow today. http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Rachael Ray Show",
        "screen_name" : "RachaelRayShow",
        "indices" : [ 99, 114 ],
        "id_str" : "56736161",
        "id" : 56736161
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DrBiden\/status\/596293383573925888\/photo\/1",
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/r3Xoh7JqI4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CEZ1qznW8AMfvmF.jpg",
        "id_str" : "596293378943414275",
        "id" : 596293378943414275,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEZ1qznW8AMfvmF.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/r3Xoh7JqI4"
      } ],
      "hashtags" : [ {
        "text" : "TeacherAppreciationWeek",
        "indices" : [ 6, 30 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "596293383573925888",
    "text" : "Happy #TeacherAppreciationWeek! Watch Dr. Biden &amp; the 2015 National Teacher of the Year on the @RachaelRayShow today. http:\/\/t.co\/r3Xoh7JqI4",
    "id" : 596293383573925888,
    "created_at" : "2015-05-07 12:39:55 +0000",
    "user" : {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "protected" : false,
      "id_str" : "1281405877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608687663034474496\/wvzVG_yt_normal.jpg",
      "id" : 1281405877,
      "verified" : true
    }
  },
  "id" : 596308464068005888,
  "created_at" : "2015-05-07 13:39:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EJ Dionne",
      "screen_name" : "EJDionne",
      "indices" : [ 3, 12 ],
      "id_str" : "453319164",
      "id" : 453319164
    }, {
      "name" : "Georgetown Univ.",
      "screen_name" : "Georgetown",
      "indices" : [ 83, 94 ],
      "id_str" : "7856542",
      "id" : 7856542
    }, {
      "name" : "Robert D. Putnam",
      "screen_name" : "RobertDPutnam",
      "indices" : [ 111, 125 ],
      "id_str" : "1726670335",
      "id" : 1726670335
    }, {
      "name" : "Arthur Brooks",
      "screen_name" : "arthurbrooks",
      "indices" : [ 132, 145 ],
      "id_str" : "28178127",
      "id" : 28178127
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596307237783474176",
  "text" : "RT @EJDionne: Excited to be discussing opportunity &amp; combating poverty 5\/12 at @Georgetown w\/ Pres. Obama, @RobertDPutnam &amp; @arthurbrooks #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Georgetown Univ.",
        "screen_name" : "Georgetown",
        "indices" : [ 69, 80 ],
        "id_str" : "7856542",
        "id" : 7856542
      }, {
        "name" : "Robert D. Putnam",
        "screen_name" : "RobertDPutnam",
        "indices" : [ 97, 111 ],
        "id_str" : "1726670335",
        "id" : 1726670335
      }, {
        "name" : "Arthur Brooks",
        "screen_name" : "arthurbrooks",
        "indices" : [ 118, 131 ],
        "id_str" : "28178127",
        "id" : 28178127
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PovertySummit",
        "indices" : [ 132, 146 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "596298473152114689",
    "text" : "Excited to be discussing opportunity &amp; combating poverty 5\/12 at @Georgetown w\/ Pres. Obama, @RobertDPutnam &amp; @arthurbrooks #PovertySummit",
    "id" : 596298473152114689,
    "created_at" : "2015-05-07 13:00:09 +0000",
    "user" : {
      "name" : "EJ Dionne",
      "screen_name" : "EJDionne",
      "protected" : false,
      "id_str" : "453319164",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/676849075652861952\/X-f5kcFx_normal.jpg",
      "id" : 453319164,
      "verified" : true
    }
  },
  "id" : 596307237783474176,
  "created_at" : "2015-05-07 13:34:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernest Moniz",
      "screen_name" : "ErnestMoniz",
      "indices" : [ 3, 15 ],
      "id_str" : "1393155566",
      "id" : 1393155566
    }, {
      "name" : "The Daily Show",
      "screen_name" : "TheDailyShow",
      "indices" : [ 32, 45 ],
      "id_str" : "158414847",
      "id" : 158414847
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "energy",
      "indices" : [ 75, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/RzmiRSxzGn",
      "expanded_url" : "http:\/\/thedailyshow.cc.com\/guests\/ernest-moniz",
      "display_url" : "thedailyshow.cc.com\/guests\/ernest-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "596081784204304385",
  "text" : "RT @ErnestMoniz: I'm a guest on @TheDailyShow tonight. Tune in for laughs, #energy insights, maybe even hair tips. http:\/\/t.co\/RzmiRSxzGn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Daily Show",
        "screen_name" : "TheDailyShow",
        "indices" : [ 15, 28 ],
        "id_str" : "158414847",
        "id" : 158414847
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "energy",
        "indices" : [ 58, 65 ]
      } ],
      "urls" : [ {
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/RzmiRSxzGn",
        "expanded_url" : "http:\/\/thedailyshow.cc.com\/guests\/ernest-moniz",
        "display_url" : "thedailyshow.cc.com\/guests\/ernest-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "595996524225667074",
    "text" : "I'm a guest on @TheDailyShow tonight. Tune in for laughs, #energy insights, maybe even hair tips. http:\/\/t.co\/RzmiRSxzGn",
    "id" : 595996524225667074,
    "created_at" : "2015-05-06 17:00:19 +0000",
    "user" : {
      "name" : "Ernest Moniz",
      "screen_name" : "ErnestMoniz",
      "protected" : false,
      "id_str" : "1393155566",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793425933113954305\/f5Mxv7BK_normal.jpg",
      "id" : 1393155566,
      "verified" : true
    }
  },
  "id" : 596081784204304385,
  "created_at" : "2015-05-06 22:39:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/596076172888313856\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/dlm6P625vA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEWv-9PW0AAo6Bv.jpg",
      "id_str" : "596076021822181376",
      "id" : 596076021822181376,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEWv-9PW0AAo6Bv.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/dlm6P625vA"
    } ],
    "hashtags" : [ {
      "text" : "CommunityCollege",
      "indices" : [ 10, 27 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 105 ],
      "url" : "https:\/\/t.co\/Q4X146Atr6",
      "expanded_url" : "https:\/\/medium.com\/@WhiteHouse\/how-i-became-chief-data-scientist-93ff698a7188",
      "display_url" : "medium.com\/@WhiteHouse\/ho\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "596076172888313856",
  "text" : "Where can #CommunityCollege take you?\nChief Data Scientist of the United States \u2192 https:\/\/t.co\/Q4X146Atr6 http:\/\/t.co\/dlm6P625vA",
  "id" : 596076172888313856,
  "created_at" : "2015-05-06 22:16:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/596050010808061952\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/08zENxf6Ff",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEWYQ4TXIAEWQKw.jpg",
      "id_str" : "596049941455380481",
      "id" : 596049941455380481,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEWYQ4TXIAEWQKw.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/08zENxf6Ff"
    } ],
    "hashtags" : [ {
      "text" : "CommunityCollege",
      "indices" : [ 30, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596050010808061952",
  "text" : "RT if you agree: Two years of #CommunityCollege should be as free and universal as high school is today. http:\/\/t.co\/08zENxf6Ff",
  "id" : 596050010808061952,
  "created_at" : "2015-05-06 20:32:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 99, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/CxF0iN1lKj",
      "expanded_url" : "https:\/\/www.whitehouse.gov\/blog\/2015\/05\/06\/connecting-america-s-communities-actionable-climate-science",
      "display_url" : "whitehouse.gov\/blog\/2015\/05\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "596041662775709696",
  "text" : "RT @whitehouseostp: Dr. Holdren is in Lincoln, NE, today, learning how locals are using science to #ActOnClimate https:\/\/t.co\/CxF0iN1lKj ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/whitehouseostp\/status\/596041282142674944\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/A73V5Vz5Q3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CEWQYllVEAAaHdw.jpg",
        "id_str" : "596041277776400384",
        "id" : 596041277776400384,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEWQYllVEAAaHdw.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 427,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 427,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/A73V5Vz5Q3"
      } ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 79, 92 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/CxF0iN1lKj",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/blog\/2015\/05\/06\/connecting-america-s-communities-actionable-climate-science",
        "display_url" : "whitehouse.gov\/blog\/2015\/05\/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "596041282142674944",
    "text" : "Dr. Holdren is in Lincoln, NE, today, learning how locals are using science to #ActOnClimate https:\/\/t.co\/CxF0iN1lKj http:\/\/t.co\/A73V5Vz5Q3",
    "id" : 596041282142674944,
    "created_at" : "2015-05-06 19:58:10 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 596041662775709696,
  "created_at" : "2015-05-06 19:59:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ed Markey",
      "screen_name" : "SenMarkey",
      "indices" : [ 3, 13 ],
      "id_str" : "21406834",
      "id" : 21406834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596030753596551168",
  "text" : "RT @SenMarkey: CO2 911: Global CO2 concentrations pass 400PPM for 1st month since measurements began. No denial, no time to waste. #ActOnCl\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 116, 129 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "595961169942286336",
    "text" : "CO2 911: Global CO2 concentrations pass 400PPM for 1st month since measurements began. No denial, no time to waste. #ActOnClimate",
    "id" : 595961169942286336,
    "created_at" : "2015-05-06 14:39:49 +0000",
    "user" : {
      "name" : "Ed Markey",
      "screen_name" : "SenMarkey",
      "protected" : false,
      "id_str" : "21406834",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/739889609262411780\/qDeJ7rdE_normal.jpg",
      "id" : 21406834,
      "verified" : true
    }
  },
  "id" : 596030753596551168,
  "created_at" : "2015-05-06 19:16:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "CVS Health",
      "screen_name" : "CVSHealth",
      "indices" : [ 23, 33 ],
      "id_str" : "122473388",
      "id" : 122473388
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OneBaltimore",
      "indices" : [ 115, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596024398684913664",
  "text" : "RT @vj44: Great to see @CVSHealth announce it will rebuild the Baltimore locations. That\u2019s the community spirit of #OneBaltimore.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CVS Health",
        "screen_name" : "CVSHealth",
        "indices" : [ 13, 23 ],
        "id_str" : "122473388",
        "id" : 122473388
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OneBaltimore",
        "indices" : [ 105, 118 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "596022294046056448",
    "text" : "Great to see @CVSHealth announce it will rebuild the Baltimore locations. That\u2019s the community spirit of #OneBaltimore.",
    "id" : 596022294046056448,
    "created_at" : "2015-05-06 18:42:43 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 596024398684913664,
  "created_at" : "2015-05-06 18:51:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/596013861226024960\/photo\/1",
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/f18Is5Ogho",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEV3EUbUEAAQaRI.jpg",
      "id_str" : "596013441782910976",
      "id" : 596013441782910976,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEV3EUbUEAAQaRI.jpg",
      "sizes" : [ {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/f18Is5Ogho"
    } ],
    "hashtags" : [ {
      "text" : "ReachHigher",
      "indices" : [ 64, 76 ]
    }, {
      "text" : "CollegeIn5Words",
      "indices" : [ 77, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/UwMLFndCtY",
      "expanded_url" : "http:\/\/go.wh.gov\/RWKLEH",
      "display_url" : "go.wh.gov\/RWKLEH"
    } ]
  },
  "geo" : { },
  "id_str" : "596017590587142144",
  "text" : "RT @FLOTUS: Key to building your dreams: http:\/\/t.co\/UwMLFndCtY #ReachHigher #CollegeIn5Words http:\/\/t.co\/f18Is5Ogho",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/596013861226024960\/photo\/1",
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/f18Is5Ogho",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CEV3EUbUEAAQaRI.jpg",
        "id_str" : "596013441782910976",
        "id" : 596013441782910976,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEV3EUbUEAAQaRI.jpg",
        "sizes" : [ {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/f18Is5Ogho"
      } ],
      "hashtags" : [ {
        "text" : "ReachHigher",
        "indices" : [ 52, 64 ]
      }, {
        "text" : "CollegeIn5Words",
        "indices" : [ 65, 81 ]
      } ],
      "urls" : [ {
        "indices" : [ 29, 51 ],
        "url" : "http:\/\/t.co\/UwMLFndCtY",
        "expanded_url" : "http:\/\/go.wh.gov\/RWKLEH",
        "display_url" : "go.wh.gov\/RWKLEH"
      } ]
    },
    "geo" : { },
    "id_str" : "596013861226024960",
    "text" : "Key to building your dreams: http:\/\/t.co\/UwMLFndCtY #ReachHigher #CollegeIn5Words http:\/\/t.co\/f18Is5Ogho",
    "id" : 596013861226024960,
    "created_at" : "2015-05-06 18:09:12 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 596017590587142144,
  "created_at" : "2015-05-06 18:24:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/VP\/status\/596009135226753024\/photo\/1",
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/HBUDTpacoJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEVzJiaW8AElbds.jpg",
      "id_str" : "596009133389836289",
      "id" : 596009133389836289,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEVzJiaW8AElbds.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/HBUDTpacoJ"
    } ],
    "hashtags" : [ {
      "text" : "collegein5words",
      "indices" : [ 49, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/EQrXb7ILnZ",
      "expanded_url" : "https:\/\/www.whitehouse.gov\/issues\/education\/road-to-higher-ed",
      "display_url" : "whitehouse.gov\/issues\/educati\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "596009808911675392",
  "text" : "RT @VP: Higher. Education. For. Every. American. #collegein5words https:\/\/t.co\/EQrXb7ILnZ http:\/\/t.co\/HBUDTpacoJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/596009135226753024\/photo\/1",
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/HBUDTpacoJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CEVzJiaW8AElbds.jpg",
        "id_str" : "596009133389836289",
        "id" : 596009133389836289,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEVzJiaW8AElbds.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1333,
          "resize" : "fit",
          "w" : 2000
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/HBUDTpacoJ"
      } ],
      "hashtags" : [ {
        "text" : "collegein5words",
        "indices" : [ 41, 57 ]
      } ],
      "urls" : [ {
        "indices" : [ 58, 81 ],
        "url" : "https:\/\/t.co\/EQrXb7ILnZ",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/issues\/education\/road-to-higher-ed",
        "display_url" : "whitehouse.gov\/issues\/educati\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "596009135226753024",
    "text" : "Higher. Education. For. Every. American. #collegein5words https:\/\/t.co\/EQrXb7ILnZ http:\/\/t.co\/HBUDTpacoJ",
    "id" : 596009135226753024,
    "created_at" : "2015-05-06 17:50:25 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 596009808911675392,
  "created_at" : "2015-05-06 17:53:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/596004151819051011\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/l08uU4NhWN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEVtf9NWAAAVe3C.jpg",
      "id_str" : "596002921470361600",
      "id" : 596002921470361600,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEVtf9NWAAAVe3C.jpg",
      "sizes" : [ {
        "h" : 354,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 354,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 354,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 241,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/l08uU4NhWN"
    } ],
    "hashtags" : [ {
      "text" : "VEDay70",
      "indices" : [ 108, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "596004151819051011",
  "text" : "Let's honor the heroes who fought to protect our freedom.\nShare the story of a WWII vet in your family with #VEDay70. http:\/\/t.co\/l08uU4NhWN",
  "id" : 596004151819051011,
  "created_at" : "2015-05-06 17:30:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gail O. Mellow",
      "screen_name" : "GailOMellow",
      "indices" : [ 3, 15 ],
      "id_str" : "2279491158",
      "id" : 2279491158
    }, {
      "name" : "LaGuardia CC",
      "screen_name" : "LaGuardiaCC",
      "indices" : [ 90, 102 ],
      "id_str" : "39598688",
      "id" : 39598688
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/GailOMellow\/status\/595985550013820929\/photo\/1",
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/zPLldUQXee",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEVdswUWAAAIh4n.jpg",
      "id_str" : "595985549162315776",
      "id" : 595985549162315776,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEVdswUWAAAIh4n.jpg",
      "sizes" : [ {
        "h" : 427,
        "resize" : "fit",
        "w" : 577
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 427,
        "resize" : "fit",
        "w" : 577
      }, {
        "h" : 252,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 427,
        "resize" : "fit",
        "w" : 577
      } ],
      "display_url" : "pic.twitter.com\/zPLldUQXee"
    } ],
    "hashtags" : [ {
      "text" : "collegein5words",
      "indices" : [ 55, 71 ]
    }, {
      "text" : "CommunityCollege",
      "indices" : [ 72, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "595998007797002241",
  "text" : "RT @GailOMellow: Community college: education for all. #collegein5words #CommunityCollege @LaGuardiaCC http:\/\/t.co\/zPLldUQXee",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "LaGuardia CC",
        "screen_name" : "LaGuardiaCC",
        "indices" : [ 73, 85 ],
        "id_str" : "39598688",
        "id" : 39598688
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/GailOMellow\/status\/595985550013820929\/photo\/1",
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/zPLldUQXee",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CEVdswUWAAAIh4n.jpg",
        "id_str" : "595985549162315776",
        "id" : 595985549162315776,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEVdswUWAAAIh4n.jpg",
        "sizes" : [ {
          "h" : 427,
          "resize" : "fit",
          "w" : 577
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 427,
          "resize" : "fit",
          "w" : 577
        }, {
          "h" : 252,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 427,
          "resize" : "fit",
          "w" : 577
        } ],
        "display_url" : "pic.twitter.com\/zPLldUQXee"
      } ],
      "hashtags" : [ {
        "text" : "collegein5words",
        "indices" : [ 38, 54 ]
      }, {
        "text" : "CommunityCollege",
        "indices" : [ 55, 72 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "595985550013820929",
    "text" : "Community college: education for all. #collegein5words #CommunityCollege @LaGuardiaCC http:\/\/t.co\/zPLldUQXee",
    "id" : 595985550013820929,
    "created_at" : "2015-05-06 16:16:42 +0000",
    "user" : {
      "name" : "Gail O. Mellow",
      "screen_name" : "GailOMellow",
      "protected" : false,
      "id_str" : "2279491158",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/425715711109906432\/1pnaQHm9_normal.jpeg",
      "id" : 2279491158,
      "verified" : false
    }
  },
  "id" : 595998007797002241,
  "created_at" : "2015-05-06 17:06:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reach Higher",
      "screen_name" : "ReachHigher",
      "indices" : [ 3, 15 ],
      "id_str" : "2461821548",
      "id" : 2461821548
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/ReachHigher\/status\/595969136913567744\/photo\/1",
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/Nisk9Ogd3B",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEVOl1JUkAAYGlV.jpg",
      "id_str" : "595968937524760576",
      "id" : 595968937524760576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEVOl1JUkAAYGlV.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      } ],
      "display_url" : "pic.twitter.com\/Nisk9Ogd3B"
    } ],
    "hashtags" : [ {
      "text" : "collegein5words",
      "indices" : [ 50, 66 ]
    }, {
      "text" : "ReachHigher",
      "indices" : [ 67, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "595983852646100992",
  "text" : "RT @ReachHigher: Helping students to reach higher #collegein5words #ReachHigher http:\/\/t.co\/Nisk9Ogd3B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/ReachHigher\/status\/595969136913567744\/photo\/1",
        "indices" : [ 63, 85 ],
        "url" : "http:\/\/t.co\/Nisk9Ogd3B",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CEVOl1JUkAAYGlV.jpg",
        "id_str" : "595968937524760576",
        "id" : 595968937524760576,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEVOl1JUkAAYGlV.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 436,
          "resize" : "fit",
          "w" : 654
        }, {
          "h" : 436,
          "resize" : "fit",
          "w" : 654
        } ],
        "display_url" : "pic.twitter.com\/Nisk9Ogd3B"
      } ],
      "hashtags" : [ {
        "text" : "collegein5words",
        "indices" : [ 33, 49 ]
      }, {
        "text" : "ReachHigher",
        "indices" : [ 50, 62 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "595969136913567744",
    "text" : "Helping students to reach higher #collegein5words #ReachHigher http:\/\/t.co\/Nisk9Ogd3B",
    "id" : 595969136913567744,
    "created_at" : "2015-05-06 15:11:29 +0000",
    "user" : {
      "name" : "Reach Higher",
      "screen_name" : "ReachHigher",
      "protected" : false,
      "id_str" : "2461821548",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/508240407688663040\/El8GILjl_normal.jpeg",
      "id" : 2461821548,
      "verified" : true
    }
  },
  "id" : 595983852646100992,
  "created_at" : "2015-05-06 16:09:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "indices" : [ 3, 15 ],
      "id_str" : "369232105",
      "id" : 369232105
    }, {
      "name" : "CPCC",
      "screen_name" : "cpcc",
      "indices" : [ 22, 27 ],
      "id_str" : "43887304",
      "id" : 43887304
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 35, 46 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CommunityCollege",
      "indices" : [ 102, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "595978190377607168",
  "text" : "RT @PAniskoff44: From @cpcc to the @WhiteHouse; Crystal on our communications team knows the value of #CommunityCollege http:\/\/t.co\/Nr29zBm\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CPCC",
        "screen_name" : "cpcc",
        "indices" : [ 5, 10 ],
        "id_str" : "43887304",
        "id" : 43887304
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 18, 29 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PAniskoff44\/status\/595977419774767104\/photo\/1",
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/Nr29zBmrpq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CEVWTXrUIAEMH0u.png",
        "id_str" : "595977416469651457",
        "id" : 595977416469651457,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEVWTXrUIAEMH0u.png",
        "sizes" : [ {
          "h" : 629,
          "resize" : "fit",
          "w" : 822
        }, {
          "h" : 260,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 629,
          "resize" : "fit",
          "w" : 822
        }, {
          "h" : 459,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/Nr29zBmrpq"
      } ],
      "hashtags" : [ {
        "text" : "CommunityCollege",
        "indices" : [ 85, 102 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "595977419774767104",
    "text" : "From @cpcc to the @WhiteHouse; Crystal on our communications team knows the value of #CommunityCollege http:\/\/t.co\/Nr29zBmrpq",
    "id" : 595977419774767104,
    "created_at" : "2015-05-06 15:44:24 +0000",
    "user" : {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "protected" : false,
      "id_str" : "369232105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623146355767140352\/58sqoVrw_normal.jpg",
      "id" : 369232105,
      "verified" : true
    }
  },
  "id" : 595978190377607168,
  "created_at" : "2015-05-06 15:47:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/595967345207586818\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/hwZA01L0tJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEVNHClVIAAFdZX.jpg",
      "id_str" : "595967309044326400",
      "id" : 595967309044326400,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEVNHClVIAAFdZX.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/hwZA01L0tJ"
    } ],
    "hashtags" : [ {
      "text" : "CommunityCollege",
      "indices" : [ 28, 45 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/Y6fFU0aVfN",
      "expanded_url" : "http:\/\/go.wh.gov\/RWKLEH",
      "display_url" : "go.wh.gov\/RWKLEH"
    } ]
  },
  "geo" : { },
  "id_str" : "595967345207586818",
  "text" : "How would two years of free #CommunityCollege help you (or someone you know) succeed? http:\/\/t.co\/Y6fFU0aVfN http:\/\/t.co\/hwZA01L0tJ",
  "id" : 595967345207586818,
  "created_at" : "2015-05-06 15:04:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/595961695949852673\/photo\/1",
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/BqZLYScXn9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEVH97yUUAA-4-c.jpg",
      "id_str" : "595961655042789376",
      "id" : 595961655042789376,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEVH97yUUAA-4-c.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/BqZLYScXn9"
    } ],
    "hashtags" : [ {
      "text" : "CollegeIn5Words",
      "indices" : [ 57, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/WZu4wrj1Ja",
      "expanded_url" : "http:\/\/go.wh.gov\/CommunityCollege",
      "display_url" : "go.wh.gov\/CommunityColle\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "595961695949852673",
  "text" : "Community college should be free: http:\/\/t.co\/WZu4wrj1Ja #CollegeIn5Words http:\/\/t.co\/BqZLYScXn9",
  "id" : 595961695949852673,
  "created_at" : "2015-05-06 14:41:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rep. Nydia Velazquez",
      "screen_name" : "NydiaVelazquez",
      "indices" : [ 3, 18 ],
      "id_str" : "164369297",
      "id" : 164369297
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "595957091854000128",
  "text" : "RT @NydiaVelazquez: This National Small Business Week we salute American entrepreneurs who create 3 out of 4 new jobs. Let's help them succ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DreamSmallBiz",
        "indices" : [ 124, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "595931781397880832",
    "text" : "This National Small Business Week we salute American entrepreneurs who create 3 out of 4 new jobs. Let's help them succeed. #DreamSmallBiz",
    "id" : 595931781397880832,
    "created_at" : "2015-05-06 12:43:03 +0000",
    "user" : {
      "name" : "Rep. Nydia Velazquez",
      "screen_name" : "NydiaVelazquez",
      "protected" : false,
      "id_str" : "164369297",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/649938376506765312\/qvRvMm4p_normal.jpg",
      "id" : 164369297,
      "verified" : true
    }
  },
  "id" : 595957091854000128,
  "created_at" : "2015-05-06 14:23:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/595706413491605504\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/n6eDTTwbYr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CERfjHJWIAAX2xs.jpg",
      "id_str" : "595706107538055168",
      "id" : 595706107538055168,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CERfjHJWIAAX2xs.jpg",
      "sizes" : [ {
        "h" : 568,
        "resize" : "fit",
        "w" : 853
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 568,
        "resize" : "fit",
        "w" : 853
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/n6eDTTwbYr"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "595706413491605504",
  "text" : "\"America is a story of progress...often written by people who come here with a vision of what's possible.\" \u2014Obama http:\/\/t.co\/n6eDTTwbYr",
  "id" : 595706413491605504,
  "created_at" : "2015-05-05 21:47:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CincoDeMayo",
      "indices" : [ 115, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "595706021332516865",
  "text" : "RT @WHLive: \"Congress still needs to step up and ultimately pass commonsense immigration reform.\" \u2014President Obama #CincoDeMayo #Immigratio\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CincoDeMayo",
        "indices" : [ 103, 115 ]
      }, {
        "text" : "ImmigrationAction",
        "indices" : [ 116, 134 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "595705996892332032",
    "text" : "\"Congress still needs to step up and ultimately pass commonsense immigration reform.\" \u2014President Obama #CincoDeMayo #ImmigrationAction",
    "id" : 595705996892332032,
    "created_at" : "2015-05-05 21:45:51 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 595706021332516865,
  "created_at" : "2015-05-05 21:45:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CincoDeMayo",
      "indices" : [ 96, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "595705508931178496",
  "text" : "\"It\u2019s one of the great David vs. Goliath stories in history.\" \u2014President Obama on the origin of #CincoDeMayo",
  "id" : 595705508931178496,
  "created_at" : "2015-05-05 21:43:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CincoDeMayo",
      "indices" : [ 7, 19 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/WexLiQuTVd",
      "expanded_url" : "http:\/\/go.wh.gov\/fJXbvq",
      "display_url" : "go.wh.gov\/fJXbvq"
    } ]
  },
  "geo" : { },
  "id_str" : "595705195864162304",
  "text" : "\"Happy #CincoDeMayo!\" \u2014President Obama hosting a reception at the White House: http:\/\/t.co\/WexLiQuTVd",
  "id" : 595705195864162304,
  "created_at" : "2015-05-05 21:42:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CincoDeMayo",
      "indices" : [ 36, 48 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/WexLiQuTVd",
      "expanded_url" : "http:\/\/go.wh.gov\/fJXbvq",
      "display_url" : "go.wh.gov\/fJXbvq"
    } ]
  },
  "geo" : { },
  "id_str" : "595705092092878848",
  "text" : "Watch live: President Obama hosts a #CincoDeMayo reception \u2192 http:\/\/t.co\/WexLiQuTVd",
  "id" : 595705092092878848,
  "created_at" : "2015-05-05 21:42:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/yKJBxPn7ex",
      "expanded_url" : "http:\/\/snpy.tv\/1EaIeuo",
      "display_url" : "snpy.tv\/1EaIeuo"
    } ]
  },
  "geo" : { },
  "id_str" : "595686949953736704",
  "text" : "\"We care about your future\u2014not just sometimes, but all the time.\" \u2014President Obama to young boys and men of color http:\/\/t.co\/yKJBxPn7ex",
  "id" : 595686949953736704,
  "created_at" : "2015-05-05 20:30:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melinda Gates",
      "screen_name" : "melindagates",
      "indices" : [ 3, 16 ],
      "id_str" : "161801527",
      "id" : 161801527
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThankATeacher",
      "indices" : [ 113, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "595677161203306497",
  "text" : "RT @melindagates: Thankful for the great teachers in my life like Ms. Bauer, who exposed me to computer science. #ThankATeacher http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/melindagates\/status\/595673229248827393\/photo\/1",
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/1rbnxXfMPw",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CERBpR1WoAAw8ku.jpg",
        "id_str" : "595673228137373696",
        "id" : 595673228137373696,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CERBpR1WoAAw8ku.jpg",
        "sizes" : [ {
          "h" : 1452,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 482,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 851,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1676,
          "resize" : "fit",
          "w" : 1182
        } ],
        "display_url" : "pic.twitter.com\/1rbnxXfMPw"
      } ],
      "hashtags" : [ {
        "text" : "ThankATeacher",
        "indices" : [ 95, 109 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "595673229248827393",
    "text" : "Thankful for the great teachers in my life like Ms. Bauer, who exposed me to computer science. #ThankATeacher http:\/\/t.co\/1rbnxXfMPw",
    "id" : 595673229248827393,
    "created_at" : "2015-05-05 19:35:39 +0000",
    "user" : {
      "name" : "Melinda Gates",
      "screen_name" : "melindagates",
      "protected" : false,
      "id_str" : "161801527",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/576426383989080065\/HoFESJ2k_normal.jpeg",
      "id" : 161801527,
      "verified" : true
    }
  },
  "id" : 595677161203306497,
  "created_at" : "2015-05-05 19:51:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Education",
      "screen_name" : "usedgov",
      "indices" : [ 3, 11 ],
      "id_str" : "20437286",
      "id" : 20437286
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/usedgov\/status\/595666775863353344\/photo\/1",
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/lwMg5fwuQJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEQ7xs4W0AA8yW5.jpg",
      "id_str" : "595666775766913024",
      "id" : 595666775766913024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEQ7xs4W0AA8yW5.jpg",
      "sizes" : [ {
        "h" : 440,
        "resize" : "fit",
        "w" : 880
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 440,
        "resize" : "fit",
        "w" : 880
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/lwMg5fwuQJ"
    } ],
    "hashtags" : [ {
      "text" : "ReachHigher",
      "indices" : [ 58, 70 ]
    }, {
      "text" : "ThankATeacher",
      "indices" : [ 72, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "595670588552773634",
  "text" : "RT @usedgov: Thank you teachers for inspiring students to #ReachHigher! #ThankATeacher http:\/\/t.co\/lwMg5fwuQJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/usedgov\/status\/595666775863353344\/photo\/1",
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/lwMg5fwuQJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CEQ7xs4W0AA8yW5.jpg",
        "id_str" : "595666775766913024",
        "id" : 595666775766913024,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEQ7xs4W0AA8yW5.jpg",
        "sizes" : [ {
          "h" : 440,
          "resize" : "fit",
          "w" : 880
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 440,
          "resize" : "fit",
          "w" : 880
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/lwMg5fwuQJ"
      } ],
      "hashtags" : [ {
        "text" : "ReachHigher",
        "indices" : [ 45, 57 ]
      }, {
        "text" : "ThankATeacher",
        "indices" : [ 59, 73 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "595666775863353344",
    "text" : "Thank you teachers for inspiring students to #ReachHigher! #ThankATeacher http:\/\/t.co\/lwMg5fwuQJ",
    "id" : 595666775863353344,
    "created_at" : "2015-05-05 19:10:00 +0000",
    "user" : {
      "name" : "US Dept of Education",
      "screen_name" : "usedgov",
      "protected" : false,
      "id_str" : "20437286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749204008108261377\/93-TTeZl_normal.jpg",
      "id" : 20437286,
      "verified" : true
    }
  },
  "id" : 595670588552773634,
  "created_at" : "2015-05-05 19:25:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/NkzYR1vL8Z",
      "expanded_url" : "http:\/\/snpy.tv\/1GVmjM7",
      "display_url" : "snpy.tv\/1GVmjM7"
    } ]
  },
  "geo" : { },
  "id_str" : "595660383735705600",
  "text" : "\"America's future depends on us caring about this.\" \u2014Obama on helping young people from every community succeed http:\/\/t.co\/NkzYR1vL8Z",
  "id" : 595660383735705600,
  "created_at" : "2015-05-05 18:44:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/F4XKEBasVi",
      "expanded_url" : "http:\/\/snpy.tv\/1EdHBQR",
      "display_url" : "snpy.tv\/1EdHBQR"
    } ]
  },
  "geo" : { },
  "id_str" : "595633173880557569",
  "text" : "Watch President Obama announce his nominees to be the next Chariman and Vice Chairman of the Joint Chiefs of Staff. http:\/\/t.co\/F4XKEBasVi",
  "id" : 595633173880557569,
  "created_at" : "2015-05-05 16:56:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christy Goldfuss",
      "screen_name" : "Goldfuss44",
      "indices" : [ 3, 14 ],
      "id_str" : "2377561969",
      "id" : 2377561969
    }, {
      "name" : "The Hill",
      "screen_name" : "thehill",
      "indices" : [ 120, 128 ],
      "id_str" : "1917731",
      "id" : 1917731
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 23, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "595618583243264000",
  "text" : "RT @Goldfuss44: Smart, #ActOnClimate planning and design can make infrastructure more resilient, better for communities @thehill: http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Hill",
        "screen_name" : "thehill",
        "indices" : [ 104, 112 ],
        "id_str" : "1917731",
        "id" : 1917731
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 7, 20 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/kB7UZzC6kn",
        "expanded_url" : "http:\/\/bit.ly\/1Qi9MGV",
        "display_url" : "bit.ly\/1Qi9MGV"
      } ]
    },
    "geo" : { },
    "id_str" : "595570452526948352",
    "text" : "Smart, #ActOnClimate planning and design can make infrastructure more resilient, better for communities @thehill: http:\/\/t.co\/kB7UZzC6kn",
    "id" : 595570452526948352,
    "created_at" : "2015-05-05 12:47:15 +0000",
    "user" : {
      "name" : "Christy Goldfuss",
      "screen_name" : "Goldfuss44",
      "protected" : false,
      "id_str" : "2377561969",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/668926989940727809\/WeMBK__c_normal.jpg",
      "id" : 2377561969,
      "verified" : true
    }
  },
  "id" : 595618583243264000,
  "created_at" : "2015-05-05 15:58:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/petesouza\/status\/595558569287757824\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/cW8BOKh7R9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEPZW8xUIAENYSx.jpg",
      "id_str" : "595558564036354049",
      "id" : 595558564036354049,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEPZW8xUIAENYSx.jpg",
      "sizes" : [ {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/cW8BOKh7R9"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "595583857400872960",
  "text" : "RT @petesouza: Yesterday, young men listen to President Obama at My Brother's Keeper event in the Bronx. http:\/\/t.co\/cW8BOKh7R9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/petesouza\/status\/595558569287757824\/photo\/1",
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/cW8BOKh7R9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CEPZW8xUIAENYSx.jpg",
        "id_str" : "595558564036354049",
        "id" : 595558564036354049,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEPZW8xUIAENYSx.jpg",
        "sizes" : [ {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/cW8BOKh7R9"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "595558569287757824",
    "text" : "Yesterday, young men listen to President Obama at My Brother's Keeper event in the Bronx. http:\/\/t.co\/cW8BOKh7R9",
    "id" : 595558569287757824,
    "created_at" : "2015-05-05 12:00:02 +0000",
    "user" : {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "protected" : false,
      "id_str" : "18215973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771916869808844800\/7d_poH48_normal.jpg",
      "id" : 18215973,
      "verified" : true
    }
  },
  "id" : 595583857400872960,
  "created_at" : "2015-05-05 13:40:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/WG96HOZwke",
      "expanded_url" : "http:\/\/on.fb.me\/1Qh92BO",
      "display_url" : "on.fb.me\/1Qh92BO"
    } ]
  },
  "geo" : { },
  "id_str" : "595446314927845376",
  "text" : "President Obama posted a note on Facebook in remembrance of David Goldberg: http:\/\/t.co\/WG96HOZwke",
  "id" : 595446314927845376,
  "created_at" : "2015-05-05 04:33:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/595365600492331008\/photo\/1",
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/CONRJYxvBF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEMptX6UUAARUuA.jpg",
      "id_str" : "595365435232505856",
      "id" : 595365435232505856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEMptX6UUAARUuA.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/CONRJYxvBF"
    } ],
    "hashtags" : [ {
      "text" : "MayThe4thBeWithYou",
      "indices" : [ 44, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/2S6i95F1iG",
      "expanded_url" : "http:\/\/go.wh.gov\/StarWars",
      "display_url" : "go.wh.gov\/StarWars"
    } ]
  },
  "geo" : { },
  "id_str" : "595365600492331008",
  "text" : "Happy Star Wars Day! http:\/\/t.co\/2S6i95F1iG #MayThe4thBeWithYou http:\/\/t.co\/CONRJYxvBF",
  "id" : 595365600492331008,
  "created_at" : "2015-05-04 23:13:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/595340488489705472\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/NnGotiGVEP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEMSpgnUgAAhB3K.jpg",
      "id_str" : "595340080081829888",
      "id" : 595340080081829888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEMSpgnUgAAhB3K.jpg",
      "sizes" : [ {
        "h" : 374,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 374,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 374,
        "resize" : "fit",
        "w" : 560
      } ],
      "display_url" : "pic.twitter.com\/NnGotiGVEP"
    } ],
    "hashtags" : [ {
      "text" : "TeacherAppreciationWeek",
      "indices" : [ 18, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "595355501350809600",
  "text" : "RT @FLOTUS: Happy #TeacherAppreciationWeek! Let's thank teachers for their extraordinary work on behalf of our kids. http:\/\/t.co\/NnGotiGVEP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/595340488489705472\/photo\/1",
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/NnGotiGVEP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CEMSpgnUgAAhB3K.jpg",
        "id_str" : "595340080081829888",
        "id" : 595340080081829888,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEMSpgnUgAAhB3K.jpg",
        "sizes" : [ {
          "h" : 374,
          "resize" : "fit",
          "w" : 560
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 374,
          "resize" : "fit",
          "w" : 560
        }, {
          "h" : 374,
          "resize" : "fit",
          "w" : 560
        } ],
        "display_url" : "pic.twitter.com\/NnGotiGVEP"
      } ],
      "hashtags" : [ {
        "text" : "TeacherAppreciationWeek",
        "indices" : [ 6, 30 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "595340488489705472",
    "text" : "Happy #TeacherAppreciationWeek! Let's thank teachers for their extraordinary work on behalf of our kids. http:\/\/t.co\/NnGotiGVEP",
    "id" : 595340488489705472,
    "created_at" : "2015-05-04 21:33:28 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 595355501350809600,
  "created_at" : "2015-05-04 22:33:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyBrothersKeeper",
      "indices" : [ 80, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/28ICVCbKpO",
      "expanded_url" : "http:\/\/snpy.tv\/1R7aQPl",
      "display_url" : "snpy.tv\/1R7aQPl"
    } ]
  },
  "geo" : { },
  "id_str" : "595313929133301761",
  "text" : "\"You matter. You matter to us.\" \u2014President Obama to young boys and men of color #MyBrothersKeeper http:\/\/t.co\/28ICVCbKpO",
  "id" : 595313929133301761,
  "created_at" : "2015-05-04 19:47:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "595308049067167744",
  "text" : "\"This will remain a mission for me\u2014not just for the rest of my presidency\u2014but for the rest of my life\" \u2014Obama on helping our kids succeed",
  "id" : 595308049067167744,
  "created_at" : "2015-05-04 19:24:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 120, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "595307269442568194",
  "text" : "\u201CFor these are all our children. We will all profit by, or pay for, whatever they become.\u201D \u2014Obama quoting James Baldwin #OpportunityForAll",
  "id" : 595307269442568194,
  "created_at" : "2015-05-04 19:21:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "595306267087872002",
  "text" : "RT @WHLive: \"This is about more than economics. It\u2019s about values.\" \u2014President Obama on helping young people from every community succeed",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "595306237673218048",
    "text" : "\"This is about more than economics. It\u2019s about values.\" \u2014President Obama on helping young people from every community succeed",
    "id" : 595306237673218048,
    "created_at" : "2015-05-04 19:17:21 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 595306267087872002,
  "created_at" : "2015-05-04 19:17:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/595305252716412929\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/6ONyDvBmwo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CELy0DkVIAAnbKA.jpg",
      "id_str" : "595305076891131904",
      "id" : 595305076891131904,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CELy0DkVIAAnbKA.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/6ONyDvBmwo"
    } ],
    "hashtags" : [ {
      "text" : "MyBrothersKeeper",
      "indices" : [ 98, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "595305252716412929",
  "text" : "\u201CHow well we do as a nation depends on how well our young people are succeeding\u201D \u2014President Obama #MyBrothersKeeper http:\/\/t.co\/6ONyDvBmwo",
  "id" : 595305252716412929,
  "created_at" : "2015-05-04 19:13:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/595304139036315649\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/n6zEBUKpY4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CELx43JVIAAnI_8.jpg",
      "id_str" : "595304059944378368",
      "id" : 595304059944378368,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CELx43JVIAAnI_8.jpg",
      "sizes" : [ {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/n6zEBUKpY4"
    } ],
    "hashtags" : [ {
      "text" : "MyBrothersKeeper",
      "indices" : [ 92, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "595304139036315649",
  "text" : "\u201CAll lives matter. We care about your future. Not just sometimes, but all the time.\" \u2014Obama #MyBrothersKeeper http:\/\/t.co\/n6zEBUKpY4",
  "id" : 595304139036315649,
  "created_at" : "2015-05-04 19:09:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/595303579176423424\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/85ugq0XOib",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CELxXfCUMAA9zW0.jpg",
      "id_str" : "595303486536822784",
      "id" : 595303486536822784,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CELxXfCUMAA9zW0.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      } ],
      "display_url" : "pic.twitter.com\/85ugq0XOib"
    } ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 98, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "595303579176423424",
  "text" : "\"We\u2019ve partnered with cities to get more kids access to quality early education\" \u2014President Obama #OpportunityForAll http:\/\/t.co\/85ugq0XOib",
  "id" : 595303579176423424,
  "created_at" : "2015-05-04 19:06:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "595303066880102400",
  "text" : "\"The overwhelming majority of police officers are good and honest and fair, and they care deeply about their communities.\" \u2014President Obama",
  "id" : 595303066880102400,
  "created_at" : "2015-05-04 19:04:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 117, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/Ve3hfPN6BO",
      "expanded_url" : "http:\/\/wh.gov\/MyBrothersKeeper",
      "display_url" : "wh.gov\/MyBrothersKeep\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "595302222310735873",
  "text" : "\"We do strive to guarantee an equal shot for everybody who\u2019s willing to work for it.\" \u2014Obama: http:\/\/t.co\/Ve3hfPN6BO #OpportunityForAll",
  "id" : 595302222310735873,
  "created_at" : "2015-05-04 19:01:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyBrothersKeeper",
      "indices" : [ 111, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/dEZq9zUPKp",
      "expanded_url" : "http:\/\/go.wh.gov\/J3aUqw",
      "display_url" : "go.wh.gov\/J3aUqw"
    } ]
  },
  "geo" : { },
  "id_str" : "595301149604872192",
  "text" : "Watch live: President Obama speaks on new efforts to expand opportunity for more kids \u2192 http:\/\/t.co\/dEZq9zUPKp #MyBrothersKeeper",
  "id" : 595301149604872192,
  "created_at" : "2015-05-04 18:57:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/595286240422944768\/photo\/1",
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/2Zp5tex5IZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CELhdiKUIAARCSQ.jpg",
      "id_str" : "595285998268850176",
      "id" : 595285998268850176,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CELhdiKUIAARCSQ.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2731,
        "resize" : "fit",
        "w" : 4096
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/2Zp5tex5IZ"
    } ],
    "hashtags" : [ {
      "text" : "TeacherAppreciationWeek",
      "indices" : [ 6, 30 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/ezVzVMZH6A",
      "expanded_url" : "http:\/\/go.wh.gov\/ThankATeacher",
      "display_url" : "go.wh.gov\/ThankATeacher"
    } ]
  },
  "geo" : { },
  "id_str" : "595286240422944768",
  "text" : "Happy #TeacherAppreciationWeek!\nLet's invest in teachers &amp; help our kids realize their dreams. http:\/\/t.co\/ezVzVMZH6A http:\/\/t.co\/2Zp5tex5IZ",
  "id" : 595286240422944768,
  "created_at" : "2015-05-04 17:57:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    }, {
      "name" : "NASA Kepler and K2",
      "screen_name" : "NASAKepler",
      "indices" : [ 114, 125 ],
      "id_str" : "17781165",
      "id" : 17781165
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MayThe4thBeWithYou",
      "indices" : [ 94, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/iV91VQnhe1",
      "expanded_url" : "http:\/\/go.nasa.gov\/1GVF9pj",
      "display_url" : "go.nasa.gov\/1GVF9pj"
    } ]
  },
  "geo" : { },
  "id_str" : "595264211548303360",
  "text" : "RT @NASA: Tatooine? No, it's Kepler-16b, a world with a double sunset. http:\/\/t.co\/iV91VQnhe1 #MayThe4thBeWithYou @NASAKepler http:\/\/t.co\/i\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NASA Kepler and K2",
        "screen_name" : "NASAKepler",
        "indices" : [ 104, 115 ],
        "id_str" : "17781165",
        "id" : 17781165
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NASA\/status\/595260976276107264\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/iEBB111veq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CELKtDqWgAAY-zl.jpg",
        "id_str" : "595260976192192512",
        "id" : 595260976192192512,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CELKtDqWgAAY-zl.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/iEBB111veq"
      } ],
      "hashtags" : [ {
        "text" : "MayThe4thBeWithYou",
        "indices" : [ 84, 103 ]
      } ],
      "urls" : [ {
        "indices" : [ 61, 83 ],
        "url" : "http:\/\/t.co\/iV91VQnhe1",
        "expanded_url" : "http:\/\/go.nasa.gov\/1GVF9pj",
        "display_url" : "go.nasa.gov\/1GVF9pj"
      } ]
    },
    "geo" : { },
    "id_str" : "595260976276107264",
    "text" : "Tatooine? No, it's Kepler-16b, a world with a double sunset. http:\/\/t.co\/iV91VQnhe1 #MayThe4thBeWithYou @NASAKepler http:\/\/t.co\/iEBB111veq",
    "id" : 595260976276107264,
    "created_at" : "2015-05-04 16:17:30 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 595264211548303360,
  "created_at" : "2015-05-04 16:30:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyBrothersKeeper",
      "indices" : [ 127, 144 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/ZuiKCReOkB",
      "expanded_url" : "http:\/\/huff.to\/1GKIe60",
      "display_url" : "huff.to\/1GKIe60"
    } ]
  },
  "geo" : { },
  "id_str" : "595241539904753664",
  "text" : "It's time to tear down barriers facing too many young Americans &amp; expand opportunities to succeed \u2192 http:\/\/t.co\/ZuiKCReOkB #MyBrothersKeeper",
  "id" : 595241539904753664,
  "created_at" : "2015-05-04 15:00:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyBrothersKeeper",
      "indices" : [ 10, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "595223424785592320",
  "text" : "RT @vj44: #MyBrothersKeeper is a call to action for all Americans to recognize that \u201Cmy neighbor's child is my child.\u201D http:\/\/t.co\/zRtHxawG\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MyBrothersKeeper",
        "indices" : [ 0, 17 ]
      } ],
      "urls" : [ {
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/zRtHxawGCl",
        "expanded_url" : "http:\/\/www.huffingtonpost.com\/broderick-johnson\/expanding-opportunity-wor_b_7203626.html?1430742435&utm_campaign=naytev&utm_content=55477747e4b01e7a2e12da8a",
        "display_url" : "huffingtonpost.com\/broderick-john\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "595223385996570624",
    "text" : "#MyBrothersKeeper is a call to action for all Americans to recognize that \u201Cmy neighbor's child is my child.\u201D http:\/\/t.co\/zRtHxawGCl",
    "id" : 595223385996570624,
    "created_at" : "2015-05-04 13:48:08 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 595223424785592320,
  "created_at" : "2015-05-04 13:48:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CommunityCollege",
      "indices" : [ 44, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/L6h342vQpg",
      "expanded_url" : "http:\/\/go.wh.gov\/bS4gXu",
      "display_url" : "go.wh.gov\/bS4gXu"
    } ]
  },
  "geo" : { },
  "id_str" : "594965002160906240",
  "text" : "\"I\u2019ve put forward a plan to make 2 years of #CommunityCollege as free &amp; universal...as high school is today\" \u2014Obama: http:\/\/t.co\/L6h342vQpg",
  "id" : 594965002160906240,
  "created_at" : "2015-05-03 20:41:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u5B89\u500D\u664B\u4E09",
      "screen_name" : "AbeShinzo",
      "indices" : [ 1, 11 ],
      "id_str" : "468122115",
      "id" : 468122115
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 33, 40 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594888800263778304",
  "text" : ".@AbeShinzo, The President &amp; @FLOTUS thank you for a historic visit. The US-Japan relationship has never been stronger. Mata chikai uchi ni.",
  "id" : 594888800263778304,
  "created_at" : "2015-05-03 15:38:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u9996\u76F8\u5B98\u90B8",
      "screen_name" : "kantei",
      "indices" : [ 3, 10 ],
      "id_str" : "412940784",
      "id" : 412940784
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/kantei\/status\/594753783315369985\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/sigkBQ4UGH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CED9aicUUAE7D_-.jpg",
      "id_str" : "594753783176908801",
      "id" : 594753783176908801,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CED9aicUUAE7D_-.jpg",
      "sizes" : [ {
        "h" : 523,
        "resize" : "fit",
        "w" : 784
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 523,
        "resize" : "fit",
        "w" : 784
      } ],
      "display_url" : "pic.twitter.com\/sigkBQ4UGH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594888201514385409",
  "text" : "RT @kantei: Barack, thank you for everything, including the Lincoln Memorial tour, Yamaguchi sake &amp; haiku -Shinzo http:\/\/t.co\/sigkBQ4UGH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bi.garage.co.jp\/\" rel=\"nofollow\"\u003ETweetmanager Series\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/kantei\/status\/594753783315369985\/photo\/1",
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/sigkBQ4UGH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CED9aicUUAE7D_-.jpg",
        "id_str" : "594753783176908801",
        "id" : 594753783176908801,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CED9aicUUAE7D_-.jpg",
        "sizes" : [ {
          "h" : 523,
          "resize" : "fit",
          "w" : 784
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 523,
          "resize" : "fit",
          "w" : 784
        } ],
        "display_url" : "pic.twitter.com\/sigkBQ4UGH"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "594753783315369985",
    "text" : "Barack, thank you for everything, including the Lincoln Memorial tour, Yamaguchi sake &amp; haiku -Shinzo http:\/\/t.co\/sigkBQ4UGH",
    "id" : 594753783315369985,
    "created_at" : "2015-05-03 06:42:06 +0000",
    "user" : {
      "name" : "\u9996\u76F8\u5B98\u90B8",
      "screen_name" : "kantei",
      "protected" : false,
      "id_str" : "412940784",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2592225984\/iu6a5op0blkjkbnceolg_normal.jpeg",
      "id" : 412940784,
      "verified" : true
    }
  },
  "id" : 594888201514385409,
  "created_at" : "2015-05-03 15:36:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ReachHigher",
      "indices" : [ 106, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/L6h342vQpg",
      "expanded_url" : "http:\/\/go.wh.gov\/bS4gXu",
      "display_url" : "go.wh.gov\/bS4gXu"
    } ]
  },
  "geo" : { },
  "id_str" : "594884257555861505",
  "text" : "President Obama on why we need to ensure that every child gets a great education \u2192 http:\/\/t.co\/L6h342vQpg #ReachHigher",
  "id" : 594884257555861505,
  "created_at" : "2015-05-03 15:20:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 3, 11 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594873463594180608",
  "text" : "RT @DrBiden: \"Change is serving the country you love regardless of who you love.\" -Dr. Biden at @hrcatlanta dinner.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "594669682138939392",
    "text" : "\"Change is serving the country you love regardless of who you love.\" -Dr. Biden at @hrcatlanta dinner.",
    "id" : 594669682138939392,
    "created_at" : "2015-05-03 01:07:55 +0000",
    "user" : {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "protected" : false,
      "id_str" : "1281405877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608687663034474496\/wvzVG_yt_normal.jpg",
      "id" : 1281405877,
      "verified" : true
    }
  },
  "id" : 594873463594180608,
  "created_at" : "2015-05-03 14:37:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/594600102989156353\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/TTThxVR0ob",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CEBxhpBUIAAsdD1.png",
      "id_str" : "594599973573894144",
      "id" : 594599973573894144,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CEBxhpBUIAAsdD1.png",
      "sizes" : [ {
        "h" : 144,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 288,
        "resize" : "fit",
        "w" : 678
      }, {
        "h" : 288,
        "resize" : "fit",
        "w" : 678
      } ],
      "display_url" : "pic.twitter.com\/TTThxVR0ob"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594600102989156353",
  "text" : "\"On behalf of the American people, we wish the Duke and Duchess and their son George much joy.\" \u2014President Obama: http:\/\/t.co\/TTThxVR0ob",
  "id" : 594600102989156353,
  "created_at" : "2015-05-02 20:31:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/L6h342ef0G",
      "expanded_url" : "http:\/\/go.wh.gov\/bS4gXu",
      "display_url" : "go.wh.gov\/bS4gXu"
    } ]
  },
  "geo" : { },
  "id_str" : "594579640317935616",
  "text" : "\"I\u2019ve put forward a plan to make 2 years of community college as free &amp; universal...as high school is today\" \u2014Obama: http:\/\/t.co\/L6h342ef0G",
  "id" : 594579640317935616,
  "created_at" : "2015-05-02 19:10:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/L6h342ef0G",
      "expanded_url" : "http:\/\/go.wh.gov\/bS4gXu",
      "display_url" : "go.wh.gov\/bS4gXu"
    } ]
  },
  "geo" : { },
  "id_str" : "594550194450010113",
  "text" : "\"We\u2019ve got to help ensure that everyone...in every zip code\u2014urban and rural\u2014has the chance to learn\" \u2014Obama: http:\/\/t.co\/L6h342ef0G",
  "id" : 594550194450010113,
  "created_at" : "2015-05-02 17:13:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/L6h342vQpg",
      "expanded_url" : "http:\/\/go.wh.gov\/bS4gXu",
      "display_url" : "go.wh.gov\/bS4gXu"
    } ]
  },
  "geo" : { },
  "id_str" : "594528283900936196",
  "text" : "\"No matter who you are...or how much money you\u2019ve got, you should be able to access the world\u2019s knowledge\" \u2014Obama: http:\/\/t.co\/L6h342vQpg",
  "id" : 594528283900936196,
  "created_at" : "2015-05-02 15:46:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pharrell Williams",
      "screen_name" : "Pharrell",
      "indices" : [ 3, 12 ],
      "id_str" : "338084918",
      "id" : 338084918
    }, {
      "name" : "Reach Higher",
      "screen_name" : "ReachHigher",
      "indices" : [ 77, 89 ],
      "id_str" : "2461821548",
      "id" : 2461821548
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 103, 110 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Pharrell\/status\/594270549141884929\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/oaMP2EpbzO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CD9Fw9IUgAAvRll.jpg",
      "id_str" : "594270383181692928",
      "id" : 594270383181692928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CD9Fw9IUgAAvRll.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/oaMP2EpbzO"
    } ],
    "hashtags" : [ {
      "text" : "ReachHigher",
      "indices" : [ 90, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594277753907781633",
  "text" : "RT @Pharrell: Education is the key to freedom. YOU are the next best leaders @ReachHigher #ReachHigher @FLOTUS http:\/\/t.co\/oaMP2EpbzO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Reach Higher",
        "screen_name" : "ReachHigher",
        "indices" : [ 63, 75 ],
        "id_str" : "2461821548",
        "id" : 2461821548
      }, {
        "name" : "The First Lady",
        "screen_name" : "FLOTUS",
        "indices" : [ 89, 96 ],
        "id_str" : "1093090866",
        "id" : 1093090866
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Pharrell\/status\/594270549141884929\/photo\/1",
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/oaMP2EpbzO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CD9Fw9IUgAAvRll.jpg",
        "id_str" : "594270383181692928",
        "id" : 594270383181692928,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CD9Fw9IUgAAvRll.jpg",
        "sizes" : [ {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        } ],
        "display_url" : "pic.twitter.com\/oaMP2EpbzO"
      } ],
      "hashtags" : [ {
        "text" : "ReachHigher",
        "indices" : [ 76, 88 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "594270549141884929",
    "text" : "Education is the key to freedom. YOU are the next best leaders @ReachHigher #ReachHigher @FLOTUS http:\/\/t.co\/oaMP2EpbzO",
    "id" : 594270549141884929,
    "created_at" : "2015-05-01 22:41:54 +0000",
    "user" : {
      "name" : "Pharrell Williams",
      "screen_name" : "Pharrell",
      "protected" : false,
      "id_str" : "338084918",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/777892792328531968\/aRbbZcMo_normal.jpg",
      "id" : 338084918,
      "verified" : true
    }
  },
  "id" : 594277753907781633,
  "created_at" : "2015-05-01 23:10:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "indices" : [ 3, 13 ],
      "id_str" : "15007149",
      "id" : 15007149
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 28, 35 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Yale University",
      "screen_name" : "Yale",
      "indices" : [ 119, 124 ],
      "id_str" : "5695032",
      "id" : 5695032
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ReachHigher",
      "indices" : [ 102, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594250302825439232",
  "text" : "RT @JohnKerry: Joining with @FLOTUS to encourage all young people in the U.S. and around the world to #ReachHigher. cc:@Yale http:\/\/t.co\/5n\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The First Lady",
        "screen_name" : "FLOTUS",
        "indices" : [ 13, 20 ],
        "id_str" : "1093090866",
        "id" : 1093090866
      }, {
        "name" : "Yale University",
        "screen_name" : "Yale",
        "indices" : [ 104, 109 ],
        "id_str" : "5695032",
        "id" : 5695032
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JohnKerry\/status\/594247831717818368\/photo\/1",
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/5nQsfnsmDI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CD8xQQLWMAAX4CR.jpg",
        "id_str" : "594247831126421504",
        "id" : 594247831126421504,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CD8xQQLWMAAX4CR.jpg",
        "sizes" : [ {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 681,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 681,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/5nQsfnsmDI"
      } ],
      "hashtags" : [ {
        "text" : "ReachHigher",
        "indices" : [ 87, 99 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "594247831717818368",
    "text" : "Joining with @FLOTUS to encourage all young people in the U.S. and around the world to #ReachHigher. cc:@Yale http:\/\/t.co\/5nQsfnsmDI",
    "id" : 594247831717818368,
    "created_at" : "2015-05-01 21:11:38 +0000",
    "user" : {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "protected" : false,
      "id_str" : "15007149",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/482149339842617346\/l6b7LXjb_normal.jpeg",
      "id" : 15007149,
      "verified" : true
    }
  },
  "id" : 594250302825439232,
  "created_at" : "2015-05-01 21:21:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA Astronauts",
      "screen_name" : "NASA_Astronauts",
      "indices" : [ 3, 19 ],
      "id_str" : "43166813",
      "id" : 43166813
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ReachHigher",
      "indices" : [ 121, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594223442506993664",
  "text" : "RT @NASA_Astronauts: Never stop reaching for the stars! A good education helped take these astronauts out of this world. #ReachHigher http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NASA_Astronauts\/status\/594181157870272513\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/gl8zvlwcte",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CD70nUzUkAANiOV.jpg",
        "id_str" : "594181157295525888",
        "id" : 594181157295525888,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CD70nUzUkAANiOV.jpg",
        "sizes" : [ {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/gl8zvlwcte"
      } ],
      "hashtags" : [ {
        "text" : "ReachHigher",
        "indices" : [ 100, 112 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "594181157870272513",
    "text" : "Never stop reaching for the stars! A good education helped take these astronauts out of this world. #ReachHigher http:\/\/t.co\/gl8zvlwcte",
    "id" : 594181157870272513,
    "created_at" : "2015-05-01 16:46:42 +0000",
    "user" : {
      "name" : "NASA Astronauts",
      "screen_name" : "NASA_Astronauts",
      "protected" : false,
      "id_str" : "43166813",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458726768468180992\/AbY9O7eH_normal.jpeg",
      "id" : 43166813,
      "verified" : true
    }
  },
  "id" : 594223442506993664,
  "created_at" : "2015-05-01 19:34:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Seventeen",
      "screen_name" : "seventeen",
      "indices" : [ 3, 13 ],
      "id_str" : "16824090",
      "id" : 16824090
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 108, 115 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Reach Higher",
      "screen_name" : "ReachHigher",
      "indices" : [ 116, 128 ],
      "id_str" : "2461821548",
      "id" : 2461821548
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeSigningDay",
      "indices" : [ 50, 68 ]
    }, {
      "text" : "ReachHigher",
      "indices" : [ 94, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594222823335395328",
  "text" : "RT @seventeen: We're rocking our college gear for #CollegeSigningDay to encourage students to #ReachHigher! @FLOTUS @ReachHigher http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The First Lady",
        "screen_name" : "FLOTUS",
        "indices" : [ 93, 100 ],
        "id_str" : "1093090866",
        "id" : 1093090866
      }, {
        "name" : "Reach Higher",
        "screen_name" : "ReachHigher",
        "indices" : [ 101, 113 ],
        "id_str" : "2461821548",
        "id" : 2461821548
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/seventeen\/status\/594221879256297473\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/YgmxYE8Ske",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CD8ZpN8UgAAGH-N.jpg",
        "id_str" : "594221871744188416",
        "id" : 594221871744188416,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CD8ZpN8UgAAGH-N.jpg",
        "sizes" : [ {
          "h" : 318,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 958,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 561,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 958,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/YgmxYE8Ske"
      } ],
      "hashtags" : [ {
        "text" : "CollegeSigningDay",
        "indices" : [ 35, 53 ]
      }, {
        "text" : "ReachHigher",
        "indices" : [ 79, 91 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "594221879256297473",
    "text" : "We're rocking our college gear for #CollegeSigningDay to encourage students to #ReachHigher! @FLOTUS @ReachHigher http:\/\/t.co\/YgmxYE8Ske",
    "id" : 594221879256297473,
    "created_at" : "2015-05-01 19:28:30 +0000",
    "user" : {
      "name" : "Seventeen",
      "screen_name" : "seventeen",
      "protected" : false,
      "id_str" : "16824090",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/768854806953799680\/aBUMKx78_normal.jpg",
      "id" : 16824090,
      "verified" : true
    }
  },
  "id" : 594222823335395328,
  "created_at" : "2015-05-01 19:32:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michigan Football",
      "screen_name" : "UMichFootball",
      "indices" : [ 3, 17 ],
      "id_str" : "27902825",
      "id" : 27902825
    }, {
      "name" : "Coach Harbaugh",
      "screen_name" : "CoachJim4UM",
      "indices" : [ 20, 32 ],
      "id_str" : "2955596087",
      "id" : 2955596087
    }, {
      "name" : "Michelle Obama",
      "screen_name" : "MichelleObama",
      "indices" : [ 55, 69 ],
      "id_str" : "409486555",
      "id" : 409486555
    }, {
      "name" : "Ciara",
      "screen_name" : "ciara",
      "indices" : [ 76, 82 ],
      "id_str" : "28897926",
      "id" : 28897926
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ReachHigher",
      "indices" : [ 128, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594217735627898882",
  "text" : "RT @umichfootball: .@CoachJim4UM joined the First Lady @MichelleObama &amp; @ciara today in Detroit to promote higher education #ReachHigher ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Coach Harbaugh",
        "screen_name" : "CoachJim4UM",
        "indices" : [ 1, 13 ],
        "id_str" : "2955596087",
        "id" : 2955596087
      }, {
        "name" : "Michelle Obama",
        "screen_name" : "MichelleObama",
        "indices" : [ 36, 50 ],
        "id_str" : "409486555",
        "id" : 409486555
      }, {
        "name" : "Ciara",
        "screen_name" : "ciara",
        "indices" : [ 57, 63 ],
        "id_str" : "28897926",
        "id" : 28897926
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/umichfootball\/status\/594188517045047296\/photo\/1",
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/IbXryGksdQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CD77SG1UMAEC_so.jpg",
        "id_str" : "594188489349935105",
        "id" : 594188489349935105,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CD77SG1UMAEC_so.jpg",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 639,
          "resize" : "fit",
          "w" : 639
        }, {
          "h" : 639,
          "resize" : "fit",
          "w" : 639
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/IbXryGksdQ"
      } ],
      "hashtags" : [ {
        "text" : "ReachHigher",
        "indices" : [ 109, 121 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "594188517045047296",
    "text" : ".@CoachJim4UM joined the First Lady @MichelleObama &amp; @ciara today in Detroit to promote higher education #ReachHigher http:\/\/t.co\/IbXryGksdQ",
    "id" : 594188517045047296,
    "created_at" : "2015-05-01 17:15:56 +0000",
    "user" : {
      "name" : "Michigan Football",
      "screen_name" : "UMichFootball",
      "protected" : false,
      "id_str" : "27902825",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762258952998354944\/77PosglG_normal.jpg",
      "id" : 27902825,
      "verified" : true
    }
  },
  "id" : 594217735627898882,
  "created_at" : "2015-05-01 19:12:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Savvy Shields",
      "screen_name" : "MissAmerica",
      "indices" : [ 3, 15 ],
      "id_str" : "35940348",
      "id" : 35940348
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 108, 115 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Reach Higher",
      "screen_name" : "ReachHigher",
      "indices" : [ 116, 128 ],
      "id_str" : "2461821548",
      "id" : 2461821548
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MissAmerica",
      "indices" : [ 38, 50 ]
    }, {
      "text" : "ReachHigher",
      "indices" : [ 72, 84 ]
    }, {
      "text" : "scholarships",
      "indices" : [ 93, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594215111067238401",
  "text" : "RT @MissAmerica: Participating in the #MissAmerica program helped me to #ReachHigher through #scholarships! @FLOTUS @ReachHigher http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The First Lady",
        "screen_name" : "FLOTUS",
        "indices" : [ 91, 98 ],
        "id_str" : "1093090866",
        "id" : 1093090866
      }, {
        "name" : "Reach Higher",
        "screen_name" : "ReachHigher",
        "indices" : [ 99, 111 ],
        "id_str" : "2461821548",
        "id" : 2461821548
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/MissAmerica\/status\/594162959854632960\/photo\/1",
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/6h0AgSvsGT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CD7kEC3VEAMCx75.jpg",
        "id_str" : "594162958999031811",
        "id" : 594162958999031811,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CD7kEC3VEAMCx75.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/6h0AgSvsGT"
      } ],
      "hashtags" : [ {
        "text" : "MissAmerica",
        "indices" : [ 21, 33 ]
      }, {
        "text" : "ReachHigher",
        "indices" : [ 55, 67 ]
      }, {
        "text" : "scholarships",
        "indices" : [ 76, 89 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "594162959854632960",
    "text" : "Participating in the #MissAmerica program helped me to #ReachHigher through #scholarships! @FLOTUS @ReachHigher http:\/\/t.co\/6h0AgSvsGT",
    "id" : 594162959854632960,
    "created_at" : "2015-05-01 15:34:23 +0000",
    "user" : {
      "name" : "Savvy Shields",
      "screen_name" : "MissAmerica",
      "protected" : false,
      "id_str" : "35940348",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794610497018589184\/i3Q8kXoT_normal.jpg",
      "id" : 35940348,
      "verified" : true
    }
  },
  "id" : 594215111067238401,
  "created_at" : "2015-05-01 19:01:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Connie Britton",
      "screen_name" : "conniebritton",
      "indices" : [ 3, 17 ],
      "id_str" : "1905230346",
      "id" : 1905230346
    }, {
      "name" : "Reach Higher",
      "screen_name" : "ReachHigher",
      "indices" : [ 41, 53 ],
      "id_str" : "2461821548",
      "id" : 2461821548
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 59, 66 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594213944127959041",
  "text" : "RT @conniebritton: Celebrating 1 year of @reachhigher with @flotus and thousands of students around the country in my\u2026 https:\/\/t.co\/aUl8Dm6\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Reach Higher",
        "screen_name" : "ReachHigher",
        "indices" : [ 22, 34 ],
        "id_str" : "2461821548",
        "id" : 2461821548
      }, {
        "name" : "The First Lady",
        "screen_name" : "FLOTUS",
        "indices" : [ 40, 47 ],
        "id_str" : "1093090866",
        "id" : 1093090866
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/aUl8Dm6xGz",
        "expanded_url" : "https:\/\/instagram.com\/p\/2JcdSNC3kl\/",
        "display_url" : "instagram.com\/p\/2JcdSNC3kl\/"
      } ]
    },
    "geo" : { },
    "id_str" : "594190582601412609",
    "text" : "Celebrating 1 year of @reachhigher with @flotus and thousands of students around the country in my\u2026 https:\/\/t.co\/aUl8Dm6xGz",
    "id" : 594190582601412609,
    "created_at" : "2015-05-01 17:24:09 +0000",
    "user" : {
      "name" : "Connie Britton",
      "screen_name" : "conniebritton",
      "protected" : false,
      "id_str" : "1905230346",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/795623148842524672\/CqwRofAF_normal.jpg",
      "id" : 1905230346,
      "verified" : true
    }
  },
  "id" : 594213944127959041,
  "created_at" : "2015-05-01 18:56:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Power",
      "screen_name" : "AmbassadorPower",
      "indices" : [ 3, 19 ],
      "id_str" : "1615463502",
      "id" : 1615463502
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WPFD2015",
      "indices" : [ 30, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594207433859301377",
  "text" : "RT @AmbassadorPower: Ahead of #WPFD2015, POTUS hosted journos who've been persecuted for doing vital work investigating, trying to tell tru\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WPFD2015",
        "indices" : [ 9, 18 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "594184817694089217",
    "text" : "Ahead of #WPFD2015, POTUS hosted journos who've been persecuted for doing vital work investigating, trying to tell truth in their countries",
    "id" : 594184817694089217,
    "created_at" : "2015-05-01 17:01:14 +0000",
    "user" : {
      "name" : "Samantha Power",
      "screen_name" : "AmbassadorPower",
      "protected" : false,
      "id_str" : "1615463502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/620632341497683968\/CkFXABqQ_normal.jpg",
      "id" : 1615463502,
      "verified" : true
    }
  },
  "id" : 594207433859301377,
  "created_at" : "2015-05-01 18:31:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Justice Department",
      "screen_name" : "TheJusticeDept",
      "indices" : [ 3, 18 ],
      "id_str" : "73181712",
      "id" : 73181712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/hShkXUDmAI",
      "expanded_url" : "http:\/\/go.usa.gov\/3Bu3V",
      "display_url" : "go.usa.gov\/3Bu3V"
    } ]
  },
  "geo" : { },
  "id_str" : "594205072810188800",
  "text" : "RT @TheJusticeDept: Justice Department Announces $20 Million in Funding to Support Body-Worn Camera Pilot Program http:\/\/t.co\/hShkXUDmAI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/hShkXUDmAI",
        "expanded_url" : "http:\/\/go.usa.gov\/3Bu3V",
        "display_url" : "go.usa.gov\/3Bu3V"
      } ]
    },
    "geo" : { },
    "id_str" : "594160789856112641",
    "text" : "Justice Department Announces $20 Million in Funding to Support Body-Worn Camera Pilot Program http:\/\/t.co\/hShkXUDmAI",
    "id" : 594160789856112641,
    "created_at" : "2015-05-01 15:25:45 +0000",
    "user" : {
      "name" : "Justice Department",
      "screen_name" : "TheJusticeDept",
      "protected" : false,
      "id_str" : "73181712",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/445550654\/twitter_logo_normal.png",
      "id" : 73181712,
      "verified" : true
    }
  },
  "id" : 594205072810188800,
  "created_at" : "2015-05-01 18:21:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Education",
      "screen_name" : "usedgov",
      "indices" : [ 3, 11 ],
      "id_str" : "20437286",
      "id" : 20437286
    }, {
      "name" : "IUPUI",
      "screen_name" : "IUPUI",
      "indices" : [ 91, 97 ],
      "id_str" : "10086382",
      "id" : 10086382
    }, {
      "name" : "Reach Higher",
      "screen_name" : "ReachHigher",
      "indices" : [ 117, 129 ],
      "id_str" : "2461821548",
      "id" : 2461821548
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeSigningDay",
      "indices" : [ 98, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594189684617547776",
  "text" : "RT @usedgov: My name is China. I have cerebral palsy. Nothing is impossible. I'm attending @IUPUI #CollegeSigningDay @ReachHigher http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "IUPUI",
        "screen_name" : "IUPUI",
        "indices" : [ 78, 84 ],
        "id_str" : "10086382",
        "id" : 10086382
      }, {
        "name" : "Reach Higher",
        "screen_name" : "ReachHigher",
        "indices" : [ 104, 116 ],
        "id_str" : "2461821548",
        "id" : 2461821548
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/usedgov\/status\/594160620309721088\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/9IxrzNsCpi",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CD7h7SPXIAELLeU.jpg",
        "id_str" : "594160609484283905",
        "id" : 594160609484283905,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CD7h7SPXIAELLeU.jpg",
        "sizes" : [ {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/9IxrzNsCpi"
      } ],
      "hashtags" : [ {
        "text" : "CollegeSigningDay",
        "indices" : [ 85, 103 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "594160620309721088",
    "text" : "My name is China. I have cerebral palsy. Nothing is impossible. I'm attending @IUPUI #CollegeSigningDay @ReachHigher http:\/\/t.co\/9IxrzNsCpi",
    "id" : 594160620309721088,
    "created_at" : "2015-05-01 15:25:05 +0000",
    "user" : {
      "name" : "US Dept of Education",
      "screen_name" : "usedgov",
      "protected" : false,
      "id_str" : "20437286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749204008108261377\/93-TTeZl_normal.jpg",
      "id" : 20437286,
      "verified" : true
    }
  },
  "id" : 594189684617547776,
  "created_at" : "2015-05-01 17:20:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ReachHigher",
      "indices" : [ 38, 50 ]
    }, {
      "text" : "CollegeSigningDay",
      "indices" : [ 55, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594181083484135424",
  "text" : "RT @VP: Everyone deserves a chance to #ReachHigher. On #CollegeSigningDay wear your school colors \u2013 preferably Delaware blue. http:\/\/t.co\/z\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/594173569346576384\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/zeHhhvXOH9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CD7ttikVIAExuHD.jpg",
        "id_str" : "594173567488565249",
        "id" : 594173567488565249,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CD7ttikVIAExuHD.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 2000,
          "resize" : "fit",
          "w" : 3000
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/zeHhhvXOH9"
      } ],
      "hashtags" : [ {
        "text" : "ReachHigher",
        "indices" : [ 30, 42 ]
      }, {
        "text" : "CollegeSigningDay",
        "indices" : [ 47, 65 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "594173569346576384",
    "text" : "Everyone deserves a chance to #ReachHigher. On #CollegeSigningDay wear your school colors \u2013 preferably Delaware blue. http:\/\/t.co\/zeHhhvXOH9",
    "id" : 594173569346576384,
    "created_at" : "2015-05-01 16:16:32 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 594181083484135424,
  "created_at" : "2015-05-01 16:46:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DPSCommunityDistrict",
      "screen_name" : "Detroitk12",
      "indices" : [ 3, 14 ],
      "id_str" : "57457257",
      "id" : 57457257
    }, {
      "name" : "Reach Higher",
      "screen_name" : "ReachHigher",
      "indices" : [ 93, 105 ],
      "id_str" : "2461821548",
      "id" : 2461821548
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 106, 113 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ReachHigher",
      "indices" : [ 114, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594173470683987968",
  "text" : "RT @Detroitk12: \"If I did this, YOU can do this. I worked hard. That's it. And so will you!\" @ReachHigher @FLOTUS #ReachHigher http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Reach Higher",
        "screen_name" : "ReachHigher",
        "indices" : [ 77, 89 ],
        "id_str" : "2461821548",
        "id" : 2461821548
      }, {
        "name" : "The First Lady",
        "screen_name" : "FLOTUS",
        "indices" : [ 90, 97 ],
        "id_str" : "1093090866",
        "id" : 1093090866
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Detroitk12\/status\/594171190513631232\/photo\/1",
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/hMRoWEvVZR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CD7rfoVUkAAwQWk.jpg",
        "id_str" : "594171129494802432",
        "id" : 594171129494802432,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CD7rfoVUkAAwQWk.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/hMRoWEvVZR"
      } ],
      "hashtags" : [ {
        "text" : "ReachHigher",
        "indices" : [ 98, 110 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "594171190513631232",
    "text" : "\"If I did this, YOU can do this. I worked hard. That's it. And so will you!\" @ReachHigher @FLOTUS #ReachHigher http:\/\/t.co\/hMRoWEvVZR",
    "id" : 594171190513631232,
    "created_at" : "2015-05-01 16:07:05 +0000",
    "user" : {
      "name" : "DPSCommunityDistrict",
      "screen_name" : "Detroitk12",
      "protected" : false,
      "id_str" : "57457257",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/753285248138502144\/ONfVnGt5_normal.jpg",
      "id" : 57457257,
      "verified" : false
    }
  },
  "id" : 594173470683987968,
  "created_at" : "2015-05-01 16:16:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 57, 68 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeSigningDay",
      "indices" : [ 26, 44 ]
    }, {
      "text" : "ReachHigher",
      "indices" : [ 109, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594157035987468289",
  "text" : "RT @PressSec: Celebrating #CollegeSigningDay here at the @WhiteHouse, share a photo in your school gear with #ReachHigher http:\/\/t.co\/yV4S7\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 43, 54 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PressSec\/status\/594156734240796672\/photo\/1",
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/yV4S758uRF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CD7eYCTW8AAyh0t.jpg",
        "id_str" : "594156705375776768",
        "id" : 594156705375776768,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CD7eYCTW8AAyh0t.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 2448,
          "resize" : "fit",
          "w" : 3264
        } ],
        "display_url" : "pic.twitter.com\/yV4S758uRF"
      } ],
      "hashtags" : [ {
        "text" : "CollegeSigningDay",
        "indices" : [ 12, 30 ]
      }, {
        "text" : "ReachHigher",
        "indices" : [ 95, 107 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "594156734240796672",
    "text" : "Celebrating #CollegeSigningDay here at the @WhiteHouse, share a photo in your school gear with #ReachHigher http:\/\/t.co\/yV4S758uRF",
    "id" : 594156734240796672,
    "created_at" : "2015-05-01 15:09:38 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 594157035987468289,
  "created_at" : "2015-05-01 15:10:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/594150630060466176\/photo\/1",
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/G9NrCkRcwn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CD7YpGwUsAQEG_N.jpg",
      "id_str" : "594150401559015428",
      "id" : 594150401559015428,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CD7YpGwUsAQEG_N.jpg",
      "sizes" : [ {
        "h" : 341,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 853,
        "resize" : "fit",
        "w" : 851
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 853,
        "resize" : "fit",
        "w" : 851
      }, {
        "h" : 601,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/G9NrCkRcwn"
    } ],
    "hashtags" : [ {
      "text" : "CollegeSigningDay",
      "indices" : [ 6, 24 ]
    }, {
      "text" : "ReachHigher",
      "indices" : [ 65, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/DBjvCy4HVV",
      "expanded_url" : "https:\/\/instagram.com\/p\/2JDhxmPZEz\/",
      "display_url" : "instagram.com\/p\/2JDhxmPZEz\/"
    } ]
  },
  "geo" : { },
  "id_str" : "594150630060466176",
  "text" : "Happy #CollegeSigningDay! Share a photo in your school gear with #ReachHigher. https:\/\/t.co\/DBjvCy4HVV http:\/\/t.co\/G9NrCkRcwn",
  "id" : 594150630060466176,
  "created_at" : "2015-05-01 14:45:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Homeland Security",
      "screen_name" : "DHSgov",
      "indices" : [ 3, 10 ],
      "id_str" : "15647676",
      "id" : 15647676
    }, {
      "name" : "Morehouse College",
      "screen_name" : "Morehouse",
      "indices" : [ 48, 58 ],
      "id_str" : "111074974",
      "id" : 111074974
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/DHSgov\/status\/594135881730105346\/photo\/1",
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/rYYwu3nLKt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CD7Lb2bUkAAZUSv.jpg",
      "id_str" : "594135880186499072",
      "id" : 594135880186499072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CD7Lb2bUkAAZUSv.jpg",
      "sizes" : [ {
        "h" : 2100,
        "resize" : "fit",
        "w" : 2100
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/rYYwu3nLKt"
    } ],
    "hashtags" : [ {
      "text" : "CollegeSigningDay",
      "indices" : [ 18, 36 ]
    }, {
      "text" : "ReachHigher",
      "indices" : [ 87, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594142911425433601",
  "text" : "RT @DHSgov: Happy #CollegeSigningDay from proud @Morehouse alum Secretary Jeh Johnson! #ReachHigher http:\/\/t.co\/rYYwu3nLKt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Morehouse College",
        "screen_name" : "Morehouse",
        "indices" : [ 36, 46 ],
        "id_str" : "111074974",
        "id" : 111074974
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DHSgov\/status\/594135881730105346\/photo\/1",
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/rYYwu3nLKt",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CD7Lb2bUkAAZUSv.jpg",
        "id_str" : "594135880186499072",
        "id" : 594135880186499072,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CD7Lb2bUkAAZUSv.jpg",
        "sizes" : [ {
          "h" : 2100,
          "resize" : "fit",
          "w" : 2100
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/rYYwu3nLKt"
      } ],
      "hashtags" : [ {
        "text" : "CollegeSigningDay",
        "indices" : [ 6, 24 ]
      }, {
        "text" : "ReachHigher",
        "indices" : [ 75, 87 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "594135881730105346",
    "text" : "Happy #CollegeSigningDay from proud @Morehouse alum Secretary Jeh Johnson! #ReachHigher http:\/\/t.co\/rYYwu3nLKt",
    "id" : 594135881730105346,
    "created_at" : "2015-05-01 13:46:47 +0000",
    "user" : {
      "name" : "Homeland Security",
      "screen_name" : "DHSgov",
      "protected" : false,
      "id_str" : "15647676",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/936215926\/dhs-twitter-300_normal.jpg",
      "id" : 15647676,
      "verified" : true
    }
  },
  "id" : 594142911425433601,
  "created_at" : "2015-05-01 14:14:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Roberts",
      "screen_name" : "RobinRoberts",
      "indices" : [ 3, 16 ],
      "id_str" : "267921808",
      "id" : 267921808
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 56, 63 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ReachHigher",
      "indices" : [ 66, 78 ]
    }, {
      "text" : "LionUp",
      "indices" : [ 128, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594139903488761857",
  "text" : "RT @RobinRoberts: Proud of my alma mater, in support of @FLOTUS\u2019s #ReachHigher encouraging students to pursue higher education. #LionUp htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The First Lady",
        "screen_name" : "FLOTUS",
        "indices" : [ 38, 45 ],
        "id_str" : "1093090866",
        "id" : 1093090866
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/RobinRoberts\/status\/594135440053108736\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/2bfdizL5Wj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CD7LCLWUgAEVGQV.jpg",
        "id_str" : "594135439126069249",
        "id" : 594135439126069249,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CD7LCLWUgAEVGQV.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2448,
          "resize" : "fit",
          "w" : 2448
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/2bfdizL5Wj"
      } ],
      "hashtags" : [ {
        "text" : "ReachHigher",
        "indices" : [ 48, 60 ]
      }, {
        "text" : "LionUp",
        "indices" : [ 110, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "594135440053108736",
    "text" : "Proud of my alma mater, in support of @FLOTUS\u2019s #ReachHigher encouraging students to pursue higher education. #LionUp http:\/\/t.co\/2bfdizL5Wj",
    "id" : 594135440053108736,
    "created_at" : "2015-05-01 13:45:02 +0000",
    "user" : {
      "name" : "Robin Roberts",
      "screen_name" : "RobinRoberts",
      "protected" : false,
      "id_str" : "267921808",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/456076015261863936\/lJuO4EoP_normal.jpeg",
      "id" : 267921808,
      "verified" : true
    }
  },
  "id" : 594139903488761857,
  "created_at" : "2015-05-01 14:02:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CollegeSigningDay",
      "indices" : [ 28, 46 ]
    }, {
      "text" : "ReachHigher",
      "indices" : [ 116, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "594138151947358209",
  "text" : "RT @FLOTUS: Who's ready for #CollegeSigningDay?\nShare a photo in your college gear to celebrate students pushing to #ReachHigher. http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/594136938644279296\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/nmXUjlobNv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CD7MKjuUsAEdl0m.jpg",
        "id_str" : "594136682619777025",
        "id" : 594136682619777025,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CD7MKjuUsAEdl0m.jpg",
        "sizes" : [ {
          "h" : 341,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 853,
          "resize" : "fit",
          "w" : 851
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 853,
          "resize" : "fit",
          "w" : 851
        }, {
          "h" : 601,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/nmXUjlobNv"
      } ],
      "hashtags" : [ {
        "text" : "CollegeSigningDay",
        "indices" : [ 16, 34 ]
      }, {
        "text" : "ReachHigher",
        "indices" : [ 104, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "594136938644279296",
    "text" : "Who's ready for #CollegeSigningDay?\nShare a photo in your college gear to celebrate students pushing to #ReachHigher. http:\/\/t.co\/nmXUjlobNv",
    "id" : 594136938644279296,
    "created_at" : "2015-05-01 13:50:59 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 594138151947358209,
  "created_at" : "2015-05-01 13:55:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
} ]