Grailbird.data.tweets_2012_03 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BuffettRule",
      "indices" : [ 106, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/WPZamXzh",
      "expanded_url" : "http:\/\/youtu.be\/XhPjeL3GQto",
      "display_url" : "youtu.be\/XhPjeL3GQto"
    } ]
  },
  "geo" : { },
  "id_str" : "186128028143857664",
  "text" : "\"Tell [Congress] to stop giving tax breaks to people who don\u2019t need them\" -President Obama on passing the #BuffettRule http:\/\/t.co\/WPZamXzh",
  "id" : 186128028143857664,
  "created_at" : "2012-03-31 16:29:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deepa",
      "screen_name" : "deepa_k",
      "indices" : [ 3, 11 ],
      "id_str" : "24363945",
      "id" : 24363945
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 22, 33 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "Facebook",
      "screen_name" : "facebook",
      "indices" : [ 34, 43 ],
      "id_str" : "2425151",
      "id" : 2425151
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/deepa_k\/status\/185845551802232833\/photo\/1",
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/XhojGcrP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ApRBi3KCMAAYXe3.png",
      "id_str" : "185845551806427136",
      "id" : 185845551806427136,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ApRBi3KCMAAYXe3.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 203,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 358,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 506,
        "resize" : "fit",
        "w" : 848
      }, {
        "h" : 506,
        "resize" : "fit",
        "w" : 848
      } ],
      "display_url" : "pic.twitter.com\/XhojGcrP"
    } ],
    "hashtags" : [ {
      "text" : "whitehousefb",
      "indices" : [ 88, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "185845949996867584",
  "text" : "RT @deepa_k: love the @whitehouse @facebook timeline -- check out the website in 1994!  #whitehousefb http:\/\/t.co\/XhojGcrP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 9, 20 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "Facebook",
        "screen_name" : "facebook",
        "indices" : [ 21, 30 ],
        "id_str" : "2425151",
        "id" : 2425151
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/deepa_k\/status\/185845551802232833\/photo\/1",
        "indices" : [ 89, 109 ],
        "url" : "http:\/\/t.co\/XhojGcrP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ApRBi3KCMAAYXe3.png",
        "id_str" : "185845551806427136",
        "id" : 185845551806427136,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ApRBi3KCMAAYXe3.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 203,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 358,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 506,
          "resize" : "fit",
          "w" : 848
        }, {
          "h" : 506,
          "resize" : "fit",
          "w" : 848
        } ],
        "display_url" : "pic.twitter.com\/XhojGcrP"
      } ],
      "hashtags" : [ {
        "text" : "whitehousefb",
        "indices" : [ 75, 88 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "185845551802232833",
    "text" : "love the @whitehouse @facebook timeline -- check out the website in 1994!  #whitehousefb http:\/\/t.co\/XhojGcrP",
    "id" : 185845551802232833,
    "created_at" : "2012-03-30 21:46:48 +0000",
    "user" : {
      "name" : "Deepa",
      "screen_name" : "deepa_k",
      "protected" : false,
      "id_str" : "24363945",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/514101527363846144\/tKc0PQEe_normal.jpeg",
      "id" : 24363945,
      "verified" : false
    }
  },
  "id" : 185845949996867584,
  "created_at" : "2012-03-30 21:48:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 3, 11 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    }, {
      "name" : "Facebook",
      "screen_name" : "facebook",
      "indices" : [ 21, 30 ],
      "id_str" : "2425151",
      "id" : 2425151
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/macon44\/status\/185843636251000834\/photo\/1",
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/gHCijZYH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ApQ_zXLCAAAghiy.png",
      "id_str" : "185843636255195136",
      "id" : 185843636255195136,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ApQ_zXLCAAAghiy.png",
      "sizes" : [ {
        "h" : 396,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 603,
        "resize" : "fit",
        "w" : 913
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 603,
        "resize" : "fit",
        "w" : 913
      } ],
      "display_url" : "pic.twitter.com\/gHCijZYH"
    } ],
    "hashtags" : [ {
      "text" : "WhiteHouseFB",
      "indices" : [ 91, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "185844551787884545",
  "text" : "RT @macon44: Our new @facebook timeline pulls photos of 2 moments together to create a 3rd #WhiteHouseFB http:\/\/t.co\/gHCijZYH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Facebook",
        "screen_name" : "facebook",
        "indices" : [ 8, 17 ],
        "id_str" : "2425151",
        "id" : 2425151
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/macon44\/status\/185843636251000834\/photo\/1",
        "indices" : [ 92, 112 ],
        "url" : "http:\/\/t.co\/gHCijZYH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/ApQ_zXLCAAAghiy.png",
        "id_str" : "185843636255195136",
        "id" : 185843636255195136,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ApQ_zXLCAAAghiy.png",
        "sizes" : [ {
          "h" : 396,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 603,
          "resize" : "fit",
          "w" : 913
        }, {
          "h" : 225,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 603,
          "resize" : "fit",
          "w" : 913
        } ],
        "display_url" : "pic.twitter.com\/gHCijZYH"
      } ],
      "hashtags" : [ {
        "text" : "WhiteHouseFB",
        "indices" : [ 78, 91 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "185843636251000834",
    "text" : "Our new @facebook timeline pulls photos of 2 moments together to create a 3rd #WhiteHouseFB http:\/\/t.co\/gHCijZYH",
    "id" : 185843636251000834,
    "created_at" : "2012-03-30 21:39:11 +0000",
    "user" : {
      "name" : "Macon Phillips",
      "screen_name" : "IIPCoordinator",
      "protected" : false,
      "id_str" : "110823581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000495374915\/f6a5ae048ab7f8f12c0386114df53203_normal.jpeg",
      "id" : 110823581,
      "verified" : true
    }
  },
  "id" : 185844551787884545,
  "created_at" : "2012-03-30 21:42:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 12, 23 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "Facebook",
      "screen_name" : "facebook",
      "indices" : [ 24, 33 ],
      "id_str" : "2425151",
      "id" : 2425151
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whitehousefb",
      "indices" : [ 119, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 100 ],
      "url" : "https:\/\/t.co\/cAVegnpT",
      "expanded_url" : "https:\/\/facebook.com\/WhiteHouse",
      "display_url" : "facebook.com\/WhiteHouse"
    } ]
  },
  "geo" : { },
  "id_str" : "185842912460943360",
  "text" : "Introducing @Whitehouse @Facebook timeline! It highlights our 200+ yr history: https:\/\/t.co\/cAVegnpT Share feedback w\/ #whitehousefb",
  "id" : 185842912460943360,
  "created_at" : "2012-03-30 21:36:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Tumblr",
      "indices" : [ 39, 46 ]
    }, {
      "text" : "California",
      "indices" : [ 52, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/1Q6yv6O9",
      "expanded_url" : "http:\/\/on.doi.gov\/zLGeEp",
      "display_url" : "on.doi.gov\/zLGeEp"
    } ]
  },
  "geo" : { },
  "id_str" : "185806730364596224",
  "text" : "RT @Interior: Another great photo from #Tumblr. The #California Coastal National Monument at sunset: http:\/\/t.co\/1Q6yv6O9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Tumblr",
        "indices" : [ 25, 32 ]
      }, {
        "text" : "California",
        "indices" : [ 38, 49 ]
      } ],
      "urls" : [ {
        "indices" : [ 87, 107 ],
        "url" : "http:\/\/t.co\/1Q6yv6O9",
        "expanded_url" : "http:\/\/on.doi.gov\/zLGeEp",
        "display_url" : "on.doi.gov\/zLGeEp"
      } ]
    },
    "geo" : { },
    "id_str" : "185798335695831042",
    "text" : "Another great photo from #Tumblr. The #California Coastal National Monument at sunset: http:\/\/t.co\/1Q6yv6O9",
    "id" : 185798335695831042,
    "created_at" : "2012-03-30 18:39:09 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 185806730364596224,
  "created_at" : "2012-03-30 19:12:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 7, 16 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "MSt",
      "screen_name" : "zyng",
      "indices" : [ 122, 127 ],
      "id_str" : "21657975",
      "id" : 21657975
    }, {
      "name" : "\u0412\u0430\u043B\u0435\u043D\u0442\u0438\u043D\u0430 Jones",
      "screen_name" : "jonese13",
      "indices" : [ 128, 137 ],
      "id_str" : "2616097280",
      "id" : 2616097280
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BigOil",
      "indices" : [ 36, 43 ]
    }, {
      "text" : "Iran",
      "indices" : [ 72, 77 ]
    }, {
      "text" : "1q",
      "indices" : [ 92, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/YupflbIf",
      "expanded_url" : "http:\/\/youtu.be\/Bjtq36zA6Is",
      "display_url" : "youtu.be\/Bjtq36zA6Is"
    } ]
  },
  "geo" : { },
  "id_str" : "185746445603844096",
  "text" : "Watch: @PressSec answers your ?s on #BigOil subsidies, foreign policy & #Iran in the latest #1q: http:\/\/t.co\/YupflbIf cc: @zyng @JonesE13",
  "id" : 185746445603844096,
  "created_at" : "2012-03-30 15:12:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/Y8gPUxp0",
      "expanded_url" : "http:\/\/youtu.be\/dpi1LGEwlUs",
      "display_url" : "youtu.be\/dpi1LGEwlUs"
    } ]
  },
  "geo" : { },
  "id_str" : "185587302628720640",
  "text" : "Check out West Wing Week, your guide to everything that's happening @ 1600 Pennsylvania Ave: http:\/\/t.co\/Y8gPUxp0",
  "id" : 185587302628720640,
  "created_at" : "2012-03-30 04:40:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Education",
      "screen_name" : "usedgov",
      "indices" : [ 3, 11 ],
      "id_str" : "20437286",
      "id" : 20437286
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AskVP",
      "indices" : [ 43, 49 ]
    }, {
      "text" : "CollegeAffordability",
      "indices" : [ 77, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/D252fmh2",
      "expanded_url" : "http:\/\/go.usa.gov\/Ez6",
      "display_url" : "go.usa.gov\/Ez6"
    } ]
  },
  "geo" : { },
  "id_str" : "185440507969810433",
  "text" : "RT @usedgov: Now isn't the time to be shy. #AskVP Biden your questions about #CollegeAffordability http:\/\/t.co\/D252fmh2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AskVP",
        "indices" : [ 30, 36 ]
      }, {
        "text" : "CollegeAffordability",
        "indices" : [ 64, 85 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 106 ],
        "url" : "http:\/\/t.co\/D252fmh2",
        "expanded_url" : "http:\/\/go.usa.gov\/Ez6",
        "display_url" : "go.usa.gov\/Ez6"
      } ]
    },
    "geo" : { },
    "id_str" : "185437155991105536",
    "text" : "Now isn't the time to be shy. #AskVP Biden your questions about #CollegeAffordability http:\/\/t.co\/D252fmh2",
    "id" : 185437155991105536,
    "created_at" : "2012-03-29 18:43:57 +0000",
    "user" : {
      "name" : "US Dept of Education",
      "screen_name" : "usedgov",
      "protected" : false,
      "id_str" : "20437286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749204008108261377\/93-TTeZl_normal.jpg",
      "id" : 20437286,
      "verified" : true
    }
  },
  "id" : 185440507969810433,
  "created_at" : "2012-03-29 18:57:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AskVP",
      "indices" : [ 19, 25 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/RSl1gZz5",
      "expanded_url" : "http:\/\/www.wh.gov\/askvp",
      "display_url" : "wh.gov\/askvp"
    } ]
  },
  "geo" : { },
  "id_str" : "185427801200013313",
  "text" : "RT @VP: Announcing #AskVP: What are your questions about college affordability? VP Biden will answer on twitter on 4\/3: http:\/\/t.co\/RSl1gZz5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AskVP",
        "indices" : [ 11, 17 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 132 ],
        "url" : "http:\/\/t.co\/RSl1gZz5",
        "expanded_url" : "http:\/\/www.wh.gov\/askvp",
        "display_url" : "wh.gov\/askvp"
      } ]
    },
    "geo" : { },
    "id_str" : "185426028150272000",
    "text" : "Announcing #AskVP: What are your questions about college affordability? VP Biden will answer on twitter on 4\/3: http:\/\/t.co\/RSl1gZz5",
    "id" : 185426028150272000,
    "created_at" : "2012-03-29 17:59:44 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 185427801200013313,
  "created_at" : "2012-03-29 18:06:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Carson",
      "screen_name" : "JonCarson44",
      "indices" : [ 3, 15 ],
      "id_str" : "1287388789",
      "id" : 1287388789
    }, {
      "name" : "America Ferrera",
      "screen_name" : "AmericaFerrera",
      "indices" : [ 35, 50 ],
      "id_str" : "531561605",
      "id" : 531561605
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 52, 63 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChamps",
      "indices" : [ 104, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "185421599166570497",
  "text" : "RT @JonCarson44: Starting now with @AmericaFerrera! @whitehouse honors Cesar Chavez Champions of Change #WHChamps Watch live: http:\/\/t.c ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "America Ferrera",
        "screen_name" : "AmericaFerrera",
        "indices" : [ 18, 33 ],
        "id_str" : "531561605",
        "id" : 531561605
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 35, 46 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChamps",
        "indices" : [ 87, 96 ]
      } ],
      "urls" : [ {
        "indices" : [ 109, 129 ],
        "url" : "http:\/\/t.co\/2n0s3Mxz",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "185421121351454720",
    "text" : "Starting now with @AmericaFerrera! @whitehouse honors Cesar Chavez Champions of Change #WHChamps Watch live: http:\/\/t.co\/2n0s3Mxz",
    "id" : 185421121351454720,
    "created_at" : "2012-03-29 17:40:14 +0000",
    "user" : {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "protected" : false,
      "id_str" : "369232105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623146355767140352\/58sqoVrw_normal.jpg",
      "id" : 369232105,
      "verified" : true
    }
  },
  "id" : 185421599166570497,
  "created_at" : "2012-03-29 17:42:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/185417028935491584\/photo\/1",
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/9vz2wL4u",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ApK7zjFCIAAziDh.jpg",
      "id_str" : "185417028939685888",
      "id" : 185417028939685888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ApK7zjFCIAAziDh.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      } ],
      "display_url" : "pic.twitter.com\/9vz2wL4u"
    } ],
    "hashtags" : [ {
      "text" : "BigOil",
      "indices" : [ 34, 41 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/VmLOmpaH",
      "expanded_url" : "http:\/\/wh.gov\/n8D",
      "display_url" : "wh.gov\/n8D"
    } ]
  },
  "geo" : { },
  "id_str" : "185417028935491584",
  "text" : "It's time to repeal subsidies for #BigOil companies: http:\/\/t.co\/VmLOmpaH RT if you agree. http:\/\/t.co\/9vz2wL4u",
  "id" : 185417028935491584,
  "created_at" : "2012-03-29 17:23:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "indices" : [ 3, 16 ],
      "id_str" : "78138151",
      "id" : 78138151
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 55, 66 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChamps",
      "indices" : [ 111, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "185399439307980800",
  "text" : "RT @lacasablanca: Watch live today @ 1:30pm EST as the @whitehouse honors our Cesar Chavez Champions of Change #WHChamps http:\/\/t.co\/KeN ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 37, 48 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChamps",
        "indices" : [ 93, 102 ]
      } ],
      "urls" : [ {
        "indices" : [ 103, 123 ],
        "url" : "http:\/\/t.co\/KeNLKAIZ",
        "expanded_url" : "http:\/\/ow.ly\/9XmXi",
        "display_url" : "ow.ly\/9XmXi"
      } ]
    },
    "geo" : { },
    "id_str" : "185389540645679104",
    "text" : "Watch live today @ 1:30pm EST as the @whitehouse honors our Cesar Chavez Champions of Change #WHChamps http:\/\/t.co\/KeNLKAIZ",
    "id" : 185389540645679104,
    "created_at" : "2012-03-29 15:34:45 +0000",
    "user" : {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "protected" : false,
      "id_str" : "78138151",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616360382911754241\/4Tfqcfie_normal.png",
      "id" : 78138151,
      "verified" : true
    }
  },
  "id" : 185399439307980800,
  "created_at" : "2012-03-29 16:14:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim O'Reilly",
      "screen_name" : "timoreilly",
      "indices" : [ 3, 14 ],
      "id_str" : "2384071",
      "id" : 2384071
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/3MDqLmF0",
      "expanded_url" : "http:\/\/nyti.ms\/H3xeRV",
      "display_url" : "nyti.ms\/H3xeRV"
    } ]
  },
  "geo" : { },
  "id_str" : "185391344976539648",
  "text" : "RT @timoreilly: Glad the White House is paying attention to the data revolution http:\/\/t.co\/3MDqLmF0 Gov is a platform, data is 21st cen ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 84 ],
        "url" : "http:\/\/t.co\/3MDqLmF0",
        "expanded_url" : "http:\/\/nyti.ms\/H3xeRV",
        "display_url" : "nyti.ms\/H3xeRV"
      } ]
    },
    "geo" : { },
    "id_str" : "185390120214601728",
    "text" : "Glad the White House is paying attention to the data revolution http:\/\/t.co\/3MDqLmF0 Gov is a platform, data is 21st century imperative",
    "id" : 185390120214601728,
    "created_at" : "2012-03-29 15:37:03 +0000",
    "user" : {
      "name" : "Tim O'Reilly",
      "screen_name" : "timoreilly",
      "protected" : false,
      "id_str" : "2384071",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2823681988\/f4f6f2bed8ab4d5a48dea4b9ea85d5f1_normal.jpeg",
      "id" : 2384071,
      "verified" : true
    }
  },
  "id" : 185391344976539648,
  "created_at" : "2012-03-29 15:41:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "185381044059504640",
  "text" : "RT @jesseclee44: Obama speaks on today's Senate vote on ending big oil subsidies. Amazingly, this is controversial. Watch: http:\/\/t.co\/x ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 126 ],
        "url" : "http:\/\/t.co\/xFp7wlgY",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "185380430697074689",
    "text" : "Obama speaks on today's Senate vote on ending big oil subsidies. Amazingly, this is controversial. Watch: http:\/\/t.co\/xFp7wlgY",
    "id" : 185380430697074689,
    "created_at" : "2012-03-29 14:58:33 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 185381044059504640,
  "created_at" : "2012-03-29 15:00:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "America Ferrera",
      "screen_name" : "AmericaFerrera",
      "indices" : [ 3, 18 ],
      "id_str" : "531561605",
      "id" : 531561605
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "185372069737938944",
  "text" : "RT @AmericaFerrera: I'm White House bound to MC an event celebrating Cesar Chavez' legacy on his 85th birthday! Watch Live 1:30 EDT http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.whosay.com\" rel=\"nofollow\"\u003EWhoSay\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 132 ],
        "url" : "http:\/\/t.co\/mZK1wys1",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
        "display_url" : "whitehouse.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "185343153316958208",
    "text" : "I'm White House bound to MC an event celebrating Cesar Chavez' legacy on his 85th birthday! Watch Live 1:30 EDT http:\/\/t.co\/mZK1wys1",
    "id" : 185343153316958208,
    "created_at" : "2012-03-29 12:30:25 +0000",
    "user" : {
      "name" : "America Ferrera",
      "screen_name" : "AmericaFerrera",
      "protected" : false,
      "id_str" : "531561605",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/795764312962805760\/LRZ3K04w_normal.jpg",
      "id" : 531561605,
      "verified" : true
    }
  },
  "id" : 185372069737938944,
  "created_at" : "2012-03-29 14:25:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "oil",
      "indices" : [ 77, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "185371961680084992",
  "text" : "Happening @ 10:45ET: President Obama speaks on Congressional vote concerning #oil companies. Watch live: http:\/\/t.co\/u95y7hhB",
  "id" : 185371961680084992,
  "created_at" : "2012-03-29 14:24:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1q",
      "indices" : [ 69, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "185355854378319872",
  "text" : "RT @PressSec: First Question is back today. Ask your questions using #1q and I'll answer some before today\u2019s briefing.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "1q",
        "indices" : [ 55, 58 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "185349788433264640",
    "text" : "First Question is back today. Ask your questions using #1q and I'll answer some before today\u2019s briefing.",
    "id" : 185349788433264640,
    "created_at" : "2012-03-29 12:56:47 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 185355854378319872,
  "created_at" : "2012-03-29 13:20:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BigOil",
      "indices" : [ 49, 56 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/7JqzQLtM",
      "expanded_url" : "http:\/\/1.usa.gov\/H1V98P",
      "display_url" : "1.usa.gov\/H1V98P"
    } ]
  },
  "geo" : { },
  "id_str" : "185187319823863808",
  "text" : "$200M in profits\/day & taxpayers still subsidize #BigOil. Tmrw, Congress may act: http:\/\/t.co\/7JqzQLtM RT if you agree big oil makes enough",
  "id" : 185187319823863808,
  "created_at" : "2012-03-29 02:11:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Carson",
      "screen_name" : "JonCarson44",
      "indices" : [ 3, 15 ],
      "id_str" : "1287388789",
      "id" : 1287388789
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 17, 28 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChamps",
      "indices" : [ 67, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "185045721056165888",
  "text" : "RT @JonCarson44: @WhiteHouse will honor 10 leaders as Cesar Chavez #WHChamps 2morrow @ 1:30PM Find out how you can watch & engage online ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChamps",
        "indices" : [ 50, 59 ]
      } ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/SlU3OZsj",
        "expanded_url" : "http:\/\/1.usa.gov\/HeY6Pi",
        "display_url" : "1.usa.gov\/HeY6Pi"
      } ]
    },
    "geo" : { },
    "id_str" : "185043712483659776",
    "in_reply_to_user_id" : 30313925,
    "text" : "@WhiteHouse will honor 10 leaders as Cesar Chavez #WHChamps 2morrow @ 1:30PM Find out how you can watch & engage online http:\/\/t.co\/SlU3OZsj",
    "id" : 185043712483659776,
    "created_at" : "2012-03-28 16:40:33 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "protected" : false,
      "id_str" : "369232105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623146355767140352\/58sqoVrw_normal.jpg",
      "id" : 369232105,
      "verified" : true
    }
  },
  "id" : 185045721056165888,
  "created_at" : "2012-03-28 16:48:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/184808073993527297\/photo\/1",
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/PUZROVgn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/ApCR9tJCIAAhVx0.jpg",
      "id_str" : "184808073997721600",
      "id" : 184808073997721600,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/ApCR9tJCIAAhVx0.jpg",
      "sizes" : [ {
        "h" : 928,
        "resize" : "fit",
        "w" : 1392
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/PUZROVgn"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http:\/\/t.co\/TmO0p4xm",
      "expanded_url" : "http:\/\/wh.gov\/n2C",
      "display_url" : "wh.gov\/n2C"
    } ]
  },
  "geo" : { },
  "id_str" : "184808073993527297",
  "text" : "New slideshow: President Obama travels to Seoul, South Korea: http:\/\/t.co\/TmO0p4xm Pic: Obama views the DMZ: http:\/\/t.co\/PUZROVgn",
  "id" : 184808073993527297,
  "created_at" : "2012-03-28 01:04:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/bcmCI8gz",
      "expanded_url" : "http:\/\/1.usa.gov\/H9Bhmj",
      "display_url" : "1.usa.gov\/H9Bhmj"
    } ]
  },
  "geo" : { },
  "id_str" : "184802578058592257",
  "text" : "RT @petesouza: Slide show of the President's trip to South Korea: http:\/\/t.co\/bcmCI8gz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 51, 71 ],
        "url" : "http:\/\/t.co\/bcmCI8gz",
        "expanded_url" : "http:\/\/1.usa.gov\/H9Bhmj",
        "display_url" : "1.usa.gov\/H9Bhmj"
      } ]
    },
    "geo" : { },
    "id_str" : "184802426765848576",
    "text" : "Slide show of the President's trip to South Korea: http:\/\/t.co\/bcmCI8gz",
    "id" : 184802426765848576,
    "created_at" : "2012-03-28 00:41:46 +0000",
    "user" : {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "protected" : false,
      "id_str" : "18215973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771916869808844800\/7d_poH48_normal.jpg",
      "id" : 18215973,
      "verified" : true
    }
  },
  "id" : 184802578058592257,
  "created_at" : "2012-03-28 00:42:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kate Hoit",
      "screen_name" : "KateHoit",
      "indices" : [ 3, 12 ],
      "id_str" : "15575800",
      "id" : 15575800
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "184683931143118848",
  "text" : "RT @KateHoit: Great quotes & photos from VA's women leaders: Behind the Change: Portraits of Women Leading VA\u2019s Transformation http:\/\/t. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 133 ],
        "url" : "http:\/\/t.co\/XEZ0EegY",
        "expanded_url" : "http:\/\/www.blogs.va.gov\/VAntage\/6227\/behind-the-change-portraits-of-women-leading-va%E2%80%99s-transformation\/",
        "display_url" : "blogs.va.gov\/VAntage\/6227\/b\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "184672113980997634",
    "text" : "Great quotes & photos from VA's women leaders: Behind the Change: Portraits of Women Leading VA\u2019s Transformation http:\/\/t.co\/XEZ0EegY",
    "id" : 184672113980997634,
    "created_at" : "2012-03-27 16:03:57 +0000",
    "user" : {
      "name" : "Kate Hoit",
      "screen_name" : "KateHoit",
      "protected" : false,
      "id_str" : "15575800",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/743145496664018948\/C9GugN0m_normal.jpg",
      "id" : 15575800,
      "verified" : false
    }
  },
  "id" : 184683931143118848,
  "created_at" : "2012-03-27 16:50:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    }, {
      "name" : "Kate Sheppard",
      "screen_name" : "kate_sheppard",
      "indices" : [ 25, 39 ],
      "id_str" : "15458181",
      "id" : 15458181
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hcr",
      "indices" : [ 17, 21 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/NdAPmiKZ",
      "expanded_url" : "http:\/\/bit.ly\/GUaAPk",
      "display_url" : "bit.ly\/GUaAPk"
    } ]
  },
  "geo" : { },
  "id_str" : "184638732283019264",
  "text" : "RT @jesseclee44: #hcr RT @kate_sheppard: Chart of the Day: The Affordable Care Act and Women http:\/\/t.co\/NdAPmiKZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kate Sheppard",
        "screen_name" : "kate_sheppard",
        "indices" : [ 8, 22 ],
        "id_str" : "15458181",
        "id" : 15458181
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "hcr",
        "indices" : [ 0, 4 ]
      } ],
      "urls" : [ {
        "indices" : [ 76, 96 ],
        "url" : "http:\/\/t.co\/NdAPmiKZ",
        "expanded_url" : "http:\/\/bit.ly\/GUaAPk",
        "display_url" : "bit.ly\/GUaAPk"
      } ]
    },
    "geo" : { },
    "id_str" : "184637065890238465",
    "text" : "#hcr RT @kate_sheppard: Chart of the Day: The Affordable Care Act and Women http:\/\/t.co\/NdAPmiKZ",
    "id" : 184637065890238465,
    "created_at" : "2012-03-27 13:44:41 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 184638732283019264,
  "created_at" : "2012-03-27 13:51:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    }, {
      "name" : "Judy Woodruff",
      "screen_name" : "JudyWoodruff",
      "indices" : [ 21, 34 ],
      "id_str" : "48144950",
      "id" : 48144950
    }, {
      "name" : "AtlanticLIVE",
      "screen_name" : "Atlantic_LIVE",
      "indices" : [ 44, 58 ],
      "id_str" : "117445602",
      "id" : 117445602
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FutureEd",
      "indices" : [ 111, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "184633214156013573",
  "text" : "RT @arneduncan: Join @JudyWoodruff & me for @Atlantic_LIVE's ed & the economy digital town hall at 9am ET. Use #FutureEd & watch here: h ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Judy Woodruff",
        "screen_name" : "JudyWoodruff",
        "indices" : [ 5, 18 ],
        "id_str" : "48144950",
        "id" : 48144950
      }, {
        "name" : "AtlanticLIVE",
        "screen_name" : "Atlantic_LIVE",
        "indices" : [ 28, 42 ],
        "id_str" : "117445602",
        "id" : 117445602
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FutureEd",
        "indices" : [ 95, 104 ]
      } ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/QMhOztuQ",
        "expanded_url" : "http:\/\/bit.ly\/H7QjsC",
        "display_url" : "bit.ly\/H7QjsC"
      } ]
    },
    "geo" : { },
    "id_str" : "184607368426950657",
    "text" : "Join @JudyWoodruff & me for @Atlantic_LIVE's ed & the economy digital town hall at 9am ET. Use #FutureEd & watch here: http:\/\/t.co\/QMhOztuQ",
    "id" : 184607368426950657,
    "created_at" : "2012-03-27 11:46:41 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 184633214156013573,
  "created_at" : "2012-03-27 13:29:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/pfeiffer44\/status\/184452104621002753\/photo\/1",
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/QUsR7lV4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ao9ONj5CEAAaHJ3.jpg",
      "id_str" : "184452104625197056",
      "id" : 184452104625197056,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ao9ONj5CEAAaHJ3.jpg",
      "sizes" : [ {
        "h" : 455,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1296,
        "resize" : "fit",
        "w" : 968
      }, {
        "h" : 1296,
        "resize" : "fit",
        "w" : 968
      }, {
        "h" : 803,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/QUsR7lV4"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "184458008313602048",
  "text" : "RT @pfeiffer44: Here is a photo of POTUS at the DMZ between North and South Korea on Sunday http:\/\/t.co\/QUsR7lV4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EPhotos on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/pfeiffer44\/status\/184452104621002753\/photo\/1",
        "indices" : [ 76, 96 ],
        "url" : "http:\/\/t.co\/QUsR7lV4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ao9ONj5CEAAaHJ3.jpg",
        "id_str" : "184452104625197056",
        "id" : 184452104625197056,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ao9ONj5CEAAaHJ3.jpg",
        "sizes" : [ {
          "h" : 455,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1296,
          "resize" : "fit",
          "w" : 968
        }, {
          "h" : 1296,
          "resize" : "fit",
          "w" : 968
        }, {
          "h" : 803,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/QUsR7lV4"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "184452104621002753",
    "text" : "Here is a photo of POTUS at the DMZ between North and South Korea on Sunday http:\/\/t.co\/QUsR7lV4",
    "id" : 184452104621002753,
    "created_at" : "2012-03-27 01:29:44 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 184458008313602048,
  "created_at" : "2012-03-27 01:53:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/184366113289809920\/photo\/1",
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/IxAUmPa8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ao8AANPCMAArGWo.jpg",
      "id_str" : "184366113298198528",
      "id" : 184366113298198528,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ao8AANPCMAArGWo.jpg",
      "sizes" : [ {
        "h" : 674,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 224,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 884,
        "resize" : "fit",
        "w" : 1343
      }, {
        "h" : 395,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/IxAUmPa8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "184366113289809920",
  "text" : "Photo of the Day: President Obama views the DMZ from Observation Post Ouellette @ Camp Bonifas, Republic of Korea: http:\/\/t.co\/IxAUmPa8",
  "id" : 184366113289809920,
  "created_at" : "2012-03-26 19:48:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Military",
      "indices" : [ 19, 28 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/csELeUJ7",
      "expanded_url" : "http:\/\/www.defense.gov\/news\/newsarticle.aspx?id=67692",
      "display_url" : "defense.gov\/news\/newsartic\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "184360213011374080",
  "text" : "RT @VP: Dr. Biden: #Military Support Will Define Future Leaders: http:\/\/t.co\/csELeUJ7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Military",
        "indices" : [ 11, 20 ]
      } ],
      "urls" : [ {
        "indices" : [ 57, 77 ],
        "url" : "http:\/\/t.co\/csELeUJ7",
        "expanded_url" : "http:\/\/www.defense.gov\/news\/newsarticle.aspx?id=67692",
        "display_url" : "defense.gov\/news\/newsartic\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "184352628044595200",
    "text" : "Dr. Biden: #Military Support Will Define Future Leaders: http:\/\/t.co\/csELeUJ7",
    "id" : 184352628044595200,
    "created_at" : "2012-03-26 18:54:26 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 184360213011374080,
  "created_at" : "2012-03-26 19:24:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 3, 12 ],
      "id_str" : "36719281",
      "id" : 36719281
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "184344846511783936",
  "text" : "RT @letsmove: \"It's an important way to have a conversation about your health\" -First Lady to kids @ WH garden planting. Watch now: http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/Do631pPw",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "184344770691338240",
    "text" : "\"It's an important way to have a conversation about your health\" -First Lady to kids @ WH garden planting. Watch now: http:\/\/t.co\/Do631pPw",
    "id" : 184344770691338240,
    "created_at" : "2012-03-26 18:23:12 +0000",
    "user" : {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "protected" : false,
      "id_str" : "36719281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207340336\/780fc13e31b6fdd80bd57d000dc13838_normal.jpeg",
      "id" : 36719281,
      "verified" : true
    }
  },
  "id" : 184344846511783936,
  "created_at" : "2012-03-26 18:23:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "letsmove",
      "indices" : [ 128, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "184344258357108736",
  "text" : "Happening now: The First Lady welcomes kids from across the country for the 4th WH garden planting. Watch: http:\/\/t.co\/u95y7hhB #letsmove",
  "id" : 184344258357108736,
  "created_at" : "2012-03-26 18:21:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/184341954929246209\/photo\/1",
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/355P8xY8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ao7qCAVCQAAtl6V.jpg",
      "id_str" : "184341954937634816",
      "id" : 184341954937634816,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ao7qCAVCQAAtl6V.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 396
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 396
      }, {
        "h" : 495,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 396
      } ],
      "display_url" : "pic.twitter.com\/355P8xY8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "184341954929246209",
  "text" : "\"I want this Congress to stop the giveaways to an oil industry that\u2019s never been more profitable\" -President Obama http:\/\/t.co\/355P8xY8",
  "id" : 184341954929246209,
  "created_at" : "2012-03-26 18:12:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 3, 13 ],
      "id_str" : "9624742",
      "id" : 9624742
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 117, 128 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Canada",
      "indices" : [ 21, 28 ]
    }, {
      "text" : "Mexico",
      "indices" : [ 33, 40 ]
    }, {
      "text" : "NSS2012",
      "indices" : [ 129, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/hfyuOEFJ",
      "expanded_url" : "http:\/\/go.usa.gov\/Eyy",
      "display_url" : "go.usa.gov\/Eyy"
    } ]
  },
  "geo" : { },
  "id_str" : "184339309367795713",
  "text" : "RT @StateDept: U.S., #Canada and #Mexico issue trilateral announcement on nuclear security: http:\/\/t.co\/hfyuOEFJ via @WhiteHouse #NSS2012",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 102, 113 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Canada",
        "indices" : [ 6, 13 ]
      }, {
        "text" : "Mexico",
        "indices" : [ 18, 25 ]
      }, {
        "text" : "NSS2012",
        "indices" : [ 114, 122 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 97 ],
        "url" : "http:\/\/t.co\/hfyuOEFJ",
        "expanded_url" : "http:\/\/go.usa.gov\/Eyy",
        "display_url" : "go.usa.gov\/Eyy"
      } ]
    },
    "geo" : { },
    "id_str" : "184335608448159747",
    "text" : "U.S., #Canada and #Mexico issue trilateral announcement on nuclear security: http:\/\/t.co\/hfyuOEFJ via @WhiteHouse #NSS2012",
    "id" : 184335608448159747,
    "created_at" : "2012-03-26 17:46:48 +0000",
    "user" : {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "protected" : false,
      "id_str" : "9624742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724612605185282048\/1rEfkXDZ_normal.jpg",
      "id" : 9624742,
      "verified" : true
    }
  },
  "id" : 184339309367795713,
  "created_at" : "2012-03-26 18:01:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Katz",
      "screen_name" : "ESPNAndyKatz",
      "indices" : [ 84, 97 ],
      "id_str" : "85961526",
      "id" : 85961526
    }, {
      "name" : "ESPN",
      "screen_name" : "espn",
      "indices" : [ 115, 120 ],
      "id_str" : "2557521",
      "id" : 2557521
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 142 ],
      "url" : "http:\/\/t.co\/R4fxdxda",
      "expanded_url" : "http:\/\/ow.ly\/9SUHb",
      "display_url" : "ow.ly\/9SUHb"
    } ]
  },
  "geo" : { },
  "id_str" : "184324219755167744",
  "text" : "President Obama discuss Title IX &amp; coaching his daughter\u2019s basketball team with @ESPNAndyKatz. Watch the video @ESPN: http:\/\/t.co\/R4fxdxda",
  "id" : 184324219755167744,
  "created_at" : "2012-03-26 17:01:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Embassy Seoul",
      "screen_name" : "USEmbassySeoul",
      "indices" : [ 1, 16 ],
      "id_str" : "61426538",
      "id" : 61426538
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/9BKz34tG",
      "expanded_url" : "http:\/\/ow.ly\/9SAvN",
      "display_url" : "ow.ly\/9SAvN"
    } ]
  },
  "geo" : { },
  "id_str" : "184280219413250050",
  "text" : ".@usembassyseoul asked South Koreans to submit ?s via social media for President Obama. Check out the Qs &amp; As: http:\/\/t.co\/9BKz34tG",
  "id" : 184280219413250050,
  "created_at" : "2012-03-26 14:06:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 3, 12 ],
      "id_str" : "36719281",
      "id" : 36719281
    }, {
      "name" : "WNBA",
      "screen_name" : "WNBA",
      "indices" : [ 74, 79 ],
      "id_str" : "17159397",
      "id" : 17159397
    }, {
      "name" : "Tamika Catchings",
      "screen_name" : "Catchin24",
      "indices" : [ 84, 94 ],
      "id_str" : "370435297",
      "id" : 370435297
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "184279042797744130",
  "text" : "RT @letsmove: What are your questions about staying healthy &amp; active? @WNBA MVP @Catchin24 is stopping by today to answer some ?s. A ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "WNBA",
        "screen_name" : "WNBA",
        "indices" : [ 60, 65 ],
        "id_str" : "17159397",
        "id" : 17159397
      }, {
        "name" : "Tamika Catchings",
        "screen_name" : "Catchin24",
        "indices" : [ 70, 80 ],
        "id_str" : "370435297",
        "id" : 370435297
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LetsMove",
        "indices" : [ 130, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "184269484964589569",
    "text" : "What are your questions about staying healthy &amp; active? @WNBA MVP @Catchin24 is stopping by today to answer some ?s. Ask with #LetsMove",
    "id" : 184269484964589569,
    "created_at" : "2012-03-26 13:24:03 +0000",
    "user" : {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "protected" : false,
      "id_str" : "36719281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207340336\/780fc13e31b6fdd80bd57d000dc13838_normal.jpeg",
      "id" : 36719281,
      "verified" : true
    }
  },
  "id" : 184279042797744130,
  "created_at" : "2012-03-26 14:02:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Carson",
      "screen_name" : "JonCarson44",
      "indices" : [ 3, 15 ],
      "id_str" : "1287388789",
      "id" : 1287388789
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 22, 33 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "U.S. EPA",
      "screen_name" : "EPAGov",
      "indices" : [ 40, 47 ],
      "id_str" : "1604108887",
      "id" : 1604108887
    }, {
      "name" : "Lisa P. Jackson",
      "screen_name" : "lisapjackson",
      "indices" : [ 50, 63 ],
      "id_str" : "1182675871",
      "id" : 1182675871
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "shegoesgreen",
      "indices" : [ 119, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "184267450752307200",
  "text" : "RT @JonCarson44: Join @whitehouse &amp; @EPAgov's @lisapjackson in a briefing focused on women &amp; env't today @ 9am #shegoesgreen Wat ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 5, 16 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "U.S. EPA",
        "screen_name" : "EPAGov",
        "indices" : [ 23, 30 ],
        "id_str" : "1604108887",
        "id" : 1604108887
      }, {
        "name" : "Lisa P. Jackson",
        "screen_name" : "lisapjackson",
        "indices" : [ 33, 46 ],
        "id_str" : "1182675871",
        "id" : 1182675871
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "shegoesgreen",
        "indices" : [ 102, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 128, 148 ],
        "url" : "http:\/\/t.co\/2n0s3Mxz",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "184252126715850754",
    "text" : "Join @whitehouse &amp; @EPAgov's @lisapjackson in a briefing focused on women &amp; env't today @ 9am #shegoesgreen Watch live: http:\/\/t.co\/2n0s3Mxz",
    "id" : 184252126715850754,
    "created_at" : "2012-03-26 12:15:04 +0000",
    "user" : {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "protected" : false,
      "id_str" : "369232105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623146355767140352\/58sqoVrw_normal.jpg",
      "id" : 369232105,
      "verified" : true
    }
  },
  "id" : 184267450752307200,
  "created_at" : "2012-03-26 13:15:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/gahwEC5c",
      "expanded_url" : "http:\/\/ow.ly\/9R8VB",
      "display_url" : "ow.ly\/9R8VB"
    } ]
  },
  "geo" : { },
  "id_str" : "183601264398057473",
  "text" : "In his weekly address, President Obama says House must pass bipartisan transportation bill. Watch: http:\/\/t.co\/gahwEC5c",
  "id" : 183601264398057473,
  "created_at" : "2012-03-24 17:08:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Storify",
      "screen_name" : "Storify",
      "indices" : [ 127, 135 ],
      "id_str" : "17814938",
      "id" : 17814938
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 76, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/rnCr8InV",
      "expanded_url" : "http:\/\/sfy.co\/jMC",
      "display_url" : "sfy.co\/jMC"
    } ]
  },
  "geo" : { },
  "id_str" : "183340670843498496",
  "text" : "RT @WHLive: Missed WH Office Hrs today? Check out the full Q&amp;A from our #WHChat on health reform: http:\/\/t.co\/rnCr8InV via @Storify",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Storify",
        "screen_name" : "Storify",
        "indices" : [ 115, 123 ],
        "id_str" : "17814938",
        "id" : 17814938
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 64, 71 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 110 ],
        "url" : "http:\/\/t.co\/rnCr8InV",
        "expanded_url" : "http:\/\/sfy.co\/jMC",
        "display_url" : "sfy.co\/jMC"
      } ]
    },
    "geo" : { },
    "id_str" : "183340586990972928",
    "text" : "Missed WH Office Hrs today? Check out the full Q&amp;A from our #WHChat on health reform: http:\/\/t.co\/rnCr8InV via @Storify",
    "id" : 183340586990972928,
    "created_at" : "2012-03-23 23:52:56 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 183340670843498496,
  "created_at" : "2012-03-23 23:53:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/storify.com\" rel=\"nofollow\"\u003EStorify\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Pedersen",
      "screen_name" : "jasonbpedersen",
      "indices" : [ 0, 15 ],
      "id_str" : "424415574",
      "id" : 424415574
    }, {
      "name" : "Storify",
      "screen_name" : "Storify",
      "indices" : [ 131, 139 ],
      "id_str" : "17814938",
      "id" : 17814938
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 80, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/Dlkuxdds",
      "expanded_url" : "http:\/\/sfy.co\/jMC",
      "display_url" : "sfy.co\/jMC"
    } ]
  },
  "geo" : { },
  "id_str" : "183340204042620928",
  "in_reply_to_user_id" : 424415574,
  "text" : "@jasonbpedersen Missed WH Office Hrs today? Check out the full Q&amp;A from our #WHChat on health reform: http:\/\/t.co\/Dlkuxdds via @Storify",
  "id" : 183340204042620928,
  "created_at" : "2012-03-23 23:51:25 +0000",
  "in_reply_to_screen_name" : "jasonbpedersen",
  "in_reply_to_user_id_str" : "424415574",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/storify.com\" rel=\"nofollow\"\u003EStorify\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Storify",
      "screen_name" : "Storify",
      "indices" : [ 130, 138 ],
      "id_str" : "17814938",
      "id" : 17814938
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 79, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/Dlkuxdds",
      "expanded_url" : "http:\/\/sfy.co\/jMC",
      "display_url" : "sfy.co\/jMC"
    } ]
  },
  "geo" : { },
  "id_str" : "183340204080381953",
  "in_reply_to_user_id" : 491952737,
  "text" : "@MatthewAaron_ Missed WH Office Hrs today? Check out the full Q&amp;A from our #WHChat on health reform: http:\/\/t.co\/Dlkuxdds via @Storify",
  "id" : 183340204080381953,
  "created_at" : "2012-03-23 23:51:25 +0000",
  "in_reply_to_screen_name" : "ApexDelicto",
  "in_reply_to_user_id_str" : "491952737",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/storify.com\" rel=\"nofollow\"\u003EStorify\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Countdown 2 Coverage",
      "screen_name" : "ourcountdown",
      "indices" : [ 0, 13 ],
      "id_str" : "491396568",
      "id" : 491396568
    }, {
      "name" : "Storify",
      "screen_name" : "Storify",
      "indices" : [ 129, 137 ],
      "id_str" : "17814938",
      "id" : 17814938
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 78, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/Dlkuxdds",
      "expanded_url" : "http:\/\/sfy.co\/jMC",
      "display_url" : "sfy.co\/jMC"
    } ]
  },
  "geo" : { },
  "id_str" : "183340204592070656",
  "in_reply_to_user_id" : 491396568,
  "text" : "@ourcountdown Missed WH Office Hrs today? Check out the full Q&amp;A from our #WHChat on health reform: http:\/\/t.co\/Dlkuxdds via @Storify",
  "id" : 183340204592070656,
  "created_at" : "2012-03-23 23:51:25 +0000",
  "in_reply_to_screen_name" : "ourcountdown",
  "in_reply_to_user_id_str" : "491396568",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 3, 12 ],
      "id_str" : "36719281",
      "id" : 36719281
    }, {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 49, 58 ],
      "id_str" : "36719281",
      "id" : 36719281
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHTweetup",
      "indices" : [ 59, 69 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "183320792992464896",
  "text" : "RT @letsmove: We're excited to announce the next @LetsMove #WHTweetup: Apply for your chance to attend the 134th WH Easter Egg Roll: htt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Let's Move!",
        "screen_name" : "letsmove",
        "indices" : [ 35, 44 ],
        "id_str" : "36719281",
        "id" : 36719281
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHTweetup",
        "indices" : [ 45, 55 ]
      } ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/kzXOcbdt",
        "expanded_url" : "http:\/\/wh.gov\/tweetup",
        "display_url" : "wh.gov\/tweetup"
      } ]
    },
    "geo" : { },
    "id_str" : "183318491888234497",
    "text" : "We're excited to announce the next @LetsMove #WHTweetup: Apply for your chance to attend the 134th WH Easter Egg Roll: http:\/\/t.co\/kzXOcbdt",
    "id" : 183318491888234497,
    "created_at" : "2012-03-23 22:25:09 +0000",
    "user" : {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "protected" : false,
      "id_str" : "36719281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207340336\/780fc13e31b6fdd80bd57d000dc13838_normal.jpeg",
      "id" : 36719281,
      "verified" : true
    }
  },
  "id" : 183320792992464896,
  "created_at" : "2012-03-23 22:34:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Nowruz",
      "indices" : [ 85, 92 ]
    }, {
      "text" : "energy",
      "indices" : [ 109, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/lay07fuT",
      "expanded_url" : "http:\/\/youtu.be\/0XBFpWbtwzo",
      "display_url" : "youtu.be\/0XBFpWbtwzo"
    } ]
  },
  "geo" : { },
  "id_str" : "183290826296791040",
  "text" : "Check out the latest West Wing Week: The President celebrates St. Patty's Day, marks #Nowruz, talks American #energy: http:\/\/t.co\/lay07fuT",
  "id" : 183290826296791040,
  "created_at" : "2012-03-23 20:35:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Christine Stone",
      "screen_name" : "ChristineMStone",
      "indices" : [ 13, 29 ],
      "id_str" : "21965433",
      "id" : 21965433
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "183257826980921344",
  "text" : "RT @WHLive: .@ChristineMStone We made sure to balance providing preventive care incl contraception with religious liberty  http:\/\/t.co\/W ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Christine Stone",
        "screen_name" : "ChristineMStone",
        "indices" : [ 1, 17 ],
        "id_str" : "21965433",
        "id" : 21965433
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whchat",
        "indices" : [ 132, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 131 ],
        "url" : "http:\/\/t.co\/W3IQqDYV",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/the-press-office\/2012\/02\/10\/fact-sheet-women-s-preventive-services-and-religious-institutions",
        "display_url" : "whitehouse.gov\/the-press-offi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "183257779115524097",
    "text" : ".@ChristineMStone We made sure to balance providing preventive care incl contraception with religious liberty  http:\/\/t.co\/W3IQqDYV #whchat",
    "id" : 183257779115524097,
    "created_at" : "2012-03-23 18:23:53 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 183257826980921344,
  "created_at" : "2012-03-23 18:24:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christine Stone",
      "screen_name" : "ChristineMStone",
      "indices" : [ 3, 19 ],
      "id_str" : "21965433",
      "id" : 21965433
    }, {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 29, 36 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whchat",
      "indices" : [ 21, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "183257799705362432",
  "text" : "RT @ChristineMStone: #whchat @WHLive, I'm really concerned abt contraception access 4 all women, no matter where they work. TY for safeg ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "White House Live",
        "screen_name" : "WHLive",
        "indices" : [ 8, 15 ],
        "id_str" : "369505837",
        "id" : 369505837
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whchat",
        "indices" : [ 0, 7 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "183256926119923712",
    "text" : "#whchat @WHLive, I'm really concerned abt contraception access 4 all women, no matter where they work. TY for safeguarding women's health!",
    "id" : 183256926119923712,
    "created_at" : "2012-03-23 18:20:30 +0000",
    "user" : {
      "name" : "Christine Stone",
      "screen_name" : "ChristineMStone",
      "protected" : false,
      "id_str" : "21965433",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/773886167578243072\/tB9uJjJI_normal.jpg",
      "id" : 21965433,
      "verified" : false
    }
  },
  "id" : 183257799705362432,
  "created_at" : "2012-03-23 18:23:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Jason Pedersen",
      "screen_name" : "jasonbpedersen",
      "indices" : [ 13, 28 ],
      "id_str" : "424415574",
      "id" : 424415574
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 73, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "183254328709095424",
  "text" : "RT @WHLive: .@jasonbpedersen  health spending has reached historic lows, #ACA takes steps to hold health care costs down http:\/\/t.co\/GCn ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jason Pedersen",
        "screen_name" : "jasonbpedersen",
        "indices" : [ 1, 16 ],
        "id_str" : "424415574",
        "id" : 424415574
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ACA",
        "indices" : [ 61, 65 ]
      }, {
        "text" : "whchat",
        "indices" : [ 130, 137 ]
      } ],
      "urls" : [ {
        "indices" : [ 109, 129 ],
        "url" : "http:\/\/t.co\/GCnDoDYw",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2012\/01\/09\/lowering-health-care-cost-growth-get-more-value-consumers",
        "display_url" : "whitehouse.gov\/blog\/2012\/01\/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "183253879750799360",
    "text" : ".@jasonbpedersen  health spending has reached historic lows, #ACA takes steps to hold health care costs down http:\/\/t.co\/GCnDoDYw #whchat",
    "id" : 183253879750799360,
    "created_at" : "2012-03-23 18:08:24 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 183254328709095424,
  "created_at" : "2012-03-23 18:10:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Pedersen",
      "screen_name" : "jasonbpedersen",
      "indices" : [ 3, 18 ],
      "id_str" : "424415574",
      "id" : 424415574
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 76, 87 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "183254309201383424",
  "text" : "RT @jasonbpedersen: Why haven't health care costs gone down with Obamacare? @whitehouse: Have Qs on what the health care law Ask now: #W ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 56, 67 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 114, 121 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "183231429134659584",
    "text" : "Why haven't health care costs gone down with Obamacare? @whitehouse: Have Qs on what the health care law Ask now: #WHChat",
    "id" : 183231429134659584,
    "created_at" : "2012-03-23 16:39:11 +0000",
    "user" : {
      "name" : "Jason Pedersen",
      "screen_name" : "jasonbpedersen",
      "protected" : false,
      "id_str" : "424415574",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1664632353\/jpedersen_normal.jpg",
      "id" : 424415574,
      "verified" : false
    }
  },
  "id" : 183254309201383424,
  "created_at" : "2012-03-23 18:10:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "183253615748710400",
  "text" : "RT @WHLive: Hi all - this is Cecilia Munoz, ready to answer your questions about the Affordable Care Act, which is 2 years old today! #w ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whchat",
        "indices" : [ 122, 129 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "183253107579420673",
    "text" : "Hi all - this is Cecilia Munoz, ready to answer your questions about the Affordable Care Act, which is 2 years old today! #whchat",
    "id" : 183253107579420673,
    "created_at" : "2012-03-23 18:05:20 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 183253615748710400,
  "created_at" : "2012-03-23 18:07:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/183249955446722561\/photo\/1",
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/XONNipb2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AosI3RRCEAAmLk8.jpg",
      "id_str" : "183249955459305472",
      "id" : 183249955459305472,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AosI3RRCEAAmLk8.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      } ],
      "display_url" : "pic.twitter.com\/XONNipb2"
    } ],
    "hashtags" : [ {
      "text" : "HCR",
      "indices" : [ 49, 53 ]
    } ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http:\/\/t.co\/7R8Vy1l8",
      "expanded_url" : "http:\/\/wh.gov\/RoR",
      "display_url" : "wh.gov\/RoR"
    } ]
  },
  "geo" : { },
  "id_str" : "183249955446722561",
  "text" : "By the Numbers: 100% http:\/\/t.co\/7R8Vy1l8 b\/c of #HCR insurers can't deny coverage to kids w\/ pre-existing conditions http:\/\/t.co\/XONNipb2",
  "id" : 183249955446722561,
  "created_at" : "2012-03-23 17:52:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 3, 11 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    }, {
      "name" : "Mashable",
      "screen_name" : "mashable",
      "indices" : [ 106, 115 ],
      "id_str" : "972651",
      "id" : 972651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/uXUeYL6U",
      "expanded_url" : "http:\/\/mashable.com\/2012\/03\/23\/white-house-listening-we-the-people\/",
      "display_url" : "mashable.com\/2012\/03\/23\/whi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "183247886874722304",
  "text" : "RT @macon44: White House on 'We the People' Petitions: 'We're Listening' [VIDEO] http:\/\/t.co\/uXUeYL6U via @mashable",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mashable",
        "screen_name" : "mashable",
        "indices" : [ 93, 102 ],
        "id_str" : "972651",
        "id" : 972651
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 88 ],
        "url" : "http:\/\/t.co\/uXUeYL6U",
        "expanded_url" : "http:\/\/mashable.com\/2012\/03\/23\/white-house-listening-we-the-people\/",
        "display_url" : "mashable.com\/2012\/03\/23\/whi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "183247205812011008",
    "text" : "White House on 'We the People' Petitions: 'We're Listening' [VIDEO] http:\/\/t.co\/uXUeYL6U via @mashable",
    "id" : 183247205812011008,
    "created_at" : "2012-03-23 17:41:53 +0000",
    "user" : {
      "name" : "Macon Phillips",
      "screen_name" : "IIPCoordinator",
      "protected" : false,
      "id_str" : "110823581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000495374915\/f6a5ae048ab7f8f12c0386114df53203_normal.jpeg",
      "id" : 110823581,
      "verified" : true
    }
  },
  "id" : 183247886874722304,
  "created_at" : "2012-03-23 17:44:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 83, 87 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 135, 142 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/6S4eIdXg",
      "expanded_url" : "http:\/\/wh.gov\/Rd6",
      "display_url" : "wh.gov\/Rd6"
    } ]
  },
  "geo" : { },
  "id_str" : "183227860499173378",
  "text" : "Have Qs on what the health care law means for you &amp; your family? We're holding #ACA Office Hrs @ 2ET http:\/\/t.co\/6S4eIdXg Ask now: #WHChat",
  "id" : 183227860499173378,
  "created_at" : "2012-03-23 16:25:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 18, 29 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 43, 53 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/wEw9HyZ2",
      "expanded_url" : "http:\/\/flic.kr\/s\/aHsjzdKF3c",
      "display_url" : "flic.kr\/s\/aHsjzdKF3c"
    } ]
  },
  "geo" : { },
  "id_str" : "183226981247229952",
  "text" : "New photos: Chief @whitehouse photographer @petesouza takes you behind-the-scenes in February: http:\/\/t.co\/wEw9HyZ2",
  "id" : 183226981247229952,
  "created_at" : "2012-03-23 16:21:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "indices" : [ 3, 18 ],
      "id_str" : "19674502",
      "id" : 19674502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "183223494706860033",
  "text" : "RT @AmbassadorRice: Dr. Kim is an outstanding choice to head the World Bank. A visionary who has already had a remarkable impact on glob ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "183211089616576513",
    "text" : "Dr. Kim is an outstanding choice to head the World Bank. A visionary who has already had a remarkable impact on global health &amp; development.",
    "id" : 183211089616576513,
    "created_at" : "2012-03-23 15:18:22 +0000",
    "user" : {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "protected" : false,
      "id_str" : "19674502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2245433940\/297681_10150417294436240_295915266239_10074516_1895344954_n_normal.jpg",
      "id" : 19674502,
      "verified" : true
    }
  },
  "id" : 183223494706860033,
  "created_at" : "2012-03-23 16:07:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "World Bank",
      "screen_name" : "WorldBank",
      "indices" : [ 98, 108 ],
      "id_str" : "27860681",
      "id" : 27860681
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/gj005wcB",
      "expanded_url" : "http:\/\/wh.gov\/RA6",
      "display_url" : "wh.gov\/RA6"
    } ]
  },
  "geo" : { },
  "id_str" : "183206164333473792",
  "text" : "Today President Obama announced that the US will nominate Dr. Jim Yong Kim to be President of the @worldbank http:\/\/t.co\/gj005wcB",
  "id" : 183206164333473792,
  "created_at" : "2012-03-23 14:58:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "183188951186673664",
  "text" : "Happening @ 10ET: President Obama makes a personnel announcement in the Rose Garden. Watch live: http:\/\/t.co\/u95y7hhB",
  "id" : 183188951186673664,
  "created_at" : "2012-03-23 13:50:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/182962572222398465\/photo\/1",
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/mIKMFylW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AooDfXUCAAAVhtj.jpg",
      "id_str" : "182962572230787072",
      "id" : 182962572230787072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AooDfXUCAAAVhtj.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/mIKMFylW"
    } ],
    "hashtags" : [ {
      "text" : "energy",
      "indices" : [ 49, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "182962572222398465",
  "text" : "Photo of the Day: President Obama talks American #energy @ the TransCanada Stillwater Pipe Yard in Cushing, Oklahoma: http:\/\/t.co\/mIKMFylW",
  "id" : 182962572222398465,
  "created_at" : "2012-03-22 22:50:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 124, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "182944373821030400",
  "text" : "RT @WHLive: Tomorrow @ 2ET: Domestic Policy Council Director Cecilia Mu\u00F1oz answers your ?s on the health care law. Ask now: #WHChat http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 112, 119 ]
      } ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/CDGxD4QZ",
        "expanded_url" : "http:\/\/ow.ly\/9P9NP",
        "display_url" : "ow.ly\/9P9NP"
      } ]
    },
    "geo" : { },
    "id_str" : "182944318145839105",
    "text" : "Tomorrow @ 2ET: Domestic Policy Council Director Cecilia Mu\u00F1oz answers your ?s on the health care law. Ask now: #WHChat http:\/\/t.co\/CDGxD4QZ",
    "id" : 182944318145839105,
    "created_at" : "2012-03-22 21:38:19 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 182944373821030400,
  "created_at" : "2012-03-22 21:38:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ohio State",
      "screen_name" : "OhioState",
      "indices" : [ 3, 13 ],
      "id_str" : "18846918",
      "id" : 18846918
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obama",
      "indices" : [ 50, 56 ]
    }, {
      "text" : "ObamaOSU",
      "indices" : [ 116, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "182934926885269504",
  "text" : "RT @OhioState: We\u2019re excited to welcome President #Obama to campus today! He\u2019s a Buckeye at heart\u2014here\u2019s the proof. #ObamaOSU http:\/\/t.c ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Obama",
        "indices" : [ 35, 41 ]
      }, {
        "text" : "ObamaOSU",
        "indices" : [ 101, 110 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 131 ],
        "url" : "http:\/\/t.co\/N8qKEv0y",
        "expanded_url" : "http:\/\/twitpic.com\/8zqyd4",
        "display_url" : "twitpic.com\/8zqyd4"
      } ]
    },
    "geo" : { },
    "id_str" : "182824965224153089",
    "text" : "We\u2019re excited to welcome President #Obama to campus today! He\u2019s a Buckeye at heart\u2014here\u2019s the proof. #ObamaOSU http:\/\/t.co\/N8qKEv0y",
    "id" : 182824965224153089,
    "created_at" : "2012-03-22 13:44:03 +0000",
    "user" : {
      "name" : "Ohio State",
      "screen_name" : "OhioState",
      "protected" : false,
      "id_str" : "18846918",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3433597373\/0a80bbe598692a73112d6df2ddca6fa9_normal.png",
      "id" : 18846918,
      "verified" : true
    }
  },
  "id" : 182934926885269504,
  "created_at" : "2012-03-22 21:00:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "oil",
      "indices" : [ 20, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "182931376201416704",
  "text" : "\"We have subsidized #oil companies for a century. That\u2019s long enough. It\u2019s time to end the taxpayer giveaways\" -President Obama",
  "id" : 182931376201416704,
  "created_at" : "2012-03-22 20:46:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamainOH",
      "indices" : [ 97, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "182930855801528320",
  "text" : "RT @WHLive: President Obama: See, America has always succeeded because we refuse to stand still. #ObamainOH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ObamainOH",
        "indices" : [ 85, 95 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "182930759592587265",
    "text" : "President Obama: See, America has always succeeded because we refuse to stand still. #ObamainOH",
    "id" : 182930759592587265,
    "created_at" : "2012-03-22 20:44:26 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 182930855801528320,
  "created_at" : "2012-03-22 20:44:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "energy",
      "indices" : [ 50, 57 ]
    }, {
      "text" : "ObamainOH",
      "indices" : [ 94, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "182929371839991809",
  "text" : "RT @WHLive: President Obama: I will not accept an #energy strategy that traps us in the past. #ObamainOH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "energy",
        "indices" : [ 38, 45 ]
      }, {
        "text" : "ObamainOH",
        "indices" : [ 82, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "182929304575950848",
    "text" : "President Obama: I will not accept an #energy strategy that traps us in the past. #ObamainOH",
    "id" : 182929304575950848,
    "created_at" : "2012-03-22 20:38:39 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 182929371839991809,
  "created_at" : "2012-03-22 20:38:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ohio State",
      "screen_name" : "OhioState",
      "indices" : [ 58, 68 ],
      "id_str" : "18846918",
      "id" : 18846918
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "energy",
      "indices" : [ 50, 57 ]
    }, {
      "text" : "ObamainOH",
      "indices" : [ 103, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "182927639307223040",
  "text" : "Happening now: President Obama speaks on American #energy @OhioState. Watch live: http:\/\/t.co\/u95y7hhB #ObamainOH",
  "id" : 182927639307223040,
  "created_at" : "2012-03-22 20:32:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russell Simmons",
      "screen_name" : "UncleRUSH",
      "indices" : [ 3, 13 ],
      "id_str" : "25110374",
      "id" : 25110374
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "biz",
      "indices" : [ 41, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "182912913131053056",
  "text" : "RT @UncleRUSH: Thinking about starting a #biz, but need some help? Watch the Urban Economic Forum now for resources: http:\/\/t.co\/bynwcD0 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "biz",
        "indices" : [ 26, 30 ]
      }, {
        "text" : "UrbanEconForum",
        "indices" : [ 123, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 102, 122 ],
        "url" : "http:\/\/t.co\/bynwcD0i",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
        "display_url" : "whitehouse.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "182885713572933632",
    "text" : "Thinking about starting a #biz, but need some help? Watch the Urban Economic Forum now for resources: http:\/\/t.co\/bynwcD0i #UrbanEconForum",
    "id" : 182885713572933632,
    "created_at" : "2012-03-22 17:45:26 +0000",
    "user" : {
      "name" : "Russell Simmons",
      "screen_name" : "UncleRUSH",
      "protected" : false,
      "id_str" : "25110374",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/748232081008959488\/0fWqh6-F_normal.jpg",
      "id" : 25110374,
      "verified" : true
    }
  },
  "id" : 182912913131053056,
  "created_at" : "2012-03-22 19:33:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "182912077722161152",
  "text" : "RT @whitehouseostp: \"Investments in science, medical research, space, and technology would be cut by more than $100B over the next decad ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/zKhjWClJ",
        "expanded_url" : "http:\/\/1.usa.gov\/GHKVw2",
        "display_url" : "1.usa.gov\/GHKVw2"
      } ]
    },
    "geo" : { },
    "id_str" : "182911722233925633",
    "text" : "\"Investments in science, medical research, space, and technology would be cut by more than $100B over the next decade.\" http:\/\/t.co\/zKhjWClJ",
    "id" : 182911722233925633,
    "created_at" : "2012-03-22 19:28:47 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 182912077722161152,
  "created_at" : "2012-03-22 19:30:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "consumerfinance.gov",
      "screen_name" : "CFPB",
      "indices" : [ 3, 8 ],
      "id_str" : "234826866",
      "id" : 234826866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "182905073867816961",
  "text" : "RT @CFPB: Have questions about financial products? Get answers in plain language. Go to Ask CFPB &amp; just start typing! http:\/\/t.co\/iM ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 132 ],
        "url" : "http:\/\/t.co\/iMSXaGYN",
        "expanded_url" : "http:\/\/www.consumerfinance.gov\/askcfpb\/",
        "display_url" : "consumerfinance.gov\/askcfpb\/"
      } ]
    },
    "geo" : { },
    "id_str" : "182884169213415424",
    "text" : "Have questions about financial products? Get answers in plain language. Go to Ask CFPB &amp; just start typing! http:\/\/t.co\/iMSXaGYN",
    "id" : 182884169213415424,
    "created_at" : "2012-03-22 17:39:18 +0000",
    "user" : {
      "name" : "consumerfinance.gov",
      "screen_name" : "CFPB",
      "protected" : false,
      "id_str" : "234826866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000026267147\/ab435400ed4215d94370fdfcf836dfbe_normal.png",
      "id" : 234826866,
      "verified" : true
    }
  },
  "id" : 182905073867816961,
  "created_at" : "2012-03-22 19:02:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Kitzhaber",
      "screen_name" : "GovKitz",
      "indices" : [ 3, 11 ],
      "id_str" : "69427169",
      "id" : 69427169
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/4iJGuFIL",
      "expanded_url" : "http:\/\/www.oregonlive.com\/opinion\/index.ssf\/2012\/03\/kitzhaber_commentary.html",
      "display_url" : "oregonlive.com\/opinion\/index.\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "182897041066827776",
  "text" : "RT @GovKitz: My op-ed on how health care reform is helping our state improve outcomes and coverage while saving money. http:\/\/t.co\/4iJGuFIL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 126 ],
        "url" : "http:\/\/t.co\/4iJGuFIL",
        "expanded_url" : "http:\/\/www.oregonlive.com\/opinion\/index.ssf\/2012\/03\/kitzhaber_commentary.html",
        "display_url" : "oregonlive.com\/opinion\/index.\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "182891222828986369",
    "text" : "My op-ed on how health care reform is helping our state improve outcomes and coverage while saving money. http:\/\/t.co\/4iJGuFIL",
    "id" : 182891222828986369,
    "created_at" : "2012-03-22 18:07:20 +0000",
    "user" : {
      "name" : "John Kitzhaber",
      "screen_name" : "GovKitz",
      "protected" : false,
      "id_str" : "69427169",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464191420396351489\/ltGvA7qC_normal.jpeg",
      "id" : 69427169,
      "verified" : true
    }
  },
  "id" : 182897041066827776,
  "created_at" : "2012-03-22 18:30:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Carson",
      "screen_name" : "JonCarson44",
      "indices" : [ 0, 12 ],
      "id_str" : "1287388789",
      "id" : 1287388789
    }, {
      "name" : "MomsRising",
      "screen_name" : "MomsRising",
      "indices" : [ 13, 24 ],
      "id_str" : "15174710",
      "id" : 15174710
    }, {
      "name" : "NWLC",
      "screen_name" : "nwlc",
      "indices" : [ 25, 30 ],
      "id_str" : "16967845",
      "id" : 16967845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 68 ],
      "url" : "https:\/\/t.co\/HXOqVN8P",
      "expanded_url" : "https:\/\/twitter.com\/#!\/macon44\/status\/182890805906771968",
      "display_url" : "twitter.com\/#!\/macon44\/sta\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "182889635104559105",
  "geo" : { },
  "id_str" : "182891005937336320",
  "in_reply_to_user_id" : 369232105,
  "text" : "@JonCarson44 @MomsRising @NWLC check this out: https:\/\/t.co\/HXOqVN8P",
  "id" : 182891005937336320,
  "in_reply_to_status_id" : 182889635104559105,
  "created_at" : "2012-03-22 18:06:28 +0000",
  "in_reply_to_screen_name" : "PAniskoff44",
  "in_reply_to_user_id_str" : "369232105",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 3, 12 ],
      "id_str" : "36719281",
      "id" : 36719281
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChamps",
      "indices" : [ 29, 38 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/Do631pPw",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "182883134944186368",
  "text" : "RT @letsmove: Happening now: #WHChamps of Change: Let\u2019s Move! Watch live: http:\/\/t.co\/Do631pPw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChamps",
        "indices" : [ 15, 24 ]
      } ],
      "urls" : [ {
        "indices" : [ 60, 80 ],
        "url" : "http:\/\/t.co\/Do631pPw",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "182883047119659008",
    "text" : "Happening now: #WHChamps of Change: Let\u2019s Move! Watch live: http:\/\/t.co\/Do631pPw",
    "id" : 182883047119659008,
    "created_at" : "2012-03-22 17:34:50 +0000",
    "user" : {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "protected" : false,
      "id_str" : "36719281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207340336\/780fc13e31b6fdd80bd57d000dc13838_normal.jpeg",
      "id" : 36719281,
      "verified" : true
    }
  },
  "id" : 182883134944186368,
  "created_at" : "2012-03-22 17:35:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "indices" : [ 3, 10 ],
      "id_str" : "166252256",
      "id" : 166252256
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "STEM",
      "indices" : [ 45, 50 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/JYzK2iGy",
      "expanded_url" : "http:\/\/go.usa.gov\/Puw",
      "display_url" : "go.usa.gov\/Puw"
    } ]
  },
  "geo" : { },
  "id_str" : "182854272185147392",
  "text" : "RT @ENERGY: Join our Tweet Up about women in #STEM careers today at 2:30pm ET. Send your Qs http:\/\/t.co\/JYzK2iGy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "STEM",
        "indices" : [ 33, 38 ]
      } ],
      "urls" : [ {
        "indices" : [ 80, 100 ],
        "url" : "http:\/\/t.co\/JYzK2iGy",
        "expanded_url" : "http:\/\/go.usa.gov\/Puw",
        "display_url" : "go.usa.gov\/Puw"
      } ]
    },
    "geo" : { },
    "id_str" : "182852397566136320",
    "text" : "Join our Tweet Up about women in #STEM careers today at 2:30pm ET. Send your Qs http:\/\/t.co\/JYzK2iGy",
    "id" : 182852397566136320,
    "created_at" : "2012-03-22 15:33:03 +0000",
    "user" : {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "protected" : false,
      "id_str" : "166252256",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793425839694155781\/HRS6sfn4_normal.jpg",
      "id" : 166252256,
      "verified" : true
    }
  },
  "id" : 182854272185147392,
  "created_at" : "2012-03-22 15:40:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "oil",
      "indices" : [ 76, 80 ]
    }, {
      "text" : "ObamainOK",
      "indices" : [ 114, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "182852225826160640",
  "text" : "RT @WHLive: President Obama: Since I took office, our dependence on foreign #oil has gone down every single year. #ObamainOK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "oil",
        "indices" : [ 64, 68 ]
      }, {
        "text" : "ObamainOK",
        "indices" : [ 102, 112 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "182852183333675008",
    "text" : "President Obama: Since I took office, our dependence on foreign #oil has gone down every single year. #ObamainOK",
    "id" : 182852183333675008,
    "created_at" : "2012-03-22 15:32:12 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 182852225826160640,
  "created_at" : "2012-03-22 15:32:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AllOfTheAbove",
      "indices" : [ 40, 54 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "182852007214850049",
  "text" : "RT @WHLive: Obama: I believe we need an #AllOfTheAbove strategy. That means producing more biofuels...fuel-efficient cars...solar power  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AllOfTheAbove",
        "indices" : [ 28, 42 ]
      }, {
        "text" : "ObamainOK",
        "indices" : [ 124, 134 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "182851933822926848",
    "text" : "Obama: I believe we need an #AllOfTheAbove strategy. That means producing more biofuels...fuel-efficient cars...solar power #ObamainOK",
    "id" : 182851933822926848,
    "created_at" : "2012-03-22 15:31:12 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 182852007214850049,
  "created_at" : "2012-03-22 15:31:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "energy",
      "indices" : [ 41, 48 ]
    }, {
      "text" : "ObamainOK",
      "indices" : [ 116, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/hhNoX4fh",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "182849691602530304",
  "text" : "Happening now: President Obama speaks on #energy at Cushing Pipe Yard in Oklahoma. Watch live: http:\/\/t.co\/hhNoX4fh #ObamainOK",
  "id" : 182849691602530304,
  "created_at" : "2012-03-22 15:22:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/182833271443435520\/photo\/1",
      "indices" : [ 123, 143 ],
      "url" : "http:\/\/t.co\/K9ZUhjPZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AomN5EYCMAE44g8.jpg",
      "id_str" : "182833271451824129",
      "id" : 182833271451824129,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AomN5EYCMAE44g8.jpg",
      "sizes" : [ {
        "h" : 1259,
        "resize" : "fit",
        "w" : 976
      }, {
        "h" : 1259,
        "resize" : "fit",
        "w" : 976
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 439,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 774,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/K9ZUhjPZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/pykFUz5F",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/2013-republican-budget",
      "display_url" : "whitehouse.gov\/2013-republica\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "182833271443435520",
  "text" : "Republican budget would give millionaires &amp; billionaires an ave tax cut of $150,000. Infographic: http:\/\/t.co\/pykFUz5F http:\/\/t.co\/K9ZUhjPZ",
  "id" : 182833271443435520,
  "created_at" : "2012-03-22 14:17:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "182621381333229568",
  "text" : "Live at 8:15ET: President Obama speaks on the Admin\u2019s commitment to expanding domestic oil &amp; gas production. Watch: http:\/\/t.co\/u95y7hhB",
  "id" : 182621381333229568,
  "created_at" : "2012-03-22 00:15:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hcr",
      "indices" : [ 92, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/Sc4UosHe",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2012\/03\/21\/health-reform-action-mothers-story",
      "display_url" : "whitehouse.gov\/blog\/2012\/03\/2\u2026"
    }, {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/j2eY3dNw",
      "expanded_url" : "http:\/\/youtu.be\/wXrKTsqmOjA",
      "display_url" : "youtu.be\/wXrKTsqmOjA"
    } ]
  },
  "geo" : { },
  "id_str" : "182615209398116352",
  "text" : "Health reform in action: A mother's story: http:\/\/t.co\/Sc4UosHe Watch: http:\/\/t.co\/j2eY3dNw #hcr",
  "id" : 182615209398116352,
  "created_at" : "2012-03-21 23:50:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Enda Kenny",
      "screen_name" : "EndaKennyTD",
      "indices" : [ 59, 71 ],
      "id_str" : "135514272",
      "id" : 135514272
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/182594654087290883\/photo\/1",
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/VWfs5R70",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Aoi03tdCIAAdpcL.jpg",
      "id_str" : "182594654095679488",
      "id" : 182594654095679488,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Aoi03tdCIAAdpcL.jpg",
      "sizes" : [ {
        "h" : 1275,
        "resize" : "fit",
        "w" : 1898
      }, {
        "h" : 403,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 688,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 228,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/VWfs5R70"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "182594654087290883",
  "text" : "Photo of the Day: Obama &amp; Boehner applaud as Taoiseach @endakennytd speaks @ St Patrick\u2019s Day lunch @ the Capitol: http:\/\/t.co\/VWfs5R70",
  "id" : 182594654087290883,
  "created_at" : "2012-03-21 22:28:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "indices" : [ 26, 35 ],
      "id_str" : "337742544",
      "id" : 337742544
    }, {
      "name" : "Storify",
      "screen_name" : "Storify",
      "indices" : [ 73, 81 ],
      "id_str" : "17814938",
      "id" : 17814938
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/182584474796695553\/photo\/1",
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/nFtUuA5o",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AoirnMpCIAE_cfG.jpg",
      "id_str" : "182584474805084161",
      "id" : 182584474805084161,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AoirnMpCIAE_cfG.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/nFtUuA5o"
    } ],
    "hashtags" : [ {
      "text" : "budget",
      "indices" : [ 43, 50 ]
    }, {
      "text" : "whchat",
      "indices" : [ 104, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/2sg89brT",
      "expanded_url" : "http:\/\/storify.com\/whitehouse\/budget-office-hours-with-jeff-zients-3-21-12",
      "display_url" : "storify.com\/whitehouse\/bud\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "182584474796695553",
  "text" : "Missed WH Office Hrs with @ombpress on the #budget? See full Q&amp;A via @Storify: http:\/\/t.co\/2sg89brT #whchat http:\/\/t.co\/nFtUuA5o",
  "id" : 182584474796695553,
  "created_at" : "2012-03-21 21:48:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HealthCare.gov",
      "screen_name" : "HealthCareGov",
      "indices" : [ 3, 17 ],
      "id_str" : "86697288",
      "id" : 86697288
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyCare",
      "indices" : [ 19, 26 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/bmE7yiIL",
      "expanded_url" : "http:\/\/youtu.be\/0dLg0iXQiOM",
      "display_url" : "youtu.be\/0dLg0iXQiOM"
    } ]
  },
  "geo" : { },
  "id_str" : "182577951001419778",
  "text" : "RT @HealthCareGov: #MyCare Video: Steven's story about coverage for young adults under 26 http:\/\/t.co\/bmE7yiIL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MyCare",
        "indices" : [ 0, 7 ]
      } ],
      "urls" : [ {
        "indices" : [ 71, 91 ],
        "url" : "http:\/\/t.co\/bmE7yiIL",
        "expanded_url" : "http:\/\/youtu.be\/0dLg0iXQiOM",
        "display_url" : "youtu.be\/0dLg0iXQiOM"
      } ]
    },
    "geo" : { },
    "id_str" : "182577152959590400",
    "text" : "#MyCare Video: Steven's story about coverage for young adults under 26 http:\/\/t.co\/bmE7yiIL",
    "id" : 182577152959590400,
    "created_at" : "2012-03-21 21:19:20 +0000",
    "user" : {
      "name" : "HealthCare.gov",
      "screen_name" : "HealthCareGov",
      "protected" : false,
      "id_str" : "86697288",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/528294497105350656\/OXpX0USe_normal.png",
      "id" : 86697288,
      "verified" : true
    }
  },
  "id" : 182577951001419778,
  "created_at" : "2012-03-21 21:22:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "indices" : [ 3, 12 ],
      "id_str" : "337742544",
      "id" : 337742544
    }, {
      "name" : "Elba Flamenco",
      "screen_name" : "ElbaFlamenco",
      "indices" : [ 15, 28 ],
      "id_str" : "480709023",
      "id" : 480709023
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "182576248671834112",
  "text" : "RT @OMBPress: .@ElbaFlamenco Under Obama, US once again leading investor in clean energy. GOP budget cont tax cuts 4 oil, 19% cut to cle ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Elba Flamenco",
        "screen_name" : "ElbaFlamenco",
        "indices" : [ 1, 14 ],
        "id_str" : "480709023",
        "id" : 480709023
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whchat",
        "indices" : [ 132, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "182576088420061184",
    "text" : ".@ElbaFlamenco Under Obama, US once again leading investor in clean energy. GOP budget cont tax cuts 4 oil, 19% cut to clean energy #whchat",
    "id" : 182576088420061184,
    "created_at" : "2012-03-21 21:15:06 +0000",
    "user" : {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "protected" : false,
      "id_str" : "337742544",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1449289379\/OMB_Seal_normal.jpg",
      "id" : 337742544,
      "verified" : true
    }
  },
  "id" : 182576248671834112,
  "created_at" : "2012-03-21 21:15:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elba Flamenco",
      "screen_name" : "ElbaFlamenco",
      "indices" : [ 3, 16 ],
      "id_str" : "480709023",
      "id" : 480709023
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 18, 25 ]
    }, {
      "text" : "budget",
      "indices" : [ 26, 33 ]
    }, {
      "text" : "RenewableEnergy",
      "indices" : [ 57, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "182576229692608512",
  "text" : "RT @ElbaFlamenco: #WHchat #budget \u25BA what's the status on #RenewableEnergy investments?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHchat",
        "indices" : [ 0, 7 ]
      }, {
        "text" : "budget",
        "indices" : [ 8, 15 ]
      }, {
        "text" : "RenewableEnergy",
        "indices" : [ 39, 55 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "182574846000115713",
    "text" : "#WHchat #budget \u25BA what's the status on #RenewableEnergy investments?",
    "id" : 182574846000115713,
    "created_at" : "2012-03-21 21:10:10 +0000",
    "user" : {
      "name" : "Elba Flamenco",
      "screen_name" : "ElbaFlamenco",
      "protected" : false,
      "id_str" : "480709023",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615219000121757696\/6ujnIoRK_normal.jpg",
      "id" : 480709023,
      "verified" : false
    }
  },
  "id" : 182576229692608512,
  "created_at" : "2012-03-21 21:15:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "indices" : [ 3, 12 ],
      "id_str" : "337742544",
      "id" : 337742544
    }, {
      "name" : "The Bobby Broadway",
      "screen_name" : "BobbyBroad",
      "indices" : [ 15, 26 ],
      "id_str" : "20952823",
      "id" : 20952823
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "182572124454653952",
  "text" : "RT @OMBPress: .@BobbyBroad GOP budget would deny coverage to 50M Americans, slash medicaid, raise costs for seniors ending medicare as w ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Bobby Broadway",
        "screen_name" : "BobbyBroad",
        "indices" : [ 1, 12 ],
        "id_str" : "20952823",
        "id" : 20952823
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whchat",
        "indices" : [ 132, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "182570551875870720",
    "text" : ".@BobbyBroad GOP budget would deny coverage to 50M Americans, slash medicaid, raise costs for seniors ending medicare as we know it #whchat",
    "id" : 182570551875870720,
    "created_at" : "2012-03-21 20:53:06 +0000",
    "user" : {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "protected" : false,
      "id_str" : "337742544",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1449289379\/OMB_Seal_normal.jpg",
      "id" : 337742544,
      "verified" : true
    }
  },
  "id" : 182572124454653952,
  "created_at" : "2012-03-21 20:59:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Bobby Broadway",
      "screen_name" : "BobbyBroad",
      "indices" : [ 3, 14 ],
      "id_str" : "20952823",
      "id" : 20952823
    }, {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "indices" : [ 16, 25 ],
      "id_str" : "337742544",
      "id" : 337742544
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "182572079416225794",
  "text" : "RT @BobbyBroad: @OMBPress how much more deeper are @RepPaulRyan cuts to health care then what Pres Obama proposed during debt ceiling de ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "OMBPress",
        "screen_name" : "OMBPress",
        "indices" : [ 0, 9 ],
        "id_str" : "337742544",
        "id" : 337742544
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHchat",
        "indices" : [ 125, 132 ]
      }, {
        "text" : "Budget",
        "indices" : [ 133, 140 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "182569082418241536",
    "geo" : { },
    "id_str" : "182569660703707136",
    "in_reply_to_user_id" : 337742544,
    "text" : "@OMBPress how much more deeper are @RepPaulRyan cuts to health care then what Pres Obama proposed during debt ceiling debate #WHchat #Budget",
    "id" : 182569660703707136,
    "in_reply_to_status_id" : 182569082418241536,
    "created_at" : "2012-03-21 20:49:33 +0000",
    "in_reply_to_screen_name" : "OMBPress",
    "in_reply_to_user_id_str" : "337742544",
    "user" : {
      "name" : "The Bobby Broadway",
      "screen_name" : "BobbyBroad",
      "protected" : false,
      "id_str" : "20952823",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/695724380060565504\/SVG2xCAh_normal.jpg",
      "id" : 20952823,
      "verified" : false
    }
  },
  "id" : 182572079416225794,
  "created_at" : "2012-03-21 20:59:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "indices" : [ 3, 12 ],
      "id_str" : "337742544",
      "id" : 337742544
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "budget",
      "indices" : [ 71, 78 ]
    }, {
      "text" : "WHchat",
      "indices" : [ 101, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "182570802854625281",
  "text" : "RT @OMBPress: Hi Jeff here, ready to answer your questions on all news #budget. Ready to get started #WHchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "budget",
        "indices" : [ 57, 64 ]
      }, {
        "text" : "WHchat",
        "indices" : [ 87, 94 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "182567300233302017",
    "text" : "Hi Jeff here, ready to answer your questions on all news #budget. Ready to get started #WHchat",
    "id" : 182567300233302017,
    "created_at" : "2012-03-21 20:40:10 +0000",
    "user" : {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "protected" : false,
      "id_str" : "337742544",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1449289379\/OMB_Seal_normal.jpg",
      "id" : 337742544,
      "verified" : true
    }
  },
  "id" : 182570802854625281,
  "created_at" : "2012-03-21 20:54:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "energy",
      "indices" : [ 58, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "182566317465935875",
  "text" : "Happening now: President Obama speaks on diversifying our #energy portfolio in Nevada. Watch live: http:\/\/t.co\/u95y7hhB",
  "id" : 182566317465935875,
  "created_at" : "2012-03-21 20:36:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whchat",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/czxflkhv",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2012\/03\/21\/ryan-republican-budget-consequences-imbalance",
      "display_url" : "whitehouse.gov\/blog\/2012\/03\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "182531026390753281",
  "text" : "Jeff Zients on the the Ryan-Republican Budget &amp; the consequences of imbalance: http:\/\/t.co\/czxflkhv Have questions? Ask now with #whchat",
  "id" : 182531026390753281,
  "created_at" : "2012-03-21 18:16:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "indices" : [ 3, 12 ],
      "id_str" : "337742544",
      "id" : 337742544
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/CA21aKuc",
      "expanded_url" : "http:\/\/ht.ly\/9NksT",
      "display_url" : "ht.ly\/9NksT"
    } ]
  },
  "geo" : { },
  "id_str" : "182521307727003648",
  "text" : "RT @OMBPress: WH Office Hours today: The Budget: OMB Acting Director Jeff Zients answers your ?s @ 4:30ET: http:\/\/t.co\/CA21aKuc Ask now: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 123, 130 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 113 ],
        "url" : "http:\/\/t.co\/CA21aKuc",
        "expanded_url" : "http:\/\/ht.ly\/9NksT",
        "display_url" : "ht.ly\/9NksT"
      } ]
    },
    "geo" : { },
    "id_str" : "182521220040884224",
    "text" : "WH Office Hours today: The Budget: OMB Acting Director Jeff Zients answers your ?s @ 4:30ET: http:\/\/t.co\/CA21aKuc Ask now: #WHChat",
    "id" : 182521220040884224,
    "created_at" : "2012-03-21 17:37:04 +0000",
    "user" : {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "protected" : false,
      "id_str" : "337742544",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1449289379\/OMB_Seal_normal.jpg",
      "id" : 337742544,
      "verified" : true
    }
  },
  "id" : 182521307727003648,
  "created_at" : "2012-03-21 17:37:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "indices" : [ 27, 34 ],
      "id_str" : "44783853",
      "id" : 44783853
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChamps",
      "indices" : [ 58, 67 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/g5ih2w0F",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "182519334508314624",
  "text" : "RT @WHLive: Happening now: @HHSGov Sec Sebelius speaks to #WHChamps of Change: Affordable Care Act. Watch live: http:\/\/t.co\/g5ih2w0F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "HHS.gov",
        "screen_name" : "HHSGov",
        "indices" : [ 15, 22 ],
        "id_str" : "44783853",
        "id" : 44783853
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChamps",
        "indices" : [ 46, 55 ]
      } ],
      "urls" : [ {
        "indices" : [ 100, 120 ],
        "url" : "http:\/\/t.co\/g5ih2w0F",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "182519215788539904",
    "text" : "Happening now: @HHSGov Sec Sebelius speaks to #WHChamps of Change: Affordable Care Act. Watch live: http:\/\/t.co\/g5ih2w0F",
    "id" : 182519215788539904,
    "created_at" : "2012-03-21 17:29:06 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 182519334508314624,
  "created_at" : "2012-03-21 17:29:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "indices" : [ 15, 22 ],
      "id_str" : "44783853",
      "id" : 44783853
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChamps",
      "indices" : [ 46, 55 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "182519210667290624",
  "text" : "Happening now: @HHSGov Sec Sebelius speaks to #WHChamps of Change: Affordable Care Act. Watch live: http:\/\/t.co\/u95y7hhB",
  "id" : 182519210667290624,
  "created_at" : "2012-03-21 17:29:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 42, 53 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/aKE79fAK",
      "expanded_url" : "http:\/\/storify.com\/whitehouse\/top-tweets-of-2012",
      "display_url" : "storify.com\/whitehouse\/top\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "182482364868460546",
  "text" : "Happy Birthday Twitter! Check out some of @whitehouse's top tweets from 2011: http:\/\/t.co\/aKE79fAK",
  "id" : 182482364868460546,
  "created_at" : "2012-03-21 15:02:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AllOfTheAbove",
      "indices" : [ 74, 88 ]
    }, {
      "text" : "energy",
      "indices" : [ 89, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/yc35oC6M",
      "expanded_url" : "http:\/\/wh.gov\/energy\/gasprices",
      "display_url" : "wh.gov\/energy\/gaspric\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "182466673020907520",
  "text" : "Today, President Obama heads to Nevada &amp; New Mexico to talk about his #AllOfTheAbove #energy strategy: http:\/\/t.co\/yc35oC6M",
  "id" : 182466673020907520,
  "created_at" : "2012-03-21 14:00:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kori Schulman",
      "screen_name" : "ks44",
      "indices" : [ 3, 8 ],
      "id_str" : "369246180",
      "id" : 369246180
    }, {
      "name" : "Stephanie Dahle",
      "screen_name" : "StephanieDahle",
      "indices" : [ 105, 120 ],
      "id_str" : "49844221",
      "id" : 49844221
    }, {
      "name" : "Amy Lynn Smith",
      "screen_name" : "alswrite",
      "indices" : [ 121, 130 ],
      "id_str" : "165537211",
      "id" : 165537211
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whtweetup",
      "indices" : [ 27, 37 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/eq5mExOZ",
      "expanded_url" : "http:\/\/ow.ly\/9MiQt",
      "display_url" : "ow.ly\/9MiQt"
    } ]
  },
  "geo" : { },
  "id_str" : "182253798692106242",
  "text" : "RT @ks44: Can't get enough #whtweetup? See more highlights from the UK Arrival: http:\/\/t.co\/eq5mExOZ cc: @stephaniedahle @alswrite @SanR ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephanie Dahle",
        "screen_name" : "StephanieDahle",
        "indices" : [ 95, 110 ],
        "id_str" : "49844221",
        "id" : 49844221
      }, {
        "name" : "Amy Lynn Smith",
        "screen_name" : "alswrite",
        "indices" : [ 111, 120 ],
        "id_str" : "165537211",
        "id" : 165537211
      }, {
        "name" : "San Rafael Police",
        "screen_name" : "SanRafaelPolice",
        "indices" : [ 121, 137 ],
        "id_str" : "27241813",
        "id" : 27241813
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whtweetup",
        "indices" : [ 17, 27 ]
      } ],
      "urls" : [ {
        "indices" : [ 70, 90 ],
        "url" : "http:\/\/t.co\/eq5mExOZ",
        "expanded_url" : "http:\/\/ow.ly\/9MiQt",
        "display_url" : "ow.ly\/9MiQt"
      } ]
    },
    "geo" : { },
    "id_str" : "182253700536999936",
    "text" : "Can't get enough #whtweetup? See more highlights from the UK Arrival: http:\/\/t.co\/eq5mExOZ cc: @stephaniedahle @alswrite @SanRafaelPolice",
    "id" : 182253700536999936,
    "created_at" : "2012-03-20 23:54:02 +0000",
    "user" : {
      "name" : "Kori Schulman",
      "screen_name" : "ks44",
      "protected" : false,
      "id_str" : "369246180",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/667876153793859584\/DV7HzP-1_normal.jpg",
      "id" : 369246180,
      "verified" : true
    }
  },
  "id" : 182253798692106242,
  "created_at" : "2012-03-20 23:54:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Todd Park",
      "screen_name" : "todd_park",
      "indices" : [ 3, 13 ],
      "id_str" : "200176600",
      "id" : 200176600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "182251173733085185",
  "text" : "RT @todd_park: Now on the job in my new role. Thanks very much to all for your tweets and messages, and look forward to working with you!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "182242729760260096",
    "text" : "Now on the job in my new role. Thanks very much to all for your tweets and messages, and look forward to working with you!",
    "id" : 182242729760260096,
    "created_at" : "2012-03-20 23:10:27 +0000",
    "user" : {
      "name" : "Todd Park",
      "screen_name" : "todd_park",
      "protected" : false,
      "id_str" : "200176600",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1140157375\/toddpark_normal.jpg",
      "id" : 200176600,
      "verified" : false
    }
  },
  "id" : 182251173733085185,
  "created_at" : "2012-03-20 23:44:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "182243946716610562",
  "text" : "Happening now: President Obama &amp; First Lady Michelle Obama Host a St. Patrick\u2019s Day reception. Watch: http:\/\/t.co\/u95y7hhB",
  "id" : 182243946716610562,
  "created_at" : "2012-03-20 23:15:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHLGBT",
      "indices" : [ 24, 31 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/BC5c7dyU",
      "expanded_url" : "http:\/\/ow.ly\/9McpK",
      "display_url" : "ow.ly\/9McpK"
    } ]
  },
  "geo" : { },
  "id_str" : "182221567495901185",
  "text" : "RT @WHLive: Watch Live: #WHLGBT Conference on Safe Schools &amp; Communities: http:\/\/t.co\/BC5c7dyU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHLGBT",
        "indices" : [ 12, 19 ]
      } ],
      "urls" : [ {
        "indices" : [ 66, 86 ],
        "url" : "http:\/\/t.co\/BC5c7dyU",
        "expanded_url" : "http:\/\/ow.ly\/9McpK",
        "display_url" : "ow.ly\/9McpK"
      } ]
    },
    "geo" : { },
    "id_str" : "182221447119372288",
    "text" : "Watch Live: #WHLGBT Conference on Safe Schools &amp; Communities: http:\/\/t.co\/BC5c7dyU",
    "id" : 182221447119372288,
    "created_at" : "2012-03-20 21:45:53 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 182221567495901185,
  "created_at" : "2012-03-20 21:46:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Carson",
      "screen_name" : "JonCarson44",
      "indices" : [ 3, 15 ],
      "id_str" : "1287388789",
      "id" : 1287388789
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hcr",
      "indices" : [ 17, 21 ]
    }, {
      "text" : "ACA",
      "indices" : [ 59, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "182208675363045377",
  "text" : "RT @JonCarson44: #hcr map is LIVE Click on state 2 see how #ACA benefits people &amp; find stories from Americans w better + affordable  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "hcr",
        "indices" : [ 0, 4 ]
      }, {
        "text" : "ACA",
        "indices" : [ 42, 46 ]
      } ],
      "urls" : [ {
        "indices" : [ 124, 144 ],
        "url" : "http:\/\/t.co\/uHYYTTX8",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/healthreform\/map",
        "display_url" : "whitehouse.gov\/healthreform\/m\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "182207769129132033",
    "text" : "#hcr map is LIVE Click on state 2 see how #ACA benefits people &amp; find stories from Americans w better + affordable care http:\/\/t.co\/uHYYTTX8",
    "id" : 182207769129132033,
    "created_at" : "2012-03-20 20:51:32 +0000",
    "user" : {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "protected" : false,
      "id_str" : "369232105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623146355767140352\/58sqoVrw_normal.jpg",
      "id" : 369232105,
      "verified" : true
    }
  },
  "id" : 182208675363045377,
  "created_at" : "2012-03-20 20:55:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/182160958284763136\/photo\/1",
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/2iBnWAgn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AocqbSrCEAALB7-.jpg",
      "id_str" : "182160958288957440",
      "id" : 182160958288957440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AocqbSrCEAALB7-.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      } ],
      "display_url" : "pic.twitter.com\/2iBnWAgn"
    } ],
    "hashtags" : [ {
      "text" : "hcr",
      "indices" : [ 109, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http:\/\/t.co\/y8I2O9ht",
      "expanded_url" : "http:\/\/wh.gov\/RjF",
      "display_url" : "wh.gov\/RjF"
    } ]
  },
  "geo" : { },
  "id_str" : "182160958284763136",
  "text" : "By the numbers: 20.4: http:\/\/t.co\/y8I2O9ht: 20.4 million women have accessed free preventive health services #hcr http:\/\/t.co\/2iBnWAgn",
  "id" : 182160958284763136,
  "created_at" : "2012-03-20 17:45:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "indices" : [ 3, 18 ],
      "id_str" : "19674502",
      "id" : 19674502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "182132904699248640",
  "text" : "RT @AmbassadorRice: I extend my best wishes to all who are celebrating Nowruz. Eid-eh Shoma Mobarak - Happy New Year to you.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "182131917754351617",
    "text" : "I extend my best wishes to all who are celebrating Nowruz. Eid-eh Shoma Mobarak - Happy New Year to you.",
    "id" : 182131917754351617,
    "created_at" : "2012-03-20 15:50:07 +0000",
    "user" : {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "protected" : false,
      "id_str" : "19674502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2245433940\/297681_10150417294436240_295915266239_10074516_1895344954_n_normal.jpg",
      "id" : 19674502,
      "verified" : true
    }
  },
  "id" : 182132904699248640,
  "created_at" : "2012-03-20 15:54:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0627\u0644\u062E\u0627\u0631\u062C\u064A\u0629 \u0627\u0644\u0623\u0645\u0631\u064A\u0643\u064A\u0629",
      "screen_name" : "USAbilAraby",
      "indices" : [ 3, 15 ],
      "id_str" : "249409411",
      "id" : 249409411
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obama",
      "indices" : [ 92, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/JLTK8eq2",
      "expanded_url" : "http:\/\/youtu.be\/f95AvfP83Kw",
      "display_url" : "youtu.be\/f95AvfP83Kw"
    } ]
  },
  "geo" : { },
  "id_str" : "182132800365924352",
  "text" : "RT @USAbilAraby: \u0627\u0644\u0631\u0626\u064A\u0633 \u0623\u0648\u0628\u0627\u0645\u0627 \u0648\u0627\u0644\u0633\u064A\u062F\u0629 \u0645\u064A\u0634\u064A\u0644 \u0623\u0648\u0628\u0627\u0645\u0627 \u064A\u0647\u0646\u0626\u0627\u0646 \u0627\u0644\u0634\u0639\u0628 \u0627\u0644\u0623\u064A\u0631\u0627\u0646\u064A \u0628\u0645\u0646\u0627\u0633\u0628\u0629 \u0639\u064A\u062F \u0646\u0648\u0631\u0648\u0632 #Obama\nhttp:\/\/t.co\/JLTK8eq2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Obama",
        "indices" : [ 75, 81 ]
      } ],
      "urls" : [ {
        "indices" : [ 82, 102 ],
        "url" : "http:\/\/t.co\/JLTK8eq2",
        "expanded_url" : "http:\/\/youtu.be\/f95AvfP83Kw",
        "display_url" : "youtu.be\/f95AvfP83Kw"
      } ]
    },
    "geo" : { },
    "id_str" : "182112718298419200",
    "text" : "\u0627\u0644\u0631\u0626\u064A\u0633 \u0623\u0648\u0628\u0627\u0645\u0627 \u0648\u0627\u0644\u0633\u064A\u062F\u0629 \u0645\u064A\u0634\u064A\u0644 \u0623\u0648\u0628\u0627\u0645\u0627 \u064A\u0647\u0646\u0626\u0627\u0646 \u0627\u0644\u0634\u0639\u0628 \u0627\u0644\u0623\u064A\u0631\u0627\u0646\u064A \u0628\u0645\u0646\u0627\u0633\u0628\u0629 \u0639\u064A\u062F \u0646\u0648\u0631\u0648\u0632 #Obama\nhttp:\/\/t.co\/JLTK8eq2",
    "id" : 182112718298419200,
    "created_at" : "2012-03-20 14:33:50 +0000",
    "user" : {
      "name" : "\u0627\u0644\u062E\u0627\u0631\u062C\u064A\u0629 \u0627\u0644\u0623\u0645\u0631\u064A\u0643\u064A\u0629",
      "screen_name" : "USAbilAraby",
      "protected" : false,
      "id_str" : "249409411",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/551745952730451968\/hpIBWtgZ_normal.png",
      "id" : 249409411,
      "verified" : true
    }
  },
  "id" : 182132800365924352,
  "created_at" : "2012-03-20 15:53:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    }, {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 18, 29 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "182128786429587457",
  "text" : "RT @jesseclee44: .@pfeiffer44: \"House budget would end Medicare as we know it, turning guarantee of retirement security into a voucher\"  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "pu iezov uf",
        "screen_name" : "pfeiffer44",
        "indices" : [ 1, 12 ],
        "id_str" : "3187888216",
        "id" : 3187888216
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/IAo4LZZH",
        "expanded_url" : "http:\/\/wh.gov\/RK1",
        "display_url" : "wh.gov\/RK1"
      } ]
    },
    "geo" : { },
    "id_str" : "182116748860993536",
    "text" : ".@pfeiffer44: \"House budget would end Medicare as we know it, turning guarantee of retirement security into a voucher\" http:\/\/t.co\/IAo4LZZH",
    "id" : 182116748860993536,
    "created_at" : "2012-03-20 14:49:51 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 182128786429587457,
  "created_at" : "2012-03-20 15:37:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "indices" : [ 3, 10 ],
      "id_str" : "166252256",
      "id" : 166252256
    }, {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "indices" : [ 59, 66 ],
      "id_str" : "166252256",
      "id" : 166252256
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "askENERGY",
      "indices" : [ 109, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "182122759357333506",
  "text" : "RT @ENERGY: Twitter Q&amp;A TODAY 12 PM ET: Got Q's on how @ENERGY promotes alt fuels and advanced vehicles? #askENERGY: http:\/\/t.co\/sKg ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Energy Department",
        "screen_name" : "ENERGY",
        "indices" : [ 47, 54 ],
        "id_str" : "166252256",
        "id" : 166252256
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "askENERGY",
        "indices" : [ 97, 107 ]
      } ],
      "urls" : [ {
        "indices" : [ 109, 129 ],
        "url" : "http:\/\/t.co\/sKgN61XK",
        "expanded_url" : "http:\/\/go.usa.gov\/Ea3",
        "display_url" : "go.usa.gov\/Ea3"
      } ]
    },
    "geo" : { },
    "id_str" : "182100067690352641",
    "text" : "Twitter Q&amp;A TODAY 12 PM ET: Got Q's on how @ENERGY promotes alt fuels and advanced vehicles? #askENERGY: http:\/\/t.co\/sKgN61XK",
    "id" : 182100067690352641,
    "created_at" : "2012-03-20 13:43:34 +0000",
    "user" : {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "protected" : false,
      "id_str" : "166252256",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793425839694155781\/HRS6sfn4_normal.jpg",
      "id" : 166252256,
      "verified" : true
    }
  },
  "id" : 182122759357333506,
  "created_at" : "2012-03-20 15:13:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HealthCare.gov",
      "screen_name" : "HealthCareGov",
      "indices" : [ 3, 17 ],
      "id_str" : "86697288",
      "id" : 86697288
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hcr",
      "indices" : [ 29, 33 ]
    }, {
      "text" : "MyCare",
      "indices" : [ 123, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "182107921319079936",
  "text" : "RT @HealthCareGov: \"Now with #hcr other families won\u2019t have to fight to keep their children well\" - Vanessa, FL. Watch her #MyCare video ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "hcr",
        "indices" : [ 10, 14 ]
      }, {
        "text" : "MyCare",
        "indices" : [ 104, 111 ]
      } ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/q80ctstl",
        "expanded_url" : "http:\/\/1.usa.gov\/GD9eHj",
        "display_url" : "1.usa.gov\/GD9eHj"
      } ]
    },
    "geo" : { },
    "id_str" : "182103465756078080",
    "text" : "\"Now with #hcr other families won\u2019t have to fight to keep their children well\" - Vanessa, FL. Watch her #MyCare video: http:\/\/t.co\/q80ctstl",
    "id" : 182103465756078080,
    "created_at" : "2012-03-20 13:57:04 +0000",
    "user" : {
      "name" : "HealthCare.gov",
      "screen_name" : "HealthCareGov",
      "protected" : false,
      "id_str" : "86697288",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/528294497105350656\/OXpX0USe_normal.png",
      "id" : 86697288,
      "verified" : true
    }
  },
  "id" : 182107921319079936,
  "created_at" : "2012-03-20 14:14:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USA darFarsi",
      "screen_name" : "USAdarFarsi",
      "indices" : [ 3, 15 ],
      "id_str" : "251633354",
      "id" : 251633354
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u0627\u0648\u0628\u0627\u0645\u0627",
      "indices" : [ 25, 32 ]
    }, {
      "text" : "\u0646\u0648\u0631\u0648\u0632",
      "indices" : [ 36, 42 ]
    }, {
      "text" : "Iran",
      "indices" : [ 126, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/d02kSiqD",
      "expanded_url" : "http:\/\/goo.gl\/aozyE",
      "display_url" : "goo.gl\/aozyE"
    } ]
  },
  "geo" : { },
  "id_str" : "182106051859054592",
  "text" : "RT @USAdarFarsi: \u067E\u0631\u0632\u06CC\u062F\u0646\u062A #\u0627\u0648\u0628\u0627\u0645\u0627 \u062F\u0631 #\u0646\u0648\u0631\u0648\u0632 \u0628\u0627 \u0627\u06CC\u0631\u0627\u0646\u06CC\u0627\u0646 \u0633\u062E\u0646 \u06AF\u0641\u062A (\u06F1\u06F3\u06F9\u06F1) - \u067E\u06CC\u0627\u0645 \u0648\u06CC\u062F\u0626\u0648\u06CC\u06CC \u0646\u0648\u0631\u0648\u0632 \u0628\u0627 \u06A9\u06CC\u0641\u06CC\u062A \u0628\u0627\u0644\u0627 http:\/\/t.co\/d02kSiqD #Iran #Now ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 123, 134 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "\u0627\u0648\u0628\u0627\u0645\u0627",
        "indices" : [ 8, 15 ]
      }, {
        "text" : "\u0646\u0648\u0631\u0648\u0632",
        "indices" : [ 19, 25 ]
      }, {
        "text" : "Iran",
        "indices" : [ 109, 114 ]
      }, {
        "text" : "Nowruz",
        "indices" : [ 115, 122 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 108 ],
        "url" : "http:\/\/t.co\/d02kSiqD",
        "expanded_url" : "http:\/\/goo.gl\/aozyE",
        "display_url" : "goo.gl\/aozyE"
      } ]
    },
    "geo" : { },
    "id_str" : "182090266830835712",
    "text" : "\u067E\u0631\u0632\u06CC\u062F\u0646\u062A #\u0627\u0648\u0628\u0627\u0645\u0627 \u062F\u0631 #\u0646\u0648\u0631\u0648\u0632 \u0628\u0627 \u0627\u06CC\u0631\u0627\u0646\u06CC\u0627\u0646 \u0633\u062E\u0646 \u06AF\u0641\u062A (\u06F1\u06F3\u06F9\u06F1) - \u067E\u06CC\u0627\u0645 \u0648\u06CC\u062F\u0626\u0648\u06CC\u06CC \u0646\u0648\u0631\u0648\u0632 \u0628\u0627 \u06A9\u06CC\u0641\u06CC\u062A \u0628\u0627\u0644\u0627 http:\/\/t.co\/d02kSiqD #Iran #Nowruz @whitehouse",
    "id" : 182090266830835712,
    "created_at" : "2012-03-20 13:04:37 +0000",
    "user" : {
      "name" : "USA darFarsi",
      "screen_name" : "USAdarFarsi",
      "protected" : false,
      "id_str" : "251633354",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/476387055849594880\/bhbFFBzR_normal.jpeg",
      "id" : 251633354,
      "verified" : true
    }
  },
  "id" : 182106051859054592,
  "created_at" : "2012-03-20 14:07:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Nowruz",
      "indices" : [ 98, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 124, 144 ],
      "url" : "http:\/\/t.co\/ocSAnltf",
      "expanded_url" : "http:\/\/youtu.be\/vBtkSa6RiPg",
      "display_url" : "youtu.be\/vBtkSa6RiPg"
    } ]
  },
  "geo" : { },
  "id_str" : "182091935937335296",
  "text" : "President Obama: \"Today, Michelle &amp; I extend our best wishes to all those who are celebrating #Nowruz around the world\" http:\/\/t.co\/ocSAnltf",
  "id" : 182091935937335296,
  "created_at" : "2012-03-20 13:11:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/181899199263150081\/photo\/1",
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/G9fwBSxs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AoY8W6YCEAAs2mF.jpg",
      "id_str" : "181899199279927296",
      "id" : 181899199279927296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AoY8W6YCEAAs2mF.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/G9fwBSxs"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "181899199263150081",
  "text" : "Photo of the Day: President Obama calls Palestinian Authority President Mahmoud Abbas from the Oval Office: http:\/\/t.co\/G9fwBSxs",
  "id" : 181899199263150081,
  "created_at" : "2012-03-20 00:25:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kori Schulman",
      "screen_name" : "ks44",
      "indices" : [ 3, 8 ],
      "id_str" : "369246180",
      "id" : 369246180
    }, {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 44, 53 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/g2aQii6i",
      "expanded_url" : "http:\/\/ow.ly\/9KIfy",
      "display_url" : "ow.ly\/9KIfy"
    } ]
  },
  "geo" : { },
  "id_str" : "181865300365553664",
  "text" : "RT @ks44: Check out today's 1st Question w\/ @presssec: http:\/\/t.co\/g2aQii6i What'd you think? Appreciate input\/ always looking for ways  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Josh Earnest",
        "screen_name" : "PressSec",
        "indices" : [ 34, 43 ],
        "id_str" : "113420831",
        "id" : 113420831
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "1q",
        "indices" : [ 137, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 45, 65 ],
        "url" : "http:\/\/t.co\/g2aQii6i",
        "expanded_url" : "http:\/\/ow.ly\/9KIfy",
        "display_url" : "ow.ly\/9KIfy"
      } ]
    },
    "geo" : { },
    "id_str" : "181865193847005184",
    "text" : "Check out today's 1st Question w\/ @presssec: http:\/\/t.co\/g2aQii6i What'd you think? Appreciate input\/ always looking for ways to improve #1q",
    "id" : 181865193847005184,
    "created_at" : "2012-03-19 22:10:15 +0000",
    "user" : {
      "name" : "Kori Schulman",
      "screen_name" : "ks44",
      "protected" : false,
      "id_str" : "369246180",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/667876153793859584\/DV7HzP-1_normal.jpg",
      "id" : 369246180,
      "verified" : true
    }
  },
  "id" : 181865300365553664,
  "created_at" : "2012-03-19 22:10:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 11, 20 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gasprices",
      "indices" : [ 66, 76 ]
    }, {
      "text" : "energy",
      "indices" : [ 78, 85 ]
    }, {
      "text" : "ACA",
      "indices" : [ 92, 96 ]
    }, {
      "text" : "1q",
      "indices" : [ 100, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/00A23yrl",
      "expanded_url" : "http:\/\/youtu.be\/eK4SQGP5lmM",
      "display_url" : "youtu.be\/eK4SQGP5lmM"
    } ]
  },
  "geo" : { },
  "id_str" : "181850923591663616",
  "text" : "You asked, @PressSec answered. Watch Jay Carney answer your ?s on #gasprices, #energy &amp; #ACA in #1q: http:\/\/t.co\/00A23yrl",
  "id" : 181850923591663616,
  "created_at" : "2012-03-19 21:13:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyCare",
      "indices" : [ 100, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/A5Mfkzys",
      "expanded_url" : "http:\/\/ow.ly\/9Kr2w",
      "display_url" : "ow.ly\/9Kr2w"
    } ]
  },
  "geo" : { },
  "id_str" : "181816318142590976",
  "text" : "\"Getting the donut hole closed, that gives me a little more money in my pocket\" -Helen R. Watch her #MyCare story: http:\/\/t.co\/A5Mfkzys",
  "id" : 181816318142590976,
  "created_at" : "2012-03-19 18:56:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/181800023359623168\/photo\/1",
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/bTXFbf0k",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AoXiKHTCEAAV6DH.jpg",
      "id_str" : "181800023363817472",
      "id" : 181800023363817472,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AoXiKHTCEAAV6DH.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      } ],
      "display_url" : "pic.twitter.com\/bTXFbf0k"
    } ],
    "hashtags" : [ {
      "text" : "hcr",
      "indices" : [ 108, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 24, 44 ],
      "url" : "http:\/\/t.co\/6MyeVa49",
      "expanded_url" : "http:\/\/wh.gov\/R4S",
      "display_url" : "wh.gov\/R4S"
    } ]
  },
  "geo" : { },
  "id_str" : "181800023359623168",
  "text" : "By the Numbers: $4,200: http:\/\/t.co\/6MyeVa49 Seniors on Medicare will save $4,200 on health care because of #hcr http:\/\/t.co\/bTXFbf0k",
  "id" : 181800023359623168,
  "created_at" : "2012-03-19 17:51:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "fuck off fascists.",
      "screen_name" : "Rizzz",
      "indices" : [ 13, 19 ],
      "id_str" : "13532822",
      "id" : 13532822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "181760331792654336",
  "text" : "RT @WHLive: .@rizzz Law requires free prevention incl birth control, students will have access, religious orgs and univs won't pay for c ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "fuck off fascists.",
        "screen_name" : "Rizzz",
        "indices" : [ 1, 7 ],
        "id_str" : "13532822",
        "id" : 13532822
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whchat",
        "indices" : [ 132, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "181759890887413761",
    "text" : ".@rizzz Law requires free prevention incl birth control, students will have access, religious orgs and univs won't pay for coverage #whchat",
    "id" : 181759890887413761,
    "created_at" : "2012-03-19 15:11:49 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 181760331792654336,
  "created_at" : "2012-03-19 15:13:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "fuck off fascists.",
      "screen_name" : "Rizzz",
      "indices" : [ 3, 9 ],
      "id_str" : "13532822",
      "id" : 13532822
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whchat",
      "indices" : [ 130, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "181760320673550338",
  "text" : "RT @Rizzz: How are you going to ensure that ALL students, regardless of what school they attend, will have birth control covered? #whchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whchat",
        "indices" : [ 119, 126 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "181748914813284354",
    "text" : "How are you going to ensure that ALL students, regardless of what school they attend, will have birth control covered? #whchat",
    "id" : 181748914813284354,
    "created_at" : "2012-03-19 14:28:12 +0000",
    "user" : {
      "name" : "fuck off fascists.",
      "screen_name" : "Rizzz",
      "protected" : false,
      "id_str" : "13532822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/643164912857010176\/vK8chOui_normal.jpg",
      "id" : 13532822,
      "verified" : false
    }
  },
  "id" : 181760320673550338,
  "created_at" : "2012-03-19 15:13:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Khyati Desai",
      "screen_name" : "kdesai1",
      "indices" : [ 13, 21 ],
      "id_str" : "31451649",
      "id" : 31451649
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "181757699451662336",
  "text" : "RT @WHLive: .@kdesai1 The law already makes preventive services like mammograms free for Medicare and tens of millions in private plans  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Khyati Desai",
        "screen_name" : "kdesai1",
        "indices" : [ 1, 9 ],
        "id_str" : "31451649",
        "id" : 31451649
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whchat",
        "indices" : [ 124, 131 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "181749429320155136",
    "geo" : { },
    "id_str" : "181756857759711232",
    "in_reply_to_user_id" : 31451649,
    "text" : ".@kdesai1 The law already makes preventive services like mammograms free for Medicare and tens of millions in private plans #whchat",
    "id" : 181756857759711232,
    "in_reply_to_status_id" : 181749429320155136,
    "created_at" : "2012-03-19 14:59:46 +0000",
    "in_reply_to_screen_name" : "kdesai1",
    "in_reply_to_user_id_str" : "31451649",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 181757699451662336,
  "created_at" : "2012-03-19 15:03:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Khyati Desai",
      "screen_name" : "kdesai1",
      "indices" : [ 3, 11 ],
      "id_str" : "31451649",
      "id" : 31451649
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "181757673937715201",
  "text" : "RT @kdesai1: What is the commitment to cover preventive care &amp; alternative medicine? Better health, lower medical costs-sounds like  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 136, 143 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "181749429320155136",
    "text" : "What is the commitment to cover preventive care &amp; alternative medicine? Better health, lower medical costs-sounds like a no-brainer #WHChat",
    "id" : 181749429320155136,
    "created_at" : "2012-03-19 14:30:15 +0000",
    "user" : {
      "name" : "Khyati Desai",
      "screen_name" : "kdesai1",
      "protected" : false,
      "id_str" : "31451649",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1874904317\/ry_3D401_normal.jpg",
      "id" : 31451649,
      "verified" : false
    }
  },
  "id" : 181757673937715201,
  "created_at" : "2012-03-19 15:03:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1q",
      "indices" : [ 74, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "181740214929207296",
  "text" : "RT @PressSec: Today, we\u2019re bringing back First Question. Ask your ?s with #1q &amp; I'll answer some later. Looking forward to this: htt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "1q",
        "indices" : [ 60, 63 ]
      } ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/rs2Y4JF5",
        "expanded_url" : "http:\/\/wh.gov\/RgT",
        "display_url" : "wh.gov\/RgT"
      } ]
    },
    "geo" : { },
    "id_str" : "181739453918871553",
    "text" : "Today, we\u2019re bringing back First Question. Ask your ?s with #1q &amp; I'll answer some later. Looking forward to this: http:\/\/t.co\/rs2Y4JF5",
    "id" : 181739453918871553,
    "created_at" : "2012-03-19 13:50:37 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 181740214929207296,
  "created_at" : "2012-03-19 13:53:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 107, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/fhuGgzP1",
      "expanded_url" : "http:\/\/ow.ly\/9JTbC",
      "display_url" : "ow.ly\/9JTbC"
    } ]
  },
  "geo" : { },
  "id_str" : "181740176530354177",
  "text" : "Starting @ 10:30ET: Nancy-Ann DeParle answers your ?s on health care reform during WH Office Hrs. Ask now: #WHChat http:\/\/t.co\/fhuGgzP1",
  "id" : 181740176530354177,
  "created_at" : "2012-03-19 13:53:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HealthCare.gov",
      "screen_name" : "HealthCareGov",
      "indices" : [ 3, 17 ],
      "id_str" : "86697288",
      "id" : 86697288
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyCare",
      "indices" : [ 92, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/lTY6wEbd",
      "expanded_url" : "http:\/\/1.usa.gov\/y5xuR9",
      "display_url" : "1.usa.gov\/y5xuR9"
    } ]
  },
  "geo" : { },
  "id_str" : "181729636416364544",
  "text" : "RT @HealthCareGov: Breaking It Down: The Health Care Law &amp; Seniors http:\/\/t.co\/lTY6wEbd #MyCare",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MyCare",
        "indices" : [ 73, 80 ]
      } ],
      "urls" : [ {
        "indices" : [ 52, 72 ],
        "url" : "http:\/\/t.co\/lTY6wEbd",
        "expanded_url" : "http:\/\/1.usa.gov\/y5xuR9",
        "display_url" : "1.usa.gov\/y5xuR9"
      } ]
    },
    "geo" : { },
    "id_str" : "181727372612091905",
    "text" : "Breaking It Down: The Health Care Law &amp; Seniors http:\/\/t.co\/lTY6wEbd #MyCare",
    "id" : 181727372612091905,
    "created_at" : "2012-03-19 13:02:36 +0000",
    "user" : {
      "name" : "HealthCare.gov",
      "screen_name" : "HealthCareGov",
      "protected" : false,
      "id_str" : "86697288",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/528294497105350656\/OXpX0USe_normal.png",
      "id" : 86697288,
      "verified" : true
    }
  },
  "id" : 181729636416364544,
  "created_at" : "2012-03-19 13:11:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/181517696079376384\/photo\/1",
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/XrxpkV2X",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AoThYgPCMAEFg1W.jpg",
      "id_str" : "181517696087764993",
      "id" : 181517696087764993,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AoThYgPCMAEFg1W.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 309,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 309,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 309,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 202,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/XrxpkV2X"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "181517696079376384",
  "text" : "\u201CSince I took office, America\u2019s dependence on foreign oil has gone down every single year.\u201D -President Obama http:\/\/t.co\/XrxpkV2X",
  "id" : 181517696079376384,
  "created_at" : "2012-03-18 23:09:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "energy",
      "indices" : [ 87, 94 ]
    }, {
      "text" : "gasprices",
      "indices" : [ 101, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/AJ6wFnQX",
      "expanded_url" : "http:\/\/youtu.be\/E5Qqvmqgz2A",
      "display_url" : "youtu.be\/E5Qqvmqgz2A"
    } ]
  },
  "geo" : { },
  "id_str" : "181405981908025344",
  "text" : "WATCH: President Obama talks about steps his Administration is taking when it comes to #energy &amp; #gasprices: http:\/\/t.co\/AJ6wFnQX",
  "id" : 181405981908025344,
  "created_at" : "2012-03-18 15:45:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/181174013207388160\/photo\/1",
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/LnzacYGb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AoOozhwCIAAMQAi.jpg",
      "id_str" : "181174013211582464",
      "id" : 181174013211582464,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AoOozhwCIAAMQAi.jpg",
      "sizes" : [ {
        "h" : 399,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 809,
        "resize" : "fit",
        "w" : 1216
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 681,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/LnzacYGb"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/iCeDIRFf",
      "expanded_url" : "http:\/\/1.usa.gov\/FOEM0k",
      "display_url" : "1.usa.gov\/FOEM0k"
    } ]
  },
  "geo" : { },
  "id_str" : "181174013207388160",
  "text" : "President Obama celebrates St. Patty's Day at local Irish bar. Photos: http:\/\/t.co\/iCeDIRFf http:\/\/t.co\/LnzacYGb",
  "id" : 181174013207388160,
  "created_at" : "2012-03-18 00:23:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "NCAA March Madness",
      "screen_name" : "marchmadness",
      "indices" : [ 25, 38 ],
      "id_str" : "202416362",
      "id" : 202416362
    }, {
      "name" : "Syracuse University",
      "screen_name" : "SyracuseU",
      "indices" : [ 48, 58 ],
      "id_str" : "125688706",
      "id" : 125688706
    }, {
      "name" : "K-State",
      "screen_name" : "KState",
      "indices" : [ 64, 71 ],
      "id_str" : "48808600",
      "id" : 48808600
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/VP\/status\/181147840381333504\/photo\/1",
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/se29NjYy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AoORAEYCMAAW-nT.jpg",
      "id_str" : "181147840385527808",
      "id" : 181147840385527808,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AoORAEYCMAAW-nT.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 667,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 667,
        "resize" : "fit",
        "w" : 1000
      } ],
      "display_url" : "pic.twitter.com\/se29NjYy"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "181172901146398721",
  "text" : "RT @VP: PHOTO: VP enjoys @marchmadness  watches @SyracuseU play @KState in Pittsburgh, PA http:\/\/t.co\/se29NjYy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NCAA March Madness",
        "screen_name" : "marchmadness",
        "indices" : [ 17, 30 ],
        "id_str" : "202416362",
        "id" : 202416362
      }, {
        "name" : "Syracuse University",
        "screen_name" : "SyracuseU",
        "indices" : [ 40, 50 ],
        "id_str" : "125688706",
        "id" : 125688706
      }, {
        "name" : "K-State",
        "screen_name" : "KState",
        "indices" : [ 56, 63 ],
        "id_str" : "48808600",
        "id" : 48808600
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/181147840381333504\/photo\/1",
        "indices" : [ 82, 102 ],
        "url" : "http:\/\/t.co\/se29NjYy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AoORAEYCMAAW-nT.jpg",
        "id_str" : "181147840385527808",
        "id" : 181147840385527808,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AoORAEYCMAAW-nT.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        } ],
        "display_url" : "pic.twitter.com\/se29NjYy"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "181147840381333504",
    "text" : "PHOTO: VP enjoys @marchmadness  watches @SyracuseU play @KState in Pittsburgh, PA http:\/\/t.co\/se29NjYy",
    "id" : 181147840381333504,
    "created_at" : "2012-03-17 22:39:46 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 181172901146398721,
  "created_at" : "2012-03-18 00:19:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/181127383481462785\/photo\/1",
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/lb0pNhmv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AoN-ZUgCMAEN8Qd.jpg",
      "id_str" : "181127383489851393",
      "id" : 181127383489851393,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AoN-ZUgCMAEN8Qd.jpg",
      "sizes" : [ {
        "h" : 910,
        "resize" : "fit",
        "w" : 1365
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/lb0pNhmv"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "181127383481462785",
  "text" : "PHOTO: President Obama greets the crowd at the Dubliner, an Irish pub near the Capitol, on St. Patrick's Day: http:\/\/t.co\/lb0pNhmv",
  "id" : 181127383481462785,
  "created_at" : "2012-03-17 21:18:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/181125847229546498\/photo\/1",
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/lSnXb1dH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AoN8_5hCQAASOrs.jpg",
      "id_str" : "181125847237935104",
      "id" : 181125847237935104,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AoN8_5hCQAASOrs.jpg",
      "sizes" : [ {
        "h" : 910,
        "resize" : "fit",
        "w" : 1365
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/lSnXb1dH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "181125847229546498",
  "text" : "Happy St. Patrick's Day! President Obama just stopped by the Dubliner, a local Irish pub, to celebrate: http:\/\/t.co\/lSnXb1dH",
  "id" : 181125847229546498,
  "created_at" : "2012-03-17 21:12:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/fTxhcIZ9",
      "expanded_url" : "http:\/\/1.usa.gov\/wpU12E",
      "display_url" : "1.usa.gov\/wpU12E"
    } ]
  },
  "geo" : { },
  "id_str" : "181116213362032641",
  "text" : "RT @petesouza: Potus has a St Pat's beer at the Dubliner: http:\/\/t.co\/fTxhcIZ9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 43, 63 ],
        "url" : "http:\/\/t.co\/fTxhcIZ9",
        "expanded_url" : "http:\/\/1.usa.gov\/wpU12E",
        "display_url" : "1.usa.gov\/wpU12E"
      } ]
    },
    "geo" : { },
    "id_str" : "181105886624882689",
    "text" : "Potus has a St Pat's beer at the Dubliner: http:\/\/t.co\/fTxhcIZ9",
    "id" : 181105886624882689,
    "created_at" : "2012-03-17 19:53:02 +0000",
    "user" : {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "protected" : false,
      "id_str" : "18215973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771916869808844800\/7d_poH48_normal.jpg",
      "id" : 18215973,
      "verified" : true
    }
  },
  "id" : 181116213362032641,
  "created_at" : "2012-03-17 20:34:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GasPrices",
      "indices" : [ 13, 23 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/AJ6wFnQX",
      "expanded_url" : "http:\/\/youtu.be\/E5Qqvmqgz2A",
      "display_url" : "youtu.be\/E5Qqvmqgz2A"
    }, {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/CDS75iTZ",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/energy\/gasprices",
      "display_url" : "whitehouse.gov\/energy\/gaspric\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "181068639527632897",
  "text" : "The Facts on #GasPrices: Watch President Obama's weekly address: http:\/\/t.co\/AJ6wFnQX See the infographic: http:\/\/t.co\/CDS75iTZ",
  "id" : 181068639527632897,
  "created_at" : "2012-03-17 17:25:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/9ftr14rF",
      "expanded_url" : "http:\/\/ow.ly\/9Ix59",
      "display_url" : "ow.ly\/9Ix59"
    } ]
  },
  "geo" : { },
  "id_str" : "181068109086597121",
  "text" : "\"Your member of Congress should be fighting for you...Not for big oil companies\" -President Obama. Weekly Address: http:\/\/t.co\/9ftr14rF",
  "id" : 181068109086597121,
  "created_at" : "2012-03-17 17:22:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/180768884062814210\/photo\/1",
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/ivxTVvae",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AoI4V6ICAAEcgIx.jpg",
      "id_str" : "180768884079591425",
      "id" : 180768884079591425,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AoI4V6ICAAEcgIx.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/ivxTVvae"
    } ],
    "hashtags" : [ {
      "text" : "energy",
      "indices" : [ 91, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "180768884062814210",
  "text" : "Photo of the Day: President Obama pets 1st dog Bo outside the Oval after returning from an #energy event in MD: http:\/\/t.co\/ivxTVvae",
  "id" : 180768884062814210,
  "created_at" : "2012-03-16 21:33:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "indices" : [ 3, 10 ],
      "id_str" : "44783853",
      "id" : 44783853
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyCare",
      "indices" : [ 24, 31 ]
    }, {
      "text" : "hc",
      "indices" : [ 77, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/1USlDzl8",
      "expanded_url" : "http:\/\/www.healthcare.gov\/mycare",
      "display_url" : "healthcare.gov\/mycare"
    } ]
  },
  "geo" : { },
  "id_str" : "180739091195899904",
  "text" : "RT @HHSGov: Introducing #MyCare, a new initiative to share stories about the #hc law and you. Check it out! http:\/\/t.co\/1USlDzl8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MyCare",
        "indices" : [ 12, 19 ]
      }, {
        "text" : "hc",
        "indices" : [ 65, 68 ]
      } ],
      "urls" : [ {
        "indices" : [ 96, 116 ],
        "url" : "http:\/\/t.co\/1USlDzl8",
        "expanded_url" : "http:\/\/www.healthcare.gov\/mycare",
        "display_url" : "healthcare.gov\/mycare"
      } ]
    },
    "geo" : { },
    "id_str" : "180702120452960258",
    "text" : "Introducing #MyCare, a new initiative to share stories about the #hc law and you. Check it out! http:\/\/t.co\/1USlDzl8",
    "id" : 180702120452960258,
    "created_at" : "2012-03-16 17:08:37 +0000",
    "user" : {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "protected" : false,
      "id_str" : "44783853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567350542326718464\/FXOsgyA7_normal.jpeg",
      "id" : 44783853,
      "verified" : true
    }
  },
  "id" : 180739091195899904,
  "created_at" : "2012-03-16 19:35:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/180677826754789376\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/z3sl1Ckg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AoHlhrLCQAEpI7q.jpg",
      "id_str" : "180677826758983681",
      "id" : 180677826758983681,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AoHlhrLCQAEpI7q.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 309,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 309,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 309,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 202,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/z3sl1Ckg"
    } ],
    "hashtags" : [ {
      "text" : "oil",
      "indices" : [ 46, 50 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/0zpWSx8z",
      "expanded_url" : "http:\/\/1.usa.gov\/AsWr9f",
      "display_url" : "1.usa.gov\/AsWr9f"
    } ]
  },
  "geo" : { },
  "id_str" : "180677826754789376",
  "text" : "Every year Obama has been in office, domestic #oil production is \u2B06 &amp; foreign oil imports are \u2B07 http:\/\/t.co\/0zpWSx8z http:\/\/t.co\/z3sl1Ckg",
  "id" : 180677826754789376,
  "created_at" : "2012-03-16 15:32:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/180666636725006337\/photo\/1",
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/cSSwHCbG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AoHbWVFCMAAPmIO.jpg",
      "id_str" : "180666636733394944",
      "id" : 180666636733394944,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AoHbWVFCMAAPmIO.jpg",
      "sizes" : [ {
        "h" : 722,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 971,
        "resize" : "fit",
        "w" : 1378
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 423,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/cSSwHCbG"
    } ],
    "hashtags" : [ {
      "text" : "NCAA",
      "indices" : [ 45, 50 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/3MWK2dyn",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2012\/03\/16\/president-obama-s-picks-2012-ncaa-women-s-basketball-tournament",
      "display_url" : "whitehouse.gov\/blog\/2012\/03\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "180666636725006337",
  "text" : "Check out the President\u2019s picks for the 2012 #NCAA women\u2019s basketball tournament: http:\/\/t.co\/3MWK2dyn Full bracket: http:\/\/t.co\/cSSwHCbG",
  "id" : 180666636725006337,
  "created_at" : "2012-03-16 14:47:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Carson",
      "screen_name" : "JonCarson44",
      "indices" : [ 3, 15 ],
      "id_str" : "1287388789",
      "id" : 1287388789
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 31, 42 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "180653845364486144",
  "text" : "RT @JonCarson44: Morning C-bus @whitehouse Comm Partnership Summit w @MarthaGSA facilitating innovative open space process I'm joining c ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 14, 25 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHSummit",
        "indices" : [ 130, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "180640295787044864",
    "text" : "Morning C-bus @whitehouse Comm Partnership Summit w @MarthaGSA facilitating innovative open space process I'm joining convo using #WHSummit",
    "id" : 180640295787044864,
    "created_at" : "2012-03-16 13:02:57 +0000",
    "user" : {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "protected" : false,
      "id_str" : "369232105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623146355767140352\/58sqoVrw_normal.jpg",
      "id" : 369232105,
      "verified" : true
    }
  },
  "id" : 180653845364486144,
  "created_at" : "2012-03-16 13:56:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 79, 90 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/180432017874362368\/photo\/1",
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/gZExyRUJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AoEF9twCIAAbrj7.jpg",
      "id_str" : "180432017882750976",
      "id" : 180432017882750976,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AoEF9twCIAAbrj7.jpg",
      "sizes" : [ {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1920,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/gZExyRUJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/WT5Ytx0u",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/photos-and-video\/photogallery\/prime-minister-david-cameron-united-kingdom-official-visit",
      "display_url" : "whitehouse.gov\/photos-and-vid\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "180432017874362368",
  "text" : "New slideshow: President Obama welcomes UK Prime Minister David Cameron to the @whitehouse: http:\/\/t.co\/WT5Ytx0u http:\/\/t.co\/gZExyRUJ",
  "id" : 180432017874362368,
  "created_at" : "2012-03-15 23:15:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 35, 46 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/YPc2mVFH",
      "expanded_url" : "http:\/\/ow.ly\/9GsFP",
      "display_url" : "ow.ly\/9GsFP"
    } ]
  },
  "geo" : { },
  "id_str" : "180394316232011777",
  "text" : "Interested in an internship at the @WhiteHouse? We're now accepting applications for Fall 2012. Apply here: http:\/\/t.co\/YPc2mVFH",
  "id" : 180394316232011777,
  "created_at" : "2012-03-15 20:45:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SEGrinnell",
      "screen_name" : "SEGrinnell",
      "indices" : [ 76, 87 ],
      "id_str" : "509564408",
      "id" : 509564408
    }, {
      "name" : "Thach or Tak Nguyen",
      "screen_name" : "takster718",
      "indices" : [ 88, 99 ],
      "id_str" : "35549509",
      "id" : 35549509
    }, {
      "name" : "Full Circle",
      "screen_name" : "UAFullCircle",
      "indices" : [ 100, 113 ],
      "id_str" : "306395283",
      "id" : 306395283
    }, {
      "name" : "Ryan Harb",
      "screen_name" : "ryanharb",
      "indices" : [ 114, 123 ],
      "id_str" : "87305478",
      "id" : 87305478
    }, {
      "name" : "Ted Gonder",
      "screen_name" : "tedgonder",
      "indices" : [ 124, 134 ],
      "id_str" : "60741940",
      "id" : 60741940
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChamps",
      "indices" : [ 12, 21 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "180377091840290817",
  "text" : "Congrats to #WHChamps of Change for their outstanding leadership on campus! @SEGrinnell @takster718 @UAFullCircle @ryanharb @tedgonder",
  "id" : 180377091840290817,
  "created_at" : "2012-03-15 19:37:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MTV Issues",
      "screen_name" : "MTVAct",
      "indices" : [ 3, 10 ],
      "id_str" : "3028398526",
      "id" : 3028398526
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/MTVact\/status\/180372496711819264\/photo\/1",
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/nBviZjxW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AoDP1IICIAAPNE7.jpg",
      "id_str" : "180372496716013568",
      "id" : 180372496716013568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AoDP1IICIAAPNE7.jpg",
      "sizes" : [ {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/nBviZjxW"
    } ],
    "hashtags" : [ {
      "text" : "WHchamps",
      "indices" : [ 43, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "180372610008354818",
  "text" : "RT @MTVact: The President is hereeeee!!!!! #WHchamps http:\/\/t.co\/nBviZjxW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MTVact\/status\/180372496711819264\/photo\/1",
        "indices" : [ 41, 61 ],
        "url" : "http:\/\/t.co\/nBviZjxW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AoDP1IICIAAPNE7.jpg",
        "id_str" : "180372496716013568",
        "id" : 180372496716013568,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AoDP1IICIAAPNE7.jpg",
        "sizes" : [ {
          "h" : 448,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 765,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 254,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 765,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/nBviZjxW"
      } ],
      "hashtags" : [ {
        "text" : "WHchamps",
        "indices" : [ 31, 40 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "180372496711819264",
    "text" : "The President is hereeeee!!!!! #WHchamps http:\/\/t.co\/nBviZjxW",
    "id" : 180372496711819264,
    "created_at" : "2012-03-15 19:18:49 +0000",
    "user" : {
      "name" : "MTV Politics",
      "screen_name" : "MTVPolitics",
      "protected" : false,
      "id_str" : "208697224",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/712634534743973890\/rv61pNvM_normal.jpg",
      "id" : 208697224,
      "verified" : true
    }
  },
  "id" : 180372610008354818,
  "created_at" : "2012-03-15 19:19:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChamps",
      "indices" : [ 46, 55 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/hhNoX4fh",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "180372507130470400",
  "text" : "Happening now: President Obama just surprised #WHChamps! Watch live: http:\/\/t.co\/hhNoX4fh",
  "id" : 180372507130470400,
  "created_at" : "2012-03-15 19:18:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MTV Issues",
      "screen_name" : "MTVAct",
      "indices" : [ 3, 10 ],
      "id_str" : "3028398526",
      "id" : 3028398526
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 75, 86 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "180347179846737920",
  "text" : "RT @MTVact: We're in DC to celebrate the Campus Champions of Change at the @whitehouse, and you can watch later today 2:50pm ET! http:\/\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 63, 74 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 137 ],
        "url" : "http:\/\/t.co\/5MqlM4Wl",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/live",
        "display_url" : "whitehouse.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "180325911365820416",
    "text" : "We're in DC to celebrate the Campus Champions of Change at the @whitehouse, and you can watch later today 2:50pm ET! http:\/\/t.co\/5MqlM4Wl",
    "id" : 180325911365820416,
    "created_at" : "2012-03-15 16:13:42 +0000",
    "user" : {
      "name" : "MTV Politics",
      "screen_name" : "MTVPolitics",
      "protected" : false,
      "id_str" : "208697224",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/712634534743973890\/rv61pNvM_normal.jpg",
      "id" : 208697224,
      "verified" : true
    }
  },
  "id" : 180347179846737920,
  "created_at" : "2012-03-15 17:38:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MD Democratic Party",
      "screen_name" : "mddems",
      "indices" : [ 3, 10 ],
      "id_str" : "20100423",
      "id" : 20100423
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "obamainmd",
      "indices" : [ 112, 122 ]
    }, {
      "text" : "mdpolitics",
      "indices" : [ 123, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "180318172786860032",
  "text" : "RT @mddems: As Americans we look forward &amp; have faith in the future. We're good at being ahead of the curve #obamainmd #mdpolitics h ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/mddems\/status\/180316441080365056\/photo\/1",
        "indices" : [ 123, 143 ],
        "url" : "http:\/\/t.co\/khi83v0D",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AoCc2QpCAAElY99.jpg",
        "id_str" : "180316441088753665",
        "id" : 180316441088753665,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AoCc2QpCAAElY99.jpg",
        "sizes" : [ {
          "h" : 1365,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 2592,
          "resize" : "fit",
          "w" : 1944
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/khi83v0D"
      } ],
      "hashtags" : [ {
        "text" : "obamainmd",
        "indices" : [ 100, 110 ]
      }, {
        "text" : "mdpolitics",
        "indices" : [ 111, 122 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "180316441080365056",
    "text" : "As Americans we look forward &amp; have faith in the future. We're good at being ahead of the curve #obamainmd #mdpolitics http:\/\/t.co\/khi83v0D",
    "id" : 180316441080365056,
    "created_at" : "2012-03-15 15:36:06 +0000",
    "user" : {
      "name" : "MD Democratic Party",
      "screen_name" : "mddems",
      "protected" : false,
      "id_str" : "20100423",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/453896798231199744\/miS_jDMl_normal.jpeg",
      "id" : 20100423,
      "verified" : true
    }
  },
  "id" : 180318172786860032,
  "created_at" : "2012-03-15 15:42:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamainMD",
      "indices" : [ 79, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "180315937625485312",
  "text" : "RT @WHLive: President Obama: \"It\u2019s time for this oil industry giveaway to end\" #ObamainMD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ObamainMD",
        "indices" : [ 67, 77 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "180315858709647360",
    "text" : "President Obama: \"It\u2019s time for this oil industry giveaway to end\" #ObamainMD",
    "id" : 180315858709647360,
    "created_at" : "2012-03-15 15:33:45 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 180315937625485312,
  "created_at" : "2012-03-15 15:34:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamainMD",
      "indices" : [ 120, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "180313926880337920",
  "text" : "RT @WHLive: President Obama: \"Since I took office, America\u2019s dependence on foreign oil has gone down every single year\" #ObamainMD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ObamainMD",
        "indices" : [ 108, 118 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "180313884383641600",
    "text" : "President Obama: \"Since I took office, America\u2019s dependence on foreign oil has gone down every single year\" #ObamainMD",
    "id" : 180313884383641600,
    "created_at" : "2012-03-15 15:25:54 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 180313926880337920,
  "created_at" : "2012-03-15 15:26:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamainMD",
      "indices" : [ 12, 22 ]
    }, {
      "text" : "jobs",
      "indices" : [ 53, 58 ]
    }, {
      "text" : "energy",
      "indices" : [ 108, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "180313541704826880",
  "text" : "RT @WHLive: #ObamainMD: \"Thousands of Americans have #jobs right now because we\u2019ve doubled the use of clean #energy in this country\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ObamainMD",
        "indices" : [ 0, 10 ]
      }, {
        "text" : "jobs",
        "indices" : [ 41, 46 ]
      }, {
        "text" : "energy",
        "indices" : [ 96, 103 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "180313486885273601",
    "text" : "#ObamainMD: \"Thousands of Americans have #jobs right now because we\u2019ve doubled the use of clean #energy in this country\"",
    "id" : 180313486885273601,
    "created_at" : "2012-03-15 15:24:19 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 180313541704826880,
  "created_at" : "2012-03-15 15:24:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "180313270031364097",
  "text" : "RT @WHLive: President Obama: [We need] an all-of-the-above strategy for the 21st century that develops every source of American-made #en ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "energy",
        "indices" : [ 121, 128 ]
      }, {
        "text" : "ObamainMD",
        "indices" : [ 129, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "180313207909519362",
    "text" : "President Obama: [We need] an all-of-the-above strategy for the 21st century that develops every source of American-made #energy #ObamainMD",
    "id" : 180313207909519362,
    "created_at" : "2012-03-15 15:23:13 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 180313270031364097,
  "created_at" : "2012-03-15 15:23:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "180311234426576896",
  "text" : "RT @WHLive: President Obama: \"Under my Administration, America is producing more oil today than at any time in the last 8 yrs. That's a  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ObamainMD",
        "indices" : [ 130, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "180311164851466240",
    "text" : "President Obama: \"Under my Administration, America is producing more oil today than at any time in the last 8 yrs. That's a fact\" #ObamainMD",
    "id" : 180311164851466240,
    "created_at" : "2012-03-15 15:15:06 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 180311234426576896,
  "created_at" : "2012-03-15 15:15:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 119, 126 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "energy",
      "indices" : [ 52, 59 ]
    }, {
      "text" : "gasprices",
      "indices" : [ 66, 76 ]
    }, {
      "text" : "ObamainMD",
      "indices" : [ 127, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "180308512222609408",
  "text" : "Happening now: President Obama talks about American #energy &amp; #gasprices. Watch live: http:\/\/t.co\/u95y7hhB Follow: @WHLive #ObamainMD",
  "id" : 180308512222609408,
  "created_at" : "2012-03-15 15:04:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Carson",
      "screen_name" : "JonCarson44",
      "indices" : [ 3, 15 ],
      "id_str" : "1287388789",
      "id" : 1287388789
    }, {
      "name" : "Chirag Sagar",
      "screen_name" : "chiragdsagar",
      "indices" : [ 26, 39 ],
      "id_str" : "275921580",
      "id" : 275921580
    }, {
      "name" : "Ryan Harb",
      "screen_name" : "ryanharb",
      "indices" : [ 40, 49 ],
      "id_str" : "87305478",
      "id" : 87305478
    }, {
      "name" : "Full Circle",
      "screen_name" : "UAFullCircle",
      "indices" : [ 50, 63 ],
      "id_str" : "306395283",
      "id" : 306395283
    }, {
      "name" : "Thach or Tak Nguyen",
      "screen_name" : "takster718",
      "indices" : [ 64, 75 ],
      "id_str" : "35549509",
      "id" : 35549509
    }, {
      "name" : "SEGrinnell",
      "screen_name" : "SEGrinnell",
      "indices" : [ 76, 87 ],
      "id_str" : "509564408",
      "id" : 509564408
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHCHamps",
      "indices" : [ 88, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "180302813702787072",
  "text" : "RT @JonCarson44: Honoring @chiragdsagar @ryanharb @UAFullCircle @takster718 @SEGrinnell #WHCHamps Pres\"I hope their brilliant example wi ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Chirag Sagar",
        "screen_name" : "chiragdsagar",
        "indices" : [ 9, 22 ],
        "id_str" : "275921580",
        "id" : 275921580
      }, {
        "name" : "Ryan Harb",
        "screen_name" : "ryanharb",
        "indices" : [ 23, 32 ],
        "id_str" : "87305478",
        "id" : 87305478
      }, {
        "name" : "Full Circle",
        "screen_name" : "UAFullCircle",
        "indices" : [ 33, 46 ],
        "id_str" : "306395283",
        "id" : 306395283
      }, {
        "name" : "Thach or Tak Nguyen",
        "screen_name" : "takster718",
        "indices" : [ 47, 58 ],
        "id_str" : "35549509",
        "id" : 35549509
      }, {
        "name" : "SEGrinnell",
        "screen_name" : "SEGrinnell",
        "indices" : [ 59, 70 ],
        "id_str" : "509564408",
        "id" : 509564408
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHCHamps",
        "indices" : [ 71, 80 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "180281087522635776",
    "text" : "Honoring @chiragdsagar @ryanharb @UAFullCircle @takster718 @SEGrinnell #WHCHamps Pres\"I hope their brilliant example will inspire Americans\"",
    "id" : 180281087522635776,
    "created_at" : "2012-03-15 13:15:35 +0000",
    "user" : {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "protected" : false,
      "id_str" : "369232105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623146355767140352\/58sqoVrw_normal.jpg",
      "id" : 369232105,
      "verified" : true
    }
  },
  "id" : 180302813702787072,
  "created_at" : "2012-03-15 14:41:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 3, 13 ],
      "id_str" : "9624742",
      "id" : 9624742
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SecClinton",
      "indices" : [ 25, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "180301550701387778",
  "text" : "RT @StateDept: Live Now: #SecClinton chairs the President's Interagency Task Force to Monitor and Combat Trafficking in Persons. http:\/\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SecClinton",
        "indices" : [ 10, 21 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 134 ],
        "url" : "http:\/\/t.co\/HUZms8Lq",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "180300815251144706",
    "text" : "Live Now: #SecClinton chairs the President's Interagency Task Force to Monitor and Combat Trafficking in Persons. http:\/\/t.co\/HUZms8Lq",
    "id" : 180300815251144706,
    "created_at" : "2012-03-15 14:33:58 +0000",
    "user" : {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "protected" : false,
      "id_str" : "9624742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724612605185282048\/1rEfkXDZ_normal.jpg",
      "id" : 9624742,
      "verified" : true
    }
  },
  "id" : 180301550701387778,
  "created_at" : "2012-03-15 14:36:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "energy",
      "indices" : [ 33, 40 ]
    }, {
      "text" : "gasprices",
      "indices" : [ 47, 57 ]
    }, {
      "text" : "ObamainMD",
      "indices" : [ 131, 141 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "180295661831462912",
  "text" : "Today, President Obama speaks on #energy &amp; #gasprices at Prince George's Community College. Watch @ 11ET: http:\/\/t.co\/u95y7hhB #ObamainMD",
  "id" : 180295661831462912,
  "created_at" : "2012-03-15 14:13:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/MJI346qh",
      "expanded_url" : "http:\/\/1.usa.gov\/yCdvsP",
      "display_url" : "1.usa.gov\/yCdvsP"
    } ]
  },
  "geo" : { },
  "id_str" : "180284823116587008",
  "text" : "RT @petesouza: Slide show from yesterday's state arrival w PM Cameron: http:\/\/t.co\/MJI346qh (photos from the dinner will be updated soon)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 76 ],
        "url" : "http:\/\/t.co\/MJI346qh",
        "expanded_url" : "http:\/\/1.usa.gov\/yCdvsP",
        "display_url" : "1.usa.gov\/yCdvsP"
      } ]
    },
    "geo" : { },
    "id_str" : "180268558293540864",
    "text" : "Slide show from yesterday's state arrival w PM Cameron: http:\/\/t.co\/MJI346qh (photos from the dinner will be updated soon)",
    "id" : 180268558293540864,
    "created_at" : "2012-03-15 12:25:48 +0000",
    "user" : {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "protected" : false,
      "id_str" : "18215973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771916869808844800\/7d_poH48_normal.jpg",
      "id" : 18215973,
      "verified" : true
    }
  },
  "id" : 180284823116587008,
  "created_at" : "2012-03-15 13:30:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 34, 45 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/Sf00EQ9W",
      "expanded_url" : "http:\/\/youtu.be\/z7Ek5BzOgBc",
      "display_url" : "youtu.be\/z7Ek5BzOgBc"
    } ]
  },
  "geo" : { },
  "id_str" : "180080131879092224",
  "text" : "What's on the menu tonight? Watch @whitehouse chefs prep for the UK State Dinner: http:\/\/t.co\/Sf00EQ9W",
  "id" : 180080131879092224,
  "created_at" : "2012-03-14 23:57:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Storify",
      "screen_name" : "Storify",
      "indices" : [ 62, 70 ],
      "id_str" : "17814938",
      "id" : 17814938
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHTweetup",
      "indices" : [ 36, 46 ]
    }, {
      "text" : "CameroninUS",
      "indices" : [ 107, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/yEXwkumW",
      "expanded_url" : "http:\/\/sfy.co\/h61",
      "display_url" : "sfy.co\/h61"
    } ]
  },
  "geo" : { },
  "id_str" : "180075934928478209",
  "text" : "Just posted the UK Arrival Ceremony #WHTweetup experience via @storify. Check it out: http:\/\/t.co\/yEXwkumW #CameroninUS",
  "id" : 180075934928478209,
  "created_at" : "2012-03-14 23:40:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/storify.com\" rel=\"nofollow\"\u003EStorify\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 0, 11 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    }, {
      "name" : "Emily Jolley",
      "screen_name" : "emilybjolley",
      "indices" : [ 12, 25 ],
      "id_str" : "41723054",
      "id" : 41723054
    }, {
      "name" : "Storify",
      "screen_name" : "Storify",
      "indices" : [ 88, 96 ],
      "id_str" : "17814938",
      "id" : 17814938
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHTweetup",
      "indices" : [ 62, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/yEXwkumW",
      "expanded_url" : "http:\/\/sfy.co\/h61",
      "display_url" : "sfy.co\/h61"
    } ]
  },
  "geo" : { },
  "id_str" : "180075424049672193",
  "in_reply_to_user_id" : 131144091,
  "text" : "@pfeiffer44 @emilybjolley Just posted the UK Arrival Ceremony #WHTweetup experience via @storify. Check it out:  http:\/\/t.co\/yEXwkumW",
  "id" : 180075424049672193,
  "created_at" : "2012-03-14 23:38:21 +0000",
  "in_reply_to_screen_name" : "Goldman44",
  "in_reply_to_user_id_str" : "131144091",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/storify.com\" rel=\"nofollow\"\u003EStorify\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt McDermott",
      "screen_name" : "mattmfm",
      "indices" : [ 0, 8 ],
      "id_str" : "15418628",
      "id" : 15418628
    }, {
      "name" : "Kenneth",
      "screen_name" : "terp11",
      "indices" : [ 9, 16 ],
      "id_str" : "17604107",
      "id" : 17604107
    }, {
      "name" : "Vicky Lisle",
      "screen_name" : "vklisle",
      "indices" : [ 17, 25 ],
      "id_str" : "25946700",
      "id" : 25946700
    }, {
      "name" : "Storify",
      "screen_name" : "Storify",
      "indices" : [ 88, 96 ],
      "id_str" : "17814938",
      "id" : 17814938
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHTweetup",
      "indices" : [ 62, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/yEXwkumW",
      "expanded_url" : "http:\/\/sfy.co\/h61",
      "display_url" : "sfy.co\/h61"
    } ]
  },
  "geo" : { },
  "id_str" : "180075207980105730",
  "in_reply_to_user_id" : 15418628,
  "text" : "@mattmfm @terp11 @vklisle Just posted the UK Arrival Ceremony #WHTweetup experience via @storify. Check it out:  http:\/\/t.co\/yEXwkumW",
  "id" : 180075207980105730,
  "created_at" : "2012-03-14 23:37:29 +0000",
  "in_reply_to_screen_name" : "mattmfm",
  "in_reply_to_user_id_str" : "15418628",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/storify.com\" rel=\"nofollow\"\u003EStorify\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy D. Thompson",
      "screen_name" : "Reelpolitik",
      "indices" : [ 0, 12 ],
      "id_str" : "6226232",
      "id" : 6226232
    }, {
      "name" : "San Rafael Police",
      "screen_name" : "SanRafaelPolice",
      "indices" : [ 13, 29 ],
      "id_str" : "27241813",
      "id" : 27241813
    }, {
      "name" : "Storify",
      "screen_name" : "Storify",
      "indices" : [ 92, 100 ],
      "id_str" : "17814938",
      "id" : 17814938
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHTweetup",
      "indices" : [ 66, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/yEXwkumW",
      "expanded_url" : "http:\/\/sfy.co\/h61",
      "display_url" : "sfy.co\/h61"
    } ]
  },
  "geo" : { },
  "id_str" : "180075208034619392",
  "in_reply_to_user_id" : 6226232,
  "text" : "@Reelpolitik @SanRafaelPolice Just posted the UK Arrival Ceremony #WHTweetup experience via @storify. Check it out:  http:\/\/t.co\/yEXwkumW",
  "id" : 180075208034619392,
  "created_at" : "2012-03-14 23:37:29 +0000",
  "in_reply_to_screen_name" : "Reelpolitik",
  "in_reply_to_user_id_str" : "6226232",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/storify.com\" rel=\"nofollow\"\u003EStorify\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mieke eoyang",
      "screen_name" : "MiekeEoyang",
      "indices" : [ 0, 12 ],
      "id_str" : "297632458",
      "id" : 297632458
    }, {
      "name" : "UK Prime Minister",
      "screen_name" : "Number10gov",
      "indices" : [ 13, 25 ],
      "id_str" : "14224719",
      "id" : 14224719
    }, {
      "name" : "Storify",
      "screen_name" : "Storify",
      "indices" : [ 88, 96 ],
      "id_str" : "17814938",
      "id" : 17814938
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHTweetup",
      "indices" : [ 62, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/yEXwkumW",
      "expanded_url" : "http:\/\/sfy.co\/h61",
      "display_url" : "sfy.co\/h61"
    } ]
  },
  "geo" : { },
  "id_str" : "180075157195468800",
  "in_reply_to_user_id" : 297632458,
  "text" : "@MiekeEoyang @number10gov Just posted the UK Arrival Ceremony #WHTweetup experience via @storify. Check it out:  http:\/\/t.co\/yEXwkumW",
  "id" : 180075157195468800,
  "created_at" : "2012-03-14 23:37:17 +0000",
  "in_reply_to_screen_name" : "MiekeEoyang",
  "in_reply_to_user_id_str" : "297632458",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/storify.com\" rel=\"nofollow\"\u003EStorify\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rebecca",
      "screen_name" : "RebeccaREvans",
      "indices" : [ 0, 14 ],
      "id_str" : "14229975",
      "id" : 14229975
    }, {
      "name" : "Greg Licamele",
      "screen_name" : "g_r_e_g",
      "indices" : [ 15, 23 ],
      "id_str" : "15069019",
      "id" : 15069019
    }, {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 24, 32 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    }, {
      "name" : "Storify",
      "screen_name" : "Storify",
      "indices" : [ 95, 103 ],
      "id_str" : "17814938",
      "id" : 17814938
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHTweetup",
      "indices" : [ 69, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/yEXwkumW",
      "expanded_url" : "http:\/\/sfy.co\/h61",
      "display_url" : "sfy.co\/h61"
    } ]
  },
  "geo" : { },
  "id_str" : "180075157359046656",
  "in_reply_to_user_id" : 14229975,
  "text" : "@RebeccaREvans @g_r_e_g @macon44 Just posted the UK Arrival Ceremony #WHTweetup experience via @storify. Check it out:  http:\/\/t.co\/yEXwkumW",
  "id" : 180075157359046656,
  "created_at" : "2012-03-14 23:37:17 +0000",
  "in_reply_to_screen_name" : "RebeccaREvans",
  "in_reply_to_user_id_str" : "14229975",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/storify.com\" rel=\"nofollow\"\u003EStorify\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Esther Ngumbi",
      "screen_name" : "EstherNgumbi",
      "indices" : [ 0, 13 ],
      "id_str" : "359037337",
      "id" : 359037337
    }, {
      "name" : "Joy Cook",
      "screen_name" : "JoyCookPR",
      "indices" : [ 14, 24 ],
      "id_str" : "16049954",
      "id" : 16049954
    }, {
      "name" : "Storify",
      "screen_name" : "Storify",
      "indices" : [ 87, 95 ],
      "id_str" : "17814938",
      "id" : 17814938
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHTweetup",
      "indices" : [ 61, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/yEXwkumW",
      "expanded_url" : "http:\/\/sfy.co\/h61",
      "display_url" : "sfy.co\/h61"
    } ]
  },
  "geo" : { },
  "id_str" : "180074955764011008",
  "in_reply_to_user_id" : 359037337,
  "text" : "@EstherNgumbi @JoyCookPR Just posted the UK Arrival Ceremony #WHTweetup experience via @storify. Check it out:  http:\/\/t.co\/yEXwkumW",
  "id" : 180074955764011008,
  "created_at" : "2012-03-14 23:36:29 +0000",
  "in_reply_to_screen_name" : "EstherNgumbi",
  "in_reply_to_user_id_str" : "359037337",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/storify.com\" rel=\"nofollow\"\u003EStorify\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "globalsultana",
      "screen_name" : "globalsultana",
      "indices" : [ 0, 14 ],
      "id_str" : "16935523",
      "id" : 16935523
    }, {
      "name" : "Storify",
      "screen_name" : "Storify",
      "indices" : [ 77, 85 ],
      "id_str" : "17814938",
      "id" : 17814938
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHTweetup",
      "indices" : [ 51, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/yEXwkumW",
      "expanded_url" : "http:\/\/sfy.co\/h61",
      "display_url" : "sfy.co\/h61"
    } ]
  },
  "geo" : { },
  "id_str" : "180074955898224641",
  "in_reply_to_user_id" : 16935523,
  "text" : "@globalsultana Just posted the UK Arrival Ceremony #WHTweetup experience via @storify. Check it out:  http:\/\/t.co\/yEXwkumW",
  "id" : 180074955898224641,
  "created_at" : "2012-03-14 23:36:29 +0000",
  "in_reply_to_screen_name" : "globalsultana",
  "in_reply_to_user_id_str" : "16935523",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/storify.com\" rel=\"nofollow\"\u003EStorify\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephanie Dahle",
      "screen_name" : "StephanieDahle",
      "indices" : [ 0, 15 ],
      "id_str" : "49844221",
      "id" : 49844221
    }, {
      "name" : "Jon Carson",
      "screen_name" : "JonCarson44",
      "indices" : [ 16, 28 ],
      "id_str" : "1287388789",
      "id" : 1287388789
    }, {
      "name" : "Storify",
      "screen_name" : "Storify",
      "indices" : [ 91, 99 ],
      "id_str" : "17814938",
      "id" : 17814938
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHTweetup",
      "indices" : [ 65, 75 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/yEXwkumW",
      "expanded_url" : "http:\/\/sfy.co\/h61",
      "display_url" : "sfy.co\/h61"
    } ]
  },
  "geo" : { },
  "id_str" : "180074955906629633",
  "in_reply_to_user_id" : 49844221,
  "text" : "@StephanieDahle @JonCarson44 Just posted the UK Arrival Ceremony #WHTweetup experience via @storify. Check it out:  http:\/\/t.co\/yEXwkumW",
  "id" : 180074955906629633,
  "created_at" : "2012-03-14 23:36:29 +0000",
  "in_reply_to_screen_name" : "StephanieDahle",
  "in_reply_to_user_id_str" : "49844221",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/storify.com\" rel=\"nofollow\"\u003EStorify\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Dowd",
      "screen_name" : "Marvin_Mathew",
      "indices" : [ 0, 14 ],
      "id_str" : "3791525355",
      "id" : 3791525355
    }, {
      "name" : "Karen Hopper",
      "screen_name" : "lalaforte",
      "indices" : [ 15, 25 ],
      "id_str" : "60642327",
      "id" : 60642327
    }, {
      "name" : "Storify",
      "screen_name" : "Storify",
      "indices" : [ 88, 96 ],
      "id_str" : "17814938",
      "id" : 17814938
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHTweetup",
      "indices" : [ 62, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/yEXwkumW",
      "expanded_url" : "http:\/\/sfy.co\/h61",
      "display_url" : "sfy.co\/h61"
    } ]
  },
  "geo" : { },
  "id_str" : "180074877431197696",
  "in_reply_to_user_id" : 156653431,
  "text" : "@Marvin_Mathew @lalaforte Just posted the UK Arrival Ceremony #WHTweetup experience via @storify. Check it out:  http:\/\/t.co\/yEXwkumW",
  "id" : 180074877431197696,
  "created_at" : "2012-03-14 23:36:11 +0000",
  "in_reply_to_screen_name" : "MarvinJMathew",
  "in_reply_to_user_id_str" : "156653431",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/storify.com\" rel=\"nofollow\"\u003EStorify\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jessica ellen",
      "screen_name" : "jessicaellen11",
      "indices" : [ 0, 15 ],
      "id_str" : "1284080856",
      "id" : 1284080856
    }, {
      "name" : "Brian Feldman",
      "screen_name" : "BrianFeldman",
      "indices" : [ 16, 29 ],
      "id_str" : "14089072",
      "id" : 14089072
    }, {
      "name" : "Storify",
      "screen_name" : "Storify",
      "indices" : [ 92, 100 ],
      "id_str" : "17814938",
      "id" : 17814938
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHTweetup",
      "indices" : [ 66, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/yEXwkumW",
      "expanded_url" : "http:\/\/sfy.co\/h61",
      "display_url" : "sfy.co\/h61"
    } ]
  },
  "geo" : { },
  "id_str" : "180074880144916480",
  "in_reply_to_user_id" : 141092727,
  "text" : "@jessicaellen11 @BrianFeldman Just posted the UK Arrival Ceremony #WHTweetup experience via @storify. Check it out:  http:\/\/t.co\/yEXwkumW",
  "id" : 180074880144916480,
  "created_at" : "2012-03-14 23:36:11 +0000",
  "in_reply_to_screen_name" : "jehewkin",
  "in_reply_to_user_id_str" : "141092727",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/storify.com\" rel=\"nofollow\"\u003EStorify\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James Barbour",
      "screen_name" : "jamesbarbour",
      "indices" : [ 0, 13 ],
      "id_str" : "10460222",
      "id" : 10460222
    }, {
      "name" : "Storify",
      "screen_name" : "Storify",
      "indices" : [ 76, 84 ],
      "id_str" : "17814938",
      "id" : 17814938
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHTweetup",
      "indices" : [ 50, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/yEXwkumW",
      "expanded_url" : "http:\/\/sfy.co\/h61",
      "display_url" : "sfy.co\/h61"
    } ]
  },
  "geo" : { },
  "id_str" : "180074603052412929",
  "in_reply_to_user_id" : 10460222,
  "text" : "@jamesbarbour Just posted the UK Arrival Ceremony #WHTweetup experience via @storify. Check it out:  http:\/\/t.co\/yEXwkumW",
  "id" : 180074603052412929,
  "created_at" : "2012-03-14 23:35:05 +0000",
  "in_reply_to_screen_name" : "jamesbarbour",
  "in_reply_to_user_id_str" : "10460222",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/storify.com\" rel=\"nofollow\"\u003EStorify\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Travel - State Dept",
      "screen_name" : "TravelGov",
      "indices" : [ 0, 10 ],
      "id_str" : "15649433",
      "id" : 15649433
    }, {
      "name" : "UK Prime Minister",
      "screen_name" : "Number10gov",
      "indices" : [ 11, 23 ],
      "id_str" : "14224719",
      "id" : 14224719
    }, {
      "name" : "Storify",
      "screen_name" : "Storify",
      "indices" : [ 86, 94 ],
      "id_str" : "17814938",
      "id" : 17814938
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHTweetup",
      "indices" : [ 60, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/yEXwkumW",
      "expanded_url" : "http:\/\/sfy.co\/h61",
      "display_url" : "sfy.co\/h61"
    } ]
  },
  "geo" : { },
  "id_str" : "180074600418381825",
  "in_reply_to_user_id" : 15649433,
  "text" : "@TravelGov @Number10gov Just posted the UK Arrival Ceremony #WHTweetup experience via @storify. Check it out:  http:\/\/t.co\/yEXwkumW",
  "id" : 180074600418381825,
  "created_at" : "2012-03-14 23:35:05 +0000",
  "in_reply_to_screen_name" : "TravelGov",
  "in_reply_to_user_id_str" : "15649433",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/storify.com\" rel=\"nofollow\"\u003EStorify\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Lynn Smith",
      "screen_name" : "alswrite",
      "indices" : [ 0, 9 ],
      "id_str" : "165537211",
      "id" : 165537211
    }, {
      "name" : "Michelle Holshue, RN",
      "screen_name" : "PHNurseMichelle",
      "indices" : [ 10, 26 ],
      "id_str" : "303625906",
      "id" : 303625906
    }, {
      "name" : "Storify",
      "screen_name" : "Storify",
      "indices" : [ 89, 97 ],
      "id_str" : "17814938",
      "id" : 17814938
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHTweetup",
      "indices" : [ 63, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/yEXwkumW",
      "expanded_url" : "http:\/\/sfy.co\/h61",
      "display_url" : "sfy.co\/h61"
    } ]
  },
  "geo" : { },
  "id_str" : "180074600263200768",
  "in_reply_to_user_id" : 165537211,
  "text" : "@alswrite @PHNurseMichelle Just posted the UK Arrival Ceremony #WHTweetup experience via @storify. Check it out:  http:\/\/t.co\/yEXwkumW",
  "id" : 180074600263200768,
  "created_at" : "2012-03-14 23:35:04 +0000",
  "in_reply_to_screen_name" : "alswrite",
  "in_reply_to_user_id_str" : "165537211",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/storify.com\" rel=\"nofollow\"\u003EStorify\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Caitlin Hayden",
      "screen_name" : "CaitlinHayden",
      "indices" : [ 0, 14 ],
      "id_str" : "390909351",
      "id" : 390909351
    }, {
      "name" : "Storify",
      "screen_name" : "Storify",
      "indices" : [ 89, 97 ],
      "id_str" : "17814938",
      "id" : 17814938
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHTweetup",
      "indices" : [ 63, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/yEXwkumW",
      "expanded_url" : "http:\/\/sfy.co\/h61",
      "display_url" : "sfy.co\/h61"
    } ]
  },
  "geo" : { },
  "id_str" : "180074600271593473",
  "in_reply_to_user_id" : 390909351,
  "text" : "@caitlinhayden @missphenom Just posted the UK Arrival Ceremony #WHTweetup experience via @storify. Check it out:  http:\/\/t.co\/yEXwkumW",
  "id" : 180074600271593473,
  "created_at" : "2012-03-14 23:35:04 +0000",
  "in_reply_to_screen_name" : "CaitlinHayden",
  "in_reply_to_user_id_str" : "390909351",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "180067522509410304",
  "text" : "RT @WHLive: Happening now: President Obama &amp; The First Lady welcome British Prime Minister Cameron &amp; Mrs. Cameron. Watch: http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/g5ih2w0F",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "180067419216289792",
    "text" : "Happening now: President Obama &amp; The First Lady welcome British Prime Minister Cameron &amp; Mrs. Cameron. Watch: http:\/\/t.co\/g5ih2w0F",
    "id" : 180067419216289792,
    "created_at" : "2012-03-14 23:06:32 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 180067522509410304,
  "created_at" : "2012-03-14 23:06:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 84, 95 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/180025780267515904\/photo\/1",
      "indices" : [ 123, 143 ],
      "url" : "http:\/\/t.co\/7lt1kTl4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/An-UfkvCAAI8S8W.jpg",
      "id_str" : "180025780275904514",
      "id" : 180025780275904514,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/An-UfkvCAAI8S8W.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      } ],
      "display_url" : "pic.twitter.com\/7lt1kTl4"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/4wzkOnSe",
      "expanded_url" : "http:\/\/wh.gov\/5OJ",
      "display_url" : "wh.gov\/5OJ"
    } ]
  },
  "geo" : { },
  "id_str" : "180025780267515904",
  "text" : "President Obama &amp; the First Lady welcome UK Prime Minister David Cameron to the @whitehouse: http:\/\/t.co\/4wzkOnSe Pic: http:\/\/t.co\/7lt1kTl4",
  "id" : 180025780267515904,
  "created_at" : "2012-03-14 20:21:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SummerJobs",
      "indices" : [ 33, 44 ]
    } ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/i8ZGG0Qc",
      "expanded_url" : "http:\/\/ow.ly\/9EKvo",
      "display_url" : "ow.ly\/9EKvo"
    } ]
  },
  "geo" : { },
  "id_str" : "179983503092494337",
  "text" : "Are you hiring this summer? Join #SummerJobs+ http:\/\/t.co\/i8ZGG0Qc",
  "id" : 179983503092494337,
  "created_at" : "2012-03-14 17:33:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UK Prime Minister",
      "screen_name" : "Number10gov",
      "indices" : [ 3, 15 ],
      "id_str" : "14224719",
      "id" : 14224719
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CameroninUS",
      "indices" : [ 100, 112 ]
    }, {
      "text" : "WHtweetup",
      "indices" : [ 113, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "179948643204345856",
  "text" : "RT @Number10gov: Photo: Prime Minister David Cameron and President Barack Obama in the Oval office. #CameroninUS #WHtweetup http:\/\/t.co\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CameroninUS",
        "indices" : [ 83, 95 ]
      }, {
        "text" : "WHtweetup",
        "indices" : [ 96, 106 ]
      } ],
      "urls" : [ {
        "indices" : [ 107, 127 ],
        "url" : "http:\/\/t.co\/8eG6uDSd",
        "expanded_url" : "http:\/\/yfrog.com\/ntknoqoj",
        "display_url" : "yfrog.com\/ntknoqoj"
      } ]
    },
    "geo" : { },
    "id_str" : "179946794799734785",
    "text" : "Photo: Prime Minister David Cameron and President Barack Obama in the Oval office. #CameroninUS #WHtweetup http:\/\/t.co\/8eG6uDSd",
    "id" : 179946794799734785,
    "created_at" : "2012-03-14 15:07:13 +0000",
    "user" : {
      "name" : "UK Prime Minister",
      "screen_name" : "Number10gov",
      "protected" : false,
      "id_str" : "14224719",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798111635206508544\/qPVyTQI-_normal.jpg",
      "id" : 14224719,
      "verified" : true
    }
  },
  "id" : 179948643204345856,
  "created_at" : "2012-03-14 15:14:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHTweetup",
      "indices" : [ 101, 111 ]
    }, {
      "text" : "CameroninUS",
      "indices" : [ 112, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "179923269816811521",
  "text" : "Are you watching the Arrival Ceremony for Prime Minister Cameron? Tune in now:  http:\/\/t.co\/u95y7hhB #WHTweetup #CameroninUS",
  "id" : 179923269816811521,
  "created_at" : "2012-03-14 13:33:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 15, 26 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "UK Prime Minister",
      "screen_name" : "Number10gov",
      "indices" : [ 63, 75 ],
      "id_str" : "14224719",
      "id" : 14224719
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHtweetup",
      "indices" : [ 35, 45 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "179920316208906240",
  "text" : "Welcome to the @WhiteHouse tweeps! #WHtweetup today to welcome @number10gov UK PM Cameron. Follow &amp; watch: http:\/\/t.co\/u95y7hhB",
  "id" : 179920316208906240,
  "created_at" : "2012-03-14 13:22:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 116, 127 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "179918410484957184",
  "text" : "RT @WHLive: Watch live: President Obama &amp; the First Lady welcome Prime Minister Cameron of Great Britain to the @WhiteHouse: http:\/\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 104, 115 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 137 ],
        "url" : "http:\/\/t.co\/ikhXEXkk",
        "expanded_url" : "http:\/\/ow.ly\/9EhwY",
        "display_url" : "ow.ly\/9EhwY"
      } ]
    },
    "geo" : { },
    "id_str" : "179918348270841858",
    "text" : "Watch live: President Obama &amp; the First Lady welcome Prime Minister Cameron of Great Britain to the @WhiteHouse: http:\/\/t.co\/ikhXEXkk",
    "id" : 179918348270841858,
    "created_at" : "2012-03-14 13:14:11 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 179918410484957184,
  "created_at" : "2012-03-14 13:14:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UK Prime Minister",
      "screen_name" : "Number10gov",
      "indices" : [ 3, 15 ],
      "id_str" : "14224719",
      "id" : 14224719
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 32, 43 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CameroninUS",
      "indices" : [ 108, 120 ]
    }, {
      "text" : "WHtweetup",
      "indices" : [ 121, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "179915871790170113",
  "text" : "RT @Number10gov: 7000 people on @whitehouse South Lawn to watch President Obama welcome the Prime Minister. #CameroninUS #WHtweetup",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.conversocial.com\" rel=\"nofollow\"\u003EConversocial\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 15, 26 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CameroninUS",
        "indices" : [ 91, 103 ]
      }, {
        "text" : "WHtweetup",
        "indices" : [ 104, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "179914912288604160",
    "text" : "7000 people on @whitehouse South Lawn to watch President Obama welcome the Prime Minister. #CameroninUS #WHtweetup",
    "id" : 179914912288604160,
    "created_at" : "2012-03-14 13:00:32 +0000",
    "user" : {
      "name" : "UK Prime Minister",
      "screen_name" : "Number10gov",
      "protected" : false,
      "id_str" : "14224719",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798111635206508544\/qPVyTQI-_normal.jpg",
      "id" : 14224719,
      "verified" : true
    }
  },
  "id" : 179915871790170113,
  "created_at" : "2012-03-14 13:04:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "179652238002761729",
  "text" : "RT @jesseclee44: In the time it takes you to read &amp; RT this tweet, oil companies will have received $7610 in tax breaks http:\/\/t.co\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jesseclee44\/status\/179650181254488064\/photo\/1",
        "indices" : [ 107, 127 ],
        "url" : "http:\/\/t.co\/KSATgIje",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/An4-41YCIAAwNfY.jpg",
        "id_str" : "179650181262876672",
        "id" : 179650181262876672,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/An4-41YCIAAwNfY.jpg",
        "sizes" : [ {
          "h" : 315,
          "resize" : "fit",
          "w" : 560
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 315,
          "resize" : "fit",
          "w" : 560
        }, {
          "h" : 315,
          "resize" : "fit",
          "w" : 560
        } ],
        "display_url" : "pic.twitter.com\/KSATgIje"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "179650181254488064",
    "text" : "In the time it takes you to read &amp; RT this tweet, oil companies will have received $7610 in tax breaks http:\/\/t.co\/KSATgIje",
    "id" : 179650181254488064,
    "created_at" : "2012-03-13 19:28:36 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 179652238002761729,
  "created_at" : "2012-03-13 19:36:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UK Prime Minister",
      "screen_name" : "Number10gov",
      "indices" : [ 3, 15 ],
      "id_str" : "14224719",
      "id" : 14224719
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 107, 118 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CameroninUS",
      "indices" : [ 120, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "179649165633142784",
  "text" : "RT @Number10gov: The Prime Minister and Mrs Cameron have arrived in the US for their official visit to the @WhiteHouse. #CameroninUS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.conversocial.com\" rel=\"nofollow\"\u003EConversocial\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 90, 101 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CameroninUS",
        "indices" : [ 103, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "179630070778957824",
    "text" : "The Prime Minister and Mrs Cameron have arrived in the US for their official visit to the @WhiteHouse. #CameroninUS",
    "id" : 179630070778957824,
    "created_at" : "2012-03-13 18:08:40 +0000",
    "user" : {
      "name" : "UK Prime Minister",
      "screen_name" : "Number10gov",
      "protected" : false,
      "id_str" : "14224719",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798111635206508544\/qPVyTQI-_normal.jpg",
      "id" : 14224719,
      "verified" : true
    }
  },
  "id" : 179649165633142784,
  "created_at" : "2012-03-13 19:24:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/179634013982564353\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/lh6Itm2m",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/An4wLxlCIAIE4zj.jpg",
      "id_str" : "179634013986758658",
      "id" : 179634013986758658,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/An4wLxlCIAIE4zj.jpg",
      "sizes" : [ {
        "h" : 315,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 315,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 315,
        "resize" : "fit",
        "w" : 560
      } ],
      "display_url" : "pic.twitter.com\/lh6Itm2m"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 43 ],
      "url" : "http:\/\/t.co\/Y857bvAp",
      "expanded_url" : "http:\/\/wh.gov\/IMi",
      "display_url" : "wh.gov\/IMi"
    } ]
  },
  "geo" : { },
  "id_str" : "179634013982564353",
  "text" : "By the numbers: $7,610 http:\/\/t.co\/Y857bvAp Amount of your money oil companies are receiving every minute in tax breaks http:\/\/t.co\/lh6Itm2m",
  "id" : 179634013982564353,
  "created_at" : "2012-03-13 18:24:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 3, 11 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    }, {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 30, 39 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "Google",
      "screen_name" : "google",
      "indices" : [ 64, 71 ],
      "id_str" : "20536157",
      "id" : 20536157
    }, {
      "name" : "Kori Schulman",
      "screen_name" : "ks44",
      "indices" : [ 87, 92 ],
      "id_str" : "369246180",
      "id" : 369246180
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 95, 106 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SXSWi",
      "indices" : [ 123, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "179605900976336896",
  "text" : "RT @macon44: Here's a shot of @PressSec answering questions via @google hangout during @ks44's @whitehouse presentation at #SXSWi http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Josh Earnest",
        "screen_name" : "PressSec",
        "indices" : [ 17, 26 ],
        "id_str" : "113420831",
        "id" : 113420831
      }, {
        "name" : "Google",
        "screen_name" : "google",
        "indices" : [ 51, 58 ],
        "id_str" : "20536157",
        "id" : 20536157
      }, {
        "name" : "Kori Schulman",
        "screen_name" : "ks44",
        "indices" : [ 74, 79 ],
        "id_str" : "369246180",
        "id" : 369246180
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 82, 93 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/macon44\/status\/179604404389949440\/photo\/1",
        "indices" : [ 117, 137 ],
        "url" : "http:\/\/t.co\/arApinzQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/An4VQRQCMAQBuwS.jpg",
        "id_str" : "179604404394143748",
        "id" : 179604404394143748,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/An4VQRQCMAQBuwS.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/arApinzQ"
      } ],
      "hashtags" : [ {
        "text" : "SXSWi",
        "indices" : [ 110, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "179604404389949440",
    "text" : "Here's a shot of @PressSec answering questions via @google hangout during @ks44's @whitehouse presentation at #SXSWi http:\/\/t.co\/arApinzQ",
    "id" : 179604404389949440,
    "created_at" : "2012-03-13 16:26:42 +0000",
    "user" : {
      "name" : "Macon Phillips",
      "screen_name" : "IIPCoordinator",
      "protected" : false,
      "id_str" : "110823581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000495374915\/f6a5ae048ab7f8f12c0386114df53203_normal.jpeg",
      "id" : 110823581,
      "verified" : true
    }
  },
  "id" : 179605900976336896,
  "created_at" : "2012-03-13 16:32:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 37 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "179585805860356097",
  "text" : "Starting soon on http:\/\/t.co\/u95y7hhB: President Obama speaks on new efforts to enforce our trade rights with China.",
  "id" : 179585805860356097,
  "created_at" : "2012-03-13 15:12:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LinkedIn SlideShare",
      "screen_name" : "SlideShare",
      "indices" : [ 68, 79 ],
      "id_str" : "9676152",
      "id" : 9676152
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gas",
      "indices" : [ 30, 34 ]
    } ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/X9LQbLgo",
      "expanded_url" : "http:\/\/www.slideshare.net\/whitehouse\/infographic-obama-energy-agenda-gas-prices",
      "display_url" : "slideshare.net\/whitehouse\/inf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "179315217019318273",
  "text" : "Infographic: Get the facts on #gas prices: http:\/\/t.co\/X9LQbLgo via @slideshare",
  "id" : 179315217019318273,
  "created_at" : "2012-03-12 21:17:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ITA",
      "screen_name" : "TradeGov",
      "indices" : [ 3, 12 ],
      "id_str" : "19112923",
      "id" : 19112923
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ExportSuccess",
      "indices" : [ 75, 89 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/PQGjygLn",
      "expanded_url" : "http:\/\/go.usa.gov\/PPf",
      "display_url" : "go.usa.gov\/PPf"
    } ]
  },
  "geo" : { },
  "id_str" : "179300778404614144",
  "text" : "RT @TradeGov The National Export Initiative is two years old. What is your #ExportSuccess? See the video! http:\/\/t.co\/PQGjygLn",
  "id" : 179300778404614144,
  "created_at" : "2012-03-12 20:20:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/179249185932058625\/photo\/1",
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/w8UojrMj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AnzSL1YCIAA3TB-.jpg",
      "id_str" : "179249185936252928",
      "id" : 179249185936252928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AnzSL1YCIAA3TB-.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 331
      }, {
        "h" : 2047,
        "resize" : "fit",
        "w" : 565
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 188
      }, {
        "h" : 2047,
        "resize" : "fit",
        "w" : 565
      } ],
      "display_url" : "pic.twitter.com\/w8UojrMj"
    } ],
    "hashtags" : [ {
      "text" : "Gas",
      "indices" : [ 17, 21 ]
    }, {
      "text" : "energy",
      "indices" : [ 53, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/CDS75iTZ",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/energy\/gasprices",
      "display_url" : "whitehouse.gov\/energy\/gaspric\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "179249185932058625",
  "text" : "New infographic: #Gas prices &amp; President Obama's #energy plan. Full size: http:\/\/t.co\/CDS75iTZ Twitter size: http:\/\/t.co\/w8UojrMj",
  "id" : 179249185932058625,
  "created_at" : "2012-03-12 16:55:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jobs",
      "indices" : [ 83, 88 ]
    }, {
      "text" : "MadeinAmerica",
      "indices" : [ 121, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/HcMg6Pvp",
      "expanded_url" : "http:\/\/ow.ly\/9zTp0",
      "display_url" : "ow.ly\/9zTp0"
    } ]
  },
  "geo" : { },
  "id_str" : "178579159705071616",
  "text" : "In his Weekly Address, President Obama talks about how companies are creating more #jobs in the US: http:\/\/t.co\/HcMg6Pvp #MadeinAmerica",
  "id" : 178579159705071616,
  "created_at" : "2012-03-10 20:32:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/k1lnQgZO",
      "expanded_url" : "http:\/\/ow.ly\/9zIdV",
      "display_url" : "ow.ly\/9zIdV"
    } ]
  },
  "geo" : { },
  "id_str" : "178509078765637632",
  "text" : "\"I want this Congress to stop the giveaways to an oil industry that\u2019s never been more profitable\" -President Obama http:\/\/t.co\/k1lnQgZO",
  "id" : 178509078765637632,
  "created_at" : "2012-03-10 15:54:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/178236263894228993\/photo\/1",
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/OEkHCfuy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ank48AwCIAAdZlL.jpg",
      "id_str" : "178236263902617600",
      "id" : 178236263902617600,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ank48AwCIAAdZlL.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 481,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 481,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 315,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 481,
        "resize" : "fit",
        "w" : 520
      } ],
      "display_url" : "pic.twitter.com\/OEkHCfuy"
    } ],
    "hashtags" : [ {
      "text" : "jobs",
      "indices" : [ 12, 17 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/0DPIHdrN",
      "expanded_url" : "http:\/\/wh.gov\/I5M",
      "display_url" : "wh.gov\/I5M"
    } ]
  },
  "geo" : { },
  "id_str" : "178236263894228993",
  "text" : "We've added #jobs for 24 straight months \u2013that's work for 3.9m Americans. Are you one of them? http:\/\/t.co\/0DPIHdrN http:\/\/t.co\/OEkHCfuy",
  "id" : 178236263894228993,
  "created_at" : "2012-03-09 21:50:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aneesh Chopra",
      "screen_name" : "aneeshchopra",
      "indices" : [ 3, 16 ],
      "id_str" : "121539516",
      "id" : 121539516
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 39, 50 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "Todd Park",
      "screen_name" : "todd_park",
      "indices" : [ 61, 71 ],
      "id_str" : "200176600",
      "id" : 200176600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "178187562236645376",
  "text" : "RT @aneeshchopra: An OUTSTANDING pick! @whitehouse announces @todd_park will be our next CTO! I've got a tear in my eye :) http:\/\/t.co\/g ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ESafari on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 21, 32 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "Todd Park",
        "screen_name" : "todd_park",
        "indices" : [ 43, 53 ],
        "id_str" : "200176600",
        "id" : 200176600
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 125 ],
        "url" : "http:\/\/t.co\/gJn8Gz4B",
        "expanded_url" : "http:\/\/m.whitehouse.gov\/blog\/2012\/03\/09\/todd-park-named-new-us-chief-technology-officer",
        "display_url" : "m.whitehouse.gov\/blog\/2012\/03\/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "178187202658963456",
    "text" : "An OUTSTANDING pick! @whitehouse announces @todd_park will be our next CTO! I've got a tear in my eye :) http:\/\/t.co\/gJn8Gz4B",
    "id" : 178187202658963456,
    "created_at" : "2012-03-09 18:35:14 +0000",
    "user" : {
      "name" : "Aneesh Chopra",
      "screen_name" : "aneeshchopra",
      "protected" : false,
      "id_str" : "121539516",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000040581867\/a0962f4551be12d095b281f8afa81a95_normal.jpeg",
      "id" : 121539516,
      "verified" : true
    }
  },
  "id" : 178187562236645376,
  "created_at" : "2012-03-09 18:36:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 3, 11 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    }, {
      "name" : "Todd Park",
      "screen_name" : "todd_park",
      "indices" : [ 27, 37 ],
      "id_str" : "200176600",
      "id" : 200176600
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 87, 98 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/8pHxXi7m",
      "expanded_url" : "http:\/\/whitehouse.gov\/blog\/2012\/03\/09\/todd-park-named-new-us-chief-technology-officer",
      "display_url" : "whitehouse.gov\/blog\/2012\/03\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "178184246794530816",
  "text" : "RT @macon44: Thrilled that @todd_park will bring contagious enthusiasm &amp; smarts to @whitehouse as next US CTO http:\/\/t.co\/8pHxXi7m w ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Todd Park",
        "screen_name" : "todd_park",
        "indices" : [ 14, 24 ],
        "id_str" : "200176600",
        "id" : 200176600
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 74, 85 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "sxsw",
        "indices" : [ 133, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 101, 121 ],
        "url" : "http:\/\/t.co\/8pHxXi7m",
        "expanded_url" : "http:\/\/whitehouse.gov\/blog\/2012\/03\/09\/todd-park-named-new-us-chief-technology-officer",
        "display_url" : "whitehouse.gov\/blog\/2012\/03\/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "178184186996330497",
    "text" : "Thrilled that @todd_park will bring contagious enthusiasm &amp; smarts to @whitehouse as next US CTO http:\/\/t.co\/8pHxXi7m we speak @ #sxsw tmrw",
    "id" : 178184186996330497,
    "created_at" : "2012-03-09 18:23:15 +0000",
    "user" : {
      "name" : "Macon Phillips",
      "screen_name" : "IIPCoordinator",
      "protected" : false,
      "id_str" : "110823581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000495374915\/f6a5ae048ab7f8f12c0386114df53203_normal.jpeg",
      "id" : 110823581,
      "verified" : true
    }
  },
  "id" : 178184246794530816,
  "created_at" : "2012-03-09 18:23:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "178167475207286784",
  "text" : "Happening @ 12:30ET: President Obama speaks @ Rolls-Royce Crosspointe in VA. Watch live: http:\/\/t.co\/u95y7hhB",
  "id" : 178167475207286784,
  "created_at" : "2012-03-09 17:16:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/178152400618655745\/photo\/1",
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/CpRcba1Y",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AnjsqhvCEAACR_s.jpg",
      "id_str" : "178152400635432960",
      "id" : 178152400635432960,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AnjsqhvCEAACR_s.jpg",
      "sizes" : [ {
        "h" : 452,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 771,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 256,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 856,
        "resize" : "fit",
        "w" : 1137
      } ],
      "display_url" : "pic.twitter.com\/CpRcba1Y"
    } ],
    "hashtags" : [ {
      "text" : "jobs",
      "indices" : [ 26, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "178152400618655745",
  "text" : "The economy added 233,000 #jobs in February. Encouraging, but more work to be done. New jobs chart: http:\/\/t.co\/CpRcba1Y",
  "id" : 178152400618655745,
  "created_at" : "2012-03-09 16:16:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/177877436636205057\/photo\/1",
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/yRJ7h0px",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AnfylhCCEAAgZa7.jpg",
      "id_str" : "177877436640399360",
      "id" : 177877436640399360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AnfylhCCEAAgZa7.jpg",
      "sizes" : [ {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2047
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/yRJ7h0px"
    } ],
    "hashtags" : [ {
      "text" : "Charlotte",
      "indices" : [ 77, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "177877436636205057",
  "text" : "Photo of the Day: President Obama walks across the tarmac to greet people in #Charlotte NC: http:\/\/t.co\/yRJ7h0px",
  "id" : 177877436636205057,
  "created_at" : "2012-03-08 22:04:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opengov",
      "indices" : [ 129, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/3cuX0IHC",
      "expanded_url" : "http:\/\/Ethics.gov",
      "display_url" : "Ethics.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "177835438113959936",
  "text" : "Today, President Obama takes another step to ensure unprecedented openness in government. Check out the new http:\/\/t.co\/3cuX0IHC #opengov",
  "id" : 177835438113959936,
  "created_at" : "2012-03-08 19:17:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dept. of Agriculture",
      "screen_name" : "USDA",
      "indices" : [ 3, 8 ],
      "id_str" : "61853389",
      "id" : 61853389
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyPlate",
      "indices" : [ 97, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "177801401777401856",
  "text" : "RT @USDA: It's \"What's on MyPlate\" day! Snap a pic of your healthy plate & send it our way using #MyPlate. Can't wait to see what you got!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MyPlate",
        "indices" : [ 87, 95 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "177795113135771648",
    "text" : "It's \"What's on MyPlate\" day! Snap a pic of your healthy plate & send it our way using #MyPlate. Can't wait to see what you got!",
    "id" : 177795113135771648,
    "created_at" : "2012-03-08 16:37:12 +0000",
    "user" : {
      "name" : "Dept. of Agriculture",
      "screen_name" : "USDA",
      "protected" : false,
      "id_str" : "61853389",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3475696751\/bf524afc612e7aa534d6c543a3d3e144_normal.jpeg",
      "id" : 61853389,
      "verified" : true
    }
  },
  "id" : 177801401777401856,
  "created_at" : "2012-03-08 17:02:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "indices" : [ 3, 12 ],
      "id_str" : "337742544",
      "id" : 337742544
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "womensday",
      "indices" : [ 22, 32 ]
    }, {
      "text" : "2013Budget",
      "indices" : [ 67, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/kOqsK4ul",
      "expanded_url" : "http:\/\/1.usa.gov\/ArtnwP",
      "display_url" : "1.usa.gov\/ArtnwP"
    } ]
  },
  "geo" : { },
  "id_str" : "177796036402757633",
  "text" : "RT @OMBPress: On intl #womensday, Heather Higginbottom reviews how #2013Budget stands up for women around the world http:\/\/t.co\/kOqsK4ul ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "womensday",
        "indices" : [ 8, 18 ]
      }, {
        "text" : "2013Budget",
        "indices" : [ 53, 64 ]
      }, {
        "text" : "IWD",
        "indices" : [ 123, 127 ]
      } ],
      "urls" : [ {
        "indices" : [ 102, 122 ],
        "url" : "http:\/\/t.co\/kOqsK4ul",
        "expanded_url" : "http:\/\/1.usa.gov\/ArtnwP",
        "display_url" : "1.usa.gov\/ArtnwP"
      } ]
    },
    "geo" : { },
    "id_str" : "177793621590949888",
    "text" : "On intl #womensday, Heather Higginbottom reviews how #2013Budget stands up for women around the world http:\/\/t.co\/kOqsK4ul #IWD",
    "id" : 177793621590949888,
    "created_at" : "2012-03-08 16:31:17 +0000",
    "user" : {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "protected" : false,
      "id_str" : "337742544",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1449289379\/OMB_Seal_normal.jpg",
      "id" : 337742544,
      "verified" : true
    }
  },
  "id" : 177796036402757633,
  "created_at" : "2012-03-08 16:40:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 3, 13 ],
      "id_str" : "9624742",
      "id" : 9624742
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SecClinton",
      "indices" : [ 15, 26 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/IA3sMjab",
      "expanded_url" : "http:\/\/go.usa.gov\/P2F",
      "display_url" : "go.usa.gov\/P2F"
    } ]
  },
  "geo" : { },
  "id_str" : "177560618973405184",
  "text" : "RT @StateDept: #SecClinton: We reaffirm our commitment to locating Mr. Levinson, bringing him home safely. http:\/\/t.co\/IA3sMjab @helpbob ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Help Bob Levinson",
        "screen_name" : "HelpBobLevinson",
        "indices" : [ 113, 129 ],
        "id_str" : "430422376",
        "id" : 430422376
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SecClinton",
        "indices" : [ 0, 11 ]
      }, {
        "text" : "HelpBob",
        "indices" : [ 130, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 112 ],
        "url" : "http:\/\/t.co\/IA3sMjab",
        "expanded_url" : "http:\/\/go.usa.gov\/P2F",
        "display_url" : "go.usa.gov\/P2F"
      } ]
    },
    "geo" : { },
    "id_str" : "177414505670782976",
    "text" : "#SecClinton: We reaffirm our commitment to locating Mr. Levinson, bringing him home safely. http:\/\/t.co\/IA3sMjab @helpboblevinson #HelpBob",
    "id" : 177414505670782976,
    "created_at" : "2012-03-07 15:24:49 +0000",
    "user" : {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "protected" : false,
      "id_str" : "9624742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724612605185282048\/1rEfkXDZ_normal.jpg",
      "id" : 9624742,
      "verified" : true
    }
  },
  "id" : 177560618973405184,
  "created_at" : "2012-03-08 01:05:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Business Roundtable",
      "screen_name" : "BizRoundtable",
      "indices" : [ 29, 43 ],
      "id_str" : "44682276",
      "id" : 44682276
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jobs",
      "indices" : [ 61, 66 ]
    }, {
      "text" : "economy",
      "indices" : [ 73, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/ZZN8FdEg",
      "expanded_url" : "http:\/\/ow.ly\/9wiOm",
      "display_url" : "ow.ly\/9wiOm"
    }, {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/5HTxUAwc",
      "expanded_url" : "http:\/\/youtu.be\/Z5mLfqI6SAc",
      "display_url" : "youtu.be\/Z5mLfqI6SAc"
    } ]
  },
  "geo" : { },
  "id_str" : "177544666995109890",
  "text" : "President Obama meets w\/ the @BizRoundtable & talks American #jobs & the #economy: http:\/\/t.co\/ZZN8FdEg Watch: http:\/\/t.co\/5HTxUAwc",
  "id" : 177544666995109890,
  "created_at" : "2012-03-08 00:02:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Marines",
      "screen_name" : "USMC",
      "indices" : [ 93, 98 ],
      "id_str" : "10126672",
      "id" : 10126672
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/177524996497874945\/photo\/1",
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/QdydfTxj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AnayCzNCIAAfi9G.jpg",
      "id_str" : "177524996502069248",
      "id" : 177524996502069248,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AnayCzNCIAAfi9G.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/QdydfTxj"
    } ],
    "hashtags" : [ {
      "text" : "AtTheWH",
      "indices" : [ 58, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "177524996497874945",
  "text" : "Photo of the Day: President Obama greets wounded warriors #AtTheWH & signs prosthetic arm of @USMC Sgt Carlos Evans: http:\/\/t.co\/QdydfTxj",
  "id" : 177524996497874945,
  "created_at" : "2012-03-07 22:43:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Case",
      "screen_name" : "SteveCase",
      "indices" : [ 3, 13 ],
      "id_str" : "6708952",
      "id" : 6708952
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 27, 38 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "177462577046093825",
  "text" : "RT @SteveCase: Grateful to @WhiteHouse for issuing this statement of support for Jumpstart Our Business Startups Act http:\/\/t.co\/a5L00uB ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 12, 23 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "StartupAmerica",
        "indices" : [ 123, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 102, 122 ],
        "url" : "http:\/\/t.co\/a5L00uBB",
        "expanded_url" : "http:\/\/ow.ly\/9vSBk",
        "display_url" : "ow.ly\/9vSBk"
      } ]
    },
    "geo" : { },
    "id_str" : "177461042459312128",
    "text" : "Grateful to @WhiteHouse for issuing this statement of support for Jumpstart Our Business Startups Act http:\/\/t.co\/a5L00uBB #StartupAmerica",
    "id" : 177461042459312128,
    "created_at" : "2012-03-07 18:29:44 +0000",
    "user" : {
      "name" : "Steve Case",
      "screen_name" : "SteveCase",
      "protected" : false,
      "id_str" : "6708952",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/708164499014987780\/w8TcvuF0_normal.jpg",
      "id" : 6708952,
      "verified" : true
    }
  },
  "id" : 177462577046093825,
  "created_at" : "2012-03-07 18:35:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daimler Trucks NA",
      "screen_name" : "DaimlerTrucksNA",
      "indices" : [ 45, 61 ],
      "id_str" : "256141218",
      "id" : 256141218
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MountHolly",
      "indices" : [ 85, 96 ]
    }, {
      "text" : "NC",
      "indices" : [ 97, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "177446027232673793",
  "text" : "Happening at 12:45ET: President Obama visits @DaimlerTrucksNA manufacturing plant in #MountHolly #NC. Watch: http:\/\/t.co\/u95y7hhB",
  "id" : 177446027232673793,
  "created_at" : "2012-03-07 17:30:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daimler Trucks NA",
      "screen_name" : "DaimlerTrucksNA",
      "indices" : [ 3, 19 ],
      "id_str" : "256141218",
      "id" : 256141218
    }, {
      "name" : "Barack Obama",
      "screen_name" : "BarackObama",
      "indices" : [ 125, 137 ],
      "id_str" : "813286",
      "id" : 813286
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MountHolly",
      "indices" : [ 67, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "177427093959880705",
  "text" : "RT @DaimlerTrucksNA: The line is growing by the minute here at the #MountHolly truck plant in anticipation of the arrival of @BarackObama",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Barack Obama",
        "screen_name" : "BarackObama",
        "indices" : [ 104, 116 ],
        "id_str" : "813286",
        "id" : 813286
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MountHolly",
        "indices" : [ 46, 57 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "177409356743192577",
    "text" : "The line is growing by the minute here at the #MountHolly truck plant in anticipation of the arrival of @BarackObama",
    "id" : 177409356743192577,
    "created_at" : "2012-03-07 15:04:21 +0000",
    "user" : {
      "name" : "Daimler Trucks NA",
      "screen_name" : "DaimlerTrucksNA",
      "protected" : false,
      "id_str" : "256141218",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/679713238033002497\/4Nan4JiR_normal.png",
      "id" : 256141218,
      "verified" : false
    }
  },
  "id" : 177427093959880705,
  "created_at" : "2012-03-07 16:14:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    }, {
      "name" : "Syracuse University",
      "screen_name" : "SyracuseU",
      "indices" : [ 20, 30 ],
      "id_str" : "125688706",
      "id" : 125688706
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "veterans",
      "indices" : [ 123, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "177424054335184896",
  "text" : "RT @JoiningForces: .@SyracuseU's Institute for vets & military families releases a study on the \u201Cbusiness case\u201D for hiring #veterans: ht ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Syracuse University",
        "screen_name" : "SyracuseU",
        "indices" : [ 1, 11 ],
        "id_str" : "125688706",
        "id" : 125688706
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "veterans",
        "indices" : [ 104, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 135 ],
        "url" : "http:\/\/t.co\/jwM4xceS",
        "expanded_url" : "http:\/\/ow.ly\/9vD34",
        "display_url" : "ow.ly\/9vD34"
      } ]
    },
    "geo" : { },
    "id_str" : "177424009934274560",
    "text" : ".@SyracuseU's Institute for vets & military families releases a study on the \u201Cbusiness case\u201D for hiring #veterans: http:\/\/t.co\/jwM4xceS",
    "id" : 177424009934274560,
    "created_at" : "2012-03-07 16:02:35 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 177424054335184896,
  "created_at" : "2012-03-07 16:02:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "indices" : [ 3, 12 ],
      "id_str" : "337742544",
      "id" : 337742544
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SAP44",
      "indices" : [ 14, 20 ]
    }, {
      "text" : "jobs",
      "indices" : [ 87, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/92fs5ppv",
      "expanded_url" : "http:\/\/1.usa.gov\/wYE5nI",
      "display_url" : "1.usa.gov\/wYE5nI"
    } ]
  },
  "geo" : { },
  "id_str" : "177184320220434432",
  "text" : "RT @OMBPress: #SAP44: Admin supports HR 3606; helps startups, small biz succeed\/create #jobs http:\/\/t.co\/92fs5ppv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SAP44",
        "indices" : [ 0, 6 ]
      }, {
        "text" : "jobs",
        "indices" : [ 73, 78 ]
      } ],
      "urls" : [ {
        "indices" : [ 79, 99 ],
        "url" : "http:\/\/t.co\/92fs5ppv",
        "expanded_url" : "http:\/\/1.usa.gov\/wYE5nI",
        "display_url" : "1.usa.gov\/wYE5nI"
      } ]
    },
    "geo" : { },
    "id_str" : "177125695342911489",
    "text" : "#SAP44: Admin supports HR 3606; helps startups, small biz succeed\/create #jobs http:\/\/t.co\/92fs5ppv",
    "id" : 177125695342911489,
    "created_at" : "2012-03-06 20:17:11 +0000",
    "user" : {
      "name" : "OMBPress",
      "screen_name" : "OMBPress",
      "protected" : false,
      "id_str" : "337742544",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1449289379\/OMB_Seal_normal.jpg",
      "id" : 337742544,
      "verified" : true
    }
  },
  "id" : 177184320220434432,
  "created_at" : "2012-03-07 00:10:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 3, 12 ],
      "id_str" : "36719281",
      "id" : 36719281
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EasterEggRoll",
      "indices" : [ 73, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/EpvKSttG",
      "expanded_url" : "http:\/\/ow.ly\/9uJdC",
      "display_url" : "ow.ly\/9uJdC"
    } ]
  },
  "geo" : { },
  "id_str" : "177163660395937794",
  "text" : "RT @letsmove: Calling all students: Last chance to enter the White House #EasterEggRoll Poster Contest: http:\/\/t.co\/EpvKSttG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EasterEggRoll",
        "indices" : [ 59, 73 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 110 ],
        "url" : "http:\/\/t.co\/EpvKSttG",
        "expanded_url" : "http:\/\/ow.ly\/9uJdC",
        "display_url" : "ow.ly\/9uJdC"
      } ]
    },
    "geo" : { },
    "id_str" : "177163491050926080",
    "text" : "Calling all students: Last chance to enter the White House #EasterEggRoll Poster Contest: http:\/\/t.co\/EpvKSttG",
    "id" : 177163491050926080,
    "created_at" : "2012-03-06 22:47:22 +0000",
    "user" : {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "protected" : false,
      "id_str" : "36719281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207340336\/780fc13e31b6fdd80bd57d000dc13838_normal.jpeg",
      "id" : 36719281,
      "verified" : true
    }
  },
  "id" : 177163660395937794,
  "created_at" : "2012-03-06 22:48:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 45, 55 ],
      "id_str" : "9624742",
      "id" : 9624742
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/177141545840017408\/photo\/1",
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/nsLfNMjk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AnVVTCPCAAABHqx.jpg",
      "id_str" : "177141545856794624",
      "id" : 177141545856794624,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AnVVTCPCAAABHqx.jpg",
      "sizes" : [ {
        "h" : 402,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 686,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 228,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1286,
        "resize" : "fit",
        "w" : 1920
      } ],
      "display_url" : "pic.twitter.com\/nsLfNMjk"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "177141545840017408",
  "text" : "Photo of the Day: President Obama talks with @StateDept Secretary Clinton in the Oval Office: http:\/\/t.co\/nsLfNMjk",
  "id" : 177141545840017408,
  "created_at" : "2012-03-06 21:20:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/tQcE4sly",
      "expanded_url" : "http:\/\/ow.ly\/9uxxl",
      "display_url" : "ow.ly\/9uxxl"
    } ]
  },
  "geo" : { },
  "id_str" : "177124874844782592",
  "text" : "What you need to know about today's housing announcement: http:\/\/t.co\/tQcE4sly",
  "id" : 177124874844782592,
  "created_at" : "2012-03-06 20:13:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "177096940574609408",
  "text" : "Now, President Obama is taking questions from the press in the briefing room. Watch live: http:\/\/t.co\/u95y7hhB",
  "id" : 177096940574609408,
  "created_at" : "2012-03-06 18:22:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 130, 137 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "177094750292283392",
  "text" : "Live @ 1:15ET: President Obama announces new actions to help homeowners in a news conference. Watch: http:\/\/t.co\/u95y7hhB Follow: @WHLive",
  "id" : 177094750292283392,
  "created_at" : "2012-03-06 18:14:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HUD News | not",
      "screen_name" : "HUDNews",
      "indices" : [ 3, 11 ],
      "id_str" : "1881201980",
      "id" : 1881201980
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "177090719343849472",
  "text" : "RT @HUDNews: POTUS to announce NEW steps to provide housing relief to veterans and servicemembers at 1:15 p.m. ET. More info at http:\/\/t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 135 ],
        "url" : "http:\/\/t.co\/j4SrnhYX",
        "expanded_url" : "http:\/\/HUD.gov",
        "display_url" : "HUD.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "177084847712505856",
    "text" : "POTUS to announce NEW steps to provide housing relief to veterans and servicemembers at 1:15 p.m. ET. More info at http:\/\/t.co\/j4SrnhYX.",
    "id" : 177084847712505856,
    "created_at" : "2012-03-06 17:34:52 +0000",
    "user" : {
      "name" : "HUDgov",
      "screen_name" : "HUDgov",
      "protected" : false,
      "id_str" : "19948202",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000438958545\/e9038252f910c840e582818a63dd9908_normal.jpeg",
      "id" : 19948202,
      "verified" : true
    }
  },
  "id" : 177090719343849472,
  "created_at" : "2012-03-06 17:58:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "indices" : [ 3, 10 ],
      "id_str" : "166252256",
      "id" : 166252256
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/qyl8F5Up",
      "expanded_url" : "http:\/\/energy.gov\/live",
      "display_url" : "energy.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "177059149497106432",
  "text" : "RT @ENERGY: Today, 2:15p EST: LIVE Q&A with Sec Chu and Energy Innovation Hub directors. Tweet your Qs. http:\/\/t.co\/qyl8F5Up",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 112 ],
        "url" : "http:\/\/t.co\/qyl8F5Up",
        "expanded_url" : "http:\/\/energy.gov\/live",
        "display_url" : "energy.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "177051870202826752",
    "text" : "Today, 2:15p EST: LIVE Q&A with Sec Chu and Energy Innovation Hub directors. Tweet your Qs. http:\/\/t.co\/qyl8F5Up",
    "id" : 177051870202826752,
    "created_at" : "2012-03-06 15:23:49 +0000",
    "user" : {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "protected" : false,
      "id_str" : "166252256",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793425839694155781\/HRS6sfn4_normal.jpg",
      "id" : 166252256,
      "verified" : true
    }
  },
  "id" : 177059149497106432,
  "created_at" : "2012-03-06 15:52:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 81, 92 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 130, 137 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/g5ih2w0F",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "177051022433320960",
  "text" : "RT @WHLive: Happening at 1:15 ET: President Obama holds a news conference at the @whitehouse. Watch: http:\/\/t.co\/g5ih2w0F Follow: @WHLive",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 69, 80 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "White House Live",
        "screen_name" : "WHLive",
        "indices" : [ 118, 125 ],
        "id_str" : "369505837",
        "id" : 369505837
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 109 ],
        "url" : "http:\/\/t.co\/g5ih2w0F",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "177050963398504448",
    "text" : "Happening at 1:15 ET: President Obama holds a news conference at the @whitehouse. Watch: http:\/\/t.co\/g5ih2w0F Follow: @WHLive",
    "id" : 177050963398504448,
    "created_at" : "2012-03-06 15:20:13 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 177051022433320960,
  "created_at" : "2012-03-06 15:20:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    }, {
      "name" : "The Associated Press",
      "screen_name" : "AP",
      "indices" : [ 20, 23 ],
      "id_str" : "51241574",
      "id" : 51241574
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/7nLSaHiU",
      "expanded_url" : "http:\/\/bit.ly\/zamnf0",
      "display_url" : "bit.ly\/zamnf0"
    } ]
  },
  "geo" : { },
  "id_str" : "177036513698263040",
  "text" : "RT @pfeiffer44: Via @AP Pres Obama will use his news conference today to announce new actions to help homeowners http:\/\/t.co\/7nLSaHiU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Associated Press",
        "screen_name" : "AP",
        "indices" : [ 4, 7 ],
        "id_str" : "51241574",
        "id" : 51241574
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 117 ],
        "url" : "http:\/\/t.co\/7nLSaHiU",
        "expanded_url" : "http:\/\/bit.ly\/zamnf0",
        "display_url" : "bit.ly\/zamnf0"
      } ]
    },
    "geo" : { },
    "id_str" : "177008566031486976",
    "text" : "Via @AP Pres Obama will use his news conference today to announce new actions to help homeowners http:\/\/t.co\/7nLSaHiU",
    "id" : 177008566031486976,
    "created_at" : "2012-03-06 12:31:45 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 177036513698263040,
  "created_at" : "2012-03-06 14:22:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/ZV503M8Z",
      "expanded_url" : "http:\/\/wh.gov\/XZr",
      "display_url" : "wh.gov\/XZr"
    } ]
  },
  "geo" : { },
  "id_str" : "176823329141964800",
  "text" : "Know a scientist, engineer or inventor? Nominations for National Medals of Science + Technology & Innovation are open: http:\/\/t.co\/ZV503M8Z",
  "id" : 176823329141964800,
  "created_at" : "2012-03-06 00:15:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/0QmN64M9",
      "expanded_url" : "http:\/\/ow.ly\/9taeU",
      "display_url" : "ow.ly\/9taeU"
    } ]
  },
  "geo" : { },
  "id_str" : "176796175096233985",
  "text" : "In just 11 months, the Chamber of Commerce has held 100 Hiring Fairs for 8,000+ Veterans & Military Spouses. Learn more http:\/\/t.co\/0QmN64M9",
  "id" : 176796175096233985,
  "created_at" : "2012-03-05 22:27:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "176772909119967232",
  "text" : "RT @jesseclee44: 105 million Americans (1\/3 of total population) no longer face lifetime limits on their insurance. State by state: http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "hcr",
        "indices" : [ 136, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 135 ],
        "url" : "http:\/\/t.co\/KhPHXEXo",
        "expanded_url" : "http:\/\/wh.gov\/XDu",
        "display_url" : "wh.gov\/XDu"
      } ]
    },
    "geo" : { },
    "id_str" : "176727113557213184",
    "text" : "105 million Americans (1\/3 of total population) no longer face lifetime limits on their insurance. State by state: http:\/\/t.co\/KhPHXEXo #hcr",
    "id" : 176727113557213184,
    "created_at" : "2012-03-05 17:53:21 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 176772909119967232,
  "created_at" : "2012-03-05 20:55:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KYF2",
      "indices" : [ 134, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "176748273762185216",
  "text" : "Interested in Local & Regional Foods? Join us @ 2:30 pm for Know Your Farmer, Know your Food. Watch http:\/\/t.co\/u95y7hhB & Ask a Q w\/ #KYF2",
  "id" : 176748273762185216,
  "created_at" : "2012-03-05 19:17:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AIPAC2012",
      "indices" : [ 90, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/Y3HkFqE4",
      "expanded_url" : "http:\/\/ow.ly\/9sr08",
      "display_url" : "ow.ly\/9sr08"
    } ]
  },
  "geo" : { },
  "id_str" : "176714433203142656",
  "text" : "Today, President Obama meets w\/ Israeli Prime Minister Netanyahu. Sunday, he spoke at the #AIPAC2012 Conference. Watch: http:\/\/t.co\/Y3HkFqE4",
  "id" : 176714433203142656,
  "created_at" : "2012-03-05 17:02:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "176694118913810433",
  "text" : "RT @presssec: Breaking: President Obama will hold a news conference with the White House press corps tomorrow afternoon.",
  "id" : 176694118913810433,
  "created_at" : "2012-03-05 15:42:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "176691830665121793",
  "text" : "RT @pfeiffer44: On 5\/21, POTUS gives the commencement at the high school in Joplin, Missouri -- the sight of terrible tornadoes http:\/\/t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 132 ],
        "url" : "http:\/\/t.co\/gXzihkBE",
        "expanded_url" : "http:\/\/apne.ws\/yrMsDd",
        "display_url" : "apne.ws\/yrMsDd"
      } ]
    },
    "geo" : { },
    "id_str" : "176674397304791040",
    "text" : "On 5\/21, POTUS gives the commencement at the high school in Joplin, Missouri -- the sight of terrible tornadoes http:\/\/t.co\/gXzihkBE",
    "id" : 176674397304791040,
    "created_at" : "2012-03-05 14:23:53 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 176691830665121793,
  "created_at" : "2012-03-05 15:33:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Carson",
      "screen_name" : "JonCarson44",
      "indices" : [ 3, 15 ],
      "id_str" : "1287388789",
      "id" : 1287388789
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 22, 33 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UrbanEconForum",
      "indices" : [ 34, 49 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/DjYOOHmq",
      "expanded_url" : "http:\/\/1.usa.gov\/UT2FE",
      "display_url" : "1.usa.gov\/UT2FE"
    } ]
  },
  "geo" : { },
  "id_str" : "176674854244847616",
  "text" : "RT @JonCarson44: Join @whitehouse #UrbanEconForum in Birmingham, AL w 300 local entrepreneurs Watch live http:\/\/t.co\/DjYOOHmq Read more  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 5, 16 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UrbanEconForum",
        "indices" : [ 17, 32 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 108 ],
        "url" : "http:\/\/t.co\/DjYOOHmq",
        "expanded_url" : "http:\/\/1.usa.gov\/UT2FE",
        "display_url" : "1.usa.gov\/UT2FE"
      }, {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/aA6Ul3Zo",
        "expanded_url" : "http:\/\/1.usa.gov\/xxwErp",
        "display_url" : "1.usa.gov\/xxwErp"
      } ]
    },
    "geo" : { },
    "id_str" : "176673638852984832",
    "text" : "Join @whitehouse #UrbanEconForum in Birmingham, AL w 300 local entrepreneurs Watch live http:\/\/t.co\/DjYOOHmq Read more http:\/\/t.co\/aA6Ul3Zo",
    "id" : 176673638852984832,
    "created_at" : "2012-03-05 14:20:52 +0000",
    "user" : {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "protected" : false,
      "id_str" : "369232105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623146355767140352\/58sqoVrw_normal.jpg",
      "id" : 369232105,
      "verified" : true
    }
  },
  "id" : 176674854244847616,
  "created_at" : "2012-03-05 14:25:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/O8Sg08LP",
      "expanded_url" : "http:\/\/ow.ly\/9qSTG",
      "display_url" : "ow.ly\/9qSTG"
    } ]
  },
  "geo" : { },
  "id_str" : "176032472742633473",
  "text" : "Weekly Address: Taking Control of our Energy Future http:\/\/t.co\/O8Sg08LP",
  "id" : 176032472742633473,
  "created_at" : "2012-03-03 19:53:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Fugate",
      "screen_name" : "CraigatFEMA",
      "indices" : [ 79, 91 ],
      "id_str" : "67378554",
      "id" : 67378554
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/rJvttjF9",
      "expanded_url" : "http:\/\/ow.ly\/9qlp2",
      "display_url" : "ow.ly\/9qlp2"
    }, {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/usoANWtJ",
      "expanded_url" : "http:\/\/ow.ly\/9ql76",
      "display_url" : "ow.ly\/9ql76"
    } ]
  },
  "geo" : { },
  "id_str" : "175739412179714048",
  "text" : "Know what to do before a tornado warning is issued: http:\/\/t.co\/rJvttjF9 Watch @CraigatFEMA for more on being prepared: http:\/\/t.co\/usoANWtJ",
  "id" : 175739412179714048,
  "created_at" : "2012-03-03 00:28:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Fugate",
      "screen_name" : "CraigatFEMA",
      "indices" : [ 3, 15 ],
      "id_str" : "67378554",
      "id" : 67378554
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wx",
      "indices" : [ 75, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/YVxy5Hhk",
      "expanded_url" : "http:\/\/www.spc.noaa.gov\/",
      "display_url" : "spc.noaa.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "175736500825231360",
  "text" : "RT @CraigatFEMA: The Storm Prediction Center is forecasting a major severe #wx outbreak today and\/or tonight. http:\/\/t.co\/YVxy5Hhk http: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "wx",
        "indices" : [ 58, 61 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 113 ],
        "url" : "http:\/\/t.co\/YVxy5Hhk",
        "expanded_url" : "http:\/\/www.spc.noaa.gov\/",
        "display_url" : "spc.noaa.gov"
      }, {
        "indices" : [ 114, 134 ],
        "url" : "http:\/\/t.co\/lacsmooK",
        "expanded_url" : "http:\/\/m.fema.gov",
        "display_url" : "m.fema.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "175574576519069696",
    "text" : "The Storm Prediction Center is forecasting a major severe #wx outbreak today and\/or tonight. http:\/\/t.co\/YVxy5Hhk http:\/\/t.co\/lacsmooK",
    "id" : 175574576519069696,
    "created_at" : "2012-03-02 13:33:35 +0000",
    "user" : {
      "name" : "Craig Fugate",
      "screen_name" : "CraigatFEMA",
      "protected" : false,
      "id_str" : "67378554",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/522052690138763264\/isW58OSG_normal.jpeg",
      "id" : 67378554,
      "verified" : true
    }
  },
  "id" : 175736500825231360,
  "created_at" : "2012-03-03 00:17:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 0, 9 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/pK6gAmk1",
      "expanded_url" : "http:\/\/wh.gov\/9PA",
      "display_url" : "wh.gov\/9PA"
    } ]
  },
  "geo" : { },
  "id_str" : "175722735639605248",
  "in_reply_to_user_id" : 76348185,
  "text" : "@Interior Sec. Ken Salazar: What generated $55 billion & 440k jobs in 2009? Recreation in national parks. Learn more: http:\/\/t.co\/pK6gAmk1",
  "id" : 175722735639605248,
  "created_at" : "2012-03-02 23:22:19 +0000",
  "in_reply_to_screen_name" : "Interior",
  "in_reply_to_user_id_str" : "76348185",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/175716390945296384\/photo\/1",
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/yOp6SIOA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AnBFIGfCEAEjGLw.jpg",
      "id_str" : "175716390949490689",
      "id" : 175716390949490689,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AnBFIGfCEAEjGLw.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/yOp6SIOA"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/9sNl9TWJ",
      "expanded_url" : "http:\/\/wh.gov\/9ZQ",
      "display_url" : "wh.gov\/9ZQ"
    } ]
  },
  "geo" : { },
  "id_str" : "175716390945296384",
  "text" : "Photo of the Day: The President traveled to Nashua, N.H., to speak about our energy future. More: http:\/\/t.co\/9sNl9TWJ http:\/\/t.co\/yOp6SIOA",
  "id" : 175716390945296384,
  "created_at" : "2012-03-02 22:57:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whconservation",
      "indices" : [ 125, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/OfTozGgf",
      "expanded_url" : "http:\/\/ow.ly\/9pXJc",
      "display_url" : "ow.ly\/9pXJc"
    } ]
  },
  "geo" : { },
  "id_str" : "175657151136665600",
  "text" : "RT @interior: President Obama to address conservation conference today at 5:15 pm EST. Watch it live at http:\/\/t.co\/OfTozGgf #whconservation",
  "id" : 175657151136665600,
  "created_at" : "2012-03-02 19:01:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/XNetF3hi",
      "expanded_url" : "http:\/\/ow.ly\/9pIzv",
      "display_url" : "ow.ly\/9pIzv"
    } ]
  },
  "geo" : { },
  "id_str" : "175620172059656192",
  "text" : "Watch West Wing Week: Your behind-the-scences guide to everything that\u2019s happened this week at 1600 Pennsylvania Ave http:\/\/t.co\/XNetF3hi",
  "id" : 175620172059656192,
  "created_at" : "2012-03-02 16:34:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Carson",
      "screen_name" : "JonCarson44",
      "indices" : [ 3, 15 ],
      "id_str" : "1287388789",
      "id" : 1287388789
    }, {
      "name" : "HUD News | not",
      "screen_name" : "HUDNews",
      "indices" : [ 115, 123 ],
      "id_str" : "1881201980",
      "id" : 1881201980
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Philly",
      "indices" : [ 52, 59 ]
    }, {
      "text" : "WHSummit",
      "indices" : [ 129, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "175613904045613057",
  "text" : "RT @joncarson44: WH Community Partnership Summit in #Philly is interactive & dynamic. Join convo now w\/ @MarthaGSA @HUDNews. Use #WHSummit",
  "id" : 175613904045613057,
  "created_at" : "2012-03-02 16:09:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 3, 14 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "175342717432373248",
  "text" : "RT @whitehouse: Photo of the Day: The First Lady poses for a photo with a guest during the Department of Defense dinner last night. http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/175342363361804289\/photo\/1",
        "indices" : [ 116, 136 ],
        "url" : "http:\/\/t.co\/5EdwYJ3J",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Am7w81KCAAAuFin.jpg",
        "id_str" : "175342363365998592",
        "id" : 175342363365998592,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Am7w81KCAAAuFin.jpg",
        "sizes" : [ {
          "h" : 436,
          "resize" : "fit",
          "w" : 654
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 436,
          "resize" : "fit",
          "w" : 654
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/5EdwYJ3J"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "175342363361804289",
    "text" : "Photo of the Day: The First Lady poses for a photo with a guest during the Department of Defense dinner last night. http:\/\/t.co\/5EdwYJ3J",
    "id" : 175342363361804289,
    "created_at" : "2012-03-01 22:10:52 +0000",
    "user" : {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "protected" : false,
      "id_str" : "30313925",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
      "id" : 30313925,
      "verified" : true
    }
  },
  "id" : 175342717432373248,
  "created_at" : "2012-03-01 22:12:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/175342363361804289\/photo\/1",
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/5EdwYJ3J",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Am7w81KCAAAuFin.jpg",
      "id_str" : "175342363365998592",
      "id" : 175342363365998592,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Am7w81KCAAAuFin.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/5EdwYJ3J"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "175342363361804289",
  "text" : "Photo of the Day: The First Lady poses for a photo with a guest during the Department of Defense dinner last night. http:\/\/t.co\/5EdwYJ3J",
  "id" : 175342363361804289,
  "created_at" : "2012-03-01 22:10:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "175293655664435202",
  "text" : "RT @WHLive: Obama: Right now, four billion of your tax dollars subsidize the oil industry every year.  Four billion dollars.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "175290938711740416",
    "text" : "Obama: Right now, four billion of your tax dollars subsidize the oil industry every year.  Four billion dollars.",
    "id" : 175290938711740416,
    "created_at" : "2012-03-01 18:46:31 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 175293655664435202,
  "created_at" : "2012-03-01 18:57:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "175293534117699584",
  "text" : "RT @WHLive: Obama: Anyone who tells you we can drill our way out of this problem doesn\u2019t know what they\u2019re talking about \u2013 or isn\u2019t tell ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "175289787480154113",
    "text" : "Obama: Anyone who tells you we can drill our way out of this problem doesn\u2019t know what they\u2019re talking about \u2013 or isn\u2019t telling the truth.",
    "id" : 175289787480154113,
    "created_at" : "2012-03-01 18:41:56 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 175293534117699584,
  "created_at" : "2012-03-01 18:56:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "175293315787399168",
  "text" : "RT @WHLive: Obama: You can see on the chart behind me, since I took office, our dependence on foreign oil has gone down every year. http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WHLive\/status\/175288577884831744\/photo\/1",
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/yNfLg7TA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Am7ACHGCQAAenTR.jpg",
        "id_str" : "175288578010660864",
        "id" : 175288578010660864,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Am7ACHGCQAAenTR.jpg",
        "sizes" : [ {
          "h" : 354,
          "resize" : "fit",
          "w" : 520
        }, {
          "h" : 231,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 354,
          "resize" : "fit",
          "w" : 520
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 354,
          "resize" : "fit",
          "w" : 520
        } ],
        "display_url" : "pic.twitter.com\/yNfLg7TA"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "175288577884831744",
    "text" : "Obama: You can see on the chart behind me, since I took office, our dependence on foreign oil has gone down every year. http:\/\/t.co\/yNfLg7TA",
    "id" : 175288577884831744,
    "created_at" : "2012-03-01 18:37:08 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 175293315787399168,
  "created_at" : "2012-03-01 18:55:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 129, 136 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "175286250209681408",
  "text" : "Happening now: President Obama speaks on our energy future at Nashua Community College. Watch Live: http:\/\/t.co\/u95y7hhB Follow: @WHLive",
  "id" : 175286250209681408,
  "created_at" : "2012-03-01 18:27:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 20, 31 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EasterEggRoll",
      "indices" : [ 32, 46 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/l2vsfNC0",
      "expanded_url" : "http:\/\/youtu.be\/wn_DS2UjoXg",
      "display_url" : "youtu.be\/wn_DS2UjoXg"
    } ]
  },
  "geo" : { },
  "id_str" : "175251240991731712",
  "text" : "Announcing the 2012 @WhiteHouse #EasterEggRoll & ticket lottery: http:\/\/t.co\/l2vsfNC0",
  "id" : 175251240991731712,
  "created_at" : "2012-03-01 16:08:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/175234924348063745\/photo\/1",
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/QWCtcsYy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Am6PPDpCQAM-laH.jpg",
      "id_str" : "175234924352258051",
      "id" : 175234924352258051,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Am6PPDpCQAM-laH.jpg",
      "sizes" : [ {
        "h" : 448,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 190,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 336,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/QWCtcsYy"
    } ],
    "hashtags" : [ {
      "text" : "oil",
      "indices" : [ 61, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/Caokw4Ux",
      "expanded_url" : "http:\/\/wh.gov\/9jN",
      "display_url" : "wh.gov\/9jN"
    } ]
  },
  "geo" : { },
  "id_str" : "175234924348063745",
  "text" : "Since President Obama took office, our dependence on foreign #oil has gone down every year: http:\/\/t.co\/Caokw4Ux Look: http:\/\/t.co\/QWCtcsYy",
  "id" : 175234924348063745,
  "created_at" : "2012-03-01 15:03:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Simmons 1.0",
      "screen_name" : "SportsGuy33",
      "indices" : [ 3, 15 ],
      "id_str" : "941724637",
      "id" : 941724637
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/4nZQfSGx",
      "expanded_url" : "http:\/\/es.pn\/xibE3m",
      "display_url" : "es.pn\/xibE3m"
    } ]
  },
  "geo" : { },
  "id_str" : "175223258134757376",
  "text" : "RT @sportsguy33: BS Report: Went to the White House and did a podcast with President Obama. What a cool day. http:\/\/t.co\/4nZQfSGx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 112 ],
        "url" : "http:\/\/t.co\/4nZQfSGx",
        "expanded_url" : "http:\/\/es.pn\/xibE3m",
        "display_url" : "es.pn\/xibE3m"
      } ]
    },
    "geo" : { },
    "id_str" : "175196325481156608",
    "text" : "BS Report: Went to the White House and did a podcast with President Obama. What a cool day. http:\/\/t.co\/4nZQfSGx",
    "id" : 175196325481156608,
    "created_at" : "2012-03-01 12:30:33 +0000",
    "user" : {
      "name" : "Bill Simmons",
      "screen_name" : "BillSimmons",
      "protected" : false,
      "id_str" : "32765534",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/645990884165578753\/moYctN8w_normal.jpg",
      "id" : 32765534,
      "verified" : true
    }
  },
  "id" : 175223258134757376,
  "created_at" : "2012-03-01 14:17:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
} ]