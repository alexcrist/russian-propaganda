Grailbird.data.tweets_2012_09 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "252488813484584961",
  "text" : "RT @JoiningForces: Today we honor Gold Star Mothers, whose children fell serving our country. Your sacrifice is inspiring, and we are al ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "252488698355146754",
    "text" : "Today we honor Gold Star Mothers, whose children fell serving our country. Your sacrifice is inspiring, and we are all grateful. \u2013mo",
    "id" : 252488698355146754,
    "created_at" : "2012-09-30 19:22:51 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 252488813484584961,
  "created_at" : "2012-09-30 19:23:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "252149910969929728",
  "text" : "RT @Brundage44: In the weekly address, POTUS discusses steps he took to help homeowners &amp; calls on Congress to help families refinan ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 123, 143 ],
        "url" : "http:\/\/t.co\/KWxlTMMD",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2012\/09\/29\/weekly-address-it-s-time-congress-help-responsible-homeowners",
        "display_url" : "whitehouse.gov\/blog\/2012\/09\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "252044186797350912",
    "text" : "In the weekly address, POTUS discusses steps he took to help homeowners &amp; calls on Congress to help families refinance http:\/\/t.co\/KWxlTMMD",
    "id" : 252044186797350912,
    "created_at" : "2012-09-29 13:56:31 +0000",
    "user" : {
      "name" : "Liz Allen",
      "screen_name" : "LizAllen44",
      "protected" : false,
      "id_str" : "562456722",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705867932392407042\/-1npI72O_normal.jpg",
      "id" : 562456722,
      "verified" : true
    }
  },
  "id" : 252149910969929728,
  "created_at" : "2012-09-29 20:56:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/252106501483806720\/photo\/1",
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/HF3oJb6e",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A3-phwNCQAAhvi0.jpg",
      "id_str" : "252106501496389632",
      "id" : 252106501496389632,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A3-phwNCQAAhvi0.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/HF3oJb6e"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "252106501483806720",
  "text" : "Photo of the day: President Obama talks on the phone with Prime Minister Netanyahu of Israel, in the Oval Office. http:\/\/t.co\/HF3oJb6e",
  "id" : 252106501483806720,
  "created_at" : "2012-09-29 18:04:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 3, 12 ],
      "id_str" : "36719281",
      "id" : 36719281
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "252089513722142721",
  "text" : "RT @letsmove: Today is National Public Lands Day. Fees are being waved at federal parks nationwide. Check out a location near you: http: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 137 ],
        "url" : "http:\/\/t.co\/3V3Xop89",
        "expanded_url" : "http:\/\/bit.ly\/nKsSH9",
        "display_url" : "bit.ly\/nKsSH9"
      } ]
    },
    "geo" : { },
    "id_str" : "252054725606899712",
    "text" : "Today is National Public Lands Day. Fees are being waved at federal parks nationwide. Check out a location near you: http:\/\/t.co\/3V3Xop89",
    "id" : 252054725606899712,
    "created_at" : "2012-09-29 14:38:24 +0000",
    "user" : {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "protected" : false,
      "id_str" : "36719281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207340336\/780fc13e31b6fdd80bd57d000dc13838_normal.jpeg",
      "id" : 36719281,
      "verified" : true
    }
  },
  "id" : 252089513722142721,
  "created_at" : "2012-09-29 16:56:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/tX7JfVIR",
      "expanded_url" : "http:\/\/on.wh.gov\/t24GIA",
      "display_url" : "on.wh.gov\/t24GIA"
    } ]
  },
  "geo" : { },
  "id_str" : "252047509357228032",
  "text" : "Weekly Address: It's Time for Congress to Help Responsible Homeowners: http:\/\/t.co\/tX7JfVIR",
  "id" : 252047509357228032,
  "created_at" : "2012-09-29 14:09:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 81, 84 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/251814690194337793\/photo\/1",
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/Vld0AA0H",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A36gIGbCMAECsPe.jpg",
      "id_str" : "251814690202726401",
      "id" : 251814690202726401,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A36gIGbCMAECsPe.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Vld0AA0H"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "251814690194337793",
  "text" : "Photo of the day: President Obama looks at a magazine outside the Oval Office as @VP Biden talks with an advisor. http:\/\/t.co\/Vld0AA0H",
  "id" : 251814690194337793,
  "created_at" : "2012-09-28 22:44:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "humantrafficking",
      "indices" : [ 50, 67 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/dt3ctOXs",
      "expanded_url" : "http:\/\/on.wh.gov\/yOw0Bt",
      "display_url" : "on.wh.gov\/yOw0Bt"
    }, {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/pfcwfGEX",
      "expanded_url" : "http:\/\/on.wh.gov\/9dzI00",
      "display_url" : "on.wh.gov\/9dzI00"
    } ]
  },
  "geo" : { },
  "id_str" : "251798143799271425",
  "text" : "Missed yesterday's White House Google+ Hangout on #humantrafficking? Learn more: http:\/\/t.co\/dt3ctOXs Watch: http:\/\/t.co\/pfcwfGEX",
  "id" : 251798143799271425,
  "created_at" : "2012-09-28 21:38:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NationalPublicLandsDay",
      "indices" : [ 17, 40 ]
    } ],
    "urls" : [ {
      "indices" : [ 122, 142 ],
      "url" : "http:\/\/t.co\/3F8eXx6x",
      "expanded_url" : "http:\/\/on.wh.gov\/HDgqng",
      "display_url" : "on.wh.gov\/HDgqng"
    } ]
  },
  "geo" : { },
  "id_str" : "251782135701204992",
  "text" : "Tomorrow 9\/29 is #NationalPublicLandsDay! Get free entry to America's National Parks. Plan a visit &amp; spread the word: http:\/\/t.co\/3F8eXx6x",
  "id" : 251782135701204992,
  "created_at" : "2012-09-28 20:35:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/0fJ2YeST",
      "expanded_url" : "http:\/\/on.wh.gov\/iiMStv",
      "display_url" : "on.wh.gov\/iiMStv"
    } ]
  },
  "geo" : { },
  "id_str" : "251765754918236161",
  "text" : "West Wing Week 09\/28\/2012: Your behind the scenes guide to this week at 1600 Pennsylvania Ave. Video: http:\/\/t.co\/0fJ2YeST",
  "id" : 251765754918236161,
  "created_at" : "2012-09-28 19:30:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tina canali",
      "screen_name" : "tinacan25",
      "indices" : [ 3, 13 ],
      "id_str" : "120879699",
      "id" : 120879699
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHGarden",
      "indices" : [ 49, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "251764024679747584",
  "text" : "RT @tinacan25: So excited to be accepted for the #WHGarden social 3 weeks from today! Tours also open to public, see here http:\/\/t.co\/iC ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHGarden",
        "indices" : [ 34, 43 ]
      } ],
      "urls" : [ {
        "indices" : [ 107, 127 ],
        "url" : "http:\/\/t.co\/iCupICaL",
        "expanded_url" : "http:\/\/goo.gl\/J23Zm",
        "display_url" : "goo.gl\/J23Zm"
      } ]
    },
    "geo" : { },
    "id_str" : "251726711950045184",
    "text" : "So excited to be accepted for the #WHGarden social 3 weeks from today! Tours also open to public, see here http:\/\/t.co\/iCupICaL for details!",
    "id" : 251726711950045184,
    "created_at" : "2012-09-28 16:54:59 +0000",
    "user" : {
      "name" : "tina canali",
      "screen_name" : "tinacan25",
      "protected" : false,
      "id_str" : "120879699",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1452829951\/b814cb1c-6551-4d1a-93dd-bdb82b166c12_normal.png",
      "id" : 120879699,
      "verified" : false
    }
  },
  "id" : 251764024679747584,
  "created_at" : "2012-09-28 19:23:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualFutures",
      "indices" : [ 81, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/MzN4QTER",
      "expanded_url" : "http:\/\/on.wh.gov\/PZKkuk",
      "display_url" : "on.wh.gov\/PZKkuk"
    } ]
  },
  "geo" : { },
  "id_str" : "251484495067369474",
  "text" : "Empowering Women and Girls in the United States and Abroad: http:\/\/t.co\/MzN4QTER #EqualFutures",
  "id" : 251484495067369474,
  "created_at" : "2012-09-28 00:52:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Natalie Grant",
      "screen_name" : "NatalieGrant",
      "indices" : [ 3, 16 ],
      "id_str" : "14453529",
      "id" : 14453529
    }, {
      "name" : "Abolition INTL",
      "screen_name" : "AbolitionINTl",
      "indices" : [ 26, 40 ],
      "id_str" : "2813601552",
      "id" : 2813601552
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 45, 56 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHHangout",
      "indices" : [ 65, 75 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/66joxVKW",
      "expanded_url" : "http:\/\/on.wh.gov\/kgdOVz",
      "display_url" : "on.wh.gov\/kgdOVz"
    } ]
  },
  "geo" : { },
  "id_str" : "251355418297782273",
  "text" : "MT @NatalieGrant: Join me @AbolitionIntl for @whitehouse Google+ #WHHangout on fighting trafficking \/\/ Happening now: http:\/\/t.co\/66joxVKW",
  "id" : 251355418297782273,
  "created_at" : "2012-09-27 16:19:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHHangout",
      "indices" : [ 24, 34 ]
    }, {
      "text" : "humantrafficking",
      "indices" : [ 97, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/iOFBcuHT",
      "expanded_url" : "http:\/\/WH.gov\/live",
      "display_url" : "WH.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "251353449688616960",
  "text" : "RT @WHLive: Watch live: #WHHangout w\/ Tina Tchen &amp; Samantha Power on Admin efforts to combat #humantrafficking http:\/\/t.co\/iOFBcuHT  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WHLive\/status\/251352856953765888\/photo\/1",
        "indices" : [ 124, 144 ],
        "url" : "http:\/\/t.co\/7VdTkTrk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A3z8F3hCQAIQ-EK.png",
        "id_str" : "251352856957960194",
        "id" : 251352856957960194,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A3z8F3hCQAIQ-EK.png",
        "sizes" : [ {
          "h" : 192,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 339,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 361,
          "resize" : "fit",
          "w" : 638
        }, {
          "h" : 361,
          "resize" : "fit",
          "w" : 638
        } ],
        "display_url" : "pic.twitter.com\/7VdTkTrk"
      } ],
      "hashtags" : [ {
        "text" : "WHHangout",
        "indices" : [ 12, 22 ]
      }, {
        "text" : "humantrafficking",
        "indices" : [ 85, 102 ]
      } ],
      "urls" : [ {
        "indices" : [ 103, 123 ],
        "url" : "http:\/\/t.co\/iOFBcuHT",
        "expanded_url" : "http:\/\/WH.gov\/live",
        "display_url" : "WH.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "251352856953765888",
    "text" : "Watch live: #WHHangout w\/ Tina Tchen &amp; Samantha Power on Admin efforts to combat #humantrafficking http:\/\/t.co\/iOFBcuHT http:\/\/t.co\/7VdTkTrk",
    "id" : 251352856953765888,
    "created_at" : "2012-09-27 16:09:25 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 251353449688616960,
  "created_at" : "2012-09-27 16:11:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "humantrafficking",
      "indices" : [ 52, 69 ]
    }, {
      "text" : "WHHangout",
      "indices" : [ 100, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/YpM1yfjZ",
      "expanded_url" : "http:\/\/at.wh.gov\/e2z1Y",
      "display_url" : "at.wh.gov\/e2z1Y"
    } ]
  },
  "geo" : { },
  "id_str" : "251351635996069888",
  "text" : "Happening now: Join a live video chat on combatting #humantrafficking. Watch live &amp; ask ?s with #WHHangout: http:\/\/t.co\/YpM1yfjZ",
  "id" : 251351635996069888,
  "created_at" : "2012-09-27 16:04:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HumanTrafficking",
      "indices" : [ 21, 38 ]
    }, {
      "text" : "WHHangout",
      "indices" : [ 51, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 122, 142 ],
      "url" : "http:\/\/t.co\/uHD3c9D8",
      "expanded_url" : "http:\/\/on.wh.gov\/8Yak6Z",
      "display_url" : "on.wh.gov\/8Yak6Z"
    } ]
  },
  "geo" : { },
  "id_str" : "251139605024342016",
  "text" : "Have questions about #HumanTrafficking? Ask now w\/ #WHHangout &amp; then watch our Google+ Hangout tomorrow 9\/27 at 12ET: http:\/\/t.co\/uHD3c9D8",
  "id" : 251139605024342016,
  "created_at" : "2012-09-27 02:02:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualFutures",
      "indices" : [ 58, 71 ]
    }, {
      "text" : "HumanTrafficking",
      "indices" : [ 108, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 127, 147 ],
      "url" : "http:\/\/t.co\/QqQx2QOE",
      "expanded_url" : "http:\/\/on.wh.gov\/up5uPj",
      "display_url" : "on.wh.gov\/up5uPj"
    } ]
  },
  "geo" : { },
  "id_str" : "251122757591519232",
  "text" : "MT @vj44: 2 major steps to empower all women &amp; girls: #EqualFutures Partnership &amp; efforts to combat #HumanTrafficking: http:\/\/t.co\/QqQx2QOE",
  "id" : 251122757591519232,
  "created_at" : "2012-09-27 00:55:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Labor Department",
      "screen_name" : "USDOL",
      "indices" : [ 120, 126 ],
      "id_str" : "20179628",
      "id" : 20179628
    }, {
      "name" : "U.S. Commerce Dept.",
      "screen_name" : "CommerceGov",
      "indices" : [ 127, 139 ],
      "id_str" : "110541296",
      "id" : 110541296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/euI0C3bI",
      "expanded_url" : "http:\/\/on.wh.gov\/sa4zbz",
      "display_url" : "on.wh.gov\/sa4zbz"
    } ]
  },
  "geo" : { },
  "id_str" : "251106864249577472",
  "text" : "The Obama admin teams up to bring jobs back to the U.S. with the Make it in America Challenge: http:\/\/t.co\/euI0C3bI (cc @USDOL @CommerceGov)",
  "id" : 251106864249577472,
  "created_at" : "2012-09-26 23:51:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HumanTrafficking",
      "indices" : [ 68, 85 ]
    }, {
      "text" : "WHHangout",
      "indices" : [ 124, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/zsSPNg2v",
      "expanded_url" : "http:\/\/on.wh.gov\/MsqjpC",
      "display_url" : "on.wh.gov\/MsqjpC"
    } ]
  },
  "geo" : { },
  "id_str" : "251091383023194113",
  "text" : "Tomorrow, 9\/27 at 12ET join us for a White House Google+ Hangout on #HumanTrafficking: http:\/\/t.co\/zsSPNg2v. Ask Q's now w\/ #WHHangout",
  "id" : 251091383023194113,
  "created_at" : "2012-09-26 22:50:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/251080895707115520\/photo\/1",
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/ZFIV6xtz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A3wEvo8CcAAoXO8.jpg",
      "id_str" : "251080895715504128",
      "id" : 251080895715504128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A3wEvo8CcAAoXO8.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ZFIV6xtz"
    } ],
    "hashtags" : [ {
      "text" : "CGI2012",
      "indices" : [ 82, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "251080895707115520",
  "text" : "Former President Clinton watches backstage as President Obama delivers remarks at #CGI2012 yesterday in N.Y.C. Photo: http:\/\/t.co\/ZFIV6xtz",
  "id" : 251080895707115520,
  "created_at" : "2012-09-26 22:08:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 30, 41 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "251066122273685504",
  "text" : "RT @arneduncan: Check out the @WhiteHouse's excellent photos from our \"Education Drives America\" bus tour across the country: http:\/\/t.c ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 14, 25 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 130 ],
        "url" : "http:\/\/t.co\/iC6Gli2V",
        "expanded_url" : "http:\/\/go.usa.gov\/YcXj",
        "display_url" : "go.usa.gov\/YcXj"
      } ]
    },
    "geo" : { },
    "id_str" : "251029444054118400",
    "text" : "Check out the @WhiteHouse's excellent photos from our \"Education Drives America\" bus tour across the country: http:\/\/t.co\/iC6Gli2V",
    "id" : 251029444054118400,
    "created_at" : "2012-09-26 18:44:18 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 251066122273685504,
  "created_at" : "2012-09-26 21:10:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HumanTrafficking",
      "indices" : [ 65, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/xXzd33o5",
      "expanded_url" : "http:\/\/on.wh.gov\/pgzrKk",
      "display_url" : "on.wh.gov\/pgzrKk"
    } ]
  },
  "geo" : { },
  "id_str" : "250640208037556225",
  "text" : "Fact Sheet: The Obama Administration Announces Efforts to Combat #HumanTrafficking at Home &amp; Abroad: http:\/\/t.co\/xXzd33o5",
  "id" : 250640208037556225,
  "created_at" : "2012-09-25 16:57:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "humantrafficking",
      "indices" : [ 47, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "250639953267142656",
  "text" : "RT @WHLive: President Obama: Our fight against #humantrafficking is one of the great human rights causes of our time &amp; the US will c ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "humantrafficking",
        "indices" : [ 35, 52 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "250639884950310912",
    "text" : "President Obama: Our fight against #humantrafficking is one of the great human rights causes of our time &amp; the US will continue to lead it.",
    "id" : 250639884950310912,
    "created_at" : "2012-09-25 16:56:19 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 250639953267142656,
  "created_at" : "2012-09-25 16:56:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "humantrafficking",
      "indices" : [ 31, 48 ]
    }, {
      "text" : "CGI2012",
      "indices" : [ 52, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "250639484679491585",
  "text" : "RT @WHLive: President Obama on #humantrafficking at #CGI2012: \"This cycle can be broken; victims can become not only survivors, but lead ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "humantrafficking",
        "indices" : [ 19, 36 ]
      }, {
        "text" : "CGI2012",
        "indices" : [ 40, 48 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "250639132236324864",
    "text" : "President Obama on #humantrafficking at #CGI2012: \"This cycle can be broken; victims can become not only survivors, but leaders.\"",
    "id" : 250639132236324864,
    "created_at" : "2012-09-25 16:53:20 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 250639484679491585,
  "created_at" : "2012-09-25 16:54:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "250638107555274752",
  "text" : "RT @WHLive: President Obama: \"But no government, no nation, can meet this challenge alone. Everyone has a responsibility. Every nation c ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "250637810711789570",
    "text" : "President Obama: \"But no government, no nation, can meet this challenge alone. Everyone has a responsibility. Every nation can take action.\"",
    "id" : 250637810711789570,
    "created_at" : "2012-09-25 16:48:05 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 250638107555274752,
  "created_at" : "2012-09-25 16:49:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CGI2012",
      "indices" : [ 31, 39 ]
    }, {
      "text" : "humantrafficking",
      "indices" : [ 43, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "250636665054457857",
  "text" : "RT @WHLive: President Obama at #CGI2012 on #humantrafficking: \"Nations must speak with one voice\u2014our people, our children, are not for s ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CGI2012",
        "indices" : [ 19, 27 ]
      }, {
        "text" : "humantrafficking",
        "indices" : [ 31, 48 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "250636485563400193",
    "text" : "President Obama at #CGI2012 on #humantrafficking: \"Nations must speak with one voice\u2014our people, our children, are not for sale.\"",
    "id" : 250636485563400193,
    "created_at" : "2012-09-25 16:42:49 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 250636665054457857,
  "created_at" : "2012-09-25 16:43:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "humantrafficking",
      "indices" : [ 31, 48 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "250636040514174976",
  "text" : "RT @WHLive: President Obama on #humantrafficking: \"It\u2019s barbaric, it\u2019s evil, and it has no place in a civilized world.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "humantrafficking",
        "indices" : [ 19, 36 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "250635644697735168",
    "text" : "President Obama on #humantrafficking: \"It\u2019s barbaric, it\u2019s evil, and it has no place in a civilized world.\"",
    "id" : 250635644697735168,
    "created_at" : "2012-09-25 16:39:28 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 250636040514174976,
  "created_at" : "2012-09-25 16:41:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "CGI",
      "screen_name" : "ClintonGlobal",
      "indices" : [ 74, 88 ],
      "id_str" : "68999404",
      "id" : 68999404
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CGI2012",
      "indices" : [ 101, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http:\/\/t.co\/g5icuVZL",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "250634570209325056",
  "text" : "RT @WHLive: Happening now on http:\/\/t.co\/g5icuVZL: President Obama speaks @ClintonGlobal Initiative. #CGI2012",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CGI",
        "screen_name" : "ClintonGlobal",
        "indices" : [ 62, 76 ],
        "id_str" : "68999404",
        "id" : 68999404
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CGI2012",
        "indices" : [ 89, 97 ]
      } ],
      "urls" : [ {
        "indices" : [ 17, 37 ],
        "url" : "http:\/\/t.co\/g5icuVZL",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "250633817642123266",
    "text" : "Happening now on http:\/\/t.co\/g5icuVZL: President Obama speaks @ClintonGlobal Initiative. #CGI2012",
    "id" : 250633817642123266,
    "created_at" : "2012-09-25 16:32:13 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 250634570209325056,
  "created_at" : "2012-09-25 16:35:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "humantrafficking",
      "indices" : [ 116, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/g5icuVZL",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "250625865451466753",
  "text" : "RT @WHLive: Starting at 12:10ET on http:\/\/t.co\/g5icuVZL: President Obama speaks at the Clinton Global Initiative on #humantrafficking.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "humantrafficking",
        "indices" : [ 104, 121 ]
      } ],
      "urls" : [ {
        "indices" : [ 23, 43 ],
        "url" : "http:\/\/t.co\/g5icuVZL",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "250625769380933632",
    "text" : "Starting at 12:10ET on http:\/\/t.co\/g5icuVZL: President Obama speaks at the Clinton Global Initiative on #humantrafficking.",
    "id" : 250625769380933632,
    "created_at" : "2012-09-25 16:00:14 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 250625865451466753,
  "created_at" : "2012-09-25 16:00:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UNGA",
      "indices" : [ 31, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "250608093707264001",
  "text" : "RT @WHLive: President Obama at #UNGA: \"What gives me the most hope is not the actions of leaders \u2013 it is the people I\u2019ve seen\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UNGA",
        "indices" : [ 19, 24 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "250607915168309248",
    "text" : "President Obama at #UNGA: \"What gives me the most hope is not the actions of leaders \u2013 it is the people I\u2019ve seen\"",
    "id" : 250607915168309248,
    "created_at" : "2012-09-25 14:49:17 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 250608093707264001,
  "created_at" : "2012-09-25 14:50:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "250606212033429504",
  "text" : "RT @WHLive: President Obama: \"We must seize this moment &amp; America stands ready to work with all who are willing to embrace a better  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UNGA",
        "indices" : [ 133, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "250605981560627200",
    "text" : "President Obama: \"We must seize this moment &amp; America stands ready to work with all who are willing to embrace a better future.\" #UNGA",
    "id" : 250605981560627200,
    "created_at" : "2012-09-25 14:41:36 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 250606212033429504,
  "created_at" : "2012-09-25 14:42:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UNGA",
      "indices" : [ 107, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "250604636816416768",
  "text" : "RT @WHLive: President Obama: \"On this we must agree: there is no speech that justifies mindless violence.\" #UNGA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UNGA",
        "indices" : [ 95, 100 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "250604448492179456",
    "text" : "President Obama: \"On this we must agree: there is no speech that justifies mindless violence.\" #UNGA",
    "id" : 250604448492179456,
    "created_at" : "2012-09-25 14:35:31 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 250604636816416768,
  "created_at" : "2012-09-25 14:36:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "250604182900465664",
  "text" : "RT @WHLive: President Obama: \"I accept that people are going to call me awful things every day &amp; I will always defend their right to ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UNGA",
        "indices" : [ 132, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "250604073764675584",
    "text" : "President Obama: \"I accept that people are going to call me awful things every day &amp; I will always defend their right to do so\" #UNGA",
    "id" : 250604073764675584,
    "created_at" : "2012-09-25 14:34:01 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 250604182900465664,
  "created_at" : "2012-09-25 14:34:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "250603282299486209",
  "text" : "RT @WHLive: President Obama: \"The turmoil of recent weeks reminds us that the path to democracy does not end with the casting of a ballo ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UNGA",
        "indices" : [ 127, 132 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "250603001486643200",
    "text" : "President Obama: \"The turmoil of recent weeks reminds us that the path to democracy does not end with the casting of a ballot\" #UNGA",
    "id" : 250603001486643200,
    "created_at" : "2012-09-25 14:29:46 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 250603282299486209,
  "created_at" : "2012-09-25 14:30:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UNGA",
      "indices" : [ 31, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "250603022302973952",
  "text" : "RT @WHLive: President Obama at #UNGA: \"Let us remember that this is a season of progress\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UNGA",
        "indices" : [ 19, 24 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "250602771341000704",
    "text" : "President Obama at #UNGA: \"Let us remember that this is a season of progress\"",
    "id" : 250602771341000704,
    "created_at" : "2012-09-25 14:28:51 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 250603022302973952,
  "created_at" : "2012-09-25 14:29:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UNGA",
      "indices" : [ 31, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "250601800443518976",
  "text" : "RT @WHLive: President Obama at #UNGA: \"I tell you this story because Chris Stevens embodied the best of America.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UNGA",
        "indices" : [ 19, 24 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "250601475636596736",
    "text" : "President Obama at #UNGA: \"I tell you this story because Chris Stevens embodied the best of America.\"",
    "id" : 250601475636596736,
    "created_at" : "2012-09-25 14:23:42 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 250601800443518976,
  "created_at" : "2012-09-25 14:24:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UNGA",
      "indices" : [ 111, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/g5icuVZL",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "250601103752830976",
  "text" : "RT @WHLive: Happening now: President Obama speaks to the UN General Assembly. Watch live: http:\/\/t.co\/g5icuVZL #UNGA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UNGA",
        "indices" : [ 99, 104 ]
      } ],
      "urls" : [ {
        "indices" : [ 78, 98 ],
        "url" : "http:\/\/t.co\/g5icuVZL",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "250600852274962433",
    "text" : "Happening now: President Obama speaks to the UN General Assembly. Watch live: http:\/\/t.co\/g5icuVZL #UNGA",
    "id" : 250600852274962433,
    "created_at" : "2012-09-25 14:21:13 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 250601103752830976,
  "created_at" : "2012-09-25 14:22:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UNGA",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 23, 43 ],
      "url" : "http:\/\/t.co\/u95tzH8r",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "250588963281186818",
  "text" : "Starting at 10:10ET on http:\/\/t.co\/u95tzH8r: President Obama speaks to the UN General Assembly #UNGA",
  "id" : 250588963281186818,
  "created_at" : "2012-09-25 13:33:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/250370486012350464\/photo\/1",
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/q2iLlPtp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A3l-oWmCEAARMWv.jpg",
      "id_str" : "250370486020739072",
      "id" : 250370486020739072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A3l-oWmCEAARMWv.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/q2iLlPtp"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/K3Bhzpzd",
      "expanded_url" : "http:\/\/on.wh.gov\/X2xWvG",
      "display_url" : "on.wh.gov\/X2xWvG"
    } ]
  },
  "geo" : { },
  "id_str" : "250370486012350464",
  "text" : "Photo Gallery: Behind the scenes in August 2012: http:\/\/t.co\/K3Bhzpzd Including President Obama with a happy baby: http:\/\/t.co\/q2iLlPtp",
  "id" : 250370486012350464,
  "created_at" : "2012-09-24 23:05:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualFutures",
      "indices" : [ 65, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "250354441880997888",
  "text" : "RT @vj44: Today US came together w\/ 12 other countries to launch #EqualFutures Partnership to empower women &amp; girls Find out more ht ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EqualFutures",
        "indices" : [ 55, 68 ]
      } ],
      "urls" : [ {
        "indices" : [ 124, 144 ],
        "url" : "http:\/\/t.co\/x7cGvd0B",
        "expanded_url" : "http:\/\/wh.gov\/BaYS",
        "display_url" : "wh.gov\/BaYS"
      } ]
    },
    "geo" : { },
    "id_str" : "250350616784826368",
    "text" : "Today US came together w\/ 12 other countries to launch #EqualFutures Partnership to empower women &amp; girls Find out more http:\/\/t.co\/x7cGvd0B",
    "id" : 250350616784826368,
    "created_at" : "2012-09-24 21:46:52 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 250354441880997888,
  "created_at" : "2012-09-24 22:02:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/txDfnYsO",
      "expanded_url" : "http:\/\/bit.ly\/PvEBJk",
      "display_url" : "bit.ly\/PvEBJk"
    } ]
  },
  "geo" : { },
  "id_str" : "250278534680035328",
  "text" : "RT @petesouza: New behind-the-scenes photos of President Obama from August: http:\/\/t.co\/txDfnYsO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 81 ],
        "url" : "http:\/\/t.co\/txDfnYsO",
        "expanded_url" : "http:\/\/bit.ly\/PvEBJk",
        "display_url" : "bit.ly\/PvEBJk"
      } ]
    },
    "geo" : { },
    "id_str" : "249284639347331072",
    "text" : "New behind-the-scenes photos of President Obama from August: http:\/\/t.co\/txDfnYsO",
    "id" : 249284639347331072,
    "created_at" : "2012-09-21 23:11:04 +0000",
    "user" : {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "protected" : false,
      "id_str" : "18215973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771916869808844800\/7d_poH48_normal.jpg",
      "id" : 18215973,
      "verified" : true
    }
  },
  "id" : 250278534680035328,
  "created_at" : "2012-09-24 17:00:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/249719371633672192\/photo\/1",
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/WQGC4ZVH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A3cucghCQAAJeCO.jpg",
      "id_str" : "249719371642060800",
      "id" : 249719371642060800,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A3cucghCQAAJeCO.jpg",
      "sizes" : [ {
        "h" : 336,
        "resize" : "fit",
        "w" : 504
      }, {
        "h" : 336,
        "resize" : "fit",
        "w" : 504
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 336,
        "resize" : "fit",
        "w" : 504
      } ],
      "display_url" : "pic.twitter.com\/WQGC4ZVH"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/tzQdDc90",
      "expanded_url" : "http:\/\/on.wh.gov\/peBiF3",
      "display_url" : "on.wh.gov\/peBiF3"
    } ]
  },
  "geo" : { },
  "id_str" : "249719371633672192",
  "text" : "Photo Gallery: Presidents &amp; Olympians http:\/\/t.co\/tzQdDc90 Pic: President Johnson pins a flower on Peggy Flemming http:\/\/t.co\/WQGC4ZVH",
  "id" : 249719371633672192,
  "created_at" : "2012-09-23 03:58:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/249541660537671680\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/sSvCZZY9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A3aM0XFCUAAl5gc.jpg",
      "id_str" : "249541660541865984",
      "id" : 249541660541865984,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A3aM0XFCUAAl5gc.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/sSvCZZY9"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/HdaCIDlD",
      "expanded_url" : "http:\/\/on.wh.gov\/yIogdq",
      "display_url" : "on.wh.gov\/yIogdq"
    } ]
  },
  "geo" : { },
  "id_str" : "249541660537671680",
  "text" : "The Emancipation Proclamation is 150 years old: http:\/\/t.co\/HdaCIDlD Pic: President Obama w\/ a copy in the Oval Office: http:\/\/t.co\/sSvCZZY9",
  "id" : 249541660537671680,
  "created_at" : "2012-09-22 16:12:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/OjMiUR35",
      "expanded_url" : "http:\/\/on.wh.gov\/Ua9U4C",
      "display_url" : "on.wh.gov\/Ua9U4C"
    } ]
  },
  "geo" : { },
  "id_str" : "249510278155350016",
  "text" : "Weekly Address: Congress Must Act to Create Jobs and Grow the Economy: http:\/\/t.co\/OjMiUR35",
  "id" : 249510278155350016,
  "created_at" : "2012-09-22 14:07:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/249417617536872448\/photo\/1",
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/5lgclyXm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A3YcAG5CcAAuMhl.jpg",
      "id_str" : "249417617541066752",
      "id" : 249417617541066752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A3YcAG5CcAAuMhl.jpg",
      "sizes" : [ {
        "h" : 336,
        "resize" : "fit",
        "w" : 504
      }, {
        "h" : 336,
        "resize" : "fit",
        "w" : 504
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 336,
        "resize" : "fit",
        "w" : 504
      } ],
      "display_url" : "pic.twitter.com\/5lgclyXm"
    } ],
    "hashtags" : [ {
      "text" : "spottheshuttle",
      "indices" : [ 84, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/ONaoSFaf",
      "expanded_url" : "http:\/\/on.wh.gov\/hQth6y",
      "display_url" : "on.wh.gov\/hQth6y"
    } ]
  },
  "geo" : { },
  "id_str" : "249417617536872448",
  "text" : "Photo Gallery: Space Shuttle Endeavour Takes Its Final Flight: http:\/\/t.co\/ONaoSFaf #spottheshuttle Photo: http:\/\/t.co\/5lgclyXm",
  "id" : 249417617536872448,
  "created_at" : "2012-09-22 07:59:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/249337725654810624\/photo\/1",
      "indices" : [ 123, 143 ],
      "url" : "http:\/\/t.co\/F3l49k7N",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A3XTVycCQAA95E0.jpg",
      "id_str" : "249337725659004928",
      "id" : 249337725659004928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A3XTVycCQAA95E0.jpg",
      "sizes" : [ {
        "h" : 336,
        "resize" : "fit",
        "w" : 223
      }, {
        "h" : 336,
        "resize" : "fit",
        "w" : 223
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 336,
        "resize" : "fit",
        "w" : 223
      }, {
        "h" : 336,
        "resize" : "fit",
        "w" : 223
      } ],
      "display_url" : "pic.twitter.com\/F3l49k7N"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/nXAjboGM",
      "expanded_url" : "http:\/\/on.wh.gov\/3hEc1a",
      "display_url" : "on.wh.gov\/3hEc1a"
    } ]
  },
  "geo" : { },
  "id_str" : "249337725654810624",
  "text" : "Photo Gallery: Presidents &amp; Olympians through the years: http:\/\/t.co\/nXAjboGM Incl President Reagan w\/ Mary Lou Retton http:\/\/t.co\/F3l49k7N",
  "id" : 249337725654810624,
  "created_at" : "2012-09-22 02:42:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/Nr3TFwBV",
      "expanded_url" : "http:\/\/on.wh.gov\/JXjWau",
      "display_url" : "on.wh.gov\/JXjWau"
    } ]
  },
  "geo" : { },
  "id_str" : "249283217453092864",
  "text" : "Lt. Brad Snyder was blinded in Afghanistan, 1 year later he won Paralympic gold. Watch his inspiring story &amp; share: http:\/\/t.co\/Nr3TFwBV",
  "id" : 249283217453092864,
  "created_at" : "2012-09-21 23:05:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/249257463122116609\/photo\/1",
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/ffxHA5ro",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A3WKV5NCQAEwtxz.jpg",
      "id_str" : "249257463126310913",
      "id" : 249257463126310913,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A3WKV5NCQAEwtxz.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 288,
        "resize" : "fit",
        "w" : 430
      }, {
        "h" : 228,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 288,
        "resize" : "fit",
        "w" : 430
      }, {
        "h" : 288,
        "resize" : "fit",
        "w" : 430
      } ],
      "display_url" : "pic.twitter.com\/ffxHA5ro"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/krfV0zZR",
      "expanded_url" : "http:\/\/on.wh.gov\/iQfK7K",
      "display_url" : "on.wh.gov\/iQfK7K"
    } ]
  },
  "geo" : { },
  "id_str" : "249257463122116609",
  "text" : "Today, President Obama designated Chimney Rock in Colorado as our newest national monument: http:\/\/t.co\/krfV0zZR Pic: http:\/\/t.co\/ffxHA5ro",
  "id" : 249257463122116609,
  "created_at" : "2012-09-21 21:23:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "249238543220736000",
  "text" : "RT @VP: VP &amp; Dr. B celebrated the next generation of LGBT leaders on Wednesday at the Naval Observatory. Read more here: http:\/\/t.co ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 137 ],
        "url" : "http:\/\/t.co\/IxC1pf3f",
        "expanded_url" : "http:\/\/wh.gov\/ZPPN",
        "display_url" : "wh.gov\/ZPPN"
      } ]
    },
    "geo" : { },
    "id_str" : "249217321363726338",
    "text" : "VP &amp; Dr. B celebrated the next generation of LGBT leaders on Wednesday at the Naval Observatory. Read more here: http:\/\/t.co\/IxC1pf3f",
    "id" : 249217321363726338,
    "created_at" : "2012-09-21 18:43:34 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 249238543220736000,
  "created_at" : "2012-09-21 20:07:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    }, {
      "name" : "Dept. of Agriculture",
      "screen_name" : "USDA",
      "indices" : [ 122, 127 ],
      "id_str" : "61853389",
      "id" : 61853389
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ChimneyRock",
      "indices" : [ 61, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/NZvzMFNb",
      "expanded_url" : "http:\/\/on.doi.gov\/Vlz1vA",
      "display_url" : "on.doi.gov\/Vlz1vA"
    } ]
  },
  "geo" : { },
  "id_str" : "249214094715015169",
  "text" : "RT @Interior: President Obama signs proclamation designating #ChimneyRock as a National Monument http:\/\/t.co\/NZvzMFNb cc: @USDA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/bitly.com\/\" rel=\"nofollow\"\u003EBitly Composer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dept. of Agriculture",
        "screen_name" : "USDA",
        "indices" : [ 108, 113 ],
        "id_str" : "61853389",
        "id" : 61853389
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ChimneyRock",
        "indices" : [ 47, 59 ]
      } ],
      "urls" : [ {
        "indices" : [ 83, 103 ],
        "url" : "http:\/\/t.co\/NZvzMFNb",
        "expanded_url" : "http:\/\/on.doi.gov\/Vlz1vA",
        "display_url" : "on.doi.gov\/Vlz1vA"
      } ]
    },
    "geo" : { },
    "id_str" : "249213311013498880",
    "text" : "President Obama signs proclamation designating #ChimneyRock as a National Monument http:\/\/t.co\/NZvzMFNb cc: @USDA",
    "id" : 249213311013498880,
    "created_at" : "2012-09-21 18:27:38 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 249214094715015169,
  "created_at" : "2012-09-21 18:30:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "jearnest44",
      "indices" : [ 3, 14 ],
      "id_str" : "369238541",
      "id" : 369238541
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "249180506237853697",
  "text" : "RT @jearnest44: NEW report: Obamacare saves $5k for every senior, millions have already saved $$ on prescription drugs. Details here: ht ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/9pTXb4s1",
        "expanded_url" : "http:\/\/goo.gl\/mouMW",
        "display_url" : "goo.gl\/mouMW"
      } ]
    },
    "geo" : { },
    "id_str" : "249144007173754882",
    "text" : "NEW report: Obamacare saves $5k for every senior, millions have already saved $$ on prescription drugs. Details here: http:\/\/t.co\/9pTXb4s1",
    "id" : 249144007173754882,
    "created_at" : "2012-09-21 13:52:14 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "jearnest44",
      "protected" : false,
      "id_str" : "369238541",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1769108407\/Twitter_profile_photo_real_normal.JPG",
      "id" : 369238541,
      "verified" : true
    }
  },
  "id" : 249180506237853697,
  "created_at" : "2012-09-21 16:17:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http:\/\/t.co\/yUjuE8xn",
      "expanded_url" : "http:\/\/on.wh.gov\/8iNvfY",
      "display_url" : "on.wh.gov\/8iNvfY"
    } ]
  },
  "geo" : { },
  "id_str" : "249171878067970048",
  "text" : "West Wing Week: Your behind the scenes guide this week at 1600 Pennsylvania Ave.  Video: http:\/\/t.co\/yUjuE8xn",
  "id" : 249171878067970048,
  "created_at" : "2012-09-21 15:42:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/248929222003933184\/photo\/1",
      "indices" : [ 124, 144 ],
      "url" : "http:\/\/t.co\/YkHcNyRB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A3RfzvxCQAAKDuZ.jpg",
      "id_str" : "248929222012321792",
      "id" : 248929222012321792,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A3RfzvxCQAAKDuZ.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/YkHcNyRB"
    } ],
    "hashtags" : [ {
      "text" : "DADT",
      "indices" : [ 118, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/OdEapk72",
      "expanded_url" : "http:\/\/on.wh.gov\/taoNyW",
      "display_url" : "on.wh.gov\/taoNyW"
    } ]
  },
  "geo" : { },
  "id_str" : "248929222003933184",
  "text" : "From the archives: A year ago today \"Don't Ask, Don't Tell\" was finally &amp; formally repealed: http:\/\/t.co\/OdEapk72 #DADT http:\/\/t.co\/YkHcNyRB",
  "id" : 248929222003933184,
  "created_at" : "2012-09-20 23:38:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DADT",
      "indices" : [ 116, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/bIoAREZc",
      "expanded_url" : "http:\/\/on.wh.gov\/CEZT2S",
      "display_url" : "on.wh.gov\/CEZT2S"
    } ]
  },
  "geo" : { },
  "id_str" : "248912657896312832",
  "text" : "Statement by the President on the One Year Anniversary of the Repeal of Don't Ask, Don't Tell: http:\/\/t.co\/bIoAREZc #DADT",
  "id" : 248912657896312832,
  "created_at" : "2012-09-20 22:32:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/248896771525332992\/photo\/1",
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/6ud17zHg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A3RCS4TCUAAQpu6.jpg",
      "id_str" : "248896771529527296",
      "id" : 248896771529527296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A3RCS4TCUAAQpu6.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/6ud17zHg"
    } ],
    "hashtags" : [ {
      "text" : "DADT",
      "indices" : [ 93, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "248896771525332992",
  "text" : "\"We are a nation that welcomes the service of every patriot.\" -President Obama on the end of #DADT http:\/\/t.co\/6ud17zHg",
  "id" : 248896771525332992,
  "created_at" : "2012-09-20 21:29:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Late Show",
      "screen_name" : "Late_Show",
      "indices" : [ 98, 108 ],
      "id_str" : "1455783554",
      "id" : 1455783554
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/248875538943459329\/photo\/1",
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/aeadzmVz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A3Qu--yCQAAMJ3v.jpg",
      "id_str" : "248875538951847936",
      "id" : 248875538951847936,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A3Qu--yCQAAMJ3v.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/aeadzmVz"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "248875538943459329",
  "text" : "Photo of the Day: President Obama laughs at a photo during an interview w\/ David Letterman on the @Late_Show http:\/\/t.co\/aeadzmVz",
  "id" : 248875538943459329,
  "created_at" : "2012-09-20 20:05:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/248857601960448000\/photo\/1",
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/JIzXrGvO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A3Qeq6TCEAEJyrb.jpg",
      "id_str" : "248857601964642305",
      "id" : 248857601964642305,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A3Qeq6TCEAEJyrb.jpg",
      "sizes" : [ {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 373,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 373,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 373,
        "resize" : "fit",
        "w" : 560
      } ],
      "display_url" : "pic.twitter.com\/JIzXrGvO"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/e9SyS4RD",
      "expanded_url" : "http:\/\/on.wh.gov\/jYJX2b",
      "display_url" : "on.wh.gov\/jYJX2b"
    } ]
  },
  "geo" : { },
  "id_str" : "248857601960448000",
  "text" : "Yesterday, President Obama met with Burmese Nobel Laureate Aung San Suu Kyi: http:\/\/t.co\/e9SyS4RD Photo: http:\/\/t.co\/JIzXrGvO",
  "id" : 248857601960448000,
  "created_at" : "2012-09-20 18:54:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/MjaxIlty",
      "expanded_url" : "http:\/\/flic.kr\/p\/cNf8XJ",
      "display_url" : "flic.kr\/p\/cNf8XJ"
    } ]
  },
  "geo" : { },
  "id_str" : "248784624598265856",
  "text" : "RT @JoiningForces: Taylor Morris &amp; Danielle Kelly inspire us all. See what's behind this: http:\/\/t.co\/MjaxIlty in 22 pictures: http: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 95 ],
        "url" : "http:\/\/t.co\/MjaxIlty",
        "expanded_url" : "http:\/\/flic.kr\/p\/cNf8XJ",
        "display_url" : "flic.kr\/p\/cNf8XJ"
      }, {
        "indices" : [ 112, 132 ],
        "url" : "http:\/\/t.co\/ApqtV3Pv",
        "expanded_url" : "http:\/\/www.buzzfeed.com\/txblacklabel\/true-love-in-pictures-only-28m7",
        "display_url" : "buzzfeed.com\/txblacklabel\/t\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "248784319949205504",
    "text" : "Taylor Morris &amp; Danielle Kelly inspire us all. See what's behind this: http:\/\/t.co\/MjaxIlty in 22 pictures: http:\/\/t.co\/ApqtV3Pv \u2013mo",
    "id" : 248784319949205504,
    "created_at" : "2012-09-20 14:02:58 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 248784624598265856,
  "created_at" : "2012-09-20 14:04:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/neD7zhJa",
      "expanded_url" : "http:\/\/on.wh.gov\/GjMwHj",
      "display_url" : "on.wh.gov\/GjMwHj"
    } ]
  },
  "geo" : { },
  "id_str" : "248556778395148288",
  "text" : "9\/23 is the deadline to submit an application for the Spring 2013 White House Internship Program. Get info &amp; apply: http:\/\/t.co\/neD7zhJa",
  "id" : 248556778395148288,
  "created_at" : "2012-09-19 22:58:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Minnesota Lynx",
      "screen_name" : "minnesotalynx",
      "indices" : [ 41, 55 ],
      "id_str" : "18939563",
      "id" : 18939563
    }, {
      "name" : "WNBA",
      "screen_name" : "WNBA",
      "indices" : [ 106, 111 ],
      "id_str" : "17159397",
      "id" : 17159397
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/248529694000029696\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/GngDyZT3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A3L0cJ-CIAA2wv6.jpg",
      "id_str" : "248529694008418304",
      "id" : 248529694008418304,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A3L0cJ-CIAA2wv6.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/GngDyZT3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "248529694000029696",
  "text" : "Photo of the day: President Obama greets @MinnesotaLynx coach Cheryl Reeve prior to an event honoring the @WNBA champs. http:\/\/t.co\/GngDyZT3",
  "id" : 248529694000029696,
  "created_at" : "2012-09-19 21:11:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    }, {
      "name" : "CommerceSec",
      "screen_name" : "CommerceSec",
      "indices" : [ 35, 47 ],
      "id_str" : "2319148561",
      "id" : 2319148561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "248515991007535104",
  "text" : "RT @Interior: Salazar &amp; Acting @CommerceSec Blank: Administration's efforts to promote travel &amp; tourism are working http:\/\/t.co\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/bitly.com\/\" rel=\"nofollow\"\u003EBitly Composer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CommerceSec",
        "screen_name" : "CommerceSec",
        "indices" : [ 21, 33 ],
        "id_str" : "2319148561",
        "id" : 2319148561
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 130 ],
        "url" : "http:\/\/t.co\/ptRHYl3K",
        "expanded_url" : "http:\/\/on.doi.gov\/PUeYE0",
        "display_url" : "on.doi.gov\/PUeYE0"
      } ]
    },
    "geo" : { },
    "id_str" : "248515533459320833",
    "text" : "Salazar &amp; Acting @CommerceSec Blank: Administration's efforts to promote travel &amp; tourism are working http:\/\/t.co\/ptRHYl3K",
    "id" : 248515533459320833,
    "created_at" : "2012-09-19 20:14:55 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 248515991007535104,
  "created_at" : "2012-09-19 20:16:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 3, 11 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 23, 34 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "WH.gov",
      "screen_name" : "WHWeb",
      "indices" : [ 105, 111 ],
      "id_str" : "390320946",
      "id" : 390320946
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "248448516509286400",
  "text" : "RT @macon44: Gr8 2 see @Whitehouse #8 in  iTunes\u2019 free news app category w\/solid reviews. Using it? Tell @whweb what you think! https:\/\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 10, 21 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "WH.gov",
        "screen_name" : "WHWeb",
        "indices" : [ 92, 98 ],
        "id_str" : "390320946",
        "id" : 390320946
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 136 ],
        "url" : "https:\/\/t.co\/obr2nZF0",
        "expanded_url" : "https:\/\/itunes.apple.com\/us\/app\/the-white-house\/id350190807?mt=8",
        "display_url" : "itunes.apple.com\/us\/app\/the-whi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "248421782002991105",
    "text" : "Gr8 2 see @Whitehouse #8 in  iTunes\u2019 free news app category w\/solid reviews. Using it? Tell @whweb what you think! https:\/\/t.co\/obr2nZF0",
    "id" : 248421782002991105,
    "created_at" : "2012-09-19 14:02:22 +0000",
    "user" : {
      "name" : "Macon Phillips",
      "screen_name" : "IIPCoordinator",
      "protected" : false,
      "id_str" : "110823581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000495374915\/f6a5ae048ab7f8f12c0386114df53203_normal.jpeg",
      "id" : 110823581,
      "verified" : true
    }
  },
  "id" : 248448516509286400,
  "created_at" : "2012-09-19 15:48:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHGarden",
      "indices" : [ 116, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/YUDIQjXm",
      "expanded_url" : "http:\/\/on.wh.gov\/d0oGhv",
      "display_url" : "on.wh.gov\/d0oGhv"
    } ]
  },
  "geo" : { },
  "id_str" : "248215333264056321",
  "text" : "You're invited! Learn more about how you can attend the \"White House Social\" Fall Garden Tour: http:\/\/t.co\/YUDIQjXm #WHGarden",
  "id" : 248215333264056321,
  "created_at" : "2012-09-19 00:22:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Phelps",
      "screen_name" : "MichaelPhelps",
      "indices" : [ 24, 38 ],
      "id_str" : "225539878",
      "id" : 225539878
    }, {
      "name" : "David Boudia",
      "screen_name" : "davidboudia",
      "indices" : [ 39, 51 ],
      "id_str" : "49498735",
      "id" : 49498735
    }, {
      "name" : "Katie Ledecky",
      "screen_name" : "katieledecky",
      "indices" : [ 52, 65 ],
      "id_str" : "743538714",
      "id" : 743538714
    }, {
      "name" : "Dennis Ogbe",
      "screen_name" : "dennisogbe",
      "indices" : [ 72, 83 ],
      "id_str" : "213166491",
      "id" : 213166491
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TeamUSA",
      "indices" : [ 91, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/MQJaWiZn",
      "expanded_url" : "http:\/\/on.wh.gov\/gzC4Cy",
      "display_url" : "on.wh.gov\/gzC4Cy"
    } ]
  },
  "geo" : { },
  "id_str" : "248200027065950208",
  "text" : "Go behind the scenes w\/ @MichaelPhelps @DavidBoudia @KatieLedecky &amp; @DennisOgbe\nduring #TeamUSA's visit to the WH: http:\/\/t.co\/MQJaWiZn",
  "id" : 248200027065950208,
  "created_at" : "2012-09-18 23:21:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SBA",
      "screen_name" : "SBAgov",
      "indices" : [ 3, 10 ],
      "id_str" : "153149305",
      "id" : 153149305
    }, {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 27, 32 ],
      "id_str" : "11348282",
      "id" : 11348282
    }, {
      "name" : "Curiosity Rover",
      "screen_name" : "MarsCuriosity",
      "indices" : [ 101, 115 ],
      "id_str" : "15473958",
      "id" : 15473958
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smallbiz",
      "indices" : [ 77, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/17bXroji",
      "expanded_url" : "http:\/\/owl.li\/dO8E0",
      "display_url" : "owl.li\/dO8E0"
    } ]
  },
  "geo" : { },
  "id_str" : "248181180799782912",
  "text" : "RT @SBAgov: Join SBA &amp; @NASA for a Google+ Hangout tomorrow to learn how #smallbiz helped launch @MarsCuriosity: http:\/\/t.co\/17bXroji",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NASA",
        "screen_name" : "NASA",
        "indices" : [ 15, 20 ],
        "id_str" : "11348282",
        "id" : 11348282
      }, {
        "name" : "Curiosity Rover",
        "screen_name" : "MarsCuriosity",
        "indices" : [ 89, 103 ],
        "id_str" : "15473958",
        "id" : 15473958
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "smallbiz",
        "indices" : [ 65, 74 ]
      } ],
      "urls" : [ {
        "indices" : [ 105, 125 ],
        "url" : "http:\/\/t.co\/17bXroji",
        "expanded_url" : "http:\/\/owl.li\/dO8E0",
        "display_url" : "owl.li\/dO8E0"
      } ]
    },
    "geo" : { },
    "id_str" : "248141881131802624",
    "text" : "Join SBA &amp; @NASA for a Google+ Hangout tomorrow to learn how #smallbiz helped launch @MarsCuriosity: http:\/\/t.co\/17bXroji",
    "id" : 248141881131802624,
    "created_at" : "2012-09-18 19:30:09 +0000",
    "user" : {
      "name" : "SBA",
      "screen_name" : "SBAgov",
      "protected" : false,
      "id_str" : "153149305",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/637366120236756992\/ky6enEIv_normal.png",
      "id" : 153149305,
      "verified" : true
    }
  },
  "id" : 248181180799782912,
  "created_at" : "2012-09-18 22:06:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TeamUSA",
      "indices" : [ 26, 34 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http:\/\/t.co\/r00SHil3",
      "expanded_url" : "http:\/\/on.wh.gov\/guQ0Pj",
      "display_url" : "on.wh.gov\/guQ0Pj"
    } ]
  },
  "geo" : { },
  "id_str" : "248144218030223361",
  "text" : "Go behind the scenes with #TeamUSA at the White House. Video: http:\/\/t.co\/r00SHil3",
  "id" : 248144218030223361,
  "created_at" : "2012-09-18 19:39:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WNBA",
      "screen_name" : "WNBA",
      "indices" : [ 47, 52 ],
      "id_str" : "17159397",
      "id" : 17159397
    }, {
      "name" : "Minnesota Lynx",
      "screen_name" : "minnesotalynx",
      "indices" : [ 62, 76 ],
      "id_str" : "18939563",
      "id" : 18939563
    }, {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 133, 140 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/XIeyCw62",
      "expanded_url" : "http:\/\/on.wh.gov\/lkzUPd",
      "display_url" : "on.wh.gov\/lkzUPd"
    } ]
  },
  "geo" : { },
  "id_str" : "248102812452519936",
  "text" : "Starting at 1:10ET: President Obama honors the @WNBA champion @MinnesotaLynx at the White House. Watch: http:\/\/t.co\/XIeyCw62 Follow: @WHLive",
  "id" : 248102812452519936,
  "created_at" : "2012-09-18 16:54:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "U.S. Air Force",
      "screen_name" : "usairforce",
      "indices" : [ 26, 37 ],
      "id_str" : "19611483",
      "id" : 19611483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "248091207769673728",
  "text" : "RT @VP: Happy birthday to @USAirForce: protecting our freedom from above for 65 years and going strong. Thank you for your service. --VP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "U.S. Air Force",
        "screen_name" : "usairforce",
        "indices" : [ 18, 29 ],
        "id_str" : "19611483",
        "id" : 19611483
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "248085788498202624",
    "text" : "Happy birthday to @USAirForce: protecting our freedom from above for 65 years and going strong. Thank you for your service. --VP",
    "id" : 248085788498202624,
    "created_at" : "2012-09-18 15:47:15 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 248091207769673728,
  "created_at" : "2012-09-18 16:08:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FEMA",
      "screen_name" : "fema",
      "indices" : [ 3, 8 ],
      "id_str" : "16669075",
      "id" : 16669075
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "248086699727527938",
  "text" : "RT @fema: Cash is an important addition to your emergency kit. ATMs or credit card readers may not work after a disaster http:\/\/t.co\/Br1 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 131 ],
        "url" : "http:\/\/t.co\/Br1Yu7QL",
        "expanded_url" : "http:\/\/www.ready.gov\/basic-disaster-supplies-kit",
        "display_url" : "ready.gov\/basic-disaster\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "248086206385094656",
    "text" : "Cash is an important addition to your emergency kit. ATMs or credit card readers may not work after a disaster http:\/\/t.co\/Br1Yu7QL",
    "id" : 248086206385094656,
    "created_at" : "2012-09-18 15:48:55 +0000",
    "user" : {
      "name" : "FEMA",
      "screen_name" : "fema",
      "protected" : false,
      "id_str" : "16669075",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2620163192\/j143q33k69loivqmp2dg_normal.gif",
      "id" : 16669075,
      "verified" : true
    }
  },
  "id" : 248086699727527938,
  "created_at" : "2012-09-18 15:50:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NPM",
      "indices" : [ 138, 142 ]
    } ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http:\/\/t.co\/L6Qf4eWR",
      "expanded_url" : "http:\/\/on.wh.gov\/nWvX0F",
      "display_url" : "on.wh.gov\/nWvX0F"
    }, {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/EIYirtEa",
      "expanded_url" : "http:\/\/on.wh.gov\/fc0sTg",
      "display_url" : "on.wh.gov\/fc0sTg"
    } ]
  },
  "geo" : { },
  "id_str" : "247819663348727808",
  "text" : "It's National Preparedness Month: http:\/\/t.co\/L6Qf4eWR Does your family have a plan for disasters &amp; emergencies? http:\/\/t.co\/EIYirtEa #NPM",
  "id" : 247819663348727808,
  "created_at" : "2012-09-17 22:09:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Air Force",
      "screen_name" : "usairforce",
      "indices" : [ 20, 31 ],
      "id_str" : "19611483",
      "id" : 19611483
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http:\/\/t.co\/Gpki3hkj",
      "expanded_url" : "http:\/\/on.wh.gov\/IiWLQH",
      "display_url" : "on.wh.gov\/IiWLQH"
    }, {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/ytytf5BP",
      "expanded_url" : "http:\/\/on.wh.gov\/STAuiP",
      "display_url" : "on.wh.gov\/STAuiP"
    } ]
  },
  "geo" : { },
  "id_str" : "247804288963858432",
  "text" : "Happy 65th birthday @USAirForce! http:\/\/t.co\/Gpki3hkj To commemorate, share a message of thanks with a military family: http:\/\/t.co\/ytytf5BP",
  "id" : 247804288963858432,
  "created_at" : "2012-09-17 21:08:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VAWA",
      "indices" : [ 67, 72 ]
    }, {
      "text" : "1is2many",
      "indices" : [ 97, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/qaEMTu5F",
      "expanded_url" : "http:\/\/wh.gov\/WSkV",
      "display_url" : "wh.gov\/WSkV"
    } ]
  },
  "geo" : { },
  "id_str" : "247789056824582144",
  "text" : "RT @VP: Read Lynn Rosenthal\u2019s blog post on the 18th Anniversary of #VAWA -- http:\/\/t.co\/qaEMTu5F #1is2many",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "VAWA",
        "indices" : [ 59, 64 ]
      }, {
        "text" : "1is2many",
        "indices" : [ 89, 98 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 88 ],
        "url" : "http:\/\/t.co\/qaEMTu5F",
        "expanded_url" : "http:\/\/wh.gov\/WSkV",
        "display_url" : "wh.gov\/WSkV"
      } ]
    },
    "geo" : { },
    "id_str" : "247788361677410304",
    "text" : "Read Lynn Rosenthal\u2019s blog post on the 18th Anniversary of #VAWA -- http:\/\/t.co\/qaEMTu5F #1is2many",
    "id" : 247788361677410304,
    "created_at" : "2012-09-17 20:05:23 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 247789056824582144,
  "created_at" : "2012-09-17 20:08:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/247784050402668544\/photo\/1",
      "indices" : [ 123, 143 ],
      "url" : "http:\/\/t.co\/pp6YsPwF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A3BOR_GCMAArb8D.jpg",
      "id_str" : "247784050406862848",
      "id" : 247784050406862848,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A3BOR_GCMAArb8D.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/pp6YsPwF"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "247784050402668544",
  "text" : "Photo: President Obama &amp; Sec Clinton at Andrews AFB marking the return of the remains of the Americans killed in Libya http:\/\/t.co\/pp6YsPwF",
  "id" : 247784050402668544,
  "created_at" : "2012-09-17 19:48:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/duceNaBA",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2012\/09\/17\/patent-reform-celebrating-one-year-anniversary-america-invents-act",
      "display_url" : "whitehouse.gov\/blog\/2012\/09\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "247752963085455360",
  "text" : "RT @whitehouseostp: Patent Reform: Celebrating One Year Anniversary of the America Invents Act http:\/\/t.co\/duceNaBA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 95 ],
        "url" : "http:\/\/t.co\/duceNaBA",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2012\/09\/17\/patent-reform-celebrating-one-year-anniversary-america-invents-act",
        "display_url" : "whitehouse.gov\/blog\/2012\/09\/1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "247752711989256192",
    "text" : "Patent Reform: Celebrating One Year Anniversary of the America Invents Act http:\/\/t.co\/duceNaBA",
    "id" : 247752711989256192,
    "created_at" : "2012-09-17 17:43:44 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 247752963085455360,
  "created_at" : "2012-09-17 17:44:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/QHJSmIG7",
      "expanded_url" : "http:\/\/on.wh.gov\/MHWOEl",
      "display_url" : "on.wh.gov\/MHWOEl"
    } ]
  },
  "geo" : { },
  "id_str" : "247416109333102592",
  "text" : "President Obama on Rosh Hashanah: \"I want to extend my warmest wishes to all those celebrating the New Year.\" Watch: http:\/\/t.co\/QHJSmIG7",
  "id" : 247416109333102592,
  "created_at" : "2012-09-16 19:26:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/GQE1Sh8C",
      "expanded_url" : "http:\/\/on.wh.gov\/YKELzc",
      "display_url" : "on.wh.gov\/YKELzc"
    } ]
  },
  "geo" : { },
  "id_str" : "246971247722909696",
  "text" : "\"We must reaffirm that we will carry on the work of our fallen heroes\" -President Obama in his Weekly Address: http:\/\/t.co\/GQE1Sh8C",
  "id" : 246971247722909696,
  "created_at" : "2012-09-15 13:58:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/246763493980766208\/photo\/1",
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/3uc3bZJ1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A2yuFyOCAAA-XU9.jpg",
      "id_str" : "246763494001737728",
      "id" : 246763494001737728,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A2yuFyOCAAA-XU9.jpg",
      "sizes" : [ {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1335,
        "resize" : "fit",
        "w" : 2004
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/3uc3bZJ1"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "246763493980766208",
  "text" : "Photo of the Day: President Obama participates in a conference call with his national security team in Golden, CO: http:\/\/t.co\/3uc3bZJ1",
  "id" : 246763493980766208,
  "created_at" : "2012-09-15 00:12:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/N60Gq7lc",
      "expanded_url" : "http:\/\/on.wh.gov\/sKBUfH",
      "display_url" : "on.wh.gov\/sKBUfH"
    } ]
  },
  "geo" : { },
  "id_str" : "246732920453222400",
  "text" : "Watch the latest installment of West Wing Week, your guide to everything that's happening at 1600 Pennsylvania Ave: http:\/\/t.co\/N60Gq7lc",
  "id" : 246732920453222400,
  "created_at" : "2012-09-14 22:11:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 132, 152 ],
      "url" : "http:\/\/t.co\/yVPCZMXZ",
      "expanded_url" : "http:\/\/on.wh.gov\/NygJ4c",
      "display_url" : "on.wh.gov\/NygJ4c"
    } ]
  },
  "geo" : { },
  "id_str" : "246715289964785665",
  "text" : "\"Michelle &amp; I wish you &amp; your families a sweet year full of health, happiness &amp; peace. L'Shana Tovah.\" -President Obama http:\/\/t.co\/yVPCZMXZ",
  "id" : 246715289964785665,
  "created_at" : "2012-09-14 21:01:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHTeamUSA",
      "indices" : [ 106, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "246618042413486081",
  "text" : "RT @WHLive: President Obama: \"We could not be prouder of you. You gave us a summer we will never forget.\" #WHTeamUSA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHTeamUSA",
        "indices" : [ 94, 104 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "246615480075423744",
    "text" : "President Obama: \"We could not be prouder of you. You gave us a summer we will never forget.\" #WHTeamUSA",
    "id" : 246615480075423744,
    "created_at" : "2012-09-14 14:24:46 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 246618042413486081,
  "created_at" : "2012-09-14 14:34:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "246615300676677632",
  "text" : "RT @WHLive: President Obama: \"As Olympians and Paralympians, you find the strength to keep pushing \u2013 on the good days and the bad days.\" ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHTeamUSA",
        "indices" : [ 125, 135 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "246615249422258176",
    "text" : "President Obama: \"As Olympians and Paralympians, you find the strength to keep pushing \u2013 on the good days and the bad days.\" #WHTeamUSA",
    "id" : 246615249422258176,
    "created_at" : "2012-09-14 14:23:52 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 246615300676677632,
  "created_at" : "2012-09-14 14:24:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHTeamUSA",
      "indices" : [ 127, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "246614831539572736",
  "text" : "RT @WHLive: President Obama: \"We could not have asked for better representatives and better ambassadors of the United States.\" #WHTeamUSA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHTeamUSA",
        "indices" : [ 115, 125 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "246614555541778433",
    "text" : "President Obama: \"We could not have asked for better representatives and better ambassadors of the United States.\" #WHTeamUSA",
    "id" : 246614555541778433,
    "created_at" : "2012-09-14 14:21:06 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 246614831539572736,
  "created_at" : "2012-09-14 14:22:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Team USA ",
      "screen_name" : "USOlympic",
      "indices" : [ 52, 62 ],
      "id_str" : "3061782654",
      "id" : 3061782654
    }, {
      "name" : "U.S. Paralympics",
      "screen_name" : "USParalympics",
      "indices" : [ 69, 83 ],
      "id_str" : "28652197",
      "id" : 28652197
    }, {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 127, 134 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHTeamUSA",
      "indices" : [ 135, 145 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/u95tzH8r",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "246610715715203072",
  "text" : "Happening now: The President &amp; First Lady honor @USOlympic &amp; @USParalympics teams. Watch: http:\/\/t.co\/u95tzH8r Follow: @WHLive #WHTeamUSA",
  "id" : 246610715715203072,
  "created_at" : "2012-09-14 14:05:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TeamUSA",
      "indices" : [ 74, 82 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/F7NkrOxK",
      "expanded_url" : "http:\/\/at.wh.gov\/dIeR1",
      "display_url" : "at.wh.gov\/dIeR1"
    } ]
  },
  "geo" : { },
  "id_str" : "246605915942445056",
  "text" : "RT @WHLive: Happening at 10ET: President Obama &amp; the First Lady honor #TeamUSA at the White House. Watch live: http:\/\/t.co\/F7NkrOxK  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TeamUSA",
        "indices" : [ 62, 70 ]
      }, {
        "text" : "WHTeamUSA",
        "indices" : [ 124, 134 ]
      } ],
      "urls" : [ {
        "indices" : [ 103, 123 ],
        "url" : "http:\/\/t.co\/F7NkrOxK",
        "expanded_url" : "http:\/\/at.wh.gov\/dIeR1",
        "display_url" : "at.wh.gov\/dIeR1"
      } ]
    },
    "geo" : { },
    "id_str" : "246601952476160000",
    "text" : "Happening at 10ET: President Obama &amp; the First Lady honor #TeamUSA at the White House. Watch live: http:\/\/t.co\/F7NkrOxK #WHTeamUSA",
    "id" : 246601952476160000,
    "created_at" : "2012-09-14 13:31:01 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 246605915942445056,
  "created_at" : "2012-09-14 13:46:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Team USA ",
      "screen_name" : "USOlympic",
      "indices" : [ 32, 42 ],
      "id_str" : "3061782654",
      "id" : 3061782654
    }, {
      "name" : "U.S. Paralympics",
      "screen_name" : "USParalympics",
      "indices" : [ 49, 63 ],
      "id_str" : "28652197",
      "id" : 28652197
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThanksTeamUSA",
      "indices" : [ 122, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "246602818507661312",
  "text" : "Today Barack &amp; I will honor @USOlympic &amp; @USParalympics teams at the White House. I hope you'll join us &amp; say #ThanksTeamUSA! -mo",
  "id" : 246602818507661312,
  "created_at" : "2012-09-14 13:34:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TeamUSA",
      "indices" : [ 57, 65 ]
    }, {
      "text" : "ThanksTeamUSA",
      "indices" : [ 90, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 123, 143 ],
      "url" : "http:\/\/t.co\/pixPqu9z",
      "expanded_url" : "http:\/\/on.wh.gov\/wzHrqR",
      "display_url" : "on.wh.gov\/wzHrqR"
    } ]
  },
  "geo" : { },
  "id_str" : "246417003169083394",
  "text" : "Tomorrow President Obama &amp; the First Lady will honor #TeamUSA at the White House. Say #ThanksTeamUSA &amp; watch live: http:\/\/t.co\/pixPqu9z",
  "id" : 246417003169083394,
  "created_at" : "2012-09-14 01:16:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 100, 103 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VAWA",
      "indices" : [ 132, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/PJhHoViI",
      "expanded_url" : "http:\/\/on.wh.gov\/g534Bd",
      "display_url" : "on.wh.gov\/g534Bd"
    } ]
  },
  "geo" : { },
  "id_str" : "246351818978897920",
  "text" : "Eighteen years ago today, the landmark Violence Against Women Act was signed into law. Statement by @VP Biden: http:\/\/t.co\/PJhHoViI #VAWA",
  "id" : 246351818978897920,
  "created_at" : "2012-09-13 20:57:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 45, 55 ],
      "id_str" : "9624742",
      "id" : 9624742
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/246327196145291265\/photo\/1",
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/aPGxYMK3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A2shR6FCEAEb-xO.jpg",
      "id_str" : "246327196153679873",
      "id" : 246327196153679873,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A2shR6FCEAEb-xO.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1281,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/aPGxYMK3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "246327196145291265",
  "text" : "Photo of the Day: President Obama meets with @StateDept employees after speaking to them about the attack in Benghazi: http:\/\/t.co\/aPGxYMK3",
  "id" : 246327196145291265,
  "created_at" : "2012-09-13 19:19:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VAWA",
      "indices" : [ 124, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "246281982416412672",
  "text" : "RT @vj44: 18 years ago today, the Violence Against Women Act became law. We must work together to preserve &amp; strengthen #VAWA: http: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "VAWA",
        "indices" : [ 114, 119 ]
      } ],
      "urls" : [ {
        "indices" : [ 121, 141 ],
        "url" : "http:\/\/t.co\/V9i4Oorp",
        "expanded_url" : "http:\/\/at.wh.gov\/dGHVQ",
        "display_url" : "at.wh.gov\/dGHVQ"
      } ]
    },
    "geo" : { },
    "id_str" : "246281187188948992",
    "text" : "18 years ago today, the Violence Against Women Act became law. We must work together to preserve &amp; strengthen #VAWA: http:\/\/t.co\/V9i4Oorp",
    "id" : 246281187188948992,
    "created_at" : "2012-09-13 16:16:25 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 246281982416412672,
  "created_at" : "2012-09-13 16:19:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 66, 76 ],
      "id_str" : "9624742",
      "id" : 9624742
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/246053887654653952\/photo\/1",
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/emY5jmWf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A2ootQnCcAAyjyX.jpg",
      "id_str" : "246053887663042560",
      "id" : 246053887663042560,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A2ootQnCcAAyjyX.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/emY5jmWf"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/380ommNO",
      "expanded_url" : "http:\/\/on.wh.gov\/NOZ1gg",
      "display_url" : "on.wh.gov\/NOZ1gg"
    } ]
  },
  "geo" : { },
  "id_str" : "246053887654653952",
  "text" : "President Obama &amp; Secretary Clinton meet with employees today @StateDept: http:\/\/t.co\/380ommNO Photo: http:\/\/t.co\/emY5jmWf",
  "id" : 246053887654653952,
  "created_at" : "2012-09-13 01:13:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/uf9879L2",
      "expanded_url" : "http:\/\/on.wh.gov\/IpHDlA",
      "display_url" : "on.wh.gov\/IpHDlA"
    } ]
  },
  "geo" : { },
  "id_str" : "245970197457035264",
  "text" : "Proclamation: President Obama orders US flags to be flown at half-staff honoring the victims of the attack in Libya: http:\/\/t.co\/uf9879L2",
  "id" : 245970197457035264,
  "created_at" : "2012-09-12 19:40:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "245896860194197504",
  "text" : "RT @WHLive: Obama: \"Let us grieve with their families... let us continue their work of seeking a stronger America &amp; better world for ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "245896552135147520",
    "text" : "Obama: \"Let us grieve with their families... let us continue their work of seeking a stronger America &amp; better world for our children\"",
    "id" : 245896552135147520,
    "created_at" : "2012-09-12 14:48:01 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 245896860194197504,
  "created_at" : "2012-09-12 14:49:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "245896317719678977",
  "text" : "RT @WHLive: President Obama: \u201Clet us never, ever, forget that our freedom is only sustained because there are people who are willing to  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "245896235800735744",
    "text" : "President Obama: \u201Clet us never, ever, forget that our freedom is only sustained because there are people who are willing to fight for it\u201D",
    "id" : 245896235800735744,
    "created_at" : "2012-09-12 14:46:45 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 245896317719678977,
  "created_at" : "2012-09-12 14:47:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "245895945005461505",
  "text" : "RT @WHLive: President Obama: \u201CThe world must stand together to unequivocally reject these brutal acts.\u201D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "245895646563950592",
    "text" : "President Obama: \u201CThe world must stand together to unequivocally reject these brutal acts.\u201D",
    "id" : 245895646563950592,
    "created_at" : "2012-09-12 14:44:25 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 245895945005461505,
  "created_at" : "2012-09-12 14:45:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "245895922331025408",
  "text" : "RT @WHLive: President Obama: \u201CToday, the American people stand united in holding the families of the four Americans we lost in our thoug ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "245895549964931072",
    "text" : "President Obama: \u201CToday, the American people stand united in holding the families of the four Americans we lost in our thoughts &amp; prayers\u201D",
    "id" : 245895549964931072,
    "created_at" : "2012-09-12 14:44:02 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 245895922331025408,
  "created_at" : "2012-09-12 14:45:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 119, 126 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/DwYpGlk0",
      "expanded_url" : "http:\/\/whitehouse.gov\/live",
      "display_url" : "whitehouse.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "245895299413979136",
  "text" : "RT @WHLive: Happening now: President Obama speaks on the attack in Benghazi. Watch: http:\/\/t.co\/DwYpGlk0 &amp; follow: @whlive",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "White House Live",
        "screen_name" : "WHLive",
        "indices" : [ 107, 114 ],
        "id_str" : "369505837",
        "id" : 369505837
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 72, 92 ],
        "url" : "http:\/\/t.co\/DwYpGlk0",
        "expanded_url" : "http:\/\/whitehouse.gov\/live",
        "display_url" : "whitehouse.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "245895212822577152",
    "text" : "Happening now: President Obama speaks on the attack in Benghazi. Watch: http:\/\/t.co\/DwYpGlk0 &amp; follow: @whlive",
    "id" : 245895212822577152,
    "created_at" : "2012-09-12 14:42:41 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 245895299413979136,
  "created_at" : "2012-09-12 14:43:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/fJ51rw01",
      "expanded_url" : "http:\/\/at.wh.gov\/dEzud",
      "display_url" : "at.wh.gov\/dEzud"
    } ]
  },
  "geo" : { },
  "id_str" : "245877085728542720",
  "text" : "RT @WHLive: Happening at 10:35 AM EDT: President Obama delivers a statement in the Rose Garden. Watch live: http:\/\/t.co\/fJ51rw01",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 116 ],
        "url" : "http:\/\/t.co\/fJ51rw01",
        "expanded_url" : "http:\/\/at.wh.gov\/dEzud",
        "display_url" : "at.wh.gov\/dEzud"
      } ]
    },
    "geo" : { },
    "id_str" : "245876936495222786",
    "text" : "Happening at 10:35 AM EDT: President Obama delivers a statement in the Rose Garden. Watch live: http:\/\/t.co\/fJ51rw01",
    "id" : 245876936495222786,
    "created_at" : "2012-09-12 13:30:04 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 245877085728542720,
  "created_at" : "2012-09-12 13:30:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/Mf003c4D",
      "expanded_url" : "http:\/\/on.wh.gov\/jfa9We",
      "display_url" : "on.wh.gov\/jfa9We"
    } ]
  },
  "geo" : { },
  "id_str" : "245875351836839938",
  "text" : "\"I strongly condemn the outrageous attack on our diplomatic facility in Benghazi\" -President Obama. Full statement: http:\/\/t.co\/Mf003c4D",
  "id" : 245875351836839938,
  "created_at" : "2012-09-12 13:23:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/245662376681144320\/photo\/1",
      "indices" : [ 123, 143 ],
      "url" : "http:\/\/t.co\/XtCJdFEh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A2jEoUlCAAIxzzD.jpg",
      "id_str" : "245662376689532930",
      "id" : 245662376689532930,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A2jEoUlCAAIxzzD.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/XtCJdFEh"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "245662376681144320",
  "text" : "PHOTO: The President, First Lady &amp; White House staff observe a moment of silence to mark the 11th anniversary of 9\/11: http:\/\/t.co\/XtCJdFEh",
  "id" : 245662376681144320,
  "created_at" : "2012-09-11 23:17:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/245643464111448065\/photo\/1",
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/L2veLsMf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A2izbdxCYAEO0Au.jpg",
      "id_str" : "245643464119836673",
      "id" : 245643464119836673,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A2izbdxCYAEO0Au.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/L2veLsMf"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "245643464111448065",
  "text" : "President Obama: \"The true legacy of 9\/11...will be a safer world; a stronger nation &amp; a people more united\" http:\/\/t.co\/L2veLsMf",
  "id" : 245643464111448065,
  "created_at" : "2012-09-11 22:02:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 7, 10 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/245554603037433859\/photo\/1",
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/BcKSlgpd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A2hinEeCIAAVuPS.jpg",
      "id_str" : "245554603045822464",
      "id" : 245554603045822464,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A2hinEeCIAAVuPS.jpg",
      "sizes" : [ {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/BcKSlgpd"
    } ],
    "hashtags" : [ {
      "text" : "Flight93",
      "indices" : [ 50, 59 ]
    }, {
      "text" : "Remember911",
      "indices" : [ 78, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "245554603037433859",
  "text" : "PHOTO: @VP Biden in Shanksville, PA, today at the #Flight93 memorial service. #Remember911 http:\/\/t.co\/BcKSlgpd",
  "id" : 245554603037433859,
  "created_at" : "2012-09-11 16:09:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/VP\/status\/245529905872400384\/photo\/1",
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/aVRYshed",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A2hMJgWCcAEvWB2.jpg",
      "id_str" : "245529905876594689",
      "id" : 245529905876594689,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A2hMJgWCcAEvWB2.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/aVRYshed"
    } ],
    "hashtags" : [ {
      "text" : "September11th",
      "indices" : [ 86, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "245531352382992385",
  "text" : "RT @VP: PHOTO: Dr. Biden thanks emergency responders at Alexandria Fire Station #206. #September11th http:\/\/t.co\/aVRYshed",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/245529905872400384\/photo\/1",
        "indices" : [ 93, 113 ],
        "url" : "http:\/\/t.co\/aVRYshed",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/A2hMJgWCcAEvWB2.jpg",
        "id_str" : "245529905876594689",
        "id" : 245529905876594689,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A2hMJgWCcAEvWB2.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1536,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/aVRYshed"
      } ],
      "hashtags" : [ {
        "text" : "September11th",
        "indices" : [ 78, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "245529905872400384",
    "text" : "PHOTO: Dr. Biden thanks emergency responders at Alexandria Fire Station #206. #September11th http:\/\/t.co\/aVRYshed",
    "id" : 245529905872400384,
    "created_at" : "2012-09-11 14:31:07 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 245531352382992385,
  "created_at" : "2012-09-11 14:36:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "245521611208413185",
  "text" : "RT @WHLive: Obama: On a day when others sought to bring this country down, we choose to build it up with a National Day of Service &amp; ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "245520842711257089",
    "text" : "Obama: On a day when others sought to bring this country down, we choose to build it up with a National Day of Service &amp; Remembrance.",
    "id" : 245520842711257089,
    "created_at" : "2012-09-11 13:55:05 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 245521611208413185,
  "created_at" : "2012-09-11 13:58:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "September11th",
      "indices" : [ 31, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "245521278902091776",
  "text" : "RT @WHLive: President Obama on #September11th: This anniversary also renews our faith that even the darkest night gives way to a brighte ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "September11th",
        "indices" : [ 19, 33 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "245521070239670272",
    "text" : "President Obama on #September11th: This anniversary also renews our faith that even the darkest night gives way to a brighter dawn.",
    "id" : 245521070239670272,
    "created_at" : "2012-09-11 13:55:59 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 245521278902091776,
  "created_at" : "2012-09-11 13:56:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "September11th",
      "indices" : [ 84, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/u95tzH8r",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "245514583232630785",
  "text" : "Starting now on http:\/\/t.co\/u95tzH8r: President Obama &amp; the First Lady attend a #September11th Observance Ceremony at the Pentagon.",
  "id" : 245514583232630785,
  "created_at" : "2012-09-11 13:30:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/WCWPhh6A",
      "expanded_url" : "http:\/\/on.wh.gov\/I4SNUu",
      "display_url" : "on.wh.gov\/I4SNUu"
    } ]
  },
  "geo" : { },
  "id_str" : "245493727500587009",
  "text" : "Presidential Proclamation -- Patriot Day and National Day of Service and Remembrance, September 11th, 2012 http:\/\/t.co\/WCWPhh6A",
  "id" : 245493727500587009,
  "created_at" : "2012-09-11 12:07:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHmobile",
      "indices" : [ 83, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http:\/\/t.co\/FcJNYItR",
      "expanded_url" : "http:\/\/on.wh.gov\/jAQa9Zi",
      "display_url" : "on.wh.gov\/jAQa9Zi"
    } ]
  },
  "geo" : { },
  "id_str" : "245287824486707200",
  "text" : "Visit the White House, \"Anytime, Anywhere, and on Any Device\" http:\/\/t.co\/FcJNYItR #WHmobile",
  "id" : 245287824486707200,
  "created_at" : "2012-09-10 22:29:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/245226307384909825\/photo\/1",
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/sC9vjQGF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A2c4Bv2CIAAY1BH.jpg",
      "id_str" : "245226307389104128",
      "id" : 245226307389104128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A2c4Bv2CIAAY1BH.jpg",
      "sizes" : [ {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 373,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 373,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 373,
        "resize" : "fit",
        "w" : 560
      } ],
      "display_url" : "pic.twitter.com\/sC9vjQGF"
    } ],
    "hashtags" : [ {
      "text" : "911Day",
      "indices" : [ 9, 16 ]
    } ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http:\/\/t.co\/EIRt1xtS",
      "expanded_url" : "http:\/\/on.wh.gov\/GenrxC",
      "display_url" : "on.wh.gov\/GenrxC"
    } ]
  },
  "geo" : { },
  "id_str" : "245226307384909825",
  "text" : "Remember #911Day with service. Sign up: http:\/\/t.co\/EIRt1xtS. PIC:The First Family volunteers in DC in 2011: http:\/\/t.co\/sC9vjQGF",
  "id" : 245226307384909825,
  "created_at" : "2012-09-10 18:24:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Green Bay Packers",
      "screen_name" : "packers",
      "indices" : [ 94, 102 ],
      "id_str" : "35865630",
      "id" : 35865630
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/244932300121444353\/photo\/1",
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/XF1z9Br3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A2YsoRdCEAAPuMB.jpg",
      "id_str" : "244932300129832960",
      "id" : 244932300129832960,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A2YsoRdCEAAPuMB.jpg",
      "sizes" : [ {
        "h" : 336,
        "resize" : "fit",
        "w" : 504
      }, {
        "h" : 336,
        "resize" : "fit",
        "w" : 504
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 336,
        "resize" : "fit",
        "w" : 504
      } ],
      "display_url" : "pic.twitter.com\/XF1z9Br3"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/CB6vgtOh",
      "expanded_url" : "http:\/\/on.wh.gov\/wFtnwY",
      "display_url" : "on.wh.gov\/wFtnwY"
    } ]
  },
  "geo" : { },
  "id_str" : "244932300121444353",
  "text" : "Photo Gallery: NFL Champions at the White House: http:\/\/t.co\/CB6vgtOh Including the Green Bay @Packers in 2011: http:\/\/t.co\/XF1z9Br3",
  "id" : 244932300121444353,
  "created_at" : "2012-09-09 22:56:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Paralympic",
      "indices" : [ 23, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "244845645377175552",
  "text" : "Congratulations to our #Paralympic athletes! You have inspired us all &amp; I can't wait to honor you at the White House. -mo",
  "id" : 244845645377175552,
  "created_at" : "2012-09-09 17:12:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/82tCksLz",
      "expanded_url" : "http:\/\/on.wh.gov\/5UliOU",
      "display_url" : "on.wh.gov\/5UliOU"
    } ]
  },
  "geo" : { },
  "id_str" : "244816300558397442",
  "text" : "\"Instead of changing who we are, the attacks have brought out the best in the American people.\" -President Obama: http:\/\/t.co\/82tCksLz",
  "id" : 244816300558397442,
  "created_at" : "2012-09-09 15:15:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/244588736996851715\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/Y3XNjhqH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A2T0KRFCQAIE4w4.jpg",
      "id_str" : "244588737005240322",
      "id" : 244588737005240322,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A2T0KRFCQAIE4w4.jpg",
      "sizes" : [ {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 373,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 373,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 373,
        "resize" : "fit",
        "w" : 560
      } ],
      "display_url" : "pic.twitter.com\/Y3XNjhqH"
    } ],
    "hashtags" : [ {
      "text" : "911Day",
      "indices" : [ 36, 43 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/VtZ93BW7",
      "expanded_url" : "http:\/\/on.wh.gov\/WDRTbo",
      "display_url" : "on.wh.gov\/WDRTbo"
    } ]
  },
  "geo" : { },
  "id_str" : "244588736996851715",
  "text" : "Last year, the First Family honored #911Day at DC Central Kitchen. Find a service opportunity: http:\/\/t.co\/VtZ93BW7 PIC http:\/\/t.co\/Y3XNjhqH",
  "id" : 244588736996851715,
  "created_at" : "2012-09-09 00:11:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Paralympic",
      "indices" : [ 72, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "244513242037227521",
  "text" : "We're so proud of Navy Lt Brad Snyder - 1 year after losing sight, wins #Paralympic gold. Thank you for your service, for inspiring us. -mo",
  "id" : 244513242037227521,
  "created_at" : "2012-09-08 19:11:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "911Day",
      "indices" : [ 39, 46 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/00Ngt8uH",
      "expanded_url" : "http:\/\/on.wh.gov\/X799FF",
      "display_url" : "on.wh.gov\/X799FF"
    } ]
  },
  "geo" : { },
  "id_str" : "244476291787657216",
  "text" : "Pay tribute with service this weekend: #911Day of Service and Remembrance. Find a service opportunity near you: http:\/\/t.co\/00Ngt8uH",
  "id" : 244476291787657216,
  "created_at" : "2012-09-08 16:44:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 124, 144 ],
      "url" : "http:\/\/t.co\/dJ3TE9mH",
      "expanded_url" : "http:\/\/on.wh.gov\/xhrXfQ",
      "display_url" : "on.wh.gov\/xhrXfQ"
    } ]
  },
  "geo" : { },
  "id_str" : "244460767779368960",
  "text" : "\"We mark September 11th as a National Day of Service &amp; Remembrance because we are one American family\" -President Obama http:\/\/t.co\/dJ3TE9mH",
  "id" : 244460767779368960,
  "created_at" : "2012-09-08 15:42:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/tLMMstYS",
      "expanded_url" : "http:\/\/on.wh.gov\/OsVyzg",
      "display_url" : "on.wh.gov\/OsVyzg"
    } ]
  },
  "geo" : { },
  "id_str" : "244430797078159361",
  "text" : "President Obama's Weekly Address: Coming Together to Remember September 11th:  http:\/\/t.co\/tLMMstYS",
  "id" : 244430797078159361,
  "created_at" : "2012-09-08 13:43:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "We the People",
      "screen_name" : "wethepeople",
      "indices" : [ 77, 89 ],
      "id_str" : "369507958",
      "id" : 369507958
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHmobile",
      "indices" : [ 56, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 122, 142 ],
      "url" : "http:\/\/t.co\/IHkDu891",
      "expanded_url" : "http:\/\/on.wh.gov\/NoyMIW",
      "display_url" : "on.wh.gov\/NoyMIW"
    } ]
  },
  "geo" : { },
  "id_str" : "244162587028238336",
  "text" : "This week at 1600 Penn: The top secret beer recipe, new #WHmobile apps &amp; @WethePeople at 3 million signatures. Watch: http:\/\/t.co\/IHkDu891",
  "id" : 244162587028238336,
  "created_at" : "2012-09-07 19:57:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dul\u00E9 Hill",
      "screen_name" : "DuleHill",
      "indices" : [ 3, 12 ],
      "id_str" : "262388975",
      "id" : 262388975
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 46, 57 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/oGEtO5FC",
      "expanded_url" : "http:\/\/1.usa.gov\/RaqR9U",
      "display_url" : "1.usa.gov\/RaqR9U"
    } ]
  },
  "geo" : { },
  "id_str" : "244089883914801152",
  "text" : "RT @DuleHill: Loving this new White House App @whitehouse! http:\/\/t.co\/oGEtO5FC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetlogix.com\" rel=\"nofollow\"\u003ETweetlogix\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 32, 43 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 65 ],
        "url" : "http:\/\/t.co\/oGEtO5FC",
        "expanded_url" : "http:\/\/1.usa.gov\/RaqR9U",
        "display_url" : "1.usa.gov\/RaqR9U"
      } ]
    },
    "geo" : { },
    "id_str" : "243483343226814464",
    "text" : "Loving this new White House App @whitehouse! http:\/\/t.co\/oGEtO5FC",
    "id" : 243483343226814464,
    "created_at" : "2012-09-05 22:58:47 +0000",
    "user" : {
      "name" : "Dul\u00E9 Hill",
      "screen_name" : "DuleHill",
      "protected" : false,
      "id_str" : "262388975",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/780784540390264832\/k8smqjX2_normal.jpg",
      "id" : 262388975,
      "verified" : true
    }
  },
  "id" : 244089883914801152,
  "created_at" : "2012-09-07 15:08:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "jearnest44",
      "indices" : [ 3, 14 ],
      "id_str" : "369238541",
      "id" : 369238541
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "244079195423117312",
  "text" : "RT @jearnest44: Check out the analysis of this month's jobs report offered up by the President's economist, CEA Chair Alan Krueger: http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 136 ],
        "url" : "http:\/\/t.co\/tvOZdnXU",
        "expanded_url" : "http:\/\/wh.gov\/DwOy",
        "display_url" : "wh.gov\/DwOy"
      } ]
    },
    "geo" : { },
    "id_str" : "244070279108767746",
    "text" : "Check out the analysis of this month's jobs report offered up by the President's economist, CEA Chair Alan Krueger: http:\/\/t.co\/tvOZdnXU",
    "id" : 244070279108767746,
    "created_at" : "2012-09-07 13:51:03 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "jearnest44",
      "protected" : false,
      "id_str" : "369238541",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1769108407\/Twitter_profile_photo_real_normal.JPG",
      "id" : 369238541,
      "verified" : true
    }
  },
  "id" : 244079195423117312,
  "created_at" : "2012-09-07 14:26:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http:\/\/t.co\/vIowfzog",
      "expanded_url" : "http:\/\/on.wh.gov\/LWGCPLt",
      "display_url" : "on.wh.gov\/LWGCPLt"
    } ]
  },
  "geo" : { },
  "id_str" : "243801954176880640",
  "text" : "Three Ways to Explore the White House...from Home http:\/\/t.co\/vIowfzog",
  "id" : 243801954176880640,
  "created_at" : "2012-09-06 20:04:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "New York Giants",
      "screen_name" : "Giants",
      "indices" : [ 83, 90 ],
      "id_str" : "240734425",
      "id" : 240734425
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NFL",
      "indices" : [ 4, 8 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/oU0xLQyT",
      "expanded_url" : "http:\/\/on.wh.gov\/iyHQfPC",
      "display_url" : "on.wh.gov\/iyHQfPC"
    } ]
  },
  "geo" : { },
  "id_str" : "243509313782554626",
  "text" : "The #NFL season kicks off tonight! Watch President Obama congratulate the New York @Giants at the White House. Video: http:\/\/t.co\/oU0xLQyT",
  "id" : 243509313782554626,
  "created_at" : "2012-09-06 00:41:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "We the People",
      "screen_name" : "wethepeople",
      "indices" : [ 1, 13 ],
      "id_str" : "369507958",
      "id" : 369507958
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/243494106695876609\/photo\/1",
      "indices" : [ 124, 144 ],
      "url" : "http:\/\/t.co\/UBkEkWFc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A2EQmZbCQAEy3xh.jpg",
      "id_str" : "243494106700070913",
      "id" : 243494106700070913,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A2EQmZbCQAEy3xh.jpg",
      "sizes" : [ {
        "h" : 1200,
        "resize" : "fit",
        "w" : 307
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1975,
        "resize" : "fit",
        "w" : 505
      }, {
        "h" : 1975,
        "resize" : "fit",
        "w" : 505
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 174
      } ],
      "display_url" : "pic.twitter.com\/UBkEkWFc"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/hBoHK6Om",
      "expanded_url" : "http:\/\/on.wh.gov\/EpAPsmJ",
      "display_url" : "on.wh.gov\/EpAPsmJ"
    } ]
  },
  "geo" : { },
  "id_str" : "243494106695876609",
  "text" : ".@WethePeople has racked up 3 million signatures &amp; 46k petitions. What is it? Find out: http:\/\/t.co\/hBoHK6Om Key facts: http:\/\/t.co\/UBkEkWFc",
  "id" : 243494106695876609,
  "created_at" : "2012-09-05 23:41:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/243447065600995328\/photo\/1",
      "indices" : [ 123, 143 ],
      "url" : "http:\/\/t.co\/FH46tRyu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A2Dl0P5CMAAJk4j.jpg",
      "id_str" : "243447065659715584",
      "id" : 243447065659715584,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A2Dl0P5CMAAJk4j.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/FH46tRyu"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "243447065600995328",
  "text" : "Photo of the day: President Obama and daughters Malia &amp; Sasha watch on TV as the First Lady takes the stage at the DNC http:\/\/t.co\/FH46tRyu",
  "id" : 243447065600995328,
  "created_at" : "2012-09-05 20:34:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Google Arts",
      "screen_name" : "googleart",
      "indices" : [ 24, 34 ],
      "id_str" : "4433429660",
      "id" : 4433429660
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 42, 53 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 141, 148 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/uXgM0W4A",
      "expanded_url" : "http:\/\/on.wh.gov\/um1XMHs",
      "display_url" : "on.wh.gov\/um1XMHs"
    } ]
  },
  "geo" : { },
  "id_str" : "243389525886377985",
  "text" : "Go behind the scenes as @GoogleArt visits @whitehouse: http:\/\/t.co\/uXgM0W4A Have Q's on WH art &amp; history? Join the Q&amp;A @ 2ET. Ask w\/ #WHChat",
  "id" : 243389525886377985,
  "created_at" : "2012-09-05 16:45:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 12, 23 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "Google Arts",
      "screen_name" : "googleart",
      "indices" : [ 42, 52 ],
      "id_str" : "4433429660",
      "id" : 4433429660
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 100, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/743YNfUW",
      "expanded_url" : "http:\/\/on.wh.gov\/4F4wMPT",
      "display_url" : "on.wh.gov\/4F4wMPT"
    } ]
  },
  "geo" : { },
  "id_str" : "243337913511845888",
  "text" : "Explore the @whitehouse from home through @googleart: http:\/\/t.co\/743YNfUW &amp; ask questions with #WHChat. WH Curator will answer @ 2ET today",
  "id" : 243337913511845888,
  "created_at" : "2012-09-05 13:20:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "243183625108074496",
  "text" : "RT @petesouza: President Obama and his daughters, Malia and Sasha, watch on television the First Lady's speech to the DNC tonight: http: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 136 ],
        "url" : "http:\/\/t.co\/NsSZYzdY",
        "expanded_url" : "http:\/\/bit.ly\/TWHmmE",
        "display_url" : "bit.ly\/TWHmmE"
      } ]
    },
    "geo" : { },
    "id_str" : "243181335982768128",
    "text" : "President Obama and his daughters, Malia and Sasha, watch on television the First Lady's speech to the DNC tonight: http:\/\/t.co\/NsSZYzdY",
    "id" : 243181335982768128,
    "created_at" : "2012-09-05 02:58:43 +0000",
    "user" : {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "protected" : false,
      "id_str" : "18215973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771916869808844800\/7d_poH48_normal.jpg",
      "id" : 18215973,
      "verified" : true
    }
  },
  "id" : 243183625108074496,
  "created_at" : "2012-09-05 03:07:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 8, 19 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/243160670084923393\/photo\/1",
      "indices" : [ 121, 141 ],
      "url" : "http:\/\/t.co\/MzpEE5nh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A1_hV1RCAAA3Muk.jpg",
      "id_str" : "243160670093312000",
      "id" : 243160670093312000,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A1_hV1RCAAA3Muk.jpg",
      "sizes" : [ {
        "h" : 405,
        "resize" : "fit",
        "w" : 405
      }, {
        "h" : 405,
        "resize" : "fit",
        "w" : 405
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 405,
        "resize" : "fit",
        "w" : 405
      } ],
      "display_url" : "pic.twitter.com\/MzpEE5nh"
    } ],
    "hashtags" : [ {
      "text" : "WHmobile",
      "indices" : [ 110, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/ebwoSu1D",
      "expanded_url" : "http:\/\/on.wh.gov\/drlZAJ2",
      "display_url" : "on.wh.gov\/drlZAJ2"
    } ]
  },
  "geo" : { },
  "id_str" : "243160670084923393",
  "text" : "The new @whitehouse app features news, photos &amp; videos, plus live streams: http:\/\/t.co\/ebwoSu1D Check out #WHmobile: http:\/\/t.co\/MzpEE5nh",
  "id" : 243160670084923393,
  "created_at" : "2012-09-05 01:36:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/243107996836700161\/photo\/1",
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/2bGE93Hp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A1-xb2ICIAAFI5h.jpg",
      "id_str" : "243107996845088768",
      "id" : 243107996845088768,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A1-xb2ICIAAFI5h.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/2bGE93Hp"
    } ],
    "hashtags" : [ {
      "text" : "Isaac",
      "indices" : [ 66, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "243107996836700161",
  "text" : "Photo of the Day: President Obama meets with victims of Hurricane #Isaac in LaPlace, Louisiana: http:\/\/t.co\/2bGE93Hp",
  "id" : 243107996836700161,
  "created_at" : "2012-09-04 22:07:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WH.gov",
      "screen_name" : "WHWeb",
      "indices" : [ 3, 9 ],
      "id_str" : "390320946",
      "id" : 390320946
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 43, 54 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "opensource",
      "indices" : [ 55, 66 ]
    }, {
      "text" : "OSS",
      "indices" : [ 131, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/Gu2fkgPY",
      "expanded_url" : "http:\/\/at.wh.gov\/dsz4G",
      "display_url" : "at.wh.gov\/dsz4G"
    } ]
  },
  "geo" : { },
  "id_str" : "243060007296442368",
  "text" : "RT @WHWeb: Want to use &amp; contribute to @whitehouse #opensource projects? See our new page for developers: http:\/\/t.co\/Gu2fkgPY #OSS  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 32, 43 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "opensource",
        "indices" : [ 44, 55 ]
      }, {
        "text" : "OSS",
        "indices" : [ 120, 124 ]
      }, {
        "text" : "OpenGov",
        "indices" : [ 125, 133 ]
      }, {
        "text" : "Drupal",
        "indices" : [ 134, 141 ]
      } ],
      "urls" : [ {
        "indices" : [ 99, 119 ],
        "url" : "http:\/\/t.co\/Gu2fkgPY",
        "expanded_url" : "http:\/\/at.wh.gov\/dsz4G",
        "display_url" : "at.wh.gov\/dsz4G"
      } ]
    },
    "geo" : { },
    "id_str" : "243057305539723264",
    "text" : "Want to use &amp; contribute to @whitehouse #opensource projects? See our new page for developers: http:\/\/t.co\/Gu2fkgPY #OSS #OpenGov #Drupal",
    "id" : 243057305539723264,
    "created_at" : "2012-09-04 18:45:52 +0000",
    "user" : {
      "name" : "WH.gov",
      "screen_name" : "WHWeb",
      "protected" : false,
      "id_str" : "390320946",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618051538582310913\/0xcdHiQS_normal.jpg",
      "id" : 390320946,
      "verified" : true
    }
  },
  "id" : 243060007296442368,
  "created_at" : "2012-09-04 18:56:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 37, 48 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHmobile",
      "indices" : [ 111, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/MjqfkPeo",
      "expanded_url" : "http:\/\/on.wh.gov\/nbj09L4",
      "display_url" : "on.wh.gov\/nbj09L4"
    }, {
      "indices" : [ 122, 142 ],
      "url" : "http:\/\/t.co\/dJDtUtQo",
      "expanded_url" : "http:\/\/on.wh.gov\/AOBlmNw",
      "display_url" : "on.wh.gov\/AOBlmNw"
    } ]
  },
  "geo" : { },
  "id_str" : "243046990966046720",
  "text" : "Today, we're excited to announce new @whitehouse apps for iPhone, iPad &amp; Android: http:\/\/t.co\/MjqfkPeo Get #WHmobile: http:\/\/t.co\/dJDtUtQo",
  "id" : 243046990966046720,
  "created_at" : "2012-09-04 18:04:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 3, 11 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 17, 28 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http:\/\/t.co\/UbRJUvWm",
      "expanded_url" : "http:\/\/youtu.be\/0wCvyR3Psx4",
      "display_url" : "youtu.be\/0wCvyR3Psx4"
    }, {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/1vBuBdle",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2012\/09\/04\/visiting-white-house-anytime-anywhere-and-any-device",
      "display_url" : "whitehouse.gov\/blog\/2012\/09\/0\u2026"
    }, {
      "indices" : [ 115, 136 ],
      "url" : "https:\/\/t.co\/WVEZbDUI",
      "expanded_url" : "https:\/\/github.com\/whitehouse",
      "display_url" : "github.com\/whitehouse"
    } ]
  },
  "geo" : { },
  "id_str" : "242977371119038464",
  "text" : "RT @macon44: new @whitehouse mobile apps http:\/\/t.co\/UbRJUvWm are live http:\/\/t.co\/1vBuBdle, as is the source code https:\/\/t.co\/WVEZbDUI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 4, 15 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 28, 48 ],
        "url" : "http:\/\/t.co\/UbRJUvWm",
        "expanded_url" : "http:\/\/youtu.be\/0wCvyR3Psx4",
        "display_url" : "youtu.be\/0wCvyR3Psx4"
      }, {
        "indices" : [ 58, 78 ],
        "url" : "http:\/\/t.co\/1vBuBdle",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2012\/09\/04\/visiting-white-house-anytime-anywhere-and-any-device",
        "display_url" : "whitehouse.gov\/blog\/2012\/09\/0\u2026"
      }, {
        "indices" : [ 102, 123 ],
        "url" : "https:\/\/t.co\/WVEZbDUI",
        "expanded_url" : "https:\/\/github.com\/whitehouse",
        "display_url" : "github.com\/whitehouse"
      } ]
    },
    "geo" : { },
    "id_str" : "242971834675503104",
    "text" : "new @whitehouse mobile apps http:\/\/t.co\/UbRJUvWm are live http:\/\/t.co\/1vBuBdle, as is the source code https:\/\/t.co\/WVEZbDUI",
    "id" : 242971834675503104,
    "created_at" : "2012-09-04 13:06:14 +0000",
    "user" : {
      "name" : "Macon Phillips",
      "screen_name" : "IIPCoordinator",
      "protected" : false,
      "id_str" : "110823581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000495374915\/f6a5ae048ab7f8f12c0386114df53203_normal.jpeg",
      "id" : 110823581,
      "verified" : true
    }
  },
  "id" : 242977371119038464,
  "created_at" : "2012-09-04 13:28:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Isaac",
      "indices" : [ 81, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/V34MPaXB",
      "expanded_url" : "http:\/\/at.wh.gov\/dr9a0",
      "display_url" : "at.wh.gov\/dr9a0"
    } ]
  },
  "geo" : { },
  "id_str" : "242797283723333633",
  "text" : "RT @WHLive: Remarks by President Obama after touring flood damage from Hurricane #Isaac in Louisiana: http:\/\/t.co\/V34MPaXB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Isaac",
        "indices" : [ 69, 75 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 110 ],
        "url" : "http:\/\/t.co\/V34MPaXB",
        "expanded_url" : "http:\/\/at.wh.gov\/dr9a0",
        "display_url" : "at.wh.gov\/dr9a0"
      } ]
    },
    "geo" : { },
    "id_str" : "242797152496123904",
    "text" : "Remarks by President Obama after touring flood damage from Hurricane #Isaac in Louisiana: http:\/\/t.co\/V34MPaXB",
    "id" : 242797152496123904,
    "created_at" : "2012-09-04 01:32:06 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 242797283723333633,
  "created_at" : "2012-09-04 01:32:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Isaac",
      "indices" : [ 57, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 121, 141 ],
      "url" : "http:\/\/t.co\/I5fZL2Lv",
      "expanded_url" : "http:\/\/on.wh.gov\/cQGiCua",
      "display_url" : "on.wh.gov\/cQGiCua"
    } ]
  },
  "geo" : { },
  "id_str" : "242757886252568577",
  "text" : "Happening at 7:20ET: President Obama speaks on Hurricane #Isaac response &amp; recovery efforts from New Orleans. Watch: http:\/\/t.co\/I5fZL2Lv",
  "id" : 242757886252568577,
  "created_at" : "2012-09-03 22:56:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Immediate Capital",
      "screen_name" : "HildaSolisDOL",
      "indices" : [ 92, 106 ],
      "id_str" : "2187968017",
      "id" : 2187968017
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/jtQiuRRz",
      "expanded_url" : "http:\/\/on.wh.gov\/lcnBQjW",
      "display_url" : "on.wh.gov\/lcnBQjW"
    }, {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/GOVnl5mH",
      "expanded_url" : "http:\/\/on.wh.gov\/Bqp7x8i",
      "display_url" : "on.wh.gov\/Bqp7x8i"
    } ]
  },
  "geo" : { },
  "id_str" : "242717421268504578",
  "text" : "Labor Day 2012: Honoring the Great American Worker: http:\/\/t.co\/jtQiuRRz Video message from @HildaSolisDOL: http:\/\/t.co\/GOVnl5mH",
  "id" : 242717421268504578,
  "created_at" : "2012-09-03 20:15:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/242689768952049664\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/vzTy333f",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A141Dx2CMAEfgob.jpg",
      "id_str" : "242689768960438273",
      "id" : 242689768960438273,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A141Dx2CMAEfgob.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/vzTy333f"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/WGVwkDX6",
      "expanded_url" : "http:\/\/on.wh.gov\/8jtymGu",
      "display_url" : "on.wh.gov\/8jtymGu"
    } ]
  },
  "geo" : { },
  "id_str" : "242689768952049664",
  "text" : "\"America will always stand behind our workers\" -President Obama on Labor Day http:\/\/t.co\/WGVwkDX6 Obama greets workers: http:\/\/t.co\/vzTy333f",
  "id" : 242689768952049664,
  "created_at" : "2012-09-03 18:25:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/LTk6r4vv",
      "expanded_url" : "http:\/\/on.wh.gov\/qfgTNw1",
      "display_url" : "on.wh.gov\/qfgTNw1"
    } ]
  },
  "geo" : { },
  "id_str" : "242608516060295169",
  "text" : "Ale to the Chief: Check out the White House Beer Recipe: http:\/\/t.co\/LTk6r4vv",
  "id" : 242608516060295169,
  "created_at" : "2012-09-03 13:02:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 40, 43 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/242441860163985408\/photo\/1",
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/qX0nOZ1p",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A11TllpCYAEqfN7.jpg",
      "id_str" : "242441860172374017",
      "id" : 242441860172374017,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A11TllpCYAEqfN7.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/qX0nOZ1p"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "242441860163985408",
  "text" : "Photo of the Day: President Obama &amp; @VP Biden talk on the patio outside the Oval Office: http:\/\/t.co\/qX0nOZ1p",
  "id" : 242441860163985408,
  "created_at" : "2012-09-03 02:00:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/1aT5RzqB",
      "expanded_url" : "http:\/\/on.wh.gov\/Gz3klfv",
      "display_url" : "on.wh.gov\/Gz3klfv"
    } ]
  },
  "geo" : { },
  "id_str" : "242309910849794049",
  "text" : "Weekly Address: Honoring Our Nation's Service Members and Military Families http:\/\/t.co\/1aT5RzqB",
  "id" : 242309910849794049,
  "created_at" : "2012-09-02 17:15:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/242221946811609088\/photo\/1",
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/Ewz0Ev7k",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A1yLk8jCcAAhunx.jpg",
      "id_str" : "242221946815803392",
      "id" : 242221946815803392,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A1yLk8jCcAAhunx.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 694,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1323,
        "resize" : "fit",
        "w" : 1952
      }, {
        "h" : 230,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 407,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/Ewz0Ev7k"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "242221946811609088",
  "text" : "Photo of the Day: President Obama bids farewell to Gen. Lloyd Austin III at Fort Bliss in El Paso, Texas: http:\/\/t.co\/Ewz0Ev7k",
  "id" : 242221946811609088,
  "created_at" : "2012-09-02 11:26:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/XeYPxsXX",
      "expanded_url" : "http:\/\/on.wh.gov\/PBlpNOI",
      "display_url" : "on.wh.gov\/PBlpNOI"
    } ]
  },
  "geo" : { },
  "id_str" : "242069540849217538",
  "text" : "\"It's time to build a nation that lives up to the ideals that so many Americans have fought for\" -President Obama: http:\/\/t.co\/XeYPxsXX",
  "id" : 242069540849217538,
  "created_at" : "2012-09-02 01:20:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/1QIIczUt",
      "expanded_url" : "http:\/\/on.wh.gov\/gcu588m",
      "display_url" : "on.wh.gov\/gcu588m"
    } ]
  },
  "geo" : { },
  "id_str" : "242046631606902784",
  "text" : "President Obama's Weekly Address: Honoring Our Nation's Service Members &amp; Military Families: http:\/\/t.co\/1QIIczUt",
  "id" : 242046631606902784,
  "created_at" : "2012-09-01 23:49:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/242018350014803968\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/KlNmPJwf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/A1vSaDZCMAAgIG_.jpg",
      "id_str" : "242018350023192576",
      "id" : 242018350023192576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/A1vSaDZCMAAgIG_.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/KlNmPJwf"
    } ],
    "hashtags" : [ {
      "text" : "LaborDay",
      "indices" : [ 67, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/MTdb8vKd",
      "expanded_url" : "http:\/\/on.wh.gov\/QSyq9d7",
      "display_url" : "on.wh.gov\/QSyq9d7"
    } ]
  },
  "geo" : { },
  "id_str" : "242018350014803968",
  "text" : "\"America will always stand behind our workers\" -President Obama on #LaborDay http:\/\/t.co\/MTdb8vKd Obama greets workers: http:\/\/t.co\/KlNmPJwf",
  "id" : 242018350014803968,
  "created_at" : "2012-09-01 21:57:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/OHg9KvMZ",
      "expanded_url" : "http:\/\/at.wh.gov\/doJRh",
      "display_url" : "at.wh.gov\/doJRh"
    }, {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/0dUbXGxK",
      "expanded_url" : "http:\/\/youtu.be\/dygQrX8FI3Q",
      "display_url" : "youtu.be\/dygQrX8FI3Q"
    } ]
  },
  "geo" : { },
  "id_str" : "241956706958061568",
  "text" : "RT @PressSec: We just released the White House beer recipe. Check it out: http:\/\/t.co\/OHg9KvMZ &amp; see how it's made: http:\/\/t.co\/0dUbXGxK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 80 ],
        "url" : "http:\/\/t.co\/OHg9KvMZ",
        "expanded_url" : "http:\/\/at.wh.gov\/doJRh",
        "display_url" : "at.wh.gov\/doJRh"
      }, {
        "indices" : [ 106, 126 ],
        "url" : "http:\/\/t.co\/0dUbXGxK",
        "expanded_url" : "http:\/\/youtu.be\/dygQrX8FI3Q",
        "display_url" : "youtu.be\/dygQrX8FI3Q"
      } ]
    },
    "geo" : { },
    "id_str" : "241956323154092033",
    "text" : "We just released the White House beer recipe. Check it out: http:\/\/t.co\/OHg9KvMZ &amp; see how it's made: http:\/\/t.co\/0dUbXGxK",
    "id" : 241956323154092033,
    "created_at" : "2012-09-01 17:50:57 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 241956706958061568,
  "created_at" : "2012-09-01 17:52:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SaluteTroops",
      "indices" : [ 130, 143 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241889350659489792",
  "text" : "President Obama: \"Only 1% of Americans may wear the uniform, but 100% of Americans need to be supporting you &amp; your families\" #SaluteTroops",
  "id" : 241889350659489792,
  "created_at" : "2012-09-01 13:24:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
} ]