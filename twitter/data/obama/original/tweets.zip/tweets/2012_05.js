Grailbird.data.tweets_2012_05 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/bGwivZsS",
      "expanded_url" : "http:\/\/on.wh.gov\/n0SG",
      "display_url" : "on.wh.gov\/n0SG"
    } ]
  },
  "geo" : { },
  "id_str" : "208337160322027520",
  "text" : "In March, students joined the First Lady to plant a new crop in the WH garden. Today, local kids helped harvest: http:\/\/t.co\/bGwivZsS",
  "id" : 208337160322027520,
  "created_at" : "2012-05-31 23:20:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 21, 24 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/208296590811729920\/photo\/1",
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/IU0If7uv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AuQEpU_CEAE5sQd.jpg",
      "id_str" : "208296590820118529",
      "id" : 208296590820118529,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AuQEpU_CEAE5sQd.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 667,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 667,
        "resize" : "fit",
        "w" : 1000
      } ],
      "display_url" : "pic.twitter.com\/IU0If7uv"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/JIlIjEhk",
      "expanded_url" : "http:\/\/on.wh.gov\/DYdJ",
      "display_url" : "on.wh.gov\/DYdJ"
    } ]
  },
  "geo" : { },
  "id_str" : "208296590811729920",
  "text" : "\"A proud tradition\": @VP Biden delivers the commencement address @ West Point graduation: http:\/\/t.co\/JIlIjEhk http:\/\/t.co\/IU0If7uv",
  "id" : 208296590811729920,
  "created_at" : "2012-05-31 20:39:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/HyrbvzYP",
      "expanded_url" : "http:\/\/on.wh.gov\/hkkH",
      "display_url" : "on.wh.gov\/hkkH"
    } ]
  },
  "geo" : { },
  "id_str" : "208278238462615552",
  "text" : "Op-ed by Valerie Jarrett: Prioritizing low-income families &amp; creating pathways to opportunity for all Americans: http:\/\/t.co\/HyrbvzYP",
  "id" : 208278238462615552,
  "created_at" : "2012-05-31 19:26:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "indices" : [ 3, 10 ],
      "id_str" : "166252256",
      "id" : 166252256
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ENERGY\/status\/208266304384286720\/photo\/1",
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/TCTbES07",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AuPpGbPCQAAhtGd.jpg",
      "id_str" : "208266304388481024",
      "id" : 208266304388481024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AuPpGbPCQAAhtGd.jpg",
      "sizes" : [ {
        "h" : 455,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1296,
        "resize" : "fit",
        "w" : 968
      }, {
        "h" : 1296,
        "resize" : "fit",
        "w" : 968
      }, {
        "h" : 803,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/TCTbES07"
    } ],
    "hashtags" : [ {
      "text" : "labchat",
      "indices" : [ 56, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "208267773372153858",
  "text" : "RT @ENERGY: Hi everyone. Steven Chu here to answer your #labchat q's. -Chu http:\/\/t.co\/TCTbES07",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ENERGY\/status\/208266304384286720\/photo\/1",
        "indices" : [ 63, 83 ],
        "url" : "http:\/\/t.co\/TCTbES07",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AuPpGbPCQAAhtGd.jpg",
        "id_str" : "208266304388481024",
        "id" : 208266304388481024,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AuPpGbPCQAAhtGd.jpg",
        "sizes" : [ {
          "h" : 455,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1296,
          "resize" : "fit",
          "w" : 968
        }, {
          "h" : 1296,
          "resize" : "fit",
          "w" : 968
        }, {
          "h" : 803,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/TCTbES07"
      } ],
      "hashtags" : [ {
        "text" : "labchat",
        "indices" : [ 44, 52 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "208266304384286720",
    "text" : "Hi everyone. Steven Chu here to answer your #labchat q's. -Chu http:\/\/t.co\/TCTbES07",
    "id" : 208266304384286720,
    "created_at" : "2012-05-31 18:38:52 +0000",
    "user" : {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "protected" : false,
      "id_str" : "166252256",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793425839694155781\/HRS6sfn4_normal.jpg",
      "id" : 166252256,
      "verified" : true
    }
  },
  "id" : 208267773372153858,
  "created_at" : "2012-05-31 18:44:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "indices" : [ 3, 10 ],
      "id_str" : "166252256",
      "id" : 166252256
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LabChat",
      "indices" : [ 51, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "208259088050688002",
  "text" : "RT @ENERGY: Today 2 pm ET | Less than 1 hour until #LabChat! 3 National Lab researchers + 1 special guest from Energy HQ! Ask your Qs.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LabChat",
        "indices" : [ 39, 47 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "208245415156518913",
    "text" : "Today 2 pm ET | Less than 1 hour until #LabChat! 3 National Lab researchers + 1 special guest from Energy HQ! Ask your Qs.",
    "id" : 208245415156518913,
    "created_at" : "2012-05-31 17:15:50 +0000",
    "user" : {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "protected" : false,
      "id_str" : "166252256",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793425839694155781\/HRS6sfn4_normal.jpg",
      "id" : 166252256,
      "verified" : true
    }
  },
  "id" : 208259088050688002,
  "created_at" : "2012-05-31 18:10:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/6ttj0MKd",
      "expanded_url" : "http:\/\/on.wh.gov\/CXdL",
      "display_url" : "on.wh.gov\/CXdL"
    } ]
  },
  "geo" : { },
  "id_str" : "208249102356582404",
  "text" : "Watch live: President Obama welcomes President George W. Bush for official portrait unveiling: http:\/\/t.co\/6ttj0MKd",
  "id" : 208249102356582404,
  "created_at" : "2012-05-31 17:30:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SummerJobsPlus",
      "indices" : [ 86, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/ij1kJl6G",
      "expanded_url" : "http:\/\/on.wh.gov\/RtxB",
      "display_url" : "on.wh.gov\/RtxB"
    } ]
  },
  "geo" : { },
  "id_str" : "208236770909892610",
  "text" : "RT @whitehouseostp: A Must Watch: Dr. John Holdren's first job: http:\/\/t.co\/ij1kJl6G  #SummerJobsPlus",
  "id" : 208236770909892610,
  "created_at" : "2012-05-31 16:41:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Homeland Security",
      "screen_name" : "DHSgov",
      "indices" : [ 35, 42 ],
      "id_str" : "15647676",
      "id" : 15647676
    }, {
      "name" : "Craig Fugate",
      "screen_name" : "CraigatFEMA",
      "indices" : [ 59, 71 ],
      "id_str" : "67378554",
      "id" : 67378554
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/208217122571157504\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/aX71cPYx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AuO8XqtCAAECbKj.jpg",
      "id_str" : "208217122575351809",
      "id" : 208217122575351809,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AuO8XqtCAAECbKj.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/aX71cPYx"
    } ],
    "hashtags" : [ {
      "text" : "hurricane",
      "indices" : [ 75, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "208217122571157504",
  "text" : "Photo of the Day: President Obama, @DHSgov Sec Napolitano, @CraigatFEMA in #hurricane preparedness mtg in the Sit Room: http:\/\/t.co\/aX71cPYx",
  "id" : 208217122571157504,
  "created_at" : "2012-05-31 15:23:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfFreedom",
      "indices" : [ 17, 32 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/WwKFWb86",
      "expanded_url" : "http:\/\/youtu.be\/MCAwRkZQM2E",
      "display_url" : "youtu.be\/MCAwRkZQM2E"
    } ]
  },
  "geo" : { },
  "id_str" : "208165271368777730",
  "text" : "President Obama: #MedalOfFreedom honorees \"inspired us with their actions.\" Watch the award ceremony: http:\/\/t.co\/WwKFWb86",
  "id" : 208165271368777730,
  "created_at" : "2012-05-31 11:57:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfFreedom",
      "indices" : [ 35, 50 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/z3LcvCUw",
      "expanded_url" : "http:\/\/on.wh.gov\/yVmC",
      "display_url" : "on.wh.gov\/yVmC"
    } ]
  },
  "geo" : { },
  "id_str" : "207967851175354368",
  "text" : "Watch: John Glenn on his hope that #MedalOfFreedom winners will encourage children to embrace their curiosity: http:\/\/t.co\/z3LcvCUw",
  "id" : 207967851175354368,
  "created_at" : "2012-05-30 22:52:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 16, 27 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalofFreedom",
      "indices" : [ 66, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/MnBEX0pn",
      "expanded_url" : "http:\/\/go.nasa.gov\/L3P6DP",
      "display_url" : "go.nasa.gov\/L3P6DP"
    } ]
  },
  "geo" : { },
  "id_str" : "207967362744467456",
  "text" : "RT @NASA: A new @WhiteHouse blog post explores what receiving the #MedalofFreedom meant to John Glenn: http:\/\/t.co\/MnBEX0pn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.exacttarget.com\/social\" rel=\"nofollow\"\u003ESocialEngage\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 6, 17 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MedalofFreedom",
        "indices" : [ 56, 71 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 113 ],
        "url" : "http:\/\/t.co\/MnBEX0pn",
        "expanded_url" : "http:\/\/go.nasa.gov\/L3P6DP",
        "display_url" : "go.nasa.gov\/L3P6DP"
      } ]
    },
    "geo" : { },
    "id_str" : "207966435975233536",
    "text" : "A new @WhiteHouse blog post explores what receiving the #MedalofFreedom meant to John Glenn: http:\/\/t.co\/MnBEX0pn",
    "id" : 207966435975233536,
    "created_at" : "2012-05-30 22:47:16 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 207967362744467456,
  "created_at" : "2012-05-30 22:50:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfFreedom",
      "indices" : [ 64, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/uqb7cJys",
      "expanded_url" : "http:\/\/on.wh.gov\/2sHL",
      "display_url" : "on.wh.gov\/2sHL"
    } ]
  },
  "geo" : { },
  "id_str" : "207916957293490177",
  "text" : "Former Secretary of State Madeleine Albright says receiving the #MedalOfFreedom left her \"almost\" speechless. Watch: http:\/\/t.co\/uqb7cJys",
  "id" : 207916957293490177,
  "created_at" : "2012-05-30 19:30:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/gjxCOGTc",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "207857233487331329",
  "text" : "RT @Brundage44: POTUS to make remarks on Ex-Im bill shortly, urge Congress to do more on jobs - watch live at http:\/\/t.co\/gjxCOGTc  #Con ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CongressToDoList",
        "indices" : [ 116, 133 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 114 ],
        "url" : "http:\/\/t.co\/gjxCOGTc",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "207856139235364865",
    "text" : "POTUS to make remarks on Ex-Im bill shortly, urge Congress to do more on jobs - watch live at http:\/\/t.co\/gjxCOGTc  #CongressToDoList",
    "id" : 207856139235364865,
    "created_at" : "2012-05-30 15:29:00 +0000",
    "user" : {
      "name" : "Liz Allen",
      "screen_name" : "LizAllen44",
      "protected" : false,
      "id_str" : "562456722",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705867932392407042\/-1npI72O_normal.jpg",
      "id" : 562456722,
      "verified" : true
    }
  },
  "id" : 207857233487331329,
  "created_at" : "2012-05-30 15:33:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    }, {
      "name" : "U.S. Navy",
      "screen_name" : "USNavy",
      "indices" : [ 72, 79 ],
      "id_str" : "54885400",
      "id" : 54885400
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/s4U0w7Nj",
      "expanded_url" : "http:\/\/wh.gov\/Mdz",
      "display_url" : "wh.gov\/Mdz"
    } ]
  },
  "geo" : { },
  "id_str" : "207854489338789888",
  "text" : "RT @JoiningForces: Meet the women who are charting a new course onboard @USNavy submarines: http:\/\/t.co\/s4U0w7Nj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "U.S. Navy",
        "screen_name" : "USNavy",
        "indices" : [ 53, 60 ],
        "id_str" : "54885400",
        "id" : 54885400
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 93 ],
        "url" : "http:\/\/t.co\/s4U0w7Nj",
        "expanded_url" : "http:\/\/wh.gov\/Mdz",
        "display_url" : "wh.gov\/Mdz"
      } ]
    },
    "geo" : { },
    "id_str" : "207826430694916097",
    "text" : "Meet the women who are charting a new course onboard @USNavy submarines: http:\/\/t.co\/s4U0w7Nj",
    "id" : 207826430694916097,
    "created_at" : "2012-05-30 13:30:56 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 207854489338789888,
  "created_at" : "2012-05-30 15:22:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven VanRoekel",
      "screen_name" : "stevenvDC",
      "indices" : [ 46, 56 ],
      "id_str" : "26390322",
      "id" : 26390322
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/Nyfw4yW8",
      "expanded_url" : "http:\/\/on.wh.gov\/PF57",
      "display_url" : "on.wh.gov\/PF57"
    } ]
  },
  "geo" : { },
  "id_str" : "207793374231666688",
  "text" : "Roadmap for a Digital Government: Federal CIO @stevenvDC announces the Digital Govt Strategy: http:\/\/t.co\/Nyfw4yW8",
  "id" : 207793374231666688,
  "created_at" : "2012-05-30 11:19:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/207625588935102464\/photo\/1",
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/2pWOnx7A",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AuGiX4NCEAIEjLu.jpg",
      "id_str" : "207625588943491074",
      "id" : 207625588943491074,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AuGiX4NCEAIEjLu.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/2pWOnx7A"
    } ],
    "hashtags" : [ {
      "text" : "MedalOfFreedom",
      "indices" : [ 58, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207625588935102464",
  "text" : "Photo of the Day: President Obama talks with Presidential #MedalOfFreedom recipient Toni Morrison in the Blue Room: http:\/\/t.co\/2pWOnx7A",
  "id" : 207625588935102464,
  "created_at" : "2012-05-30 00:12:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/aHCXMIjv",
      "expanded_url" : "http:\/\/youtu.be\/LBLz_JGIuZo",
      "display_url" : "youtu.be\/LBLz_JGIuZo"
    } ]
  },
  "geo" : { },
  "id_str" : "207612185709514752",
  "text" : "Watch: President Obama marks the 50th anniversary of Vietnam War at the Vietnam Memorial in DC: http:\/\/t.co\/aHCXMIjv",
  "id" : 207612185709514752,
  "created_at" : "2012-05-29 23:19:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfFreedom",
      "indices" : [ 29, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207559015125876736",
  "text" : "RT @WHLive: President Obama: #MedalOfFreedom honorees \"have moved us with their words &amp; inspired us with their actions\" Watch: http: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MedalOfFreedom",
        "indices" : [ 17, 32 ]
      } ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/g5icuVZL",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "207558961317158912",
    "text" : "President Obama: #MedalOfFreedom honorees \"have moved us with their words &amp; inspired us with their actions\" Watch: http:\/\/t.co\/g5icuVZL",
    "id" : 207558961317158912,
    "created_at" : "2012-05-29 19:48:07 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 207559015125876736,
  "created_at" : "2012-05-29 19:48:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 141 ],
      "url" : "http:\/\/t.co\/dt4m1gYT",
      "expanded_url" : "http:\/\/on.wh.gov\/g5hV",
      "display_url" : "on.wh.gov\/g5hV"
    } ]
  },
  "geo" : { },
  "id_str" : "207557554547601408",
  "text" : "Happening now: President Obama awards Medal of Freedom to Bob Dylan, Madeleine Albright, John Glenn &amp; others. Watch: http:\/\/t.co\/dt4m1gYT",
  "id" : 207557554547601408,
  "created_at" : "2012-05-29 19:42:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 94, 102 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CongressToDoList",
      "indices" : [ 73, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/EvdlCj9v",
      "expanded_url" : "http:\/\/on.wh.gov\/DATt",
      "display_url" : "on.wh.gov\/DATt"
    } ]
  },
  "geo" : { },
  "id_str" : "207501594357542913",
  "text" : "President Obama answered your questions about clean energy job &amp; the #CongressToDoList on @Twitter: http:\/\/t.co\/EvdlCj9v",
  "id" : 207501594357542913,
  "created_at" : "2012-05-29 16:00:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JoiningForces",
      "indices" : [ 92, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/thNKkjtV",
      "expanded_url" : "http:\/\/on.wh.gov\/IHh3",
      "display_url" : "on.wh.gov\/IHh3"
    } ]
  },
  "geo" : { },
  "id_str" : "207488664677257216",
  "text" : "Dr. Jill Biden: \"Everyone Can Find a Way to Honor our Service Members\" http:\/\/t.co\/thNKkjtV #JoiningForces",
  "id" : 207488664677257216,
  "created_at" : "2012-05-29 15:08:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 3, 11 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/sRYmUDBN",
      "expanded_url" : "http:\/\/NYTimes.com",
      "display_url" : "NYTimes.com"
    }, {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/hWQogEzL",
      "expanded_url" : "http:\/\/nyti.ms\/Kp7ypn",
      "display_url" : "nyti.ms\/Kp7ypn"
    }, {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/hfnJPEJB",
      "expanded_url" : "http:\/\/wh.gov\/innovationfellows",
      "display_url" : "wh.gov\/innovationfell\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "207459659974582272",
  "text" : "RT @macon44: A Government Program That Could Improve the Economy - http:\/\/t.co\/sRYmUDBN http:\/\/t.co\/hWQogEzL http:\/\/t.co\/hfnJPEJB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 74 ],
        "url" : "http:\/\/t.co\/sRYmUDBN",
        "expanded_url" : "http:\/\/NYTimes.com",
        "display_url" : "NYTimes.com"
      }, {
        "indices" : [ 75, 95 ],
        "url" : "http:\/\/t.co\/hWQogEzL",
        "expanded_url" : "http:\/\/nyti.ms\/Kp7ypn",
        "display_url" : "nyti.ms\/Kp7ypn"
      }, {
        "indices" : [ 96, 116 ],
        "url" : "http:\/\/t.co\/hfnJPEJB",
        "expanded_url" : "http:\/\/wh.gov\/innovationfellows",
        "display_url" : "wh.gov\/innovationfell\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "207457014459269124",
    "text" : "A Government Program That Could Improve the Economy - http:\/\/t.co\/sRYmUDBN http:\/\/t.co\/hWQogEzL http:\/\/t.co\/hfnJPEJB",
    "id" : 207457014459269124,
    "created_at" : "2012-05-29 13:03:01 +0000",
    "user" : {
      "name" : "Macon Phillips",
      "screen_name" : "IIPCoordinator",
      "protected" : false,
      "id_str" : "110823581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000495374915\/f6a5ae048ab7f8f12c0386114df53203_normal.jpeg",
      "id" : 110823581,
      "verified" : true
    }
  },
  "id" : 207459659974582272,
  "created_at" : "2012-05-29 13:13:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SBA",
      "screen_name" : "SBAgov",
      "indices" : [ 91, 98 ],
      "id_str" : "153149305",
      "id" : 153149305
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/tiyu8m2v",
      "expanded_url" : "http:\/\/on.wh.gov\/KnQa",
      "display_url" : "on.wh.gov\/KnQa"
    } ]
  },
  "geo" : { },
  "id_str" : "207447789632888832",
  "text" : "Watch: Hanging out with Small Business Administrator Karen Mills: http:\/\/t.co\/tiyu8m2v cc: @sbagov",
  "id" : 207447789632888832,
  "created_at" : "2012-05-29 12:26:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/XOZ82rGZ",
      "expanded_url" : "http:\/\/on.wh.gov\/LjVF",
      "display_url" : "on.wh.gov\/LjVF"
    } ]
  },
  "geo" : { },
  "id_str" : "207315065131638784",
  "text" : "Weekly Address: Honoring Our Fallen Heroes this Memorial Day http:\/\/t.co\/XOZ82rGZ",
  "id" : 207315065131638784,
  "created_at" : "2012-05-29 03:38:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MemorialDay",
      "indices" : [ 19, 31 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/gfORZVEf",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2012\/05\/28\/president-obama-celebrates-us-troops-memorial-day",
      "display_url" : "whitehouse.gov\/blog\/2012\/05\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "207299986973663233",
  "text" : "President Obama on #MemorialDay: \"We come together, as Americans, to pray, to reflect &amp; to remember these heroes\" http:\/\/t.co\/gfORZVEf",
  "id" : 207299986973663233,
  "created_at" : "2012-05-29 02:39:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Washington Post",
      "screen_name" : "washingtonpost",
      "indices" : [ 21, 36 ],
      "id_str" : "2467791",
      "id" : 2467791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/NfDM4rMb",
      "expanded_url" : "http:\/\/wapo.st\/JIq7C5",
      "display_url" : "wapo.st\/JIq7C5"
    } ]
  },
  "geo" : { },
  "id_str" : "207267836714950656",
  "text" : "RT @AlexHortonVA: RT @washingtonpost: A look at The Vietnam Memorial's past and present http:\/\/t.co\/NfDM4rMb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Washington Post",
        "screen_name" : "washingtonpost",
        "indices" : [ 3, 18 ],
        "id_str" : "2467791",
        "id" : 2467791
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 70, 90 ],
        "url" : "http:\/\/t.co\/NfDM4rMb",
        "expanded_url" : "http:\/\/wapo.st\/JIq7C5",
        "display_url" : "wapo.st\/JIq7C5"
      } ]
    },
    "geo" : { },
    "id_str" : "207243459910840320",
    "text" : "RT @washingtonpost: A look at The Vietnam Memorial's past and present http:\/\/t.co\/NfDM4rMb",
    "id" : 207243459910840320,
    "created_at" : "2012-05-28 22:54:25 +0000",
    "user" : {
      "name" : "Alex Horton",
      "screen_name" : "AlexHortonTX",
      "protected" : false,
      "id_str" : "169620752",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738970146350366720\/auEAWNru_normal.jpg",
      "id" : 169620752,
      "verified" : true
    }
  },
  "id" : 207267836714950656,
  "created_at" : "2012-05-29 00:31:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/207252818627792898\/photo\/1",
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/88clhjim",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AuBPVymCEAAD9T6.jpg",
      "id_str" : "207252818636181504",
      "id" : 207252818636181504,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AuBPVymCEAAD9T6.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/88clhjim"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207252818627792898",
  "text" : "Photo of the Day: President Obama is reflected in the Vietnam Veterans Memorial wall as he speaks on Memorial Day: http:\/\/t.co\/88clhjim",
  "id" : 207252818627792898,
  "created_at" : "2012-05-28 23:31:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MemorialDay",
      "indices" : [ 63, 75 ]
    }, {
      "text" : "HonorTheFallen",
      "indices" : [ 119, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/lXKSyPy5",
      "expanded_url" : "http:\/\/youtu.be\/xFYCEKDmvz0",
      "display_url" : "youtu.be\/xFYCEKDmvz0"
    } ]
  },
  "geo" : { },
  "id_str" : "207223010489409536",
  "text" : "\"America will be there for you.\" -President Obama commemorates #MemorialDay @ Arlington Cemetery: http:\/\/t.co\/lXKSyPy5 #HonorTheFallen",
  "id" : 207223010489409536,
  "created_at" : "2012-05-28 21:33:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SECNAV Ray Mabus",
      "screen_name" : "SECNAV",
      "indices" : [ 3, 10 ],
      "id_str" : "117821354",
      "id" : 117821354
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 68, 79 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MemorialDay",
      "indices" : [ 116, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207218743670091779",
  "text" : "RT @SECNAV: Together with 1st women submariners, POTUS &amp; FLOTUS @whitehouse to honor the fallen &amp; recognize #MemorialDay http:\/\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 56, 67 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MemorialDay",
        "indices" : [ 104, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 137 ],
        "url" : "http:\/\/t.co\/n3AMmEdo",
        "expanded_url" : "http:\/\/flic.kr\/p\/c72ogm",
        "display_url" : "flic.kr\/p\/c72ogm"
      } ]
    },
    "geo" : { },
    "id_str" : "207198706703925248",
    "text" : "Together with 1st women submariners, POTUS &amp; FLOTUS @whitehouse to honor the fallen &amp; recognize #MemorialDay http:\/\/t.co\/n3AMmEdo",
    "id" : 207198706703925248,
    "created_at" : "2012-05-28 19:56:35 +0000",
    "user" : {
      "name" : "SECNAV Ray Mabus",
      "screen_name" : "SECNAV",
      "protected" : false,
      "id_str" : "117821354",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000498025894\/4c601432c150014970480c27c4d350f3_normal.jpeg",
      "id" : 117821354,
      "verified" : true
    }
  },
  "id" : 207218743670091779,
  "created_at" : "2012-05-28 21:16:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207180871340539905",
  "text" : "RT @WHLive: President Obama: \"Because of the hard lessons of Vietnam, because of you, America is even stronger than before\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "207180825681330177",
    "text" : "President Obama: \"Because of the hard lessons of Vietnam, because of you, America is even stronger than before\"",
    "id" : 207180825681330177,
    "created_at" : "2012-05-28 18:45:32 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 207180871340539905,
  "created_at" : "2012-05-28 18:45:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 3, 13 ],
      "id_str" : "9624742",
      "id" : 9624742
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HonorTheFallen",
      "indices" : [ 15, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "207178457103343616",
  "text" : "RT @StateDept: #HonorTheFallen: Pay tribute to U.S. men and women who died during military service by observing a minute of silence at 3 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HonorTheFallen",
        "indices" : [ 0, 15 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "207177736609992706",
    "text" : "#HonorTheFallen: Pay tribute to U.S. men and women who died during military service by observing a minute of silence at 3 p.m. local time.",
    "id" : 207177736609992706,
    "created_at" : "2012-05-28 18:33:16 +0000",
    "user" : {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "protected" : false,
      "id_str" : "9624742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724612605185282048\/1rEfkXDZ_normal.jpg",
      "id" : 9624742,
      "verified" : true
    }
  },
  "id" : 207178457103343616,
  "created_at" : "2012-05-28 18:36:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Vietnam",
      "indices" : [ 66, 74 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/u95tzH8r",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "207175757674446851",
  "text" : "Watch live: President Obama speaks at the 50th Anniversary of the #Vietnam War Commemoration Ceremony: http:\/\/t.co\/u95tzH8r",
  "id" : 207175757674446851,
  "created_at" : "2012-05-28 18:25:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/u95tzH8r",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "207166972750868480",
  "text" : "Watch live @ 1:50ET: President Obama speaks at the 50th Anniversary of the Vietnam War Commemoration Ceremony: http:\/\/t.co\/u95tzH8r",
  "id" : 207166972750868480,
  "created_at" : "2012-05-28 17:50:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Arlington Cemetery",
      "screen_name" : "ArlingtonNatl",
      "indices" : [ 86, 100 ],
      "id_str" : "102455692",
      "id" : 102455692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/g5icuVZL",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "207134604937793539",
  "text" : "RT @WHLive: Watch live @ 11:20ET: President Obama speaks at the Memorial Amphitheater @arlingtonnatl: http:\/\/t.co\/g5icuVZL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Arlington Cemetery",
        "screen_name" : "ArlingtonNatl",
        "indices" : [ 74, 88 ],
        "id_str" : "102455692",
        "id" : 102455692
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 110 ],
        "url" : "http:\/\/t.co\/g5icuVZL",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "207129260421431299",
    "text" : "Watch live @ 11:20ET: President Obama speaks at the Memorial Amphitheater @arlingtonnatl: http:\/\/t.co\/g5icuVZL",
    "id" : 207129260421431299,
    "created_at" : "2012-05-28 15:20:38 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 207134604937793539,
  "created_at" : "2012-05-28 15:41:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MemorialDay",
      "indices" : [ 108, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 122, 142 ],
      "url" : "http:\/\/t.co\/bCgYoyLU",
      "expanded_url" : "http:\/\/ow.ly\/bblhA",
      "display_url" : "ow.ly\/bblhA"
    } ]
  },
  "geo" : { },
  "id_str" : "206863770306359296",
  "text" : "\"We come together as Americans to let these families &amp; veterans know that they are not alone\" -Obama on #MemorialDay: http:\/\/t.co\/bCgYoyLU",
  "id" : 206863770306359296,
  "created_at" : "2012-05-27 21:45:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/206743002025164800\/photo\/1",
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/OJM1SAKN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/At5_qjwCAAAp4hF.jpg",
      "id_str" : "206743002033553408",
      "id" : 206743002033553408,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/At5_qjwCAAAp4hF.jpg",
      "sizes" : [ {
        "h" : 420,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 716,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 716,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 238,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/OJM1SAKN"
    } ],
    "hashtags" : [ {
      "text" : "RollingThunder",
      "indices" : [ 32, 47 ]
    }, {
      "text" : "Veterans",
      "indices" : [ 91, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206743002025164800",
  "text" : "Photo: President Obama welcomes #RollingThunder to the WH. On Mon, he'll visit the Vietnam #Veterans Memorial Wall: http:\/\/t.co\/OJM1SAKN",
  "id" : 206743002025164800,
  "created_at" : "2012-05-27 13:45:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MemorialDay",
      "indices" : [ 113, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 127, 147 ],
      "url" : "http:\/\/t.co\/DPJu4gV3",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/the-press-office\/2012\/05\/25\/presidential-proclamation-prayer-peace-memorial-day-2012",
      "display_url" : "whitehouse.gov\/the-press-offi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "206514200690966528",
  "text" : "\"Our Nation endures &amp; thrives because of the devotion of our men &amp; women in uniform\" -President Obama on #MemorialDay: http:\/\/t.co\/DPJu4gV3",
  "id" : 206514200690966528,
  "created_at" : "2012-05-26 22:36:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US National Archives",
      "screen_name" : "USNatArchives",
      "indices" : [ 51, 65 ],
      "id_str" : "101802390",
      "id" : 101802390
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/206450190452920322\/photo\/1",
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/DmulgGbE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/At11WrpCEAApk-Y.jpg",
      "id_str" : "206450190461308928",
      "id" : 206450190461308928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/At11WrpCEAApk-Y.jpg",
      "sizes" : [ {
        "h" : 269,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 811,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 475,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1622,
        "resize" : "fit",
        "w" : 2048
      } ],
      "display_url" : "pic.twitter.com\/DmulgGbE"
    } ],
    "hashtags" : [ {
      "text" : "MemorialDay",
      "indices" : [ 34, 46 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/6B8yJtPe",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2012\/05\/25\/photo-gallery-thirteen-presidents-mark-memorial-day",
      "display_url" : "whitehouse.gov\/blog\/2012\/05\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "206450190452920322",
  "text" : "Photo Gallery: 13 Presidents mark #MemorialDay via @USNatArchives: http:\/\/t.co\/6B8yJtPe Address by Hoover in 1931: http:\/\/t.co\/DmulgGbE",
  "id" : 206450190452920322,
  "created_at" : "2012-05-26 18:22:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MemorialDay",
      "indices" : [ 46, 58 ]
    }, {
      "text" : "HonorTheFallen",
      "indices" : [ 88, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/ezUDAlbS",
      "expanded_url" : "http:\/\/youtu.be\/iDpOMv_kQqQ",
      "display_url" : "youtu.be\/iDpOMv_kQqQ"
    } ]
  },
  "geo" : { },
  "id_str" : "206380909451165698",
  "text" : "President Obama: Honor our fallen heroes this #MemorialDay. Watch: http:\/\/t.co\/ezUDAlbS #HonorTheFallen",
  "id" : 206380909451165698,
  "created_at" : "2012-05-26 13:46:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "TAPS4America",
      "screen_name" : "Taps4America",
      "indices" : [ 74, 87 ],
      "id_str" : "735332516375203845",
      "id" : 735332516375203845
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/2oCK2uQ9",
      "expanded_url" : "http:\/\/1.usa.gov\/KMEQMJ",
      "display_url" : "1.usa.gov\/KMEQMJ"
    } ]
  },
  "geo" : { },
  "id_str" : "206152331824340993",
  "text" : "RT @VP: Read Dr. B\u2019s blog post, \u201CAmerica Remembers,\u201D http:\/\/t.co\/2oCK2uQ9 @TAPS4America",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "TAPS4America",
        "screen_name" : "Taps4America",
        "indices" : [ 66, 79 ],
        "id_str" : "735332516375203845",
        "id" : 735332516375203845
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 65 ],
        "url" : "http:\/\/t.co\/2oCK2uQ9",
        "expanded_url" : "http:\/\/1.usa.gov\/KMEQMJ",
        "display_url" : "1.usa.gov\/KMEQMJ"
      } ]
    },
    "geo" : { },
    "id_str" : "206137716973375490",
    "text" : "Read Dr. B\u2019s blog post, \u201CAmerica Remembers,\u201D http:\/\/t.co\/2oCK2uQ9 @TAPS4America",
    "id" : 206137716973375490,
    "created_at" : "2012-05-25 21:40:36 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 206152331824340993,
  "created_at" : "2012-05-25 22:38:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "jearnest44",
      "indices" : [ 3, 14 ],
      "id_str" : "369238541",
      "id" : 369238541
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/xgiJSf7h",
      "expanded_url" : "http:\/\/www.flickr.com\/photos\/whitehouse\/7269020826\/in\/photostream",
      "display_url" : "flickr.com\/photos\/whiteho\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "206142932724629504",
  "text" : "RT @jearnest44: NEW PHOTO: POTUS welcomes Rolling Thunder to the WH today. http:\/\/t.co\/xgiJSf7h  On Mon, he'll visit the Vietnam Veteran ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 79 ],
        "url" : "http:\/\/t.co\/xgiJSf7h",
        "expanded_url" : "http:\/\/www.flickr.com\/photos\/whitehouse\/7269020826\/in\/photostream",
        "display_url" : "flickr.com\/photos\/whiteho\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "206136636835250176",
    "text" : "NEW PHOTO: POTUS welcomes Rolling Thunder to the WH today. http:\/\/t.co\/xgiJSf7h  On Mon, he'll visit the Vietnam Veterans Memorial Wall.",
    "id" : 206136636835250176,
    "created_at" : "2012-05-25 21:36:18 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "jearnest44",
      "protected" : false,
      "id_str" : "369238541",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1769108407\/Twitter_profile_photo_real_normal.JPG",
      "id" : 369238541,
      "verified" : true
    }
  },
  "id" : 206142932724629504,
  "created_at" : "2012-05-25 22:01:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Dept of Defense",
      "screen_name" : "DeptofDefense",
      "indices" : [ 3, 17 ],
      "id_str" : "66369181",
      "id" : 66369181
    }, {
      "name" : "U.S. Army",
      "screen_name" : "USArmy",
      "indices" : [ 76, 83 ],
      "id_str" : "8775672",
      "id" : 8775672
    }, {
      "name" : "U.S. Navy",
      "screen_name" : "USNavy",
      "indices" : [ 85, 92 ],
      "id_str" : "54885400",
      "id" : 54885400
    }, {
      "name" : "U.S. Air Force",
      "screen_name" : "usairforce",
      "indices" : [ 94, 105 ],
      "id_str" : "19611483",
      "id" : 19611483
    }, {
      "name" : "U.S. Marines",
      "screen_name" : "USMC",
      "indices" : [ 107, 112 ],
      "id_str" : "10126672",
      "id" : 10126672
    }, {
      "name" : "U.S. Coast Guard",
      "screen_name" : "USCG",
      "indices" : [ 114, 119 ],
      "id_str" : "15113565",
      "id" : 15113565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206130207416004609",
  "text" : "RT @DeptofDefense: This Memorial Day weekend, follow the military services: @USArmy, @USNavy, @USAirForce, @USMC, @USCG and don't forget ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "U.S. Army",
        "screen_name" : "USArmy",
        "indices" : [ 57, 64 ],
        "id_str" : "8775672",
        "id" : 8775672
      }, {
        "name" : "U.S. Navy",
        "screen_name" : "USNavy",
        "indices" : [ 66, 73 ],
        "id_str" : "54885400",
        "id" : 54885400
      }, {
        "name" : "U.S. Air Force",
        "screen_name" : "usairforce",
        "indices" : [ 75, 86 ],
        "id_str" : "19611483",
        "id" : 19611483
      }, {
        "name" : "U.S. Marines",
        "screen_name" : "USMC",
        "indices" : [ 88, 93 ],
        "id_str" : "10126672",
        "id" : 10126672
      }, {
        "name" : "U.S. Coast Guard",
        "screen_name" : "USCG",
        "indices" : [ 95, 100 ],
        "id_str" : "15113565",
        "id" : 15113565
      }, {
        "name" : "National Guard",
        "screen_name" : "USNationalGuard",
        "indices" : [ 118, 134 ],
        "id_str" : "31310158",
        "id" : 31310158
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FF",
        "indices" : [ 135, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "206000493930094592",
    "text" : "This Memorial Day weekend, follow the military services: @USArmy, @USNavy, @USAirForce, @USMC, @USCG and don't forget @USNationalGuard #FF",
    "id" : 206000493930094592,
    "created_at" : "2012-05-25 12:35:19 +0000",
    "user" : {
      "name" : "U.S. Dept of Defense",
      "screen_name" : "DeptofDefense",
      "protected" : false,
      "id_str" : "66369181",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/533350546027995137\/b84VANoF_normal.png",
      "id" : 66369181,
      "verified" : true
    }
  },
  "id" : 206130207416004609,
  "created_at" : "2012-05-25 21:10:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/206113568482000896\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/e8gFfvtS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AtxDMtFCAAAjC0z.jpg",
      "id_str" : "206113568490389504",
      "id" : 206113568490389504,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AtxDMtFCAAAjC0z.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/e8gFfvtS"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206113568482000896",
  "text" : "Photo of the Day: President Obama greets a crowd (including this cute kid) at the airport following his arrival in Iowa http:\/\/t.co\/e8gFfvtS",
  "id" : 206113568482000896,
  "created_at" : "2012-05-25 20:04:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/b9aLaCaI",
      "expanded_url" : "http:\/\/youtu.be\/H0FH0LzgHYA",
      "display_url" : "youtu.be\/H0FH0LzgHYA"
    } ]
  },
  "geo" : { },
  "id_str" : "206091834299121666",
  "text" : "Go behind the scenes with President Obama in the latest West Wing Week: \u201CWe Are Not Meant to Walk This Road Alone\u201D   http:\/\/t.co\/b9aLaCaI",
  "id" : 206091834299121666,
  "created_at" : "2012-05-25 18:38:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/206081489832656897\/photo\/1",
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/q7ryazhe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AtwmBeyCQAAuMpQ.jpg",
      "id_str" : "206081489836851200",
      "id" : 206081489836851200,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AtwmBeyCQAAuMpQ.jpg",
      "sizes" : [ {
        "h" : 336,
        "resize" : "fit",
        "w" : 504
      }, {
        "h" : 336,
        "resize" : "fit",
        "w" : 504
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 336,
        "resize" : "fit",
        "w" : 504
      } ],
      "display_url" : "pic.twitter.com\/q7ryazhe"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/XMh5z8pP",
      "expanded_url" : "http:\/\/wh.gov\/LXX",
      "display_url" : "wh.gov\/LXX"
    } ]
  },
  "geo" : { },
  "id_str" : "206081489832656897",
  "text" : "Photo Gallery: 13 Presidents mark Memorial Day: http:\/\/t.co\/XMh5z8pP President Franklin Delano Roosevelt from 1942: http:\/\/t.co\/q7ryazhe",
  "id" : 206081489832656897,
  "created_at" : "2012-05-25 17:57:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Dragon",
      "indices" : [ 37, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206065178301841408",
  "text" : "RT @whitehouseostp: History is made: #Dragon Spacecraft has Berthed with the International Space Station. Statement from the White House ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Dragon",
        "indices" : [ 17, 24 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/46vb3PSM",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2012\/05\/25\/dragon-spacecraft-has-berthed-international-space-station",
        "display_url" : "whitehouse.gov\/blog\/2012\/05\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "206064257958297601",
    "text" : "History is made: #Dragon Spacecraft has Berthed with the International Space Station. Statement from the White House: http:\/\/t.co\/46vb3PSM",
    "id" : 206064257958297601,
    "created_at" : "2012-05-25 16:48:42 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 206065178301841408,
  "created_at" : "2012-05-25 16:52:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    }, {
      "name" : "SpaceX",
      "screen_name" : "SpaceX",
      "indices" : [ 35, 42 ],
      "id_str" : "34743251",
      "id" : 34743251
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Dragon",
      "indices" : [ 17, 24 ]
    }, {
      "text" : "ISS",
      "indices" : [ 79, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "206063141191286784",
  "text" : "RT @NASA: Why is #Dragon trending? @SpaceX became 1st private company to reach #ISS. A new era for U.S. &amp; commercial space! http:\/\/t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.exacttarget.com\/social\" rel=\"nofollow\"\u003ESocialEngage\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "SpaceX",
        "screen_name" : "SpaceX",
        "indices" : [ 25, 32 ],
        "id_str" : "34743251",
        "id" : 34743251
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Dragon",
        "indices" : [ 7, 14 ]
      }, {
        "text" : "ISS",
        "indices" : [ 69, 73 ]
      } ],
      "urls" : [ {
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/H8b2wBsY",
        "expanded_url" : "http:\/\/go.nasa.gov\/J3iDIl",
        "display_url" : "go.nasa.gov\/J3iDIl"
      } ]
    },
    "geo" : { },
    "id_str" : "206035147131338754",
    "text" : "Why is #Dragon trending? @SpaceX became 1st private company to reach #ISS. A new era for U.S. &amp; commercial space! http:\/\/t.co\/H8b2wBsY",
    "id" : 206035147131338754,
    "created_at" : "2012-05-25 14:53:01 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 206063141191286784,
  "created_at" : "2012-05-25 16:44:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jackie Hyland",
      "screen_name" : "jackie_hyland",
      "indices" : [ 3, 17 ],
      "id_str" : "22114213",
      "id" : 22114213
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 102, 113 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Innovation",
      "indices" : [ 42, 53 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/OFRnDhCV",
      "expanded_url" : "http:\/\/1.usa.gov\/KGJ3iH",
      "display_url" : "1.usa.gov\/KGJ3iH"
    } ]
  },
  "geo" : { },
  "id_str" : "206030266282676224",
  "text" : "RT @jackie_hyland: Apply! -- Presidential #Innovation Fellows | The White House: http:\/\/t.co\/OFRnDhCV @whitehouse",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 83, 94 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Innovation",
        "indices" : [ 23, 34 ]
      } ],
      "urls" : [ {
        "indices" : [ 62, 82 ],
        "url" : "http:\/\/t.co\/OFRnDhCV",
        "expanded_url" : "http:\/\/1.usa.gov\/KGJ3iH",
        "display_url" : "1.usa.gov\/KGJ3iH"
      } ]
    },
    "geo" : { },
    "id_str" : "206029498838290432",
    "text" : "Apply! -- Presidential #Innovation Fellows | The White House: http:\/\/t.co\/OFRnDhCV @whitehouse",
    "id" : 206029498838290432,
    "created_at" : "2012-05-25 14:30:35 +0000",
    "user" : {
      "name" : "Jackie Hyland",
      "screen_name" : "jackie_hyland",
      "protected" : false,
      "id_str" : "22114213",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/784214203695452161\/crkgnFX0_normal.jpg",
      "id" : 22114213,
      "verified" : false
    }
  },
  "id" : 206030266282676224,
  "created_at" : "2012-05-25 14:33:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/205846823527657472\/photo\/1",
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/tK0i2DrG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AttQmGsCMAIk36e.jpg",
      "id_str" : "205846823536046082",
      "id" : 205846823536046082,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AttQmGsCMAIk36e.jpg",
      "sizes" : [ {
        "h" : 276,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 487,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 487,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 487,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/tK0i2DrG"
    } ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 43, 50 ]
    }, {
      "text" : "CongressToDoList",
      "indices" : [ 58, 75 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/RoUlS9kQ",
      "expanded_url" : "http:\/\/wh.gov\/F9Z",
      "display_url" : "wh.gov\/F9Z"
    } ]
  },
  "geo" : { },
  "id_str" : "205846823527657472",
  "text" : "President Obama was on Twitter today for a #WHChat on the #CongressToDoList.  Read all about it: http:\/\/t.co\/RoUlS9kQ http:\/\/t.co\/tK0i2DrG",
  "id" : 205846823527657472,
  "created_at" : "2012-05-25 02:24:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kori Schulman",
      "screen_name" : "ks44",
      "indices" : [ 3, 8 ],
      "id_str" : "369246180",
      "id" : 369246180
    }, {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 87, 95 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CongressToDoList",
      "indices" : [ 66, 83 ]
    }, {
      "text" : "whchat",
      "indices" : [ 101, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/nv2Aly3Z",
      "expanded_url" : "http:\/\/sfy.co\/100K",
      "display_url" : "sfy.co\/100K"
    } ]
  },
  "geo" : { },
  "id_str" : "205792965954781184",
  "text" : "RT @ks44: President Obama just finished answering questions about #CongressToDoList on @twitter. See #whchat here: http:\/\/t.co\/nv2Aly3Z  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Twitter",
        "screen_name" : "twitter",
        "indices" : [ 77, 85 ],
        "id_str" : "783214",
        "id" : 783214
      }, {
        "name" : "Storify",
        "screen_name" : "Storify",
        "indices" : [ 130, 138 ],
        "id_str" : "17814938",
        "id" : 17814938
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CongressToDoList",
        "indices" : [ 56, 73 ]
      }, {
        "text" : "whchat",
        "indices" : [ 91, 98 ]
      } ],
      "urls" : [ {
        "indices" : [ 105, 125 ],
        "url" : "http:\/\/t.co\/nv2Aly3Z",
        "expanded_url" : "http:\/\/sfy.co\/100K",
        "display_url" : "sfy.co\/100K"
      } ]
    },
    "geo" : { },
    "id_str" : "205791672251056128",
    "text" : "President Obama just finished answering questions about #CongressToDoList on @twitter. See #whchat here: http:\/\/t.co\/nv2Aly3Z via @Storify",
    "id" : 205791672251056128,
    "created_at" : "2012-05-24 22:45:32 +0000",
    "user" : {
      "name" : "Kori Schulman",
      "screen_name" : "ks44",
      "protected" : false,
      "id_str" : "369246180",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/667876153793859584\/DV7HzP-1_normal.jpg",
      "id" : 369246180,
      "verified" : true
    }
  },
  "id" : 205792965954781184,
  "created_at" : "2012-05-24 22:50:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whchat",
      "indices" : [ 60, 67 ]
    }, {
      "text" : "CongressToDoList",
      "indices" : [ 74, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/PngeoD3r",
      "expanded_url" : "http:\/\/sfy.co\/100K",
      "display_url" : "sfy.co\/100K"
    } ]
  },
  "geo" : { },
  "id_str" : "205791388078571520",
  "text" : "Missed the Q&amp;A with President Obama? Check out the full #whchat about #CongressToDoList here: http:\/\/t.co\/PngeoD3r",
  "id" : 205791388078571520,
  "created_at" : "2012-05-24 22:44:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205787477921894401",
  "text" : "off to des moines.  thx for questions - keep em coming.  remember we're not D's or R's but americans first! -bo",
  "id" : 205787477921894401,
  "created_at" : "2012-05-24 22:28:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam",
      "screen_name" : "mycroft16",
      "indices" : [ 1, 11 ],
      "id_str" : "16829834",
      "id" : 16829834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "205734093286150145",
  "geo" : { },
  "id_str" : "205787114854547457",
  "in_reply_to_user_id" : 16829834,
  "text" : ".@mycroft16 I've always said best ideas don't come out of DC. Citizens need to keep pushing  best ideas &amp; put country ahead of politics. -bo",
  "id" : 205787114854547457,
  "in_reply_to_status_id" : 205734093286150145,
  "created_at" : "2012-05-24 22:27:26 +0000",
  "in_reply_to_screen_name" : "mycroft16",
  "in_reply_to_user_id_str" : "16829834",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam",
      "screen_name" : "mycroft16",
      "indices" : [ 3, 13 ],
      "id_str" : "16829834",
      "id" : 16829834
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205786478796746755",
  "text" : "RT @mycroft16: What is the plan to make both sides see that a cooperative compromise is the best way forward on ALL of these to-dos? #WHChat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"erased_49624\" rel=\"nofollow\"\u003Eerased_49624\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 118, 125 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "205734093286150145",
    "text" : "What is the plan to make both sides see that a cooperative compromise is the best way forward on ALL of these to-dos? #WHChat",
    "id" : 205734093286150145,
    "created_at" : "2012-05-24 18:56:44 +0000",
    "user" : {
      "name" : "Adam",
      "screen_name" : "mycroft16",
      "protected" : false,
      "id_str" : "16829834",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/627780698032619520\/OTMHNRK7_normal.jpg",
      "id" : 16829834,
      "verified" : false
    }
  },
  "id" : 205786478796746755,
  "created_at" : "2012-05-24 22:24:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Theresa Keel",
      "screen_name" : "tkeel",
      "indices" : [ 1, 7 ],
      "id_str" : "27909697",
      "id" : 27909697
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "205773154155630592",
  "geo" : { },
  "id_str" : "205786270763466754",
  "in_reply_to_user_id" : 27909697,
  "text" : ".@tkeel ... Already eliminated or revised 100's of regs, expect billions in savings, &amp; need Congress to give me addt'l re-org authority. -bo",
  "id" : 205786270763466754,
  "in_reply_to_status_id" : 205773154155630592,
  "created_at" : "2012-05-24 22:24:04 +0000",
  "in_reply_to_screen_name" : "tkeel",
  "in_reply_to_user_id_str" : "27909697",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Theresa Keel",
      "screen_name" : "tkeel",
      "indices" : [ 1, 7 ],
      "id_str" : "27909697",
      "id" : 27909697
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "205773154155630592",
  "geo" : { },
  "id_str" : "205785833024925698",
  "in_reply_to_user_id" : 27909697,
  "text" : ".@tkeel instructed every fed agency to review all regulations affecting biz &amp; get rid of those that don't work. (cont)",
  "id" : 205785833024925698,
  "in_reply_to_status_id" : 205773154155630592,
  "created_at" : "2012-05-24 22:22:20 +0000",
  "in_reply_to_screen_name" : "tkeel",
  "in_reply_to_user_id_str" : "27909697",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Theresa Keel",
      "screen_name" : "tkeel",
      "indices" : [ 3, 9 ],
      "id_str" : "27909697",
      "id" : 27909697
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 11, 18 ]
    }, {
      "text" : "smallbiz",
      "indices" : [ 61, 70 ]
    }, {
      "text" : "LNYHBT",
      "indices" : [ 79, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205785488047620096",
  "text" : "RT @tkeel: #WHChat What will you deregulate to make owning a #smallbiz easier? #LNYHBT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.handmark.com\" rel=\"nofollow\"\u003ETweetCaster for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 0, 7 ]
      }, {
        "text" : "smallbiz",
        "indices" : [ 50, 59 ]
      }, {
        "text" : "LNYHBT",
        "indices" : [ 68, 75 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "205773154155630592",
    "text" : "#WHChat What will you deregulate to make owning a #smallbiz easier? #LNYHBT",
    "id" : 205773154155630592,
    "created_at" : "2012-05-24 21:31:57 +0000",
    "user" : {
      "name" : "Theresa Keel",
      "screen_name" : "tkeel",
      "protected" : false,
      "id_str" : "27909697",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2210528821\/image_normal.jpg",
      "id" : 27909697,
      "verified" : false
    }
  },
  "id" : 205785488047620096,
  "created_at" : "2012-05-24 22:20:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 118, 135 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "205731970653765633",
  "geo" : { },
  "id_str" : "205785285127180288",
  "in_reply_to_user_id" : 28639317,
  "text" : ".@mlslawter75 R's say they're willing to go along, but not moving fast enough. Need to keep the pressure on. Tell 'em #DontDoubleMyRate -bo",
  "id" : 205785285127180288,
  "in_reply_to_status_id" : 205731970653765633,
  "created_at" : "2012-05-24 22:20:09 +0000",
  "in_reply_to_screen_name" : "sahdx3",
  "in_reply_to_user_id_str" : "28639317",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 17, 28 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 71, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205784984940855297",
  "text" : "RT @mlslawter75: @whitehouse: Where is congress on student loan rates? #WHChat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 54, 61 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "205731970653765633",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse: Where is congress on student loan rates? #WHChat",
    "id" : 205731970653765633,
    "created_at" : "2012-05-24 18:48:18 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "SAHDX3",
      "screen_name" : "sahdx3",
      "protected" : false,
      "id_str" : "28639317",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796358312610631681\/24fJXZ4u_normal.jpg",
      "id" : 28639317,
      "verified" : false
    }
  },
  "id" : 205784984940855297,
  "created_at" : "2012-05-24 22:18:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "joe warner",
      "screen_name" : "jwarner180",
      "indices" : [ 1, 12 ],
      "id_str" : "98028995",
      "id" : 98028995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "205729546278928384",
  "geo" : { },
  "id_str" : "205784676399448064",
  "in_reply_to_user_id" : 98028995,
  "text" : ".@jwarner180 bio fuels, wind , solar  all getting cheaper each year &amp; oil getting more expensive. Why we need all-of-the-above strategy. -bo",
  "id" : 205784676399448064,
  "in_reply_to_status_id" : 205729546278928384,
  "created_at" : "2012-05-24 22:17:44 +0000",
  "in_reply_to_screen_name" : "jwarner180",
  "in_reply_to_user_id_str" : "98028995",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "joe warner",
      "screen_name" : "jwarner180",
      "indices" : [ 3, 14 ],
      "id_str" : "98028995",
      "id" : 98028995
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 16, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205784235452280832",
  "text" : "RT @jwarner180: #WHChat Fossil fuels are much much much cheaper and our economy is based on cheap energy. Why push Algae?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 0, 7 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "205729546278928384",
    "text" : "#WHChat Fossil fuels are much much much cheaper and our economy is based on cheap energy. Why push Algae?",
    "id" : 205729546278928384,
    "created_at" : "2012-05-24 18:38:40 +0000",
    "user" : {
      "name" : "joe warner",
      "screen_name" : "jwarner180",
      "protected" : false,
      "id_str" : "98028995",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/545737730919890944\/OfIzB0KU_normal.jpeg",
      "id" : 98028995,
      "verified" : false
    }
  },
  "id" : 205784235452280832,
  "created_at" : "2012-05-24 22:15:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mix n' Munch",
      "screen_name" : "mixnmunch",
      "indices" : [ 1, 11 ],
      "id_str" : "172153615",
      "id" : 172153615
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CongressToDoList",
      "indices" : [ 31, 48 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "205734982449238017",
  "geo" : { },
  "id_str" : "205784163884871680",
  "in_reply_to_user_id" : 172153615,
  "text" : ".@mixnmunch ... &amp; items on #CongressToDoList puts more $ in folks pockets, which means more customers for you. -bo",
  "id" : 205784163884871680,
  "in_reply_to_status_id" : 205734982449238017,
  "created_at" : "2012-05-24 22:15:42 +0000",
  "in_reply_to_screen_name" : "mixnmunch",
  "in_reply_to_user_id_str" : "172153615",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mix n' Munch",
      "screen_name" : "mixnmunch",
      "indices" : [ 1, 11 ],
      "id_str" : "172153615",
      "id" : 172153615
    }, {
      "name" : "SBA",
      "screen_name" : "SBAgov",
      "indices" : [ 17, 24 ],
      "id_str" : "153149305",
      "id" : 153149305
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "205734982449238017",
  "geo" : { },
  "id_str" : "205784106322247680",
  "in_reply_to_user_id" : 172153615,
  "text" : ".@mixnmunch push @SBAgov to provide more credits to small biz, &amp; pushing big banks to do the right thing ... (cont)",
  "id" : 205784106322247680,
  "in_reply_to_status_id" : 205734982449238017,
  "created_at" : "2012-05-24 22:15:28 +0000",
  "in_reply_to_screen_name" : "mixnmunch",
  "in_reply_to_user_id_str" : "172153615",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/petesouza\/status\/205782909595029505\/photo\/1",
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/rQOyuxL3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AtsWd0uCEAAee91.jpg",
      "id_str" : "205782909599223808",
      "id" : 205782909599223808,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AtsWd0uCEAAee91.jpg",
      "sizes" : [ {
        "h" : 276,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 487,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 831,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 831,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/rQOyuxL3"
    } ],
    "hashtags" : [ {
      "text" : "whchat",
      "indices" : [ 73, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205783735629643776",
  "text" : "RT @petesouza: Photo of POTUS answering questions on twitter now in Iowa #whchat http:\/\/t.co\/rQOyuxL3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/petesouza\/status\/205782909595029505\/photo\/1",
        "indices" : [ 66, 86 ],
        "url" : "http:\/\/t.co\/rQOyuxL3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AtsWd0uCEAAee91.jpg",
        "id_str" : "205782909599223808",
        "id" : 205782909599223808,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AtsWd0uCEAAee91.jpg",
        "sizes" : [ {
          "h" : 276,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 487,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 831,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 831,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/rQOyuxL3"
      } ],
      "hashtags" : [ {
        "text" : "whchat",
        "indices" : [ 58, 65 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "205782909595029505",
    "text" : "Photo of POTUS answering questions on twitter now in Iowa #whchat http:\/\/t.co\/rQOyuxL3",
    "id" : 205782909595029505,
    "created_at" : "2012-05-24 22:10:44 +0000",
    "user" : {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "protected" : false,
      "id_str" : "18215973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771916869808844800\/7d_poH48_normal.jpg",
      "id" : 18215973,
      "verified" : true
    }
  },
  "id" : 205783735629643776,
  "created_at" : "2012-05-24 22:14:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mix n' Munch",
      "screen_name" : "mixnmunch",
      "indices" : [ 1, 11 ],
      "id_str" : "172153615",
      "id" : 172153615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "205734982449238017",
  "geo" : { },
  "id_str" : "205783648841109504",
  "in_reply_to_user_id" : 172153615,
  "text" : ".@mixnmunch tax credits for small biz that hire new workers or increase pay in addition to 18 tax credits i already signed into law (cont)",
  "id" : 205783648841109504,
  "in_reply_to_status_id" : 205734982449238017,
  "created_at" : "2012-05-24 22:13:39 +0000",
  "in_reply_to_screen_name" : "mixnmunch",
  "in_reply_to_user_id_str" : "172153615",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mix n' Munch",
      "screen_name" : "mixnmunch",
      "indices" : [ 3, 13 ],
      "id_str" : "172153615",
      "id" : 172153615
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 15, 26 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whchat",
      "indices" : [ 27, 34 ]
    }, {
      "text" : "smallbiz",
      "indices" : [ 51, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205783415230963712",
  "text" : "RT @mixnmunch: @whitehouse #whchat We &lt;3 bein a #smallbiz &amp; employing the peeps in R community. What plans do u have to keep us & ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whchat",
        "indices" : [ 12, 19 ]
      }, {
        "text" : "smallbiz",
        "indices" : [ 36, 45 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "205728539239129088",
    "geo" : { },
    "id_str" : "205734982449238017",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse #whchat We &lt;3 bein a #smallbiz &amp; employing the peeps in R community. What plans do u have to keep us &amp; our fellow smlbiz afloat?",
    "id" : 205734982449238017,
    "in_reply_to_status_id" : 205728539239129088,
    "created_at" : "2012-05-24 19:00:16 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Mix n' Munch",
      "screen_name" : "mixnmunch",
      "protected" : false,
      "id_str" : "172153615",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/672162411114180608\/xbEuyZL2_normal.jpg",
      "id" : 172153615,
      "verified" : false
    }
  },
  "id" : 205783415230963712,
  "created_at" : "2012-05-24 22:12:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melissa T",
      "screen_name" : "Augustmuser",
      "indices" : [ 1, 13 ],
      "id_str" : "345476277",
      "id" : 345476277
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CongressToDoList",
      "indices" : [ 89, 106 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "205748836734484480",
  "geo" : { },
  "id_str" : "205783251179147264",
  "in_reply_to_user_id" : 345476277,
  "text" : ".@Augustmuser I refuse to let mkt hit bottom.  Refi could save folks $3k each mo. Its on #CongressToDoList. Get it done - bo",
  "id" : 205783251179147264,
  "in_reply_to_status_id" : 205748836734484480,
  "created_at" : "2012-05-24 22:12:05 +0000",
  "in_reply_to_screen_name" : "Augustmuser",
  "in_reply_to_user_id_str" : "345476277",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melissa T",
      "screen_name" : "Augustmuser",
      "indices" : [ 3, 15 ],
      "id_str" : "345476277",
      "id" : 345476277
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 17, 28 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 29, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205783224906035202",
  "text" : "RT @Augustmuser: @whitehouse #WHChat what about mortgage re-finance options for homeowners trapped by underwater home prices?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 12, 19 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "205741671701422081",
    "geo" : { },
    "id_str" : "205748836734484480",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse #WHChat what about mortgage re-finance options for homeowners trapped by underwater home prices?",
    "id" : 205748836734484480,
    "in_reply_to_status_id" : 205741671701422081,
    "created_at" : "2012-05-24 19:55:19 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Melissa T",
      "screen_name" : "Augustmuser",
      "protected" : false,
      "id_str" : "345476277",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2255728817\/421016_248808605208077_160411127381159_567124_1023298615_n_normal.jpg",
      "id" : 345476277,
      "verified" : false
    }
  },
  "id" : 205783224906035202,
  "created_at" : "2012-05-24 22:11:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexandria Sturtz",
      "screen_name" : "asturtz",
      "indices" : [ 1, 9 ],
      "id_str" : "84164391",
      "id" : 84164391
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "205713694066356224",
  "geo" : { },
  "id_str" : "205782902280159233",
  "in_reply_to_user_id" : 84164391,
  "text" : ".@asturtz all of the above energy strategy; increase dom. oil &amp; gas. increase energy efficiency. 2x clean energy. 2x car fuel eff. -bo",
  "id" : 205782902280159233,
  "in_reply_to_status_id" : 205713694066356224,
  "created_at" : "2012-05-24 22:10:41 +0000",
  "in_reply_to_screen_name" : "asturtz",
  "in_reply_to_user_id_str" : "84164391",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexandria Sturtz",
      "screen_name" : "asturtz",
      "indices" : [ 3, 11 ],
      "id_str" : "84164391",
      "id" : 84164391
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 77, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205782868197249024",
  "text" : "RT @asturtz: What are we doing to curb, better yet avoid, dependency on oil? #WHChat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 64, 71 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "205713694066356224",
    "text" : "What are we doing to curb, better yet avoid, dependency on oil? #WHChat",
    "id" : 205713694066356224,
    "created_at" : "2012-05-24 17:35:41 +0000",
    "user" : {
      "name" : "Alexandria Sturtz",
      "screen_name" : "asturtz",
      "protected" : false,
      "id_str" : "84164391",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/778245961101430787\/a3k9Q_pq_normal.jpg",
      "id" : 84164391,
      "verified" : false
    }
  },
  "id" : 205782868197249024,
  "created_at" : "2012-05-24 22:10:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205782197775507457",
  "text" : "this is barack - let's get this started! -bo",
  "id" : 205782197775507457,
  "created_at" : "2012-05-24 22:07:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CongressToDoList",
      "indices" : [ 99, 116 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 125, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205772255966396416",
  "text" : "Let's try this: After I speak here in Iowa about clean energy jobs, I'll answer a few questions on #CongressToDoList. Ask w\/ #WHChat -bo",
  "id" : 205772255966396416,
  "created_at" : "2012-05-24 21:28:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CongressToDoList",
      "indices" : [ 26, 43 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 105, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205767593213165570",
  "text" : "Have a question about the #CongressToDoList &amp; the President's plan to grow the economy? Ask now with #WHChat",
  "id" : 205767593213165570,
  "created_at" : "2012-05-24 21:09:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CongressToDoList",
      "indices" : [ 46, 63 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 136, 143 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/u95tzH8r",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "205759332191698944",
  "text" : "Happening @ 5:15ET: President Obama speaks on #CongressToDoList &amp; clean energy in Newton, Iowa. Watch: http:\/\/t.co\/u95tzH8r Ask Qs: #WHChat",
  "id" : 205759332191698944,
  "created_at" : "2012-05-24 20:37:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CongressToDoList",
      "indices" : [ 35, 52 ]
    }, {
      "text" : "refi",
      "indices" : [ 78, 83 ]
    }, {
      "text" : "smallbiz",
      "indices" : [ 103, 112 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 128, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205741671701422081",
  "text" : "What do you want to know about the #CongressToDoList?  Have ?s about mortgage #refi or tax credits for #smallbiz?  Ask now with #WHChat",
  "id" : 205741671701422081,
  "created_at" : "2012-05-24 19:26:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CongressToDoList",
      "indices" : [ 14, 31 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 134, 141 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/Tgim0wX3",
      "expanded_url" : "http:\/\/wh.gov\/todolist",
      "display_url" : "wh.gov\/todolist"
    } ]
  },
  "geo" : { },
  "id_str" : "205730382354714624",
  "text" : "Got ?s on the #CongressToDoList &amp; the President's plan to invest in clean energy manufacturing? http:\/\/t.co\/Tgim0wX3 Ask now with #WHChat",
  "id" : 205730382354714624,
  "created_at" : "2012-05-24 18:42:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smallbiz",
      "indices" : [ 70, 79 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 94, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205728539239129088",
  "text" : "Got questions on the President's plan to invest in clean energy &amp; #smallbiz? Ask now with #WHChat",
  "id" : 205728539239129088,
  "created_at" : "2012-05-24 18:34:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/wAfLZB1O",
      "expanded_url" : "http:\/\/wh.gov\/todolist",
      "display_url" : "wh.gov\/todolist"
    } ]
  },
  "geo" : { },
  "id_str" : "205717821517348865",
  "text" : "RT @WHLive: What do you want to know about the President's to-do list for Congress to create jobs? http:\/\/t.co\/wAfLZB1O Ask your questio ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 132, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 87, 107 ],
        "url" : "http:\/\/t.co\/wAfLZB1O",
        "expanded_url" : "http:\/\/wh.gov\/todolist",
        "display_url" : "wh.gov\/todolist"
      } ]
    },
    "geo" : { },
    "id_str" : "205704464726892545",
    "text" : "What do you want to know about the President's to-do list for Congress to create jobs? http:\/\/t.co\/wAfLZB1O Ask your questions with #WHChat",
    "id" : 205704464726892545,
    "created_at" : "2012-05-24 16:59:00 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 205717821517348865,
  "created_at" : "2012-05-24 17:52:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/205692068985712640\/photo\/1",
      "indices" : [ 122, 142 ],
      "url" : "http:\/\/t.co\/SttdLCpk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AtrD2NGCMAEvHTj.jpg",
      "id_str" : "205692068994101249",
      "id" : 205692068994101249,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AtrD2NGCMAEvHTj.jpg",
      "sizes" : [ {
        "h" : 322,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 569,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 569,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 569,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/SttdLCpk"
    } ],
    "hashtags" : [ {
      "text" : "CongressToDoList",
      "indices" : [ 26, 43 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 114, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205692068985712640",
  "text" : "Have a question about the #CongressToDoList &amp; the President's plan to bring jobs back to the US? Ask now with #WHChat http:\/\/t.co\/SttdLCpk",
  "id" : 205692068985712640,
  "created_at" : "2012-05-24 16:09:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CongressToDoList",
      "indices" : [ 82, 99 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 129, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205668946882465793",
  "text" : "President Obama heads to Newton, Iowa today to talk about clean energy jobs &amp; #CongressToDoList. Got questions? Ask now with #WHChat",
  "id" : 205668946882465793,
  "created_at" : "2012-05-24 14:37:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "indices" : [ 3, 12 ],
      "id_str" : "44196397",
      "id" : 44196397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205506058653933569",
  "text" : "RT @elonmusk: The President just called to say congrats. Caller ID was blocked, so at first I thought it was a telemarketer :)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "205502360112476161",
    "text" : "The President just called to say congrats. Caller ID was blocked, so at first I thought it was a telemarketer :)",
    "id" : 205502360112476161,
    "created_at" : "2012-05-24 03:35:55 +0000",
    "user" : {
      "name" : "Elon Musk",
      "screen_name" : "elonmusk",
      "protected" : false,
      "id_str" : "44196397",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/782474226020200448\/zDo-gAo0_normal.jpg",
      "id" : 44196397,
      "verified" : true
    }
  },
  "id" : 205506058653933569,
  "created_at" : "2012-05-24 03:50:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/205461830343204864\/photo\/1",
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/jVi86FHU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AtnycjTCIAEcfM_.jpg",
      "id_str" : "205461830347399169",
      "id" : 205461830347399169,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AtnycjTCIAEcfM_.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/jVi86FHU"
    } ],
    "hashtags" : [ {
      "text" : "Joplin",
      "indices" : [ 41, 48 ]
    }, {
      "text" : "Joplin",
      "indices" : [ 76, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/Uj9aULmn",
      "expanded_url" : "http:\/\/wh.gov\/joplin",
      "display_url" : "wh.gov\/joplin"
    } ]
  },
  "geo" : { },
  "id_str" : "205461830343204864",
  "text" : "Photo of the Day: President Obama greets #Joplin High School grads. More on #Joplin 1 year later: http:\/\/t.co\/Uj9aULmn http:\/\/t.co\/jVi86FHU",
  "id" : 205461830343204864,
  "created_at" : "2012-05-24 00:54:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/WXmUAKMb",
      "expanded_url" : "http:\/\/abcnews.go.com\/blogs\/politics\/2012\/05\/air-force-academy-graduates-first-openly-gay-cadets\/",
      "display_url" : "abcnews.go.com\/blogs\/politics\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "205434368796266496",
  "text" : "RT @jesseclee44: RT if you smile when you read this story... \"Air Force Academy Graduates First Openly Gay Cadets\" http:\/\/t.co\/WXmUAKMb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 98, 118 ],
        "url" : "http:\/\/t.co\/WXmUAKMb",
        "expanded_url" : "http:\/\/abcnews.go.com\/blogs\/politics\/2012\/05\/air-force-academy-graduates-first-openly-gay-cadets\/",
        "display_url" : "abcnews.go.com\/blogs\/politics\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "205433651243134976",
    "text" : "RT if you smile when you read this story... \"Air Force Academy Graduates First Openly Gay Cadets\" http:\/\/t.co\/WXmUAKMb",
    "id" : 205433651243134976,
    "created_at" : "2012-05-23 23:02:53 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 205434368796266496,
  "created_at" : "2012-05-23 23:05:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kisstixx Lip Balm",
      "screen_name" : "Kisstixx",
      "indices" : [ 37, 46 ],
      "id_str" : "167204231",
      "id" : 167204231
    }, {
      "name" : "Fresh Diet",
      "screen_name" : "freshdiet",
      "indices" : [ 47, 57 ],
      "id_str" : "779405704922882053",
      "id" : 779405704922882053
    }, {
      "name" : "Rodgers' Puddings",
      "screen_name" : "RodgersPudding",
      "indices" : [ 58, 73 ],
      "id_str" : "126325070",
      "id" : 126325070
    }, {
      "name" : "Rustic Crust",
      "screen_name" : "RusticCrust",
      "indices" : [ 74, 86 ],
      "id_str" : "47327623",
      "id" : 47327623
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smallbiz",
      "indices" : [ 12, 21 ]
    }, {
      "text" : "SBW2012",
      "indices" : [ 108, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/RFhLlDRE",
      "expanded_url" : "http:\/\/wh.gov\/F4O",
      "display_url" : "wh.gov\/F4O"
    }, {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/sKiDWnqk",
      "expanded_url" : "http:\/\/youtu.be\/9aPPwIQOejc",
      "display_url" : "youtu.be\/9aPPwIQOejc"
    } ]
  },
  "geo" : { },
  "id_str" : "205383450105090048",
  "text" : "Congrats to #smallbiz video winners: @kisstixx @FreshDiet @RodgersPudding @RusticCrust http:\/\/t.co\/RFhLlDRE #SBW2012 http:\/\/t.co\/sKiDWnqk",
  "id" : 205383450105090048,
  "created_at" : "2012-05-23 19:43:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SBA",
      "screen_name" : "SBAgov",
      "indices" : [ 3, 10 ],
      "id_str" : "153149305",
      "id" : 153149305
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 126, 137 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SBW2012",
      "indices" : [ 34, 42 ]
    }, {
      "text" : "WHHangout",
      "indices" : [ 85, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/gWtJR23J",
      "expanded_url" : "http:\/\/owl.li\/b62qr",
      "display_url" : "owl.li\/b62qr"
    } ]
  },
  "geo" : { },
  "id_str" : "205375462271221761",
  "text" : "RT @SBAgov: NOW: Have a Q for our #SBW2012 video winners or Admin. Mills? Tweet with #WHHangout | Watch: http:\/\/t.co\/gWtJR23J @whitehouse",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 114, 125 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SBW2012",
        "indices" : [ 22, 30 ]
      }, {
        "text" : "WHHangout",
        "indices" : [ 73, 83 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 113 ],
        "url" : "http:\/\/t.co\/gWtJR23J",
        "expanded_url" : "http:\/\/owl.li\/b62qr",
        "display_url" : "owl.li\/b62qr"
      } ]
    },
    "geo" : { },
    "id_str" : "205375221618843648",
    "text" : "NOW: Have a Q for our #SBW2012 video winners or Admin. Mills? Tweet with #WHHangout | Watch: http:\/\/t.co\/gWtJR23J @whitehouse",
    "id" : 205375221618843648,
    "created_at" : "2012-05-23 19:10:43 +0000",
    "user" : {
      "name" : "SBA",
      "screen_name" : "SBAgov",
      "protected" : false,
      "id_str" : "153149305",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/637366120236756992\/ky6enEIv_normal.png",
      "id" : 153149305,
      "verified" : true
    }
  },
  "id" : 205375462271221761,
  "created_at" : "2012-05-23 19:11:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SBA",
      "screen_name" : "SBAgov",
      "indices" : [ 60, 67 ],
      "id_str" : "153149305",
      "id" : 153149305
    }, {
      "name" : "Entrepreneur",
      "screen_name" : "EntMagazine",
      "indices" : [ 74, 86 ],
      "id_str" : "2932542566",
      "id" : 2932542566
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHHangout",
      "indices" : [ 44, 54 ]
    }, {
      "text" : "SBW2012",
      "indices" : [ 119, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/u95tzH8r",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "205372841187737600",
  "text" : "Happening now: National Small Business Week #WHHangout with @SBAgov &amp; @EntMagazine watch live http:\/\/t.co\/u95tzH8r #SBW2012",
  "id" : 205372841187737600,
  "created_at" : "2012-05-23 19:01:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SBA",
      "screen_name" : "SBAgov",
      "indices" : [ 67, 74 ],
      "id_str" : "153149305",
      "id" : 153149305
    }, {
      "name" : "Entrepreneur",
      "screen_name" : "EntMagazine",
      "indices" : [ 81, 93 ],
      "id_str" : "2932542566",
      "id" : 2932542566
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHHangout",
      "indices" : [ 51, 61 ]
    }, {
      "text" : "NSBW2012",
      "indices" : [ 127, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/u95tzH8r",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "205360686451265537",
  "text" : "Happy National Small Business Week! Don't miss our #WHHangout with @sbagov &amp; @EntMagazine live @ 3ET: http:\/\/t.co\/u95tzH8r #NSBW2012",
  "id" : 205360686451265537,
  "created_at" : "2012-05-23 18:12:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Entrepreneur",
      "screen_name" : "EntMagazine",
      "indices" : [ 3, 15 ],
      "id_str" : "2932542566",
      "id" : 2932542566
    }, {
      "name" : "Diana Ransom",
      "screen_name" : "dianaransom",
      "indices" : [ 59, 71 ],
      "id_str" : "244187775",
      "id" : 244187775
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHHangout",
      "indices" : [ 110, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205359562650423296",
  "text" : "RT @EntMagazine: Have a question for Karen Mills? Join mod @dianaransom for a live chat today at 3pm EST. Use #WHHangout to participate. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Diana Ransom",
        "screen_name" : "dianaransom",
        "indices" : [ 42, 54 ],
        "id_str" : "244187775",
        "id" : 244187775
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHHangout",
        "indices" : [ 93, 103 ]
      } ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/QBMciVqP",
        "expanded_url" : "http:\/\/entm.ag\/JmXpqh",
        "display_url" : "entm.ag\/JmXpqh"
      } ]
    },
    "geo" : { },
    "id_str" : "205359110953238528",
    "text" : "Have a question for Karen Mills? Join mod @dianaransom for a live chat today at 3pm EST. Use #WHHangout to participate. http:\/\/t.co\/QBMciVqP",
    "id" : 205359110953238528,
    "created_at" : "2012-05-23 18:06:42 +0000",
    "user" : {
      "name" : "Entrepreneur",
      "screen_name" : "Entrepreneur",
      "protected" : false,
      "id_str" : "19407053",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/474753665970868224\/GcoCzmcI_normal.jpeg",
      "id" : 19407053,
      "verified" : true
    }
  },
  "id" : 205359562650423296,
  "created_at" : "2012-05-23 18:08:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "205336178772283392",
  "text" : "RT @WHLive: President Obama to Air Force Academy grads: \"Cadets, this is the day you finally become officers in the finest Air Force in  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "205336089240678401",
    "text" : "President Obama to Air Force Academy grads: \"Cadets, this is the day you finally become officers in the finest Air Force in the world\"",
    "id" : 205336089240678401,
    "created_at" : "2012-05-23 16:35:13 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 205336178772283392,
  "created_at" : "2012-05-23 16:35:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 125, 132 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/u95tzH8r",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "205329588388245505",
  "text" : "Live now: President Obama delivers the commencement address at the US Air Force Academy. Watch: http:\/\/t.co\/u95tzH8r Follow: @WHLive",
  "id" : 205329588388245505,
  "created_at" : "2012-05-23 16:09:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Todd Park",
      "screen_name" : "todd_park",
      "indices" : [ 84, 94 ],
      "id_str" : "200176600",
      "id" : 200176600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 141 ],
      "url" : "http:\/\/t.co\/CUZIWLn4",
      "expanded_url" : "http:\/\/wh.gov\/F1x",
      "display_url" : "wh.gov\/F1x"
    } ]
  },
  "geo" : { },
  "id_str" : "205316866556698624",
  "text" : "Wanted: A few good women &amp; men to serve as Presidential Innovation Fellows. CTO @Todd_Park announces new initiative: http:\/\/t.co\/CUZIWLn4",
  "id" : 205316866556698624,
  "created_at" : "2012-05-23 15:18:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/205097568198332416\/photo\/1",
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/eHC3oLoZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AtinJtECEAAomca.jpg",
      "id_str" : "205097568202526720",
      "id" : 205097568202526720,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AtinJtECEAAomca.jpg",
      "sizes" : [ {
        "h" : 315,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 315,
        "resize" : "fit",
        "w" : 560
      }, {
        "h" : 315,
        "resize" : "fit",
        "w" : 560
      } ],
      "display_url" : "pic.twitter.com\/eHC3oLoZ"
    } ],
    "hashtags" : [ {
      "text" : "Joplin",
      "indices" : [ 56, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http:\/\/t.co\/IaDYd4mp",
      "expanded_url" : "http:\/\/wh.gov\/6hr",
      "display_url" : "wh.gov\/6hr"
    } ]
  },
  "geo" : { },
  "id_str" : "205097568198332416",
  "text" : "Number of the Day: 82 years: http:\/\/t.co\/IaDYd4mp Since #Joplin tornado 1yr ago, 126k people put in 755k service hrs: http:\/\/t.co\/eHC3oLoZ",
  "id" : 205097568198332416,
  "created_at" : "2012-05-23 00:47:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Joplin",
      "indices" : [ 13, 20 ]
    }, {
      "text" : "longform",
      "indices" : [ 118, 127 ]
    }, {
      "text" : "longreads",
      "indices" : [ 128, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/Uj9aULmn",
      "expanded_url" : "http:\/\/wh.gov\/joplin",
      "display_url" : "wh.gov\/joplin"
    } ]
  },
  "geo" : { },
  "id_str" : "205092022976135168",
  "text" : "The story of #Joplin: \"We're going to come back &amp; we\u2019re going to come back better than ever\" http:\/\/t.co\/Uj9aULmn #longform #longreads",
  "id" : 205092022976135168,
  "created_at" : "2012-05-23 00:25:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SBA",
      "screen_name" : "SBAgov",
      "indices" : [ 5, 12 ],
      "id_str" : "153149305",
      "id" : 153149305
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smallbiz",
      "indices" : [ 53, 62 ]
    }, {
      "text" : "WHHangout",
      "indices" : [ 91, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/r6rfVU6v",
      "expanded_url" : "http:\/\/wh.gov\/6Vt",
      "display_url" : "wh.gov\/6Vt"
    } ]
  },
  "geo" : { },
  "id_str" : "205063309152616448",
  "text" : "Join @SBAgov Admin Karen Mills for a G+ Hangout with #smallbiz owners on 5\/23. Ask ?s with #WHHangout &amp; watch live: http:\/\/t.co\/r6rfVU6v",
  "id" : 205063309152616448,
  "created_at" : "2012-05-22 22:31:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 89, 98 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "Storify",
      "screen_name" : "Storify",
      "indices" : [ 103, 111 ],
      "id_str" : "17814938",
      "id" : 17814938
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 11, 18 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/twLRyxHg",
      "expanded_url" : "http:\/\/storify.com\/whitehouse\/whchat-presssec-answers-your-questions-about-cong",
      "display_url" : "storify.com\/whitehouse\/whc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "204981187922497536",
  "text" : "Missed the #WHChat on the President's to-do list for Congress? See the full Q&amp;A with @PressSec via @storify: http:\/\/t.co\/twLRyxHg",
  "id" : 204981187922497536,
  "created_at" : "2012-05-22 17:04:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "Brian Bonner",
      "screen_name" : "brianbonner",
      "indices" : [ 15, 27 ],
      "id_str" : "16479143",
      "id" : 16479143
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "204976490016800768",
  "text" : "RT @PressSec: .@brianbonner Gvt helps w\/investments in edu, infrastructure, R&amp;D but private sector is real job growth engine: 4.2M p ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Brian Bonner",
        "screen_name" : "brianbonner",
        "indices" : [ 1, 13 ],
        "id_str" : "16479143",
        "id" : 16479143
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "204791694909124608",
    "geo" : { },
    "id_str" : "204975861303222272",
    "in_reply_to_user_id" : 16479143,
    "text" : ".@brianbonner Gvt helps w\/investments in edu, infrastructure, R&amp;D but private sector is real job growth engine: 4.2M past 26 mos under POTUS",
    "id" : 204975861303222272,
    "in_reply_to_status_id" : 204791694909124608,
    "created_at" : "2012-05-22 16:43:48 +0000",
    "in_reply_to_screen_name" : "brianbonner",
    "in_reply_to_user_id_str" : "16479143",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 204976490016800768,
  "created_at" : "2012-05-22 16:46:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Bonner",
      "screen_name" : "brianbonner",
      "indices" : [ 3, 15 ],
      "id_str" : "16479143",
      "id" : 16479143
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 17, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "204976472451055616",
  "text" : "RT @brianbonner: #WHChat how does government create jobs?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 0, 7 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "204791694909124608",
    "text" : "#WHChat how does government create jobs?",
    "id" : 204791694909124608,
    "created_at" : "2012-05-22 04:31:59 +0000",
    "user" : {
      "name" : "Brian Bonner",
      "screen_name" : "brianbonner",
      "protected" : false,
      "id_str" : "16479143",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/522541134807969792\/4PU4i2bY_normal.jpeg",
      "id" : 16479143,
      "verified" : false
    }
  },
  "id" : 204976472451055616,
  "created_at" : "2012-05-22 16:46:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "Cynthia Sbertoli",
      "screen_name" : "cynsbe",
      "indices" : [ 15, 22 ],
      "id_str" : "42274795",
      "id" : 42274795
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "204975533304463361",
  "text" : "RT @PressSec: .@cynsbe manufacturing in America is already coming back. Over 400k mfg jobs created so far in recovery. Saving US auto in ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Cynthia Sbertoli",
        "screen_name" : "cynsbe",
        "indices" : [ 1, 8 ],
        "id_str" : "42274795",
        "id" : 42274795
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whchat",
        "indices" : [ 133, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "204969336144793601",
    "text" : ".@cynsbe manufacturing in America is already coming back. Over 400k mfg jobs created so far in recovery. Saving US auto ind was key. #whchat",
    "id" : 204969336144793601,
    "created_at" : "2012-05-22 16:17:52 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 204975533304463361,
  "created_at" : "2012-05-22 16:42:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cynthia Sbertoli",
      "screen_name" : "cynsbe",
      "indices" : [ 3, 10 ],
      "id_str" : "42274795",
      "id" : 42274795
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 12, 23 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 61, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "204975507463344128",
  "text" : "RT @cynsbe: @whitehouse how are you going to bring mfg back? #WHChat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 0, 11 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 49, 56 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "204787459073130499",
    "geo" : { },
    "id_str" : "204800358424387584",
    "in_reply_to_user_id" : 30313925,
    "text" : "@whitehouse how are you going to bring mfg back? #WHChat",
    "id" : 204800358424387584,
    "in_reply_to_status_id" : 204787459073130499,
    "created_at" : "2012-05-22 05:06:25 +0000",
    "in_reply_to_screen_name" : "WhiteHouse",
    "in_reply_to_user_id_str" : "30313925",
    "user" : {
      "name" : "Cynthia Sbertoli",
      "screen_name" : "cynsbe",
      "protected" : false,
      "id_str" : "42274795",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1859695442\/5NyjSx9W_normal",
      "id" : 42274795,
      "verified" : false
    }
  },
  "id" : 204975507463344128,
  "created_at" : "2012-05-22 16:42:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 15, 24 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/204972669865705472\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/4oVBQBe1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Atg1jqhCQAA6tjk.jpg",
      "id_str" : "204972669869899776",
      "id" : 204972669869899776,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Atg1jqhCQAA6tjk.jpg",
      "sizes" : [ {
        "h" : 1407,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 704,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 234,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 412,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/4oVBQBe1"
    } ],
    "hashtags" : [ {
      "text" : "CongressToDoList",
      "indices" : [ 51, 68 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 112, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "204972669865705472",
  "text" : "Happening now: @PressSec discusses the President\u2019s #CongressToDoList \u2013 ask your questions &amp; follow along w\/ #WHChat http:\/\/t.co\/4oVBQBe1",
  "id" : 204972669865705472,
  "created_at" : "2012-05-22 16:31:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 88, 97 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jobs",
      "indices" : [ 81, 86 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 131, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "204966795835219968",
  "text" : "What do you want to know about the President's to-do list for Congress to create #jobs? @presssec will answer your Qs soon. Ask w\/ #WHChat",
  "id" : 204966795835219968,
  "created_at" : "2012-05-22 16:07:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 120, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "204945586837917696",
  "text" : "RT @PressSec: What do you want to know about the President's To- Do List for Congress? I'll answer @ 12ET. Ask now with #WHChat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 106, 113 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "204934697095147521",
    "text" : "What do you want to know about the President's To- Do List for Congress? I'll answer @ 12ET. Ask now with #WHChat",
    "id" : 204934697095147521,
    "created_at" : "2012-05-22 14:00:13 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 204945586837917696,
  "created_at" : "2012-05-22 14:43:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    }, {
      "name" : "SpaceX",
      "screen_name" : "SpaceX",
      "indices" : [ 48, 55 ],
      "id_str" : "34743251",
      "id" : 34743251
    }, {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 83, 88 ],
      "id_str" : "11348282",
      "id" : 11348282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http:\/\/t.co\/gHbcB4Eq",
      "expanded_url" : "http:\/\/go.nasa.gov\/KHVlNq",
      "display_url" : "go.nasa.gov\/KHVlNq"
    } ]
  },
  "geo" : { },
  "id_str" : "204944695485411329",
  "text" : "RT @whitehouseostp: Video of historic launch of @SpaceX rocket in partnership with @NASA http:\/\/t.co\/gHbcB4Eq WH Statement: http:\/\/t.co\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "SpaceX",
        "screen_name" : "SpaceX",
        "indices" : [ 28, 35 ],
        "id_str" : "34743251",
        "id" : 34743251
      }, {
        "name" : "NASA",
        "screen_name" : "NASA",
        "indices" : [ 63, 68 ],
        "id_str" : "11348282",
        "id" : 11348282
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DragonLaunch",
        "indices" : [ 125, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 69, 89 ],
        "url" : "http:\/\/t.co\/gHbcB4Eq",
        "expanded_url" : "http:\/\/go.nasa.gov\/KHVlNq",
        "display_url" : "go.nasa.gov\/KHVlNq"
      }, {
        "indices" : [ 104, 124 ],
        "url" : "http:\/\/t.co\/JmWhXJKO",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2012\/05\/22\/statement-white-house-falcon-9-launch",
        "display_url" : "whitehouse.gov\/blog\/2012\/05\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "204943966934806529",
    "text" : "Video of historic launch of @SpaceX rocket in partnership with @NASA http:\/\/t.co\/gHbcB4Eq WH Statement: http:\/\/t.co\/JmWhXJKO #DragonLaunch",
    "id" : 204943966934806529,
    "created_at" : "2012-05-22 14:37:04 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 204944695485411329,
  "created_at" : "2012-05-22 14:39:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Joplin",
      "indices" : [ 55, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/cjrdiBsw",
      "expanded_url" : "http:\/\/wh.gov\/6Hm",
      "display_url" : "wh.gov\/6Hm"
    } ]
  },
  "geo" : { },
  "id_str" : "204929543142776835",
  "text" : "\"You\u2019re the source of inspiration\" -President Obama to #Joplin High School graduates: http:\/\/t.co\/cjrdiBsw",
  "id" : 204929543142776835,
  "created_at" : "2012-05-22 13:39:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CongressToDoList",
      "indices" : [ 52, 69 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 79, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/CKS9A9Ne",
      "expanded_url" : "http:\/\/wh.gov\/6sJ",
      "display_url" : "wh.gov\/6sJ"
    } ]
  },
  "geo" : { },
  "id_str" : "204908300217749505",
  "text" : "Join WH Office Hours today: Ask questions about the #CongressToDoList now with #WHChat &amp; join live at 12ET: http:\/\/t.co\/CKS9A9Ne",
  "id" : 204908300217749505,
  "created_at" : "2012-05-22 12:15:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 87, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 127, 147 ],
      "url" : "http:\/\/t.co\/CKS9A9Ne",
      "expanded_url" : "http:\/\/wh.gov\/6sJ",
      "display_url" : "wh.gov\/6sJ"
    } ]
  },
  "geo" : { },
  "id_str" : "204874629985222656",
  "text" : "Got ?s on the President's plan to help Americans save $ on their mortgages? Ask now w\/ #WHChat &amp; join Q&amp;A live on 5\/22 http:\/\/t.co\/CKS9A9Ne",
  "id" : 204874629985222656,
  "created_at" : "2012-05-22 10:01:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smallbiz",
      "indices" : [ 63, 72 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 87, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 126, 146 ],
      "url" : "http:\/\/t.co\/CKS9A9Ne",
      "expanded_url" : "http:\/\/wh.gov\/6sJ",
      "display_url" : "wh.gov\/6sJ"
    } ]
  },
  "geo" : { },
  "id_str" : "204859349632421889",
  "text" : "Got ?s on the President's plan to invest in clean energy &amp; #smallbiz? Ask now with #WHChat &amp; join Q&amp;A live @ 12ET http:\/\/t.co\/CKS9A9Ne",
  "id" : 204859349632421889,
  "created_at" : "2012-05-22 09:00:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 131, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "204787459073130499",
  "text" : "What do you want to know about the President's plan to bring jobs back to the US? Join WH Office Hrs today @ 12ET. Ask ?s now with #WHChat",
  "id" : 204787459073130499,
  "created_at" : "2012-05-22 04:15:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jobs",
      "indices" : [ 84, 89 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 104, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/CKSe7JWo",
      "expanded_url" : "http:\/\/wh.gov\/6sJ",
      "display_url" : "wh.gov\/6sJ"
    } ]
  },
  "geo" : { },
  "id_str" : "204775952792817665",
  "text" : "WH Office Hours: Got ?s on President Obama's to-do list for Congress that\u2019ll create #jobs? Ask now with #WHChat http:\/\/t.co\/CKSe7JWo",
  "id" : 204775952792817665,
  "created_at" : "2012-05-22 03:29:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Joplin",
      "indices" : [ 68, 75 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "204748394730754049",
  "text" : "Happening now: President Obama delivers the commencement address at #Joplin High School. Watch live: http:\/\/t.co\/u95y7hhB",
  "id" : 204748394730754049,
  "created_at" : "2012-05-22 01:39:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/204746642107285505\/photo\/1",
      "indices" : [ 124, 144 ],
      "url" : "http:\/\/t.co\/MKBQASio",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Atdn_HhCQAAkgzb.jpg",
      "id_str" : "204746642115674112",
      "id" : 204746642115674112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Atdn_HhCQAAkgzb.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      } ],
      "display_url" : "pic.twitter.com\/MKBQASio"
    } ],
    "hashtags" : [ {
      "text" : "Joplin",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/Uj9fslnh",
      "expanded_url" : "http:\/\/wh.gov\/joplin",
      "display_url" : "wh.gov\/joplin"
    } ]
  },
  "geo" : { },
  "id_str" : "204746642107285505",
  "text" : "#Joplin: Remember, Rejoice, Rebuild: Check out interviews, photos &amp; videos marking the 1 yr anniv: http:\/\/t.co\/Uj9fslnh http:\/\/t.co\/MKBQASio",
  "id" : 204746642107285505,
  "created_at" : "2012-05-22 01:32:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/Wd0phtN9",
      "expanded_url" : "http:\/\/wh.gov\/6of",
      "display_url" : "wh.gov\/6of"
    } ]
  },
  "geo" : { },
  "id_str" : "204730934342328320",
  "text" : "Tonight, President Obama delivers the commencement address @ Joplin High School. Watch live at 9:15 p.m. ET: http:\/\/t.co\/Wd0phtN9",
  "id" : 204730934342328320,
  "created_at" : "2012-05-22 00:30:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Webby Awards",
      "screen_name" : "TheWebbyAwards",
      "indices" : [ 3, 18 ],
      "id_str" : "15866188",
      "id" : 15866188
    }, {
      "name" : "Barack Obama",
      "screen_name" : "BarackObama",
      "indices" : [ 21, 33 ],
      "id_str" : "813286",
      "id" : 813286
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "webby",
      "indices" : [ 119, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "204705043297996800",
  "text" : "RT @TheWebbyAwards: .@BarackObama \"The truth is when we are talking about Steve Jobs, we only need one word: amazing.\" #webby #thinkdiff ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Barack Obama",
        "screen_name" : "BarackObama",
        "indices" : [ 1, 13 ],
        "id_str" : "813286",
        "id" : 813286
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "webby",
        "indices" : [ 99, 105 ]
      }, {
        "text" : "thinkdifferent",
        "indices" : [ 106, 121 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "204703336623120387",
    "text" : ".@BarackObama \"The truth is when we are talking about Steve Jobs, we only need one word: amazing.\" #webby #thinkdifferent",
    "id" : 204703336623120387,
    "created_at" : "2012-05-21 22:40:53 +0000",
    "user" : {
      "name" : "The Webby Awards",
      "screen_name" : "TheWebbyAwards",
      "protected" : false,
      "id_str" : "15866188",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/716099640815435776\/jOMvD1nF_normal.jpg",
      "id" : 15866188,
      "verified" : true
    }
  },
  "id" : 204705043297996800,
  "created_at" : "2012-05-21 22:47:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Webby",
      "indices" : [ 56, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "204703122298384384",
  "text" : "\"Thank you for thinking different.\" -President Obama in #Webby Awards tribute to Steve Jobs",
  "id" : 204703122298384384,
  "created_at" : "2012-05-21 22:40:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 3, 12 ],
      "id_str" : "36719281",
      "id" : 36719281
    }, {
      "name" : "epicurious",
      "screen_name" : "epicurious",
      "indices" : [ 72, 83 ],
      "id_str" : "16145224",
      "id" : 16145224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "204666461891985409",
  "text" : "RT @letsmove: Announcing the Kids' \"State Dinner\"! The First Lady &amp; @epicurious invite you to send in your favorite lunch recipe: ht ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "epicurious",
        "screen_name" : "epicurious",
        "indices" : [ 58, 69 ],
        "id_str" : "16145224",
        "id" : 16145224
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/D6RIDP66",
        "expanded_url" : "http:\/\/ow.ly\/b3rV9",
        "display_url" : "ow.ly\/b3rV9"
      } ]
    },
    "geo" : { },
    "id_str" : "204666401066201088",
    "text" : "Announcing the Kids' \"State Dinner\"! The First Lady &amp; @epicurious invite you to send in your favorite lunch recipe: http:\/\/t.co\/D6RIDP66",
    "id" : 204666401066201088,
    "created_at" : "2012-05-21 20:14:07 +0000",
    "user" : {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "protected" : false,
      "id_str" : "36719281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207340336\/780fc13e31b6fdd80bd57d000dc13838_normal.jpeg",
      "id" : 36719281,
      "verified" : true
    }
  },
  "id" : 204666461891985409,
  "created_at" : "2012-05-21 20:14:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Soldier Field",
      "screen_name" : "SoldierField",
      "indices" : [ 52, 65 ],
      "id_str" : "119178220",
      "id" : 119178220
    }, {
      "name" : "NATO",
      "screen_name" : "NATO",
      "indices" : [ 76, 81 ],
      "id_str" : "83795099",
      "id" : 83795099
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/204613031504785409\/photo\/1",
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/tFyihpKx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Atbud9OCMAIlLZp.jpg",
      "id_str" : "204613031508979714",
      "id" : 204613031508979714,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Atbud9OCMAIlLZp.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 235,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 707,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1325,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 414,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/tFyihpKx"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "204613031504785409",
  "text" : "Photo of the Day: President Obama throws a football @soldierfield after the @NATO dinner in Chicago: http:\/\/t.co\/tFyihpKx",
  "id" : 204613031504785409,
  "created_at" : "2012-05-21 16:42:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SBA",
      "screen_name" : "SBAgov",
      "indices" : [ 3, 10 ],
      "id_str" : "153149305",
      "id" : 153149305
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smallbiz",
      "indices" : [ 76, 85 ]
    }, {
      "text" : "SBW2012",
      "indices" : [ 128, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/3zaaYNaw",
      "expanded_url" : "http:\/\/owl.li\/b1ZGn",
      "display_url" : "owl.li\/b1ZGn"
    } ]
  },
  "geo" : { },
  "id_str" : "204580220303450115",
  "text" : "RT @SBAgov: Now: Join SBA Admin Karen Mills+others as they discuss the role #smallbiz play in our economy: http:\/\/t.co\/3zaaYNaw #SBW2012",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "smallbiz",
        "indices" : [ 64, 73 ]
      }, {
        "text" : "SBW2012",
        "indices" : [ 116, 124 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 115 ],
        "url" : "http:\/\/t.co\/3zaaYNaw",
        "expanded_url" : "http:\/\/owl.li\/b1ZGn",
        "display_url" : "owl.li\/b1ZGn"
      } ]
    },
    "geo" : { },
    "id_str" : "204573537653104640",
    "text" : "Now: Join SBA Admin Karen Mills+others as they discuss the role #smallbiz play in our economy: http:\/\/t.co\/3zaaYNaw #SBW2012",
    "id" : 204573537653104640,
    "created_at" : "2012-05-21 14:05:06 +0000",
    "user" : {
      "name" : "SBA",
      "screen_name" : "SBAgov",
      "protected" : false,
      "id_str" : "153149305",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/637366120236756992\/ky6enEIv_normal.png",
      "id" : 153149305,
      "verified" : true
    }
  },
  "id" : 204580220303450115,
  "created_at" : "2012-05-21 14:31:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/204579572581273600\/photo\/1",
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/pSt38Hjc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AtbQCZBCEAAHvNO.jpg",
      "id_str" : "204579572585467904",
      "id" : 204579572585467904,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AtbQCZBCEAAHvNO.jpg",
      "sizes" : [ {
        "h" : 772,
        "resize" : "fit",
        "w" : 1372
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/pSt38Hjc"
    } ],
    "hashtags" : [ {
      "text" : "G8",
      "indices" : [ 52, 55 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/bF1k9oXq",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/photos-and-video\/photogallery\/g8-summit-camp-david",
      "display_url" : "whitehouse.gov\/photos-and-vid\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "204579572581273600",
  "text" : "Photos: President Obama hosts world leaders for the #G8 Summit @ Camp David: http:\/\/t.co\/bF1k9oXq \"Family photo\": http:\/\/t.co\/pSt38Hjc",
  "id" : 204579572581273600,
  "created_at" : "2012-05-21 14:29:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "G8",
      "indices" : [ 80, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/g5ih2w0F",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "203964871098908672",
  "text" : "RT @WHLive: Happening @ 5:45ET: President Obama delivers closing remarks at the #G8 Summit at Camp David. Watch: http:\/\/t.co\/g5ih2w0F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "G8",
        "indices" : [ 68, 71 ]
      } ],
      "urls" : [ {
        "indices" : [ 101, 121 ],
        "url" : "http:\/\/t.co\/g5ih2w0F",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "203962837851316225",
    "text" : "Happening @ 5:45ET: President Obama delivers closing remarks at the #G8 Summit at Camp David. Watch: http:\/\/t.co\/g5ih2w0F",
    "id" : 203962837851316225,
    "created_at" : "2012-05-19 21:38:24 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 203964871098908672,
  "created_at" : "2012-05-19 21:46:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UK Prime Minister",
      "screen_name" : "Number10gov",
      "indices" : [ 3, 15 ],
      "id_str" : "14224719",
      "id" : 14224719
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "G8",
      "indices" : [ 71, 74 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/CGQJJ57r",
      "expanded_url" : "http:\/\/www.flickr.com\/photos\/number10gov\/7227852762\/",
      "display_url" : "flickr.com\/photos\/number1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "203962453531435008",
  "text" : "RT @Number10gov: Photo: PM David Cameron and US President Obama at the #G8 summit at Camp David. http:\/\/t.co\/CGQJJ57r",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "G8",
        "indices" : [ 54, 57 ]
      } ],
      "urls" : [ {
        "indices" : [ 80, 100 ],
        "url" : "http:\/\/t.co\/CGQJJ57r",
        "expanded_url" : "http:\/\/www.flickr.com\/photos\/number10gov\/7227852762\/",
        "display_url" : "flickr.com\/photos\/number1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "203891164733120513",
    "text" : "Photo: PM David Cameron and US President Obama at the #G8 summit at Camp David. http:\/\/t.co\/CGQJJ57r",
    "id" : 203891164733120513,
    "created_at" : "2012-05-19 16:53:36 +0000",
    "user" : {
      "name" : "UK Prime Minister",
      "screen_name" : "Number10gov",
      "protected" : false,
      "id_str" : "14224719",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798111635206508544\/qPVyTQI-_normal.jpg",
      "id" : 14224719,
      "verified" : true
    }
  },
  "id" : 203962453531435008,
  "created_at" : "2012-05-19 21:36:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 8, 16 ],
      "id_str" : "783214",
      "id" : 783214
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 79, 90 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DNT",
      "indices" : [ 91, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/Fyha3bO4",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2012\/05\/19\/putting-twitter-s-do-not-track-feature-context",
      "display_url" : "whitehouse.gov\/blog\/2012\/05\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "203870399375740932",
  "text" : "Putting @Twitter\u2019s \u201CDo Not Track\u201D feature in context: http:\/\/t.co\/Fyha3bO4 via @whitehouse #DNT",
  "id" : 203870399375740932,
  "created_at" : "2012-05-19 15:31:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WallStreetReform",
      "indices" : [ 56, 73 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/u0WReG05",
      "expanded_url" : "http:\/\/youtu.be\/6qylcsQjLTA",
      "display_url" : "youtu.be\/6qylcsQjLTA"
    } ]
  },
  "geo" : { },
  "id_str" : "203867725204959234",
  "text" : "Weekly Address: Congress must move forward, not back on #WallStreetReform: http:\/\/t.co\/u0WReG05",
  "id" : 203867725204959234,
  "created_at" : "2012-05-19 15:20:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CongressToDoList",
      "indices" : [ 37, 54 ]
    }, {
      "text" : "smallbiz",
      "indices" : [ 74, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/Tgiqy76d",
      "expanded_url" : "http:\/\/wh.gov\/todolist",
      "display_url" : "wh.gov\/todolist"
    }, {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/3cDqfbiA",
      "expanded_url" : "http:\/\/youtu.be\/vFJvIQi3bMQ",
      "display_url" : "youtu.be\/vFJvIQi3bMQ"
    } ]
  },
  "geo" : { },
  "id_str" : "203598011555782656",
  "text" : "Watch: President Obama discusses the #CongressToDoList &amp; how it helps #smallbiz owners. http:\/\/t.co\/Tgiqy76d http:\/\/t.co\/3cDqfbiA",
  "id" : 203598011555782656,
  "created_at" : "2012-05-18 21:28:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "G8",
      "indices" : [ 4, 7 ]
    }, {
      "text" : "GlobalAg",
      "indices" : [ 133, 142 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/791FjyvT",
      "expanded_url" : "http:\/\/wh.gov\/ouB",
      "display_url" : "wh.gov\/ouB"
    } ]
  },
  "geo" : { },
  "id_str" : "203584113846915073",
  "text" : "The #G8, African nations &amp; private sector team up to fight hunger. Goal: Lifting 50M people out of poverty: http:\/\/t.co\/791FjyvT #GlobalAg",
  "id" : 203584113846915073,
  "created_at" : "2012-05-18 20:33:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    }, {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 29, 43 ],
      "id_str" : "26278266",
      "id" : 26278266
    }, {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 50, 59 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203549601456861186",
  "text" : "RT @JoiningForces: This week @JoiningForces &amp; @Interior announce free annual pass 4 service members &amp; dependents 2 national park ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Joining Forces",
        "screen_name" : "JoiningForces",
        "indices" : [ 10, 24 ],
        "id_str" : "26278266",
        "id" : 26278266
      }, {
        "name" : "US Dept of Interior",
        "screen_name" : "Interior",
        "indices" : [ 31, 40 ],
        "id_str" : "76348185",
        "id" : 76348185
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/N9k0RXfA",
        "expanded_url" : "http:\/\/youtu.be\/LvqBCpArMgk",
        "display_url" : "youtu.be\/LvqBCpArMgk"
      } ]
    },
    "geo" : { },
    "id_str" : "203520647937261569",
    "text" : "This week @JoiningForces &amp; @Interior announce free annual pass 4 service members &amp; dependents 2 national parks: http:\/\/t.co\/N9k0RXfA",
    "id" : 203520647937261569,
    "created_at" : "2012-05-18 16:21:18 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 203549601456861186,
  "created_at" : "2012-05-18 18:16:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 128, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203526979230777344",
  "text" : "Starting @ 1pm ET: WH Chef Sam Kass answers your questions about school gardens &amp; making healthy choices. Ask your Q now w\/ #WHChat.",
  "id" : 203526979230777344,
  "created_at" : "2012-05-18 16:46:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 3, 12 ],
      "id_str" : "36719281",
      "id" : 36719281
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 96, 103 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203504133934817281",
  "text" : "RT @letsmove: Got questions about healthy choices? WH Chef Sam Kass answers during a Let's Move #WHChat today @ 1:00ET. Ask Q now w\/ #WHChat",
  "id" : 203504133934817281,
  "created_at" : "2012-05-18 15:15:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USAID",
      "screen_name" : "USAID",
      "indices" : [ 3, 9 ],
      "id_str" : "36683668",
      "id" : 36683668
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hunger",
      "indices" : [ 64, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203495788054192128",
  "text" : "RT @USAID: President Obama: \u201CWe\u2019ve put the fight against global #hunger where it should be\u2014at the forefront of global development\u201D #Glob ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "hunger",
        "indices" : [ 53, 60 ]
      }, {
        "text" : "GlobalAg",
        "indices" : [ 120, 129 ]
      }, {
        "text" : "G8",
        "indices" : [ 130, 133 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "203488521191817219",
    "text" : "President Obama: \u201CWe\u2019ve put the fight against global #hunger where it should be\u2014at the forefront of global development\u201D #GlobalAg #G8",
    "id" : 203488521191817219,
    "created_at" : "2012-05-18 14:13:38 +0000",
    "user" : {
      "name" : "USAID",
      "screen_name" : "USAID",
      "protected" : false,
      "id_str" : "36683668",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/717410574523564032\/ExeUofTG_normal.jpg",
      "id" : 36683668,
      "verified" : true
    }
  },
  "id" : 203495788054192128,
  "created_at" : "2012-05-18 14:42:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GlobalAg",
      "indices" : [ 126, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "203488974491222017",
  "text" : "Happening now: President Obama speaks at the Symposium on Global Agriculture &amp; Food Security. Watch: http:\/\/t.co\/u95y7hhB #GlobalAg",
  "id" : 203488974491222017,
  "created_at" : "2012-05-18 14:15:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/SyxrGOql",
      "expanded_url" : "http:\/\/youtu.be\/V8MMb8j2VhI",
      "display_url" : "youtu.be\/V8MMb8j2VhI"
    } ]
  },
  "geo" : { },
  "id_str" : "203475691856080897",
  "text" : "Go behind the scenes with President Obama in the latest West Wing Week: \"Reach High &amp; Hope Deeply.\" Watch: http:\/\/t.co\/SyxrGOql",
  "id" : 203475691856080897,
  "created_at" : "2012-05-18 13:22:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 124, 144 ],
      "url" : "http:\/\/t.co\/dunHr1M0",
      "expanded_url" : "http:\/\/wh.gov\/7s1",
      "display_url" : "wh.gov\/7s1"
    } ]
  },
  "geo" : { },
  "id_str" : "203261384224542720",
  "text" : "Obama on the passing of Donna Summer: \"Her voice was unforgettable &amp; the music industry has lost a legend far too soon\" http:\/\/t.co\/dunHr1M0",
  "id" : 203261384224542720,
  "created_at" : "2012-05-17 23:11:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CongressToDoList",
      "indices" : [ 119, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/3cDqfbiA",
      "expanded_url" : "http:\/\/youtu.be\/vFJvIQi3bMQ",
      "display_url" : "youtu.be\/vFJvIQi3bMQ"
    } ]
  },
  "geo" : { },
  "id_str" : "203221777512529920",
  "text" : "President Obama's message to Congress: \"act to help build &amp; sustain momentum for our economy\" http:\/\/t.co\/3cDqfbiA #CongressToDoList",
  "id" : 203221777512529920,
  "created_at" : "2012-05-17 20:33:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "indices" : [ 3, 18 ],
      "id_str" : "19674502",
      "id" : 19674502
    }, {
      "name" : "Nicholas Kristof",
      "screen_name" : "NickKristof",
      "indices" : [ 43, 55 ],
      "id_str" : "17004618",
      "id" : 17004618
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/IRWdyWwz",
      "expanded_url" : "http:\/\/nytimes.com",
      "display_url" : "nytimes.com"
    } ]
  },
  "geo" : { },
  "id_str" : "203191059377963008",
  "text" : "RT @AmbassadorRice: About to hang out with @NickKristof. Watch our Google+ foreign policy chat live: http:\/\/t.co\/IRWdyWwz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nicholas Kristof",
        "screen_name" : "NickKristof",
        "indices" : [ 23, 35 ],
        "id_str" : "17004618",
        "id" : 17004618
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 81, 101 ],
        "url" : "http:\/\/t.co\/IRWdyWwz",
        "expanded_url" : "http:\/\/nytimes.com",
        "display_url" : "nytimes.com"
      } ]
    },
    "geo" : { },
    "id_str" : "203190494673637376",
    "text" : "About to hang out with @NickKristof. Watch our Google+ foreign policy chat live: http:\/\/t.co\/IRWdyWwz",
    "id" : 203190494673637376,
    "created_at" : "2012-05-17 18:29:23 +0000",
    "user" : {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "protected" : false,
      "id_str" : "19674502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2245433940\/297681_10150417294436240_295915266239_10074516_1895344954_n_normal.jpg",
      "id" : 19674502,
      "verified" : true
    }
  },
  "id" : 203191059377963008,
  "created_at" : "2012-05-17 18:31:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Army",
      "screen_name" : "USArmy",
      "indices" : [ 93, 100 ],
      "id_str" : "8775672",
      "id" : 8775672
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/203190706196586496\/photo\/1",
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/mEjY3i3k",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AtHg3ujCIAAaTuZ.jpg",
      "id_str" : "203190706200780800",
      "id" : 203190706200780800,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AtHg3ujCIAAaTuZ.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/mEjY3i3k"
    } ],
    "hashtags" : [ {
      "text" : "MedalofHonor",
      "indices" : [ 69, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203190706196586496",
  "text" : "Photo of the Day: The President &amp; First Lady greet the family of #MedalofHonor recipient @USArmy Spc Leslie Sabo: http:\/\/t.co\/mEjY3i3k",
  "id" : 203190706196586496,
  "created_at" : "2012-05-17 18:30:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "indices" : [ 3, 18 ],
      "id_str" : "19674502",
      "id" : 19674502
    }, {
      "name" : "Nicholas Kristof",
      "screen_name" : "NickKristof",
      "indices" : [ 29, 41 ],
      "id_str" : "17004618",
      "id" : 17004618
    }, {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "indices" : [ 76, 91 ],
      "id_str" : "19674502",
      "id" : 19674502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/qhk8bs99",
      "expanded_url" : "http:\/\/nyti.ms\/Ml5e45",
      "display_url" : "nyti.ms\/Ml5e45"
    } ]
  },
  "geo" : { },
  "id_str" : "203175847862075394",
  "text" : "RT @AmbassadorRice: Ready RT @NickKristof Ready for my Google+ hangout with @AmbassadorRice on Thursday? Join us: http:\/\/t.co\/qhk8bs99",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nicholas Kristof",
        "screen_name" : "NickKristof",
        "indices" : [ 9, 21 ],
        "id_str" : "17004618",
        "id" : 17004618
      }, {
        "name" : "Susan Rice",
        "screen_name" : "AmbassadorRice",
        "indices" : [ 56, 71 ],
        "id_str" : "19674502",
        "id" : 19674502
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 114 ],
        "url" : "http:\/\/t.co\/qhk8bs99",
        "expanded_url" : "http:\/\/nyti.ms\/Ml5e45",
        "display_url" : "nyti.ms\/Ml5e45"
      } ]
    },
    "geo" : { },
    "id_str" : "202963200663232513",
    "text" : "Ready RT @NickKristof Ready for my Google+ hangout with @AmbassadorRice on Thursday? Join us: http:\/\/t.co\/qhk8bs99",
    "id" : 202963200663232513,
    "created_at" : "2012-05-17 03:26:12 +0000",
    "user" : {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "protected" : false,
      "id_str" : "19674502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2245433940\/297681_10150417294436240_295915266239_10074516_1895344954_n_normal.jpg",
      "id" : 19674502,
      "verified" : true
    }
  },
  "id" : 203175847862075394,
  "created_at" : "2012-05-17 17:31:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CommerceSec",
      "screen_name" : "CommerceSec",
      "indices" : [ 3, 15 ],
      "id_str" : "2319148561",
      "id" : 2319148561
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "50thEAward",
      "indices" : [ 46, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "203145495466614784",
  "text" : "RT @CommerceSec: Awarded 41 top exporters the #50thEAward. It\u2019s a great time to be an American exporter because of strong global demand  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "50thEAward",
        "indices" : [ 29, 40 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "203131676925239296",
    "text" : "Awarded 41 top exporters the #50thEAward. It\u2019s a great time to be an American exporter because of strong global demand for Made in USA",
    "id" : 203131676925239296,
    "created_at" : "2012-05-17 14:35:40 +0000",
    "user" : {
      "name" : "Penny Pritzker",
      "screen_name" : "PennyPritzker",
      "protected" : false,
      "id_str" : "308573576",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000260306047\/1faea5d057983d2f15a31efc6b696ab5_normal.jpeg",
      "id" : 308573576,
      "verified" : true
    }
  },
  "id" : 203145495466614784,
  "created_at" : "2012-05-17 15:30:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/202902923779379200\/photo\/1",
      "indices" : [ 122, 142 ],
      "url" : "http:\/\/t.co\/QAEx6dTy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AtDbIlgCEAAhLew.jpg",
      "id_str" : "202902923783573504",
      "id" : 202902923783573504,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AtDbIlgCEAAhLew.jpg",
      "sizes" : [ {
        "h" : 1280,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/QAEx6dTy"
    } ],
    "hashtags" : [ {
      "text" : "CongressToDoList",
      "indices" : [ 53, 70 ]
    }, {
      "text" : "smallbiz",
      "indices" : [ 90, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/FVDbwsFw",
      "expanded_url" : "http:\/\/wh.gov\/v9y",
      "display_url" : "wh.gov\/v9y"
    } ]
  },
  "geo" : { },
  "id_str" : "202902923779379200",
  "text" : "President Obama visits @Taylor_Gourmet to talk about #CongressToDoList &amp; how it helps #smallbiz: http:\/\/t.co\/FVDbwsFw http:\/\/t.co\/QAEx6dTy",
  "id" : 202902923779379200,
  "created_at" : "2012-05-16 23:26:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/202852458794459136\/photo\/1",
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/HLazYnZk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AtCtPIyCIAEhwsB.jpg",
      "id_str" : "202852458798653441",
      "id" : 202852458798653441,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AtCtPIyCIAEhwsB.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      } ],
      "display_url" : "pic.twitter.com\/HLazYnZk"
    } ],
    "hashtags" : [ {
      "text" : "CongressToDoList",
      "indices" : [ 3, 20 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/zWjCh4K7",
      "expanded_url" : "http:\/\/wh.gov\/v9v",
      "display_url" : "wh.gov\/v9v"
    } ]
  },
  "geo" : { },
  "id_str" : "202852458794459136",
  "text" : "On #CongressToDoList: Help nearly 2 million small business owners create jobs: http:\/\/t.co\/zWjCh4K7 http:\/\/t.co\/HLazYnZk",
  "id" : 202852458794459136,
  "created_at" : "2012-05-16 20:06:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "202839666121117696",
  "text" : "Starting soon: President Obama Awards Specialist Leslie H. Sabo, Jr., U.S. Army, the Medal of Honor. Watch: http:\/\/t.co\/u95y7hhB",
  "id" : 202839666121117696,
  "created_at" : "2012-05-16 19:15:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 35, 44 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1q",
      "indices" : [ 133, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/3Pgjsgq8",
      "expanded_url" : "http:\/\/www.wh.gov",
      "display_url" : "wh.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "202803007623147524",
  "text" : "We just wrapped up live Q&amp;A w\/ @PressSec Jay Carney. Did you watch? Video on http:\/\/t.co\/3Pgjsgq8 soon. Share your feedback with #1q",
  "id" : 202803007623147524,
  "created_at" : "2012-05-16 16:49:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 1, 10 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1q",
      "indices" : [ 103, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/s4NY1bhW",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=hynENZeLzLw",
      "display_url" : "youtube.com\/watch?v=hynENZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "202800450225975298",
  "text" : ".@PressSec Jay Carney is answering your questions live now. Watch: http:\/\/t.co\/s4NY1bhW &amp; ask with #1q",
  "id" : 202800450225975298,
  "created_at" : "2012-05-16 16:39:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 15, 24 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 53, 61 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1q",
      "indices" : [ 76, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "202796882177703936",
  "text" : "Happening now: @presssec answers your questions with @macon44. Ask now with #1q &amp; watch live: http:\/\/t.co\/u95y7hhB",
  "id" : 202796882177703936,
  "created_at" : "2012-05-16 16:25:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "1q",
      "indices" : [ 123, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/jWESMxaP",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "202794487800541184",
  "text" : "RT @PressSec: Got questions? I'll be answering live in a few minutes. Tune-in at http:\/\/t.co\/jWESMxaP &amp; fire away with #1q",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "1q",
        "indices" : [ 109, 112 ]
      } ],
      "urls" : [ {
        "indices" : [ 67, 87 ],
        "url" : "http:\/\/t.co\/jWESMxaP",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "202792980157968385",
    "text" : "Got questions? I'll be answering live in a few minutes. Tune-in at http:\/\/t.co\/jWESMxaP &amp; fire away with #1q",
    "id" : 202792980157968385,
    "created_at" : "2012-05-16 16:09:48 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 202794487800541184,
  "created_at" : "2012-05-16 16:15:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202776533088206851",
  "text" : "RT @pfeiffer44: Excited that POTUS is visiting  @Taylor_Gourmet -- my local sandwich shop -- to talk about initiatives to help small biz ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "congresstodolist",
        "indices" : [ 121, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "202774675888148480",
    "text" : "Excited that POTUS is visiting  @Taylor_Gourmet -- my local sandwich shop -- to talk about initiatives to help small biz #congresstodolist",
    "id" : 202774675888148480,
    "created_at" : "2012-05-16 14:57:04 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 202776533088206851,
  "created_at" : "2012-05-16 15:04:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smallbiz",
      "indices" : [ 36, 45 ]
    }, {
      "text" : "CongressToDoList",
      "indices" : [ 73, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202774525962760192",
  "text" : "Today, President Obama visits local #smallbiz @Taylor_Gourmet to discuss #CongressToDoList &amp; the need to invest in small businesses",
  "id" : 202774525962760192,
  "created_at" : "2012-05-16 14:56:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VAWA",
      "indices" : [ 122, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/oZMVkCb9",
      "expanded_url" : "http:\/\/huff.to\/JSOQG3",
      "display_url" : "huff.to\/JSOQG3"
    } ]
  },
  "geo" : { },
  "id_str" : "202766833676320769",
  "text" : "Valerie Jarrett: \"Just Plain Wrong: House Republican Bill Undermines the Violence Against Women Act\" http:\/\/t.co\/oZMVkCb9 #VAWA",
  "id" : 202766833676320769,
  "created_at" : "2012-05-16 14:25:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "indices" : [ 106, 113 ],
      "id_str" : "44783853",
      "id" : 44783853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/hWYgt2ot",
      "expanded_url" : "http:\/\/www.hhs.gov\/news\/press\/2012pres\/05\/20120515a.html",
      "display_url" : "hhs.gov\/news\/press\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "202551253220339713",
  "text" : "Obama admin is committed to taking action in the fight against Alzheimer\u2019s disease. See national plan via @HHSGov: http:\/\/t.co\/hWYgt2ot",
  "id" : 202551253220339713,
  "created_at" : "2012-05-16 00:09:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/eMELzq7D",
      "expanded_url" : "http:\/\/1.usa.gov\/Jmj5oZ",
      "display_url" : "1.usa.gov\/Jmj5oZ"
    } ]
  },
  "geo" : { },
  "id_str" : "202533428330106880",
  "text" : "RT @jesseclee44: Sr. Adv. would recommend veto of House Violence Against Women Act reauth, would undermine core of VAWA http:\/\/t.co\/eMELzq7D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 123 ],
        "url" : "http:\/\/t.co\/eMELzq7D",
        "expanded_url" : "http:\/\/1.usa.gov\/Jmj5oZ",
        "display_url" : "1.usa.gov\/Jmj5oZ"
      } ]
    },
    "geo" : { },
    "id_str" : "202514613491867649",
    "text" : "Sr. Adv. would recommend veto of House Violence Against Women Act reauth, would undermine core of VAWA http:\/\/t.co\/eMELzq7D",
    "id" : 202514613491867649,
    "created_at" : "2012-05-15 21:43:41 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 202533428330106880,
  "created_at" : "2012-05-15 22:58:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/r2xhSEnu",
      "expanded_url" : "http:\/\/wh.gov\/v2V",
      "display_url" : "wh.gov\/v2V"
    } ]
  },
  "geo" : { },
  "id_str" : "202521348747169792",
  "text" : "\"We are forever in your debt\" -President Obama pays tribute to fallen police officers: http:\/\/t.co\/r2xhSEnu",
  "id" : 202521348747169792,
  "created_at" : "2012-05-15 22:10:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/n9zOjIeI",
      "expanded_url" : "http:\/\/wh.gov\/vgQ",
      "display_url" : "wh.gov\/vgQ"
    } ]
  },
  "geo" : { },
  "id_str" : "202483215984893953",
  "text" : "Today, President Obama &amp; Vice President Biden released their 2011 financial disclosure reports: http:\/\/t.co\/n9zOjIeI",
  "id" : 202483215984893953,
  "created_at" : "2012-05-15 19:38:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dept. of Agriculture",
      "screen_name" : "USDA",
      "indices" : [ 42, 47 ],
      "id_str" : "61853389",
      "id" : 61853389
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "USDA150",
      "indices" : [ 124, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/eQn3nPf6",
      "expanded_url" : "http:\/\/wh.gov\/v2W",
      "display_url" : "wh.gov\/v2W"
    } ]
  },
  "geo" : { },
  "id_str" : "202482468610252802",
  "text" : "\"We pay tribute to the men &amp; women of @USDA\" -President Obama marks the 150th Anniversary of USDA: http:\/\/t.co\/eQn3nPf6 #USDA150",
  "id" : 202482468610252802,
  "created_at" : "2012-05-15 19:35:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CongressToDoList",
      "indices" : [ 120, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/F1gn0FxG",
      "expanded_url" : "http:\/\/apne.ws\/ifjntv",
      "display_url" : "apne.ws\/ifjntv"
    } ]
  },
  "geo" : { },
  "id_str" : "202476347799515139",
  "text" : "RT @Brundage44: On POTUS agenda tmrw: push Congress on To Do List, Meet w Small Biz Owners on jobs http:\/\/t.co\/F1gn0FxG #CongressToDoList",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CongressToDoList",
        "indices" : [ 104, 121 ]
      } ],
      "urls" : [ {
        "indices" : [ 83, 103 ],
        "url" : "http:\/\/t.co\/F1gn0FxG",
        "expanded_url" : "http:\/\/apne.ws\/ifjntv",
        "display_url" : "apne.ws\/ifjntv"
      } ]
    },
    "geo" : { },
    "id_str" : "202473373329145857",
    "text" : "On POTUS agenda tmrw: push Congress on To Do List, Meet w Small Biz Owners on jobs http:\/\/t.co\/F1gn0FxG #CongressToDoList",
    "id" : 202473373329145857,
    "created_at" : "2012-05-15 18:59:48 +0000",
    "user" : {
      "name" : "Liz Allen",
      "screen_name" : "LizAllen44",
      "protected" : false,
      "id_str" : "562456722",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705867932392407042\/-1npI72O_normal.jpg",
      "id" : 562456722,
      "verified" : true
    }
  },
  "id" : 202476347799515139,
  "created_at" : "2012-05-15 19:11:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LA Galaxy",
      "screen_name" : "LAGalaxy",
      "indices" : [ 51, 60 ],
      "id_str" : "23011345",
      "id" : 23011345
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "202461392178118656",
  "text" : "Happening now: President Obama honors MLS champion @LAGalaxy at the White House. Watch: http:\/\/t.co\/u95y7hhB",
  "id" : 202461392178118656,
  "created_at" : "2012-05-15 18:12:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CongressToDoList",
      "indices" : [ 26, 43 ]
    } ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/wGBm5y0Y",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=JFD_O3w7oME&feature=share&list=PLABE000BE10AED04E",
      "display_url" : "youtube.com\/watch?v=JFD_O3\u2026"
    }, {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/Tgiqy76d",
      "expanded_url" : "http:\/\/wh.gov\/todolist",
      "display_url" : "wh.gov\/todolist"
    } ]
  },
  "geo" : { },
  "id_str" : "202441849405837313",
  "text" : "Watch: President Obama on #CongressToDoList: http:\/\/t.co\/wGBm5y0Y http:\/\/t.co\/Tgiqy76d",
  "id" : 202441849405837313,
  "created_at" : "2012-05-15 16:54:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "202419173199069184",
  "text" : "Happening now: President Obama speaks at the National Peace Officers Memorial Service @ the US Capitol. Watch: http:\/\/t.co\/u95y7hhB",
  "id" : 202419173199069184,
  "created_at" : "2012-05-15 15:24:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/202161157224660992\/photo\/1",
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/7ELpQ42I",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/As44gFwCAAEvvxV.jpg",
      "id_str" : "202161157228855297",
      "id" : 202161157228855297,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/As44gFwCAAEvvxV.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/7ELpQ42I"
    } ],
    "hashtags" : [ {
      "text" : "CongressToDoList",
      "indices" : [ 96, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202161157224660992",
  "text" : "Photo of the Day: President Obama greets a baby during his visit to Reno, Nevada to discuss the #CongressToDoList: http:\/\/t.co\/7ELpQ42I",
  "id" : 202161157224660992,
  "created_at" : "2012-05-14 22:19:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USTreasuryDept",
      "screen_name" : "USTreasuryDept",
      "indices" : [ 52, 67 ],
      "id_str" : "2484739350",
      "id" : 2484739350
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/202136768735223809\/photo\/1",
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/B09QPI5A",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/As4iUfkCIAA8Lpn.jpg",
      "id_str" : "202136768743612416",
      "id" : 202136768743612416,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/As4iUfkCIAA8Lpn.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 182
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2047,
        "resize" : "fit",
        "w" : 548
      }, {
        "h" : 1200,
        "resize" : "fit",
        "w" : 321
      }, {
        "h" : 2047,
        "resize" : "fit",
        "w" : 548
      } ],
      "display_url" : "pic.twitter.com\/B09QPI5A"
    } ],
    "hashtags" : [ {
      "text" : "refinancing",
      "indices" : [ 17, 29 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/ZNmvTfCS",
      "expanded_url" : "http:\/\/wh.gov\/yeK",
      "display_url" : "wh.gov\/yeK"
    } ]
  },
  "geo" : { },
  "id_str" : "202136768735223809",
  "text" : "Infographic: How #refinancing can help families via @USTreasuryDept: http:\/\/t.co\/ZNmvTfCS View the graphic: http:\/\/t.co\/B09QPI5A",
  "id" : 202136768735223809,
  "created_at" : "2012-05-14 20:42:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 3, 12 ],
      "id_str" : "36719281",
      "id" : 36719281
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202135307427123200",
  "text" : "RT @letsmove: This just in \u2013 the First Lady and Team USA announced commitments to get more than 1.7M kids active this year. http:\/\/t.co\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 130 ],
        "url" : "http:\/\/t.co\/BErBbJho",
        "expanded_url" : "http:\/\/1.usa.gov\/KaA0WY",
        "display_url" : "1.usa.gov\/KaA0WY"
      } ]
    },
    "geo" : { },
    "id_str" : "202134826403368960",
    "text" : "This just in \u2013 the First Lady and Team USA announced commitments to get more than 1.7M kids active this year. http:\/\/t.co\/BErBbJho",
    "id" : 202134826403368960,
    "created_at" : "2012-05-14 20:34:32 +0000",
    "user" : {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "protected" : false,
      "id_str" : "36719281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207340336\/780fc13e31b6fdd80bd57d000dc13838_normal.jpeg",
      "id" : 36719281,
      "verified" : true
    }
  },
  "id" : 202135307427123200,
  "created_at" : "2012-05-14 20:36:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/202109093312331776\/photo\/1",
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/208p4ztx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/As4JJklCAAACLc3.jpg",
      "id_str" : "202109093320720384",
      "id" : 202109093320720384,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/As4JJklCAAACLc3.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      } ],
      "display_url" : "pic.twitter.com\/208p4ztx"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/y3uQ64Ii",
      "expanded_url" : "http:\/\/wh.gov\/yLV",
      "display_url" : "wh.gov\/yLV"
    } ]
  },
  "geo" : { },
  "id_str" : "202109093312331776",
  "text" : "By the Numbers: In Nevada, refinancing applications are up 237% since last November: http:\/\/t.co\/y3uQ64Ii http:\/\/t.co\/208p4ztx",
  "id" : 202109093312331776,
  "created_at" : "2012-05-14 18:52:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202095605772853249",
  "text" : "RT @WHLive: President Obama: \"Whenever somebody tells you to set your sights lower \u2013 the trajectory of America should give you hope\" #ba ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "barnard2012",
        "indices" : [ 121, 133 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "202095563167105024",
    "text" : "President Obama: \"Whenever somebody tells you to set your sights lower \u2013 the trajectory of America should give you hope\" #barnard2012",
    "id" : 202095563167105024,
    "created_at" : "2012-05-14 17:58:31 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 202095605772853249,
  "created_at" : "2012-05-14 17:58:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "barnard2012",
      "indices" : [ 119, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202093481584365568",
  "text" : "RT @WHLive: President Obama: \"My last piece of advice is this simple...Persevere. Because nothing worthwhile is easy.\" #barnard2012",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "barnard2012",
        "indices" : [ 107, 119 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "202093435933556737",
    "text" : "President Obama: \"My last piece of advice is this simple...Persevere. Because nothing worthwhile is easy.\" #barnard2012",
    "id" : 202093435933556737,
    "created_at" : "2012-05-14 17:50:04 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 202093481584365568,
  "created_at" : "2012-05-14 17:50:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202092262182756353",
  "text" : "RT @PressSec: POTUS to Barnard grads: Don't just get involved. Fight for your seat at the table. Better yet, fight for your seat at head ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "202091681598799874",
    "text" : "POTUS to Barnard grads: Don't just get involved. Fight for your seat at the table. Better yet, fight for your seat at head of the table.",
    "id" : 202091681598799874,
    "created_at" : "2012-05-14 17:43:06 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 202092262182756353,
  "created_at" : "2012-05-14 17:45:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Barnard2012",
      "indices" : [ 125, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202090603658481664",
  "text" : "RT @WHLive: President Obama: \"We know we are better off when women are treated fairly &amp; equally in every aspect of life\" #Barnard2012",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Barnard2012",
        "indices" : [ 113, 125 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "202090547043762176",
    "text" : "President Obama: \"We know we are better off when women are treated fairly &amp; equally in every aspect of life\" #Barnard2012",
    "id" : 202090547043762176,
    "created_at" : "2012-05-14 17:38:35 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 202090603658481664,
  "created_at" : "2012-05-14 17:38:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barnard College",
      "screen_name" : "BarnardCollege",
      "indices" : [ 65, 80 ],
      "id_str" : "36196223",
      "id" : 36196223
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "barnard2012",
      "indices" : [ 115, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "202085816237953024",
  "text" : "Happening now: President Obama delivers the commencement address @BarnardCollege. Watch live: http:\/\/t.co\/u95y7hhB #barnard2012",
  "id" : 202085816237953024,
  "created_at" : "2012-05-14 17:19:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "202081876708573184",
  "text" : "RT @PressSec: President Obama is about to give the commencement address to the Class of 2012 at Barnard College for women http:\/\/t.co\/YZ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 128 ],
        "url" : "http:\/\/t.co\/YZJt4RjA",
        "expanded_url" : "http:\/\/barnard.edu\/",
        "display_url" : "barnard.edu"
      } ]
    },
    "geo" : { },
    "id_str" : "202081212557312000",
    "text" : "President Obama is about to give the commencement address to the Class of 2012 at Barnard College for women http:\/\/t.co\/YZJt4RjA.",
    "id" : 202081212557312000,
    "created_at" : "2012-05-14 17:01:30 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 202081876708573184,
  "created_at" : "2012-05-14 17:04:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/201763133872812032\/photo\/1",
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/OsWODtQ8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AszOgFOCMAA0VHw.jpg",
      "id_str" : "201763133877006336",
      "id" : 201763133877006336,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AszOgFOCMAA0VHw.jpg",
      "sizes" : [ {
        "h" : 425,
        "resize" : "fit",
        "w" : 294
      }, {
        "h" : 425,
        "resize" : "fit",
        "w" : 294
      }, {
        "h" : 425,
        "resize" : "fit",
        "w" : 294
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 425,
        "resize" : "fit",
        "w" : 294
      } ],
      "display_url" : "pic.twitter.com\/OsWODtQ8"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http:\/\/t.co\/FZaHcigd",
      "expanded_url" : "http:\/\/wh.gov\/yWb",
      "display_url" : "wh.gov\/yWb"
    } ]
  },
  "geo" : { },
  "id_str" : "201763133872812032",
  "text" : "Happy Mother's Day! See Presidential moms gallery: http:\/\/t.co\/FZaHcigd Photo of young Barack Obama with mom: http:\/\/t.co\/OsWODtQ8",
  "id" : 201763133872812032,
  "created_at" : "2012-05-13 19:57:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SBA",
      "screen_name" : "SBAgov",
      "indices" : [ 3, 10 ],
      "id_str" : "153149305",
      "id" : 153149305
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smallbiz",
      "indices" : [ 43, 52 ]
    }, {
      "text" : "HappyMothersDay",
      "indices" : [ 76, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/A7qdqpul",
      "expanded_url" : "http:\/\/owl.li\/aSznm",
      "display_url" : "owl.li\/aSznm"
    } ]
  },
  "geo" : { },
  "id_str" : "201758683816923136",
  "text" : "RT @SBAgov: The fastest growing segment in #smallbiz is women entrepreneurs #HappyMothersDay http:\/\/t.co\/A7qdqpul",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "smallbiz",
        "indices" : [ 31, 40 ]
      }, {
        "text" : "HappyMothersDay",
        "indices" : [ 64, 80 ]
      } ],
      "urls" : [ {
        "indices" : [ 81, 101 ],
        "url" : "http:\/\/t.co\/A7qdqpul",
        "expanded_url" : "http:\/\/owl.li\/aSznm",
        "display_url" : "owl.li\/aSznm"
      } ]
    },
    "geo" : { },
    "id_str" : "201756207491457024",
    "text" : "The fastest growing segment in #smallbiz is women entrepreneurs #HappyMothersDay http:\/\/t.co\/A7qdqpul",
    "id" : 201756207491457024,
    "created_at" : "2012-05-13 19:30:02 +0000",
    "user" : {
      "name" : "SBA",
      "screen_name" : "SBAgov",
      "protected" : false,
      "id_str" : "153149305",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/637366120236756992\/ky6enEIv_normal.png",
      "id" : 153149305,
      "verified" : true
    }
  },
  "id" : 201758683816923136,
  "created_at" : "2012-05-13 19:39:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 24, 38 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/201739333307342848\/photo\/1",
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/nmhgWq9m",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Asy42tNCIAAPcai.jpg",
      "id_str" : "201739333311537152",
      "id" : 201739333311537152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Asy42tNCIAAPcai.jpg",
      "sizes" : [ {
        "h" : 1005,
        "resize" : "fit",
        "w" : 524
      }, {
        "h" : 1005,
        "resize" : "fit",
        "w" : 524
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 652,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1005,
        "resize" : "fit",
        "w" : 524
      } ],
      "display_url" : "pic.twitter.com\/nmhgWq9m"
    } ],
    "hashtags" : [ {
      "text" : "ThankAMilitaryMom",
      "indices" : [ 61, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 40, 60 ],
      "url" : "http:\/\/t.co\/csYYV58L",
      "expanded_url" : "http:\/\/wh.gov\/mothersday",
      "display_url" : "wh.gov\/mothersday"
    } ]
  },
  "geo" : { },
  "id_str" : "201739333307342848",
  "text" : "Happy Mother's Day from @JoiningForces! http:\/\/t.co\/csYYV58L #ThankAMilitaryMom View the card &amp; share it: http:\/\/t.co\/nmhgWq9m",
  "id" : 201739333307342848,
  "created_at" : "2012-05-13 18:23:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/201737338190180352\/photo\/1",
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/mJDtzEb4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Asy3Ck2CMAErMue.jpg",
      "id_str" : "201737338202763265",
      "id" : 201737338202763265,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Asy3Ck2CMAErMue.jpg",
      "sizes" : [ {
        "h" : 1005,
        "resize" : "fit",
        "w" : 524
      }, {
        "h" : 1005,
        "resize" : "fit",
        "w" : 524
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 652,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1005,
        "resize" : "fit",
        "w" : 524
      } ],
      "display_url" : "pic.twitter.com\/mJDtzEb4"
    } ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 48, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/csYYV58L",
      "expanded_url" : "http:\/\/wh.gov\/mothersday",
      "display_url" : "wh.gov\/mothersday"
    } ]
  },
  "geo" : { },
  "id_str" : "201737338190180352",
  "text" : "Happy Mother's Day from the Affordable Care Act #ACA: http:\/\/t.co\/csYYV58L View the card &amp; share it: http:\/\/t.co\/mJDtzEb4",
  "id" : 201737338190180352,
  "created_at" : "2012-05-13 18:15:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "201695857811275777",
  "text" : "RT @JoiningForces: On Mother's Day &amp; every day, let's honor military moms for their courage &amp; sacrifice. Join me &amp; #ThankAMi ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ThankAMilitaryMom",
        "indices" : [ 108, 126 ]
      } ],
      "urls" : [ {
        "indices" : [ 128, 148 ],
        "url" : "http:\/\/t.co\/23t0NwNA",
        "expanded_url" : "http:\/\/wh.gov\/mSd",
        "display_url" : "wh.gov\/mSd"
      } ]
    },
    "geo" : { },
    "id_str" : "201695687941955584",
    "text" : "On Mother's Day &amp; every day, let's honor military moms for their courage &amp; sacrifice. Join me &amp; #ThankAMilitaryMom: http:\/\/t.co\/23t0NwNA -MO",
    "id" : 201695687941955584,
    "created_at" : "2012-05-13 15:29:33 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 201695857811275777,
  "created_at" : "2012-05-13 15:30:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/201331706417000448\/photo\/1",
      "indices" : [ 126, 146 ],
      "url" : "http:\/\/t.co\/UPnYFDNT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AstGHsuCMAECEdP.jpg",
      "id_str" : "201331706425389057",
      "id" : 201331706425389057,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AstGHsuCMAECEdP.jpg",
      "sizes" : [ {
        "h" : 425,
        "resize" : "fit",
        "w" : 294
      }, {
        "h" : 425,
        "resize" : "fit",
        "w" : 294
      }, {
        "h" : 425,
        "resize" : "fit",
        "w" : 294
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 425,
        "resize" : "fit",
        "w" : 294
      } ],
      "display_url" : "pic.twitter.com\/UPnYFDNT"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/fOLIces7",
      "expanded_url" : "http:\/\/1.usa.gov\/KS0KCz",
      "display_url" : "1.usa.gov\/KS0KCz"
    } ]
  },
  "geo" : { },
  "id_str" : "201331706417000448",
  "text" : "Photos from the archives: Presidents &amp; their moms in honor of Mother's Day: http:\/\/t.co\/fOLIces7 See Obama &amp; his mom: http:\/\/t.co\/UPnYFDNT",
  "id" : 201331706417000448,
  "created_at" : "2012-05-12 15:23:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CongressToDoList",
      "indices" : [ 124, 141 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/GEjK0kxk",
      "expanded_url" : "http:\/\/youtu.be\/RO5cpFw-ChU",
      "display_url" : "youtu.be\/RO5cpFw-ChU"
    } ]
  },
  "geo" : { },
  "id_str" : "201323607333408768",
  "text" : "Obama: \"Tell [Congress] now is the time to take steps we know will grow our economy &amp; create jobs\" http:\/\/t.co\/GEjK0kxk #CongressToDoList",
  "id" : 201323607333408768,
  "created_at" : "2012-05-12 14:51:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 19, 30 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "sarlynnmarmi19",
      "screen_name" : "DavidAgnew44",
      "indices" : [ 76, 89 ],
      "id_str" : "2982158781",
      "id" : 2982158781
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FollowFriday",
      "indices" : [ 0, 13 ]
    }, {
      "text" : "ff",
      "indices" : [ 131, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "201060099085713409",
  "text" : "#FollowFriday: New @WhiteHouse accts: Director of Intergovernmental Affairs @DavidAgnew44 &amp; Deputy Press Secretary @Brundage44 #ff",
  "id" : 201060099085713409,
  "created_at" : "2012-05-11 21:23:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "barkway",
      "screen_name" : "barkway",
      "indices" : [ 13, 21 ],
      "id_str" : "14973375",
      "id" : 14973375
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "201044495335301120",
  "text" : "RT @WHLive: .@barkway Good q; real problem. POTUS's plan gets at it by streamlining process e.g. eliminating $$ of appraisals for the bo ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "barkway",
        "screen_name" : "barkway",
        "indices" : [ 1, 9 ],
        "id_str" : "14973375",
        "id" : 14973375
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 131, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "201044004270383104",
    "text" : ".@barkway Good q; real problem. POTUS's plan gets at it by streamlining process e.g. eliminating $$ of appraisals for the borrower #WHChat",
    "id" : 201044004270383104,
    "created_at" : "2012-05-11 20:20:00 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 201044495335301120,
  "created_at" : "2012-05-11 20:21:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "barkway",
      "screen_name" : "barkway",
      "indices" : [ 3, 11 ],
      "id_str" : "14973375",
      "id" : 14973375
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHchat",
      "indices" : [ 13, 20 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "201044451538374658",
  "text" : "RT @barkway: #WHchat we had to back out of refi that would have helped us bcuz of all the new onerous paperwork\/regs. Too costly. How do ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHchat",
        "indices" : [ 0, 7 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "201042783136522241",
    "text" : "#WHchat we had to back out of refi that would have helped us bcuz of all the new onerous paperwork\/regs. Too costly. How does that help?",
    "id" : 201042783136522241,
    "created_at" : "2012-05-11 20:15:09 +0000",
    "user" : {
      "name" : "barkway",
      "screen_name" : "barkway",
      "protected" : false,
      "id_str" : "14973375",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1906034654\/barkalounge_normal.jpg",
      "id" : 14973375,
      "verified" : false
    }
  },
  "id" : 201044451538374658,
  "created_at" : "2012-05-11 20:21:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 72, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "201040963676811265",
  "text" : "RT @WHLive: Hi all, it's Brian Deese here...ready for your questions... #WHChat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 60, 67 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "201040411286978562",
    "text" : "Hi all, it's Brian Deese here...ready for your questions... #WHChat",
    "id" : 201040411286978562,
    "created_at" : "2012-05-11 20:05:43 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 201040963676811265,
  "created_at" : "2012-05-11 20:07:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 99, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "201033664497328128",
  "text" : "RT @WHLive: Have Qs on the President's plan to help responsible homeowners refinance? Ask now with #WHChat. NEC Deputy Director will ans ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 87, 94 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "201033484108705793",
    "text" : "Have Qs on the President's plan to help responsible homeowners refinance? Ask now with #WHChat. NEC Deputy Director will answer @ 3:45ET",
    "id" : 201033484108705793,
    "created_at" : "2012-05-11 19:38:12 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 201033664497328128,
  "created_at" : "2012-05-11 19:38:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CongressToDoList",
      "indices" : [ 46, 63 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 118, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "201019766176088064",
  "text" : "Happening @ 3:10ET: President Obama speaks on #CongressToDoList &amp; refinancing: http:\/\/t.co\/u95y7hhB Have Qs? join #WHChat after",
  "id" : 201019766176088064,
  "created_at" : "2012-05-11 18:43:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CongressToDoList",
      "indices" : [ 26, 43 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/t3AWEpxY",
      "expanded_url" : "http:\/\/ow.ly\/aQXIB",
      "display_url" : "ow.ly\/aQXIB"
    } ]
  },
  "geo" : { },
  "id_str" : "200991845524836352",
  "text" : "RT @WHLive: Have ?s about #CongressToDoList &amp; refinancing for responsible homeowners? Watch: http:\/\/t.co\/t3AWEpxY &amp; ask w\/ #WHCh ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CongressToDoList",
        "indices" : [ 14, 31 ]
      }, {
        "text" : "WHChat",
        "indices" : [ 119, 126 ]
      } ],
      "urls" : [ {
        "indices" : [ 85, 105 ],
        "url" : "http:\/\/t.co\/t3AWEpxY",
        "expanded_url" : "http:\/\/ow.ly\/aQXIB",
        "display_url" : "ow.ly\/aQXIB"
      } ]
    },
    "geo" : { },
    "id_str" : "200991779674267648",
    "text" : "Have ?s about #CongressToDoList &amp; refinancing for responsible homeowners? Watch: http:\/\/t.co\/t3AWEpxY &amp; ask w\/ #WHChat. We'll answer @ 2ET",
    "id" : 200991779674267648,
    "created_at" : "2012-05-11 16:52:29 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 200991845524836352,
  "created_at" : "2012-05-11 16:52:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VAWA",
      "indices" : [ 99, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/Gc5W8HDv",
      "expanded_url" : "http:\/\/wh.gov\/yDa",
      "display_url" : "wh.gov\/yDa"
    } ]
  },
  "geo" : { },
  "id_str" : "200988567734988800",
  "text" : "House Republicans bill \"guts nearly 18 years of established law &amp; undermines the foundation of #VAWA\": http:\/\/t.co\/Gc5W8HDv",
  "id" : 200988567734988800,
  "created_at" : "2012-05-11 16:39:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Commerce Dept.",
      "screen_name" : "CommerceGov",
      "indices" : [ 3, 15 ],
      "id_str" : "110541296",
      "id" : 110541296
    }, {
      "name" : "\u0414\u0435\u0442\u043A\u0438\u043Da \u0412\u0435\u0440\u0430",
      "screen_name" : "EconChiefGov",
      "indices" : [ 21, 34 ],
      "id_str" : "2668692210",
      "id" : 2668692210
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "manufacturing",
      "indices" : [ 53, 67 ]
    }, {
      "text" : "mfgChat",
      "indices" : [ 107, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/N5HH37Pj",
      "expanded_url" : "http:\/\/1.usa.gov\/ILi0bm",
      "display_url" : "1.usa.gov\/ILi0bm"
    } ]
  },
  "geo" : { },
  "id_str" : "200984924981952512",
  "text" : "RT @CommerceGov: Ask @EconChiefGov your questions on #manufacturing today at 1pm ET - http:\/\/t.co\/N5HH37Pj #mfgChat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u0414\u0435\u0442\u043A\u0438\u043Da \u0412\u0435\u0440\u0430",
        "screen_name" : "EconChiefGov",
        "indices" : [ 4, 17 ],
        "id_str" : "2668692210",
        "id" : 2668692210
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "manufacturing",
        "indices" : [ 36, 50 ]
      }, {
        "text" : "mfgChat",
        "indices" : [ 90, 98 ]
      } ],
      "urls" : [ {
        "indices" : [ 69, 89 ],
        "url" : "http:\/\/t.co\/N5HH37Pj",
        "expanded_url" : "http:\/\/1.usa.gov\/ILi0bm",
        "display_url" : "1.usa.gov\/ILi0bm"
      } ]
    },
    "geo" : { },
    "id_str" : "200944682371522561",
    "text" : "Ask @EconChiefGov your questions on #manufacturing today at 1pm ET - http:\/\/t.co\/N5HH37Pj #mfgChat",
    "id" : 200944682371522561,
    "created_at" : "2012-05-11 13:45:20 +0000",
    "user" : {
      "name" : "U.S. Commerce Dept.",
      "screen_name" : "CommerceGov",
      "protected" : false,
      "id_str" : "110541296",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/645983513712459776\/3Q0H2IVF_normal.jpg",
      "id" : 110541296,
      "verified" : true
    }
  },
  "id" : 200984924981952512,
  "created_at" : "2012-05-11 16:25:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "indices" : [ 3, 15 ],
      "id_str" : "113436175",
      "id" : 113436175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/EEssgi3U",
      "expanded_url" : "http:\/\/www.defense.gov\/news\/newsarticle.aspx?id=116291",
      "display_url" : "defense.gov\/news\/newsartic\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "200751027417399297",
  "text" : "RT @jesseclee44: American Forces Press Service: \"Report Shows Success of \u2018Don\u2019t Ask, Don\u2019t Tell\u2019 Repeal\" http:\/\/t.co\/EEssgi3U",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 108 ],
        "url" : "http:\/\/t.co\/EEssgi3U",
        "expanded_url" : "http:\/\/www.defense.gov\/news\/newsarticle.aspx?id=116291",
        "display_url" : "defense.gov\/news\/newsartic\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "200748811746951168",
    "text" : "American Forces Press Service: \"Report Shows Success of \u2018Don\u2019t Ask, Don\u2019t Tell\u2019 Repeal\" http:\/\/t.co\/EEssgi3U",
    "id" : 200748811746951168,
    "created_at" : "2012-05-11 00:47:01 +0000",
    "user" : {
      "name" : "Jesse Lee",
      "screen_name" : "jesseclee44",
      "protected" : false,
      "id_str" : "113436175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1366014303\/wedding_profile4_cropped_normal.png",
      "id" : 113436175,
      "verified" : true
    }
  },
  "id" : 200751027417399297,
  "created_at" : "2012-05-11 00:55:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CongressToDoList",
      "indices" : [ 19, 36 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 133, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/QFIwZARg",
      "expanded_url" : "http:\/\/wh.gov\/yrr",
      "display_url" : "wh.gov\/yrr"
    } ]
  },
  "geo" : { },
  "id_str" : "200750344005894146",
  "text" : "WH Office Hours on #CongressToDoList &amp; refinancing: NEC's Brian Deese takes your Qs on 5\/10 @ 2ET: http:\/\/t.co\/QFIwZARg Ask now: #WHChat",
  "id" : 200750344005894146,
  "created_at" : "2012-05-11 00:53:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 16, 26 ],
      "id_str" : "18215973",
      "id" : 18215973
    }, {
      "name" : "jimmy fallon",
      "screen_name" : "jimmyfallon",
      "indices" : [ 108, 120 ],
      "id_str" : "15485441",
      "id" : 15485441
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/200747536527540224\/photo\/1",
      "indices" : [ 122, 142 ],
      "url" : "http:\/\/t.co\/AAzhKxwx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Asky0iSCQAA6xdw.jpg",
      "id_str" : "200747536531734528",
      "id" : 200747536531734528,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Asky0iSCQAA6xdw.jpg",
      "sizes" : [ {
        "h" : 534,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 401,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 534,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/AAzhKxwx"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/46f8jIoy",
      "expanded_url" : "http:\/\/flic.kr\/s\/aHsjzeif9W",
      "display_url" : "flic.kr\/s\/aHsjzeif9W"
    } ]
  },
  "geo" : { },
  "id_str" : "200747536527540224",
  "text" : "WH photographer @petesouza takes you behind-the-scenes in April: http:\/\/t.co\/46f8jIoy &amp; back stage with @jimmyfallon: http:\/\/t.co\/AAzhKxwx",
  "id" : 200747536527540224,
  "created_at" : "2012-05-11 00:41:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sean Stoltey",
      "screen_name" : "WWest3001",
      "indices" : [ 3, 13 ],
      "id_str" : "29371383",
      "id" : 29371383
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CongressToDoList",
      "indices" : [ 98, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/wjipOLRx",
      "expanded_url" : "http:\/\/wh.gov\/todolist",
      "display_url" : "wh.gov\/todolist"
    } ]
  },
  "geo" : { },
  "id_str" : "200717822068924416",
  "text" : "RT @WWest3001: President Obama is calling on Congress to take action to help create jobs. See the #CongressToDoList: http:\/\/t.co\/wjipOLRx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CongressToDoList",
        "indices" : [ 83, 100 ]
      } ],
      "urls" : [ {
        "indices" : [ 102, 122 ],
        "url" : "http:\/\/t.co\/wjipOLRx",
        "expanded_url" : "http:\/\/wh.gov\/todolist",
        "display_url" : "wh.gov\/todolist"
      } ]
    },
    "geo" : { },
    "id_str" : "200707803558580224",
    "text" : "President Obama is calling on Congress to take action to help create jobs. See the #CongressToDoList: http:\/\/t.co\/wjipOLRx",
    "id" : 200707803558580224,
    "created_at" : "2012-05-10 22:04:03 +0000",
    "user" : {
      "name" : "Sean Stoltey",
      "screen_name" : "WWest3001",
      "protected" : false,
      "id_str" : "29371383",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/676560499014631425\/02kO-OVT_normal.jpg",
      "id" : 29371383,
      "verified" : false
    }
  },
  "id" : 200717822068924416,
  "created_at" : "2012-05-10 22:43:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sarlynnmarmi19",
      "screen_name" : "DavidAgnew44",
      "indices" : [ 3, 16 ],
      "id_str" : "2982158781",
      "id" : 2982158781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200704354381082624",
  "text" : "RT @DavidAgnew44: Great call w\/ Cass Sunstein &amp; local officials to discuss unpredented WH push to make fed regs smarter &amp; less c ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 127, 147 ],
        "url" : "http:\/\/t.co\/esnDs0zd",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2012\/05\/10\/making-regulation-smarter-save-lives-and-money",
        "display_url" : "whitehouse.gov\/blog\/2012\/05\/1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "200695664248762368",
    "text" : "Great call w\/ Cass Sunstein &amp; local officials to discuss unpredented WH push to make fed regs smarter &amp; less costly.   http:\/\/t.co\/esnDs0zd",
    "id" : 200695664248762368,
    "created_at" : "2012-05-10 21:15:49 +0000",
    "user" : {
      "name" : "Jerry Abramson",
      "screen_name" : "Abramson44",
      "protected" : false,
      "id_str" : "562385224",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/763586545911734272\/N3LaqB4d_normal.jpg",
      "id" : 562385224,
      "verified" : true
    }
  },
  "id" : 200704354381082624,
  "created_at" : "2012-05-10 21:50:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThankAMilitaryMom",
      "indices" : [ 36, 54 ]
    }, {
      "text" : "military",
      "indices" : [ 119, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/23t0NwNA",
      "expanded_url" : "http:\/\/wh.gov\/mSd",
      "display_url" : "wh.gov\/mSd"
    } ]
  },
  "geo" : { },
  "id_str" : "200685977390415872",
  "text" : "RT @JoiningForces: Find out ways to #ThankAMilitaryMom http:\/\/t.co\/23t0NwNA Second Lady Dr. Biden packs gift boxes for #military moms ht ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JoiningForces\/status\/200685808242540545\/photo\/1",
        "indices" : [ 115, 135 ],
        "url" : "http:\/\/t.co\/oow8Qgj1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Asj6rehCQAMw_2w.jpg",
        "id_str" : "200685808250929155",
        "id" : 200685808250929155,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Asj6rehCQAMw_2w.jpg",
        "sizes" : [ {
          "h" : 1736,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1017,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2048,
          "resize" : "fit",
          "w" : 1208
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/oow8Qgj1"
      } ],
      "hashtags" : [ {
        "text" : "ThankAMilitaryMom",
        "indices" : [ 17, 35 ]
      }, {
        "text" : "military",
        "indices" : [ 100, 109 ]
      } ],
      "urls" : [ {
        "indices" : [ 36, 56 ],
        "url" : "http:\/\/t.co\/23t0NwNA",
        "expanded_url" : "http:\/\/wh.gov\/mSd",
        "display_url" : "wh.gov\/mSd"
      } ]
    },
    "geo" : { },
    "id_str" : "200685808242540545",
    "text" : "Find out ways to #ThankAMilitaryMom http:\/\/t.co\/23t0NwNA Second Lady Dr. Biden packs gift boxes for #military moms http:\/\/t.co\/oow8Qgj1",
    "id" : 200685808242540545,
    "created_at" : "2012-05-10 20:36:41 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 200685977390415872,
  "created_at" : "2012-05-10 20:37:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 47, 61 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThankAMilitaryMom",
      "indices" : [ 120, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/RITZSwTW",
      "expanded_url" : "http:\/\/wh.gov\/yOJ",
      "display_url" : "wh.gov\/yOJ"
    } ]
  },
  "geo" : { },
  "id_str" : "200648065558913025",
  "text" : "Happening now: Mrs. Obama &amp; Dr. Biden host @JoiningForces event to honor military moms. Watch: http:\/\/t.co\/RITZSwTW #ThankAMilitaryMom",
  "id" : 200648065558913025,
  "created_at" : "2012-05-10 18:06:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Immediate Capital",
      "screen_name" : "HildaSolisDOL",
      "indices" : [ 15, 29 ],
      "id_str" : "2187968017",
      "id" : 2187968017
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SummerJobsPlus",
      "indices" : [ 57, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "200636553339482113",
  "text" : "Happening now: @HildaSolisDOL joins a Google+ Hangout on #SummerJobsPlus. Watch live: http:\/\/t.co\/u95y7hhB",
  "id" : 200636553339482113,
  "created_at" : "2012-05-10 17:20:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/e7O9RVeD",
      "expanded_url" : "http:\/\/bit.ly\/Jzjg06",
      "display_url" : "bit.ly\/Jzjg06"
    } ]
  },
  "geo" : { },
  "id_str" : "200613214784983040",
  "text" : "RT @petesouza: New behind-the-scene photos of Pres Obama from April: http:\/\/t.co\/e7O9RVeD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 74 ],
        "url" : "http:\/\/t.co\/e7O9RVeD",
        "expanded_url" : "http:\/\/bit.ly\/Jzjg06",
        "display_url" : "bit.ly\/Jzjg06"
      } ]
    },
    "geo" : { },
    "id_str" : "200556118957768704",
    "text" : "New behind-the-scene photos of Pres Obama from April: http:\/\/t.co\/e7O9RVeD",
    "id" : 200556118957768704,
    "created_at" : "2012-05-10 12:01:19 +0000",
    "user" : {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "protected" : false,
      "id_str" : "18215973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771916869808844800\/7d_poH48_normal.jpg",
      "id" : 18215973,
      "verified" : true
    }
  },
  "id" : 200613214784983040,
  "created_at" : "2012-05-10 15:48:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 27, 30 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 95, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200598371105390593",
  "text" : "RT @WHLive: Happening now: @VP Biden speaks to students about keeping college affordable &amp; #DontDoubleMyRate. Watch: http:\/\/t.co\/g5i ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 15, 18 ],
        "id_str" : "325830217",
        "id" : 325830217
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DontDoubleMyRate",
        "indices" : [ 83, 100 ]
      } ],
      "urls" : [ {
        "indices" : [ 109, 129 ],
        "url" : "http:\/\/t.co\/g5ih2w0F",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "200597853880582145",
    "text" : "Happening now: @VP Biden speaks to students about keeping college affordable &amp; #DontDoubleMyRate. Watch: http:\/\/t.co\/g5ih2w0F",
    "id" : 200597853880582145,
    "created_at" : "2012-05-10 14:47:09 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 200598371105390593,
  "created_at" : "2012-05-10 14:49:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Callahan",
      "screen_name" : "CallahanKyle",
      "indices" : [ 3, 16 ],
      "id_str" : "119933244",
      "id" : 119933244
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CongressToDoList",
      "indices" : [ 110, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200595890971484160",
  "text" : "RT @CallahanKyle: Yes! I will always support this initiative. Invest in clean energy manufacturing. 4 of 5 on #CongressToDoList: http:\/\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CongressToDoList",
        "indices" : [ 92, 109 ]
      } ],
      "urls" : [ {
        "indices" : [ 111, 131 ],
        "url" : "http:\/\/t.co\/Y4eS95g2",
        "expanded_url" : "http:\/\/wh.gov\/todolist",
        "display_url" : "wh.gov\/todolist"
      } ]
    },
    "geo" : { },
    "id_str" : "200474512955940864",
    "text" : "Yes! I will always support this initiative. Invest in clean energy manufacturing. 4 of 5 on #CongressToDoList: http:\/\/t.co\/Y4eS95g2",
    "id" : 200474512955940864,
    "created_at" : "2012-05-10 06:37:03 +0000",
    "user" : {
      "name" : "Kyle Callahan",
      "screen_name" : "CallahanKyle",
      "protected" : false,
      "id_str" : "119933244",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723362775121043456\/fsIZ7-NF_normal.jpg",
      "id" : 119933244,
      "verified" : false
    }
  },
  "id" : 200595890971484160,
  "created_at" : "2012-05-10 14:39:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Immediate Capital",
      "screen_name" : "HildaSolisDOL",
      "indices" : [ 34, 48 ],
      "id_str" : "2187968017",
      "id" : 2187968017
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SummerJobsPlus",
      "indices" : [ 17, 32 ]
    }, {
      "text" : "WHChat",
      "indices" : [ 124, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/nXzyJVrN",
      "expanded_url" : "http:\/\/wh.gov\/mHa",
      "display_url" : "wh.gov\/mHa"
    } ]
  },
  "geo" : { },
  "id_str" : "200595313080287232",
  "text" : "Got questions on #SummerJobsPlus? @HildaSolisDOL answers in a Google+ hangout today @ 1ET: http:\/\/t.co\/nXzyJVrN Ask ?s with #WHChat",
  "id" : 200595313080287232,
  "created_at" : "2012-05-10 14:37:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200589689244221440",
  "text" : "RT @VP: College must be affordable to all. Tell Congress now is not the time to double interest rates on student loans. \u2013 VP #DontDouble ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DontDoubleMyRate",
        "indices" : [ 117, 134 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "200588906922639360",
    "text" : "College must be affordable to all. Tell Congress now is not the time to double interest rates on student loans. \u2013 VP #DontDoubleMyRate",
    "id" : 200588906922639360,
    "created_at" : "2012-05-10 14:11:36 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 200589689244221440,
  "created_at" : "2012-05-10 14:14:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Roberts",
      "screen_name" : "RobinRoberts",
      "indices" : [ 94, 107 ],
      "id_str" : "267921808",
      "id" : 267921808
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/200375856089145345\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/x10kHqpf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Asfgx4xCIAAU1Xu.jpg",
      "id_str" : "200375856097533952",
      "id" : 200375856097533952,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Asfgx4xCIAAU1Xu.jpg",
      "sizes" : [ {
        "h" : 680,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1275,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 398,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/x10kHqpf"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/C8UAdhoE",
      "expanded_url" : "http:\/\/wh.gov\/mMT",
      "display_url" : "wh.gov\/mMT"
    } ]
  },
  "geo" : { },
  "id_str" : "200375856089145345",
  "text" : "President Obama: \"Same-sex couples should be able to get married\" http:\/\/t.co\/C8UAdhoE Pic of @RobinRoberts  interview: http:\/\/t.co\/x10kHqpf",
  "id" : 200375856089145345,
  "created_at" : "2012-05-10 00:05:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/C8UAdhoE",
      "expanded_url" : "http:\/\/wh.gov\/mMT",
      "display_url" : "wh.gov\/mMT"
    } ]
  },
  "geo" : { },
  "id_str" : "200350284294266880",
  "text" : "\"I think same-sex couples should be able to get married.\" -President Obama in an interview today: http:\/\/t.co\/C8UAdhoE",
  "id" : 200350284294266880,
  "created_at" : "2012-05-09 22:23:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "military",
      "indices" : [ 34, 43 ]
    }, {
      "text" : "Afghanistan",
      "indices" : [ 104, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "200306749641719808",
  "text" : "RT @JoiningForces: Meet the brave #military women of the Female Engagement Teams making a difference in #Afghanistan http:\/\/t.co\/3505Kbc ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "military",
        "indices" : [ 15, 24 ]
      }, {
        "text" : "Afghanistan",
        "indices" : [ 85, 97 ]
      } ],
      "urls" : [ {
        "indices" : [ 98, 118 ],
        "url" : "http:\/\/t.co\/3505Kbcn",
        "expanded_url" : "http:\/\/wh.gov\/mF9",
        "display_url" : "wh.gov\/mF9"
      }, {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/P7sVLroM",
        "expanded_url" : "http:\/\/youtu.be\/dN0w8uPnX3s",
        "display_url" : "youtu.be\/dN0w8uPnX3s"
      } ]
    },
    "geo" : { },
    "id_str" : "200305892867051520",
    "text" : "Meet the brave #military women of the Female Engagement Teams making a difference in #Afghanistan http:\/\/t.co\/3505Kbcn http:\/\/t.co\/P7sVLroM",
    "id" : 200305892867051520,
    "created_at" : "2012-05-09 19:27:01 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 200306749641719808,
  "created_at" : "2012-05-09 19:30:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CongressToDoList",
      "indices" : [ 0, 17 ]
    }, {
      "text" : "vets",
      "indices" : [ 69, 74 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/Tgiqy76d",
      "expanded_url" : "http:\/\/wh.gov\/todolist",
      "display_url" : "wh.gov\/todolist"
    } ]
  },
  "geo" : { },
  "id_str" : "200287899424530433",
  "text" : "#CongressToDoList: Create a Veterans Job Corps to help our returning #vets find jobs once they come home (5 of 5): http:\/\/t.co\/Tgiqy76d",
  "id" : 200287899424530433,
  "created_at" : "2012-05-09 18:15:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CongressToDoList",
      "indices" : [ 101, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/Tgiqy76d",
      "expanded_url" : "http:\/\/wh.gov\/todolist",
      "display_url" : "wh.gov\/todolist"
    } ]
  },
  "geo" : { },
  "id_str" : "200010064277417984",
  "text" : "\"Remind your member of Congress we can\u2019t afford to wait until November to get things done\" -Obama on #CongressToDoList http:\/\/t.co\/Tgiqy76d",
  "id" : 200010064277417984,
  "created_at" : "2012-05-08 23:51:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199978781841178625",
  "text" : "RT @WHLive: Happening now: President Obama speaks at the Asian Pacific American Institute for Congressional Studies Dinner. Watch: http: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/g5ih2w0F",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "199978715902525441",
    "text" : "Happening now: President Obama speaks at the Asian Pacific American Institute for Congressional Studies Dinner. Watch: http:\/\/t.co\/g5ih2w0F",
    "id" : 199978715902525441,
    "created_at" : "2012-05-08 21:46:55 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 199978781841178625,
  "created_at" : "2012-05-08 21:47:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 27, 36 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 113, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/fBaKJryH",
      "expanded_url" : "http:\/\/wh.gov\/mnH",
      "display_url" : "wh.gov\/mnH"
    } ]
  },
  "geo" : { },
  "id_str" : "199972231307198464",
  "text" : "\"Extremely disappointing\" -@PressSec on Senate Republicans vote to block student loan bill: http:\/\/t.co\/fBaKJryH #DontDoubleMyRate",
  "id" : 199972231307198464,
  "created_at" : "2012-05-08 21:21:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jon Carson",
      "screen_name" : "JonCarson44",
      "indices" : [ 51, 63 ],
      "id_str" : "1287388789",
      "id" : 1287388789
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CongressToDoList",
      "indices" : [ 92, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/hiDh3DJe",
      "expanded_url" : "http:\/\/wh.gov\/mRT",
      "display_url" : "wh.gov\/mRT"
    } ]
  },
  "geo" : { },
  "id_str" : "199958356000129025",
  "text" : "\"Reward American Jobs, Not Outsourcing\": Check out @JonCarson44's post on President Obama's #CongressToDoList: http:\/\/t.co\/hiDh3DJe",
  "id" : 199958356000129025,
  "created_at" : "2012-05-08 20:26:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/199942980944146433\/photo\/1",
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/jrB3svZI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AsZXFPMCMAEXhMm.jpg",
      "id_str" : "199942980952535041",
      "id" : 199942980952535041,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AsZXFPMCMAEXhMm.jpg",
      "sizes" : [ {
        "h" : 322,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 734,
        "resize" : "fit",
        "w" : 774
      }, {
        "h" : 734,
        "resize" : "fit",
        "w" : 774
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 569,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/jrB3svZI"
    } ],
    "hashtags" : [ {
      "text" : "CongressToDoList",
      "indices" : [ 0, 17 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/Tgiqy76d",
      "expanded_url" : "http:\/\/wh.gov\/todolist",
      "display_url" : "wh.gov\/todolist"
    } ]
  },
  "geo" : { },
  "id_str" : "199942980944146433",
  "text" : "#CongressToDoList: Cut red tape so responsible homeowners can refinance (2 of 5): http:\/\/t.co\/Tgiqy76d http:\/\/t.co\/jrB3svZI",
  "id" : 199942980944146433,
  "created_at" : "2012-05-08 19:24:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 20, 31 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "insourcing",
      "indices" : [ 42, 53 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/pHhEt1Sr",
      "expanded_url" : "http:\/\/wh.gov\/mRo",
      "display_url" : "wh.gov\/mRo"
    } ]
  },
  "geo" : { },
  "id_str" : "199936646462980098",
  "text" : "RT @Brundage44: New @whitehouse report on #insourcing: http:\/\/t.co\/pHhEt1Sr via new Twitter account. Glad to be joining the conversation ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 4, 15 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "insourcing",
        "indices" : [ 26, 37 ]
      }, {
        "text" : "CongressToDoList",
        "indices" : [ 122, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 39, 59 ],
        "url" : "http:\/\/t.co\/pHhEt1Sr",
        "expanded_url" : "http:\/\/wh.gov\/mRo",
        "display_url" : "wh.gov\/mRo"
      } ]
    },
    "geo" : { },
    "id_str" : "199936567912038400",
    "text" : "New @whitehouse report on #insourcing: http:\/\/t.co\/pHhEt1Sr via new Twitter account. Glad to be joining the conversation. #CongressToDoList",
    "id" : 199936567912038400,
    "created_at" : "2012-05-08 18:59:27 +0000",
    "user" : {
      "name" : "Liz Allen",
      "screen_name" : "LizAllen44",
      "protected" : false,
      "id_str" : "562456722",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705867932392407042\/-1npI72O_normal.jpg",
      "id" : 562456722,
      "verified" : true
    }
  },
  "id" : 199936646462980098,
  "created_at" : "2012-05-08 18:59:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/199920513701781507\/photo\/1",
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/ZW8js5tV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AsZCpeLCIAAnl4F.jpg",
      "id_str" : "199920513705975808",
      "id" : 199920513705975808,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AsZCpeLCIAAnl4F.jpg",
      "sizes" : [ {
        "h" : 322,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 734,
        "resize" : "fit",
        "w" : 774
      }, {
        "h" : 734,
        "resize" : "fit",
        "w" : 774
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 569,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/ZW8js5tV"
    } ],
    "hashtags" : [ {
      "text" : "CongressToDoList",
      "indices" : [ 7, 24 ]
    } ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/uxxThI03",
      "expanded_url" : "http:\/\/wh.gov\/m5h",
      "display_url" : "wh.gov\/m5h"
    } ]
  },
  "geo" : { },
  "id_str" : "199920513701781507",
  "text" : "Why is #CongressToDoList trending in the US? http:\/\/t.co\/uxxThI03 http:\/\/t.co\/ZW8js5tV",
  "id" : 199920513701781507,
  "created_at" : "2012-05-08 17:55:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "veterans",
      "indices" : [ 43, 52 ]
    }, {
      "text" : "CongressToDoList",
      "indices" : [ 122, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199915810599342080",
  "text" : "President Obama: \"Congress should help our #veterans returning from Iraq &amp; Afghanistan find jobs once they come home\" #CongressToDoList",
  "id" : 199915810599342080,
  "created_at" : "2012-05-08 17:36:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CongressToDoList",
      "indices" : [ 19, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199915212734865408",
  "text" : "President Obama on #CongressToDoList: \"It\u2019s about the size of a Post-It note, so every Member of Congress should have time to read it.\"",
  "id" : 199915212734865408,
  "created_at" : "2012-05-08 17:34:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CongressToDoList",
      "indices" : [ 104, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199914745153863680",
  "text" : "RT @WHLive: President Obama: \"I know this is an election year. But that is not an excuse for inaction.\" #CongressToDoList",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CongressToDoList",
        "indices" : [ 92, 109 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "199914697875664898",
    "text" : "President Obama: \"I know this is an election year. But that is not an excuse for inaction.\" #CongressToDoList",
    "id" : 199914697875664898,
    "created_at" : "2012-05-08 17:32:32 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 199914745153863680,
  "created_at" : "2012-05-08 17:32:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CongressToDoList",
      "indices" : [ 122, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199913926664790016",
  "text" : "President Obama: \"The only way we can accelerate job creation on the scale that\u2019s needed is w\/ bold action from Congress\" #CongressToDoList",
  "id" : 199913926664790016,
  "created_at" : "2012-05-08 17:29:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CongressToDoList",
      "indices" : [ 114, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199913554273517568",
  "text" : "RT @WHLive: President Obama: \"At this make-or-break moment for the middle class, there\u2019s no excuse for inaction.\" #CongressToDoList",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CongressToDoList",
        "indices" : [ 102, 119 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "199913493271547904",
    "text" : "President Obama: \"At this make-or-break moment for the middle class, there\u2019s no excuse for inaction.\" #CongressToDoList",
    "id" : 199913493271547904,
    "created_at" : "2012-05-08 17:27:45 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 199913554273517568,
  "created_at" : "2012-05-08 17:28:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 111, 118 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CongressToDoList",
      "indices" : [ 41, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/hhNoX4fh",
      "expanded_url" : "http:\/\/www.wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "199912519605821440",
  "text" : "Happening now: President Obama speaks on #CongressToDoList in Albany, NY. Listen: http:\/\/t.co\/hhNoX4fh Follow: @WHLive",
  "id" : 199912519605821440,
  "created_at" : "2012-05-08 17:23:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/199903685101367296\/photo\/1",
      "indices" : [ 121, 141 ],
      "url" : "http:\/\/t.co\/8sy5r6NJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AsYzV6wCMAA7YGb.jpg",
      "id_str" : "199903685105561600",
      "id" : 199903685105561600,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AsYzV6wCMAA7YGb.jpg",
      "sizes" : [ {
        "h" : 399,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 466,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 466,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/8sy5r6NJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199903685101367296",
  "text" : "Photo: President Obama reads \"Where the Wild Things Are\" @ the Easter Egg Roll w\/ the First Lady, Sasha, Malia &amp; Bo: http:\/\/t.co\/8sy5r6NJ",
  "id" : 199903685101367296,
  "created_at" : "2012-05-08 16:48:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/199891300517027842\/photo\/1",
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/S9dVYvVr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AsYoFCmCIAAUpd6.jpg",
      "id_str" : "199891300525416448",
      "id" : 199891300525416448,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AsYoFCmCIAAUpd6.jpg",
      "sizes" : [ {
        "h" : 322,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 734,
        "resize" : "fit",
        "w" : 774
      }, {
        "h" : 734,
        "resize" : "fit",
        "w" : 774
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 569,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/S9dVYvVr"
    } ],
    "hashtags" : [ {
      "text" : "CongressToDoList",
      "indices" : [ 0, 17 ]
    }, {
      "text" : "jobs",
      "indices" : [ 35, 40 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/uxxThI03",
      "expanded_url" : "http:\/\/wh.gov\/m5h",
      "display_url" : "wh.gov\/m5h"
    } ]
  },
  "geo" : { },
  "id_str" : "199891300517027842",
  "text" : "#CongressToDoList: Reward American #jobs, eliminate tax incentives to ship jobs overseas (1 of 5): http:\/\/t.co\/uxxThI03 http:\/\/t.co\/S9dVYvVr",
  "id" : 199891300517027842,
  "created_at" : "2012-05-08 15:59:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CNSE",
      "screen_name" : "CNSE",
      "indices" : [ 34, 39 ],
      "id_str" : "20274024",
      "id" : 20274024
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/199867910758473728\/photo\/1",
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/4VJj2Jd7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AsYSzk8CIAAobIF.jpg",
      "id_str" : "199867910762668032",
      "id" : 199867910762668032,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AsYSzk8CIAAobIF.jpg",
      "sizes" : [ {
        "h" : 322,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 734,
        "resize" : "fit",
        "w" : 774
      }, {
        "h" : 734,
        "resize" : "fit",
        "w" : 774
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 569,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/4VJj2Jd7"
    } ],
    "hashtags" : [ {
      "text" : "CongressToDoList",
      "indices" : [ 72, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199867910758473728",
  "text" : "Today, President Obama travels to @CNSE to call on Congress to act on a #CongressToDoList that will create jobs: http:\/\/t.co\/4VJj2Jd7",
  "id" : 199867910758473728,
  "created_at" : "2012-05-08 14:26:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    }, {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "indices" : [ 20, 28 ],
      "id_str" : "807095",
      "id" : 807095
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/iC4RNs2k",
      "expanded_url" : "http:\/\/nyti.ms\/JYfs5L",
      "display_url" : "nyti.ms\/JYfs5L"
    } ]
  },
  "geo" : { },
  "id_str" : "199678251923275776",
  "text" : "RT @pfeiffer44: Via @nytimes Obama Hands Congress Economic \u2018To Do\u2019 List http:\/\/t.co\/iC4RNs2k",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/nytimes\/id284862083?mt=8&uo=4\" rel=\"nofollow\"\u003ENYTimes on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The New York Times",
        "screen_name" : "nytimes",
        "indices" : [ 4, 12 ],
        "id_str" : "807095",
        "id" : 807095
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 56, 76 ],
        "url" : "http:\/\/t.co\/iC4RNs2k",
        "expanded_url" : "http:\/\/nyti.ms\/JYfs5L",
        "display_url" : "nyti.ms\/JYfs5L"
      } ]
    },
    "geo" : { },
    "id_str" : "199676825545355264",
    "text" : "Via @nytimes Obama Hands Congress Economic \u2018To Do\u2019 List http:\/\/t.co\/iC4RNs2k",
    "id" : 199676825545355264,
    "created_at" : "2012-05-08 01:47:19 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 199678251923275776,
  "created_at" : "2012-05-08 01:52:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 127, 144 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/pUt2qe0w",
      "expanded_url" : "http:\/\/wh.gov\/mXv",
      "display_url" : "wh.gov\/mXv"
    } ]
  },
  "geo" : { },
  "id_str" : "199677466506297345",
  "text" : "President Obama joins call with elected officials &amp; student leaders to discuss college affordability: http:\/\/t.co\/pUt2qe0w\n#DontDoubleMyRate",
  "id" : 199677466506297345,
  "created_at" : "2012-05-08 01:49:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 57, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199664934928384001",
  "text" : "RT @WHLive: Thanks to everyone who joined us for today\u2019s #WHChat celebrating National Nurses Week \u2013 view the full Q&amp;A session: http: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHChat",
        "indices" : [ 45, 52 ]
      } ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/GNGtzpPi",
        "expanded_url" : "http:\/\/sfy.co\/ufB",
        "display_url" : "sfy.co\/ufB"
      } ]
    },
    "geo" : { },
    "id_str" : "199662022743429121",
    "text" : "Thanks to everyone who joined us for today\u2019s #WHChat celebrating National Nurses Week \u2013 view the full Q&amp;A session: http:\/\/t.co\/GNGtzpPi",
    "id" : 199662022743429121,
    "created_at" : "2012-05-08 00:48:30 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 199664934928384001,
  "created_at" : "2012-05-08 01:00:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    }, {
      "name" : "DurhamPublicSchools",
      "screen_name" : "DurhamPublicSch",
      "indices" : [ 63, 79 ],
      "id_str" : "33530254",
      "id" : 33530254
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199630304128942080",
  "text" : "RT @arneduncan: Phoned Helen McLeod, a 40yr veteran teacher at @DurhamPublicSch, today to thank her for her hard work. We need more like ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "DurhamPublicSchools",
        "screen_name" : "DurhamPublicSch",
        "indices" : [ 47, 63 ],
        "id_str" : "33530254",
        "id" : 33530254
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "thankateacher",
        "indices" : [ 126, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "199593323739095040",
    "text" : "Phoned Helen McLeod, a 40yr veteran teacher at @DurhamPublicSch, today to thank her for her hard work. We need more like her. #thankateacher",
    "id" : 199593323739095040,
    "created_at" : "2012-05-07 20:15:31 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 199630304128942080,
  "created_at" : "2012-05-07 22:42:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 3, 11 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199630103775416321",
  "text" : "RT @macon44: \"What really makes the 787 so special is what it says about America\" - Dreamliner makes soft landing but big splash http:\/\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 136 ],
        "url" : "http:\/\/t.co\/XsBCqAwb",
        "expanded_url" : "http:\/\/bit.ly\/JaDmMa",
        "display_url" : "bit.ly\/JaDmMa"
      } ]
    },
    "geo" : { },
    "id_str" : "199628744300826624",
    "text" : "\"What really makes the 787 so special is what it says about America\" - Dreamliner makes soft landing but big splash http:\/\/t.co\/XsBCqAwb",
    "id" : 199628744300826624,
    "created_at" : "2012-05-07 22:36:16 +0000",
    "user" : {
      "name" : "Macon Phillips",
      "screen_name" : "IIPCoordinator",
      "protected" : false,
      "id_str" : "110823581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000495374915\/f6a5ae048ab7f8f12c0386114df53203_normal.jpeg",
      "id" : 110823581,
      "verified" : true
    }
  },
  "id" : 199630103775416321,
  "created_at" : "2012-05-07 22:41:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sarlynnmarmi19",
      "screen_name" : "DavidAgnew44",
      "indices" : [ 3, 16 ],
      "id_str" : "2982158781",
      "id" : 2982158781
    }, {
      "name" : "Cory Booker",
      "screen_name" : "CoryBooker",
      "indices" : [ 28, 39 ],
      "id_str" : "15808765",
      "id" : 15808765
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 96, 107 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199629915266625537",
  "text" : "RT @DavidAgnew44: Thanks to @CoryBooker for welcoming me aboard. An amazing leader-pleased that @whitehouse counts him as a friend.  Muc ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Cory Booker",
        "screen_name" : "CoryBooker",
        "indices" : [ 10, 21 ],
        "id_str" : "15808765",
        "id" : 15808765
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 78, 89 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "199625402602373120",
    "text" : "Thanks to @CoryBooker for welcoming me aboard. An amazing leader-pleased that @whitehouse counts him as a friend.  Much work to do together!",
    "id" : 199625402602373120,
    "created_at" : "2012-05-07 22:22:59 +0000",
    "user" : {
      "name" : "Jerry Abramson",
      "screen_name" : "Abramson44",
      "protected" : false,
      "id_str" : "562385224",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/763586545911734272\/N3LaqB4d_normal.jpg",
      "id" : 562385224,
      "verified" : true
    }
  },
  "id" : 199629915266625537,
  "created_at" : "2012-05-07 22:40:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "Josh Rovner",
      "screen_name" : "JoshRovner",
      "indices" : [ 13, 24 ],
      "id_str" : "131242470",
      "id" : 131242470
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 25, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199585289344253955",
  "text" : "RT @WHLive: .@JoshRovner #ACA includes $200M to expand school-based health centers; enables schools to focus on valuable nursing staff # ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Josh Rovner",
        "screen_name" : "JoshRovner",
        "indices" : [ 1, 12 ],
        "id_str" : "131242470",
        "id" : 131242470
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ACA",
        "indices" : [ 13, 17 ]
      }, {
        "text" : "WHchat",
        "indices" : [ 123, 130 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "199584783016263681",
    "text" : ".@JoshRovner #ACA includes $200M to expand school-based health centers; enables schools to focus on valuable nursing staff #WHchat",
    "id" : 199584783016263681,
    "created_at" : "2012-05-07 19:41:35 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 199585289344253955,
  "created_at" : "2012-05-07 19:43:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Rovner",
      "screen_name" : "JoshRovner",
      "indices" : [ 3, 14 ],
      "id_str" : "131242470",
      "id" : 131242470
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199585267949125632",
  "text" : "RT @JoshRovner: School-based health centers are mostly managed by nurse practitioners; local funding cuts threaten our jobs. How can WH  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WHLive",
        "indices" : [ 132, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "199575896666021890",
    "text" : "School-based health centers are mostly managed by nurse practitioners; local funding cuts threaten our jobs. How can WH support us? #WHLive",
    "id" : 199575896666021890,
    "created_at" : "2012-05-07 19:06:16 +0000",
    "user" : {
      "name" : "Josh Rovner",
      "screen_name" : "JoshRovner",
      "protected" : false,
      "id_str" : "131242470",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705108183585583104\/_04iqTsY_normal.jpg",
      "id" : 131242470,
      "verified" : false
    }
  },
  "id" : 199585267949125632,
  "created_at" : "2012-05-07 19:43:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 36, 47 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "whchat",
      "indices" : [ 119, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199582841766547456",
  "text" : "RT @WHLive: Hi, Mary Wakefield here @whitehouse ready for questions and happy to hear from my nurse colleagues for the #whchat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 24, 35 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "whchat",
        "indices" : [ 107, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "199582793188114433",
    "text" : "Hi, Mary Wakefield here @whitehouse ready for questions and happy to hear from my nurse colleagues for the #whchat",
    "id" : 199582793188114433,
    "created_at" : "2012-05-07 19:33:40 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 199582841766547456,
  "created_at" : "2012-05-07 19:33:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/199581792985026560\/photo\/1",
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/665Kjhd9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AsUOlVLCEAE8boy.jpg",
      "id_str" : "199581792989220865",
      "id" : 199581792989220865,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AsUOlVLCEAE8boy.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      } ],
      "display_url" : "pic.twitter.com\/665Kjhd9"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http:\/\/t.co\/cvB2LvtW",
      "expanded_url" : "http:\/\/wh.gov\/m8B",
      "display_url" : "wh.gov\/m8B"
    } ]
  },
  "geo" : { },
  "id_str" : "199581792985026560",
  "text" : "By the numbers: 3,000 http:\/\/t.co\/cvB2LvtW Community health centers have added 3k positions for nurses since 2009: http:\/\/t.co\/665Kjhd9",
  "id" : 199581792985026560,
  "created_at" : "2012-05-07 19:29:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thankateacher",
      "indices" : [ 65, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/dUqOz7Qb",
      "expanded_url" : "http:\/\/go.usa.gov\/VNi",
      "display_url" : "go.usa.gov\/VNi"
    } ]
  },
  "geo" : { },
  "id_str" : "199580633679396866",
  "text" : "RT @arneduncan: Join me tomorrow on Teacher Appreciation Day and #thankateacher on Twitter and Facebook http:\/\/t.co\/dUqOz7Qb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "thankateacher",
        "indices" : [ 49, 63 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 108 ],
        "url" : "http:\/\/t.co\/dUqOz7Qb",
        "expanded_url" : "http:\/\/go.usa.gov\/VNi",
        "display_url" : "go.usa.gov\/VNi"
      } ]
    },
    "geo" : { },
    "id_str" : "199579363434430464",
    "text" : "Join me tomorrow on Teacher Appreciation Day and #thankateacher on Twitter and Facebook http:\/\/t.co\/dUqOz7Qb",
    "id" : 199579363434430464,
    "created_at" : "2012-05-07 19:20:02 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 199580633679396866,
  "created_at" : "2012-05-07 19:25:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "sarlynnmarmi19",
      "screen_name" : "DavidAgnew44",
      "indices" : [ 3, 16 ],
      "id_str" : "2982158781",
      "id" : 2982158781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199573959077928961",
  "text" : "RT @DavidAgnew44: President Obama just joined call with mayors, govs, county execs &amp; student leaders-urges Congress to act on studen ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DontDoubleMyRate",
        "indices" : [ 126, 143 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "199573817901842433",
    "text" : "President Obama just joined call with mayors, govs, county execs &amp; student leaders-urges Congress to act on student loans #DontDoubleMyRate",
    "id" : 199573817901842433,
    "created_at" : "2012-05-07 18:58:00 +0000",
    "user" : {
      "name" : "Jerry Abramson",
      "screen_name" : "Abramson44",
      "protected" : false,
      "id_str" : "562385224",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/763586545911734272\/N3LaqB4d_normal.jpg",
      "id" : 562385224,
      "verified" : true
    }
  },
  "id" : 199573959077928961,
  "created_at" : "2012-05-07 18:58:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael A. Nutter",
      "screen_name" : "Michael_Nutter",
      "indices" : [ 3, 18 ],
      "id_str" : "202790178",
      "id" : 202790178
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dontdoublemyrate",
      "indices" : [ 86, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "199573712897449984",
  "text" : "RT @Michael_Nutter: College students in my office, on the phone with Pres Obama about #dontdoublemyrate. Pres Obama supports edu! http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ubersocial.com\" rel=\"nofollow\"\u003EUberSocial for BlackBerry\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "dontdoublemyrate",
        "indices" : [ 66, 83 ]
      } ],
      "urls" : [ {
        "indices" : [ 110, 130 ],
        "url" : "http:\/\/t.co\/Zw9wZkaL",
        "expanded_url" : "http:\/\/lockerz.com\/s\/207244038",
        "display_url" : "lockerz.com\/s\/207244038"
      } ]
    },
    "geo" : { },
    "id_str" : "199566256624517120",
    "text" : "College students in my office, on the phone with Pres Obama about #dontdoublemyrate. Pres Obama supports edu! http:\/\/t.co\/Zw9wZkaL",
    "id" : 199566256624517120,
    "created_at" : "2012-05-07 18:27:58 +0000",
    "user" : {
      "name" : "Michael A. Nutter",
      "screen_name" : "Michael_Nutter",
      "protected" : false,
      "id_str" : "202790178",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/753094044654395392\/Rt-pdJuc_normal.jpg",
      "id" : 202790178,
      "verified" : true
    }
  },
  "id" : 199573712897449984,
  "created_at" : "2012-05-07 18:57:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/b8DVhwDZ",
      "expanded_url" : "http:\/\/wh.gov\/mbm",
      "display_url" : "wh.gov\/mbm"
    } ]
  },
  "geo" : { },
  "id_str" : "199535378288492544",
  "text" : "President Obama called President-elect Francois Hollande of France to congratulate him: http:\/\/t.co\/b8DVhwDZ",
  "id" : 199535378288492544,
  "created_at" : "2012-05-07 16:25:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 91, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/d37G7leU",
      "expanded_url" : "http:\/\/youtu.be\/MtZa6So1lBc",
      "display_url" : "youtu.be\/MtZa6So1lBc"
    } ]
  },
  "geo" : { },
  "id_str" : "199519878519074816",
  "text" : "\"Your voice makes a difference. Your voice matters.\" -President Obama http:\/\/t.co\/d37G7leU #DontDoubleMyRate",
  "id" : 199519878519074816,
  "created_at" : "2012-05-07 15:23:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHChat",
      "indices" : [ 134, 141 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/VXwoGna1",
      "expanded_url" : "http:\/\/wh.gov\/mbJ",
      "display_url" : "wh.gov\/mbJ"
    } ]
  },
  "geo" : { },
  "id_str" : "199506746027425792",
  "text" : "It's National Nurses Week: Join Office Hours on the Affordable Care Act &amp; nurses today @ 3:30ET: http:\/\/t.co\/VXwoGna1 Ask ?s now: #WHChat",
  "id" : 199506746027425792,
  "created_at" : "2012-05-07 14:31:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/199498008604319745\/photo\/1",
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/zXHJyrCC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AsTCYcDCIAAeNxw.jpg",
      "id_str" : "199498008612708352",
      "id" : 199498008612708352,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AsTCYcDCIAAeNxw.jpg",
      "sizes" : [ {
        "h" : 1320,
        "resize" : "fit",
        "w" : 1980
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/zXHJyrCC"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/jePXqfcn",
      "expanded_url" : "http:\/\/wh.gov\/PfY",
      "display_url" : "wh.gov\/PfY"
    } ]
  },
  "geo" : { },
  "id_str" : "199498008604319745",
  "text" : "President Obama honors Teacher of the Year Rebecca Mieliwocki: http:\/\/t.co\/jePXqfcn Happy Teacher Appreciation Week! http:\/\/t.co\/zXHJyrCC",
  "id" : 199498008604319745,
  "created_at" : "2012-05-07 13:56:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/JMDqsycR",
      "expanded_url" : "http:\/\/ow.ly\/aIHQs",
      "display_url" : "ow.ly\/aIHQs"
    } ]
  },
  "geo" : { },
  "id_str" : "198796216534962176",
  "text" : "President Obama: \"After more than a decade of war, it is time to focus on nation building here at home\" Watch: http:\/\/t.co\/JMDqsycR",
  "id" : 198796216534962176,
  "created_at" : "2012-05-05 15:28:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 67, 78 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/198551193465782272\/photo\/1",
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/GP9iQhDe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AsFlQiyCAAAkzK1.jpg",
      "id_str" : "198551193469976576",
      "id" : 198551193469976576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AsFlQiyCAAAkzK1.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 951,
        "resize" : "fit",
        "w" : 1427
      } ],
      "display_url" : "pic.twitter.com\/GP9iQhDe"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198551193465782272",
  "text" : "Photo of the Day: President Obama walks along the Colonnade of the @WhiteHouse on his way to the Oval Office: http:\/\/t.co\/GP9iQhDe",
  "id" : 198551193465782272,
  "created_at" : "2012-05-04 23:14:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "198517955842146304",
  "text" : "Happening now: President Obama honors the 2012 NCAA Champions University of Kentucky Mens Basketball Team. Watch: http:\/\/t.co\/u95y7hhB",
  "id" : 198517955842146304,
  "created_at" : "2012-05-04 21:02:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Calipari",
      "screen_name" : "UKCoachCalipari",
      "indices" : [ 3, 19 ],
      "id_str" : "26072066",
      "id" : 26072066
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198511954262884352",
  "text" : "RT @UKCoachCalipari: Headed to the White House now. I'm excited for our players. You can watch a live stream of our visit at 4:50 p.m. h ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 134 ],
        "url" : "http:\/\/t.co\/9ipSe7UF",
        "expanded_url" : "http:\/\/tinyurl.com\/7tpzh42",
        "display_url" : "tinyurl.com\/7tpzh42"
      } ]
    },
    "geo" : { },
    "id_str" : "198482503865090048",
    "text" : "Headed to the White House now. I'm excited for our players. You can watch a live stream of our visit at 4:50 p.m. http:\/\/t.co\/9ipSe7UF",
    "id" : 198482503865090048,
    "created_at" : "2012-05-04 18:41:31 +0000",
    "user" : {
      "name" : "John Calipari",
      "screen_name" : "UKCoachCalipari",
      "protected" : false,
      "id_str" : "26072066",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766332774273978368\/bbbpTWZe_normal.jpg",
      "id" : 26072066,
      "verified" : true
    }
  },
  "id" : 198511954262884352,
  "created_at" : "2012-05-04 20:38:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 141 ],
      "url" : "http:\/\/t.co\/94kPduQh",
      "expanded_url" : "http:\/\/youtu.be\/wAOPcOkUzqA",
      "display_url" : "youtu.be\/wAOPcOkUzqA"
    } ]
  },
  "geo" : { },
  "id_str" : "198494491001372672",
  "text" : "This week, the President traveled to Afghanistan to sign an historic agreement &amp; address the American people. Watch: http:\/\/t.co\/94kPduQh",
  "id" : 198494491001372672,
  "created_at" : "2012-05-04 19:29:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198455240348020736",
  "text" : "RT @arneduncan: Just left Washington-Lee HS w\/Pres Obama. Great students &amp; parents. We can't let interest rates double on them. #Don ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DontDoubleMyRate",
        "indices" : [ 116, 133 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "198454461520289792",
    "text" : "Just left Washington-Lee HS w\/Pres Obama. Great students &amp; parents. We can't let interest rates double on them. #DontDoubleMyRate",
    "id" : 198454461520289792,
    "created_at" : "2012-05-04 16:50:05 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 198455240348020736,
  "created_at" : "2012-05-04 16:53:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/198453575544877059\/photo\/1",
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/pw5opy5M",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AsEMebtCMAAVjOZ.jpg",
      "id_str" : "198453575553265664",
      "id" : 198453575553265664,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AsEMebtCMAAVjOZ.jpg",
      "sizes" : [ {
        "h" : 460,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 391,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 460,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 460,
        "resize" : "fit",
        "w" : 400
      } ],
      "display_url" : "pic.twitter.com\/pw5opy5M"
    } ],
    "hashtags" : [ {
      "text" : "jobs",
      "indices" : [ 22, 27 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/vClIlD2I",
      "expanded_url" : "http:\/\/wh.gov\/mOs",
      "display_url" : "wh.gov\/mOs"
    } ]
  },
  "geo" : { },
  "id_str" : "198453575544877059",
  "text" : "The economy has added #jobs for 26 straight months. Encouraging, but more work to be done: http:\/\/t.co\/vClIlD2I Chart: http:\/\/t.co\/pw5opy5M",
  "id" : 198453575544877059,
  "created_at" : "2012-05-04 16:46:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 111, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198444996255420418",
  "text" : "President Obama: \"So tell Congress that now is not the time to double the interest rate on your student loans\" #DontDoubleMyRate",
  "id" : 198444996255420418,
  "created_at" : "2012-05-04 16:12:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 89, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198444539927736321",
  "text" : "President Obama: \"If you agree with me, I want you to send Congress a message. Tell them #DontDoubleMyRate\u201D",
  "id" : 198444539927736321,
  "created_at" : "2012-05-04 16:10:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 115, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198443395079872512",
  "text" : "President Obama: \"You guys shouldn\u2019t have to pay an extra $1,000 just because Congress can\u2019t get its act together\" #DontDoubleMyRate",
  "id" : 198443395079872512,
  "created_at" : "2012-05-04 16:06:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "education",
      "indices" : [ 79, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198442767762989057",
  "text" : "RT @WHLive: President Obama: \"We cannot price the middle class out of a higher #education. We have to make college more affordable\" #Don ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "education",
        "indices" : [ 67, 77 ]
      }, {
        "text" : "DontDoubleMyRate",
        "indices" : [ 120, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "198442674267766784",
    "text" : "President Obama: \"We cannot price the middle class out of a higher #education. We have to make college more affordable\" #DontDoubleMyRate",
    "id" : 198442674267766784,
    "created_at" : "2012-05-04 16:03:15 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 198442767762989057,
  "created_at" : "2012-05-04 16:03:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 123, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198441932580597760",
  "text" : "President Obama: \"Higher education cannot be a luxury\u2013it\u2019s an economic imperative every American should be able to afford\" #DontDoubleMyRate",
  "id" : 198441932580597760,
  "created_at" : "2012-05-04 16:00:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jobs",
      "indices" : [ 83, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198441246438596609",
  "text" : "President Obama: \"This morning, we learned our economy created 130k private sector #jobs in April. The unemployment rate ticked down again\"",
  "id" : 198441246438596609,
  "created_at" : "2012-05-04 15:57:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 108, 115 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 116, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "198440066325020673",
  "text" : "Happening now: Obama speaks on the importance of affordable higher ed. Listen: http:\/\/t.co\/u95y7hhB Follow: @WHLive #DontDoubleMyRate",
  "id" : 198440066325020673,
  "created_at" : "2012-05-04 15:52:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DontDoubleMyRate",
      "indices" : [ 122, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/Cvszd1Y5",
      "expanded_url" : "http:\/\/wh.gov\/double",
      "display_url" : "wh.gov\/double"
    } ]
  },
  "geo" : { },
  "id_str" : "198423628327567361",
  "text" : "Today, the President speaks on the need to prevent student loan interest rates from doubling on 7\/1: http:\/\/t.co\/Cvszd1Y5 #DontDoubleMyRate",
  "id" : 198423628327567361,
  "created_at" : "2012-05-04 14:47:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DREAMAct",
      "indices" : [ 41, 50 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/LYPuN0Kl",
      "expanded_url" : "http:\/\/youtu.be\/clhQ_Qg9Usk?t=4m40s",
      "display_url" : "youtu.be\/clhQ_Qg9Usk?t=\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "198179203391303683",
  "text" : "\u201CNo is not an option. I want to sign the #DREAMAct into law. I\u2019ve got the pens all ready\" -President Obama: http:\/\/t.co\/LYPuN0Kl",
  "id" : 198179203391303683,
  "created_at" : "2012-05-03 22:36:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/198165038450753536\/photo\/1",
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/tgy5aaEn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AsAGDXRCQAErHFA.jpg",
      "id_str" : "198165038459142145",
      "id" : 198165038459142145,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AsAGDXRCQAErHFA.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      } ],
      "display_url" : "pic.twitter.com\/tgy5aaEn"
    } ],
    "hashtags" : [ {
      "text" : "Afghanistan",
      "indices" : [ 72, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 23, 43 ],
      "url" : "http:\/\/t.co\/H9LaFtTu",
      "expanded_url" : "http:\/\/wh.gov\/EMZ",
      "display_url" : "wh.gov\/EMZ"
    } ]
  },
  "geo" : { },
  "id_str" : "198165038450753536",
  "text" : "By the Numbers: 23,000 http:\/\/t.co\/H9LaFtTu 23,000 US troops will leave #Afghanistan by the end of the summer 2012: http:\/\/t.co\/tgy5aaEn",
  "id" : 198165038450753536,
  "created_at" : "2012-05-03 21:40:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "indices" : [ 3, 16 ],
      "id_str" : "78138151",
      "id" : 78138151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198158186979667969",
  "text" : "RT @lacasablanca: En vivo ahora mismo: El Presidente Obama habla en una recepci\u00F3n de Cinco de Mayo en el jard\u00EDn de rosas. Vea en vivo: h ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 137 ],
        "url" : "http:\/\/t.co\/vKkqXOpm",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "198158025553494017",
    "text" : "En vivo ahora mismo: El Presidente Obama habla en una recepci\u00F3n de Cinco de Mayo en el jard\u00EDn de rosas. Vea en vivo: http:\/\/t.co\/vKkqXOpm",
    "id" : 198158025553494017,
    "created_at" : "2012-05-03 21:12:09 +0000",
    "user" : {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "protected" : false,
      "id_str" : "78138151",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616360382911754241\/4Tfqcfie_normal.png",
      "id" : 78138151,
      "verified" : true
    }
  },
  "id" : 198158186979667969,
  "created_at" : "2012-05-03 21:12:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "198157950920040448",
  "text" : "Happening now: President Obama speaks at a Cinco de Mayo reception in the Rose Garden. Watch live: http:\/\/t.co\/u95y7hhB",
  "id" : 198157950920040448,
  "created_at" : "2012-05-03 21:11:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 3, 12 ],
      "id_str" : "36719281",
      "id" : 36719281
    }, {
      "name" : "BEYONC\u00C9",
      "screen_name" : "Beyonce",
      "indices" : [ 103, 111 ],
      "id_str" : "31239408",
      "id" : 31239408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198152448802701313",
  "text" : "RT @letsmove: How do you get kids around the country moving, jumping &amp; doing the dougie in unison? @Beyonce, naturally. http:\/\/t.co\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BEYONC\u00C9",
        "screen_name" : "Beyonce",
        "indices" : [ 89, 97 ],
        "id_str" : "31239408",
        "id" : 31239408
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LetsMove",
        "indices" : [ 131, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 110, 130 ],
        "url" : "http:\/\/t.co\/HmbCvxf2",
        "expanded_url" : "http:\/\/ow.ly\/aGEqV",
        "display_url" : "ow.ly\/aGEqV"
      } ]
    },
    "geo" : { },
    "id_str" : "198152305210699776",
    "text" : "How do you get kids around the country moving, jumping &amp; doing the dougie in unison? @Beyonce, naturally. http:\/\/t.co\/HmbCvxf2 #LetsMove",
    "id" : 198152305210699776,
    "created_at" : "2012-05-03 20:49:25 +0000",
    "user" : {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "protected" : false,
      "id_str" : "36719281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207340336\/780fc13e31b6fdd80bd57d000dc13838_normal.jpeg",
      "id" : 36719281,
      "verified" : true
    }
  },
  "id" : 198152448802701313,
  "created_at" : "2012-05-03 20:49:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 89, 98 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "198110481888718848",
  "text" : "RT @VP: PHOTO:VP at Cinco de Mayo breakfast w\/ Mexican Ambassador to US Arturo Sarukhan, @Interior Sec. Salazar &amp; Cecilia Munoz http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "US Dept of Interior",
        "screen_name" : "Interior",
        "indices" : [ 81, 90 ],
        "id_str" : "76348185",
        "id" : 76348185
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/198107319664513024\/photo\/1",
        "indices" : [ 124, 144 ],
        "url" : "http:\/\/t.co\/hb6OtcA7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ar_RjsBCEAIROyL.jpg",
        "id_str" : "198107319668707330",
        "id" : 198107319668707330,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ar_RjsBCEAIROyL.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 667,
          "resize" : "fit",
          "w" : 1000
        } ],
        "display_url" : "pic.twitter.com\/hb6OtcA7"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "198107319664513024",
    "text" : "PHOTO:VP at Cinco de Mayo breakfast w\/ Mexican Ambassador to US Arturo Sarukhan, @Interior Sec. Salazar &amp; Cecilia Munoz http:\/\/t.co\/hb6OtcA7",
    "id" : 198107319664513024,
    "created_at" : "2012-05-03 17:50:41 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 198110481888718848,
  "created_at" : "2012-05-03 18:03:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SummerJobsPlus",
      "indices" : [ 99, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http:\/\/t.co\/HhlHftIc",
      "expanded_url" : "http:\/\/youtu.be\/7UDJdFDmXB4",
      "display_url" : "youtu.be\/7UDJdFDmXB4"
    }, {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/z8LXMfrT",
      "expanded_url" : "http:\/\/www.wh.gov\/summerjobs",
      "display_url" : "wh.gov\/summerjobs"
    } ]
  },
  "geo" : { },
  "id_str" : "198102982242467840",
  "text" : "White House Official Cecilia Munoz talks about her first job: http:\/\/t.co\/HhlHftIc Find yours with #SummerJobsPlus: http:\/\/t.co\/z8LXMfrT",
  "id" : 198102982242467840,
  "created_at" : "2012-05-03 17:33:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SBA",
      "screen_name" : "SBAgov",
      "indices" : [ 60, 67 ],
      "id_str" : "153149305",
      "id" : 153149305
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smallbiz",
      "indices" : [ 12, 21 ]
    } ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http:\/\/t.co\/hIHOHNSu",
      "expanded_url" : "http:\/\/wh.gov\/UuA",
      "display_url" : "wh.gov\/UuA"
    }, {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/RCFptDD6",
      "expanded_url" : "http:\/\/youtu.be\/Jq-CqklLKXI",
      "display_url" : "youtu.be\/Jq-CqklLKXI"
    } ]
  },
  "geo" : { },
  "id_str" : "198093636888571904",
  "text" : "What's your #smallbiz story? http:\/\/t.co\/hIHOHNSu Check out @SBAgov's video challenge: http:\/\/t.co\/RCFptDD6",
  "id" : 198093636888571904,
  "created_at" : "2012-05-03 16:56:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "198078151530790912",
  "text" : "Today President Obama will speak at a Cinco de Mayo reception in the Rose Garden. Watch live @ 5ET: http:\/\/t.co\/u95y7hhB",
  "id" : 198078151530790912,
  "created_at" : "2012-05-03 15:54:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Monica Wilkinson",
      "screen_name" : "ciberch",
      "indices" : [ 3, 11 ],
      "id_str" : "16513061",
      "id" : 16513061
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 92, 103 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "Cloud Foundry",
      "screen_name" : "cloudfoundry",
      "indices" : [ 118, 131 ],
      "id_str" : "18697326",
      "id" : 18697326
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/7WpUgSXm",
      "expanded_url" : "http:\/\/1.usa.gov\/IWEXVN",
      "display_url" : "1.usa.gov\/IWEXVN"
    } ]
  },
  "geo" : { },
  "id_str" : "198054418929827842",
  "text" : "RT @ciberch: Innovative Summer Jobs  Apps Announced | The White House: http:\/\/t.co\/7WpUgSXm @whitehouse. Checkout our @cloudfoundry app  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 79, 90 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "Cloud Foundry",
        "screen_name" : "cloudfoundry",
        "indices" : [ 105, 118 ],
        "id_str" : "18697326",
        "id" : 18697326
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 78 ],
        "url" : "http:\/\/t.co\/7WpUgSXm",
        "expanded_url" : "http:\/\/1.usa.gov\/IWEXVN",
        "display_url" : "1.usa.gov\/IWEXVN"
      } ]
    },
    "geo" : { },
    "id_str" : "197778307184467968",
    "text" : "Innovative Summer Jobs  Apps Announced | The White House: http:\/\/t.co\/7WpUgSXm @whitehouse. Checkout our @cloudfoundry app \"Trabaja Friends\"",
    "id" : 197778307184467968,
    "created_at" : "2012-05-02 20:03:17 +0000",
    "user" : {
      "name" : "Monica Wilkinson",
      "screen_name" : "ciberch",
      "protected" : false,
      "id_str" : "16513061",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/494217287994322944\/AqAdBjqo_normal.jpeg",
      "id" : 16513061,
      "verified" : false
    }
  },
  "id" : 198054418929827842,
  "created_at" : "2012-05-03 14:20:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SummerJobsPlus",
      "indices" : [ 103, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/Rb6A6Uo8",
      "expanded_url" : "http:\/\/wh.gov\/summerjobs",
      "display_url" : "wh.gov\/summerjobs"
    } ]
  },
  "geo" : { },
  "id_str" : "197827266271645696",
  "text" : "Announcing 300,000 summer jobs for America's youth &amp; a new tool to access opportunities. Check out #SummerJobsPlus: http:\/\/t.co\/Rb6A6Uo8",
  "id" : 197827266271645696,
  "created_at" : "2012-05-02 23:17:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "#BlueHens",
      "screen_name" : "UDBlueHens",
      "indices" : [ 40, 51 ],
      "id_str" : "31540323",
      "id" : 31540323
    }, {
      "name" : "Tina Martin",
      "screen_name" : "UDCoachMartin",
      "indices" : [ 56, 70 ],
      "id_str" : "41594577",
      "id" : 41594577
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/VP\/status\/197813117584031745\/photo\/1",
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/sGVtijvp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ar7F-34CQAAqToY.jpg",
      "id_str" : "197813117592420352",
      "id" : 197813117592420352,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ar7F-34CQAAqToY.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/sGVtijvp"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197825499244924929",
  "text" : "RT @VP: PHOTO: VP Biden visits with the @UDBlueHens and @UDCoachMartin poolside at NAVOBS. http:\/\/t.co\/sGVtijvp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "#BlueHens",
        "screen_name" : "UDBlueHens",
        "indices" : [ 32, 43 ],
        "id_str" : "31540323",
        "id" : 31540323
      }, {
        "name" : "Tina Martin",
        "screen_name" : "UDCoachMartin",
        "indices" : [ 48, 62 ],
        "id_str" : "41594577",
        "id" : 41594577
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/197813117584031745\/photo\/1",
        "indices" : [ 83, 103 ],
        "url" : "http:\/\/t.co\/sGVtijvp",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ar7F-34CQAAqToY.jpg",
        "id_str" : "197813117592420352",
        "id" : 197813117592420352,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ar7F-34CQAAqToY.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/sGVtijvp"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "197813117584031745",
    "text" : "PHOTO: VP Biden visits with the @UDBlueHens and @UDCoachMartin poolside at NAVOBS. http:\/\/t.co\/sGVtijvp",
    "id" : 197813117584031745,
    "created_at" : "2012-05-02 22:21:38 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 197825499244924929,
  "created_at" : "2012-05-02 23:10:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jimmy fallon",
      "screen_name" : "jimmyfallon",
      "indices" : [ 18, 30 ],
      "id_str" : "15485441",
      "id" : 15485441
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SummerJobsPlus",
      "indices" : [ 94, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http:\/\/t.co\/kWOZ4AEw",
      "expanded_url" : "http:\/\/youtu.be\/nfNTZASJisw",
      "display_url" : "youtu.be\/nfNTZASJisw"
    }, {
      "indices" : [ 73, 93 ],
      "url" : "http:\/\/t.co\/Rb6A6Uo8",
      "expanded_url" : "http:\/\/wh.gov\/summerjobs",
      "display_url" : "wh.gov\/summerjobs"
    } ]
  },
  "geo" : { },
  "id_str" : "197804440047198209",
  "text" : "My first job with @jimmyfallon: http:\/\/t.co\/kWOZ4AEw Now, go find yours: http:\/\/t.co\/Rb6A6Uo8 #SummerJobsPlus",
  "id" : 197804440047198209,
  "created_at" : "2012-05-02 21:47:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CEQ",
      "screen_name" : "WhiteHouseCEQ",
      "indices" : [ 3, 17 ],
      "id_str" : "564106953",
      "id" : 564106953
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EarthDayEveryDay",
      "indices" : [ 85, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 123 ],
      "url" : "http:\/\/t.co\/euUGkV3C",
      "expanded_url" : "http:\/\/wh.gov\/sustainability-challenge",
      "display_url" : "wh.gov\/sustainability\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "197764524068175872",
  "text" : "RT @WhiteHouseCEQ: Mic check. We're live, and we come with an exciting announcement! #EarthDayEveryDay http:\/\/t.co\/euUGkV3C",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EarthDayEveryDay",
        "indices" : [ 66, 83 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 104 ],
        "url" : "http:\/\/t.co\/euUGkV3C",
        "expanded_url" : "http:\/\/wh.gov\/sustainability-challenge",
        "display_url" : "wh.gov\/sustainability\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "197763783639302144",
    "text" : "Mic check. We're live, and we come with an exciting announcement! #EarthDayEveryDay http:\/\/t.co\/euUGkV3C",
    "id" : 197763783639302144,
    "created_at" : "2012-05-02 19:05:34 +0000",
    "user" : {
      "name" : "CEQ",
      "screen_name" : "WhiteHouseCEQ",
      "protected" : false,
      "id_str" : "564106953",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2168238667\/CEQ_Seal_normal.png",
      "id" : 564106953,
      "verified" : true
    }
  },
  "id" : 197764524068175872,
  "created_at" : "2012-05-02 19:08:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/197683805044228096\/photo\/1",
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/ao9giX8M",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ar5QX5JCAAAjQrc.jpg",
      "id_str" : "197683805056794624",
      "id" : 197683805056794624,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ar5QX5JCAAAjQrc.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/ao9giX8M"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/y3m6x5tu",
      "expanded_url" : "http:\/\/wh.gov\/Ep6",
      "display_url" : "wh.gov\/Ep6"
    } ]
  },
  "geo" : { },
  "id_str" : "197683805044228096",
  "text" : "Photo Gallery: President Obama's trip to Afghanistan: http:\/\/t.co\/y3m6x5tu Obama greets US troops at Bagram Airfield: http:\/\/t.co\/ao9giX8M",
  "id" : 197683805044228096,
  "created_at" : "2012-05-02 13:47:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/197678153353797633\/photo\/1",
      "indices" : [ 121, 141 ],
      "url" : "http:\/\/t.co\/A6RS3GXr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ar5LO67CIAAC2kI.jpg",
      "id_str" : "197678153357991936",
      "id" : 197678153357991936,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ar5LO67CIAAC2kI.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/A6RS3GXr"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197678153353797633",
  "text" : "Photo: President Obama greets hospital staff &amp; presents Purple Hearts in the ICU at Bagram Air Field in Afghanistan: http:\/\/t.co\/A6RS3GXr",
  "id" : 197678153353797633,
  "created_at" : "2012-05-02 13:25:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/dX15BVqx",
      "expanded_url" : "http:\/\/youtu.be\/5l4TsjAKp18",
      "display_url" : "youtu.be\/5l4TsjAKp18"
    } ]
  },
  "geo" : { },
  "id_str" : "197489265750454272",
  "text" : "\"This time of war began in Afghanistan &amp; this is where it will end\" -President Obama in address to the nation: http:\/\/t.co\/dX15BVqx",
  "id" : 197489265750454272,
  "created_at" : "2012-05-02 00:54:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/dX15BVqx",
      "expanded_url" : "http:\/\/youtu.be\/5l4TsjAKp18",
      "display_url" : "youtu.be\/5l4TsjAKp18"
    } ]
  },
  "geo" : { },
  "id_str" : "197482932804390912",
  "text" : "Watch: President Obama\u2019s address to the nation from Afghanistan: http:\/\/t.co\/dX15BVqx",
  "id" : 197482932804390912,
  "created_at" : "2012-05-02 00:29:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/bPhKxavO",
      "expanded_url" : "http:\/\/wh.gov",
      "display_url" : "wh.gov"
    }, {
      "indices" : [ 124, 144 ],
      "url" : "http:\/\/t.co\/KaTSLHBr",
      "expanded_url" : "http:\/\/wh.gov\/EyT",
      "display_url" : "wh.gov\/EyT"
    } ]
  },
  "geo" : { },
  "id_str" : "197476138115792896",
  "text" : "Stay tuned for transcript &amp; video of President Obama's address from Afghanistan on http:\/\/t.co\/bPhKxavO. Excerpts here: http:\/\/t.co\/KaTSLHBr",
  "id" : 197476138115792896,
  "created_at" : "2012-05-02 00:02:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197471020700016640",
  "text" : "President Obama: \"This time of war began in Afghanistan &amp; this is where it will end.\"",
  "id" : 197471020700016640,
  "created_at" : "2012-05-01 23:42:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197470812515741697",
  "text" : "President Obama: \"As we emerge from a decade of conflict abroad &amp; economic crisis at home, it is time to renew America\"",
  "id" : 197470812515741697,
  "created_at" : "2012-05-01 23:41:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "veterans",
      "indices" : [ 35, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197470766349025281",
  "text" : "President Obama: \"We must give our #veterans &amp; military families the support they deserve &amp; the opportunities they have earned\"",
  "id" : 197470766349025281,
  "created_at" : "2012-05-01 23:41:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197470702843072512",
  "text" : "RT @WHLive: President Obama: \"This future is only within reach because of our men and women in uniform\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "197470671981387777",
    "text" : "President Obama: \"This future is only within reach because of our men and women in uniform\"",
    "id" : 197470671981387777,
    "created_at" : "2012-05-01 23:40:51 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 197470702843072512,
  "created_at" : "2012-05-01 23:40:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197470316736430080",
  "text" : "President Obama: \"I will not keep Americans in harm\u2019s way a single day longer than is absolutely required for our national security\"",
  "id" : 197470316736430080,
  "created_at" : "2012-05-01 23:39:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197470125425819648",
  "text" : "RT @WHLive: President Obama: \"Our goal is to destroy al Qaeda, and we are on a path to do exactly that\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "197470094404763650",
    "text" : "President Obama: \"Our goal is to destroy al Qaeda, and we are on a path to do exactly that\"",
    "id" : 197470094404763650,
    "created_at" : "2012-05-01 23:38:33 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 197470125425819648,
  "created_at" : "2012-05-01 23:38:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197469569806376960",
  "text" : "RT @WHLive: Obama: \"We are building an enduring partnership\" Agreement sends \"message to the Afghan people: as you stand up, you will no ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "197469515469176832",
    "text" : "Obama: \"We are building an enduring partnership\" Agreement sends \"message to the Afghan people: as you stand up, you will not stand alone\"",
    "id" : 197469515469176832,
    "created_at" : "2012-05-01 23:36:15 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 197469569806376960,
  "created_at" : "2012-05-01 23:36:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197469064224980993",
  "text" : "President Obama: \"One year ago, from a base here in Afghanistan, our troops launched the operation that killed Osama bin Laden\"",
  "id" : 197469064224980993,
  "created_at" : "2012-05-01 23:34:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197468950483841024",
  "text" : "President Obama: \"Over the last three years, the tide has turned. We broke the Taliban\u2019s momentum\"",
  "id" : 197468950483841024,
  "created_at" : "2012-05-01 23:34:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Afghanistan",
      "indices" : [ 25, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197468591610798081",
  "text" : "Obama: Historic US &amp; #Afghanistan agreement \"defines a new kind of relationship...a future in which the war ends &amp; a new chapter begins\"",
  "id" : 197468591610798081,
  "created_at" : "2012-05-01 23:32:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 111, 118 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "197468401252319233",
  "text" : "Happening now: President Obama addresses the nation from Afghanistan. Watch live: http:\/\/t.co\/u95y7hhB Follow: @WHLive",
  "id" : 197468401252319233,
  "created_at" : "2012-05-01 23:31:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 102, 109 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/197459672473669633\/photo\/1",
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/3WevmRj4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ar2EhqOCEAIGLl_.jpg",
      "id_str" : "197459672477863938",
      "id" : 197459672477863938,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ar2EhqOCEAIGLl_.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      }, {
        "h" : 346,
        "resize" : "fit",
        "w" : 615
      } ],
      "display_url" : "pic.twitter.com\/3WevmRj4"
    } ],
    "hashtags" : [ {
      "text" : "Afghanistan",
      "indices" : [ 49, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "197459672473669633",
  "text" : "WATCH: President Obama addresses the nation from #Afghanistan at 7:30ET: http:\/\/t.co\/u95y7hhB Follow: @WHLive http:\/\/t.co\/3WevmRj4",
  "id" : 197459672473669633,
  "created_at" : "2012-05-01 22:57:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "jearnest44",
      "indices" : [ 3, 14 ],
      "id_str" : "369238541",
      "id" : 369238541
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197459179764592641",
  "text" : "RT @jearnest44: In tonight's address to the nation, POTUS will say: \"This time of war began in Afghanistan, and this is where it will end.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "197453200427720704",
    "text" : "In tonight's address to the nation, POTUS will say: \"This time of war began in Afghanistan, and this is where it will end.\"",
    "id" : 197453200427720704,
    "created_at" : "2012-05-01 22:31:26 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "jearnest44",
      "protected" : false,
      "id_str" : "369238541",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1769108407\/Twitter_profile_photo_real_normal.JPG",
      "id" : 369238541,
      "verified" : true
    }
  },
  "id" : 197459179764592641,
  "created_at" : "2012-05-01 22:55:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kori Schulman",
      "screen_name" : "ks44",
      "indices" : [ 3, 8 ],
      "id_str" : "369246180",
      "id" : 369246180
    }, {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 73, 83 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHPhotowalk",
      "indices" : [ 47, 59 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/0r3rCtjI",
      "expanded_url" : "http:\/\/wh.gov\/EE5",
      "display_url" : "wh.gov\/EE5"
    } ]
  },
  "geo" : { },
  "id_str" : "197441561439633408",
  "text" : "RT @ks44: Check out highlights from our 1st G+ #WHPhotowalk &amp; thanks @petesouza for joining: http:\/\/t.co\/0r3rCtjI A favorite: http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "petesouza",
        "screen_name" : "petesouza",
        "indices" : [ 63, 73 ],
        "id_str" : "18215973",
        "id" : 18215973
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ks44\/status\/197440702299389953\/photo\/1",
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/lBg8x7Xv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ar1zRc0CQAA-qvU.jpg",
        "id_str" : "197440702303584256",
        "id" : 197440702303584256,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ar1zRc0CQAA-qvU.jpg",
        "sizes" : [ {
          "h" : 213,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 628,
          "resize" : "fit",
          "w" : 1003
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 376,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 628,
          "resize" : "fit",
          "w" : 1003
        } ],
        "display_url" : "pic.twitter.com\/lBg8x7Xv"
      } ],
      "hashtags" : [ {
        "text" : "WHPhotowalk",
        "indices" : [ 37, 49 ]
      } ],
      "urls" : [ {
        "indices" : [ 87, 107 ],
        "url" : "http:\/\/t.co\/0r3rCtjI",
        "expanded_url" : "http:\/\/wh.gov\/EE5",
        "display_url" : "wh.gov\/EE5"
      } ]
    },
    "geo" : { },
    "id_str" : "197440702299389953",
    "text" : "Check out highlights from our 1st G+ #WHPhotowalk &amp; thanks @petesouza for joining: http:\/\/t.co\/0r3rCtjI A favorite: http:\/\/t.co\/lBg8x7Xv",
    "id" : 197440702299389953,
    "created_at" : "2012-05-01 21:41:47 +0000",
    "user" : {
      "name" : "Kori Schulman",
      "screen_name" : "ks44",
      "protected" : false,
      "id_str" : "369246180",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/667876153793859584\/DV7HzP-1_normal.jpg",
      "id" : 369246180,
      "verified" : true
    }
  },
  "id" : 197441561439633408,
  "created_at" : "2012-05-01 21:45:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/8k7xC1nk",
      "expanded_url" : "http:\/\/wh.gov\/Emf",
      "display_url" : "wh.gov\/Emf"
    } ]
  },
  "geo" : { },
  "id_str" : "197429927543455744",
  "text" : "Today, President Obama &amp; President Karzai signed the U.S.-Afghanistan Strategic Partnership Agreement. Fact Sheet: http:\/\/t.co\/8k7xC1nk",
  "id" : 197429927543455744,
  "created_at" : "2012-05-01 20:58:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/u95y7hhB",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "197426190682832897",
  "text" : "President Obama will address the nation tonight from Bagram Air Base in Afghanistan. Watch live at 7:30ET at http:\/\/t.co\/u95y7hhB",
  "id" : 197426190682832897,
  "created_at" : "2012-05-01 20:44:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Embassy Kabul",
      "screen_name" : "USEmbassyKabul",
      "indices" : [ 3, 18 ],
      "id_str" : "21645304",
      "id" : 21645304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197421704291696644",
  "text" : "RT @USEmbassyKabul: Karzai emphasized partnership w\/US, gratitude for US efforts; Obama stressed shared sacrifice and the hope for a mor ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "197416227143024640",
    "text" : "Karzai emphasized partnership w\/US, gratitude for US efforts; Obama stressed shared sacrifice and the hope for a more peaceful future.",
    "id" : 197416227143024640,
    "created_at" : "2012-05-01 20:04:31 +0000",
    "user" : {
      "name" : "U.S. Embassy Kabul",
      "screen_name" : "USEmbassyKabul",
      "protected" : false,
      "id_str" : "21645304",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000141672960\/83e2cd1f8196ea753e7dcf6bf4c6969e_normal.png",
      "id" : 21645304,
      "verified" : true
    }
  },
  "id" : 197421704291696644,
  "created_at" : "2012-05-01 20:26:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197420628201058304",
  "text" : "RT @pfeiffer44: In Kabul, President Obama is abt to sign the strategic partnership agreement that will help bring the war to a close",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "197410896472051713",
    "text" : "In Kabul, President Obama is abt to sign the strategic partnership agreement that will help bring the war to a close",
    "id" : 197410896472051713,
    "created_at" : "2012-05-01 19:43:20 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 197420628201058304,
  "created_at" : "2012-05-01 20:22:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197403947357569024",
  "text" : "President Obama just arrived in Afghanistan for a visit that will culminate in a live address to the American people at 7:30ET.",
  "id" : 197403947357569024,
  "created_at" : "2012-05-01 19:15:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ray LaHood",
      "screen_name" : "RayLaHood",
      "indices" : [ 3, 13 ],
      "id_str" : "1563604279",
      "id" : 1563604279
    }, {
      "name" : "Stop the Texts",
      "screen_name" : "StoptheTexts",
      "indices" : [ 20, 33 ],
      "id_str" : "378031834",
      "id" : 378031834
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "stopthetextsday",
      "indices" : [ 64, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197400643625943041",
  "text" : "RT @RayLaHood: Join @stopthetexts for Town Hall @ 3 pm ET.  Use #stopthetextsday to tweet ideas to help people stop texting &amp; driving.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stop the Texts",
        "screen_name" : "StoptheTexts",
        "indices" : [ 5, 18 ],
        "id_str" : "378031834",
        "id" : 378031834
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "stopthetextsday",
        "indices" : [ 49, 65 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "197386781006639105",
    "text" : "Join @stopthetexts for Town Hall @ 3 pm ET.  Use #stopthetextsday to tweet ideas to help people stop texting &amp; driving.",
    "id" : 197386781006639105,
    "created_at" : "2012-05-01 18:07:30 +0000",
    "user" : {
      "name" : "Anthony Foxx",
      "screen_name" : "SecretaryFoxx",
      "protected" : false,
      "id_str" : "43920155",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/746015409707622400\/clFVYNWs_normal.jpg",
      "id" : 43920155,
      "verified" : true
    }
  },
  "id" : 197400643625943041,
  "created_at" : "2012-05-01 19:02:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/yQSezkjS",
      "expanded_url" : "http:\/\/youtu.be\/ZNYmK19-d0U",
      "display_url" : "youtu.be\/ZNYmK19-d0U"
    } ]
  },
  "geo" : { },
  "id_str" : "197367911290126337",
  "text" : "\"Justice has been done\" -President Obama speaks to the American people on the death of Osama bin Laden 1 year ago: http:\/\/t.co\/yQSezkjS",
  "id" : 197367911290126337,
  "created_at" : "2012-05-01 16:52:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 11, 19 ],
      "id_str" : "783214",
      "id" : 783214
    }, {
      "name" : "sarlynnmarmi19",
      "screen_name" : "DavidAgnew44",
      "indices" : [ 50, 63 ],
      "id_str" : "2982158781",
      "id" : 2982158781
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 90, 101 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "197362757409046528",
  "text" : "Welcome to @Twitter Intergovernmental Affairs Dir @DavidAgnew44! Follow for latest on how @whitehouse is working w local, tribal &amp; state gov",
  "id" : 197362757409046528,
  "created_at" : "2012-05-01 16:32:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
} ]