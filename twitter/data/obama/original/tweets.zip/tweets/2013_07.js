Grailbird.data.tweets_2013_07 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    }, {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 15, 24 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Energy",
      "indices" : [ 79, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/a532uLZG3w",
      "expanded_url" : "http:\/\/on.doi.gov\/1689met",
      "display_url" : "on.doi.gov\/1689met"
    } ]
  },
  "geo" : { },
  "id_str" : "362720802078466048",
  "text" : "RT @Interior: .@Interior Holds First-Ever Competitive Lease Sale for Renewable #Energy in Federal Waters: http:\/\/t.co\/a532uLZG3w",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/bitly.com\/\" rel=\"nofollow\"\u003EBitly Composer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "US Dept of Interior",
        "screen_name" : "Interior",
        "indices" : [ 1, 10 ],
        "id_str" : "76348185",
        "id" : 76348185
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Energy",
        "indices" : [ 65, 72 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/a532uLZG3w",
        "expanded_url" : "http:\/\/on.doi.gov\/1689met",
        "display_url" : "on.doi.gov\/1689met"
      } ]
    },
    "geo" : { },
    "id_str" : "362691892904857601",
    "text" : ".@Interior Holds First-Ever Competitive Lease Sale for Renewable #Energy in Federal Waters: http:\/\/t.co\/a532uLZG3w",
    "id" : 362691892904857601,
    "created_at" : "2013-07-31 21:51:00 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 362720802078466048,
  "created_at" : "2013-07-31 23:45:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 119, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362710047081508864",
  "text" : "\"Keeping college affordable is imperative to our individual and national growth.\" \u2014Leisa, a teacher with student loans #ABetterBargain",
  "id" : 362710047081508864,
  "created_at" : "2013-07-31 23:03:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362704405453635584",
  "text" : "\"Obama's North Star is mine, too. We need to concentrate on the middle-class foundations that made this country...prosperous.\" \u2014Ann, NJ",
  "id" : 362704405453635584,
  "created_at" : "2013-07-31 22:40:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 129, 144 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362699396535689217",
  "text" : "\"Opportunity for those who work hard &amp; play by the rules is an American principle. It's time to get back to it\" \u2014Michael, IA #ABetterBargain",
  "id" : 362699396535689217,
  "created_at" : "2013-07-31 22:20:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/362695087077085184\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/5EUlNCCly8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BQiNQpPCUAAozxC.jpg",
      "id_str" : "362695087089668096",
      "id" : 362695087089668096,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQiNQpPCUAAozxC.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/5EUlNCCly8"
    } ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 55, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/WqCDosmNVQ",
      "expanded_url" : "http:\/\/at.wh.gov\/nvXCD",
      "display_url" : "at.wh.gov\/nvXCD"
    } ]
  },
  "geo" : { },
  "id_str" : "362695087077085184",
  "text" : "Share why you stand with President Obama in support of #ABetterBargain for the middle class: http:\/\/t.co\/WqCDosmNVQ, http:\/\/t.co\/5EUlNCCly8",
  "id" : 362695087077085184,
  "created_at" : "2013-07-31 22:03:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "indices" : [ 3, 13 ],
      "id_str" : "1613223313",
      "id" : 1613223313
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 53, 64 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "UConn Women's Hoops",
      "screen_name" : "UConnWBB",
      "indices" : [ 124, 133 ],
      "id_str" : "242785840",
      "id" : 242785840
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362659634596679680",
  "text" : "RT @Cecilia44: Today POTUS welcomes UConn Huskies to @whitehouse. Star athletes and role models to young women everywhere!  @UConnWBB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 38, 49 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "UConn Women's Hoops",
        "screen_name" : "UConnWBB",
        "indices" : [ 109, 118 ],
        "id_str" : "242785840",
        "id" : 242785840
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "362642593626071040",
    "text" : "Today POTUS welcomes UConn Huskies to @whitehouse. Star athletes and role models to young women everywhere!  @UConnWBB",
    "id" : 362642593626071040,
    "created_at" : "2013-07-31 18:35:06 +0000",
    "user" : {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "protected" : false,
      "id_str" : "1613223313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000172019215\/ed65eda76f51213f91b33edbaa62054c_normal.jpeg",
      "id" : 1613223313,
      "verified" : true
    }
  },
  "id" : 362659634596679680,
  "created_at" : "2013-07-31 19:42:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sophia Bush",
      "screen_name" : "SophiaBush",
      "indices" : [ 3, 14 ],
      "id_str" : "97082147",
      "id" : 97082147
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dosomething",
      "indices" : [ 24, 36 ]
    }, {
      "text" : "healthcare",
      "indices" : [ 82, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362646392956657666",
  "text" : "RT @SophiaBush: Want to #dosomething awesome for your future? Get info on all the #healthcare benefits avail for you starting 10\/1! Check @\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "HealthCare.gov",
        "screen_name" : "HealthCareGov",
        "indices" : [ 122, 136 ],
        "id_str" : "86697288",
        "id" : 86697288
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "dosomething",
        "indices" : [ 8, 20 ]
      }, {
        "text" : "healthcare",
        "indices" : [ 66, 77 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "362625476570787842",
    "text" : "Want to #dosomething awesome for your future? Get info on all the #healthcare benefits avail for you starting 10\/1! Check @healthcaregov",
    "id" : 362625476570787842,
    "created_at" : "2013-07-31 17:27:05 +0000",
    "user" : {
      "name" : "Sophia Bush",
      "screen_name" : "SophiaBush",
      "protected" : false,
      "id_str" : "97082147",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797046839824515072\/mKtkYiWl_normal.jpg",
      "id" : 97082147,
      "verified" : true
    }
  },
  "id" : 362646392956657666,
  "created_at" : "2013-07-31 18:50:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/y8Mwh2pNGG",
      "expanded_url" : "http:\/\/at.wh.gov\/nvvXK",
      "display_url" : "at.wh.gov\/nvvXK"
    } ]
  },
  "geo" : { },
  "id_str" : "362638947819601920",
  "text" : "Now available for a free download: President Obama's Kindle Singles Interview \u2014&gt; http:\/\/t.co\/y8Mwh2pNGG",
  "id" : 362638947819601920,
  "created_at" : "2013-07-31 18:20:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/362628824611049472\/photo\/1",
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/USAT8A6JJg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BQhQ_qSCUAALEfG.png",
      "id_str" : "362628824615243776",
      "id" : 362628824615243776,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQhQ_qSCUAALEfG.png",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 611,
        "resize" : "fit",
        "w" : 611
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 611,
        "resize" : "fit",
        "w" : 611
      } ],
      "display_url" : "pic.twitter.com\/USAT8A6JJg"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362628824611049472",
  "text" : "The First Paws. http:\/\/t.co\/USAT8A6JJg",
  "id" : 362628824611049472,
  "created_at" : "2013-07-31 17:40:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/hZAYJy6clD",
      "expanded_url" : "http:\/\/instagram.com\/p\/cb30r-wiim\/",
      "display_url" : "instagram.com\/p\/cb30r-wiim\/"
    } ]
  },
  "geo" : { },
  "id_str" : "362611092045836288",
  "text" : "Watch President Obama head down to the Capitol this morning to meet with members of Congress \u2014&gt; http:\/\/t.co\/hZAYJy6clD",
  "id" : 362611092045836288,
  "created_at" : "2013-07-31 16:29:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/J418DLHpVI",
      "expanded_url" : "http:\/\/at.wh.gov\/nv5Bx",
      "display_url" : "at.wh.gov\/nv5Bx"
    } ]
  },
  "geo" : { },
  "id_str" : "362600073210765312",
  "text" : "Obama: \"If we\u2019re going to give businesses a better deal\u2014then we\u2019re also going to have to give workers a better deal.\" http:\/\/t.co\/J418DLHpVI",
  "id" : 362600073210765312,
  "created_at" : "2013-07-31 15:46:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/362589512825708545\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/9qU5KTXKUI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BQgtPafCIAAe0K6.jpg",
      "id_str" : "362589512834097152",
      "id" : 362589512834097152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQgtPafCIAAe0K6.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/9qU5KTXKUI"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362589512825708545",
  "text" : "RT if you support President Obama's plan to create good jobs with fair wages and simplify our tax code. http:\/\/t.co\/9qU5KTXKUI",
  "id" : 362589512825708545,
  "created_at" : "2013-07-31 15:04:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/emfFxWFSpx",
      "expanded_url" : "http:\/\/at.wh.gov\/nuQO4",
      "display_url" : "at.wh.gov\/nuQO4"
    } ]
  },
  "geo" : { },
  "id_str" : "362578529273135105",
  "text" : "\"We should be doing everything we can as a country to create more good jobs that pay good wages. Period.\" \u2014Obama: http:\/\/t.co\/emfFxWFSpx",
  "id" : 362578529273135105,
  "created_at" : "2013-07-31 14:20:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "jearnest44",
      "indices" : [ 3, 14 ],
      "id_str" : "369238541",
      "id" : 369238541
    }, {
      "name" : "Morning Joe",
      "screen_name" : "Morning_Joe",
      "indices" : [ 26, 38 ],
      "id_str" : "254117355",
      "id" : 254117355
    }, {
      "name" : "Saxby Chambliss",
      "screen_name" : "SaxbyChambliss",
      "indices" : [ 70, 85 ],
      "id_str" : "538185166",
      "id" : 538185166
    }, {
      "name" : "Rep. Tom Cole",
      "screen_name" : "TomColeOK04",
      "indices" : [ 105, 117 ],
      "id_str" : "23124635",
      "id" : 23124635
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362570063137607680",
  "text" : "RT @jearnest44: GOPers on @Morning_Joe encouraged by Obama jobs idea. @SaxbyChambliss \"right step\" &amp; @tomcoleok04 \"there is a way to find a\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Morning Joe",
        "screen_name" : "Morning_Joe",
        "indices" : [ 10, 22 ],
        "id_str" : "254117355",
        "id" : 254117355
      }, {
        "name" : "Saxby Chambliss",
        "screen_name" : "SaxbyChambliss",
        "indices" : [ 54, 69 ],
        "id_str" : "538185166",
        "id" : 538185166
      }, {
        "name" : "Rep. Tom Cole",
        "screen_name" : "TomColeOK04",
        "indices" : [ 89, 101 ],
        "id_str" : "23124635",
        "id" : 23124635
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "362551603389153280",
    "text" : "GOPers on @Morning_Joe encouraged by Obama jobs idea. @SaxbyChambliss \"right step\" &amp; @tomcoleok04 \"there is a way to find a bargain here\"",
    "id" : 362551603389153280,
    "created_at" : "2013-07-31 12:33:32 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "jearnest44",
      "protected" : false,
      "id_str" : "369238541",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1769108407\/Twitter_profile_photo_real_normal.JPG",
      "id" : 369238541,
      "verified" : true
    }
  },
  "id" : 362570063137607680,
  "created_at" : "2013-07-31 13:46:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 60, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/t0Mib5yODu",
      "expanded_url" : "http:\/\/at.wh.gov\/nsXIM",
      "display_url" : "at.wh.gov\/nsXIM"
    } ]
  },
  "geo" : { },
  "id_str" : "362366092263432192",
  "text" : "FACT: More jobs and more hours for restaurant workers since #Obamacare became law. Watch \u2014&gt; http:\/\/t.co\/t0Mib5yODu",
  "id" : 362366092263432192,
  "created_at" : "2013-07-31 00:16:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/Cx8wsWW0o9",
      "expanded_url" : "http:\/\/at.wh.gov\/ntJH2",
      "display_url" : "at.wh.gov\/ntJH2"
    } ]
  },
  "geo" : { },
  "id_str" : "362355886276091904",
  "text" : "\"Nobody who works full-time in America should have to live in poverty.\" \u2014President Obama on raising the minimum wage: http:\/\/t.co\/Cx8wsWW0o9",
  "id" : 362355886276091904,
  "created_at" : "2013-07-30 23:35:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/362344759269945344\/photo\/1",
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/IPgpU2o7C2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BQdOo4bCcAAR3wJ.jpg",
      "id_str" : "362344759274139648",
      "id" : 362344759274139648,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQdOo4bCcAAR3wJ.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/IPgpU2o7C2"
    } ],
    "hashtags" : [ {
      "text" : "TransformationTuesday",
      "indices" : [ 57, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362344759269945344",
  "text" : "We've come a long way\u2014but there's still more work to do. #TransformationTuesday, http:\/\/t.co\/IPgpU2o7C2",
  "id" : 362344759269945344,
  "created_at" : "2013-07-30 22:51:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 34, 37 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/362338979229597697\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/Ed7xDTVvkk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BQdJYcGCAAAHNrr.jpg",
      "id_str" : "362338979233792000",
      "id" : 362338979233792000,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQdJYcGCAAAHNrr.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Ed7xDTVvkk"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362338979229597697",
  "text" : "This morning, President Obama and @VP Biden met with Israeli and Palestinian negotiators on resuming peace talks: http:\/\/t.co\/Ed7xDTVvkk",
  "id" : 362338979229597697,
  "created_at" : "2013-07-30 22:28:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/362318711438315522\/photo\/1",
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/dXhpvgDkNq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BQc28ssCEAQliyc.jpg",
      "id_str" : "362318711442509828",
      "id" : 362318711442509828,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQc28ssCEAQliyc.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/dXhpvgDkNq"
    } ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 74, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/t0Mib5yODu",
      "expanded_url" : "http:\/\/at.wh.gov\/nsXIM",
      "display_url" : "at.wh.gov\/nsXIM"
    } ]
  },
  "geo" : { },
  "id_str" : "362318711438315522",
  "text" : "Watch this GIF on increased jobs &amp; hours for restaurant workers since #Obamacare became law: http:\/\/t.co\/t0Mib5yODu, http:\/\/t.co\/dXhpvgDkNq",
  "id" : 362318711438315522,
  "created_at" : "2013-07-30 21:08:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/362306988048265217\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/EXwV8r7xkw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BQcsSTrCMAEiw9n.jpg",
      "id_str" : "362306988056653825",
      "id" : 362306988056653825,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQcsSTrCMAEiw9n.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/EXwV8r7xkw"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362306988048265217",
  "text" : "RT so your friends know about President Obama's plan to create good jobs with fair wages and simplify our tax code: http:\/\/t.co\/EXwV8r7xkw",
  "id" : 362306988048265217,
  "created_at" : "2013-07-30 20:21:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 32, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362294502142124032",
  "text" : "Just spoke in Chattanooga about #ABetterBargain for the middle class, and it begins with more good jobs. \u2013bo",
  "id" : 362294502142124032,
  "created_at" : "2013-07-30 19:31:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 18, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362279833759260672",
  "text" : "President Obama: \"#ABetterBargain for the middle class. An economy that grows from the middle out...that's where America needs to go.\"",
  "id" : 362279833759260672,
  "created_at" : "2013-07-30 18:33:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 108, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362278990230200320",
  "text" : "Obama on the House GOP: \"Wasting the country\u2019s time by taking something like 40 meaningless votes to repeal #Obamacare is not a jobs plan.\"",
  "id" : 362278990230200320,
  "created_at" : "2013-07-30 18:30:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 116, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362278120633540611",
  "text" : "President Obama: \"If we\u2019re going to give businesses a better deal, we\u2019re going to give workers a better deal, too.\" #ABetterBargain",
  "id" : 362278120633540611,
  "created_at" : "2013-07-30 18:26:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 115, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362277684551761920",
  "text" : "President Obama: \"If folks in Washington want a 'grand bargain,' how about a grand bargain for middle-class jobs?\" #ABetterBargain",
  "id" : 362277684551761920,
  "created_at" : "2013-07-30 18:25:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362276878146478081",
  "text" : "President Obama: \"For much of the past two years, Washington has taken its eye off the ball when it comes to the middle class.\"",
  "id" : 362276878146478081,
  "created_at" : "2013-07-30 18:21:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 117, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362276409948909570",
  "text" : "President Obama on raising the minimum wage: \"Nobody who works full-time in America should have to live in poverty.\" #ABetterBargain",
  "id" : 362276409948909570,
  "created_at" : "2013-07-30 18:20:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362275993458720769",
  "text" : "RT @WHLive: Obama: \"I\u2019ll bring together the CEOs and companies that are putting in place the best practices for recruiting, training &amp; hiri\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "362275957467398146",
    "text" : "Obama: \"I\u2019ll bring together the CEOs and companies that are putting in place the best practices for recruiting, training &amp; hiring workers.\"",
    "id" : 362275957467398146,
    "created_at" : "2013-07-30 18:18:13 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 362275993458720769,
  "created_at" : "2013-07-30 18:18:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362275555057471488",
  "text" : "Obama: \"Now is the time to double down on renewables and biofuels...and the research that will shift our cars and trucks off oil for good.\"",
  "id" : 362275555057471488,
  "created_at" : "2013-07-30 18:16:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362275158708326401",
  "text" : "RT @WHLive: President Obama: \"Congress should pass my 'Fix-It-First' plan to put people to work immediately on our most urgent repairs.\" #A\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ABetterBargain",
        "indices" : [ 125, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "362275123203547138",
    "text" : "President Obama: \"Congress should pass my 'Fix-It-First' plan to put people to work immediately on our most urgent repairs.\" #ABetterBargain",
    "id" : 362275123203547138,
    "created_at" : "2013-07-30 18:14:54 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 362275158708326401,
  "created_at" : "2013-07-30 18:15:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362274774199713792",
  "text" : "President Obama on rebuilding our infrastructure: \"Let\u2019s put more construction workers back on the job doing the work America needs done.\"",
  "id" : 362274774199713792,
  "created_at" : "2013-07-30 18:13:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 119, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362274396242583552",
  "text" : "Obama on simplifying our tax code: \"Let\u2019s offer new tax incentives for manufacturers that bring jobs back to America.\" #ABetterBargain",
  "id" : 362274396242583552,
  "created_at" : "2013-07-30 18:12:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 125, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362273517418455040",
  "text" : "President Obama: \"We should be doing everything we can as a country to create more good jobs that pay decent wages. Period.\" #ABetterBargain",
  "id" : 362273517418455040,
  "created_at" : "2013-07-30 18:08:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362273221527089154",
  "text" : "Obama: \"I\u2019ve come to Chattanooga today to talk about that first and most important cornerstone of a middle-class life: A good job.\"",
  "id" : 362273221527089154,
  "created_at" : "2013-07-30 18:07:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 19, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362272927258918917",
  "text" : "President Obama on #ABetterBargain for the middle class: \"A good job with good wages. A good education. A home to call your own.\"",
  "id" : 362272927258918917,
  "created_at" : "2013-07-30 18:06:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/362272417990725632\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/J00hV6daZ7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BQcM2ELCUAEHXSy.jpg",
      "id_str" : "362272417999114241",
      "id" : 362272417999114241,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQcM2ELCUAEHXSy.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/J00hV6daZ7"
    } ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 100, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362272417990725632",
  "text" : "President Obama: \"Today, our businesses have created 7.2 million new jobs over the last 40 months.\" #ABetterBargain http:\/\/t.co\/J00hV6daZ7",
  "id" : 362272417990725632,
  "created_at" : "2013-07-30 18:04:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 97, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362272015459160064",
  "text" : "President Obama: \"I\u2019ve come here today to talk about...what we need to do as a country to secure #ABetterBargain for the middle class.\"",
  "id" : 362272015459160064,
  "created_at" : "2013-07-30 18:02:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 112, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362271506627174403",
  "text" : "President Obama: \"Hello, Chattanooga! It\u2019s great to be back in Tennessee, and it\u2019s great to be here at Amazon.\" #ABetterBargain",
  "id" : 362271506627174403,
  "created_at" : "2013-07-30 18:00:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/fgWNis1VsU",
      "expanded_url" : "http:\/\/at.wh.gov\/nsYZO",
      "display_url" : "at.wh.gov\/nsYZO"
    } ]
  },
  "geo" : { },
  "id_str" : "362271015658729472",
  "text" : "Happening now: President Obama speaks on his plan to create good jobs with fair wages and simplify our tax code \u2014&gt; http:\/\/t.co\/fgWNis1VsU",
  "id" : 362271015658729472,
  "created_at" : "2013-07-30 17:58:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/fgWNis1VsU",
      "expanded_url" : "http:\/\/at.wh.gov\/nsYZO",
      "display_url" : "at.wh.gov\/nsYZO"
    } ]
  },
  "geo" : { },
  "id_str" : "362257917677797377",
  "text" : "At 2:30pm ET, President Obama speaks on his plan to create good jobs with fair wages and simplify our tax code \u2014&gt; http:\/\/t.co\/fgWNis1VsU",
  "id" : 362257917677797377,
  "created_at" : "2013-07-30 17:06:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 123, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/Q3zx97o0oq",
      "expanded_url" : "http:\/\/at.wh.gov\/nsONz",
      "display_url" : "at.wh.gov\/nsONz"
    } ]
  },
  "geo" : { },
  "id_str" : "362244454226198528",
  "text" : "\"Reducing poverty, reducing inequality, growing opportunity\u2014that's what we need.\" \u2014President Obama: http:\/\/t.co\/Q3zx97o0oq #ABetterBargain",
  "id" : 362244454226198528,
  "created_at" : "2013-07-30 16:13:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "jearnest44",
      "indices" : [ 3, 14 ],
      "id_str" : "369238541",
      "id" : 369238541
    }, {
      "name" : "Mark Murray",
      "screen_name" : "mmurraypolitics",
      "indices" : [ 45, 61 ],
      "id_str" : "92079350",
      "id" : 92079350
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362226011246559233",
  "text" : "RT @jearnest44: Makes it tough to bargain MT @mmurraypolitics Once again, you have the WH making an offer; GOP rejecting it and not making \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mark Murray",
        "screen_name" : "mmurraypolitics",
        "indices" : [ 29, 45 ],
        "id_str" : "92079350",
        "id" : 92079350
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "362210590741118977",
    "text" : "Makes it tough to bargain MT @mmurraypolitics Once again, you have the WH making an offer; GOP rejecting it and not making a counteroffer",
    "id" : 362210590741118977,
    "created_at" : "2013-07-30 13:58:29 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "jearnest44",
      "protected" : false,
      "id_str" : "369238541",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1769108407\/Twitter_profile_photo_real_normal.JPG",
      "id" : 369238541,
      "verified" : true
    }
  },
  "id" : 362226011246559233,
  "created_at" : "2013-07-30 14:59:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/c5F4EiVCAA",
      "expanded_url" : "http:\/\/at.wh.gov\/nskRk",
      "display_url" : "at.wh.gov\/nskRk"
    } ]
  },
  "geo" : { },
  "id_str" : "362218597885558784",
  "text" : "Chattanooga mayor: \"The President\u2019s plan ignites a needed discussion on how we...create new ladders of opportunity.\" http:\/\/t.co\/c5F4EiVCAA",
  "id" : 362218597885558784,
  "created_at" : "2013-07-30 14:30:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/GQdrQ4Yxqr",
      "expanded_url" : "http:\/\/at.wh.gov\/nsjKh",
      "display_url" : "at.wh.gov\/nsjKh"
    } ]
  },
  "geo" : { },
  "id_str" : "362203019602956288",
  "text" : "RT to share the news: President Obama will call for a grand bargain focused on middle-class jobs today in Tennessee: http:\/\/t.co\/GQdrQ4Yxqr",
  "id" : 362203019602956288,
  "created_at" : "2013-07-30 13:28:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362197298329026560",
  "text" : "RT @pfeiffer44: Worth a read: Today,President Obama will call for a Grand Bargain focused on Middle Class Jobs in speech in Tennessee http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/B4eKfVXkJj",
        "expanded_url" : "http:\/\/shar.es\/kFzsS",
        "display_url" : "shar.es\/kFzsS"
      } ]
    },
    "geo" : { },
    "id_str" : "362153245457653760",
    "text" : "Worth a read: Today,President Obama will call for a Grand Bargain focused on Middle Class Jobs in speech in Tennessee http:\/\/t.co\/B4eKfVXkJj",
    "id" : 362153245457653760,
    "created_at" : "2013-07-30 10:10:36 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 362197298329026560,
  "created_at" : "2013-07-30 13:05:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "indices" : [ 3, 18 ],
      "id_str" : "19674502",
      "id" : 19674502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "362006152403357696",
  "text" : "RT @AmbassadorRice: Israeli-Palestinian meetings tonight &amp; tomorrow are an important step towards peace, brought about by months &amp; years of\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "362002195186585601",
    "text" : "Israeli-Palestinian meetings tonight &amp; tomorrow are an important step towards peace, brought about by months &amp; years of hard work.",
    "id" : 362002195186585601,
    "created_at" : "2013-07-30 00:10:23 +0000",
    "user" : {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "protected" : false,
      "id_str" : "19674502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2245433940\/297681_10150417294436240_295915266239_10074516_1895344954_n_normal.jpg",
      "id" : 19674502,
      "verified" : true
    }
  },
  "id" : 362006152403357696,
  "created_at" : "2013-07-30 00:26:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/UenxNV4HmC",
      "expanded_url" : "http:\/\/at.wh.gov\/nrlh2",
      "display_url" : "at.wh.gov\/nrlh2"
    } ]
  },
  "geo" : { },
  "id_str" : "361999236453244928",
  "text" : "President Obama: James Comey \"has repeatedly demonstrated his commitment to defending America\u2019s security and ideals.\" http:\/\/t.co\/UenxNV4HmC",
  "id" : 361999236453244928,
  "created_at" : "2013-07-29 23:58:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 123, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/HvgMR4egpk",
      "expanded_url" : "http:\/\/at.wh.gov\/nr7j7",
      "display_url" : "at.wh.gov\/nr7j7"
    } ]
  },
  "geo" : { },
  "id_str" : "361981574411075585",
  "text" : "FACT: Health care costs rose at the slowest rate in nearly 50 years from May 2012 to May 2013 \u2014&gt; http:\/\/t.co\/HvgMR4egpk #Obamacare",
  "id" : 361981574411075585,
  "created_at" : "2013-07-29 22:48:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 21, 26 ],
      "id_str" : "11348282",
      "id" : 11348282
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/361971261980676099\/photo\/1",
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/q2Eo0pmF1S",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BQX68emCEAAyXpt.jpg",
      "id_str" : "361971261984870400",
      "id" : 361971261984870400,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQX68emCEAAyXpt.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 683
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 683
      } ],
      "display_url" : "pic.twitter.com\/q2Eo0pmF1S"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "361971261980676099",
  "text" : "Happy 55th birthday, @NASA! http:\/\/t.co\/q2Eo0pmF1S",
  "id" : 361971261980676099,
  "created_at" : "2013-07-29 22:07:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 3, 12 ],
      "id_str" : "36719281",
      "id" : 36719281
    }, {
      "name" : "SFGiants",
      "screen_name" : "SFGiants",
      "indices" : [ 40, 49 ],
      "id_str" : "43024351",
      "id" : 43024351
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 62, 73 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "361948563950944258",
  "text" : "RT @letsmove: The World Series Champion @SFGiants visited the @WhiteHouse today\u2014and they shared their go-to healthy pre-game meals: http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "SFGiants",
        "screen_name" : "SFGiants",
        "indices" : [ 26, 35 ],
        "id_str" : "43024351",
        "id" : 43024351
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 48, 59 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/BZOayd3x6c",
        "expanded_url" : "http:\/\/vine.co\/v\/hAY9PVVUd6L",
        "display_url" : "vine.co\/v\/hAY9PVVUd6L"
      } ]
    },
    "geo" : { },
    "id_str" : "361943639481528320",
    "text" : "The World Series Champion @SFGiants visited the @WhiteHouse today\u2014and they shared their go-to healthy pre-game meals: http:\/\/t.co\/BZOayd3x6c",
    "id" : 361943639481528320,
    "created_at" : "2013-07-29 20:17:42 +0000",
    "user" : {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "protected" : false,
      "id_str" : "36719281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207340336\/780fc13e31b6fdd80bd57d000dc13838_normal.jpeg",
      "id" : 36719281,
      "verified" : true
    }
  },
  "id" : 361948563950944258,
  "created_at" : "2013-07-29 20:37:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "361939747091910656",
  "text" : "FACT: Between 2007-2009, 71% of our agriculture workers were foreign born\u2014and there are still insufficient U.S. workers to fill labor needs.",
  "id" : 361939747091910656,
  "created_at" : "2013-07-29 20:02:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 28, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "361932515944042497",
  "text" : "FACT: The Senate bipartisan #ImmigrationReform bill would allow 1.5 million immigrant agricultural workers to earn legal status.",
  "id" : 361932515944042497,
  "created_at" : "2013-07-29 19:33:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hillary Clinton",
      "screen_name" : "HillaryClinton",
      "indices" : [ 21, 36 ],
      "id_str" : "1339835893",
      "id" : 1339835893
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/361922015462035456\/photo\/1",
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/4b5oXrYQYw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BQXOJ9CCEAAyrxK.jpg",
      "id_str" : "361922015470424064",
      "id" : 361922015470424064,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQXOJ9CCEAAyrxK.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/4b5oXrYQYw"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "361922015462035456",
  "text" : "Grabbing a bite with @HillaryClinton: http:\/\/t.co\/4b5oXrYQYw",
  "id" : 361922015462035456,
  "created_at" : "2013-07-29 18:51:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 34, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 123, 145 ],
      "url" : "http:\/\/t.co\/YB46gMAkWD",
      "expanded_url" : "http:\/\/at.wh.gov\/nqJBt",
      "display_url" : "at.wh.gov\/nqJBt"
    } ]
  },
  "geo" : { },
  "id_str" : "361918897412251648",
  "text" : "Worth a read and a RT: Here's how #ImmigrationReform would benefit farmers, U.S. agriculture &amp; rural communities \u2014&gt; http:\/\/t.co\/YB46gMAkWD",
  "id" : 361918897412251648,
  "created_at" : "2013-07-29 18:39:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/Xb62Y60wrM",
      "expanded_url" : "http:\/\/at.wh.gov\/nqrv6",
      "display_url" : "at.wh.gov\/nqrv6"
    } ]
  },
  "geo" : { },
  "id_str" : "361884723078905858",
  "text" : "\"This is a promising step forward.\" \u2014President Obama on resuming Israeli-Palestinian peace talks: http:\/\/t.co\/Xb62Y60wrM",
  "id" : 361884723078905858,
  "created_at" : "2013-07-29 16:23:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/361879544606621697\/photo\/1",
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/zfthdPHX0M",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BQWnh0wCAAEAs2w.png",
      "id_str" : "361879544610816001",
      "id" : 361879544610816001,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQWnh0wCAAEAs2w.png",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 612
      } ],
      "display_url" : "pic.twitter.com\/zfthdPHX0M"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "361879544606621697",
  "text" : "Landing on the South Lawn \u2014&gt; http:\/\/t.co\/zfthdPHX0M",
  "id" : 361879544606621697,
  "created_at" : "2013-07-29 16:03:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/gi6tjhmGES",
      "expanded_url" : "http:\/\/at.wh.gov\/nqgqH",
      "display_url" : "at.wh.gov\/nqgqH"
    } ]
  },
  "geo" : { },
  "id_str" : "361869546950365184",
  "text" : "\"I want to make sure everybody in Washington is obsessed with\u2026increasing middle-class incomes.\" \u2014President Obama: http:\/\/t.co\/gi6tjhmGES",
  "id" : 361869546950365184,
  "created_at" : "2013-07-29 15:23:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "indices" : [ 29, 37 ],
      "id_str" : "807095",
      "id" : 807095
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 98, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/33cBcrmQOZ",
      "expanded_url" : "http:\/\/at.wh.gov\/nq5iq",
      "display_url" : "at.wh.gov\/nq5iq"
    } ]
  },
  "geo" : { },
  "id_str" : "361854915590619137",
  "text" : "Don't miss President Obama's @NYTimes interview on rebuilding middle-class security, implementing #Obamacare &amp; more: http:\/\/t.co\/33cBcrmQOZ",
  "id" : 361854915590619137,
  "created_at" : "2013-07-29 14:25:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/i5QZGp5OJD",
      "expanded_url" : "http:\/\/youtu.be\/uRxHq9nLNto",
      "display_url" : "youtu.be\/uRxHq9nLNto"
    } ]
  },
  "geo" : { },
  "id_str" : "361554977283518464",
  "text" : "\"The choices we make now will determine whether or not every American has a fighting chance.\" \u2014President Obama: http:\/\/t.co\/i5QZGp5OJD",
  "id" : 361554977283518464,
  "created_at" : "2013-07-28 18:33:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/361273745945538561\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/6fY5e12ExR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BQOAjs6CMAARruW.jpg",
      "id_str" : "361273745958121472",
      "id" : 361273745958121472,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQOAjs6CMAARruW.jpg",
      "sizes" : [ {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/6fY5e12ExR"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/7vFUDaGJyD",
      "expanded_url" : "http:\/\/wh.gov\/l1pj3",
      "display_url" : "wh.gov\/l1pj3"
    } ]
  },
  "geo" : { },
  "id_str" : "361273745945538561",
  "text" : "\"Your shining deeds will live\u2014now and forever\" \u2014President Obama to Korean War veterans today: http:\/\/t.co\/7vFUDaGJyD, http:\/\/t.co\/6fY5e12ExR",
  "id" : 361273745945538561,
  "created_at" : "2013-07-27 23:55:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/KvadYk9atb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "361130126194388993",
  "text" : "Happening now: President Obama speaks at the 60th Anniversary of the Korean War Armistice. Watch \u2014&gt; http:\/\/t.co\/KvadYk9atb",
  "id" : 361130126194388993,
  "created_at" : "2013-07-27 14:25:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/361123274094149633\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/4Z2DXwbawD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BQL3tFjCAAIdx_X.jpg",
      "id_str" : "361123274098343938",
      "id" : 361123274098343938,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQL3tFjCAAIdx_X.jpg",
      "sizes" : [ {
        "h" : 612,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/4Z2DXwbawD"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/b88FOlWfEh",
      "expanded_url" : "http:\/\/wh.gov\/l1RBA",
      "display_url" : "wh.gov\/l1RBA"
    } ]
  },
  "geo" : { },
  "id_str" : "361123274094149633",
  "text" : "Watch President Obama's Weekly Address on rebuilding middle-class security \u2014&gt; http:\/\/t.co\/b88FOlWfEh, http:\/\/t.co\/4Z2DXwbawD",
  "id" : 361123274094149633,
  "created_at" : "2013-07-27 13:57:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/petesouza\/status\/360926756351401984\/photo\/1",
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/rmKQsb3DTH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BQJE-P6CYAE5vwp.jpg",
      "id_str" : "360926756355596289",
      "id" : 360926756355596289,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQJE-P6CYAE5vwp.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/rmKQsb3DTH"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/TC5hy2nXdz",
      "expanded_url" : "http:\/\/Instagram.com\/petesouza",
      "display_url" : "Instagram.com\/petesouza"
    } ]
  },
  "geo" : { },
  "id_str" : "360943165945036800",
  "text" : "RT @petesouza: Marine One lands on South Lawn. http:\/\/t.co\/TC5hy2nXdz http:\/\/t.co\/rmKQsb3DTH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/petesouza\/status\/360926756351401984\/photo\/1",
        "indices" : [ 55, 77 ],
        "url" : "http:\/\/t.co\/rmKQsb3DTH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BQJE-P6CYAE5vwp.jpg",
        "id_str" : "360926756355596289",
        "id" : 360926756355596289,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQJE-P6CYAE5vwp.jpg",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/rmKQsb3DTH"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 32, 54 ],
        "url" : "http:\/\/t.co\/TC5hy2nXdz",
        "expanded_url" : "http:\/\/Instagram.com\/petesouza",
        "display_url" : "Instagram.com\/petesouza"
      } ]
    },
    "geo" : { },
    "id_str" : "360926756351401984",
    "text" : "Marine One lands on South Lawn. http:\/\/t.co\/TC5hy2nXdz http:\/\/t.co\/rmKQsb3DTH",
    "id" : 360926756351401984,
    "created_at" : "2013-07-27 00:56:59 +0000",
    "user" : {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "protected" : false,
      "id_str" : "18215973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771916869808844800\/7d_poH48_normal.jpg",
      "id" : 18215973,
      "verified" : true
    }
  },
  "id" : 360943165945036800,
  "created_at" : "2013-07-27 02:02:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kathleen Sebelius",
      "screen_name" : "Sebelius",
      "indices" : [ 3, 12 ],
      "id_str" : "2556859698",
      "id" : 2556859698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/JOGVMrBb9O",
      "expanded_url" : "http:\/\/bit.ly\/13ij7DM",
      "display_url" : "bit.ly\/13ij7DM"
    } ]
  },
  "geo" : { },
  "id_str" : "360878614528536577",
  "text" : "RT @Sebelius: Great news for Maryland: Lower than expected health premiums in new Health Insurance Marketplace http:\/\/t.co\/JOGVMrBb9O #Obam\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ObamaCareInAction",
        "indices" : [ 120, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/JOGVMrBb9O",
        "expanded_url" : "http:\/\/bit.ly\/13ij7DM",
        "display_url" : "bit.ly\/13ij7DM"
      } ]
    },
    "geo" : { },
    "id_str" : "360861090512502785",
    "text" : "Great news for Maryland: Lower than expected health premiums in new Health Insurance Marketplace http:\/\/t.co\/JOGVMrBb9O #ObamaCareInAction",
    "id" : 360861090512502785,
    "created_at" : "2013-07-26 20:36:03 +0000",
    "user" : {
      "name" : "Kathleen Sebelius",
      "screen_name" : "SecSebelius",
      "protected" : false,
      "id_str" : "1023020557",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000082519123\/6450b6c1fe4ad3432aacf01adf22ac37_normal.png",
      "id" : 1023020557,
      "verified" : true
    }
  },
  "id" : 360878614528536577,
  "created_at" : "2013-07-26 21:45:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/5EEiIBXdSp",
      "expanded_url" : "http:\/\/www.whitehouse.gov\/the-press-office\/2013\/07\/26\/statement-press-secretary-guantanamo-bay",
      "display_url" : "whitehouse.gov\/the-press-offi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "360875555148664832",
  "text" : "RT @NSCPress: President Obama remains committed to closing the detention facility at Guantanamo Bay: http:\/\/t.co\/5EEiIBXdSp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/5EEiIBXdSp",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/the-press-office\/2013\/07\/26\/statement-press-secretary-guantanamo-bay",
        "display_url" : "whitehouse.gov\/the-press-offi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "360865826783510530",
    "text" : "President Obama remains committed to closing the detention facility at Guantanamo Bay: http:\/\/t.co\/5EEiIBXdSp",
    "id" : 360865826783510530,
    "created_at" : "2013-07-26 20:54:52 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 360875555148664832,
  "created_at" : "2013-07-26 21:33:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "indices" : [ 3, 13 ],
      "id_str" : "1613223313",
      "id" : 1613223313
    }, {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "indices" : [ 49, 58 ],
      "id_str" : "1604366701",
      "id" : 1604366701
    }, {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 59, 70 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    }, {
      "name" : "Anthony Foxx",
      "screen_name" : "SecretaryFoxx",
      "indices" : [ 71, 85 ],
      "id_str" : "43920155",
      "id" : 43920155
    }, {
      "name" : "Kathleen Sebelius",
      "screen_name" : "Sebelius",
      "indices" : [ 86, 95 ],
      "id_str" : "2556859698",
      "id" : 2556859698
    }, {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 96, 107 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    }, {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 108, 113 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Ernest Moniz",
      "screen_name" : "ErnestMoniz",
      "indices" : [ 114, 126 ],
      "id_str" : "1393155566",
      "id" : 1393155566
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FollowFriday",
      "indices" : [ 15, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360862691994255360",
  "text" : "RT @Cecilia44: #FollowFriday colleagues edition: @LaborSec @arneduncan @SecretaryFoxx @Sebelius @Pfeiffer44 @vj44 @ernestmoniz @SecretaryJe\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tom Perez",
        "screen_name" : "LaborSec",
        "indices" : [ 34, 43 ],
        "id_str" : "1604366701",
        "id" : 1604366701
      }, {
        "name" : "Arne Duncan",
        "screen_name" : "arneduncan",
        "indices" : [ 44, 55 ],
        "id_str" : "4662969794",
        "id" : 4662969794
      }, {
        "name" : "Anthony Foxx",
        "screen_name" : "SecretaryFoxx",
        "indices" : [ 56, 70 ],
        "id_str" : "43920155",
        "id" : 43920155
      }, {
        "name" : "Kathleen Sebelius",
        "screen_name" : "Sebelius",
        "indices" : [ 71, 80 ],
        "id_str" : "2556859698",
        "id" : 2556859698
      }, {
        "name" : "pu iezov uf",
        "screen_name" : "pfeiffer44",
        "indices" : [ 81, 92 ],
        "id_str" : "3187888216",
        "id" : 3187888216
      }, {
        "name" : "Valerie Jarrett",
        "screen_name" : "vj44",
        "indices" : [ 93, 98 ],
        "id_str" : "595515713",
        "id" : 595515713
      }, {
        "name" : "Ernest Moniz",
        "screen_name" : "ErnestMoniz",
        "indices" : [ 99, 111 ],
        "id_str" : "1393155566",
        "id" : 1393155566
      }, {
        "name" : "Sally Jewell",
        "screen_name" : "SecretaryJewell",
        "indices" : [ 112, 128 ],
        "id_str" : "1342861723",
        "id" : 1342861723
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FollowFriday",
        "indices" : [ 0, 13 ]
      }, {
        "text" : "FF",
        "indices" : [ 129, 132 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "360810965018738689",
    "text" : "#FollowFriday colleagues edition: @LaborSec @arneduncan @SecretaryFoxx @Sebelius @Pfeiffer44 @vj44 @ernestmoniz @SecretaryJewell #FF",
    "id" : 360810965018738689,
    "created_at" : "2013-07-26 17:16:52 +0000",
    "user" : {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "protected" : false,
      "id_str" : "1613223313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000172019215\/ed65eda76f51213f91b33edbaa62054c_normal.jpeg",
      "id" : 1613223313,
      "verified" : true
    }
  },
  "id" : 360862691994255360,
  "created_at" : "2013-07-26 20:42:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "indices" : [ 7, 17 ],
      "id_str" : "1613223313",
      "id" : 1613223313
    }, {
      "name" : "\u041A\u0430\u0442\u0435\u043D\u0430 \u041D\u0438\u043A\u043E\u043D\u0435\u043D\u043A\u043E",
      "screen_name" : "HealthCareTara",
      "indices" : [ 19, 34 ],
      "id_str" : "9448842",
      "id" : 9448842
    }, {
      "name" : "Katie Beirne Fallon",
      "screen_name" : "Katie44",
      "indices" : [ 42, 50 ],
      "id_str" : "1603381488",
      "id" : 1603381488
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FF",
      "indices" : [ 126, 129 ]
    }, {
      "text" : "FollowFriday",
      "indices" : [ 130, 143 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360857518869712896",
  "text" : "Follow @Cecilia44, @HealthCareTara, &amp; @Katie44 for the latest from the White House on health care, immigration, and more. #FF #FollowFriday",
  "id" : 360857518869712896,
  "created_at" : "2013-07-26 20:21:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WestWingWeek",
      "indices" : [ 130, 143 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/lzdKyZNOp4",
      "expanded_url" : "http:\/\/at.wh.gov\/nmAv4",
      "display_url" : "at.wh.gov\/nmAv4"
    } ]
  },
  "geo" : { },
  "id_str" : "360846673636892672",
  "text" : "Worth watching: Here's your front-row seat to recap everything going on at the White House this week \u2014&gt; http:\/\/t.co\/lzdKyZNOp4 #WestWingWeek",
  "id" : 360846673636892672,
  "created_at" : "2013-07-26 19:38:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Instagram",
      "screen_name" : "instagram",
      "indices" : [ 52, 62 ],
      "id_str" : "180505807",
      "id" : 180505807
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/360837546944655360\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/Wivn4c2Qef",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BQHz1k-CcAAPrZD.png",
      "id_str" : "360837546948849664",
      "id" : 360837546948849664,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQHz1k-CcAAPrZD.png",
      "sizes" : [ {
        "h" : 613,
        "resize" : "fit",
        "w" : 613
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 613,
        "resize" : "fit",
        "w" : 613
      } ],
      "display_url" : "pic.twitter.com\/Wivn4c2Qef"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/y5bWZhkoxp",
      "expanded_url" : "http:\/\/instagram.com\/whitehouse",
      "display_url" : "instagram.com\/whitehouse"
    } ]
  },
  "geo" : { },
  "id_str" : "360837546944655360",
  "text" : "If you haven't started following the White House on @Instagram yet, now's a great time \u2014&gt; http:\/\/t.co\/y5bWZhkoxp, http:\/\/t.co\/Wivn4c2Qef",
  "id" : 360837546944655360,
  "created_at" : "2013-07-26 19:02:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/360826752819417088\/photo\/1",
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/FbYMOOJQND",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BQHqBRuCUAApZG3.jpg",
      "id_str" : "360826752823611392",
      "id" : 360826752823611392,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQHqBRuCUAApZG3.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/FbYMOOJQND"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/Wf0oK98Bhd",
      "expanded_url" : "http:\/\/at.wh.gov\/nmpr1",
      "display_url" : "at.wh.gov\/nmpr1"
    } ]
  },
  "geo" : { },
  "id_str" : "360826752819417088",
  "text" : "Let's keep fighting to make America work for every working family \u2014&gt; http:\/\/t.co\/Wf0oK98Bhd, http:\/\/t.co\/FbYMOOJQND",
  "id" : 360826752819417088,
  "created_at" : "2013-07-26 18:19:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 80, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/guw6bPr5KU",
      "expanded_url" : "http:\/\/at.wh.gov\/nmf6s",
      "display_url" : "at.wh.gov\/nmf6s"
    } ]
  },
  "geo" : { },
  "id_str" : "360816994829864960",
  "text" : "\"You can't just be against something\u2014you've got to be for something.\" \u2014Obama on #ABetterBargain for the middle class: http:\/\/t.co\/guw6bPr5KU",
  "id" : 360816994829864960,
  "created_at" : "2013-07-26 17:40:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/360806699965243392\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/Qtw5noZfOJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BQHXyDBCYAAmao-.jpg",
      "id_str" : "360806699969437696",
      "id" : 360806699969437696,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQHXyDBCYAAmao-.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/Qtw5noZfOJ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360806699965243392",
  "text" : "RT to share President Obama's vision to keep building an economy where everyone who works hard can get ahead. http:\/\/t.co\/Qtw5noZfOJ",
  "id" : 360806699965243392,
  "created_at" : "2013-07-26 16:59:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360799136884326400",
  "text" : "RT @VP: PHOTO: VP &amp; son-in-law Howard stop for some lime juice &amp; talk w\/ employees @ a hawker market in Singapore (WH PHOTO) http:\/\/t.co\/ee\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/360770547782672384\/photo\/1",
        "indices" : [ 125, 147 ],
        "url" : "http:\/\/t.co\/eemRMfaJ60",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BQG25tqCYAAqLJM.jpg",
        "id_str" : "360770547791060992",
        "id" : 360770547791060992,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQG25tqCYAAqLJM.jpg",
        "sizes" : [ {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/eemRMfaJ60"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "360770547782672384",
    "text" : "PHOTO: VP &amp; son-in-law Howard stop for some lime juice &amp; talk w\/ employees @ a hawker market in Singapore (WH PHOTO) http:\/\/t.co\/eemRMfaJ60",
    "id" : 360770547782672384,
    "created_at" : "2013-07-26 14:36:16 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 360799136884326400,
  "created_at" : "2013-07-26 16:29:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/360789355910012929\/photo\/1",
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/lH0TrvWA7r",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BQHIAfZCIAAj7EX.jpg",
      "id_str" : "360789355918401536",
      "id" : 360789355918401536,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQHIAfZCIAAj7EX.jpg",
      "sizes" : [ {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/lH0TrvWA7r"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/WeKZUR9oBC",
      "expanded_url" : "http:\/\/at.wh.gov\/nm31e",
      "display_url" : "at.wh.gov\/nm31e"
    } ]
  },
  "geo" : { },
  "id_str" : "360789355910012929",
  "text" : "Last night, President Obama hosted an Iftar dinner celebrating Ramadan \u2014&gt; http:\/\/t.co\/WeKZUR9oBC, http:\/\/t.co\/lH0TrvWA7r",
  "id" : 360789355910012929,
  "created_at" : "2013-07-26 15:51:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "indices" : [ 3, 18 ],
      "id_str" : "19674502",
      "id" : 19674502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360784585098936321",
  "text" : "RT @AmbassadorRice: The current situation in South Sudan is deeply troubling. We are focused on ending violence &amp; supporting democracy: htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 142 ],
        "url" : "http:\/\/t.co\/WluK1k8Yhi",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2013\/07\/24\/addressing-crisis-south-sudan-s-jonglei-state",
        "display_url" : "whitehouse.gov\/blog\/2013\/07\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "360756137978626048",
    "text" : "The current situation in South Sudan is deeply troubling. We are focused on ending violence &amp; supporting democracy: http:\/\/t.co\/WluK1k8Yhi",
    "id" : 360756137978626048,
    "created_at" : "2013-07-26 13:39:00 +0000",
    "user" : {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "protected" : false,
      "id_str" : "19674502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2245433940\/297681_10150417294436240_295915266239_10074516_1895344954_n_normal.jpg",
      "id" : 19674502,
      "verified" : true
    }
  },
  "id" : 360784585098936321,
  "created_at" : "2013-07-26 15:32:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/360777091567976449\/photo\/1",
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/Lyfy8HxafF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BQG82nKCAAAmVuf.png",
      "id_str" : "360777091576365056",
      "id" : 360777091576365056,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQG82nKCAAAmVuf.png",
      "sizes" : [ {
        "h" : 614,
        "resize" : "fit",
        "w" : 613
      }, {
        "h" : 341,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 614,
        "resize" : "fit",
        "w" : 613
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 601,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/Lyfy8HxafF"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360777091567976449",
  "text" : "Good morning, Bo! http:\/\/t.co\/Lyfy8HxafF",
  "id" : 360777091567976449,
  "created_at" : "2013-07-26 15:02:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/360536294700486656\/photo\/1",
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/2VEDD7GKCn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BQDh2Y6CEAEnfxg.jpg",
      "id_str" : "360536294704680961",
      "id" : 360536294704680961,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQDh2Y6CEAEnfxg.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/2VEDD7GKCn"
    } ],
    "hashtags" : [ {
      "text" : "TBT",
      "indices" : [ 12, 16 ]
    }, {
      "text" : "ThrowbackThursday",
      "indices" : [ 17, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360536294700486656",
  "text" : "Baby POTUS. #TBT #ThrowbackThursday http:\/\/t.co\/2VEDD7GKCn",
  "id" : 360536294700486656,
  "created_at" : "2013-07-25 23:05:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/360523989682118657\/photo\/1",
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/QrqGpUlzEq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BQDWqJKCYAAliRw.png",
      "id_str" : "360523989690507264",
      "id" : 360523989690507264,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQDWqJKCYAAliRw.png",
      "sizes" : [ {
        "h" : 341,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 613,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 613,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 601,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/QrqGpUlzEq"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360523989682118657",
  "text" : "If you've ever wondered what landing on the South Lawn of the White House was like\u2026here you go \u2014&gt; http:\/\/t.co\/QrqGpUlzEq",
  "id" : 360523989682118657,
  "created_at" : "2013-07-25 22:16:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Beirne Fallon",
      "screen_name" : "Katie44",
      "indices" : [ 3, 11 ],
      "id_str" : "1603381488",
      "id" : 1603381488
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Katie44\/status\/360484245061378049\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/08sKblE3ob",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BQCygs6CIAA91OX.jpg",
      "id_str" : "360484245069766656",
      "id" : 360484245069766656,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQCygs6CIAA91OX.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/08sKblE3ob"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360500955692793856",
  "text" : "RT @Katie44: JAX Port is one of 50+ infrastructure projects that have benefited from exec action to cut red tape http:\/\/t.co\/08sKblE3ob",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Katie44\/status\/360484245061378049\/photo\/1",
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/08sKblE3ob",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BQCygs6CIAA91OX.jpg",
        "id_str" : "360484245069766656",
        "id" : 360484245069766656,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQCygs6CIAA91OX.jpg",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/08sKblE3ob"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "360484245061378049",
    "text" : "JAX Port is one of 50+ infrastructure projects that have benefited from exec action to cut red tape http:\/\/t.co\/08sKblE3ob",
    "id" : 360484245061378049,
    "created_at" : "2013-07-25 19:38:36 +0000",
    "user" : {
      "name" : "Katie Beirne Fallon",
      "screen_name" : "Katie44",
      "protected" : false,
      "id_str" : "1603381488",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000171840264\/4f11a05d0664eefddc3806b77bfd2b99_normal.jpeg",
      "id" : 1603381488,
      "verified" : true
    }
  },
  "id" : 360500955692793856,
  "created_at" : "2013-07-25 20:45:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 110, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360488183064051713",
  "text" : "It's time for Washington to focus on making our country work for all Americans. Middle-class families deserve #ABetterBargain. -bo",
  "id" : 360488183064051713,
  "created_at" : "2013-07-25 19:54:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/360478513427525633\/photo\/1",
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/4vZaPBdU5a",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BQCtTE5CMAEgSVv.png",
      "id_str" : "360478513431719937",
      "id" : 360478513431719937,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQCtTE5CMAEgSVv.png",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 611,
        "resize" : "fit",
        "w" : 611
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 611,
        "resize" : "fit",
        "w" : 611
      } ],
      "display_url" : "pic.twitter.com\/4vZaPBdU5a"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360478513427525633",
  "text" : "President Obama: \"Thank you, Florida! God bless you, and God bless the United States of America.\" http:\/\/t.co\/4vZaPBdU5a",
  "id" : 360478513427525633,
  "created_at" : "2013-07-25 19:15:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 122, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360477296454414337",
  "text" : "Obama: \"Making sure the American Dream is something that\u2019s alive and real and achievable...that's what I'm fighting for.\" #ABetterBargain",
  "id" : 360477296454414337,
  "created_at" : "2013-07-25 19:10:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 121, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360476464199647232",
  "text" : "Obama on rebuilding middle-class security: \"This is what I\u2019m going to focus on over all the days left in my presidency.\" #ABetterBargain",
  "id" : 360476464199647232,
  "created_at" : "2013-07-25 19:07:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 123, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360475871204749312",
  "text" : "President Obama: \"Making sure we have world-class infrastructure shouldn\u2019t be a partisan issue. That\u2019s an American issue.\" #ABetterBargain",
  "id" : 360475871204749312,
  "created_at" : "2013-07-25 19:05:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360475385131048963",
  "text" : "Obama on rebuilding our infrastructure: \"We have to keep at it. The businesses of tomorrow won\u2019t locate near old roads and outdated ports.\"",
  "id" : 360475385131048963,
  "created_at" : "2013-07-25 19:03:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 104, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360475102606934017",
  "text" : "RT @WHLive: President Obama: \"We know strong infrastructure is a key ingredient to a thriving economy.\" #ABetterBargain",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ABetterBargain",
        "indices" : [ 92, 107 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "360475048689152000",
    "text" : "President Obama: \"We know strong infrastructure is a key ingredient to a thriving economy.\" #ABetterBargain",
    "id" : 360475048689152000,
    "created_at" : "2013-07-25 19:02:03 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 360475102606934017,
  "created_at" : "2013-07-25 19:02:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360474481677971457",
  "text" : "President Obama: \"We need modern schools for our kids. We need modern power grids and fuel networks that can withstand stronger storms.\"",
  "id" : 360474481677971457,
  "created_at" : "2013-07-25 18:59:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 121, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360473812548059137",
  "text" : "President Obama: \"A focus on the core economic issues that matter to the middle class\u2014that\u2019s what this moment requires.\" #ABetterBargain",
  "id" : 360473812548059137,
  "created_at" : "2013-07-25 18:57:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360473090804822017",
  "text" : "President Obama: \"With an endless parade of distractions, political posturing &amp; phony scandals\u2026Washington has taken its eye off the ball.\"",
  "id" : 360473090804822017,
  "created_at" : "2013-07-25 18:54:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 19, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360472925494706179",
  "text" : "President Obama on #Obamacare: \"Tens of millions of Americans now have new benefits like free checkups and cheaper medicine on Medicare.\"",
  "id" : 360472925494706179,
  "created_at" : "2013-07-25 18:53:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/360472289453699073\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/GSRZMJP24l",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BQCnoyzCcAAuAYZ.jpg",
      "id_str" : "360472289462087680",
      "id" : 360472289462087680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQCnoyzCcAAuAYZ.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/GSRZMJP24l"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360472289453699073",
  "text" : "President Obama: \"Add it all up, and over the past 40 months, our businesses have created 7.2 million new jobs.\" http:\/\/t.co\/GSRZMJP24l",
  "id" : 360472289453699073,
  "created_at" : "2013-07-25 18:51:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 115, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360471882497130496",
  "text" : "President Obama: \"We changed a tax code too skewed in favor of the wealthiest at the expense of working families.\" #ABetterBargain",
  "id" : 360471882497130496,
  "created_at" : "2013-07-25 18:49:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 122, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360471693694730241",
  "text" : "RT @WHLive: President Obama: \"We put in place tough new rules on big banks, mortgage lenders, and credit card companies.\" #ABetterBargain",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ABetterBargain",
        "indices" : [ 110, 125 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "360471656768094208",
    "text" : "President Obama: \"We put in place tough new rules on big banks, mortgage lenders, and credit card companies.\" #ABetterBargain",
    "id" : 360471656768094208,
    "created_at" : "2013-07-25 18:48:34 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 360471693694730241,
  "created_at" : "2013-07-25 18:48:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 98, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360471148313583617",
  "text" : "President Obama: \"Yesterday, in Illinois, I talked about what we need to do as a country to build #ABetterBargain for the middle class.\"",
  "id" : 360471148313583617,
  "created_at" : "2013-07-25 18:46:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/360470897422905346\/photo\/1",
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/NSd401CAv9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BQCmXxFCMAAxwnU.jpg",
      "id_str" : "360470897431293952",
      "id" : 360470897431293952,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQCmXxFCMAAxwnU.jpg",
      "sizes" : [ {
        "h" : 612,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 612,
        "resize" : "fit",
        "w" : 612
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/NSd401CAv9"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360470897422905346",
  "text" : "President Obama: \"Hello, Jacksonville!\" http:\/\/t.co\/NSd401CAv9",
  "id" : 360470897422905346,
  "created_at" : "2013-07-25 18:45:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/fPsaoFsmme",
      "expanded_url" : "http:\/\/at.wh.gov\/nk59x",
      "display_url" : "at.wh.gov\/nk59x"
    } ]
  },
  "geo" : { },
  "id_str" : "360470323528859648",
  "text" : "Watch now: President Obama speaks in Jacksonville on rebuilding the infrastructure our businesses depend on \u2014&gt; http:\/\/t.co\/fPsaoFsmme",
  "id" : 360470323528859648,
  "created_at" : "2013-07-25 18:43:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360458532400791552",
  "text" : "RT @pfeiffer44: Everyone following Obamacare, politics or Congress shld read Norm Ornstein's powerful essay the GOP sabotage efforts http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/Zv8xtzwp5G",
        "expanded_url" : "http:\/\/www.nationaljournal.com\/columns\/washington-inside-out\/the-unprecedented-and-contemptible-attempts-to-sabotage-obamacare-20130724",
        "display_url" : "nationaljournal.com\/columns\/washin\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "360402430409715713",
    "text" : "Everyone following Obamacare, politics or Congress shld read Norm Ornstein's powerful essay the GOP sabotage efforts http:\/\/t.co\/Zv8xtzwp5G",
    "id" : 360402430409715713,
    "created_at" : "2013-07-25 14:13:30 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 360458532400791552,
  "created_at" : "2013-07-25 17:56:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/WEgVAk7miK",
      "expanded_url" : "http:\/\/at.wh.gov\/nk0KY",
      "display_url" : "at.wh.gov\/nk0KY"
    } ]
  },
  "geo" : { },
  "id_str" : "360454238486282241",
  "text" : "\"Today the American people grieve with our Spanish friends, who are in our thoughts and prayers.\" \u2014President Obama: http:\/\/t.co\/WEgVAk7miK",
  "id" : 360454238486282241,
  "created_at" : "2013-07-25 17:39:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/360451013964075009\/photo\/1",
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/776WShFkYn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BQCUSZbCEAAZjM0.png",
      "id_str" : "360451013972463616",
      "id" : 360451013972463616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQCUSZbCEAAZjM0.png",
      "sizes" : [ {
        "h" : 613,
        "resize" : "fit",
        "w" : 613
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 613,
        "resize" : "fit",
        "w" : 613
      } ],
      "display_url" : "pic.twitter.com\/776WShFkYn"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360451013964075009",
  "text" : "President Obama met with President Sang of Vietnam this morning in the Oval Office: http:\/\/t.co\/776WShFkYn",
  "id" : 360451013964075009,
  "created_at" : "2013-07-25 17:26:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/360442604900454402\/photo\/1",
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/6PRycE3zUz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BQCMo7PCEAAOkr9.jpg",
      "id_str" : "360442604913037312",
      "id" : 360442604913037312,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BQCMo7PCEAAOkr9.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/6PRycE3zUz"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 93 ],
      "url" : "http:\/\/t.co\/00C6CKhbtI",
      "expanded_url" : "http:\/\/at.wh.gov\/njU1M",
      "display_url" : "at.wh.gov\/njU1M"
    } ]
  },
  "geo" : { },
  "id_str" : "360442604900454402",
  "text" : "Let's keep fighting to make sure all our kids can make it if they try: http:\/\/t.co\/00C6CKhbtI, http:\/\/t.co\/6PRycE3zUz",
  "id" : 360442604900454402,
  "created_at" : "2013-07-25 16:53:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/uBKLldg3qW",
      "expanded_url" : "http:\/\/at.wh.gov\/njAGi",
      "display_url" : "at.wh.gov\/njAGi"
    } ]
  },
  "geo" : { },
  "id_str" : "360418397181317121",
  "text" : "At 2:35pm ET, President Obama speaks in Jacksonville on rebuilding the infrastructure our businesses depend on \u2014&gt; http:\/\/t.co\/uBKLldg3qW",
  "id" : 360418397181317121,
  "created_at" : "2013-07-25 15:16:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "indices" : [ 3, 10 ],
      "id_str" : "44783853",
      "id" : 44783853
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BlogHer2013",
      "indices" : [ 91, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/BXWx7JM7Bi",
      "expanded_url" : "http:\/\/go.usa.gov\/j8mF",
      "display_url" : "go.usa.gov\/j8mF"
    } ]
  },
  "geo" : { },
  "id_str" : "360414182090354688",
  "text" : "RT @HHSGov: Guess what? In 2014, being a woman will no longer be a pre-existing condition. #BlogHer2013 http:\/\/t.co\/BXWx7JM7Bi http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BlogHer2013",
        "indices" : [ 79, 91 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/BXWx7JM7Bi",
        "expanded_url" : "http:\/\/go.usa.gov\/j8mF",
        "display_url" : "go.usa.gov\/j8mF"
      }, {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/hdqrcNN9j8",
        "expanded_url" : "http:\/\/ow.ly\/i\/2HiMN",
        "display_url" : "ow.ly\/i\/2HiMN"
      } ]
    },
    "geo" : { },
    "id_str" : "360316117463478272",
    "text" : "Guess what? In 2014, being a woman will no longer be a pre-existing condition. #BlogHer2013 http:\/\/t.co\/BXWx7JM7Bi http:\/\/t.co\/hdqrcNN9j8",
    "id" : 360316117463478272,
    "created_at" : "2013-07-25 08:30:31 +0000",
    "user" : {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "protected" : false,
      "id_str" : "44783853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567350542326718464\/FXOsgyA7_normal.jpeg",
      "id" : 44783853,
      "verified" : true
    }
  },
  "id" : 360414182090354688,
  "created_at" : "2013-07-25 15:00:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/360189622153801729\/photo\/1",
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/nKgsiVQbgP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BP-mjZDCcAA0Ecc.jpg",
      "id_str" : "360189622162190336",
      "id" : 360189622162190336,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BP-mjZDCcAA0Ecc.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/nKgsiVQbgP"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360189622153801729",
  "text" : "RT if you agree: Washington needs to focus on making this country work for every American family. http:\/\/t.co\/nKgsiVQbgP",
  "id" : 360189622153801729,
  "created_at" : "2013-07-25 00:07:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/VLFIeYLwCs",
      "expanded_url" : "http:\/\/at.wh.gov\/nilVb",
      "display_url" : "at.wh.gov\/nilVb"
    } ]
  },
  "geo" : { },
  "id_str" : "360181611322552320",
  "text" : "Obama on the Senate acting to cut student loan rates: \"This compromise is a major victory for our nation\u2019s students.\" http:\/\/t.co\/VLFIeYLwCs",
  "id" : 360181611322552320,
  "created_at" : "2013-07-24 23:36:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/360175255077134337\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/PR0dRTnIpM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BP-ZfHhCIAAUk_a.jpg",
      "id_str" : "360175255085522944",
      "id" : 360175255085522944,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BP-ZfHhCIAAUk_a.jpg",
      "sizes" : [ {
        "h" : 1073,
        "resize" : "fit",
        "w" : 826
      }, {
        "h" : 1073,
        "resize" : "fit",
        "w" : 826
      }, {
        "h" : 442,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 779,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/PR0dRTnIpM"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360175255077134337",
  "text" : "RT to show your support for Patrick: In solidarity with the 2-yr-old leukemia patient, POTUS #41 shaved his head. http:\/\/t.co\/PR0dRTnIpM",
  "id" : 360175255077134337,
  "created_at" : "2013-07-24 23:10:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 121, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360167842559180800",
  "text" : "President Obama: \"We haven\u2019t just wanted success for ourselves\u2014we\u2019ve wanted it for our neighbors and our neighborhoods.\" #ABetterBargain",
  "id" : 360167842559180800,
  "created_at" : "2013-07-24 22:41:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360165280242077696",
  "text" : "President Obama on making preschool available to every 4-year-old: \"Our kids don't care about politics. We should prove we care about them.\"",
  "id" : 360165280242077696,
  "created_at" : "2013-07-24 22:31:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/360163962383388672\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/mwgXUjWTtQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BP-PNy9CUAAuVcK.jpg",
      "id_str" : "360163962391777280",
      "id" : 360163962391777280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BP-PNy9CUAAuVcK.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/mwgXUjWTtQ"
    } ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 101, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360163962383388672",
  "text" : "Obama: \"What we need isn\u2019t a three-month plan, or even a three-year plan. We need a long-term plan.\" #ABetterBargain, http:\/\/t.co\/mwgXUjWTtQ",
  "id" : 360163962383388672,
  "created_at" : "2013-07-24 22:25:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 96, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360162445089701889",
  "text" : "President Obama: \"This year, we are off to our strongest private-sector job growth since 1999.\" #ABetterBargain",
  "id" : 360162445089701889,
  "created_at" : "2013-07-24 22:19:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/360161864325406721\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/yNwJvg8g6a",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BP-NTrFCIAA7CLg.png",
      "id_str" : "360161864333795328",
      "id" : 360161864333795328,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BP-NTrFCIAA7CLg.png",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 574,
        "resize" : "fit",
        "w" : 574
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 574,
        "resize" : "fit",
        "w" : 574
      }, {
        "h" : 574,
        "resize" : "fit",
        "w" : 574
      } ],
      "display_url" : "pic.twitter.com\/yNwJvg8g6a"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360161864325406721",
  "text" : "Obama in MO: \"I brought a special guest with me who\u2019s celebrating her birthday today\u2014your senator Claire McCaskill!\" http:\/\/t.co\/yNwJvg8g6a",
  "id" : 360161864325406721,
  "created_at" : "2013-07-24 22:17:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 115, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/FNHZd2SmS9",
      "expanded_url" : "http:\/\/at.wh.gov\/niaE0",
      "display_url" : "at.wh.gov\/niaE0"
    } ]
  },
  "geo" : { },
  "id_str" : "360160071159787520",
  "text" : "Happening now: President Obama speaks in Missouri on rebuilding middle-class security \u2014&gt; http:\/\/t.co\/FNHZd2SmS9 #ABetterBargain",
  "id" : 360160071159787520,
  "created_at" : "2013-07-24 22:10:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    }, {
      "name" : "Lassen Volcanic NP",
      "screen_name" : "LassenNPS",
      "indices" : [ 98, 108 ],
      "id_str" : "24549680",
      "id" : 24549680
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Volcanoes",
      "indices" : [ 14, 24 ]
    }, {
      "text" : "mountains",
      "indices" : [ 26, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360157823348383747",
  "text" : "RT @Interior: #Volcanoes, #mountains &amp; this ridiculous night sky view. If you haven't been to @LassenNPS, we highly recommend it. http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lassen Volcanic NP",
        "screen_name" : "LassenNPS",
        "indices" : [ 84, 94 ],
        "id_str" : "24549680",
        "id" : 24549680
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Interior\/status\/360154801859874816\/photo\/1",
        "indices" : [ 120, 142 ],
        "url" : "http:\/\/t.co\/kDiq4sDuYH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BP-G4lWCUAAKoKL.jpg",
        "id_str" : "360154801868263424",
        "id" : 360154801868263424,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BP-G4lWCUAAKoKL.jpg",
        "sizes" : [ {
          "h" : 244,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 736,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 431,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 736,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/kDiq4sDuYH"
      } ],
      "hashtags" : [ {
        "text" : "Volcanoes",
        "indices" : [ 0, 10 ]
      }, {
        "text" : "mountains",
        "indices" : [ 12, 22 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "360154801859874816",
    "text" : "#Volcanoes, #mountains &amp; this ridiculous night sky view. If you haven't been to @LassenNPS, we highly recommend it. http:\/\/t.co\/kDiq4sDuYH",
    "id" : 360154801859874816,
    "created_at" : "2013-07-24 21:49:30 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 360157823348383747,
  "created_at" : "2013-07-24 22:01:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/rNCUDnIhGD",
      "expanded_url" : "http:\/\/instagram.com\/p\/cKZO37QiiE\/",
      "display_url" : "instagram.com\/p\/cKZO37QiiE\/"
    } ]
  },
  "geo" : { },
  "id_str" : "360145725583138819",
  "text" : "Goodbye, Illinois! Watch President Obama board Air Force One on his way to Missouri \u2708 \u2708 \u2708 http:\/\/t.co\/rNCUDnIhGD",
  "id" : 360145725583138819,
  "created_at" : "2013-07-24 21:13:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 7, 17 ],
      "id_str" : "18215973",
      "id" : 18215973
    }, {
      "name" : "Instagram",
      "screen_name" : "instagram",
      "indices" : [ 21, 31 ],
      "id_str" : "180505807",
      "id" : 180505807
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/360132624896884736\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/nfbuy1yUWT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BP9yttuCAAI0H5Y.png",
      "id_str" : "360132624905273346",
      "id" : 360132624905273346,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BP9yttuCAAI0H5Y.png",
      "sizes" : [ {
        "h" : 614,
        "resize" : "fit",
        "w" : 613
      }, {
        "h" : 341,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 614,
        "resize" : "fit",
        "w" : 613
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 601,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/nfbuy1yUWT"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/4JdOC54h7c",
      "expanded_url" : "http:\/\/Instagram.com\/petesouza",
      "display_url" : "Instagram.com\/petesouza"
    } ]
  },
  "geo" : { },
  "id_str" : "360132624896884736",
  "text" : "Follow @PeteSouza on @Instagram for behind-the-scenes photos of President Obama: http:\/\/t.co\/4JdOC54h7c, http:\/\/t.co\/nfbuy1yUWT",
  "id" : 360132624896884736,
  "created_at" : "2013-07-24 20:21:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 101, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/GigKJq8BZ3",
      "expanded_url" : "http:\/\/at.wh.gov\/nhYM1",
      "display_url" : "at.wh.gov\/nhYM1"
    } ]
  },
  "geo" : { },
  "id_str" : "360121457415688192",
  "text" : "RT to share how President Obama is fighting to rebuild middle-class security: http:\/\/t.co\/GigKJq8BZ3 #ABetterBargain",
  "id" : 360121457415688192,
  "created_at" : "2013-07-24 19:37:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 101, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/0W5I2hqbjS",
      "expanded_url" : "http:\/\/at.wh.gov\/nhXVO",
      "display_url" : "at.wh.gov\/nhXVO"
    } ]
  },
  "geo" : { },
  "id_str" : "360119648634679298",
  "text" : "Here's why raising the minimum wage is good for workers and the economy \u2014&gt; http:\/\/t.co\/0W5I2hqbjS #ABetterBargain",
  "id" : 360119648634679298,
  "created_at" : "2013-07-24 19:29:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 116, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360102358568542208",
  "text" : "Obama: \"No matter who you are, what you look like, where you come from or who you love\u2014you can make it if you try.\" #ABetterBargain",
  "id" : 360102358568542208,
  "created_at" : "2013-07-24 18:21:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 115, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360101284776378369",
  "text" : "President Obama: \"We don\u2019t call it John\u2019s dream or Susie\u2019s dream or Barack\u2019s dream\u2014we call it the American Dream.\" #ABetterBargain",
  "id" : 360101284776378369,
  "created_at" : "2013-07-24 18:16:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360100738338271232",
  "text" : "Obama: \"I care about 1 thing...how to use every min. of the 1,276 days remaining in my term to make this country work for working Americans\"",
  "id" : 360100738338271232,
  "created_at" : "2013-07-24 18:14:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360100106713829376",
  "text" : "President Obama: \"If we just stand by and do nothing in the face of immense change\u2014understand that part of our character will be lost.\"",
  "id" : 360100106713829376,
  "created_at" : "2013-07-24 18:12:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360099612712902657",
  "text" : "President Obama on Congressional gridlock: \"You can't just be against something. You've got to be for something.\"",
  "id" : 360099612712902657,
  "created_at" : "2013-07-24 18:10:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 129, 144 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360098636325064704",
  "text" : "President Obama: \"We\u2019ll need Republicans in Congress to set aside short-term politics &amp; work with me to find common ground.\" #ABetterBargain",
  "id" : 360098636325064704,
  "created_at" : "2013-07-24 18:06:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 18, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360098189879164928",
  "text" : "President Obama: \"#ABetterBargain for the middle class...an economy that grows from the middle-out. This is where I will focus my energies.\"",
  "id" : 360098189879164928,
  "created_at" : "2013-07-24 18:04:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 123, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360097771237294080",
  "text" : "Obama: \"We need to raise the minimum wage because it's lower in real terms right now than when Ronald Reagan took office.\" #ABetterBargain",
  "id" : 360097771237294080,
  "created_at" : "2013-07-24 18:02:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 111, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360097177042821124",
  "text" : "President Obama: \"We need to rebuild ladders of opportunity for all those Americans still trapped in poverty.\" #ABetterBargain",
  "id" : 360097177042821124,
  "created_at" : "2013-07-24 18:00:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 122, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360096658492633088",
  "text" : "Obama: \"If you don\u2019t have health insurance, starting October 1st, private plans will actually compete for your business.\" #ABetterBargain",
  "id" : 360096658492633088,
  "created_at" : "2013-07-24 17:58:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360095685640585216",
  "text" : "RT @WHLive: Obama: \"I\u2019ve asked Congress...to give every homeowner the chance to refinance their mortgage and save thousands of dollars.\" #A\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ABetterBargain",
        "indices" : [ 125, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "360095650320355328",
    "text" : "Obama: \"I\u2019ve asked Congress...to give every homeowner the chance to refinance their mortgage and save thousands of dollars.\" #ABetterBargain",
    "id" : 360095650320355328,
    "created_at" : "2013-07-24 17:54:27 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 360095685640585216,
  "created_at" : "2013-07-24 17:54:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360095191144730624",
  "text" : "Obama on paying for college: \"I will lay out an aggressive strategy to...tackle rising costs and improve value for middle-class students.\"",
  "id" : 360095191144730624,
  "created_at" : "2013-07-24 17:52:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 113, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360093923428933634",
  "text" : "President Obama: \"I\u2019ll keep pushing to make high-quality preschool available to every four-year-old in America.\" #ABetterBargain",
  "id" : 360093923428933634,
  "created_at" : "2013-07-24 17:47:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360093585737138178",
  "text" : "Obama on education: \"If we don\u2019t make this investment, we\u2019ll put our kids, our workers, and our country at a competitive disadvantage.\"",
  "id" : 360093585737138178,
  "created_at" : "2013-07-24 17:46:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360093274914029570",
  "text" : "Obama: \"The 2nd cornerstone of a strong middle class...An education that prepares our children...for the global competition they\u2019ll face.\"",
  "id" : 360093274914029570,
  "created_at" : "2013-07-24 17:45:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 117, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360092498808422401",
  "text" : "RT @WHLive: President Obama on investing in manufacturing: \"Let\u2019s tell the world that America is open for business.\" #ABetterBargain",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ABetterBargain",
        "indices" : [ 105, 120 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "360092452134195201",
    "text" : "President Obama on investing in manufacturing: \"Let\u2019s tell the world that America is open for business.\" #ABetterBargain",
    "id" : 360092452134195201,
    "created_at" : "2013-07-24 17:41:45 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 360092498808422401,
  "created_at" : "2013-07-24 17:41:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360091975174725632",
  "text" : "Obama: \"The first cornerstone of a strong &amp; growing middle class...an economy that generates more good jobs in durable, growing industries.\"",
  "id" : 360091975174725632,
  "created_at" : "2013-07-24 17:39:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 120, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360091486529921025",
  "text" : "Obama on helping the middle class: \"I will not allow gridlock, or inaction, or willful indifference to get in our way.\" #ABetterBargain",
  "id" : 360091486529921025,
  "created_at" : "2013-07-24 17:37:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/360091173693562882\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/KbvXPUtwhF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BP9NA79CIAEZp0j.jpg",
      "id_str" : "360091173701951489",
      "id" : 360091173701951489,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BP9NA79CIAEZp0j.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/KbvXPUtwhF"
    } ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 101, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360091173693562882",
  "text" : "Obama: \"What we need isn\u2019t a 3-month plan or even a 3-year plan, but a long-term American strategy.\" #ABetterBargain, http:\/\/t.co\/KbvXPUtwhF",
  "id" : 360091173693562882,
  "created_at" : "2013-07-24 17:36:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 122, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/XfeAFcNq1l",
      "expanded_url" : "http:\/\/at.wh.gov\/nhJ0y",
      "display_url" : "at.wh.gov\/nhJ0y"
    } ]
  },
  "geo" : { },
  "id_str" : "360090758277115904",
  "text" : "Obama: \"Reducing poverty and inequality. Growing prosperity and opportunity. That's what we need.\" http:\/\/t.co\/XfeAFcNq1l #ABetterBargain",
  "id" : 360090758277115904,
  "created_at" : "2013-07-24 17:35:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 117, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360090327861837825",
  "text" : "Obama: \"Rebuilding our manufacturing base. Educating our workforce...that\u2019s what Washington needs to be focused on.\" #ABetterBargain",
  "id" : 360090327861837825,
  "created_at" : "2013-07-24 17:33:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 103, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360089922205532160",
  "text" : "President Obama: \"Washington has taken its eye off the ball, and I am here to say this needs to stop.\" #ABetterBargain",
  "id" : 360089922205532160,
  "created_at" : "2013-07-24 17:31:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 121, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360088912170991618",
  "text" : "Obama on inequality: \"Reversing these trends must be Washington\u2019s highest priority. It\u2019s certainly my highest priority.\" #ABetterBargain",
  "id" : 360088912170991618,
  "created_at" : "2013-07-24 17:27:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360088813407698944",
  "text" : "RT @WHLive: President Obama: \"When wealth concentrates more and more at the very top, it inflates unstable bubbles that threaten the econom\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "360088774350761985",
    "text" : "President Obama: \"When wealth concentrates more and more at the very top, it inflates unstable bubbles that threaten the economy.\"",
    "id" : 360088774350761985,
    "created_at" : "2013-07-24 17:27:08 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 360088813407698944,
  "created_at" : "2013-07-24 17:27:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 84, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360088704443883520",
  "text" : "President Obama: \"Growing inequality isn\u2019t just morally wrong. It\u2019s bad economics.\" #ABetterBargain",
  "id" : 360088704443883520,
  "created_at" : "2013-07-24 17:26:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360088592623734784",
  "text" : "RT @WHLive: Obama at Knox College: \"The trends that I spoke of here in 2005\u2014of a winner-take-all economy...have been made worse by the rece\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "360088518078365696",
    "text" : "Obama at Knox College: \"The trends that I spoke of here in 2005\u2014of a winner-take-all economy...have been made worse by the recession.\"",
    "id" : 360088518078365696,
    "created_at" : "2013-07-24 17:26:07 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 360088592623734784,
  "created_at" : "2013-07-24 17:26:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 77, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360088445995061248",
  "text" : "President Obama: \"But, I\u2019m here today to tell you that we\u2019re not there yet.\" #ABetterBargain",
  "id" : 360088445995061248,
  "created_at" : "2013-07-24 17:25:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360087866187067393",
  "text" : "RT @WHLive: Obama: \"The cost of health care is growing at its slowest rate in 50 years and our deficits are falling at the fastest rate in \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "360087818795618306",
    "text" : "Obama: \"The cost of health care is growing at its slowest rate in 50 years and our deficits are falling at the fastest rate in 60 years.\"",
    "id" : 360087818795618306,
    "created_at" : "2013-07-24 17:23:20 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 360087866187067393,
  "created_at" : "2013-07-24 17:23:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/360087673886617600\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/n9nSHPpWMp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BP9J1OKCMAAs9Qv.jpg",
      "id_str" : "360087673895006208",
      "id" : 360087673895006208,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BP9J1OKCMAAs9Qv.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/n9nSHPpWMp"
    } ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 94, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360087673886617600",
  "text" : "Obama: \"Over the past 40 months, our businesses have created more than 7.2 million new jobs.\" #ABetterBargain, http:\/\/t.co\/n9nSHPpWMp",
  "id" : 360087673886617600,
  "created_at" : "2013-07-24 17:22:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 115, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360087386740363265",
  "text" : "President Obama: \"We changed a tax code too skewed in favor of the wealthiest at the expense of working families.\" #ABetterBargain",
  "id" : 360087386740363265,
  "created_at" : "2013-07-24 17:21:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 125, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360087113481461763",
  "text" : "Obama: \"Together, we saved the auto industry\u2014took on a broken health care system. We invested in new American technologies.\" #ABetterBargain",
  "id" : 360087113481461763,
  "created_at" : "2013-07-24 17:20:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ABetterBargain",
      "indices" : [ 111, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360086855590490112",
  "text" : "President Obama: \"Today, five years after the start of that Great Recession, America has fought its way back.\" #ABetterBargain",
  "id" : 360086855590490112,
  "created_at" : "2013-07-24 17:19:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/KvadYk9atb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "360085101750652929",
  "text" : "Happening now: President Obama speaks about rebuilding the cornerstones of middle-class security in America. Watch \u2014&gt; http:\/\/t.co\/KvadYk9atb",
  "id" : 360085101750652929,
  "created_at" : "2013-07-24 17:12:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/360078697799233537\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/GAdkOzDQwH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BP9BqvoCMAENas_.png",
      "id_str" : "360078697807622145",
      "id" : 360078697807622145,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BP9BqvoCMAENas_.png",
      "sizes" : [ {
        "h" : 341,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 543,
        "resize" : "fit",
        "w" : 542
      }, {
        "h" : 543,
        "resize" : "fit",
        "w" : 542
      }, {
        "h" : 543,
        "resize" : "fit",
        "w" : 542
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/GAdkOzDQwH"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/iiKB014sH9",
      "expanded_url" : "http:\/\/at.wh.gov\/nhC8p",
      "display_url" : "at.wh.gov\/nhC8p"
    } ]
  },
  "geo" : { },
  "id_str" : "360078697799233537",
  "text" : "President Obama just landed in IL for his speech at Knox College. Watch it at 12:55pm ET: http:\/\/t.co\/iiKB014sH9, http:\/\/t.co\/GAdkOzDQwH",
  "id" : 360078697799233537,
  "created_at" : "2013-07-24 16:47:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360073245430530049",
  "text" : "FACT: U.S. foreclosures are down to the lowest levels since 2006, and we're on pace for more than 5 million home sales this year.",
  "id" : 360073245430530049,
  "created_at" : "2013-07-24 16:25:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/360068715972263937\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/fJP47kmfpf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BP84lubCAAEWn4K.jpg",
      "id_str" : "360068715980652545",
      "id" : 360068715980652545,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BP84lubCAAEWn4K.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/fJP47kmfpf"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "360068715972263937",
  "text" : "FACT: Since March 2010, our economy has added 7.2 million private-sector jobs\u2014and there's more work to do. http:\/\/t.co\/fJP47kmfpf",
  "id" : 360068715972263937,
  "created_at" : "2013-07-24 16:07:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/360065267692343298\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/DrTIlNjbjw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BP81dAlCEAEQSDq.jpg",
      "id_str" : "360065267700731905",
      "id" : 360065267700731905,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BP81dAlCEAEQSDq.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/DrTIlNjbjw"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/WbZEbM5wKs",
      "expanded_url" : "http:\/\/at.wh.gov\/nhqRd",
      "display_url" : "at.wh.gov\/nhqRd"
    } ]
  },
  "geo" : { },
  "id_str" : "360065267692343298",
  "text" : "Today, President Obama will lay out his vision to keep rebuilding middle-class security: http:\/\/t.co\/WbZEbM5wKs, http:\/\/t.co\/DrTIlNjbjw",
  "id" : 360065267692343298,
  "created_at" : "2013-07-24 15:53:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Beirne Fallon",
      "screen_name" : "Katie44",
      "indices" : [ 3, 11 ],
      "id_str" : "1603381488",
      "id" : 1603381488
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/F8RAYFLH9j",
      "expanded_url" : "http:\/\/WH.gov",
      "display_url" : "WH.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "360060600593821696",
  "text" : "RT @Katie44: New on http:\/\/t.co\/F8RAYFLH9j: Here's how POTUS is fighting to rebuild the cornerstones of middle-class security \u2014&gt; http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 7, 29 ],
        "url" : "http:\/\/t.co\/F8RAYFLH9j",
        "expanded_url" : "http:\/\/WH.gov",
        "display_url" : "WH.gov"
      }, {
        "indices" : [ 119, 141 ],
        "url" : "http:\/\/t.co\/g3j8N47iWJ",
        "expanded_url" : "http:\/\/wh.gov\/a-better-bargain",
        "display_url" : "wh.gov\/a-better-barga\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "360056956670574594",
    "text" : "New on http:\/\/t.co\/F8RAYFLH9j: Here's how POTUS is fighting to rebuild the cornerstones of middle-class security \u2014&gt; http:\/\/t.co\/g3j8N47iWJ",
    "id" : 360056956670574594,
    "created_at" : "2013-07-24 15:20:42 +0000",
    "user" : {
      "name" : "Katie Beirne Fallon",
      "screen_name" : "Katie44",
      "protected" : false,
      "id_str" : "1603381488",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000171840264\/4f11a05d0664eefddc3806b77bfd2b99_normal.jpeg",
      "id" : 1603381488,
      "verified" : true
    }
  },
  "id" : 360060600593821696,
  "created_at" : "2013-07-24 15:35:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/360047719936561152\/photo\/1",
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/fHTdF6wVxv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BP8lfmGCEAMrO_o.jpg",
      "id_str" : "360047719944949763",
      "id" : 360047719944949763,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BP8lfmGCEAMrO_o.jpg",
      "sizes" : [ {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/fHTdF6wVxv"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/o4UqfQ0H7A",
      "expanded_url" : "http:\/\/at.wh.gov\/nh4aU",
      "display_url" : "at.wh.gov\/nh4aU"
    } ]
  },
  "geo" : { },
  "id_str" : "360047719936561152",
  "text" : "A behind-the-scenes look at drafting President Obama's speeches \u2014&gt; http:\/\/t.co\/o4UqfQ0H7A, http:\/\/t.co\/fHTdF6wVxv",
  "id" : 360047719936561152,
  "created_at" : "2013-07-24 14:44:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/KvadYk9atb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "360040623434235905",
  "text" : "At 12:55pm ET, President Obama speaks about his vision for rebuilding middle-class security. Watch here \u2014&gt; http:\/\/t.co\/KvadYk9atb",
  "id" : 360040623434235905,
  "created_at" : "2013-07-24 14:15:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/359825857679851520\/photo\/1",
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/bJtZCgSx02",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BP5btgxCAAQjLDy.jpg",
      "id_str" : "359825857684045828",
      "id" : 359825857684045828,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BP5btgxCAAQjLDy.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1050
      } ],
      "display_url" : "pic.twitter.com\/bJtZCgSx02"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/ifzBjRrKzz",
      "expanded_url" : "http:\/\/at.wh.gov\/nfXKu",
      "display_url" : "at.wh.gov\/nfXKu"
    } ]
  },
  "geo" : { },
  "id_str" : "359825857679851520",
  "text" : "President Obama honoring the NCAA Champion Louisville Cardinals \u2014&gt; http:\/\/t.co\/ifzBjRrKzz, http:\/\/t.co\/bJtZCgSx02",
  "id" : 359825857679851520,
  "created_at" : "2013-07-24 00:02:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 3, 11 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    }, {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 29, 37 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    }, {
      "name" : "USAID",
      "screen_name" : "USAID",
      "indices" : [ 57, 63 ],
      "id_str" : "36683668",
      "id" : 36683668
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/12UbRu9dx6",
      "expanded_url" : "http:\/\/at.wh.gov\/nfW3i",
      "display_url" : "at.wh.gov\/nfW3i"
    } ]
  },
  "geo" : { },
  "id_str" : "359822440421015552",
  "text" : "RT @DrBiden: Worth watching: @DrBiden sees firsthand how @USAID is empowering women in Agra, India \u2014&gt; http:\/\/t.co\/12UbRu9dx6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dr. Jill Biden",
        "screen_name" : "DrBiden",
        "indices" : [ 16, 24 ],
        "id_str" : "1281405877",
        "id" : 1281405877
      }, {
        "name" : "USAID",
        "screen_name" : "USAID",
        "indices" : [ 44, 50 ],
        "id_str" : "36683668",
        "id" : 36683668
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/12UbRu9dx6",
        "expanded_url" : "http:\/\/at.wh.gov\/nfW3i",
        "display_url" : "at.wh.gov\/nfW3i"
      } ]
    },
    "geo" : { },
    "id_str" : "359817049540800512",
    "text" : "Worth watching: @DrBiden sees firsthand how @USAID is empowering women in Agra, India \u2014&gt; http:\/\/t.co\/12UbRu9dx6",
    "id" : 359817049540800512,
    "created_at" : "2013-07-23 23:27:24 +0000",
    "user" : {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "protected" : false,
      "id_str" : "1281405877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608687663034474496\/wvzVG_yt_normal.jpg",
      "id" : 1281405877,
      "verified" : true
    }
  },
  "id" : 359822440421015552,
  "created_at" : "2013-07-23 23:48:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 3, 12 ],
      "id_str" : "36719281",
      "id" : 36719281
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 35, 42 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359808552908492800",
  "text" : "RT @letsmove: RT if you agree with @FLOTUS: \u201CIt\u2019s up to us to demand quality, affordable food that is good for our kids.\u201D http:\/\/t.co\/0ntJD\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The First Lady",
        "screen_name" : "FLOTUS",
        "indices" : [ 21, 28 ],
        "id_str" : "1093090866",
        "id" : 1093090866
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/letsmove\/status\/359807927806226432\/photo\/1",
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/0ntJDpLEFG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BP5LZ2zCcAAwfV_.jpg",
        "id_str" : "359807927814615040",
        "id" : 359807927814615040,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BP5LZ2zCcAAwfV_.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 700,
          "resize" : "fit",
          "w" : 1050
        } ],
        "display_url" : "pic.twitter.com\/0ntJDpLEFG"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "359807927806226432",
    "text" : "RT if you agree with @FLOTUS: \u201CIt\u2019s up to us to demand quality, affordable food that is good for our kids.\u201D http:\/\/t.co\/0ntJDpLEFG",
    "id" : 359807927806226432,
    "created_at" : "2013-07-23 22:51:09 +0000",
    "user" : {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "protected" : false,
      "id_str" : "36719281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207340336\/780fc13e31b6fdd80bd57d000dc13838_normal.jpeg",
      "id" : 36719281,
      "verified" : true
    }
  },
  "id" : 359808552908492800,
  "created_at" : "2013-07-23 22:53:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Olivier Knox",
      "screen_name" : "OKnox",
      "indices" : [ 119, 125 ],
      "id_str" : "11771512",
      "id" : 11771512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359780222624727042",
  "text" : "RT @Brundage44: great behind-the-scenes look at POTUS speechwriting process with chief WH speechwriter Cody Keenan via @OKnox here   \nhttp:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Olivier Knox",
        "screen_name" : "OKnox",
        "indices" : [ 103, 109 ],
        "id_str" : "11771512",
        "id" : 11771512
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/DONlJXAcEh",
        "expanded_url" : "http:\/\/news.yahoo.com\/-obama-speechwriter-discusses-economic-speech--%E2%80%98unfiltered-potus%E2%80%99--180942886.html",
        "display_url" : "news.yahoo.com\/-obama-speechw\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "359778450699059200",
    "text" : "great behind-the-scenes look at POTUS speechwriting process with chief WH speechwriter Cody Keenan via @OKnox here   \nhttp:\/\/t.co\/DONlJXAcEh",
    "id" : 359778450699059200,
    "created_at" : "2013-07-23 20:54:01 +0000",
    "user" : {
      "name" : "Liz Allen",
      "screen_name" : "LizAllen44",
      "protected" : false,
      "id_str" : "562456722",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705867932392407042\/-1npI72O_normal.jpg",
      "id" : 562456722,
      "verified" : true
    }
  },
  "id" : 359780222624727042,
  "created_at" : "2013-07-23 21:01:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/F87iR3AMLh",
      "expanded_url" : "http:\/\/at.wh.gov\/nfAO2",
      "display_url" : "at.wh.gov\/nfAO2"
    } ]
  },
  "geo" : { },
  "id_str" : "359767332203151360",
  "text" : "Tomorrow, President Obama will lay out his vision for rebuilding middle-class security. Here's why you should watch: http:\/\/t.co\/F87iR3AMLh",
  "id" : 359767332203151360,
  "created_at" : "2013-07-23 20:09:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 1, 9 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    }, {
      "name" : "USAID",
      "screen_name" : "USAID",
      "indices" : [ 20, 26 ],
      "id_str" : "36683668",
      "id" : 36683668
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/359756745788235777\/photo\/1",
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/eELEiS9G5d",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BP4c2q7CIAAWKYs.jpg",
      "id_str" : "359756745796624384",
      "id" : 359756745796624384,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BP4c2q7CIAAWKYs.jpg",
      "sizes" : [ {
        "h" : 574,
        "resize" : "fit",
        "w" : 574
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 574,
        "resize" : "fit",
        "w" : 574
      }, {
        "h" : 574,
        "resize" : "fit",
        "w" : 574
      } ],
      "display_url" : "pic.twitter.com\/eELEiS9G5d"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/ieudMw4SCy",
      "expanded_url" : "http:\/\/at.wh.gov\/nfv7o",
      "display_url" : "at.wh.gov\/nfv7o"
    } ]
  },
  "geo" : { },
  "id_str" : "359756745788235777",
  "text" : ".@DrBiden visited a @USAID site near the Taj Mahal that focuses on women &amp; community health: http:\/\/t.co\/ieudMw4SCy, http:\/\/t.co\/eELEiS9G5d",
  "id" : 359756745788235777,
  "created_at" : "2013-07-23 19:27:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Louisville",
      "indices" : [ 90, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359739974943375360",
  "text" : "RT @WHLive: President Obama: \"Let\u2019s give it up for Coach Pitino and the National Champion #Louisville Cardinals!\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Louisville",
        "indices" : [ 78, 89 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "359739811168395266",
    "text" : "President Obama: \"Let\u2019s give it up for Coach Pitino and the National Champion #Louisville Cardinals!\"",
    "id" : 359739811168395266,
    "created_at" : "2013-07-23 18:20:29 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 359739974943375360,
  "created_at" : "2013-07-23 18:21:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NCAA",
      "screen_name" : "NCAA",
      "indices" : [ 44, 49 ],
      "id_str" : "31122496",
      "id" : 31122496
    }, {
      "name" : "Louisville Cardinals",
      "screen_name" : "UofLCardinals",
      "indices" : [ 59, 73 ],
      "id_str" : "23729050",
      "id" : 23729050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/KvadYk9atb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "359738715276451841",
  "text" : "Happening now: President Obama welcomes the @NCAA champion @UofLCardinals to the White House \u2014&gt; http:\/\/t.co\/KvadYk9atb",
  "id" : 359738715276451841,
  "created_at" : "2013-07-23 18:16:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "indices" : [ 3, 13 ],
      "id_str" : "1613223313",
      "id" : 1613223313
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 97, 108 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359730834246340608",
  "text" : "RT @Cecilia44: Happy to be tweeting for the 1st time! Looking forward to sharing latest from the @WhiteHouse Domestic Policy Council. Oh an\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 82, 93 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GoBlue",
        "indices" : [ 126, 133 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "359705993518649345",
    "text" : "Happy to be tweeting for the 1st time! Looking forward to sharing latest from the @WhiteHouse Domestic Policy Council. Oh and #GoBlue!",
    "id" : 359705993518649345,
    "created_at" : "2013-07-23 16:06:06 +0000",
    "user" : {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "protected" : false,
      "id_str" : "1613223313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000172019215\/ed65eda76f51213f91b33edbaa62054c_normal.jpeg",
      "id" : 1613223313,
      "verified" : true
    }
  },
  "id" : 359730834246340608,
  "created_at" : "2013-07-23 17:44:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 141 ],
      "url" : "http:\/\/t.co\/ifuFgKeK2j",
      "expanded_url" : "http:\/\/at.wh.gov\/nf7F7",
      "display_url" : "at.wh.gov\/nf7F7"
    } ]
  },
  "geo" : { },
  "id_str" : "359716569351323648",
  "text" : "RT if you agree: It's time to pass a bipartisan compromise on college loans that saves 11 million students money \u2014&gt; http:\/\/t.co\/ifuFgKeK2j",
  "id" : 359716569351323648,
  "created_at" : "2013-07-23 16:48:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/359708765680959490\/photo\/1",
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/xRVgtw5j8q",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BP3xN3GCAAEOatd.jpg",
      "id_str" : "359708765689348097",
      "id" : 359708765689348097,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BP3xN3GCAAEOatd.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/xRVgtw5j8q"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359708765680959490",
  "text" : "FACT: A bipartisan compromise on college loans would save 11 million students an average of $1,500. http:\/\/t.co\/xRVgtw5j8q",
  "id" : 359708765680959490,
  "created_at" : "2013-07-23 16:17:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "indices" : [ 3, 12 ],
      "id_str" : "1604366701",
      "id" : 1604366701
    }, {
      "name" : "US Labor Department",
      "screen_name" : "USDOL",
      "indices" : [ 72, 78 ],
      "id_str" : "20179628",
      "id" : 20179628
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359675170467749890",
  "text" : "RT @LaborSec: Excited &amp; honored to begin my 1st day as secretary of @USDOL. It\u2019s a tremendous privilege to serve the American people in thi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "US Labor Department",
        "screen_name" : "USDOL",
        "indices" : [ 58, 64 ],
        "id_str" : "20179628",
        "id" : 20179628
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "359659224034328576",
    "text" : "Excited &amp; honored to begin my 1st day as secretary of @USDOL. It\u2019s a tremendous privilege to serve the American people in this new role.",
    "id" : 359659224034328576,
    "created_at" : "2013-07-23 13:00:15 +0000",
    "user" : {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "protected" : false,
      "id_str" : "1604366701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744887280666611712\/eEeyFjs6_normal.jpg",
      "id" : 1604366701,
      "verified" : true
    }
  },
  "id" : 359675170467749890,
  "created_at" : "2013-07-23 14:03:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "indices" : [ 3, 18 ],
      "id_str" : "19674502",
      "id" : 19674502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359665245188395008",
  "text" : "RT @AmbassadorRice: I welcome the EU's timely decision today to designate Hezbollah's military wing as a terrorist organization.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "359479301051133953",
    "text" : "I welcome the EU's timely decision today to designate Hezbollah's military wing as a terrorist organization.",
    "id" : 359479301051133953,
    "created_at" : "2013-07-23 01:05:18 +0000",
    "user" : {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "protected" : false,
      "id_str" : "19674502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2245433940\/297681_10150417294436240_295915266239_10074516_1895344954_n_normal.jpg",
      "id" : 19674502,
      "verified" : true
    }
  },
  "id" : 359665245188395008,
  "created_at" : "2013-07-23 13:24:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359431966199791616",
  "text" : "RT @FLOTUS: Congratulations to The Duke and Duchess of Cambridge on the birth of their son! Being a parent is the best job of all. -mo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "359428895054888961",
    "text" : "Congratulations to The Duke and Duchess of Cambridge on the birth of their son! Being a parent is the best job of all. -mo",
    "id" : 359428895054888961,
    "created_at" : "2013-07-22 21:45:01 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 359431966199791616,
  "created_at" : "2013-07-22 21:57:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RoyalBaby",
      "indices" : [ 124, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/rhi0MviAJv",
      "expanded_url" : "http:\/\/at.wh.gov\/ndkWK",
      "display_url" : "at.wh.gov\/ndkWK"
    } ]
  },
  "geo" : { },
  "id_str" : "359426056719056897",
  "text" : "\"Michelle and I are so pleased to congratulate The Duke and Duchess of Cambridge.\" \u2014President Obama: http:\/\/t.co\/rhi0MviAJv #RoyalBaby",
  "id" : 359426056719056897,
  "created_at" : "2013-07-22 21:33:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "indices" : [ 3, 11 ],
      "id_str" : "1530850933",
      "id" : 1530850933
    }, {
      "name" : "U.S. EPA",
      "screen_name" : "EPA",
      "indices" : [ 41, 45 ],
      "id_str" : "14615871",
      "id" : 14615871
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/KSppFtkGhN",
      "expanded_url" : "http:\/\/blog.epa.gov\/epaconnect\/2013\/07\/so-pumped\/",
      "display_url" : "blog.epa.gov\/epaconnect\/201\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "359414332733403138",
  "text" : "RT @GinaEPA: I\u2019m so pumped to be the new @EPA Administrator. Watch my video to EPA staff on the road ahead: http:\/\/t.co\/KSppFtkGhN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "U.S. EPA",
        "screen_name" : "EPA",
        "indices" : [ 28, 32 ],
        "id_str" : "14615871",
        "id" : 14615871
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/KSppFtkGhN",
        "expanded_url" : "http:\/\/blog.epa.gov\/epaconnect\/2013\/07\/so-pumped\/",
        "display_url" : "blog.epa.gov\/epaconnect\/201\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "359410102492610561",
    "text" : "I\u2019m so pumped to be the new @EPA Administrator. Watch my video to EPA staff on the road ahead: http:\/\/t.co\/KSppFtkGhN",
    "id" : 359410102492610561,
    "created_at" : "2013-07-22 20:30:20 +0000",
    "user" : {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "protected" : false,
      "id_str" : "1530850933",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/632229333130604548\/Bb4I34DU_normal.jpg",
      "id" : 1530850933,
      "verified" : true
    }
  },
  "id" : 359414332733403138,
  "created_at" : "2013-07-22 20:47:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 35, 43 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359380033632092160",
  "text" : "RT @VP: Worth watching: The VP and @DrBiden met with Gandhi's granddaughter in New Delhi today at the Gandhi Smriti museum \u2014&gt; http:\/\/t.co\/4\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dr. Jill Biden",
        "screen_name" : "DrBiden",
        "indices" : [ 27, 35 ],
        "id_str" : "1281405877",
        "id" : 1281405877
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 121, 143 ],
        "url" : "http:\/\/t.co\/4guuV2hv2M",
        "expanded_url" : "http:\/\/at.wh.gov\/ncRg7",
        "display_url" : "at.wh.gov\/ncRg7"
      } ]
    },
    "geo" : { },
    "id_str" : "359374289025253377",
    "text" : "Worth watching: The VP and @DrBiden met with Gandhi's granddaughter in New Delhi today at the Gandhi Smriti museum \u2014&gt; http:\/\/t.co\/4guuV2hv2M",
    "id" : 359374289025253377,
    "created_at" : "2013-07-22 18:08:02 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 359380033632092160,
  "created_at" : "2013-07-22 18:30:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    }, {
      "name" : "Gates Of The Arctic",
      "screen_name" : "GatesArcticNPS",
      "indices" : [ 75, 90 ],
      "id_str" : "65671278",
      "id" : 65671278
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Interior\/status\/359339008641343489\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/mHUfhsQj31",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BPyg7KyCIAAUQmr.jpg",
      "id_str" : "359339008649732096",
      "id" : 359339008649732096,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BPyg7KyCIAAUQmr.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 592,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 197,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 347,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 592,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/mHUfhsQj31"
    } ],
    "hashtags" : [ {
      "text" : "rainbow",
      "indices" : [ 65, 73 ]
    }, {
      "text" : "Alaska",
      "indices" : [ 91, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359367488909230082",
  "text" : "RT @Interior: Looks like someone finally made it to the end of a #rainbow. @GatesArcticNPS #Alaska http:\/\/t.co\/mHUfhsQj31",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gates Of The Arctic",
        "screen_name" : "GatesArcticNPS",
        "indices" : [ 61, 76 ],
        "id_str" : "65671278",
        "id" : 65671278
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Interior\/status\/359339008641343489\/photo\/1",
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/mHUfhsQj31",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BPyg7KyCIAAUQmr.jpg",
        "id_str" : "359339008649732096",
        "id" : 359339008649732096,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BPyg7KyCIAAUQmr.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 592,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 197,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 347,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 592,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/mHUfhsQj31"
      } ],
      "hashtags" : [ {
        "text" : "rainbow",
        "indices" : [ 51, 59 ]
      }, {
        "text" : "Alaska",
        "indices" : [ 77, 84 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "359339008641343489",
    "text" : "Looks like someone finally made it to the end of a #rainbow. @GatesArcticNPS #Alaska http:\/\/t.co\/mHUfhsQj31",
    "id" : 359339008641343489,
    "created_at" : "2013-07-22 15:47:50 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 359367488909230082,
  "created_at" : "2013-07-22 17:41:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Upworthy",
      "screen_name" : "Upworthy",
      "indices" : [ 3, 12 ],
      "id_str" : "524396430",
      "id" : 524396430
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 31, 42 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/Fpx9we09oz",
      "expanded_url" : "http:\/\/u.pw\/12vkYFZ",
      "display_url" : "u.pw\/12vkYFZ"
    } ]
  },
  "geo" : { },
  "id_str" : "359355974588448768",
  "text" : "RT @Upworthy: This is what the @WhiteHouse has to say about one of the most debated issues in America http:\/\/t.co\/Fpx9we09oz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.crowdbooster.com\" rel=\"nofollow\"\u003ECrowdbooster\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 17, 28 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/Fpx9we09oz",
        "expanded_url" : "http:\/\/u.pw\/12vkYFZ",
        "display_url" : "u.pw\/12vkYFZ"
      } ]
    },
    "geo" : { },
    "id_str" : "359340816981950464",
    "text" : "This is what the @WhiteHouse has to say about one of the most debated issues in America http:\/\/t.co\/Fpx9we09oz",
    "id" : 359340816981950464,
    "created_at" : "2013-07-22 15:55:01 +0000",
    "user" : {
      "name" : "Upworthy",
      "screen_name" : "Upworthy",
      "protected" : false,
      "id_str" : "524396430",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723597465941766144\/piclWuSr_normal.jpg",
      "id" : 524396430,
      "verified" : true
    }
  },
  "id" : 359355974588448768,
  "created_at" : "2013-07-22 16:55:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 21, 29 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359347597871300609",
  "text" : "RT @VP: PHOTO:VP and @DrBiden have arrived in New Delhi, their first stop on a 6 day trip to India and Singapore(WH photo) http:\/\/t.co\/EdlM\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dr. Jill Biden",
        "screen_name" : "DrBiden",
        "indices" : [ 13, 21 ],
        "id_str" : "1281405877",
        "id" : 1281405877
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/VP\/status\/359337894256709632\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/EdlMS3QAhC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BPyf6TXCEAAjTqH.jpg",
        "id_str" : "359337894260903936",
        "id" : 359337894260903936,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BPyf6TXCEAAjTqH.jpg",
        "sizes" : [ {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/EdlMS3QAhC"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "359337894256709632",
    "text" : "PHOTO:VP and @DrBiden have arrived in New Delhi, their first stop on a 6 day trip to India and Singapore(WH photo) http:\/\/t.co\/EdlMS3QAhC",
    "id" : 359337894256709632,
    "created_at" : "2013-07-22 15:43:25 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 359347597871300609,
  "created_at" : "2013-07-22 16:21:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/PjqiGJMcVE",
      "expanded_url" : "http:\/\/at.wh.gov\/ncv2V",
      "display_url" : "at.wh.gov\/ncv2V"
    } ]
  },
  "geo" : { },
  "id_str" : "359338456234729476",
  "text" : "President Obama will outline his vision for rebuilding middle-class security at Knox College on Wed. Don't miss it: http:\/\/t.co\/PjqiGJMcVE",
  "id" : 359338456234729476,
  "created_at" : "2013-07-22 15:45:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/359323974221578240\/photo\/1",
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/WvoZ2WiIrs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BPyTQDMCQAAuRmU.jpg",
      "id_str" : "359323974225772544",
      "id" : 359323974225772544,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BPyTQDMCQAAuRmU.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1150,
        "resize" : "fit",
        "w" : 1150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/WvoZ2WiIrs"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359323974221578240",
  "text" : "Oh, hello there! http:\/\/t.co\/WvoZ2WiIrs",
  "id" : 359323974221578240,
  "created_at" : "2013-07-22 14:48:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/bP9soLwGoZ",
      "expanded_url" : "http:\/\/at.wh.gov\/nb2kb",
      "display_url" : "at.wh.gov\/nb2kb"
    } ]
  },
  "geo" : { },
  "id_str" : "359108378674475009",
  "text" : "At Knox College on Wednesday, President Obama will lay out his vision for rebuilding middle-class security: http:\/\/t.co\/bP9soLwGoZ",
  "id" : 359108378674475009,
  "created_at" : "2013-07-22 00:31:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/NVJdoa08zX",
      "expanded_url" : "http:\/\/at.wh.gov\/nb2oq",
      "display_url" : "at.wh.gov\/nb2oq"
    } ]
  },
  "geo" : { },
  "id_str" : "359101212047585280",
  "text" : "President Obama returns to Knox College Wednesday\u2014where he laid out his economic vision 8 years ago: http:\/\/t.co\/NVJdoa08zX",
  "id" : 359101212047585280,
  "created_at" : "2013-07-22 00:02:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/359033926309801984\/photo\/1",
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/0Jsran3qmX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BPuLdChCcAA2dkl.jpg",
      "id_str" : "359033926313996288",
      "id" : 359033926313996288,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BPuLdChCcAA2dkl.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/0Jsran3qmX"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "359033926309801984",
  "text" : "Happy National Ice Cream Day! http:\/\/t.co\/0Jsran3qmX",
  "id" : 359033926309801984,
  "created_at" : "2013-07-21 19:35:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/6VuV2ghLCM",
      "expanded_url" : "http:\/\/at.wh.gov\/n9LMq",
      "display_url" : "at.wh.gov\/n9LMq"
    } ]
  },
  "geo" : { },
  "id_str" : "358648856407318529",
  "text" : "President Obama: \"Helen was a true pioneer.\" Full statement: http:\/\/t.co\/6VuV2ghLCM",
  "id" : 358648856407318529,
  "created_at" : "2013-07-20 18:05:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/iRAAHH9Y90",
      "expanded_url" : "http:\/\/at.wh.gov\/n9wkp",
      "display_url" : "at.wh.gov\/n9wkp"
    } ]
  },
  "geo" : { },
  "id_str" : "358625411304923138",
  "text" : "President Obama: \"Even though more work remains, our financial system is more fair &amp; much more sound\" Weekly Address: http:\/\/t.co\/iRAAHH9Y90",
  "id" : 358625411304923138,
  "created_at" : "2013-07-20 16:32:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "consumerfinance.gov",
      "screen_name" : "CFPB",
      "indices" : [ 111, 116 ],
      "id_str" : "234826866",
      "id" : 234826866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/QSACC8KZmF",
      "expanded_url" : "http:\/\/at.wh.gov\/n9whS",
      "display_url" : "at.wh.gov\/n9whS"
    } ]
  },
  "geo" : { },
  "id_str" : "358588400384745472",
  "text" : "In this week\u2019s address, President Obama discusses the Senate\u2019s confirmation of Rich Cordray as Director of the @CFPB: http:\/\/t.co\/QSACC8KZmF",
  "id" : 358588400384745472,
  "created_at" : "2013-07-20 14:05:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/PvF8zDAHCs",
      "expanded_url" : "http:\/\/at.wh.gov\/n8Etv",
      "display_url" : "at.wh.gov\/n8Etv"
    } ]
  },
  "geo" : { },
  "id_str" : "358305440171438080",
  "text" : "Full video: President Obama speaks on Trayvon Martin: http:\/\/t.co\/PvF8zDAHCs",
  "id" : 358305440171438080,
  "created_at" : "2013-07-19 19:20:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/DejQgfskAJ",
      "expanded_url" : "http:\/\/at.wh.gov\/n8Cp9",
      "display_url" : "at.wh.gov\/n8Cp9"
    } ]
  },
  "geo" : { },
  "id_str" : "358301675909423105",
  "text" : "\"Trayvon Martin could have been me 35 years ago.\" \u2014President Obama: http:\/\/t.co\/DejQgfskAJ",
  "id" : 358301675909423105,
  "created_at" : "2013-07-19 19:05:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/KvadYk9atb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "358281271090233345",
  "text" : "President Obama is speaking in the briefing room now. Watch: http:\/\/t.co\/KvadYk9atb",
  "id" : 358281271090233345,
  "created_at" : "2013-07-19 17:44:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. EPA",
      "screen_name" : "EPA",
      "indices" : [ 3, 7 ],
      "id_str" : "14615871",
      "id" : 14615871
    }, {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "indices" : [ 33, 41 ],
      "id_str" : "1530850933",
      "id" : 1530850933
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/eGa9aedGcu",
      "expanded_url" : "https:\/\/vine.co\/v\/hmThBTUOY0Q",
      "display_url" : "vine.co\/v\/hmThBTUOY0Q"
    } ]
  },
  "geo" : { },
  "id_str" : "358268803215794176",
  "text" : "RT @EPA: EPA's new Administrator @GinaEPA is sworn in! https:\/\/t.co\/eGa9aedGcu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gina McCarthy",
        "screen_name" : "GinaEPA",
        "indices" : [ 24, 32 ],
        "id_str" : "1530850933",
        "id" : 1530850933
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 46, 69 ],
        "url" : "https:\/\/t.co\/eGa9aedGcu",
        "expanded_url" : "https:\/\/vine.co\/v\/hmThBTUOY0Q",
        "display_url" : "vine.co\/v\/hmThBTUOY0Q"
      } ]
    },
    "geo" : { },
    "id_str" : "358228707380428800",
    "text" : "EPA's new Administrator @GinaEPA is sworn in! https:\/\/t.co\/eGa9aedGcu",
    "id" : 358228707380428800,
    "created_at" : "2013-07-19 14:15:54 +0000",
    "user" : {
      "name" : "U.S. EPA",
      "screen_name" : "EPA",
      "protected" : false,
      "id_str" : "14615871",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/632228259879628800\/-gvVhzPn_normal.png",
      "id" : 14615871,
      "verified" : true
    }
  },
  "id" : 358268803215794176,
  "created_at" : "2013-07-19 16:55:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PBS NewsHour",
      "screen_name" : "NewsHour",
      "indices" : [ 3, 12 ],
      "id_str" : "14437914",
      "id" : 14437914
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WeTheGeeks",
      "indices" : [ 44, 55 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/5TUJzs4rgu",
      "expanded_url" : "http:\/\/to.pbs.org\/1bvUSLn",
      "display_url" : "to.pbs.org\/1bvUSLn"
    } ]
  },
  "geo" : { },
  "id_str" : "358256629059682304",
  "text" : "RT @NewsHour: WATCH LIVE: White House hosts #WeTheGeeks G+ hangout on superheroes http:\/\/t.co\/5TUJzs4rgu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WeTheGeeks",
        "indices" : [ 30, 41 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/5TUJzs4rgu",
        "expanded_url" : "http:\/\/to.pbs.org\/1bvUSLn",
        "display_url" : "to.pbs.org\/1bvUSLn"
      } ]
    },
    "geo" : { },
    "id_str" : "358255643544649729",
    "text" : "WATCH LIVE: White House hosts #WeTheGeeks G+ hangout on superheroes http:\/\/t.co\/5TUJzs4rgu",
    "id" : 358255643544649729,
    "created_at" : "2013-07-19 16:02:56 +0000",
    "user" : {
      "name" : "PBS NewsHour",
      "screen_name" : "NewsHour",
      "protected" : false,
      "id_str" : "14437914",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793805679786090496\/gqA4z5BM_normal.jpg",
      "id" : 14437914,
      "verified" : true
    }
  },
  "id" : 358256629059682304,
  "created_at" : "2013-07-19 16:06:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "former Macon44",
      "screen_name" : "macon44",
      "indices" : [ 3, 11 ],
      "id_str" : "776593497122082820",
      "id" : 776593497122082820
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Whatever",
      "indices" : [ 120, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "358249544795951104",
  "text" : "RT @macon44: We're talking about invisibility cloaks, people. INVISIBILITY CLOAKS! You need to see this; Or not see it. #Whatever http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Whatever",
        "indices" : [ 107, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/INEnsDCTog",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/blog\/2013\/07\/17\/we-geeks-stuff-superheroes-are-made",
        "display_url" : "whitehouse.gov\/blog\/2013\/07\/1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "358248844045205505",
    "text" : "We're talking about invisibility cloaks, people. INVISIBILITY CLOAKS! You need to see this; Or not see it. #Whatever http:\/\/t.co\/INEnsDCTog",
    "id" : 358248844045205505,
    "created_at" : "2013-07-19 15:35:55 +0000",
    "user" : {
      "name" : "Macon Phillips",
      "screen_name" : "IIPCoordinator",
      "protected" : false,
      "id_str" : "110823581",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000495374915\/f6a5ae048ab7f8f12c0386114df53203_normal.jpeg",
      "id" : 110823581,
      "verified" : true
    }
  },
  "id" : 358249544795951104,
  "created_at" : "2013-07-19 15:38:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/358240812083068929\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/NJtcHTs9Xf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BPi6HtzCQAArJHu.jpg",
      "id_str" : "358240812091457536",
      "id" : 358240812091457536,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BPi6HtzCQAArJHu.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/NJtcHTs9Xf"
    } ],
    "hashtags" : [ {
      "text" : "WeTheGeeks",
      "indices" : [ 54, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/YpLqWkiw9F",
      "expanded_url" : "http:\/\/at.wh.gov\/n83X3",
      "display_url" : "at.wh.gov\/n83X3"
    } ]
  },
  "geo" : { },
  "id_str" : "358240812083068929",
  "text" : "Love superpowers? You're going to want to tune in for #WeTheGeeks at 12pm ET \u2014&gt; http:\/\/t.co\/YpLqWkiw9F, http:\/\/t.co\/NJtcHTs9Xf",
  "id" : 358240812083068929,
  "created_at" : "2013-07-19 15:04:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/358001443384471552\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/qZLBvuDQkT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BPfgan6CMAExt4d.jpg",
      "id_str" : "358001443392860161",
      "id" : 358001443392860161,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BPfgan6CMAExt4d.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/qZLBvuDQkT"
    } ],
    "hashtags" : [ {
      "text" : "TBT",
      "indices" : [ 106, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "358001443384471552",
  "text" : "President Obama: \"On behalf of my mother\u2014who argued with insurance companies even as she battled cancer.\" #TBT http:\/\/t.co\/qZLBvuDQkT",
  "id" : 358001443384471552,
  "created_at" : "2013-07-18 23:12:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "NelsonMandela",
      "screen_name" : "NelsonMandela",
      "indices" : [ 28, 42 ],
      "id_str" : "15762708",
      "id" : 15762708
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/357986436785520641\/photo\/1",
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/leBctLbf7o",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BPfSxH9CQAAyyzd.jpg",
      "id_str" : "357986436789714944",
      "id" : 357986436789714944,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BPfSxH9CQAAyyzd.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/leBctLbf7o"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357988152041947139",
  "text" : "RT @FLOTUS: Happy birthday, @NelsonMandela! http:\/\/t.co\/leBctLbf7o",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NelsonMandela",
        "screen_name" : "NelsonMandela",
        "indices" : [ 16, 30 ],
        "id_str" : "15762708",
        "id" : 15762708
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/357986436785520641\/photo\/1",
        "indices" : [ 32, 54 ],
        "url" : "http:\/\/t.co\/leBctLbf7o",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BPfSxH9CQAAyyzd.jpg",
        "id_str" : "357986436789714944",
        "id" : 357986436789714944,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BPfSxH9CQAAyyzd.jpg",
        "sizes" : [ {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/leBctLbf7o"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "357986436785520641",
    "text" : "Happy birthday, @NelsonMandela! http:\/\/t.co\/leBctLbf7o",
    "id" : 357986436785520641,
    "created_at" : "2013-07-18 22:13:12 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 357988152041947139,
  "created_at" : "2013-07-18 22:20:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. EPA",
      "screen_name" : "EPA",
      "indices" : [ 3, 7 ],
      "id_str" : "14615871",
      "id" : 14615871
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357984209446514688",
  "text" : "RT @EPA: Congratulations to our new Administrator Gina McCarthy!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "357957891132620800",
    "text" : "Congratulations to our new Administrator Gina McCarthy!",
    "id" : 357957891132620800,
    "created_at" : "2013-07-18 20:19:46 +0000",
    "user" : {
      "name" : "U.S. EPA",
      "screen_name" : "EPA",
      "protected" : false,
      "id_str" : "14615871",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/632228259879628800\/-gvVhzPn_normal.png",
      "id" : 14615871,
      "verified" : true
    }
  },
  "id" : 357984209446514688,
  "created_at" : "2013-07-18 22:04:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NelsonMandela",
      "screen_name" : "NelsonMandela",
      "indices" : [ 90, 104 ],
      "id_str" : "15762708",
      "id" : 15762708
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/ocuksLAKKO",
      "expanded_url" : "http:\/\/at.wh.gov\/n6tZH",
      "display_url" : "at.wh.gov\/n6tZH"
    } ]
  },
  "geo" : { },
  "id_str" : "357959871871717377",
  "text" : "\"We will forever draw strength and inspiration from his extraordinary example.\" \u2014Obama on @NelsonMandela's birthday: http:\/\/t.co\/ocuksLAKKO",
  "id" : 357959871871717377,
  "created_at" : "2013-07-18 20:27:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 16, 26 ]
    }, {
      "text" : "ObamacareInAction",
      "indices" : [ 121, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357937940330065920",
  "text" : "FACT: Thanks to #Obamacare, more than 8.5 million Americans will get insurance company rebates averaging $100 this year. #ObamacareInAction",
  "id" : 357937940330065920,
  "created_at" : "2013-07-18 19:00:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041A\u0430\u0442\u0435\u043D\u0430 \u041D\u0438\u043A\u043E\u043D\u0435\u043D\u043A\u043E",
      "screen_name" : "HealthCareTara",
      "indices" : [ 3, 18 ],
      "id_str" : "9448842",
      "id" : 9448842
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 52, 63 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357934997279219712",
  "text" : "RT @HealthCareTara: Excited to be tweeting from the @WhiteHouse. I'll be sharing the latest on the health care law\u2014and occasional Red Sox o\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 32, 43 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "357921712379146240",
    "text" : "Excited to be tweeting from the @WhiteHouse. I'll be sharing the latest on the health care law\u2014and occasional Red Sox or Springsteen facts.",
    "id" : 357921712379146240,
    "created_at" : "2013-07-18 17:56:00 +0000",
    "user" : {
      "name" : "Tara McGuinness",
      "screen_name" : "Tara44",
      "protected" : false,
      "id_str" : "1601549102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600334679951081472\/O9XyKAXl_normal.jpg",
      "id" : 1601549102,
      "verified" : true
    }
  },
  "id" : 357934997279219712,
  "created_at" : "2013-07-18 18:48:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/357931483324895232\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/YzIsI4G6is",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BPegyaYCUAERqBh.png",
      "id_str" : "357931483333283841",
      "id" : 357931483333283841,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BPegyaYCUAERqBh.png",
      "sizes" : [ {
        "h" : 284,
        "resize" : "fit",
        "w" : 634
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 152,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 284,
        "resize" : "fit",
        "w" : 634
      }, {
        "h" : 269,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/YzIsI4G6is"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357931483324895232",
  "text" : "\"Tom has lived the American Dream\u2014and has dedicated his career to keeping it within reach for hardworking families.\" http:\/\/t.co\/YzIsI4G6is",
  "id" : 357931483324895232,
  "created_at" : "2013-07-18 18:34:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamacareInAction",
      "indices" : [ 99, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357925101557121024",
  "text" : "FACT: Last year, Americans saved $3.4 billion in lower premiums thanks to the Affordable Care Act. #ObamacareInAction",
  "id" : 357925101557121024,
  "created_at" : "2013-07-18 18:09:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/357916932126674944\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/dXWen1pxwi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BPeTja7CEAAsWLS.jpg",
      "id_str" : "357916932130869248",
      "id" : 357916932130869248,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BPeTja7CEAAsWLS.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/dXWen1pxwi"
    } ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 67, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/0d3i7K3UGx",
      "expanded_url" : "http:\/\/at.wh.gov\/n66Mr",
      "display_url" : "at.wh.gov\/n66Mr"
    } ]
  },
  "geo" : { },
  "id_str" : "357916932126674944",
  "text" : "RT to share how millions of Americans are already benefitting from #Obamacare \u2014&gt; http:\/\/t.co\/0d3i7K3UGx, http:\/\/t.co\/dXWen1pxwi",
  "id" : 357916932126674944,
  "created_at" : "2013-07-18 17:37:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357899552222748672",
  "text" : "RT @Simas44: Obama on what GOP repeal would mean for consumer insurance refunds: \"Should they send it back to the insurance companies?\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "357892546032181249",
    "text" : "Obama on what GOP repeal would mean for consumer insurance refunds: \"Should they send it back to the insurance companies?\"",
    "id" : 357892546032181249,
    "created_at" : "2013-07-18 16:00:06 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 357899552222748672,
  "created_at" : "2013-07-18 16:27:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357890280747319297",
  "text" : "Obama: \"We\u2019re going to keep fighting...to make sure every American gets the care they need when they need it at a price they can afford.\"",
  "id" : 357890280747319297,
  "created_at" : "2013-07-18 15:51:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamacareInAction",
      "indices" : [ 103, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357889909765320704",
  "text" : "President Obama: \"It\u2019s about the mom in Arizona who can afford heart surgery for her little girl now.\" #ObamacareInAction",
  "id" : 357889909765320704,
  "created_at" : "2013-07-18 15:49:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 13, 17 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357889346520612865",
  "text" : "Obama on the #ACA: \"It\u2019s about the grandmother in Oregon whose free mammogram caught her breast cancer before it had the chance to spread.\"",
  "id" : 357889346520612865,
  "created_at" : "2013-07-18 15:47:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamacareInAction",
      "indices" : [ 119, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357888938372902914",
  "text" : "Obama: \"It\u2019s about the dad in Maryland who, for the first time ever, saw his family\u2019s premiums go down instead of up.\" #ObamacareInAction",
  "id" : 357888938372902914,
  "created_at" : "2013-07-18 15:45:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 13, 17 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357888482254925825",
  "text" : "Obama on the #ACA: \"Better benefits, stronger protections, more bang for your buck\u2014the basic notion that we ought to get what we pay for.\"",
  "id" : 357888482254925825,
  "created_at" : "2013-07-18 15:43:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamacareInAction",
      "indices" : [ 84, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357888051374071808",
  "text" : "President Obama: \"Last year alone, Americans saved $3.4 billion in lower premiums.\" #ObamacareInAction",
  "id" : 357888051374071808,
  "created_at" : "2013-07-18 15:42:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357887507280986112",
  "text" : "RT @WHLive: Obama on insurance company rebates: \"8.5 million rebates are being sent out this summer\u2014averaging around $100 each.\" #Obamacare\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ObamacareInAction",
        "indices" : [ 117, 135 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "357887231798689792",
    "text" : "Obama on insurance company rebates: \"8.5 million rebates are being sent out this summer\u2014averaging around $100 each.\" #ObamacareInAction",
    "id" : 357887231798689792,
    "created_at" : "2013-07-18 15:38:59 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 357887507280986112,
  "created_at" : "2013-07-18 15:40:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 13, 17 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357887061417668609",
  "text" : "Obama on the #ACA: \"Insurance companies have to spend at least 80% of every dollar you pay in premiums on your health care\u2014not on overhead.\"",
  "id" : 357887061417668609,
  "created_at" : "2013-07-18 15:38:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 12, 16 ]
    }, {
      "text" : "ObamacareInAction",
      "indices" : [ 118, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357886638027845632",
  "text" : "Obama: \"The #ACA is doing what it was designed to do\u2014deliver more choices, better benefits, a check on rising costs.\" #ObamacareInAction",
  "id" : 357886638027845632,
  "created_at" : "2013-07-18 15:36:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357886364026535936",
  "text" : "Obama: \"NY announced that next year, average premiums for consumers who buy insurance in their new marketplace will be at least 50% lower.\"",
  "id" : 357886364026535936,
  "created_at" : "2013-07-18 15:35:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamacareInAction",
      "indices" : [ 125, 143 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357886129531392000",
  "text" : "President Obama: \"In states like California, Oregon, Washington\u2014new competition &amp; new choices...are pushing costs down.\" #ObamacareInAction",
  "id" : 357886129531392000,
  "created_at" : "2013-07-18 15:34:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamacareInAction",
      "indices" : [ 118, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357885708481986560",
  "text" : "Obama: \"Starting Oct. 1st, new online marketplaces will allow consumers to...compare private health insurance plans.\" #ObamacareInAction",
  "id" : 357885708481986560,
  "created_at" : "2013-07-18 15:32:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 48, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/KvadYk9atb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "357885192557445120",
  "text" : "Happening now: President Obama speaks about how #Obamacare is already benefitting millions of Americans \u2014&gt; http:\/\/t.co\/KvadYk9atb",
  "id" : 357885192557445120,
  "created_at" : "2013-07-18 15:30:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "Max Baucus",
      "screen_name" : "MaxBaucus",
      "indices" : [ 41, 51 ],
      "id_str" : "346637907",
      "id" : 346637907
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/Sz7VlmBjez",
      "expanded_url" : "http:\/\/www.politico.com\/story\/2013\/07\/obamacare-provisions-timely-delay-94361.html#ixzz2ZLIjXWCP",
      "display_url" : "politico.com\/story\/2013\/07\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "357877307978940418",
  "text" : "RT @PressSec: Excellent op-ed by Senator @MaxBaucus on getting the implementation of the Affordable Care Act right: http:\/\/t.co\/Sz7VlmBjez.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Max Baucus",
        "screen_name" : "MaxBaucus",
        "indices" : [ 27, 37 ],
        "id_str" : "346637907",
        "id" : 346637907
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/Sz7VlmBjez",
        "expanded_url" : "http:\/\/www.politico.com\/story\/2013\/07\/obamacare-provisions-timely-delay-94361.html#ixzz2ZLIjXWCP",
        "display_url" : "politico.com\/story\/2013\/07\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "357876918567178241",
    "text" : "Excellent op-ed by Senator @MaxBaucus on getting the implementation of the Affordable Care Act right: http:\/\/t.co\/Sz7VlmBjez.",
    "id" : 357876918567178241,
    "created_at" : "2013-07-18 14:58:01 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 357877307978940418,
  "created_at" : "2013-07-18 14:59:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 58, 68 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/KvadYk9atb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "357871682700050432",
  "text" : "Tune in at 11:25am ET for President Obama's speech on how #Obamacare is already benefitting millions of Americans: http:\/\/t.co\/KvadYk9atb",
  "id" : 357871682700050432,
  "created_at" : "2013-07-18 14:37:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "jearnest44",
      "indices" : [ 3, 14 ],
      "id_str" : "369238541",
      "id" : 369238541
    }, {
      "name" : "Max Baucus",
      "screen_name" : "MaxBaucus",
      "indices" : [ 17, 27 ],
      "id_str" : "346637907",
      "id" : 346637907
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357629557043511297",
  "text" : "RT @jearnest44: .@MaxBaucus backs 1 yr delay of employer mandate. Says wont \"slow or diminish the overall effectiveness of the ACA.\" http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Max Baucus",
        "screen_name" : "MaxBaucus",
        "indices" : [ 1, 11 ],
        "id_str" : "346637907",
        "id" : 346637907
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/u8RhuL0I3a",
        "expanded_url" : "http:\/\/www.politico.com\/story\/2013\/07\/obamacare-provisions-timely-delay-94361.html#ixzz2ZLIjXWCP",
        "display_url" : "politico.com\/story\/2013\/07\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "357621238786568192",
    "text" : ".@MaxBaucus backs 1 yr delay of employer mandate. Says wont \"slow or diminish the overall effectiveness of the ACA.\" http:\/\/t.co\/u8RhuL0I3a",
    "id" : 357621238786568192,
    "created_at" : "2013-07-17 22:02:02 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "jearnest44",
      "protected" : false,
      "id_str" : "369238541",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1769108407\/Twitter_profile_photo_real_normal.JPG",
      "id" : 369238541,
      "verified" : true
    }
  },
  "id" : 357629557043511297,
  "created_at" : "2013-07-17 22:35:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/Na2j0vjVSf",
      "expanded_url" : "http:\/\/www.nytimes.com\/2013\/07\/17\/health\/health-plan-cost-for-new-yorkers-set-to-fall-50.html?ref=todayspaper",
      "display_url" : "nytimes.com\/2013\/07\/17\/hea\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "357602836009328640",
  "text" : "RT @PressSec: House R's respond to news that Obamacare will cut premiums in NY State by 50% - http:\/\/t.co\/Na2j0vjVSf - by voting to repeal \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/Na2j0vjVSf",
        "expanded_url" : "http:\/\/www.nytimes.com\/2013\/07\/17\/health\/health-plan-cost-for-new-yorkers-set-to-fall-50.html?ref=todayspaper",
        "display_url" : "nytimes.com\/2013\/07\/17\/hea\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "357599264634966017",
    "text" : "House R's respond to news that Obamacare will cut premiums in NY State by 50% - http:\/\/t.co\/Na2j0vjVSf - by voting to repeal it. Again.",
    "id" : 357599264634966017,
    "created_at" : "2013-07-17 20:34:43 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 357602836009328640,
  "created_at" : "2013-07-17 20:48:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "indices" : [ 3, 12 ],
      "id_str" : "36719281",
      "id" : 36719281
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357590825876094976",
  "text" : "RT @letsmove: Happening Now: Google+ Hangout about health &amp; fitness with Olympians, a CrossFit Champion, NFL player &amp; an Astronaut. http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 126, 148 ],
        "url" : "http:\/\/t.co\/yLdVgchBHB",
        "expanded_url" : "http:\/\/youtu.be\/gJvz10pvhiM",
        "display_url" : "youtu.be\/gJvz10pvhiM"
      } ]
    },
    "geo" : { },
    "id_str" : "357590769869144065",
    "text" : "Happening Now: Google+ Hangout about health &amp; fitness with Olympians, a CrossFit Champion, NFL player &amp; an Astronaut. http:\/\/t.co\/yLdVgchBHB",
    "id" : 357590769869144065,
    "created_at" : "2013-07-17 20:00:57 +0000",
    "user" : {
      "name" : "Let's Move!",
      "screen_name" : "letsmove",
      "protected" : false,
      "id_str" : "36719281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207340336\/780fc13e31b6fdd80bd57d000dc13838_normal.jpeg",
      "id" : 36719281,
      "verified" : true
    }
  },
  "id" : 357590825876094976,
  "created_at" : "2013-07-17 20:01:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Video",
      "screen_name" : "WHVideo",
      "indices" : [ 3, 11 ],
      "id_str" : "1378231782",
      "id" : 1378231782
    }, {
      "name" : "consumerfinance.gov",
      "screen_name" : "CFPB",
      "indices" : [ 97, 102 ],
      "id_str" : "234826866",
      "id" : 234826866
    }, {
      "name" : "Elizabeth Warren",
      "screen_name" : "SenWarren",
      "indices" : [ 124, 134 ],
      "id_str" : "970207298",
      "id" : 970207298
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357580423917867010",
  "text" : "RT @WHVideo: Today, Richard Cordray was finally confirmed as head of America's consumer watchdog @CFPB &amp; got a hug from @SenWarren http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "consumerfinance.gov",
        "screen_name" : "CFPB",
        "indices" : [ 84, 89 ],
        "id_str" : "234826866",
        "id" : 234826866
      }, {
        "name" : "Elizabeth Warren",
        "screen_name" : "SenWarren",
        "indices" : [ 111, 121 ],
        "id_str" : "970207298",
        "id" : 970207298
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/UVoLcxea5q",
        "expanded_url" : "http:\/\/instagram.com\/p\/b35_X-Qilm\/",
        "display_url" : "instagram.com\/p\/b35_X-Qilm\/"
      } ]
    },
    "geo" : { },
    "id_str" : "357571207421366272",
    "text" : "Today, Richard Cordray was finally confirmed as head of America's consumer watchdog @CFPB &amp; got a hug from @SenWarren http:\/\/t.co\/UVoLcxea5q",
    "id" : 357571207421366272,
    "created_at" : "2013-07-17 18:43:13 +0000",
    "user" : {
      "name" : "White House Video",
      "screen_name" : "WHVideo",
      "protected" : false,
      "id_str" : "1378231782",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3636216064\/e21f3204adfdbc85dafef197487218a0_normal.jpeg",
      "id" : 1378231782,
      "verified" : true
    }
  },
  "id" : 357580423917867010,
  "created_at" : "2013-07-17 19:19:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "consumerfinance.gov",
      "screen_name" : "CFPB",
      "indices" : [ 3, 8 ],
      "id_str" : "234826866",
      "id" : 234826866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/vS2R1AnNjl",
      "expanded_url" : "http:\/\/youtu.be\/itmkuB6ICYc",
      "display_url" : "youtu.be\/itmkuB6ICYc"
    } ]
  },
  "geo" : { },
  "id_str" : "357573013644259328",
  "text" : "RT @CFPB: A message from Director Cordray: http:\/\/t.co\/vS2R1AnNjl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/measuredvoice.com\/\" rel=\"nofollow\"\u003EMeasured Voice\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 33, 55 ],
        "url" : "http:\/\/t.co\/vS2R1AnNjl",
        "expanded_url" : "http:\/\/youtu.be\/itmkuB6ICYc",
        "display_url" : "youtu.be\/itmkuB6ICYc"
      } ]
    },
    "geo" : { },
    "id_str" : "357552790383497216",
    "text" : "A message from Director Cordray: http:\/\/t.co\/vS2R1AnNjl",
    "id" : 357552790383497216,
    "created_at" : "2013-07-17 17:30:02 +0000",
    "user" : {
      "name" : "consumerfinance.gov",
      "screen_name" : "CFPB",
      "protected" : false,
      "id_str" : "234826866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000026267147\/ab435400ed4215d94370fdfcf836dfbe_normal.png",
      "id" : 234826866,
      "verified" : true
    }
  },
  "id" : 357573013644259328,
  "created_at" : "2013-07-17 18:50:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 23, 41 ]
    }, {
      "text" : "SupportTheDream",
      "indices" : [ 124, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/OPZhJAxSDO",
      "expanded_url" : "http:\/\/at.wh.gov\/n3JuP",
      "display_url" : "at.wh.gov\/n3JuP"
    } ]
  },
  "geo" : { },
  "id_str" : "357555358073503744",
  "text" : "RT to spread the news: #ImmigrationReform would create jobs, reduce the deficit, and raise GDP \u2014&gt; http:\/\/t.co\/OPZhJAxSDO #SupportTheDream",
  "id" : 357555358073503744,
  "created_at" : "2013-07-17 17:40:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/357547542659088385\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/uDsIBiIUp3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BPZDmH7CQAEGpZG.jpg",
      "id_str" : "357547542663282689",
      "id" : 357547542663282689,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BPZDmH7CQAEGpZG.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/uDsIBiIUp3"
    } ],
    "hashtags" : [ {
      "text" : "SupportTheDream",
      "indices" : [ 84, 100 ]
    }, {
      "text" : "CIR",
      "indices" : [ 101, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357547542659088385",
  "text" : "Nearly all of us came from someplace else\u2014and that's one of our greatest strengths. #SupportTheDream #CIR http:\/\/t.co\/uDsIBiIUp3",
  "id" : 357547542659088385,
  "created_at" : "2013-07-17 17:09:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CFPB",
      "indices" : [ 111, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357519948895109124",
  "text" : "President Obama: \"Americans everywhere are better off because of what Rich has done as our consumer watchdog.\" #CFPB",
  "id" : 357519948895109124,
  "created_at" : "2013-07-17 15:19:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "consumerfinance.gov",
      "screen_name" : "CFPB",
      "indices" : [ 13, 18 ],
      "id_str" : "234826866",
      "id" : 234826866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357519161678761984",
  "text" : "Obama on the @CFPB: \"6 million Americans have gotten more than $400 mil in refunds from companies that engaged in unscrupulous practices.\"",
  "id" : 357519161678761984,
  "created_at" : "2013-07-17 15:16:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "consumerfinance.gov",
      "screen_name" : "CFPB",
      "indices" : [ 23, 28 ],
      "id_str" : "234826866",
      "id" : 234826866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357518448244428803",
  "text" : "President Obama on the @CFPB: \"Today, veterans have access to tools they need to defend against dishonest lenders and mortgage brokers.\"",
  "id" : 357518448244428803,
  "created_at" : "2013-07-17 15:13:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357518069419474944",
  "text" : "RT @WHLive: Obama on Cordray: \"We\u2019re giving Americans a guarantee that the protections they enjoy today will be around next year and for ye\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "357517973910589440",
    "text" : "Obama on Cordray: \"We\u2019re giving Americans a guarantee that the protections they enjoy today will be around next year and for years to come.\"",
    "id" : 357517973910589440,
    "created_at" : "2013-07-17 15:11:42 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 357518069419474944,
  "created_at" : "2013-07-17 15:12:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357517262707630080",
  "text" : "RT @WHLive: President Obama: \"Last year, I took steps on my own to temporarily appoint Richard so he could get to work on [consumers'] beha\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "357517150749065216",
    "text" : "President Obama: \"Last year, I took steps on my own to temporarily appoint Richard so he could get to work on [consumers'] behalf.\"",
    "id" : 357517150749065216,
    "created_at" : "2013-07-17 15:08:25 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 357517262707630080,
  "created_at" : "2013-07-17 15:08:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357517178079162368",
  "text" : "RT @WHLive: President Obama: \"For 2 years, Republicans in the Senate refused to give Rich a simple yes-or-no vote...because they didn\u2019t lik\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "consumerfinance.gov",
        "screen_name" : "CFPB",
        "indices" : [ 134, 139 ],
        "id_str" : "234826866",
        "id" : 234826866
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "357516967168577536",
    "text" : "President Obama: \"For 2 years, Republicans in the Senate refused to give Rich a simple yes-or-no vote...because they didn\u2019t like\" the @CFPB.",
    "id" : 357516967168577536,
    "created_at" : "2013-07-17 15:07:41 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 357517178079162368,
  "created_at" : "2013-07-17 15:08:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357516830488805376",
  "text" : "President Obama: \"Last night, Rich Cordray was finally confirmed by the U.S. Senate to keep serving as America\u2019s consumer watchdog.\"",
  "id" : 357516830488805376,
  "created_at" : "2013-07-17 15:07:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357516453282463744",
  "text" : "Obama: \"I ran for President to restore that basic bargain...that our economy works best not from the top-down, but from the middle-out.\"",
  "id" : 357516453282463744,
  "created_at" : "2013-07-17 15:05:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "consumerfinance.gov",
      "screen_name" : "CFPB",
      "indices" : [ 75, 80 ],
      "id_str" : "234826866",
      "id" : 234826866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/KvadYk9atb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "357515969993781249",
  "text" : "Happening now: President Obama speaks on Richard Cordray's confirmation to @CFPB Director \u2014&gt; http:\/\/t.co\/KvadYk9atb",
  "id" : 357515969993781249,
  "created_at" : "2013-07-17 15:03:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "consumerfinance.gov",
      "screen_name" : "CFPB",
      "indices" : [ 66, 71 ],
      "id_str" : "234826866",
      "id" : 234826866
    }, {
      "name" : "Kathleen Sebelius",
      "screen_name" : "Sebelius",
      "indices" : [ 105, 114 ],
      "id_str" : "2556859698",
      "id" : 2556859698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357509511084380164",
  "text" : "RT @VP: PHOTO:VP swears in Richard Cordray as the Director of the @CFPB this morning in his WW office w\/ @Sebelius (WH Photo) http:\/\/t.co\/M\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "consumerfinance.gov",
        "screen_name" : "CFPB",
        "indices" : [ 58, 63 ],
        "id_str" : "234826866",
        "id" : 234826866
      }, {
        "name" : "Kathleen Sebelius",
        "screen_name" : "Sebelius",
        "indices" : [ 97, 106 ],
        "id_str" : "2556859698",
        "id" : 2556859698
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/357508992265777152\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/Mn35E7Lrv0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BPYgiMiCcAAOkHu.jpg",
        "id_str" : "357508992274165760",
        "id" : 357508992274165760,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BPYgiMiCcAAOkHu.jpg",
        "sizes" : [ {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/Mn35E7Lrv0"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "357508992265777152",
    "text" : "PHOTO:VP swears in Richard Cordray as the Director of the @CFPB this morning in his WW office w\/ @Sebelius (WH Photo) http:\/\/t.co\/Mn35E7Lrv0",
    "id" : 357508992265777152,
    "created_at" : "2013-07-17 14:36:00 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 357509511084380164,
  "created_at" : "2013-07-17 14:38:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "consumerfinance.gov",
      "screen_name" : "CFPB",
      "indices" : [ 100, 105 ],
      "id_str" : "234826866",
      "id" : 234826866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/KvadYk9atb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "357506242454896641",
  "text" : "At 10:50am ET, President Obama speaks on the confirmation of Richard Cordray as the Director of the @CFPB. Watch: http:\/\/t.co\/KvadYk9atb",
  "id" : 357506242454896641,
  "created_at" : "2013-07-17 14:25:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThanksObamacare",
      "indices" : [ 114, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/Q4F3VixwGF",
      "expanded_url" : "http:\/\/at.wh.gov\/n33KV",
      "display_url" : "at.wh.gov\/n33KV"
    } ]
  },
  "geo" : { },
  "id_str" : "357498218474520577",
  "text" : "Great news: New Yorkers buying health insurance will see costs drop by 50% next year \u2014&gt; http:\/\/t.co\/Q4F3VixwGF #ThanksObamacare",
  "id" : 357498218474520577,
  "created_at" : "2013-07-17 13:53:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "indices" : [ 114, 122 ],
      "id_str" : "807095",
      "id" : 807095
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 27, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357491550520999936",
  "text" : "RT @vj44: Please RT --&gt; #Obamacare in action! New Yorkers' insurance premiums will tumble by 50% next year via @nytimes  http:\/\/t.co\/OLCKch\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The New York Times",
        "screen_name" : "nytimes",
        "indices" : [ 104, 112 ],
        "id_str" : "807095",
        "id" : 807095
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Obamacare",
        "indices" : [ 17, 27 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/OLCKchvNkS",
        "expanded_url" : "http:\/\/www.nytimes.com\/2013\/07\/17\/health\/health-plan-cost-for-new-yorkers-set-to-fall-50.html?pagewanted=all&_r=0",
        "display_url" : "nytimes.com\/2013\/07\/17\/hea\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "357490169395425280",
    "text" : "Please RT --&gt; #Obamacare in action! New Yorkers' insurance premiums will tumble by 50% next year via @nytimes  http:\/\/t.co\/OLCKchvNkS",
    "id" : 357490169395425280,
    "created_at" : "2013-07-17 13:21:12 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 357491550520999936,
  "created_at" : "2013-07-17 13:26:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CantMakeThisUp",
      "indices" : [ 101, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357485669137920000",
  "text" : "RT @Simas44: Insurance premiums drop by 50% for many New Yorkers. Time for another GOP repeal vote?! #CantMakeThisUp -----&gt;  http:\/\/t.co\/hp\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CantMakeThisUp",
        "indices" : [ 88, 103 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/hpxCJATc9i",
        "expanded_url" : "http:\/\/nyti.ms\/1arT6b3",
        "display_url" : "nyti.ms\/1arT6b3"
      } ]
    },
    "geo" : { },
    "id_str" : "357467137897533440",
    "text" : "Insurance premiums drop by 50% for many New Yorkers. Time for another GOP repeal vote?! #CantMakeThisUp -----&gt;  http:\/\/t.co\/hpxCJATc9i",
    "id" : 357467137897533440,
    "created_at" : "2013-07-17 11:49:41 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 357485669137920000,
  "created_at" : "2013-07-17 13:03:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/4FmaGcp9QX",
      "expanded_url" : "http:\/\/at.wh.gov\/n201u",
      "display_url" : "at.wh.gov\/n201u"
    } ]
  },
  "geo" : { },
  "id_str" : "357270524533022721",
  "text" : "President Obama on the Senate moving forward with cabinet nominees who \"have waited far too long for a vote.\" http:\/\/t.co\/4FmaGcp9QX",
  "id" : 357270524533022721,
  "created_at" : "2013-07-16 22:48:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    }, {
      "name" : "Grand Teton NP",
      "screen_name" : "GrandTetonNPS",
      "indices" : [ 61, 75 ],
      "id_str" : "44991932",
      "id" : 44991932
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/357251841811165184\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/swvkeDudCg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BPU2qEdCMAAECkn.jpg",
      "id_str" : "357251841823748096",
      "id" : 357251841823748096,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BPU2qEdCMAAECkn.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/swvkeDudCg"
    } ],
    "hashtags" : [ {
      "text" : "sunrise",
      "indices" : [ 92, 100 ]
    }, {
      "text" : "Wyoming",
      "indices" : [ 102, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357258373693046784",
  "text" : "RT @Interior: There's nothing quite like an early morning in @GrandTetonNPS waiting for the #sunrise. #Wyoming http:\/\/t.co\/swvkeDudCg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Grand Teton NP",
        "screen_name" : "GrandTetonNPS",
        "indices" : [ 47, 61 ],
        "id_str" : "44991932",
        "id" : 44991932
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/357251841811165184\/photo\/1",
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/swvkeDudCg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BPU2qEdCMAAECkn.jpg",
        "id_str" : "357251841823748096",
        "id" : 357251841823748096,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BPU2qEdCMAAECkn.jpg",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/swvkeDudCg"
      } ],
      "hashtags" : [ {
        "text" : "sunrise",
        "indices" : [ 78, 86 ]
      }, {
        "text" : "Wyoming",
        "indices" : [ 88, 96 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "357251841811165184",
    "text" : "There's nothing quite like an early morning in @GrandTetonNPS waiting for the #sunrise. #Wyoming http:\/\/t.co\/swvkeDudCg",
    "id" : 357251841811165184,
    "created_at" : "2013-07-16 21:34:11 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 357258373693046784,
  "created_at" : "2013-07-16 22:00:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "indices" : [ 3, 16 ],
      "id_str" : "78138151",
      "id" : 78138151
    }, {
      "name" : "rushrobert",
      "screen_name" : "leon_krauze",
      "indices" : [ 67, 79 ],
      "id_str" : "782631523983831040",
      "id" : 782631523983831040
    }, {
      "name" : "Univision",
      "screen_name" : "Univision",
      "indices" : [ 113, 123 ],
      "id_str" : "40924038",
      "id" : 40924038
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 83, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357233809864929280",
  "text" : "RT @lacasablanca: Worth watching: President Obama's interview with @Leon_Krauze on #ImmigrationReform tonight on @Univision at 6:00pm PT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "rushrobert",
        "screen_name" : "leon_krauze",
        "indices" : [ 49, 61 ],
        "id_str" : "782631523983831040",
        "id" : 782631523983831040
      }, {
        "name" : "Univision",
        "screen_name" : "Univision",
        "indices" : [ 95, 105 ],
        "id_str" : "40924038",
        "id" : 40924038
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ImmigrationReform",
        "indices" : [ 65, 83 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "357190322750636032",
    "text" : "Worth watching: President Obama's interview with @Leon_Krauze on #ImmigrationReform tonight on @Univision at 6:00pm PT",
    "id" : 357190322750636032,
    "created_at" : "2013-07-16 17:29:43 +0000",
    "user" : {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "protected" : false,
      "id_str" : "78138151",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616360382911754241\/4Tfqcfie_normal.png",
      "id" : 78138151,
      "verified" : true
    }
  },
  "id" : 357233809864929280,
  "created_at" : "2013-07-16 20:22:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 32, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357220698160242688",
  "text" : "RT if you agree: We should pass #ImmigrationReform so our best &amp; brightest students from around the world stay here &amp; help grow our economy.",
  "id" : 357220698160242688,
  "created_at" : "2013-07-16 19:30:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationNation",
      "indices" : [ 121, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357209352416927744",
  "text" : "FACT: U.S. immigrants represent 50% of PhDs working in math and computer science and 57% of PhDs working in engineering. #ImmigrationNation",
  "id" : 357209352416927744,
  "created_at" : "2013-07-16 18:45:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationNation",
      "indices" : [ 115, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357202098053586945",
  "text" : "FACT: In 2010, more than 70% of foreign graduate students were studying science, technology, engineering, or math. #ImmigrationNation",
  "id" : 357202098053586945,
  "created_at" : "2013-07-16 18:16:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationNation",
      "indices" : [ 99, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357194874405134336",
  "text" : "FACT: More than 40% of Fortune 500 companies were founded by immigrants or children of immigrants. #ImmigrationNation",
  "id" : 357194874405134336,
  "created_at" : "2013-07-16 17:47:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Google",
      "screen_name" : "google",
      "indices" : [ 102, 109 ],
      "id_str" : "20536157",
      "id" : 20536157
    }, {
      "name" : "eBay",
      "screen_name" : "eBay",
      "indices" : [ 111, 116 ],
      "id_str" : "19709040",
      "id" : 19709040
    }, {
      "name" : "Yahoo",
      "screen_name" : "Yahoo",
      "indices" : [ 118, 124 ],
      "id_str" : "19380829",
      "id" : 19380829
    }, {
      "name" : "Intel",
      "screen_name" : "intel",
      "indices" : [ 130, 136 ],
      "id_str" : "2803191",
      "id" : 2803191
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357189190145933312",
  "text" : "FACT: Immigrants have started one-fourth of public U.S. companies backed by venture capital\u2014including @Google, @eBay, @Yahoo, and @Intel.",
  "id" : 357189190145933312,
  "created_at" : "2013-07-16 17:25:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/357180256836255744\/photo\/1",
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/do1i8diaVI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BPT1jRoCAAAeqek.jpg",
      "id_str" : "357180256844644352",
      "id" : 357180256844644352,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BPT1jRoCAAAeqek.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/do1i8diaVI"
    } ],
    "hashtags" : [ {
      "text" : "ImmigrationNation",
      "indices" : [ 72, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357180256836255744",
  "text" : "FACT: In 2011, immigrants started 28% of all new businesses in the U.S. #ImmigrationNation, http:\/\/t.co\/do1i8diaVI",
  "id" : 357180256836255744,
  "created_at" : "2013-07-16 16:49:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 21, 39 ]
    }, {
      "text" : "ImmigrationNation",
      "indices" : [ 112, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/LHGNPTU8Z7",
      "expanded_url" : "http:\/\/at.wh.gov\/n1bqD",
      "display_url" : "at.wh.gov\/n1bqD"
    } ]
  },
  "geo" : { },
  "id_str" : "357174004643135488",
  "text" : "Watch why the Senate #ImmigrationReform bill would be a big boost for our economy --&gt; http:\/\/t.co\/LHGNPTU8Z7 #ImmigrationNation",
  "id" : 357174004643135488,
  "created_at" : "2013-07-16 16:24:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357159966609637378",
  "text" : "RT @Simas44: Worth sharing. \"Health Insurance Within Reach\" Solid NYT consumer piece on Health Insurance Marketplaces with video. http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/z5lcMuHrbx",
        "expanded_url" : "http:\/\/nyti.ms\/12BANi0",
        "display_url" : "nyti.ms\/12BANi0"
      } ]
    },
    "geo" : { },
    "id_str" : "357158346886889473",
    "text" : "Worth sharing. \"Health Insurance Within Reach\" Solid NYT consumer piece on Health Insurance Marketplaces with video. http:\/\/t.co\/z5lcMuHrbx",
    "id" : 357158346886889473,
    "created_at" : "2013-07-16 15:22:40 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 357159966609637378,
  "created_at" : "2013-07-16 15:29:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/357155970952093696\/photo\/1",
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/FV20p6JKcC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BPTfdpqCYAA12uT.jpg",
      "id_str" : "357155970960482304",
      "id" : 357155970960482304,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BPTfdpqCYAA12uT.jpg",
      "sizes" : [ {
        "h" : 734,
        "resize" : "fit",
        "w" : 932
      }, {
        "h" : 473,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 734,
        "resize" : "fit",
        "w" : 932
      }, {
        "h" : 268,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/FV20p6JKcC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "357155970952093696",
  "text" : "Thanks for the socks, #41! http:\/\/t.co\/FV20p6JKcC",
  "id" : 357155970952093696,
  "created_at" : "2013-07-16 15:13:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Points of Light",
      "screen_name" : "PointsofLight",
      "indices" : [ 77, 91 ],
      "id_str" : "224382700",
      "id" : 224382700
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/356926183000121345\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/c3ecX9Fjv2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BPQOeO1CIAEfh79.jpg",
      "id_str" : "356926183008509953",
      "id" : 356926183008509953,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BPQOeO1CIAEfh79.jpg",
      "sizes" : [ {
        "h" : 737,
        "resize" : "fit",
        "w" : 737
      }, {
        "h" : 737,
        "resize" : "fit",
        "w" : 737
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/c3ecX9Fjv2"
    } ],
    "hashtags" : [ {
      "text" : "MyPointOfLight",
      "indices" : [ 99, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "356926183000121345",
  "text" : "President Obama and President George H. W. Bush presenting the 5,000th Daily @PointsOfLight Award. #MyPointOfLight, http:\/\/t.co\/c3ecX9Fjv2",
  "id" : 356926183000121345,
  "created_at" : "2013-07-16 00:00:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThanksForFollowing",
      "indices" : [ 118, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/38SnLO11MB",
      "expanded_url" : "http:\/\/at.wh.gov\/mZAqw",
      "display_url" : "at.wh.gov\/mZAqw"
    } ]
  },
  "geo" : { },
  "id_str" : "356911991140528129",
  "text" : "Today, we passed 4 million followers. Here are some of our favorite tweets from along the way: http:\/\/t.co\/38SnLO11MB #ThanksForFollowing",
  "id" : 356911991140528129,
  "created_at" : "2013-07-15 23:03:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DARPADRC",
      "indices" : [ 78, 87 ]
    }, {
      "text" : "STEM",
      "indices" : [ 88, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/bSsHzZQtUi",
      "expanded_url" : "http:\/\/at.wh.gov\/mZuYQ",
      "display_url" : "at.wh.gov\/mZuYQ"
    } ]
  },
  "geo" : { },
  "id_str" : "356897328327700481",
  "text" : "Meet ATLAS\u2014one of the most advanced robots ever built: http:\/\/t.co\/bSsHzZQtUi #DARPADRC #STEM",
  "id" : 356897328327700481,
  "created_at" : "2013-07-15 22:05:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kathleen Sebelius",
      "screen_name" : "Sebelius",
      "indices" : [ 3, 12 ],
      "id_str" : "2556859698",
      "id" : 2556859698
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HIV",
      "indices" : [ 39, 43 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/AojPYlEnnT",
      "expanded_url" : "http:\/\/www.huffingtonpost.com\/sec-kathleen-sebelius\/the-hiv-care-continuum-in_b_3599435.html",
      "display_url" : "huffingtonpost.com\/sec-kathleen-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "356877037790703618",
  "text" : "RT @Sebelius: My blog post on National #HIV\/AIDS Strategy, focusing on HIV care continuum http:\/\/t.co\/AojPYlEnnT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HIV",
        "indices" : [ 25, 29 ]
      } ],
      "urls" : [ {
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/AojPYlEnnT",
        "expanded_url" : "http:\/\/www.huffingtonpost.com\/sec-kathleen-sebelius\/the-hiv-care-continuum-in_b_3599435.html",
        "display_url" : "huffingtonpost.com\/sec-kathleen-s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "356855512907784193",
    "text" : "My blog post on National #HIV\/AIDS Strategy, focusing on HIV care continuum http:\/\/t.co\/AojPYlEnnT",
    "id" : 356855512907784193,
    "created_at" : "2013-07-15 19:19:18 +0000",
    "user" : {
      "name" : "Kathleen Sebelius",
      "screen_name" : "SecSebelius",
      "protected" : false,
      "id_str" : "1023020557",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000082519123\/6450b6c1fe4ad3432aacf01adf22ac37_normal.png",
      "id" : 1023020557,
      "verified" : true
    }
  },
  "id" : 356877037790703618,
  "created_at" : "2013-07-15 20:44:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "356838545928896512",
  "text" : "President Obama to President George H. W. Bush: \"You have helped so many Americans discover that they, too, have something to contribute.\"",
  "id" : 356838545928896512,
  "created_at" : "2013-07-15 18:11:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyPointOfLight",
      "indices" : [ 115, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "356837241986883584",
  "text" : "President Obama: \"Service is not a Democratic value or a Republican value. It\u2019s a core part of being an American.\" #MyPointOfLight",
  "id" : 356837241986883584,
  "created_at" : "2013-07-15 18:06:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "356836974922973185",
  "text" : "RT @WHLive: Obama: \"Our country is a better and a stronger force for good in the world because\u2014more &amp; more\u2014we are a people that serve.\" #My\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MyPointOfLight",
        "indices" : [ 128, 143 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "356836811613548544",
    "text" : "Obama: \"Our country is a better and a stronger force for good in the world because\u2014more &amp; more\u2014we are a people that serve.\" #MyPointOfLight",
    "id" : 356836811613548544,
    "created_at" : "2013-07-15 18:05:00 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 356836974922973185,
  "created_at" : "2013-07-15 18:05:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyPointOfLight",
      "indices" : [ 104, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "356836099605266433",
  "text" : "President Obama: \"Since 1989, the number of Americans who volunteer has grown by more than 25 million.\" #MyPointOfLight",
  "id" : 356836099605266433,
  "created_at" : "2013-07-15 18:02:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Points of Light",
      "screen_name" : "PointsofLight",
      "indices" : [ 21, 35 ],
      "id_str" : "224382700",
      "id" : 224382700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "356835799397969920",
  "text" : "Obama on the 5,000th @PointsOfLight winner: Their non-profit, Outreach, \"has distributed [more than 233 million] meals to hungry children.\"",
  "id" : 356835799397969920,
  "created_at" : "2013-07-15 18:00:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyPointOfLight",
      "indices" : [ 119, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "356834516775604226",
  "text" : "President Obama: President Bush \"created an award...to recognize Americans who serve their neighbors and communities.\" #MyPointOfLight",
  "id" : 356834516775604226,
  "created_at" : "2013-07-15 17:55:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Points of Light",
      "screen_name" : "PointsofLight",
      "indices" : [ 77, 91 ],
      "id_str" : "224382700",
      "id" : 224382700
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyPointOfLight",
      "indices" : [ 123, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/KvadYk9atb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "356833089835630593",
  "text" : "Watch now: President Obama and President George H. W. Bush honor the 5,000th @PointsOfLight winner. http:\/\/t.co\/KvadYk9atb #MyPointOfLight",
  "id" : 356833089835630593,
  "created_at" : "2013-07-15 17:50:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    }, {
      "name" : "White Sands Natl Mon",
      "screen_name" : "WhiteSands_NPS",
      "indices" : [ 98, 113 ],
      "id_str" : "292512828",
      "id" : 292512828
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/356804875813781506\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/QZPOrm0drr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BPOgJOWCAAA9qfZ.jpg",
      "id_str" : "356804875822170112",
      "id" : 356804875822170112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BPOgJOWCAAA9qfZ.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 767,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 767,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 449,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/QZPOrm0drr"
    } ],
    "hashtags" : [ {
      "text" : "NewMexico",
      "indices" : [ 87, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "356814571081703424",
  "text" : "RT @Interior: One of the world's great natural wonders - the glistening white sands of #NewMexico @WhiteSands_NPS http:\/\/t.co\/QZPOrm0drr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "White Sands Natl Mon",
        "screen_name" : "WhiteSands_NPS",
        "indices" : [ 84, 99 ],
        "id_str" : "292512828",
        "id" : 292512828
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/356804875813781506\/photo\/1",
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/QZPOrm0drr",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BPOgJOWCAAA9qfZ.jpg",
        "id_str" : "356804875822170112",
        "id" : 356804875822170112,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BPOgJOWCAAA9qfZ.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 767,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 767,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 449,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/QZPOrm0drr"
      } ],
      "hashtags" : [ {
        "text" : "NewMexico",
        "indices" : [ 73, 83 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "356804875813781506",
    "text" : "One of the world's great natural wonders - the glistening white sands of #NewMexico @WhiteSands_NPS http:\/\/t.co\/QZPOrm0drr",
    "id" : 356804875813781506,
    "created_at" : "2013-07-15 15:58:06 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 356814571081703424,
  "created_at" : "2013-07-15 16:36:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Points of Light",
      "screen_name" : "PointsofLight",
      "indices" : [ 82, 96 ],
      "id_str" : "224382700",
      "id" : 224382700
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyPointOfLight",
      "indices" : [ 128, 143 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/KvadYk9atb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "356799246969737218",
  "text" : "At 1:45pm ET, President Obama &amp; President George H. W. Bush honor the 5,000th @PointsOfLight winner: http:\/\/t.co\/KvadYk9atb #MyPointOfLight",
  "id" : 356799246969737218,
  "created_at" : "2013-07-15 15:35:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Points of Light",
      "screen_name" : "PointsofLight",
      "indices" : [ 3, 17 ],
      "id_str" : "224382700",
      "id" : 224382700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "356794965415825409",
  "text" : "RT @PointsofLight: Today we celebrate our 5000th Daily Point of Light. Tweet someone who's made a difference in YOUR life to #mypointofligh\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twuffer.com\" rel=\"nofollow\"\u003ETwuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "mypointoflight",
        "indices" : [ 106, 121 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "356784042714202112",
    "text" : "Today we celebrate our 5000th Daily Point of Light. Tweet someone who's made a difference in YOUR life to #mypointoflight. We'll watch &amp; RT!",
    "id" : 356784042714202112,
    "created_at" : "2013-07-15 14:35:19 +0000",
    "user" : {
      "name" : "Points of Light",
      "screen_name" : "PointsofLight",
      "protected" : false,
      "id_str" : "224382700",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/526549601134710784\/7UzjUF1M_normal.jpeg",
      "id" : 224382700,
      "verified" : false
    }
  },
  "id" : 356794965415825409,
  "created_at" : "2013-07-15 15:18:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/356507721933139971\/photo\/1",
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/c1YducSuV1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BPKR4l3CMAIuvSl.png",
      "id_str" : "356507721937334274",
      "id" : 356507721937334274,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BPKR4l3CMAIuvSl.png",
      "sizes" : [ {
        "h" : 772,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 772,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 273,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 483,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/c1YducSuV1"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "356507721933139971",
  "text" : "Statement by President Obama on Trayvon Martin: http:\/\/t.co\/c1YducSuV1",
  "id" : 356507721933139971,
  "created_at" : "2013-07-14 20:17:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/fgrJLVD4Ar",
      "expanded_url" : "http:\/\/wh.gov\/laNQE",
      "display_url" : "wh.gov\/laNQE"
    } ]
  },
  "geo" : { },
  "id_str" : "356492648988680193",
  "text" : "\"The death of Trayvon Martin was a tragedy. Not just for\u2026any one community, but for America.\" \u2014President Obama: http:\/\/t.co\/fgrJLVD4Ar",
  "id" : 356492648988680193,
  "created_at" : "2013-07-14 19:17:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 97, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/xW1n2YBaX1",
      "expanded_url" : "http:\/\/at.wh.gov\/mVmyE",
      "display_url" : "at.wh.gov\/mVmyE"
    } ]
  },
  "geo" : { },
  "id_str" : "356088371174572032",
  "text" : "\"Tell your Reps. that now is the time. Call or email or post on their Facebook walls.\" \u2014Obama on #ImmigrationReform: http:\/\/t.co\/xW1n2YBaX1",
  "id" : 356088371174572032,
  "created_at" : "2013-07-13 16:30:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/356057947119431680\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/MCZnJNvCRH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BPD40QICMAAH9Ml.jpg",
      "id_str" : "356057947127820288",
      "id" : 356057947127820288,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BPD40QICMAAH9Ml.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/MCZnJNvCRH"
    } ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 57, 75 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/At0Yp1yozO",
      "expanded_url" : "http:\/\/on.wh.gov\/LPapTcM",
      "display_url" : "on.wh.gov\/LPapTcM"
    } ]
  },
  "geo" : { },
  "id_str" : "356057947119431680",
  "text" : "Obama: \"The House needs to act so I can sign commonsense #ImmigrationReform into law.\" http:\/\/t.co\/At0Yp1yozO, http:\/\/t.co\/MCZnJNvCRH",
  "id" : 356057947119431680,
  "created_at" : "2013-07-13 14:30:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MalalaDay",
      "indices" : [ 130, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "355812237065191424",
  "text" : "\u201CWhen a girl is determined to learn and her family and community support her, she cannot be stopped by anyone.\" \u2014Malala Yousafzai #MalalaDay",
  "id" : 355812237065191424,
  "created_at" : "2013-07-12 22:13:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 7, 18 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    }, {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 20, 29 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 31, 36 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 42, 50 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FF",
      "indices" : [ 106, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "355771082638245889",
  "text" : "Follow @Pfeiffer44, @PressSec, @VJ44, and @Simas44 for the latest from President Obama's senior advisors. #FF",
  "id" : 355771082638245889,
  "created_at" : "2013-07-12 19:30:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. EPA",
      "screen_name" : "EPAGov",
      "indices" : [ 3, 10 ],
      "id_str" : "1604108887",
      "id" : 1604108887
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Climate",
      "indices" : [ 12, 20 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "355766283943419905",
  "text" : "RT @EPAgov: #Climate change may lead to rising sea levels &amp; more intense storms, but currently no science to support the occurrence of a #S\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Climate",
        "indices" : [ 0, 8 ]
      }, {
        "text" : "Sharknado",
        "indices" : [ 129, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "355694549349314562",
    "text" : "#Climate change may lead to rising sea levels &amp; more intense storms, but currently no science to support the occurrence of a #Sharknado.",
    "id" : 355694549349314562,
    "created_at" : "2013-07-12 14:26:03 +0000",
    "user" : {
      "name" : "U.S. EPA",
      "screen_name" : "EPA",
      "protected" : false,
      "id_str" : "14615871",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/632228259879628800\/-gvVhzPn_normal.png",
      "id" : 14615871,
      "verified" : true
    }
  },
  "id" : 355766283943419905,
  "created_at" : "2013-07-12 19:11:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    }, {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 40, 45 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "355754574864322560",
  "text" : "RT @JoiningForces: RT if you agree with @vj44: \u201CTogether, we can\u2014and must\u2014help our veterans remember that they are never alone.\u201D http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Valerie Jarrett",
        "screen_name" : "vj44",
        "indices" : [ 21, 26 ],
        "id_str" : "595515713",
        "id" : 595515713
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/r713FzHtRk",
        "expanded_url" : "http:\/\/ow.ly\/mSWI2",
        "display_url" : "ow.ly\/mSWI2"
      } ]
    },
    "geo" : { },
    "id_str" : "355753661340725248",
    "text" : "RT if you agree with @vj44: \u201CTogether, we can\u2014and must\u2014help our veterans remember that they are never alone.\u201D http:\/\/t.co\/r713FzHtRk",
    "id" : 355753661340725248,
    "created_at" : "2013-07-12 18:20:57 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 355754574864322560,
  "created_at" : "2013-07-12 18:24:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    }, {
      "name" : "Ross Douthat",
      "screen_name" : "DouthatNYT",
      "indices" : [ 54, 65 ],
      "id_str" : "546135718",
      "id" : 546135718
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/2LYLEe1qUL",
      "expanded_url" : "http:\/\/nyti.ms\/178WZja",
      "display_url" : "nyti.ms\/178WZja"
    } ]
  },
  "geo" : { },
  "id_str" : "355744750734815232",
  "text" : "RT @pfeiffer44: Powerful critique of today's GOP from @douthatNYT The Farm Bill and the Common Good http:\/\/t.co\/2LYLEe1qUL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ross Douthat",
        "screen_name" : "DouthatNYT",
        "indices" : [ 38, 49 ],
        "id_str" : "546135718",
        "id" : 546135718
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/2LYLEe1qUL",
        "expanded_url" : "http:\/\/nyti.ms\/178WZja",
        "display_url" : "nyti.ms\/178WZja"
      } ]
    },
    "geo" : { },
    "id_str" : "355739998319935488",
    "text" : "Powerful critique of today's GOP from @douthatNYT The Farm Bill and the Common Good http:\/\/t.co\/2LYLEe1qUL",
    "id" : 355739998319935488,
    "created_at" : "2013-07-12 17:26:39 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 355744750734815232,
  "created_at" : "2013-07-12 17:45:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "United Nations",
      "screen_name" : "UN",
      "indices" : [ 3, 6 ],
      "id_str" : "14159148",
      "id" : 14159148
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MalalaDay",
      "indices" : [ 11, 21 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "355715319140073472",
  "text" : "RT @UN: On #MalalaDay let us pledge to deliver the best gift of all -- quality education for every girl &amp; boy in the world. http:\/\/t.co\/1j2\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MalalaDay",
        "indices" : [ 3, 13 ]
      } ],
      "urls" : [ {
        "indices" : [ 120, 142 ],
        "url" : "http:\/\/t.co\/1j24Xj5vcO",
        "expanded_url" : "http:\/\/huff.to\/183PI8O",
        "display_url" : "huff.to\/183PI8O"
      } ]
    },
    "geo" : { },
    "id_str" : "355447201612312577",
    "text" : "On #MalalaDay let us pledge to deliver the best gift of all -- quality education for every girl &amp; boy in the world. http:\/\/t.co\/1j24Xj5vcO",
    "id" : 355447201612312577,
    "created_at" : "2013-07-11 22:03:11 +0000",
    "user" : {
      "name" : "United Nations",
      "screen_name" : "UN",
      "protected" : false,
      "id_str" : "14159148",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/538328216729968642\/SdfeQXSM_normal.png",
      "id" : 14159148,
      "verified" : true
    }
  },
  "id" : 355715319140073472,
  "created_at" : "2013-07-12 15:48:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/tefkK5z6iF",
      "expanded_url" : "http:\/\/at.wh.gov\/mU8jI",
      "display_url" : "at.wh.gov\/mU8jI"
    } ]
  },
  "geo" : { },
  "id_str" : "355703149232799747",
  "text" : "President Obama on Secretary Napolitano: \"The American people are safer &amp; more secure thanks to Janet\u2019s leadership.\" http:\/\/t.co\/tefkK5z6iF",
  "id" : 355703149232799747,
  "created_at" : "2013-07-12 15:00:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/dySFdsJkXN",
      "expanded_url" : "http:\/\/at.wh.gov\/mTZxM",
      "display_url" : "at.wh.gov\/mTZxM"
    } ]
  },
  "geo" : { },
  "id_str" : "355696705695518720",
  "text" : "ICYMI: Watch this animation on why fixing our broken immigration system would be a big boost for our economy --&gt; http:\/\/t.co\/dySFdsJkXN",
  "id" : 355696705695518720,
  "created_at" : "2013-07-12 14:34:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/355414379430297601\/photo\/1",
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/c64XhRVBUd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BO6vfrpCQAIDdZN.jpg",
      "id_str" : "355414379434491906",
      "id" : 355414379434491906,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BO6vfrpCQAIDdZN.jpg",
      "sizes" : [ {
        "h" : 662,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 662,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 414,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 234,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/c64XhRVBUd"
    } ],
    "hashtags" : [ {
      "text" : "ThrowbackThursday",
      "indices" : [ 33, 51 ]
    }, {
      "text" : "TBT",
      "indices" : [ 52, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "355415413317844993",
  "text" : "RT @FLOTUS: Barack and Michelle. #ThrowbackThursday #TBT http:\/\/t.co\/c64XhRVBUd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/355414379430297601\/photo\/1",
        "indices" : [ 45, 67 ],
        "url" : "http:\/\/t.co\/c64XhRVBUd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BO6vfrpCQAIDdZN.jpg",
        "id_str" : "355414379434491906",
        "id" : 355414379434491906,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BO6vfrpCQAIDdZN.jpg",
        "sizes" : [ {
          "h" : 662,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 662,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 414,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 234,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/c64XhRVBUd"
      } ],
      "hashtags" : [ {
        "text" : "ThrowbackThursday",
        "indices" : [ 21, 39 ]
      }, {
        "text" : "TBT",
        "indices" : [ 40, 44 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "355414379430297601",
    "text" : "Barack and Michelle. #ThrowbackThursday #TBT http:\/\/t.co\/c64XhRVBUd",
    "id" : 355414379430297601,
    "created_at" : "2013-07-11 19:52:46 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 355415413317844993,
  "created_at" : "2013-07-11 19:56:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Loyola Ramblers",
      "screen_name" : "LoyolaRamblers",
      "indices" : [ 64, 79 ],
      "id_str" : "177654064",
      "id" : 177654064
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/355409644694409216\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/NLe9hCmyZY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BO6rMFZCEAISzOJ.jpg",
      "id_str" : "355409644702797826",
      "id" : 355409644702797826,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BO6rMFZCEAISzOJ.jpg",
      "sizes" : [ {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/NLe9hCmyZY"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "355409644694409216",
  "text" : "President Obama just met with members of the 1963 NCAA champion @LoyolaRamblers\u2014who helped integrate basketball. http:\/\/t.co\/NLe9hCmyZY",
  "id" : 355409644694409216,
  "created_at" : "2013-07-11 19:33:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheBushCenter",
      "screen_name" : "TheBushCenter",
      "indices" : [ 4, 18 ],
      "id_str" : "148376661",
      "id" : 148376661
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 40, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/I1koagT77D",
      "expanded_url" : "http:\/\/at.wh.gov\/mSk04",
      "display_url" : "at.wh.gov\/mSk04"
    }, {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/FfbepDV0c0",
      "expanded_url" : "http:\/\/at.wh.gov\/mSkiW",
      "display_url" : "at.wh.gov\/mSkiW"
    } ]
  },
  "geo" : { },
  "id_str" : "355391562265530368",
  "text" : "Hey @TheBushCenter, liked your video on #ImmigrationReform and the economy: http:\/\/t.co\/I1koagT77D. Here's ours: http:\/\/t.co\/FfbepDV0c0",
  "id" : 355391562265530368,
  "created_at" : "2013-07-11 18:22:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FarmBill",
      "indices" : [ 14, 23 ]
    }, {
      "text" : "SNAP",
      "indices" : [ 127, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/ZmocTvrf0M",
      "expanded_url" : "http:\/\/at.wh.gov\/mSfdg",
      "display_url" : "at.wh.gov\/mSfdg"
    } ]
  },
  "geo" : { },
  "id_str" : "355378710863552512",
  "text" : "The House GOP #FarmBill \"fails to reauthorize nutrition programs, which benefit millions of Americans.\" http:\/\/t.co\/ZmocTvrf0M #SNAP",
  "id" : 355378710863552512,
  "created_at" : "2013-07-11 17:31:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/vroBtKdYGX",
      "expanded_url" : "http:\/\/at.wh.gov\/mS819",
      "display_url" : "at.wh.gov\/mS819"
    } ]
  },
  "geo" : { },
  "id_str" : "355365133628874752",
  "text" : "RT if you agree: Fixing our broken immigration system would strengthen our economy\u2014and it's time to make it happen. http:\/\/t.co\/vroBtKdYGX",
  "id" : 355365133628874752,
  "created_at" : "2013-07-11 16:37:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationNation",
      "indices" : [ 115, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "355350858319409152",
  "text" : "FACT: In 2010, more than 70% of foreign graduate students were studying science, technology, engineering, or math. #ImmigrationNation",
  "id" : 355350858319409152,
  "created_at" : "2013-07-11 15:40:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationNation",
      "indices" : [ 100, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "355345804724142080",
  "text" : "FACT: Immigration reform would reduce the deficit by nearly $850 billion over the next two decades. #ImmigrationNation",
  "id" : 355345804724142080,
  "created_at" : "2013-07-11 15:20:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationNation",
      "indices" : [ 95, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "355340822109097985",
  "text" : "FACT: Passing immigration reform would help boost U.S. GDP by more than $1.4 trillion in 2033. #ImmigrationNation",
  "id" : 355340822109097985,
  "created_at" : "2013-07-11 15:00:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pu iezov uf",
      "screen_name" : "pfeiffer44",
      "indices" : [ 3, 14 ],
      "id_str" : "3187888216",
      "id" : 3187888216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/R76YbHPOV3",
      "expanded_url" : "http:\/\/at.wh.gov\/mRvoZ",
      "display_url" : "at.wh.gov\/mRvoZ"
    } ]
  },
  "geo" : { },
  "id_str" : "355337071944142848",
  "text" : "RT @pfeiffer44: Pls RT and share this animation on why fixing our broken immigration system is good for the economy: http:\/\/t.co\/R76YbHPOV3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/R76YbHPOV3",
        "expanded_url" : "http:\/\/at.wh.gov\/mRvoZ",
        "display_url" : "at.wh.gov\/mRvoZ"
      } ]
    },
    "geo" : { },
    "id_str" : "355334596814045184",
    "text" : "Pls RT and share this animation on why fixing our broken immigration system is good for the economy: http:\/\/t.co\/R76YbHPOV3",
    "id" : 355334596814045184,
    "created_at" : "2013-07-11 14:35:44 +0000",
    "user" : {
      "name" : "Jason Goldman",
      "screen_name" : "Goldman44",
      "protected" : false,
      "id_str" : "131144091",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/587735914048262146\/1ahEmS6d_normal.jpg",
      "id" : 131144091,
      "verified" : true
    }
  },
  "id" : 355337071944142848,
  "created_at" : "2013-07-11 14:45:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 0, 18 ]
    } ],
    "urls" : [ {
      "indices" : [ 124, 146 ],
      "url" : "http:\/\/t.co\/JyCfn26RHi",
      "expanded_url" : "http:\/\/at.wh.gov\/mRKMS",
      "display_url" : "at.wh.gov\/mRKMS"
    } ]
  },
  "geo" : { },
  "id_str" : "355332152340135936",
  "text" : "#ImmigrationReform = Higher demand for goods &amp; services + more demand for labor + more jobs for American workers --&gt; http:\/\/t.co\/JyCfn26RHi",
  "id" : 355332152340135936,
  "created_at" : "2013-07-11 14:26:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "355319864581292032",
  "text" : "RT @Simas44: Latest from GOP? Deny the 1\/4 of Americans under 65 with pre-existing conditions any shot at affordable health care. http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/rmUZWuhqgU",
        "expanded_url" : "http:\/\/bit.ly\/16u2K8Y",
        "display_url" : "bit.ly\/16u2K8Y"
      } ]
    },
    "geo" : { },
    "id_str" : "355311857621413890",
    "text" : "Latest from GOP? Deny the 1\/4 of Americans under 65 with pre-existing conditions any shot at affordable health care. http:\/\/t.co\/rmUZWuhqgU",
    "id" : 355311857621413890,
    "created_at" : "2013-07-11 13:05:22 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 355319864581292032,
  "created_at" : "2013-07-11 13:37:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationNation",
      "indices" : [ 120, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/SXr07VvNrc",
      "expanded_url" : "http:\/\/at.wh.gov\/mRvoZ",
      "display_url" : "at.wh.gov\/mRvoZ"
    } ]
  },
  "geo" : { },
  "id_str" : "355306930232754177",
  "text" : "Worth watching: An animated explanation of how immigration reform is good for our economy --&gt; http:\/\/t.co\/SXr07VvNrc #ImmigrationNation",
  "id" : 355306930232754177,
  "created_at" : "2013-07-11 12:45:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/355056708458012673\/photo\/1",
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/fOYpvwnwuU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BO1qMfcCYAE0Yjc.jpg",
      "id_str" : "355056708462206977",
      "id" : 355056708462206977,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BO1qMfcCYAE0Yjc.jpg",
      "sizes" : [ {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 436,
        "resize" : "fit",
        "w" : 654
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/fOYpvwnwuU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "355056708458012673",
  "text" : "President Obama briefs the press: http:\/\/t.co\/fOYpvwnwuU",
  "id" : 355056708458012673,
  "created_at" : "2013-07-10 20:11:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obamacare",
      "indices" : [ 11, 21 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/6rlOg0uZX6",
      "expanded_url" : "http:\/\/1.usa.gov\/12DINey",
      "display_url" : "1.usa.gov\/12DINey"
    } ]
  },
  "geo" : { },
  "id_str" : "355036420945084419",
  "text" : "Here's how #Obamacare is helping nearly 1,200 community health centers enroll unisured Americans around the country: http:\/\/t.co\/6rlOg0uZX6",
  "id" : 355036420945084419,
  "created_at" : "2013-07-10 18:50:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationNation",
      "indices" : [ 114, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/RdQZDwjaHo",
      "expanded_url" : "http:\/\/at.wh.gov\/mPXrZ",
      "display_url" : "at.wh.gov\/mPXrZ"
    } ]
  },
  "geo" : { },
  "id_str" : "355032522956083201",
  "text" : "RT @Simas44: RT to share this video on why immigration reform will strengthen our economy: http:\/\/t.co\/RdQZDwjaHo #ImmigrationNation (h\/t @\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "TheBushCenter",
        "screen_name" : "TheBushCenter",
        "indices" : [ 125, 139 ],
        "id_str" : "148376661",
        "id" : 148376661
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ImmigrationNation",
        "indices" : [ 101, 119 ]
      } ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/RdQZDwjaHo",
        "expanded_url" : "http:\/\/at.wh.gov\/mPXrZ",
        "display_url" : "at.wh.gov\/mPXrZ"
      } ]
    },
    "geo" : { },
    "id_str" : "355019446378692609",
    "text" : "RT to share this video on why immigration reform will strengthen our economy: http:\/\/t.co\/RdQZDwjaHo #ImmigrationNation (h\/t @TheBushCenter)",
    "id" : 355019446378692609,
    "created_at" : "2013-07-10 17:43:26 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 355032522956083201,
  "created_at" : "2013-07-10 18:35:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/355015400188157953\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/8H9egKd1GV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BO1EoCKCIAEyAFe.jpg",
      "id_str" : "355015400196546561",
      "id" : 355015400196546561,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BO1EoCKCIAEyAFe.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/8H9egKd1GV"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/C6qzEjdlww",
      "expanded_url" : "http:\/\/at.wh.gov\/mPZ5m",
      "display_url" : "at.wh.gov\/mPZ5m"
    } ]
  },
  "geo" : { },
  "id_str" : "355015400188157953",
  "text" : "RT to share how fixing our broken immigration system will strengthen our economy --&gt; http:\/\/t.co\/C6qzEjdlww, http:\/\/t.co\/8H9egKd1GV",
  "id" : 355015400188157953,
  "created_at" : "2013-07-10 17:27:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Senator Harry Reid",
      "screen_name" : "SenatorReid",
      "indices" : [ 3, 15 ],
      "id_str" : "16789970",
      "id" : 16789970
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 31, 42 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/qEx8sF1kZD",
      "expanded_url" : "http:\/\/at.wh.gov\/mPowL",
      "display_url" : "at.wh.gov\/mPowL"
    } ]
  },
  "geo" : { },
  "id_str" : "354992641085157378",
  "text" : "RT @SenatorReid: Check out the @whitehouse report on how immigration reform would strengthen our economy. http:\/\/t.co\/qEx8sF1kZD #Immigrati\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 14, 25 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ImmigrationNation",
        "indices" : [ 112, 130 ]
      } ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/qEx8sF1kZD",
        "expanded_url" : "http:\/\/at.wh.gov\/mPowL",
        "display_url" : "at.wh.gov\/mPowL"
      } ]
    },
    "geo" : { },
    "id_str" : "354962540972875777",
    "text" : "Check out the @whitehouse report on how immigration reform would strengthen our economy. http:\/\/t.co\/qEx8sF1kZD #ImmigrationNation",
    "id" : 354962540972875777,
    "created_at" : "2013-07-10 13:57:19 +0000",
    "user" : {
      "name" : "Senator Harry Reid",
      "screen_name" : "SenatorReid",
      "protected" : false,
      "id_str" : "16789970",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/628307865065816064\/OUQh91yr_normal.jpg",
      "id" : 16789970,
      "verified" : true
    }
  },
  "id" : 354992641085157378,
  "created_at" : "2013-07-10 15:56:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/TXTAti9arA",
      "expanded_url" : "http:\/\/at.wh.gov\/mPFlh",
      "display_url" : "at.wh.gov\/mPFlh"
    } ]
  },
  "geo" : { },
  "id_str" : "354980847306289152",
  "text" : "FACT: Bipartisan immigration reform would reduce the deficit by nearly $850 billion over the next two decades. http:\/\/t.co\/TXTAti9arA",
  "id" : 354980847306289152,
  "created_at" : "2013-07-10 15:10:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationNation",
      "indices" : [ 113, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/UtarBMNkMq",
      "expanded_url" : "http:\/\/at.wh.gov\/mPBC1",
      "display_url" : "at.wh.gov\/mPBC1"
    } ]
  },
  "geo" : { },
  "id_str" : "354974374455017472",
  "text" : "FACT: The Senate's bipartisan immigration reform bill would increase GDP by 3.3% in 2023. http:\/\/t.co\/UtarBMNkMq #ImmigrationNation",
  "id" : 354974374455017472,
  "created_at" : "2013-07-10 14:44:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354968734261194754",
  "text" : "RT @PressSec: USAT on Obamacare: Congress passed it, SCOTUS upheld it, but GOP keeps trying to undermine it, at Americans' expense: http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/BpM12j1lh4",
        "expanded_url" : "http:\/\/www.usatoday.com\/story\/opinion\/2013\/07\/09\/affordable-care-act-obamacare-nfl-editorials-debates\/2504207\/",
        "display_url" : "usatoday.com\/story\/opinion\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "354963555017179136",
    "text" : "USAT on Obamacare: Congress passed it, SCOTUS upheld it, but GOP keeps trying to undermine it, at Americans' expense: http:\/\/t.co\/BpM12j1lh4",
    "id" : 354963555017179136,
    "created_at" : "2013-07-10 14:01:21 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 354968734261194754,
  "created_at" : "2013-07-10 14:21:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationNation",
      "indices" : [ 102, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/3dMANrjnGX",
      "expanded_url" : "http:\/\/at.wh.gov\/mPowL",
      "display_url" : "at.wh.gov\/mPowL"
    } ]
  },
  "geo" : { },
  "id_str" : "354958476096712706",
  "text" : "Worth a RT: New report on how immigration reform would strengthen our economy. http:\/\/t.co\/3dMANrjnGX #ImmigrationNation",
  "id" : 354958476096712706,
  "created_at" : "2013-07-10 13:41:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    }, {
      "name" : "Acadia National Park",
      "screen_name" : "AcadiaNPS",
      "indices" : [ 21, 31 ],
      "id_str" : "185874758",
      "id" : 185874758
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Maine",
      "indices" : [ 35, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354718543662678018",
  "text" : "RT @Interior: Summer @AcadiaNPS in #Maine. If you haven't visited, we recommend looking at this photo &amp; adding it to your list. http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Acadia National Park",
        "screen_name" : "AcadiaNPS",
        "indices" : [ 7, 17 ],
        "id_str" : "185874758",
        "id" : 185874758
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/354716964805017602\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/XPz15lom7E",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BOw1MzuCAAAIqPf.jpg",
        "id_str" : "354716964813406208",
        "id" : 354716964813406208,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BOw1MzuCAAAIqPf.jpg",
        "sizes" : [ {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/XPz15lom7E"
      } ],
      "hashtags" : [ {
        "text" : "Maine",
        "indices" : [ 21, 27 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "354716964805017602",
    "text" : "Summer @AcadiaNPS in #Maine. If you haven't visited, we recommend looking at this photo &amp; adding it to your list. http:\/\/t.co\/XPz15lom7E",
    "id" : 354716964805017602,
    "created_at" : "2013-07-09 21:41:29 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 354718543662678018,
  "created_at" : "2013-07-09 21:47:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "YarnellHill",
      "indices" : [ 69, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354686551952850945",
  "text" : "RT @VP: They were all heroes long before we knew their names. \u2013VP on #YarnellHill firefighters in Arizona.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "YarnellHill",
        "indices" : [ 61, 73 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "354683085192839168",
    "text" : "They were all heroes long before we knew their names. \u2013VP on #YarnellHill firefighters in Arizona.",
    "id" : 354683085192839168,
    "created_at" : "2013-07-09 19:26:52 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 354686551952850945,
  "created_at" : "2013-07-09 19:40:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Leonard Nimoy",
      "screen_name" : "TheRealNimoy",
      "indices" : [ 3, 16 ],
      "id_str" : "128956175",
      "id" : 128956175
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354670723618455552",
  "text" : "RT @TheRealNimoy: Creating a path for immigrants to become taxpayers is logical. LLAP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "354663510581587969",
    "text" : "Creating a path for immigrants to become taxpayers is logical. LLAP",
    "id" : 354663510581587969,
    "created_at" : "2013-07-09 18:09:04 +0000",
    "user" : {
      "name" : "Leonard Nimoy",
      "screen_name" : "TheRealNimoy",
      "protected" : false,
      "id_str" : "128956175",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1858927432\/color_nimoy_headshot_normal.jpg",
      "id" : 128956175,
      "verified" : true
    }
  },
  "id" : 354670723618455552,
  "created_at" : "2013-07-09 18:37:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KidsStateDinner",
      "indices" : [ 70, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354662594688188416",
  "text" : "RT @FLOTUS: I'm so proud of all of the amazing young chefs at today's #KidsStateDinner! Loved your healthy recipes - keep up the great work\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "KidsStateDinner",
        "indices" : [ 58, 74 ]
      }, {
        "text" : "NomNom",
        "indices" : [ 129, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "354661759241551872",
    "text" : "I'm so proud of all of the amazing young chefs at today's #KidsStateDinner! Loved your healthy recipes - keep up the great work. #NomNom \u2013mo",
    "id" : 354661759241551872,
    "created_at" : "2013-07-09 18:02:07 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 354662594688188416,
  "created_at" : "2013-07-09 18:05:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KidsStateDinner",
      "indices" : [ 112, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354643686677676034",
  "text" : "\"Keep it up! You guys are going to set a good example for everyone across the country.\" \u2014President Obama to the #KidsStateDinner winners",
  "id" : 354643686677676034,
  "created_at" : "2013-07-09 16:50:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KidsStateDinner",
      "indices" : [ 39, 55 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/oC7vTIf3vh",
      "expanded_url" : "http:\/\/at.wh.gov\/mNCwZ",
      "display_url" : "at.wh.gov\/mNCwZ"
    } ]
  },
  "geo" : { },
  "id_str" : "354642186530328577",
  "text" : "Surprise! President Obama stops by the #KidsStateDinner. You're going to want to watch --&gt; http:\/\/t.co\/oC7vTIf3vh",
  "id" : 354642186530328577,
  "created_at" : "2013-07-09 16:44:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354640263320305666",
  "text" : "RT @FLOTUS: \"It\u2019s about making sure that your body can be strong and healthy and your mind can be ready to learn and explore and dream.\" \u2014T\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "354639400270970880",
    "text" : "\"It\u2019s about making sure that your body can be strong and healthy and your mind can be ready to learn and explore and dream.\" \u2014The First Lady",
    "id" : 354639400270970880,
    "created_at" : "2013-07-09 16:33:16 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 354640263320305666,
  "created_at" : "2013-07-09 16:36:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354638750107713538",
  "text" : "RT @FLOTUS: FLOTUS: \"When kids like all of you get involved in creating your own healthy meals, the results can really be amazing.\" #KidsSt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "KidsStateDinner",
        "indices" : [ 120, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "354638615227277312",
    "text" : "FLOTUS: \"When kids like all of you get involved in creating your own healthy meals, the results can really be amazing.\" #KidsStateDinner",
    "id" : 354638615227277312,
    "created_at" : "2013-07-09 16:30:09 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 354638750107713538,
  "created_at" : "2013-07-09 16:30:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KidsStateDinner",
      "indices" : [ 49, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/T9v91oA7fI",
      "expanded_url" : "http:\/\/at.wh.gov\/mNxJK",
      "display_url" : "at.wh.gov\/mNxJK"
    } ]
  },
  "geo" : { },
  "id_str" : "354634631288598528",
  "text" : "Happening now: The First Lady speaks at the 2013 #KidsStateDinner. Watch: http:\/\/t.co\/T9v91oA7fI",
  "id" : 354634631288598528,
  "created_at" : "2013-07-09 16:14:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KidsStateDinner",
      "indices" : [ 85, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354623722121994240",
  "text" : "RT @FLOTUS: The First Lady is hosting 54 young chefs from around the country for the #KidsStateDinner. They're arriving now! --&gt; http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "KidsStateDinner",
        "indices" : [ 73, 89 ]
      } ],
      "urls" : [ {
        "indices" : [ 120, 142 ],
        "url" : "http:\/\/t.co\/18uEIGmWlP",
        "expanded_url" : "http:\/\/at.wh.gov\/mNcIw",
        "display_url" : "at.wh.gov\/mNcIw"
      } ]
    },
    "geo" : { },
    "id_str" : "354623667226939393",
    "text" : "The First Lady is hosting 54 young chefs from around the country for the #KidsStateDinner. They're arriving now! --&gt; http:\/\/t.co\/18uEIGmWlP",
    "id" : 354623667226939393,
    "created_at" : "2013-07-09 15:30:45 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 354623722121994240,
  "created_at" : "2013-07-09 15:30:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Todd Park",
      "screen_name" : "todd_park",
      "indices" : [ 109, 119 ],
      "id_str" : "200176600",
      "id" : 200176600
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/J09vccebhh",
      "expanded_url" : "http:\/\/at.wh.gov\/mNgSn",
      "display_url" : "at.wh.gov\/mNgSn"
    } ]
  },
  "geo" : { },
  "id_str" : "354611099838066688",
  "text" : "\"There are phenomenal people harnessing the power of tech &amp; innovation to help government work better.\" \u2014@Todd_Park: http:\/\/t.co\/J09vccebhh",
  "id" : 354611099838066688,
  "created_at" : "2013-07-09 14:40:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 80, 93 ]
    }, {
      "text" : "health",
      "indices" : [ 115, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354601994738081792",
  "text" : "RT @whitehouseostp: LIVE at 1045a ET: meet extraordinary Americans committed to #ActOnClimate &amp; protect public #health: http:\/\/t.co\/QLMcwiB\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 60, 73 ]
      }, {
        "text" : "health",
        "indices" : [ 95, 102 ]
      }, {
        "text" : "WHChamps",
        "indices" : [ 127, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/QLMcwiB5a6",
        "expanded_url" : "http:\/\/WH.gov\/live",
        "display_url" : "WH.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "354594898395140097",
    "text" : "LIVE at 1045a ET: meet extraordinary Americans committed to #ActOnClimate &amp; protect public #health: http:\/\/t.co\/QLMcwiB5a6 #WHChamps",
    "id" : 354594898395140097,
    "created_at" : "2013-07-09 13:36:26 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 354601994738081792,
  "created_at" : "2013-07-09 14:04:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    }, {
      "name" : "Grand Canyon NPS",
      "screen_name" : "GrandCanyonNPS",
      "indices" : [ 102, 117 ],
      "id_str" : "212304085",
      "id" : 212304085
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lightning",
      "indices" : [ 26, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354379762002702339",
  "text" : "RT @Interior: If you like #lightning photos, you'll love this one by Adam Schallau from the South Rim @GrandCanyonNPS. http:\/\/t.co\/et43wwY2\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Grand Canyon NPS",
        "screen_name" : "GrandCanyonNPS",
        "indices" : [ 88, 103 ],
        "id_str" : "212304085",
        "id" : 212304085
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/354351859940618240\/photo\/1",
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/et43wwY2oR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BOrpI6GCcAAmGuW.jpg",
        "id_str" : "354351859944812544",
        "id" : 354351859944812544,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BOrpI6GCcAAmGuW.jpg",
        "sizes" : [ {
          "h" : 480,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 720
        } ],
        "display_url" : "pic.twitter.com\/et43wwY2oR"
      } ],
      "hashtags" : [ {
        "text" : "lightning",
        "indices" : [ 12, 22 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "354351859940618240",
    "text" : "If you like #lightning photos, you'll love this one by Adam Schallau from the South Rim @GrandCanyonNPS. http:\/\/t.co\/et43wwY2oR",
    "id" : 354351859940618240,
    "created_at" : "2013-07-08 21:30:41 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 354379762002702339,
  "created_at" : "2013-07-08 23:21:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354352081492123648",
  "text" : "RT @Simas44: Most people aren't interested in the debate about big v. small government. They're interested in smarter government.\nhttp:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/BGwx421sPF",
        "expanded_url" : "http:\/\/1.usa.gov\/12S3Skn",
        "display_url" : "1.usa.gov\/12S3Skn"
      } ]
    },
    "geo" : { },
    "id_str" : "354340143966072832",
    "text" : "Most people aren't interested in the debate about big v. small government. They're interested in smarter government.\nhttp:\/\/t.co\/BGwx421sPF",
    "id" : 354340143966072832,
    "created_at" : "2013-07-08 20:44:08 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 354352081492123648,
  "created_at" : "2013-07-08 21:31:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "progress",
      "indices" : [ 113, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/yLAtxGEpH3",
      "expanded_url" : "http:\/\/at.wh.gov\/mLMfB",
      "display_url" : "at.wh.gov\/mLMfB"
    } ]
  },
  "geo" : { },
  "id_str" : "354342236424642561",
  "text" : "Good news: The projected budget deficit for 2013 has decreased by more than $200 billion. http:\/\/t.co\/yLAtxGEpH3 #progress",
  "id" : 354342236424642561,
  "created_at" : "2013-07-08 20:52:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/354330050050527232\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/Cpv9zYGOQ8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BOrVTZ7CEAAMzyA.jpg",
      "id_str" : "354330050054721536",
      "id" : 354330050054721536,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BOrVTZ7CEAAMzyA.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/Cpv9zYGOQ8"
    } ],
    "hashtags" : [ {
      "text" : "SmarterGov",
      "indices" : [ 103, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354330050050527232",
  "text" : "RT to share President Obama's plan for using technology to make government smarter and more efficient. #SmarterGov, http:\/\/t.co\/Cpv9zYGOQ8",
  "id" : 354330050050527232,
  "created_at" : "2013-07-08 20:04:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "indices" : [ 3, 10 ],
      "id_str" : "166252256",
      "id" : 166252256
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "solarimpulse",
      "indices" : [ 117, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/N3bTVDz1bA",
      "expanded_url" : "http:\/\/go.usa.gov\/j3h9",
      "display_url" : "go.usa.gov\/j3h9"
    } ]
  },
  "geo" : { },
  "id_str" : "354307657416454145",
  "text" : "RT @ENERGY: Symbol of Progress: Solar-powered plane completes historic journey across America http:\/\/t.co\/N3bTVDz1bA #solarimpulse",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/measuredvoice.com\/\" rel=\"nofollow\"\u003EMeasured Voice\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "solarimpulse",
        "indices" : [ 105, 118 ]
      } ],
      "urls" : [ {
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/N3bTVDz1bA",
        "expanded_url" : "http:\/\/go.usa.gov\/j3h9",
        "display_url" : "go.usa.gov\/j3h9"
      } ]
    },
    "geo" : { },
    "id_str" : "354297616512716801",
    "text" : "Symbol of Progress: Solar-powered plane completes historic journey across America http:\/\/t.co\/N3bTVDz1bA #solarimpulse",
    "id" : 354297616512716801,
    "created_at" : "2013-07-08 17:55:08 +0000",
    "user" : {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "protected" : false,
      "id_str" : "166252256",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793425839694155781\/HRS6sfn4_normal.jpg",
      "id" : 166252256,
      "verified" : true
    }
  },
  "id" : 354307657416454145,
  "created_at" : "2013-07-08 18:35:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Opower",
      "screen_name" : "Opower",
      "indices" : [ 49, 56 ],
      "id_str" : "71666839",
      "id" : 71666839
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SmarterGov",
      "indices" : [ 111, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354292251234545664",
  "text" : "FACT: Families have used government data through @Opower to save more than $300 million on their energy bills. #SmarterGov",
  "id" : 354292251234545664,
  "created_at" : "2013-07-08 17:33:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "iTriage",
      "screen_name" : "iTriage",
      "indices" : [ 6, 14 ],
      "id_str" : "23453611",
      "id" : 23453611
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SmarterGov",
      "indices" : [ 103, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354280718551093251",
  "text" : "FACT: @iTriage uses government data to help more than 9 million people find the health care they need. #SmarterGov",
  "id" : 354280718551093251,
  "created_at" : "2013-07-08 16:48:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SmarterGov",
      "indices" : [ 124, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354270324277260288",
  "text" : "Obama: \"We, the people, realize this government belongs to us. It\u2019s up to each and every one of us to make it work better.\" #SmarterGov",
  "id" : 354270324277260288,
  "created_at" : "2013-07-08 16:06:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/cvYegRT04r",
      "expanded_url" : "http:\/\/HealthCare.Gov",
      "display_url" : "HealthCare.Gov"
    } ]
  },
  "geo" : { },
  "id_str" : "354269361952931840",
  "text" : "Obama: On \"Oct 1st, Americans will be able to log on and comparison shop an array of private health insurance plans.\" http:\/\/t.co\/cvYegRT04r",
  "id" : 354269361952931840,
  "created_at" : "2013-07-08 16:02:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354269036634316801",
  "text" : "RT @WHLive: Obama: \"Entrepreneurs and business owners are using that data to create jobs and solve problems that government can\u2019t solve by \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "354268992510238720",
    "text" : "Obama: \"Entrepreneurs and business owners are using that data to create jobs and solve problems that government can\u2019t solve by itself.\"",
    "id" : 354268992510238720,
    "created_at" : "2013-07-08 16:01:24 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 354269036634316801,
  "created_at" : "2013-07-08 16:01:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/1GSm23z96A",
      "expanded_url" : "http:\/\/Data.Gov",
      "display_url" : "Data.Gov"
    } ]
  },
  "geo" : { },
  "id_str" : "354268806056656897",
  "text" : "Obama: \"We\u2019ve opened up huge amounts of government data to the American people, and put it on the internet for free.\" http:\/\/t.co\/1GSm23z96A",
  "id" : 354268806056656897,
  "created_at" : "2013-07-08 16:00:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SmarterGov",
      "indices" : [ 115, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354268497276182529",
  "text" : "President Obama: \"Taxpayers deserve the biggest bang for their buck, especially at a time when budgets are tight.\" #SmarterGov",
  "id" : 354268497276182529,
  "created_at" : "2013-07-08 15:59:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354268188969676800",
  "text" : "RT @WHLive: Obama: We've eliminated \"dozens of federal programs and cut even more that were either duplicative, not working, or no longer n\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "354268120573165568",
    "text" : "Obama: We've eliminated \"dozens of federal programs and cut even more that were either duplicative, not working, or no longer needed.\"",
    "id" : 354268120573165568,
    "created_at" : "2013-07-08 15:57:56 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 354268188969676800,
  "created_at" : "2013-07-08 15:58:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SmarterGov",
      "indices" : [ 95, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354268005909278720",
  "text" : "President Obama: \"Second, we\u2019ve identified new ways to reduce waste and save taxpayers money.\" #SmarterGov",
  "id" : 354268005909278720,
  "created_at" : "2013-07-08 15:57:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SmarterGov",
      "indices" : [ 19, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354267673636515840",
  "text" : "President Obama on #SmarterGov: \"First, we\u2019ve found ways to deliver the services that citizens expect in smarter, faster and better ways.\"",
  "id" : 354267673636515840,
  "created_at" : "2013-07-08 15:56:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SmarterGov",
      "indices" : [ 124, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354267517641949184",
  "text" : "Obama: \"We\u2019ve made huge swaths of your government more efficient, more transparent, and more accountable than ever before.\" #SmarterGov",
  "id" : 354267517641949184,
  "created_at" : "2013-07-08 15:55:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SmarterGov",
      "indices" : [ 120, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/KvadYk9atb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "354266619322695680",
  "text" : "Watch live: President Obama lays out his vision for using technology to make government smarter. http:\/\/t.co\/KvadYk9atb #SmarterGov",
  "id" : 354266619322695680,
  "created_at" : "2013-07-08 15:51:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 3, 14 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Rally4Babies",
      "indices" : [ 48, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "354261028399357952",
  "text" : "RT @arneduncan: Join me today at 2pm ET for the #Rally4Babies Google+ Hangout to support a strong start for our children. http:\/\/t.co\/8x9x3\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Rally4Babies",
        "indices" : [ 32, 45 ]
      } ],
      "urls" : [ {
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/8x9x3bDmbZ",
        "expanded_url" : "http:\/\/bit.ly\/1aSvaQO",
        "display_url" : "bit.ly\/1aSvaQO"
      } ]
    },
    "geo" : { },
    "id_str" : "354250355363692545",
    "text" : "Join me today at 2pm ET for the #Rally4Babies Google+ Hangout to support a strong start for our children. http:\/\/t.co\/8x9x3bDmbZ",
    "id" : 354250355363692545,
    "created_at" : "2013-07-08 14:47:21 +0000",
    "user" : {
      "name" : "John King",
      "screen_name" : "JohnKingatED",
      "protected" : false,
      "id_str" : "44873497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/729662468725710848\/_mKZ500L_normal.jpg",
      "id" : 44873497,
      "verified" : true
    }
  },
  "id" : 354261028399357952,
  "created_at" : "2013-07-08 15:29:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SmarterGov",
      "indices" : [ 128, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/KvadYk9atb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "354244141829459969",
  "text" : "At 11:50am ET, watch President Obama lay out his vision for using technology to make government smarter: http:\/\/t.co\/KvadYk9atb #SmarterGov",
  "id" : 354244141829459969,
  "created_at" : "2013-07-08 14:22:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/Wyv2ItCTPA",
      "expanded_url" : "http:\/\/youtu.be\/Baw3teVZmSw",
      "display_url" : "youtu.be\/Baw3teVZmSw"
    } ]
  },
  "geo" : { },
  "id_str" : "353569289011343362",
  "text" : "\"Generations of Americans made our country what it is today\" \u2014President Obama in his Weekly Address, http:\/\/t.co\/Wyv2ItCTPA",
  "id" : 353569289011343362,
  "created_at" : "2013-07-06 17:41:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/353287460429631489\/photo\/1",
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/oL2wOipP67",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BOchEs8CEAMFBMG.jpg",
      "id_str" : "353287460438020099",
      "id" : 353287460438020099,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BOchEs8CEAMFBMG.jpg",
      "sizes" : [ {
        "h" : 401,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 685,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 736,
        "resize" : "fit",
        "w" : 1100
      } ],
      "display_url" : "pic.twitter.com\/oL2wOipP67"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "353287460429631489",
  "text" : "A view of the fireworks over the South Lawn during the Fourth of July celebration at the White House: http:\/\/t.co\/oL2wOipP67",
  "id" : 353287460429631489,
  "created_at" : "2013-07-05 23:01:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/W5ZdvuOdee",
      "expanded_url" : "http:\/\/at.wh.gov\/mHyRc",
      "display_url" : "at.wh.gov\/mHyRc"
    } ]
  },
  "geo" : { },
  "id_str" : "353260347886534658",
  "text" : "In this week's address, President Obama commemorates our nation\u2019s Independence Day: http:\/\/t.co\/W5ZdvuOdee",
  "id" : 353260347886534658,
  "created_at" : "2013-07-05 21:13:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/353171709374889986\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/exFAsn92aZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BOa3zGqCAAEJkz2.jpg",
      "id_str" : "353171709383278593",
      "id" : 353171709383278593,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BOa3zGqCAAEJkz2.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 700
      } ],
      "display_url" : "pic.twitter.com\/exFAsn92aZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/ZKQKyxk1kk",
      "expanded_url" : "http:\/\/wh.gov\/lxTDC",
      "display_url" : "wh.gov\/lxTDC"
    } ]
  },
  "geo" : { },
  "id_str" : "353171709374889986",
  "text" : "RT the news: Our economy added 202,000 private-sector jobs in June\u2014but there's more work to do http:\/\/t.co\/ZKQKyxk1kk http:\/\/t.co\/exFAsn92aZ",
  "id" : 353171709374889986,
  "created_at" : "2013-07-05 15:21:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Simas44\/status\/353147171182362629\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/3w5bvGNYtG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BOaheyxCQAAC6bI.jpg",
      "id_str" : "353147171190751232",
      "id" : 353147171190751232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BOaheyxCQAAC6bI.jpg",
      "sizes" : [ {
        "h" : 379,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 379,
        "resize" : "fit",
        "w" : 520
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 248,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 379,
        "resize" : "fit",
        "w" : 520
      } ],
      "display_url" : "pic.twitter.com\/3w5bvGNYtG"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "353161880749080578",
  "text" : "RT @Simas44: Worth a RT. The monthly reminder of how far we've come since the Great Recession hit. More work to do. http:\/\/t.co\/3w5bvGNYtG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Simas44\/status\/353147171182362629\/photo\/1",
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/3w5bvGNYtG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BOaheyxCQAAC6bI.jpg",
        "id_str" : "353147171190751232",
        "id" : 353147171190751232,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BOaheyxCQAAC6bI.jpg",
        "sizes" : [ {
          "h" : 379,
          "resize" : "fit",
          "w" : 520
        }, {
          "h" : 379,
          "resize" : "fit",
          "w" : 520
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 248,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 379,
          "resize" : "fit",
          "w" : 520
        } ],
        "display_url" : "pic.twitter.com\/3w5bvGNYtG"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "353147171182362629",
    "text" : "Worth a RT. The monthly reminder of how far we've come since the Great Recession hit. More work to do. http:\/\/t.co\/3w5bvGNYtG",
    "id" : 353147171182362629,
    "created_at" : "2013-07-05 13:43:41 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 353161880749080578,
  "created_at" : "2013-07-05 14:42:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HappyJuly4th",
      "indices" : [ 97, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/KvadYk9atb",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "352957613790601216",
  "text" : "Tune in now to watch fireworks on the National Mall from the White House: http:\/\/t.co\/KvadYk9atb #HappyJuly4th",
  "id" : 352957613790601216,
  "created_at" : "2013-07-05 01:10:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352933805880901634",
  "text" : "RT @FLOTUS: Happy birthday America (and Malia)! Feeling so blessed to share it with family, friends &amp; inspiring military families. #4thofJu\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "4thofJuly",
        "indices" : [ 123, 133 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "352933446663933952",
    "text" : "Happy birthday America (and Malia)! Feeling so blessed to share it with family, friends &amp; inspiring military families. #4thofJuly \u2013mo",
    "id" : 352933446663933952,
    "created_at" : "2013-07-04 23:34:25 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 352933805880901634,
  "created_at" : "2013-07-04 23:35:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "4thofJuly",
      "indices" : [ 84, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/glo9nVyY5J",
      "expanded_url" : "http:\/\/at.wh.gov\/mFqL8",
      "display_url" : "at.wh.gov\/mFqL8"
    } ]
  },
  "geo" : { },
  "id_str" : "352908542111514624",
  "text" : "At 6:00ET, the President &amp; First Lady welcome military families to the WH for a #4thofJuly celebration. Watch: http:\/\/t.co\/glo9nVyY5J",
  "id" : 352908542111514624,
  "created_at" : "2013-07-04 21:55:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/352868300851662848\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/yCqWWzj2Yj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BOWj2Z1CUAAt66s.jpg",
      "id_str" : "352868300860051456",
      "id" : 352868300860051456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BOWj2Z1CUAAt66s.jpg",
      "sizes" : [ {
        "h" : 270,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 795,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 477,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 795,
        "resize" : "fit",
        "w" : 1000
      } ],
      "display_url" : "pic.twitter.com\/yCqWWzj2Yj"
    } ],
    "hashtags" : [ {
      "text" : "Happy4thofJuly",
      "indices" : [ 95, 110 ]
    }, {
      "text" : "TBT",
      "indices" : [ 111, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/aBUwEGEKty",
      "expanded_url" : "http:\/\/at.wh.gov\/mFqVO",
      "display_url" : "at.wh.gov\/mFqVO"
    } ]
  },
  "geo" : { },
  "id_str" : "352868300851662848",
  "text" : "From the archives: A look back at Fourth of Julys with U.S. Presidents. http:\/\/t.co\/aBUwEGEKty #Happy4thofJuly #TBT http:\/\/t.co\/yCqWWzj2Yj",
  "id" : 352868300851662848,
  "created_at" : "2013-07-04 19:15:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Happy4thofJuly",
      "indices" : [ 46, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/RDpaSzO7WD",
      "expanded_url" : "http:\/\/at.wh.gov\/mFpFT",
      "display_url" : "at.wh.gov\/mFpFT"
    } ]
  },
  "geo" : { },
  "id_str" : "352847808581210112",
  "text" : "America the Beautiful: http:\/\/t.co\/RDpaSzO7WD #Happy4thofJuly",
  "id" : 352847808581210112,
  "created_at" : "2013-07-04 17:54:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 3, 11 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352838873442824192",
  "text" : "RT @DrBiden: Happy 4th!  Please join me in thanking our veterans, service members and their families for our freedom. - Jill http:\/\/t.co\/qg\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/qgviJpDJcF",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/joiningforces\/get-involved",
        "display_url" : "whitehouse.gov\/joiningforces\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "352837222866755584",
    "text" : "Happy 4th!  Please join me in thanking our veterans, service members and their families for our freedom. - Jill http:\/\/t.co\/qgviJpDJcF",
    "id" : 352837222866755584,
    "created_at" : "2013-07-04 17:12:03 +0000",
    "user" : {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "protected" : false,
      "id_str" : "1281405877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608687663034474496\/wvzVG_yt_normal.jpg",
      "id" : 1281405877,
      "verified" : true
    }
  },
  "id" : 352838873442824192,
  "created_at" : "2013-07-04 17:18:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/352825299743936514\/photo\/1",
      "indices" : [ 22, 44 ],
      "url" : "http:\/\/t.co\/o3MYIWBjzl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BOV8vaNCEAERWBt.jpg",
      "id_str" : "352825299748130817",
      "id" : 352825299748130817,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BOV8vaNCEAERWBt.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/o3MYIWBjzl"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352825299743936514",
  "text" : "Happy Fourth of July! http:\/\/t.co\/o3MYIWBjzl",
  "id" : 352825299743936514,
  "created_at" : "2013-07-04 16:24:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "indices" : [ 3, 12 ],
      "id_str" : "249722522",
      "id" : 249722522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/p9EF6bHnUl",
      "expanded_url" : "http:\/\/wh.gov\/lcFMr",
      "display_url" : "wh.gov\/lcFMr"
    } ]
  },
  "geo" : { },
  "id_str" : "352566008206196739",
  "text" : "RT @rhodes44: President Obama: \"The future of Egypt can only be determined by the Egyptian people\" http:\/\/t.co\/p9EF6bHnUl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/p9EF6bHnUl",
        "expanded_url" : "http:\/\/wh.gov\/lcFMr",
        "display_url" : "wh.gov\/lcFMr"
      } ]
    },
    "geo" : { },
    "id_str" : "352565640344776704",
    "text" : "President Obama: \"The future of Egypt can only be determined by the Egyptian people\" http:\/\/t.co\/p9EF6bHnUl",
    "id" : 352565640344776704,
    "created_at" : "2013-07-03 23:12:53 +0000",
    "user" : {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "protected" : false,
      "id_str" : "249722522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/700766726644850688\/1lytmnAl_normal.jpg",
      "id" : 249722522,
      "verified" : true
    }
  },
  "id" : 352566008206196739,
  "created_at" : "2013-07-03 23:14:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/352563347494952960\/photo\/1",
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/VBFCM0xTS3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BOSOfyCCYAAU8ou.png",
      "id_str" : "352563347499147264",
      "id" : 352563347499147264,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BOSOfyCCYAAU8ou.png",
      "sizes" : [ {
        "h" : 616,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 349,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 653,
        "resize" : "fit",
        "w" : 636
      }, {
        "h" : 653,
        "resize" : "fit",
        "w" : 636
      } ],
      "display_url" : "pic.twitter.com\/VBFCM0xTS3"
    } ],
    "hashtags" : [ {
      "text" : "Egypt",
      "indices" : [ 32, 38 ]
    } ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/2G3YUvZxta",
      "expanded_url" : "http:\/\/wh.gov\/lcFMr",
      "display_url" : "wh.gov\/lcFMr"
    } ]
  },
  "geo" : { },
  "id_str" : "352563347494952960",
  "text" : "Statement by President Obama on #Egypt: http:\/\/t.co\/2G3YUvZxta, http:\/\/t.co\/VBFCM0xTS3",
  "id" : 352563347494952960,
  "created_at" : "2013-07-03 23:03:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 36, 43 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/7cZXQzOiom",
      "expanded_url" : "http:\/\/at.wh.gov\/mDz14",
      "display_url" : "at.wh.gov\/mDz14"
    } ]
  },
  "geo" : { },
  "id_str" : "352504587770535936",
  "text" : "\"An experience I'll never forget.\" \u2014@FLOTUS on what it meant to visit the prison where Nelson Mandela was held: http:\/\/t.co\/7cZXQzOiom",
  "id" : 352504587770535936,
  "created_at" : "2013-07-03 19:10:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PowerAfrica",
      "indices" : [ 58, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/4kl6SthjOK",
      "expanded_url" : "http:\/\/at.wh.gov\/mDex2",
      "display_url" : "at.wh.gov\/mDex2"
    } ]
  },
  "geo" : { },
  "id_str" : "352476006277328896",
  "text" : "Soccket ball is just one example of how President Obama's #PowerAfrica initiative is a win-win for Africa &amp; the U.S. http:\/\/t.co\/4kl6SthjOK",
  "id" : 352476006277328896,
  "created_at" : "2013-07-03 17:16:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sally Jewell",
      "screen_name" : "SecretaryJewell",
      "indices" : [ 3, 19 ],
      "id_str" : "1342861723",
      "id" : 1342861723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352466928331268098",
  "text" : "RT @SecretaryJewell: Yesterday visited with the brave men and women fighting fires in AZ. Humbled by their service to our country. -SJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "352432449675993088",
    "text" : "Yesterday visited with the brave men and women fighting fires in AZ. Humbled by their service to our country. -SJ",
    "id" : 352432449675993088,
    "created_at" : "2013-07-03 14:23:38 +0000",
    "user" : {
      "name" : "Sally Jewell",
      "screen_name" : "SecretaryJewell",
      "protected" : false,
      "id_str" : "1342861723",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3525481506\/1ddf16c2cb47608803abe4dc7fc133fe_normal.jpeg",
      "id" : 1342861723,
      "verified" : true
    }
  },
  "id" : 352466928331268098,
  "created_at" : "2013-07-03 16:40:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 104, 111 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/352446418801291264\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/GO23BeYu4u",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BOQkJouCcAAacMP.png",
      "id_str" : "352446418809679872",
      "id" : 352446418809679872,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BOQkJouCcAAacMP.png",
      "sizes" : [ {
        "h" : 613,
        "resize" : "fit",
        "w" : 615
      }, {
        "h" : 339,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 598,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 613,
        "resize" : "fit",
        "w" : 615
      } ],
      "display_url" : "pic.twitter.com\/GO23BeYu4u"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352446418801291264",
  "text" : "\"These young people are amazing! With their commitment to education, I know they'll change the world.\" \u2014@FLOTUS: http:\/\/t.co\/GO23BeYu4u",
  "id" : 352446418801291264,
  "created_at" : "2013-07-03 15:19:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "indices" : [ 15, 24 ],
      "id_str" : "249722522",
      "id" : 249722522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/FZgObhEqEu",
      "expanded_url" : "http:\/\/at.wh.gov\/mBqJk",
      "display_url" : "at.wh.gov\/mBqJk"
    } ]
  },
  "geo" : { },
  "id_str" : "352196491995136000",
  "text" : "Worth sharing: @Rhodes44 recaps the President and First Lady's trip to Africa --&gt; http:\/\/t.co\/FZgObhEqEu",
  "id" : 352196491995136000,
  "created_at" : "2013-07-02 22:46:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "Instagram",
      "screen_name" : "instagram",
      "indices" : [ 51, 61 ],
      "id_str" : "180505807",
      "id" : 180505807
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/352181361739718657\/photo\/1",
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/HTNOtF2CDA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BOMzFSNCYAAqu3u.jpg",
      "id_str" : "352181361743912960",
      "id" : 352181361743912960,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BOMzFSNCYAAqu3u.jpg",
      "sizes" : [ {
        "h" : 546,
        "resize" : "fit",
        "w" : 671
      }, {
        "h" : 546,
        "resize" : "fit",
        "w" : 671
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 277,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 488,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/HTNOtF2CDA"
    } ],
    "hashtags" : [ {
      "text" : "FLOTUSinAfrica",
      "indices" : [ 86, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/bf5vvjx3eF",
      "expanded_url" : "http:\/\/at.wh.gov\/mBrrk",
      "display_url" : "at.wh.gov\/mBrrk"
    } ]
  },
  "geo" : { },
  "id_str" : "352185116031856640",
  "text" : "RT @FLOTUS: See the First Lady's trip to Africa on @instagram: http:\/\/t.co\/bf5vvjx3eF #FLOTUSinAfrica http:\/\/t.co\/HTNOtF2CDA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Instagram",
        "screen_name" : "instagram",
        "indices" : [ 39, 49 ],
        "id_str" : "180505807",
        "id" : 180505807
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/352181361739718657\/photo\/1",
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/HTNOtF2CDA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BOMzFSNCYAAqu3u.jpg",
        "id_str" : "352181361743912960",
        "id" : 352181361743912960,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BOMzFSNCYAAqu3u.jpg",
        "sizes" : [ {
          "h" : 546,
          "resize" : "fit",
          "w" : 671
        }, {
          "h" : 546,
          "resize" : "fit",
          "w" : 671
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 277,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 488,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/HTNOtF2CDA"
      } ],
      "hashtags" : [ {
        "text" : "FLOTUSinAfrica",
        "indices" : [ 74, 89 ]
      } ],
      "urls" : [ {
        "indices" : [ 51, 73 ],
        "url" : "http:\/\/t.co\/bf5vvjx3eF",
        "expanded_url" : "http:\/\/at.wh.gov\/mBrrk",
        "display_url" : "at.wh.gov\/mBrrk"
      } ]
    },
    "geo" : { },
    "id_str" : "352181361739718657",
    "text" : "See the First Lady's trip to Africa on @instagram: http:\/\/t.co\/bf5vvjx3eF #FLOTUSinAfrica http:\/\/t.co\/HTNOtF2CDA",
    "id" : 352181361739718657,
    "created_at" : "2013-07-02 21:45:54 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 352185116031856640,
  "created_at" : "2013-07-02 22:00:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole King",
      "screen_name" : "Carole_King",
      "indices" : [ 6, 18 ],
      "id_str" : "34774807",
      "id" : 34774807
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/Q81vtlVHMw",
      "expanded_url" : "http:\/\/at.wh.gov\/mBom1",
      "display_url" : "at.wh.gov\/mBom1"
    } ]
  },
  "geo" : { },
  "id_str" : "352173252245864449",
  "text" : "Watch @Carole_King share what it means to be the 1st woman to win the Gershwin Prize for Popular Song: http:\/\/t.co\/Q81vtlVHMw",
  "id" : 352173252245864449,
  "created_at" : "2013-07-02 21:13:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FLOTUSinAfrica",
      "indices" : [ 110, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/w96RlfYbsG",
      "expanded_url" : "http:\/\/wh.gov\/lcw0H",
      "display_url" : "wh.gov\/lcw0H"
    } ]
  },
  "geo" : { },
  "id_str" : "352161563152621568",
  "text" : "RT @FLOTUS: The First Lady's Travel Journal: Empowering Girls Through Education --&gt; http:\/\/t.co\/w96RlfYbsG #FLOTUSinAfrica http:\/\/t.co\/z00T\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/352144131633606656\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/z00TQil9as",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BOMRONQCcAEmdI0.jpg",
        "id_str" : "352144131637800961",
        "id" : 352144131637800961,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BOMRONQCcAEmdI0.jpg",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 610,
          "resize" : "fit",
          "w" : 610
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 610,
          "resize" : "fit",
          "w" : 610
        } ],
        "display_url" : "pic.twitter.com\/z00TQil9as"
      } ],
      "hashtags" : [ {
        "text" : "FLOTUSinAfrica",
        "indices" : [ 98, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/w96RlfYbsG",
        "expanded_url" : "http:\/\/wh.gov\/lcw0H",
        "display_url" : "wh.gov\/lcw0H"
      } ]
    },
    "geo" : { },
    "id_str" : "352144131633606656",
    "text" : "The First Lady's Travel Journal: Empowering Girls Through Education --&gt; http:\/\/t.co\/w96RlfYbsG #FLOTUSinAfrica http:\/\/t.co\/z00TQil9as",
    "id" : 352144131633606656,
    "created_at" : "2013-07-02 19:17:58 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 352161563152621568,
  "created_at" : "2013-07-02 20:27:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/352147220897878016\/photo\/1",
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/Cggbhsqks5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BOMUCBqCUAAWxWu.png",
      "id_str" : "352147220902072320",
      "id" : 352147220902072320,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BOMUCBqCUAAWxWu.png",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 609,
        "resize" : "fit",
        "w" : 609
      }, {
        "h" : 609,
        "resize" : "fit",
        "w" : 609
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/Cggbhsqks5"
    } ],
    "hashtags" : [ {
      "text" : "FLOTUSInAfrica",
      "indices" : [ 43, 58 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352147220897878016",
  "text" : "Beautiful end to a great trip in Tanzania. #FLOTUSInAfrica, http:\/\/t.co\/Cggbhsqks5",
  "id" : 352147220897878016,
  "created_at" : "2013-07-02 19:30:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/352127830366236672\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/zy8x7ZMppE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BOMCZWUCMAARr4U.jpg",
      "id_str" : "352127830374625280",
      "id" : 352127830374625280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BOMCZWUCMAARr4U.jpg",
      "sizes" : [ {
        "h" : 611,
        "resize" : "fit",
        "w" : 611
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 611,
        "resize" : "fit",
        "w" : 611
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/zy8x7ZMppE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352127830366236672",
  "text" : "A moment worth sharing: The Obama family visits former President Nelson Mandela's prison cell in South Africa. http:\/\/t.co\/zy8x7ZMppE",
  "id" : 352127830366236672,
  "created_at" : "2013-07-02 18:13:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouse\/status\/352120756173414400\/photo\/1",
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/BPrUCEeFHb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BOL79k4CIAEiLT0.jpg",
      "id_str" : "352120756177608705",
      "id" : 352120756177608705,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BOL79k4CIAEiLT0.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 667,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 667,
        "resize" : "fit",
        "w" : 1000
      } ],
      "display_url" : "pic.twitter.com\/BPrUCEeFHb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352120756173414400",
  "text" : "Nice hair, kid. http:\/\/t.co\/BPrUCEeFHb",
  "id" : 352120756173414400,
  "created_at" : "2013-07-02 17:45:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/352106782002401280\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/QU5NJhJHUv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BOLvQLCCUAAktu7.jpg",
      "id_str" : "352106782006595584",
      "id" : 352106782006595584,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BOLvQLCCUAAktu7.jpg",
      "sizes" : [ {
        "h" : 213,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 625,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 625,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 375,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/QU5NJhJHUv"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352106782002401280",
  "text" : "President Obama and President Bush greet survivors of the 1998 bombing at the U.S. Embassy in Tanzania. http:\/\/t.co\/QU5NJhJHUv",
  "id" : 352106782002401280,
  "created_at" : "2013-07-02 16:49:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/SLxGV0DGqS",
      "expanded_url" : "http:\/\/at.wh.gov\/mAFLi",
      "display_url" : "at.wh.gov\/mAFLi"
    } ]
  },
  "geo" : { },
  "id_str" : "352095470727868416",
  "text" : "\"Bill Gray was a trailblazer.\" \u2014Obama on the passing of the former Congressman &amp; 1st African American Majority Whip: http:\/\/t.co\/SLxGV0DGqS",
  "id" : 352095470727868416,
  "created_at" : "2013-07-02 16:04:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Financial Times",
      "screen_name" : "FinancialTimes",
      "indices" : [ 41, 56 ],
      "id_str" : "4898091",
      "id" : 4898091
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Croatia",
      "indices" : [ 60, 68 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/cDq9eVS8lp",
      "expanded_url" : "http:\/\/www.ft.com\/intl\/cms\/s\/0\/cfa708d0-e243-11e2-87ec-00144feabdc0.html#axzz2Xo7tfqSR",
      "display_url" : "ft.com\/intl\/cms\/s\/0\/c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "352085932255625219",
  "text" : "RT @VP: Read VP Biden's op-ed in today's @FinancialTimes on #Croatia becoming the 28th member of the EU: http:\/\/t.co\/cDq9eVS8lp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Financial Times",
        "screen_name" : "FinancialTimes",
        "indices" : [ 33, 48 ],
        "id_str" : "4898091",
        "id" : 4898091
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Croatia",
        "indices" : [ 52, 60 ]
      } ],
      "urls" : [ {
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/cDq9eVS8lp",
        "expanded_url" : "http:\/\/www.ft.com\/intl\/cms\/s\/0\/cfa708d0-e243-11e2-87ec-00144feabdc0.html#axzz2Xo7tfqSR",
        "display_url" : "ft.com\/intl\/cms\/s\/0\/c\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "352038059769991169",
    "text" : "Read VP Biden's op-ed in today's @FinancialTimes on #Croatia becoming the 28th member of the EU: http:\/\/t.co\/cDq9eVS8lp",
    "id" : 352038059769991169,
    "created_at" : "2013-07-02 12:16:28 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 352085932255625219,
  "created_at" : "2013-07-02 15:26:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ObamaInAfrica",
      "indices" : [ 125, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/zuWe65msvE",
      "expanded_url" : "http:\/\/at.wh.gov\/mArVD",
      "display_url" : "at.wh.gov\/mArVD"
    } ]
  },
  "geo" : { },
  "id_str" : "352079323336933380",
  "text" : "President Obama just wrapped up his trip to Africa with a stop in Tanzania. Check out the highlights: http:\/\/t.co\/zuWe65msvE #ObamaInAfrica",
  "id" : 352079323336933380,
  "created_at" : "2013-07-02 15:00:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/352070975229153280\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/L5vEh0Xsgo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BOLOr8cCUAApFb-.jpg",
      "id_str" : "352070975241736192",
      "id" : 352070975241736192,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BOLOr8cCUAApFb-.jpg",
      "sizes" : [ {
        "h" : 611,
        "resize" : "fit",
        "w" : 611
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 611,
        "resize" : "fit",
        "w" : 611
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/L5vEh0Xsgo"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "352070975229153280",
  "text" : "Heads up: President Obama tries out a Soccket ball in Tanzania\u2014which generates and stores energy when kicked. http:\/\/t.co\/L5vEh0Xsgo",
  "id" : 352070975229153280,
  "created_at" : "2013-07-02 14:27:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MilkyWay",
      "indices" : [ 110, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "351839859977105410",
  "text" : "RT @Interior: If you were stargazing in Great Smoky Mountains National Park, you might catch this view of the #MilkyWay. http:\/\/t.co\/gWtN3V\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/351823036376293378\/photo\/1",
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/gWtN3VqJbM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BOHtMAOCIAE1xPM.jpg",
        "id_str" : "351823036384681985",
        "id" : 351823036384681985,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BOHtMAOCIAE1xPM.jpg",
        "sizes" : [ {
          "h" : 478,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 729
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 729
        }, {
          "h" : 843,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/gWtN3VqJbM"
      } ],
      "hashtags" : [ {
        "text" : "MilkyWay",
        "indices" : [ 96, 105 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "351823036376293378",
    "text" : "If you were stargazing in Great Smoky Mountains National Park, you might catch this view of the #MilkyWay. http:\/\/t.co\/gWtN3VqJbM",
    "id" : 351823036376293378,
    "created_at" : "2013-07-01 22:02:03 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 351839859977105410,
  "created_at" : "2013-07-01 23:08:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FLOTUSinAfrica",
      "indices" : [ 114, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/KqQsEFII9L",
      "expanded_url" : "http:\/\/at.wh.gov\/mx6Bu",
      "display_url" : "at.wh.gov\/mx6Bu"
    } ]
  },
  "geo" : { },
  "id_str" : "351835057775841280",
  "text" : "RT @FLOTUS: \"Keep your big dreams\" \u2014The First Lady to youth in Africa &amp; across the US: http:\/\/t.co\/KqQsEFII9L #FLOTUSinAfrica http:\/\/t.co\/i\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/351604701575389184\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/ijvll72B8S",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BOEmnPsCIAElZ68.jpg",
        "id_str" : "351604701579583489",
        "id" : 351604701579583489,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BOEmnPsCIAElZ68.jpg",
        "sizes" : [ {
          "h" : 733,
          "resize" : "fit",
          "w" : 1100
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/ijvll72B8S"
      } ],
      "hashtags" : [ {
        "text" : "FLOTUSinAfrica",
        "indices" : [ 102, 117 ]
      } ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/KqQsEFII9L",
        "expanded_url" : "http:\/\/at.wh.gov\/mx6Bu",
        "display_url" : "at.wh.gov\/mx6Bu"
      } ]
    },
    "geo" : { },
    "id_str" : "351604701575389184",
    "text" : "\"Keep your big dreams\" \u2014The First Lady to youth in Africa &amp; across the US: http:\/\/t.co\/KqQsEFII9L #FLOTUSinAfrica http:\/\/t.co\/ijvll72B8S",
    "id" : 351604701575389184,
    "created_at" : "2013-07-01 07:34:28 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 351835057775841280,
  "created_at" : "2013-07-01 22:49:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouse\/status\/351828775190798336\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/pnBCU7bSCQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BOHyaC_CIAAls5P.jpg",
      "id_str" : "351828775203381248",
      "id" : 351828775203381248,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BOHyaC_CIAAls5P.jpg",
      "sizes" : [ {
        "h" : 666,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 666,
        "resize" : "fit",
        "w" : 1000
      } ],
      "display_url" : "pic.twitter.com\/pnBCU7bSCQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/7JhpNJ9cul",
      "expanded_url" : "http:\/\/at.wh.gov\/mz2hT",
      "display_url" : "at.wh.gov\/mz2hT"
    } ]
  },
  "geo" : { },
  "id_str" : "351828775190798336",
  "text" : "\"Ultimately, the goal here is for Africa to build Africa for Africans.\" \u2014Obama in Tanzania: http:\/\/t.co\/7JhpNJ9cul, http:\/\/t.co\/pnBCU7bSCQ",
  "id" : 351828775190798336,
  "created_at" : "2013-07-01 22:24:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "351760557877112836",
  "text" : "RT @FLOTUS: These kids are amazing. I want young people all across the world \u2014 &amp; especially at home \u2014 to see that education is the key to s\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "351752551672197120",
    "text" : "These kids are amazing. I want young people all across the world \u2014 &amp; especially at home \u2014 to see that education is the key to success. -mo",
    "id" : 351752551672197120,
    "created_at" : "2013-07-01 17:21:58 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 351760557877112836,
  "created_at" : "2013-07-01 17:53:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 42, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/yGPr4v4pML",
      "expanded_url" : "http:\/\/at.wh.gov\/myff3",
      "display_url" : "at.wh.gov\/myff3"
    } ]
  },
  "geo" : { },
  "id_str" : "351748141017595907",
  "text" : "RT the good news: The Senate's bipartisan #ImmigrationReform bill would strengthen social security. http:\/\/t.co\/yGPr4v4pML",
  "id" : 351748141017595907,
  "created_at" : "2013-07-01 17:04:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 41, 48 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "351740235828301824",
  "text" : "RT @FLOTUS: Hey twitter, I'm taking over @FLOTUS today! We're in Dar es Salaam\u2014my 1st visit to Tanzania\u2014I couldn't be more excited!\n-mo #FL\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The First Lady",
        "screen_name" : "FLOTUS",
        "indices" : [ 29, 36 ],
        "id_str" : "1093090866",
        "id" : 1093090866
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FLOTUSinAfrica",
        "indices" : [ 124, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "351739530321203201",
    "text" : "Hey twitter, I'm taking over @FLOTUS today! We're in Dar es Salaam\u2014my 1st visit to Tanzania\u2014I couldn't be more excited!\n-mo #FLOTUSinAfrica",
    "id" : 351739530321203201,
    "created_at" : "2013-07-01 16:30:13 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 351740235828301824,
  "created_at" : "2013-07-01 16:33:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Arizona",
      "indices" : [ 126, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/wFKTiugmb7",
      "expanded_url" : "http:\/\/at.wh.gov\/mxWAZ",
      "display_url" : "at.wh.gov\/mxWAZ"
    } ]
  },
  "geo" : { },
  "id_str" : "351716900314685440",
  "text" : "Obama: \"19 firefighters were killed in the line of duty while fighting a wildfire...they were heroes.\" http:\/\/t.co\/wFKTiugmb7 #Arizona",
  "id" : 351716900314685440,
  "created_at" : "2013-07-01 15:00:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "indices" : [ 3, 18 ],
      "id_str" : "19674502",
      "id" : 19674502
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 122, 133 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "351708025750433793",
  "text" : "RT @AmbassadorRice: Truly honored to have served the President for the last 4.5 years at the UN &amp; excited to begin as @whitehouse National \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 102, 113 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "351705541833273345",
    "text" : "Truly honored to have served the President for the last 4.5 years at the UN &amp; excited to begin as @whitehouse National Security Advisor.",
    "id" : 351705541833273345,
    "created_at" : "2013-07-01 14:15:10 +0000",
    "user" : {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "protected" : false,
      "id_str" : "19674502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2245433940\/297681_10150417294436240_295915266239_10074516_1895344954_n_normal.jpg",
      "id" : 19674502,
      "verified" : true
    }
  },
  "id" : 351708025750433793,
  "created_at" : "2013-07-01 14:25:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Arizona",
      "indices" : [ 23, 31 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/Q40Ui0bT1V",
      "expanded_url" : "http:\/\/at.wh.gov\/mxOqT",
      "display_url" : "at.wh.gov\/mxOqT"
    } ]
  },
  "geo" : { },
  "id_str" : "351703457104801793",
  "text" : "President Obama on the #Arizona wildfire that killed 19 firefighters in the line of duty yesterday: http:\/\/t.co\/Q40Ui0bT1V",
  "id" : 351703457104801793,
  "created_at" : "2013-07-01 14:06:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
} ]