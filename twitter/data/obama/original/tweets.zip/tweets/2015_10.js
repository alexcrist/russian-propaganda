Grailbird.data.tweets_2015_10 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/Bs8G9dhR0b",
      "expanded_url" : "http:\/\/bit.ly\/1k0dEBO",
      "display_url" : "bit.ly\/1k0dEBO"
    } ]
  },
  "geo" : { },
  "id_str" : "660607329428111360",
  "text" : "Happy Halloween! https:\/\/t.co\/Bs8G9dhR0b",
  "id" : 660607329428111360,
  "created_at" : "2015-11-01 00:00:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 28, 34 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/660548212768399360\/photo\/1",
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/BAWB8t1ibk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSq8yDcWIAA6gke.jpg",
      "id_str" : "660547863466876928",
      "id" : 660547863466876928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSq8yDcWIAA6gke.jpg",
      "sizes" : [ {
        "h" : 2044,
        "resize" : "fit",
        "w" : 2800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 248,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 748,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 438,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/BAWB8t1ibk"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/660548212768399360\/photo\/1",
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/BAWB8t1ibk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSq8yBwWUAE5lsS.jpg",
      "id_str" : "660547863013904385",
      "id" : 660547863013904385,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSq8yBwWUAE5lsS.jpg",
      "sizes" : [ {
        "h" : 420,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 717,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 238,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1961,
        "resize" : "fit",
        "w" : 2800
      } ],
      "display_url" : "pic.twitter.com\/BAWB8t1ibk"
    } ],
    "hashtags" : [ {
      "text" : "TopPrize",
      "indices" : [ 50, 59 ]
    }, {
      "text" : "HappyHalloween",
      "indices" : [ 60, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "660548212768399360",
  "text" : "Wait...wasn't he just here? @POTUS and Lil' Pope! #TopPrize #HappyHalloween https:\/\/t.co\/BAWB8t1ibk",
  "id" : 660548212768399360,
  "created_at" : "2015-10-31 20:05:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/660542376360865792\/photo\/1",
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/nxpzUqSZmQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSq3wU8WEAA5KBr.jpg",
      "id_str" : "660542336246616064",
      "id" : 660542336246616064,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSq3wU8WEAA5KBr.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1867,
        "resize" : "fit",
        "w" : 2800
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/nxpzUqSZmQ"
    } ],
    "hashtags" : [ {
      "text" : "HappyHalloween",
      "indices" : [ 30, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "660542376360865792",
  "text" : "Trick-or-treating with POTUS. #HappyHalloween https:\/\/t.co\/nxpzUqSZmQ",
  "id" : 660542376360865792,
  "created_at" : "2015-10-31 19:42:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/660509843141234688\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/aqLa3iauTO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSqaMfNW4AAXe7x.jpg",
      "id_str" : "660509834689830912",
      "id" : 660509834689830912,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSqaMfNW4AAXe7x.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/aqLa3iauTO"
    } ],
    "hashtags" : [ {
      "text" : "GetCovered",
      "indices" : [ 101, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/5r9E9gPkQk",
      "expanded_url" : "http:\/\/go.wh.gov\/GetCovered",
      "display_url" : "go.wh.gov\/GetCovered"
    } ]
  },
  "geo" : { },
  "id_str" : "660509843141234688",
  "text" : "Do you or someone you know need health coverage? Sign up starting tomorrow \u2192 https:\/\/t.co\/5r9E9gPkQk #GetCovered https:\/\/t.co\/aqLa3iauTO",
  "id" : 660509843141234688,
  "created_at" : "2015-10-31 17:33:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 21, 27 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CriminalJusticeReform",
      "indices" : [ 75, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/UYigivfKR3",
      "expanded_url" : "http:\/\/go.wh.gov\/tRGTPz",
      "display_url" : "go.wh.gov\/tRGTPz"
    } ]
  },
  "geo" : { },
  "id_str" : "660470438825357312",
  "text" : "RT if you agree with @POTUS: It's time to fix our criminal justice system. #CriminalJusticeReform https:\/\/t.co\/UYigivfKR3",
  "id" : 660470438825357312,
  "created_at" : "2015-10-31 14:56:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/660260358834130944\/photo\/1",
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/ZBkW1xrSLq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSm3DHYWwAAUlR6.jpg",
      "id_str" : "660260084535181312",
      "id" : 660260084535181312,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSm3DHYWwAAUlR6.jpg",
      "sizes" : [ {
        "h" : 667,
        "resize" : "fit",
        "w" : 927
      }, {
        "h" : 245,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 432,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 667,
        "resize" : "fit",
        "w" : 927
      } ],
      "display_url" : "pic.twitter.com\/ZBkW1xrSLq"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "660260358834130944",
  "text" : "Trick-or-treat! https:\/\/t.co\/ZBkW1xrSLq",
  "id" : 660260358834130944,
  "created_at" : "2015-10-31 01:01:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HappyHalloween",
      "indices" : [ 111, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/8bq4UBrFO9",
      "expanded_url" : "http:\/\/go.nasa.gov\/1irRW87",
      "display_url" : "go.nasa.gov\/1irRW87"
    } ]
  },
  "geo" : { },
  "id_str" : "660241190126682112",
  "text" : "RT @NASA: Dead comet that will safely zip by Earth on Oct 31 looks eerie like a skull: https:\/\/t.co\/8bq4UBrFO9 #HappyHalloween https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NASA\/status\/660240391682310145\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/gICZTSLcZr",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CSmlIx8XIAAUHTD.png",
        "id_str" : "660240390650535936",
        "id" : 660240390650535936,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CSmlIx8XIAAUHTD.png",
        "sizes" : [ {
          "h" : 1041,
          "resize" : "fit",
          "w" : 1041
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/gICZTSLcZr"
      } ],
      "hashtags" : [ {
        "text" : "HappyHalloween",
        "indices" : [ 101, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 100 ],
        "url" : "https:\/\/t.co\/8bq4UBrFO9",
        "expanded_url" : "http:\/\/go.nasa.gov\/1irRW87",
        "display_url" : "go.nasa.gov\/1irRW87"
      } ]
    },
    "geo" : { },
    "id_str" : "660240391682310145",
    "text" : "Dead comet that will safely zip by Earth on Oct 31 looks eerie like a skull: https:\/\/t.co\/8bq4UBrFO9 #HappyHalloween https:\/\/t.co\/gICZTSLcZr",
    "id" : 660240391682310145,
    "created_at" : "2015-10-30 23:42:30 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 660241190126682112,
  "created_at" : "2015-10-30 23:45:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Optimizely",
      "screen_name" : "Optimizely",
      "indices" : [ 17, 28 ],
      "id_str" : "108559862",
      "id" : 108559862
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LeadOnLeave",
      "indices" : [ 44, 56 ]
    }, {
      "text" : "PaidLeave",
      "indices" : [ 95, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "660235238488956928",
  "text" : "RT @vj44: Thanks @Optimizely for taking the #LeadOnLeave! Now it's time for Congress to expand #PaidLeave for all Americans https:\/\/t.co\/a1\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Optimizely",
        "screen_name" : "Optimizely",
        "indices" : [ 7, 18 ],
        "id_str" : "108559862",
        "id" : 108559862
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LeadOnLeave",
        "indices" : [ 34, 46 ]
      }, {
        "text" : "PaidLeave",
        "indices" : [ 85, 95 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/a1grIGUTYo",
        "expanded_url" : "https:\/\/twitter.com\/optimizely\/status\/660220662536122368",
        "display_url" : "twitter.com\/optimizely\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "660233690493120512",
    "text" : "Thanks @Optimizely for taking the #LeadOnLeave! Now it's time for Congress to expand #PaidLeave for all Americans https:\/\/t.co\/a1grIGUTYo",
    "id" : 660233690493120512,
    "created_at" : "2015-10-30 23:15:53 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 660235238488956928,
  "created_at" : "2015-10-30 23:22:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HappyHalloween",
      "indices" : [ 29, 44 ]
    } ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/WJo1nYUWup",
      "expanded_url" : "http:\/\/bit.ly\/1PauHfU",
      "display_url" : "bit.ly\/1PauHfU"
    } ]
  },
  "geo" : { },
  "id_str" : "660215950692716544",
  "text" : "Top prize goes to Lil' Pope. #HappyHalloween https:\/\/t.co\/WJo1nYUWup",
  "id" : 660215950692716544,
  "created_at" : "2015-10-30 22:05:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/660210277271621632\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/VRukt3SxgV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSmJv5xVEAANbjW.jpg",
      "id_str" : "660210276441067520",
      "id" : 660210276441067520,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSmJv5xVEAANbjW.jpg",
      "sizes" : [ {
        "h" : 1035,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1092,
        "resize" : "fit",
        "w" : 1080
      }, {
        "h" : 607,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 344,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/VRukt3SxgV"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/b4tqL36eMn",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "660210277271621632",
  "text" : "Bo and Sunny are ready to greet some trick-or-treaters. Watch live from the South Lawn \u2192 https:\/\/t.co\/b4tqL36eMn https:\/\/t.co\/VRukt3SxgV",
  "id" : 660210277271621632,
  "created_at" : "2015-10-30 21:42:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 32, 38 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 43, 50 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/660205357298528257\/photo\/1",
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/dqCUtGDJ8R",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSmFRh8VEAASaGT.jpg",
      "id_str" : "660205356602167296",
      "id" : 660205356602167296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSmFRh8VEAASaGT.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1050
      } ],
      "display_url" : "pic.twitter.com\/dqCUtGDJ8R"
    } ],
    "hashtags" : [ {
      "text" : "HappyHalloween",
      "indices" : [ 77, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 76 ],
      "url" : "https:\/\/t.co\/4VpTAr8p3I",
      "expanded_url" : "http:\/\/go.wh.gov\/Wi3nnG",
      "display_url" : "go.wh.gov\/Wi3nnG"
    } ]
  },
  "geo" : { },
  "id_str" : "660205357298528257",
  "text" : "Watch live: Trick-or-treat with @POTUS and @FLOTUS \u2192 https:\/\/t.co\/4VpTAr8p3I #HappyHalloween https:\/\/t.co\/dqCUtGDJ8R",
  "id" : 660205357298528257,
  "created_at" : "2015-10-30 21:23:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/660159512049938432\/photo\/1",
      "indices" : [ 118, 141 ],
      "url" : "https:\/\/t.co\/YluVDlnHiq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSlSaqSWwAUR2h7.jpg",
      "id_str" : "660149438367842309",
      "id" : 660149438367842309,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSlSaqSWwAUR2h7.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1250,
        "resize" : "fit",
        "w" : 2500
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/YluVDlnHiq"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "660159512049938432",
  "text" : "The bipartisan budget agreement helps make sure hedge funds &amp; private equity firms pay their fair share in taxes. https:\/\/t.co\/YluVDlnHiq",
  "id" : 660159512049938432,
  "created_at" : "2015-10-30 18:21:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/660152968134594560\/photo\/1",
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/K56SoDNMUs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSlRxOrXAAA7zdM.jpg",
      "id_str" : "660148726581886976",
      "id" : 660148726581886976,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSlRxOrXAAA7zdM.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1250,
        "resize" : "fit",
        "w" : 2500
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/K56SoDNMUs"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/B9dxCWMoLw",
      "expanded_url" : "http:\/\/go.wh.gov\/BudgetDeal",
      "display_url" : "go.wh.gov\/BudgetDeal"
    } ]
  },
  "geo" : { },
  "id_str" : "660152968134594560",
  "text" : "See how the bipartisan budget agreement benefits millions of seniors \u2192 https:\/\/t.co\/B9dxCWMoLw https:\/\/t.co\/K56SoDNMUs",
  "id" : 660152968134594560,
  "created_at" : "2015-10-30 17:55:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/660148372041506816\/photo\/1",
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/M5YFTOmyRD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSlRUj5XAAAHRQl.jpg",
      "id_str" : "660148234061545472",
      "id" : 660148234061545472,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSlRUj5XAAAHRQl.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1250,
        "resize" : "fit",
        "w" : 2500
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/M5YFTOmyRD"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/B9dxCWuNTY",
      "expanded_url" : "http:\/\/go.wh.gov\/BudgetDeal",
      "display_url" : "go.wh.gov\/BudgetDeal"
    } ]
  },
  "geo" : { },
  "id_str" : "660148372041506816",
  "text" : "FACT: The bipartisan budget agreement will add 340,000 jobs in 2016 alone \u2192 https:\/\/t.co\/B9dxCWuNTY https:\/\/t.co\/M5YFTOmyRD",
  "id" : 660148372041506816,
  "created_at" : "2015-10-30 17:36:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Social Security",
      "screen_name" : "SocialSecurity",
      "indices" : [ 41, 56 ],
      "id_str" : "39580052",
      "id" : 39580052
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/660135826081185792\/photo\/1",
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/ejcdVbZeD4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSlF4s7WIAQCVJE.jpg",
      "id_str" : "660135660821553156",
      "id" : 660135660821553156,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSlF4s7WIAQCVJE.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1250,
        "resize" : "fit",
        "w" : 2500
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ejcdVbZeD4"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/B9dxCWMoLw",
      "expanded_url" : "http:\/\/go.wh.gov\/BudgetDeal",
      "display_url" : "go.wh.gov\/BudgetDeal"
    } ]
  },
  "geo" : { },
  "id_str" : "660135826081185792",
  "text" : "The bipartisan budget agreement protects @SocialSecurity.\nHere's how \u2192 https:\/\/t.co\/B9dxCWMoLw https:\/\/t.co\/ejcdVbZeD4",
  "id" : 660135826081185792,
  "created_at" : "2015-10-30 16:47:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "indices" : [ 34, 43 ],
      "id_str" : "249722522",
      "id" : 249722522
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/660113974701068288\/photo\/1",
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/CjOPiK0pTy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSkof8nWsAAG1sd.jpg",
      "id_str" : "660103349698736128",
      "id" : 660103349698736128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSkof8nWsAAG1sd.jpg",
      "sizes" : [ {
        "h" : 399,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 639,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 639,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/CjOPiK0pTy"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 99 ],
      "url" : "https:\/\/t.co\/Rx2buumGDb",
      "expanded_url" : "http:\/\/on.fb.me\/1MZjJ8h",
      "display_url" : "on.fb.me\/1MZjJ8h"
    } ]
  },
  "geo" : { },
  "id_str" : "660113974701068288",
  "text" : "Go behind the scenes in Laos with @Rhodes44 ahead of the President's trip \u2192 https:\/\/t.co\/Rx2buumGDb PHOTO https:\/\/t.co\/CjOPiK0pTy",
  "id" : 660113974701068288,
  "created_at" : "2015-10-30 15:20:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "InvictusGames",
      "indices" : [ 112, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "660107035648765952",
  "text" : "RT @FLOTUS: \"We want the world to see these stories of grit and courage and grace.\" \u2014FLOTUS on wounded warriors #InvictusGames https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/659885686791602176\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/wGTlbDwGHl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CShiccYWsAA5IxX.jpg",
        "id_str" : "659885586203979776",
        "id" : 659885586203979776,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CShiccYWsAA5IxX.jpg",
        "sizes" : [ {
          "h" : 1886,
          "resize" : "fit",
          "w" : 2800
        }, {
          "h" : 404,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 229,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 690,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/wGTlbDwGHl"
      } ],
      "hashtags" : [ {
        "text" : "InvictusGames",
        "indices" : [ 100, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "659885686791602176",
    "text" : "\"We want the world to see these stories of grit and courage and grace.\" \u2014FLOTUS on wounded warriors #InvictusGames https:\/\/t.co\/wGTlbDwGHl",
    "id" : 659885686791602176,
    "created_at" : "2015-10-30 00:13:02 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 660107035648765952,
  "created_at" : "2015-10-30 14:52:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/660101480578330624\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/p4VAB56iL4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSkhDZNWUAAy-jS.jpg",
      "id_str" : "660095162576687104",
      "id" : 660095162576687104,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSkhDZNWUAAy-jS.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/p4VAB56iL4"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/B9dxCWMoLw",
      "expanded_url" : "http:\/\/go.wh.gov\/BudgetDeal",
      "display_url" : "go.wh.gov\/BudgetDeal"
    } ]
  },
  "geo" : { },
  "id_str" : "660101480578330624",
  "text" : "The bipartisan budget agreement is a major step forward for our economy.\nGet the details \u2192 https:\/\/t.co\/B9dxCWMoLw https:\/\/t.co\/p4VAB56iL4",
  "id" : 660101480578330624,
  "created_at" : "2015-10-30 14:30:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 113, 119 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/660094912642179072\/photo\/1",
      "indices" : [ 120, 143 ],
      "url" : "https:\/\/t.co\/YfHaXBuOqn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSkgzGtWUAApabo.jpg",
      "id_str" : "660094882732724224",
      "id" : 660094882732724224,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSkgzGtWUAApabo.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/YfHaXBuOqn"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "660094912642179072",
  "text" : "\"This agreement will strengthen the middle class by investing in education, job training &amp; basic research.\" \u2014@POTUS https:\/\/t.co\/YfHaXBuOqn",
  "id" : 660094912642179072,
  "created_at" : "2015-10-30 14:04:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/660087695188860928\/photo\/1",
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/7RSffyaU7v",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSkaMuIWEAENoyC.jpg",
      "id_str" : "660087626230272001",
      "id" : 660087626230272001,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSkaMuIWEAENoyC.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/7RSffyaU7v"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/B9dxCWuNTY",
      "expanded_url" : "http:\/\/go.wh.gov\/BudgetDeal",
      "display_url" : "go.wh.gov\/BudgetDeal"
    } ]
  },
  "geo" : { },
  "id_str" : "660087695188860928",
  "text" : ".@POTUS on passage of the bipartisan budget agreement \u2192 https:\/\/t.co\/B9dxCWuNTY https:\/\/t.co\/7RSffyaU7v",
  "id" : 660087695188860928,
  "created_at" : "2015-10-30 13:35:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/659870820223860737\/photo\/1",
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/PJbjCzIAjI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CShUzLoW4AAhEzV.jpg",
      "id_str" : "659870583681900544",
      "id" : 659870583681900544,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CShUzLoW4AAhEzV.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/PJbjCzIAjI"
    } ],
    "hashtags" : [ {
      "text" : "NationalCatDay",
      "indices" : [ 6, 21 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659870820223860737",
  "text" : "Happy #NationalCatDay! https:\/\/t.co\/PJbjCzIAjI",
  "id" : 659870820223860737,
  "created_at" : "2015-10-29 23:13:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Kelly",
      "screen_name" : "StationCDRKelly",
      "indices" : [ 12, 28 ],
      "id_str" : "65647594",
      "id" : 65647594
    }, {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 99, 104 ],
      "id_str" : "11348282",
      "id" : 11348282
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/659858843984375808\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/iR0Gce721X",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CShJ9aOWcAAWPAl.jpg",
      "id_str" : "659858664770138112",
      "id" : 659858664770138112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CShJ9aOWcAAWPAl.jpg",
      "sizes" : [ {
        "h" : 447,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 447,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 447,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 253,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/iR0Gce721X"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659858843984375808",
  "text" : "Congrats to @StationCDRKelly on breaking the record today for being in space longer than any other @NASA astronaut. https:\/\/t.co\/iR0Gce721X",
  "id" : 659858843984375808,
  "created_at" : "2015-10-29 22:26:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 85, 91 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/9slXM8GS04",
      "expanded_url" : "http:\/\/go.wh.gov\/FixTheSystem",
      "display_url" : "go.wh.gov\/FixTheSystem"
    }, {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/PvNOvzmtXL",
      "expanded_url" : "http:\/\/bit.ly\/1jSmC3W",
      "display_url" : "bit.ly\/1jSmC3W"
    } ]
  },
  "geo" : { },
  "id_str" : "659847704709722116",
  "text" : "\"Each victim of crime is one too many. Each fallen police officer is one too many.\" \u2014@POTUS: https:\/\/t.co\/9slXM8GS04 https:\/\/t.co\/PvNOvzmtXL",
  "id" : 659847704709722116,
  "created_at" : "2015-10-29 21:42:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Judith Heumann",
      "screen_name" : "IntDisability",
      "indices" : [ 3, 17 ],
      "id_str" : "1364655631",
      "id" : 1364655631
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 60, 71 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WithoutLimits",
      "indices" : [ 114, 128 ]
    }, {
      "text" : "NDEAM",
      "indices" : [ 129, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659844374306693122",
  "text" : "RT @IntDisability: My name is Leah. I am deaf. I work @ the @WhiteHouse as the West Wing Receptionist. Employment #WithoutLimits #NDEAM htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 41, 52 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/IntDisability\/status\/659715962808221696\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/7O64TzMkMg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CSfILB-VEAAszpc.jpg",
        "id_str" : "659715962267045888",
        "id" : 659715962267045888,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSfILB-VEAAszpc.jpg",
        "sizes" : [ {
          "h" : 1039,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 589,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1773,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 3673,
          "resize" : "fit",
          "w" : 2121
        } ],
        "display_url" : "pic.twitter.com\/7O64TzMkMg"
      } ],
      "hashtags" : [ {
        "text" : "WithoutLimits",
        "indices" : [ 95, 109 ]
      }, {
        "text" : "NDEAM",
        "indices" : [ 110, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "659715962808221696",
    "text" : "My name is Leah. I am deaf. I work @ the @WhiteHouse as the West Wing Receptionist. Employment #WithoutLimits #NDEAM https:\/\/t.co\/7O64TzMkMg",
    "id" : 659715962808221696,
    "created_at" : "2015-10-29 12:58:37 +0000",
    "user" : {
      "name" : "Judith Heumann",
      "screen_name" : "IntDisability",
      "protected" : false,
      "id_str" : "1364655631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/650205971348717568\/nrflwTHp_normal.jpg",
      "id" : 1364655631,
      "verified" : true
    }
  },
  "id" : 659844374306693122,
  "created_at" : "2015-10-29 21:28:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WSAZ NewsChannel 3",
      "screen_name" : "WSAZnews",
      "indices" : [ 3, 12 ],
      "id_str" : "19925980",
      "id" : 19925980
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/xbHKRO0L8Z",
      "expanded_url" : "http:\/\/bit.ly\/1MtYq4l",
      "display_url" : "bit.ly\/1MtYq4l"
    } ]
  },
  "geo" : { },
  "id_str" : "659832510801539072",
  "text" : "RT @WSAZnews: Man Calls 911, Turns In Drugs After Hearing Obama's Speech https:\/\/t.co\/xbHKRO0L8Z",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 82 ],
        "url" : "https:\/\/t.co\/xbHKRO0L8Z",
        "expanded_url" : "http:\/\/bit.ly\/1MtYq4l",
        "display_url" : "bit.ly\/1MtYq4l"
      } ]
    },
    "geo" : { },
    "id_str" : "659491095512899586",
    "text" : "Man Calls 911, Turns In Drugs After Hearing Obama's Speech https:\/\/t.co\/xbHKRO0L8Z",
    "id" : 659491095512899586,
    "created_at" : "2015-10-28 22:05:04 +0000",
    "user" : {
      "name" : "WSAZ NewsChannel 3",
      "screen_name" : "WSAZnews",
      "protected" : false,
      "id_str" : "19925980",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2426077835\/4ovl2ai87vwbopnw7qsy_normal.jpeg",
      "id" : 19925980,
      "verified" : true
    }
  },
  "id" : 659832510801539072,
  "created_at" : "2015-10-29 20:41:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/659830589915160576\/photo\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/qXDsisshpu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSgvXIVWEAAdoko.jpg",
      "id_str" : "659829419830284288",
      "id" : 659829419830284288,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSgvXIVWEAAdoko.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1250,
        "resize" : "fit",
        "w" : 2500
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/qXDsisshpu"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/9slXM8GS04",
      "expanded_url" : "http:\/\/go.wh.gov\/FixTheSystem",
      "display_url" : "go.wh.gov\/FixTheSystem"
    } ]
  },
  "geo" : { },
  "id_str" : "659830589915160576",
  "text" : "Over the last few decades, we've locked up more non-violent offenders than ever before. https:\/\/t.co\/9slXM8GS04 https:\/\/t.co\/qXDsisshpu",
  "id" : 659830589915160576,
  "created_at" : "2015-10-29 20:34:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 3, 11 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    }, {
      "name" : "Seth Meyers",
      "screen_name" : "sethmeyers",
      "indices" : [ 45, 56 ],
      "id_str" : "44039298",
      "id" : 44039298
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FreeCommunityCollege",
      "indices" : [ 83, 104 ]
    }, {
      "text" : "HeadsUpAmerica",
      "indices" : [ 105, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659815270224015360",
  "text" : "RT @DrBiden: Looking forward to talking with @SethMeyers about one of my passions. #FreeCommunityCollege #HeadsUpAmerica \u2013Jill https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Seth Meyers",
        "screen_name" : "sethmeyers",
        "indices" : [ 32, 43 ],
        "id_str" : "44039298",
        "id" : 44039298
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FreeCommunityCollege",
        "indices" : [ 70, 91 ]
      }, {
        "text" : "HeadsUpAmerica",
        "indices" : [ 92, 107 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/QfimHx2fNl",
        "expanded_url" : "https:\/\/twitter.com\/LateNightSeth\/status\/659767835506405376",
        "display_url" : "twitter.com\/LateNightSeth\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "659815138283884544",
    "text" : "Looking forward to talking with @SethMeyers about one of my passions. #FreeCommunityCollege #HeadsUpAmerica \u2013Jill https:\/\/t.co\/QfimHx2fNl",
    "id" : 659815138283884544,
    "created_at" : "2015-10-29 19:32:42 +0000",
    "user" : {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "protected" : false,
      "id_str" : "1281405877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608687663034474496\/wvzVG_yt_normal.jpg",
      "id" : 1281405877,
      "verified" : true
    }
  },
  "id" : 659815270224015360,
  "created_at" : "2015-10-29 19:33:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DC Police Department",
      "screen_name" : "DCPoliceDept",
      "indices" : [ 3, 16 ],
      "id_str" : "285198536",
      "id" : 285198536
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 28, 34 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659795572321333248",
  "text" : "RT @DCPoliceDept: Thank you @POTUS engaging with residents thru dance is part of our dedicated community policing effort in the nation's ca\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 10, 16 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "659793021668597760",
    "text" : "Thank you @POTUS engaging with residents thru dance is part of our dedicated community policing effort in the nation's capital- Chief Lanier",
    "id" : 659793021668597760,
    "created_at" : "2015-10-29 18:04:49 +0000",
    "user" : {
      "name" : "DC Police Department",
      "screen_name" : "DCPoliceDept",
      "protected" : false,
      "id_str" : "285198536",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/555419605309476864\/4pU8PxV8_normal.jpeg",
      "id" : 285198536,
      "verified" : true
    }
  },
  "id" : 659795572321333248,
  "created_at" : "2015-10-29 18:14:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659776726466207744",
  "text" : "RT @POTUS: Who knew community policing could involve the Nae Nae? Great example of police having fun while keeping us safe: https:\/\/t.co\/ZG\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 136 ],
        "url" : "https:\/\/t.co\/ZGeTDm6OYw",
        "expanded_url" : "http:\/\/wapo.st\/1iia2cP",
        "display_url" : "wapo.st\/1iia2cP"
      } ]
    },
    "geo" : { },
    "id_str" : "659775465352249344",
    "text" : "Who knew community policing could involve the Nae Nae? Great example of police having fun while keeping us safe: https:\/\/t.co\/ZGeTDm6OYw",
    "id" : 659775465352249344,
    "created_at" : "2015-10-29 16:55:03 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 659776726466207744,
  "created_at" : "2015-10-29 17:00:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/659763034357956609\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/a1TZwcv7Ik",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSfy4AiWEAEgyLr.jpg",
      "id_str" : "659762914463715329",
      "id" : 659762914463715329,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSfy4AiWEAEgyLr.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/a1TZwcv7Ik"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/joHpczQkk2",
      "expanded_url" : "http:\/\/go.wh.gov\/pLHMUF",
      "display_url" : "go.wh.gov\/pLHMUF"
    } ]
  },
  "geo" : { },
  "id_str" : "659763034357956609",
  "text" : "See how we're making sure our communities are prepared for the impacts of climate change \u2192 https:\/\/t.co\/joHpczQkk2 https:\/\/t.co\/a1TZwcv7Ik",
  "id" : 659763034357956609,
  "created_at" : "2015-10-29 16:05:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Gates",
      "screen_name" : "BillGates",
      "indices" : [ 3, 13 ],
      "id_str" : "50393960",
      "id" : 50393960
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/77BYd4bR6l",
      "expanded_url" : "http:\/\/b-gat.es\/1WjxnYY",
      "display_url" : "b-gat.es\/1WjxnYY"
    } ]
  },
  "geo" : { },
  "id_str" : "659750454683934720",
  "text" : "RT @BillGates: How to make sure the world\u2019s climate-change fund helps the people who will be hit hardest: https:\/\/t.co\/77BYd4bR6l https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BillGates\/status\/659507413561815041\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/5NT825daJT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CScKf5HWIAAGjnB.png",
        "id_str" : "659507413456920576",
        "id" : 659507413456920576,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CScKf5HWIAAGjnB.png",
        "sizes" : [ {
          "h" : 296,
          "resize" : "fit",
          "w" : 601
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 296,
          "resize" : "fit",
          "w" : 601
        }, {
          "h" : 296,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 167,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/5NT825daJT"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/77BYd4bR6l",
        "expanded_url" : "http:\/\/b-gat.es\/1WjxnYY",
        "display_url" : "b-gat.es\/1WjxnYY"
      } ]
    },
    "geo" : { },
    "id_str" : "659507413561815041",
    "text" : "How to make sure the world\u2019s climate-change fund helps the people who will be hit hardest: https:\/\/t.co\/77BYd4bR6l https:\/\/t.co\/5NT825daJT",
    "id" : 659507413561815041,
    "created_at" : "2015-10-28 23:09:55 +0000",
    "user" : {
      "name" : "Bill Gates",
      "screen_name" : "BillGates",
      "protected" : false,
      "id_str" : "50393960",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/558109954561679360\/j1f9DiJi_normal.jpeg",
      "id" : 50393960,
      "verified" : true
    }
  },
  "id" : 659750454683934720,
  "created_at" : "2015-10-29 15:15:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/659549731757162496\/photo\/1",
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/lOL4RlA2Sy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CScwwV2WcAAZl7c.jpg",
      "id_str" : "659549477490028544",
      "id" : 659549477490028544,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CScwwV2WcAAZl7c.jpg",
      "sizes" : [ {
        "h" : 248,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 746,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 437,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 787,
        "resize" : "fit",
        "w" : 1080
      } ],
      "display_url" : "pic.twitter.com\/lOL4RlA2Sy"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659549731757162496",
  "text" : "Taking in the Bulls\/Cavs game with a couple of new friends. https:\/\/t.co\/lOL4RlA2Sy",
  "id" : 659549731757162496,
  "created_at" : "2015-10-29 01:58:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/659513707094024192\/photo\/1",
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/GPlyTrQcLG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CScQOKmUAAAGi9-.jpg",
      "id_str" : "659513705982328832",
      "id" : 659513705982328832,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CScQOKmUAAAGi9-.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1250,
        "resize" : "fit",
        "w" : 2500
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/GPlyTrQcLG"
    } ],
    "hashtags" : [ {
      "text" : "CriminalJusticeReform",
      "indices" : [ 41, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/9slXM8YtoE",
      "expanded_url" : "http:\/\/go.wh.gov\/FixTheSystem",
      "display_url" : "go.wh.gov\/FixTheSystem"
    } ]
  },
  "geo" : { },
  "id_str" : "659513707094024192",
  "text" : "Add your name if you agree it's time for #CriminalJusticeReform \u2192 https:\/\/t.co\/9slXM8YtoE https:\/\/t.co\/GPlyTrQcLG",
  "id" : 659513707094024192,
  "created_at" : "2015-10-28 23:34:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 87, 93 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StopGunViolence",
      "indices" : [ 94, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/5Primdcs4V",
      "expanded_url" : "http:\/\/bit.ly\/1Xxs76C",
      "display_url" : "bit.ly\/1Xxs76C"
    } ]
  },
  "geo" : { },
  "id_str" : "659507580734185472",
  "text" : "\"I'm going to keep calling on\u2026Congress to change the way they think about gun safety.\"\u2014@POTUS #StopGunViolence https:\/\/t.co\/5Primdcs4V",
  "id" : 659507580734185472,
  "created_at" : "2015-10-28 23:10:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/OafVnBKlfz",
      "expanded_url" : "http:\/\/www2.ed.gov\/about\/offices\/list\/ocr\/letters\/colleague-201010.html",
      "display_url" : "www2.ed.gov\/about\/offices\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "659491208042033152",
  "text" : "RT @vj44: All schools should have training for teachers to help end bullying in our schools. See here: https:\/\/t.co\/OafVnBKlfz https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/OafVnBKlfz",
        "expanded_url" : "http:\/\/www2.ed.gov\/about\/offices\/list\/ocr\/letters\/colleague-201010.html",
        "display_url" : "www2.ed.gov\/about\/offices\/\u2026"
      }, {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/jzqheq6Dlw",
        "expanded_url" : "https:\/\/twitter.com\/ADL_National\/status\/659478311547097088",
        "display_url" : "twitter.com\/ADL_National\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "659488145956847616",
    "text" : "All schools should have training for teachers to help end bullying in our schools. See here: https:\/\/t.co\/OafVnBKlfz https:\/\/t.co\/jzqheq6Dlw",
    "id" : 659488145956847616,
    "created_at" : "2015-10-28 21:53:21 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 659491208042033152,
  "created_at" : "2015-10-28 22:05:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StopBullying365",
      "indices" : [ 103, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659478252852002816",
  "text" : "RT @vj44: Starting soon - please join me in discussing how we can stop bullying. Send Q's and ideas to #StopBullying365",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "StopBullying365",
        "indices" : [ 93, 109 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "659477641716699136",
    "text" : "Starting soon - please join me in discussing how we can stop bullying. Send Q's and ideas to #StopBullying365",
    "id" : 659477641716699136,
    "created_at" : "2015-10-28 21:11:36 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 659478252852002816,
  "created_at" : "2015-10-28 21:14:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BatWeek",
      "indices" : [ 19, 27 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/5lqQUXlfbp",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/ef1c1e90-974b-41db-b470-5d79d02380b1",
      "display_url" : "amp.twimg.com\/v\/ef1c1e90-974\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "659465191684460545",
  "text" : "RT @Interior: It\u2019s #BatWeek: Don\u2019t be afraid! Learn more about these fascinating creatures.\nhttps:\/\/t.co\/5lqQUXlfbp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BatWeek",
        "indices" : [ 5, 13 ]
      } ],
      "urls" : [ {
        "indices" : [ 78, 101 ],
        "url" : "https:\/\/t.co\/5lqQUXlfbp",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/ef1c1e90-974b-41db-b470-5d79d02380b1",
        "display_url" : "amp.twimg.com\/v\/ef1c1e90-974\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "659429977813749764",
    "text" : "It\u2019s #BatWeek: Don\u2019t be afraid! Learn more about these fascinating creatures.\nhttps:\/\/t.co\/5lqQUXlfbp",
    "id" : 659429977813749764,
    "created_at" : "2015-10-28 18:02:12 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 659465191684460545,
  "created_at" : "2015-10-28 20:22:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/659433198817026048\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/0OcuEcPAeC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSbGyG5WsAAqDw4.jpg",
      "id_str" : "659432959603290112",
      "id" : 659432959603290112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSbGyG5WsAAqDw4.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/0OcuEcPAeC"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/B9dxCWuNTY",
      "expanded_url" : "http:\/\/go.wh.gov\/BudgetDeal",
      "display_url" : "go.wh.gov\/BudgetDeal"
    } ]
  },
  "geo" : { },
  "id_str" : "659433198817026048",
  "text" : "The bipartisan budget agreement is a major step forward for our economy.\nGet the details \u2192 https:\/\/t.co\/B9dxCWuNTY https:\/\/t.co\/0OcuEcPAeC",
  "id" : 659433198817026048,
  "created_at" : "2015-10-28 18:15:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 56, 61 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ItsOnUs",
      "indices" : [ 126, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/qXM3lKRH8b",
      "expanded_url" : "http:\/\/t.usnews.com\/Zekakk",
      "display_url" : "t.usnews.com\/Zekakk"
    } ]
  },
  "geo" : { },
  "id_str" : "659418251886129152",
  "text" : "\"1 in 5 women are sexually assaulted while at college\" \u2014@VJ44 on how we can help stop sexual assault: https:\/\/t.co\/qXM3lKRH8b #ItsOnUs",
  "id" : 659418251886129152,
  "created_at" : "2015-10-28 17:15:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/659390368891469824\/photo\/1",
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/6sF8XIWOhK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSaeTAoWsAA0htM.jpg",
      "id_str" : "659388444880318464",
      "id" : 659388444880318464,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSaeTAoWsAA0htM.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/6sF8XIWOhK"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 107 ],
      "url" : "https:\/\/t.co\/nLjsX1eiCj",
      "expanded_url" : "http:\/\/go.wh.gov\/HearingAids",
      "display_url" : "go.wh.gov\/HearingAids"
    } ]
  },
  "geo" : { },
  "id_str" : "659390368891469824",
  "text" : "Nearly 30 million older Americans suffer from hearing loss. Learn how we can help \u2192 https:\/\/t.co\/nLjsX1eiCj https:\/\/t.co\/6sF8XIWOhK",
  "id" : 659390368891469824,
  "created_at" : "2015-10-28 15:24:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/ctjvFu7h8t",
      "expanded_url" : "http:\/\/go.wh.gov\/t5Vi7E",
      "display_url" : "go.wh.gov\/t5Vi7E"
    }, {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/qsQKkwMJ2P",
      "expanded_url" : "http:\/\/bit.ly\/1RzRHUw",
      "display_url" : "bit.ly\/1RzRHUw"
    } ]
  },
  "geo" : { },
  "id_str" : "659377406000521216",
  "text" : "Watch @POTUS speak about how communities are using data to drive down crime \u2192 https:\/\/t.co\/ctjvFu7h8t https:\/\/t.co\/qsQKkwMJ2P",
  "id" : 659377406000521216,
  "created_at" : "2015-10-28 14:33:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernest Moniz",
      "screen_name" : "ErnestMoniz",
      "indices" : [ 3, 15 ],
      "id_str" : "1393155566",
      "id" : 1393155566
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ErnestMoniz\/status\/658753306261635072\/photo\/1",
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/QbH6FmRG9H",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSRcpC1W0AEsNLx.png",
      "id_str" : "658753305707991041",
      "id" : 658753305707991041,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSRcpC1W0AEsNLx.png",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 562,
        "resize" : "fit",
        "w" : 1124
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/QbH6FmRG9H"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 32, 45 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/xLyt7whDb9",
      "expanded_url" : "http:\/\/go.wh.gov\/ClimatePledge",
      "display_url" : "go.wh.gov\/ClimatePledge"
    } ]
  },
  "geo" : { },
  "id_str" : "659369600153337856",
  "text" : "RT @ErnestMoniz: When companies #ActOnClimate it's good for the planet AND for business: https:\/\/t.co\/xLyt7whDb9 https:\/\/t.co\/QbH6FmRG9H",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ErnestMoniz\/status\/658753306261635072\/photo\/1",
        "indices" : [ 96, 119 ],
        "url" : "https:\/\/t.co\/QbH6FmRG9H",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CSRcpC1W0AEsNLx.png",
        "id_str" : "658753305707991041",
        "id" : 658753305707991041,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSRcpC1W0AEsNLx.png",
        "sizes" : [ {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 562,
          "resize" : "fit",
          "w" : 1124
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/QbH6FmRG9H"
      } ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 15, 28 ]
      } ],
      "urls" : [ {
        "indices" : [ 72, 95 ],
        "url" : "https:\/\/t.co\/xLyt7whDb9",
        "expanded_url" : "http:\/\/go.wh.gov\/ClimatePledge",
        "display_url" : "go.wh.gov\/ClimatePledge"
      } ]
    },
    "geo" : { },
    "id_str" : "658753306261635072",
    "text" : "When companies #ActOnClimate it's good for the planet AND for business: https:\/\/t.co\/xLyt7whDb9 https:\/\/t.co\/QbH6FmRG9H",
    "id" : 658753306261635072,
    "created_at" : "2015-10-26 21:13:21 +0000",
    "user" : {
      "name" : "Ernest Moniz",
      "screen_name" : "ErnestMoniz",
      "protected" : false,
      "id_str" : "1393155566",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793425933113954305\/f5Mxv7BK_normal.jpg",
      "id" : 1393155566,
      "verified" : true
    }
  },
  "id" : 659369600153337856,
  "created_at" : "2015-10-28 14:02:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 93, 99 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StopGunViolence",
      "indices" : [ 100, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/PX4dpQVB8N",
      "expanded_url" : "http:\/\/bit.ly\/1jPiRfH",
      "display_url" : "bit.ly\/1jPiRfH"
    } ]
  },
  "geo" : { },
  "id_str" : "659175759408267264",
  "text" : "\"It's a simple proposition: Cops shouldn't be out-armed by the criminals they're pursuing.\" \u2014@POTUS #StopGunViolence https:\/\/t.co\/PX4dpQVB8N",
  "id" : 659175759408267264,
  "created_at" : "2015-10-28 01:12:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Abby Wambach",
      "screen_name" : "AbbyWambach",
      "indices" : [ 56, 68 ],
      "id_str" : "336124836",
      "id" : 336124836
    }, {
      "name" : "Carli Lloyd",
      "screen_name" : "CarliLloyd",
      "indices" : [ 70, 81 ],
      "id_str" : "110195330",
      "id" : 110195330
    }, {
      "name" : "Alex Morgan",
      "screen_name" : "alexmorgan13",
      "indices" : [ 83, 96 ],
      "id_str" : "28665877",
      "id" : 28665877
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 102, 108 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/g7txMqGlNJ",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/3c78b558-7d60-437d-a6f5-28335f53585f",
      "display_url" : "amp.twimg.com\/v\/3c78b558-7d6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "659175155818586112",
  "text" : "Play like a girl? It \"means you're a badass.\"\n\nJust ask @AbbyWambach, @CarliLloyd, @AlexMorgan13, and @POTUS.\nhttps:\/\/t.co\/g7txMqGlNJ",
  "id" : 659175155818586112,
  "created_at" : "2015-10-28 01:09:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chicago Bulls",
      "screen_name" : "chicagobulls",
      "indices" : [ 3, 16 ],
      "id_str" : "16212685",
      "id" : 16212685
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 42, 48 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/chicagobulls\/status\/659166932457934848\/photo\/1",
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/V1OsEoeVJB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSXU055WIAEBN-O.jpg",
      "id_str" : "659166925839278081",
      "id" : 659166925839278081,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSXU055WIAEBN-O.jpg",
      "sizes" : [ {
        "h" : 398,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/V1OsEoeVJB"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659167933977989120",
  "text" : "RT @chicagobulls: Welcome, Mr. President! @POTUS https:\/\/t.co\/V1OsEoeVJB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 24, 30 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/chicagobulls\/status\/659166932457934848\/photo\/1",
        "indices" : [ 31, 54 ],
        "url" : "https:\/\/t.co\/V1OsEoeVJB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CSXU055WIAEBN-O.jpg",
        "id_str" : "659166925839278081",
        "id" : 659166925839278081,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSXU055WIAEBN-O.jpg",
        "sizes" : [ {
          "h" : 398,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 680,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/V1OsEoeVJB"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "659166932457934848",
    "text" : "Welcome, Mr. President! @POTUS https:\/\/t.co\/V1OsEoeVJB",
    "id" : 659166932457934848,
    "created_at" : "2015-10-28 00:36:58 +0000",
    "user" : {
      "name" : "Chicago Bulls",
      "screen_name" : "chicagobulls",
      "protected" : false,
      "id_str" : "16212685",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/720996654459916288\/b1UOVsPt_normal.jpg",
      "id" : 16212685,
      "verified" : true
    }
  },
  "id" : 659167933977989120,
  "created_at" : "2015-10-28 00:40:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 73, 79 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StopGunViolence",
      "indices" : [ 80, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/5PrimcUQGl",
      "expanded_url" : "http:\/\/bit.ly\/1Xxs76C",
      "display_url" : "bit.ly\/1Xxs76C"
    } ]
  },
  "geo" : { },
  "id_str" : "659166467896705024",
  "text" : "\"Fewer gun safety laws don't mean more freedom, they mean more danger.\" \u2014@POTUS #StopGunViolence https:\/\/t.co\/5PrimcUQGl",
  "id" : 659166467896705024,
  "created_at" : "2015-10-28 00:35:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 69, 75 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StopGunViolence",
      "indices" : [ 76, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/oYpkYCprBy",
      "expanded_url" : "http:\/\/bit.ly\/1LAtQCO",
      "display_url" : "bit.ly\/1LAtQCO"
    } ]
  },
  "geo" : { },
  "id_str" : "659161644396769280",
  "text" : "\"More guns on the streets do not make you or your community safer.\" \u2014@POTUS #StopGunViolence https:\/\/t.co\/oYpkYCprBy",
  "id" : 659161644396769280,
  "created_at" : "2015-10-28 00:15:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StopBullying365",
      "indices" : [ 115, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659128852430651392",
  "text" : "RT @vj44: Join me tomorrow at 5:00 PM ET to share ideas on how we can stop bullying - tweet questions and ideas to #StopBullying365",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "StopBullying365",
        "indices" : [ 105, 121 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "659118519842246656",
    "text" : "Join me tomorrow at 5:00 PM ET to share ideas on how we can stop bullying - tweet questions and ideas to #StopBullying365",
    "id" : 659118519842246656,
    "created_at" : "2015-10-27 21:24:35 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 659128852430651392,
  "created_at" : "2015-10-27 22:05:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 81, 87 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StopGunViolence",
      "indices" : [ 88, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/PX4dpRdcxn",
      "expanded_url" : "http:\/\/bit.ly\/1jPiRfH",
      "display_url" : "bit.ly\/1jPiRfH"
    } ]
  },
  "geo" : { },
  "id_str" : "659112090045689856",
  "text" : "\"It is easier in some communities to find a gun than to find fresh vegetables.\" \u2014@POTUS #StopGunViolence https:\/\/t.co\/PX4dpRdcxn",
  "id" : 659112090045689856,
  "created_at" : "2015-10-27 20:59:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Abby Wambach",
      "screen_name" : "AbbyWambach",
      "indices" : [ 94, 106 ],
      "id_str" : "336124836",
      "id" : 336124836
    }, {
      "name" : "Christie Rampone",
      "screen_name" : "christierampone",
      "indices" : [ 107, 123 ],
      "id_str" : "105212657",
      "id" : 105212657
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659108249803751424",
  "text" : "RT @VP: Proud to be there when you won the World Cup &amp; when you brought it home to the WH @AbbyWambach @christierampone https:\/\/t.co\/2iF3eU\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Abby Wambach",
        "screen_name" : "AbbyWambach",
        "indices" : [ 86, 98 ],
        "id_str" : "336124836",
        "id" : 336124836
      }, {
        "name" : "Christie Rampone",
        "screen_name" : "christierampone",
        "indices" : [ 99, 115 ],
        "id_str" : "105212657",
        "id" : 105212657
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/659103118773362688\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/2iF3eUl7hP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CSWayiDXIAAszgT.jpg",
        "id_str" : "659103113404686336",
        "id" : 659103113404686336,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSWayiDXIAAszgT.jpg",
        "sizes" : [ {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/2iF3eUl7hP"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "659103118773362688",
    "text" : "Proud to be there when you won the World Cup &amp; when you brought it home to the WH @AbbyWambach @christierampone https:\/\/t.co\/2iF3eUl7hP",
    "id" : 659103118773362688,
    "created_at" : "2015-10-27 20:23:23 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 659108249803751424,
  "created_at" : "2015-10-27 20:43:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 96, 102 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "The IACP",
      "screen_name" : "TheIACP",
      "indices" : [ 106, 114 ],
      "id_str" : "44917831",
      "id" : 44917831
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CriminalJusticeReform",
      "indices" : [ 115, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659099475890302976",
  "text" : "\"Let\u2019s keep pushing our world in the right direction\u2014towards fairness and justice and safety.\" \u2014@POTUS to @TheIACP #CriminalJusticeReform",
  "id" : 659099475890302976,
  "created_at" : "2015-10-27 20:08:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/659098822568755200\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/IyUzOzW5dr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSWWhGXWcAAhG6Y.jpg",
      "id_str" : "659098415868047360",
      "id" : 659098415868047360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSWWhGXWcAAhG6Y.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/IyUzOzW5dr"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659098822568755200",
  "text" : "\"The goal we share is not just a country with falling crime rates...Our goal is a country with rising opportunity.\" https:\/\/t.co\/IyUzOzW5dr",
  "id" : 659098822568755200,
  "created_at" : "2015-10-27 20:06:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 134, 140 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659097860210827265",
  "text" : "\"Since 9\/11, fewer than 100 Americans have been murdered by terrorists on American soil.  400,000 have been killed by gun violence.\" \u2014@POTUS",
  "id" : 659097860210827265,
  "created_at" : "2015-10-27 20:02:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 124, 130 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659097483155476486",
  "text" : "\"We shouldn\u2019t sell military-style assault weapons to civilians. Cops shouldn\u2019t be out-armed by the criminals they pursue.\" \u2014@POTUS",
  "id" : 659097483155476486,
  "created_at" : "2015-10-27 20:01:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 97, 103 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StopGunViolence",
      "indices" : [ 104, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659097315597225984",
  "text" : "\"We should require national criminal background checks for anyone who wants to purchase a gun.\" \u2014@POTUS #StopGunViolence",
  "id" : 659097315597225984,
  "created_at" : "2015-10-27 20:00:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659096697306501120",
  "text" : "RT @WHLive: \"In states with high gun ownership police officers are three times more likely to be murdered than in states with low gun owner\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 134, 140 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "659096606394961924",
    "text" : "\"In states with high gun ownership police officers are three times more likely to be murdered than in states with low gun ownership\" \u2014@POTUS",
    "id" : 659096606394961924,
    "created_at" : "2015-10-27 19:57:31 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 659096697306501120,
  "created_at" : "2015-10-27 19:57:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 103, 109 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StopGunViolence",
      "indices" : [ 110, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659095845464350720",
  "text" : "\"We\u2019ve got to make it harder for criminals to cause chaos by getting their hands on deadly firearms.\" \u2014@POTUS #StopGunViolence",
  "id" : 659095845464350720,
  "created_at" : "2015-10-27 19:54:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 73, 79 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CriminalJusticeReform",
      "indices" : [ 102, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659095427703316480",
  "text" : "\"The goal is to get the community involved before a crime takes place.\" \u2014@POTUS on community policing #CriminalJusticeReform",
  "id" : 659095427703316480,
  "created_at" : "2015-10-27 19:52:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 124, 130 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659093027336638464",
  "text" : "RT @WHLive: \"We\u2019ve still got work to do to restore trust between law enforcement and the citizens they protect and serve.\" \u2014@POTUS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 112, 118 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "659092932071419904",
    "text" : "\"We\u2019ve still got work to do to restore trust between law enforcement and the citizens they protect and serve.\" \u2014@POTUS",
    "id" : 659092932071419904,
    "created_at" : "2015-10-27 19:42:55 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 659093027336638464,
  "created_at" : "2015-10-27 19:43:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 98, 104 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CriminalJusticeReform",
      "indices" : [ 108, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659092705457369089",
  "text" : "\"I am encouraged by what Congress is doing. I hope they get a bill to my desk so I can sign it.\" \u2014@POTUS on #CriminalJusticeReform",
  "id" : 659092705457369089,
  "created_at" : "2015-10-27 19:42:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 105, 111 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/659091654226366465\/photo\/1",
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/4CYbC6kqnw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSWQWPqXAAACOYs.jpg",
      "id_str" : "659091632315367424",
      "id" : 659091632315367424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSWQWPqXAAACOYs.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1250,
        "resize" : "fit",
        "w" : 2500
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/4CYbC6kqnw"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659091654226366465",
  "text" : "\"For those who do break the law, we should take another look at whether the punishment fits the crime.\" \u2014@POTUS https:\/\/t.co\/4CYbC6kqnw",
  "id" : 659091654226366465,
  "created_at" : "2015-10-27 19:37:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/659091414907822080\/photo\/1",
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/UUKCMhjEuK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSWQGuVXAAA5v30.jpg",
      "id_str" : "659091365670879232",
      "id" : 659091365670879232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSWQGuVXAAA5v30.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1250,
        "resize" : "fit",
        "w" : 2500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/UUKCMhjEuK"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659091414907822080",
  "text" : "\"Let\u2019s invest in more opportunity... stop crime before it starts... go after racial disparities at the root.\" https:\/\/t.co\/UUKCMhjEuK",
  "id" : 659091414907822080,
  "created_at" : "2015-10-27 19:36:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/659090336778711040\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/KSplheare2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSWPDKZWwAAAm03.jpg",
      "id_str" : "659090204972728320",
      "id" : 659090204972728320,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSWPDKZWwAAAm03.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/KSplheare2"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659090336778711040",
  "text" : "\"Democrats and Republicans in Congress came together around a long-term budget agreement...It reflects our values.\" https:\/\/t.co\/KSplheare2",
  "id" : 659090336778711040,
  "created_at" : "2015-10-27 19:32:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 94, 100 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Simas44\/status\/659089894019616769\/photo\/1",
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/ERXcEPsDwc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSWOxDdWIAA-FuA.jpg",
      "id_str" : "659089893872771072",
      "id" : 659089893872771072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSWOxDdWIAA-FuA.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/ERXcEPsDwc"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659090017193697280",
  "text" : "RT @Simas44: \"Let's focus on common sense gun safety reforms that keep police officers safe.\" @POTUS https:\/\/t.co\/ERXcEPsDwc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 81, 87 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Simas44\/status\/659089894019616769\/photo\/1",
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/ERXcEPsDwc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CSWOxDdWIAA-FuA.jpg",
        "id_str" : "659089893872771072",
        "id" : 659089893872771072,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSWOxDdWIAA-FuA.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/ERXcEPsDwc"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "659089894019616769",
    "text" : "\"Let's focus on common sense gun safety reforms that keep police officers safe.\" @POTUS https:\/\/t.co\/ERXcEPsDwc",
    "id" : 659089894019616769,
    "created_at" : "2015-10-27 19:30:50 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 659090017193697280,
  "created_at" : "2015-10-27 19:31:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 87, 93 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CriminalJusticeReform",
      "indices" : [ 94, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659089738247372802",
  "text" : "\"We need to start by supporting you, the men and women who walk that thin blue line.\" \u2014@POTUS #CriminalJusticeReform",
  "id" : 659089738247372802,
  "created_at" : "2015-10-27 19:30:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 116, 122 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659089508596498432",
  "text" : "\"I\u2019ve spent a lot of time this year with people of all backgrounds working to reform our criminal justice system.\" \u2014@POTUS",
  "id" : 659089508596498432,
  "created_at" : "2015-10-27 19:29:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 85, 91 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "The IACP",
      "screen_name" : "TheIACP",
      "indices" : [ 95, 103 ],
      "id_str" : "44917831",
      "id" : 44917831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659086851404406785",
  "text" : "\"You serve and protect to provide the security so many Americans take for granted.\" \u2014@POTUS to @TheIACP and police across the country",
  "id" : 659086851404406785,
  "created_at" : "2015-10-27 19:18:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "The IACP",
      "screen_name" : "TheIACP",
      "indices" : [ 23, 31 ],
      "id_str" : "44917831",
      "id" : 44917831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/mOM3jz3IDQ",
      "expanded_url" : "http:\/\/go.wh.gov\/1ZAwgL",
      "display_url" : "go.wh.gov\/1ZAwgL"
    } ]
  },
  "geo" : { },
  "id_str" : "659086315573477376",
  "text" : "Watch @POTUS talk with @TheIACP and police chiefs from across the country in Chicago: https:\/\/t.co\/mOM3jz3IDQ",
  "id" : 659086315573477376,
  "created_at" : "2015-10-27 19:16:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/659062251253575680\/photo\/1",
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/4pmkkz2Hr0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSV1moyWEAAafUc.jpg",
      "id_str" : "659062227123703808",
      "id" : 659062227123703808,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSV1moyWEAAafUc.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/4pmkkz2Hr0"
    } ],
    "hashtags" : [ {
      "text" : "BudgetDeal",
      "indices" : [ 36, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/B9dxCWuNTY",
      "expanded_url" : "http:\/\/go.wh.gov\/BudgetDeal",
      "display_url" : "go.wh.gov\/BudgetDeal"
    } ]
  },
  "geo" : { },
  "id_str" : "659062251253575680",
  "text" : "Get the facts on today's bipartisan #BudgetDeal \u2192 https:\/\/t.co\/B9dxCWuNTY https:\/\/t.co\/4pmkkz2Hr0",
  "id" : 659062251253575680,
  "created_at" : "2015-10-27 17:41:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "indices" : [ 3, 15 ],
      "id_str" : "15764644",
      "id" : 15764644
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659040734339866624",
  "text" : "RT @NancyPelosi: Bipartisan budget package represents real progress. We look forward to working toward  passage this week. \u2192 https:\/\/t.co\/C\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/CY7m8Mbe0q",
        "expanded_url" : "http:\/\/goo.gl\/0BXrdg",
        "display_url" : "goo.gl\/0BXrdg"
      } ]
    },
    "geo" : { },
    "id_str" : "658987143210082306",
    "text" : "Bipartisan budget package represents real progress. We look forward to working toward  passage this week. \u2192 https:\/\/t.co\/CY7m8Mbe0q",
    "id" : 658987143210082306,
    "created_at" : "2015-10-27 12:42:32 +0000",
    "user" : {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "protected" : false,
      "id_str" : "15764644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/571313158510223360\/wnSl3yXF_normal.jpeg",
      "id" : 15764644,
      "verified" : true
    }
  },
  "id" : 659040734339866624,
  "created_at" : "2015-10-27 16:15:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Senator Harry Reid",
      "screen_name" : "SenatorReid",
      "indices" : [ 3, 15 ],
      "id_str" : "16789970",
      "id" : 16789970
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659038889903005697",
  "text" : "RT @SenatorReid: Democrats have long called for stopping sequester cuts from hitting our military and middle class. With this agreement, we\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.twitter.com\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "658992907630854144",
    "text" : "Democrats have long called for stopping sequester cuts from hitting our military and middle class. With this agreement, we\u2019ve done that.",
    "id" : 658992907630854144,
    "created_at" : "2015-10-27 13:05:27 +0000",
    "user" : {
      "name" : "Senator Harry Reid",
      "screen_name" : "SenatorReid",
      "protected" : false,
      "id_str" : "16789970",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/628307865065816064\/OUQh91yr_normal.jpg",
      "id" : 16789970,
      "verified" : true
    }
  },
  "id" : 659038889903005697,
  "created_at" : "2015-10-27 16:08:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 96, 102 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "U.S. Soccer WNT",
      "screen_name" : "ussoccer_wnt",
      "indices" : [ 110, 123 ],
      "id_str" : "133448051",
      "id" : 133448051
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SheBelieves",
      "indices" : [ 124, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659031062471929856",
  "text" : "\"This team taught all of America\u2019s children that \u201Cplaying like a girl\u201D means you're a badass.\" \u2014@POTUS on the @USSoccer_WNT #SheBelieves",
  "id" : 659031062471929856,
  "created_at" : "2015-10-27 15:37:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 117, 123 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "U.S. Soccer WNT",
      "screen_name" : "ussoccer_wnt",
      "indices" : [ 127, 140 ],
      "id_str" : "133448051",
      "id" : 133448051
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659030632916500480",
  "text" : "\"This victory was about more than just soccer. It was about dominance, and skill, and inspiring our whole country.\" \u2014@POTUS on @USSoccer_WNT",
  "id" : 659030632916500480,
  "created_at" : "2015-10-27 15:35:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 103, 109 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/659028922856775680\/photo\/1",
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/RPspqGfuwg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSVXFVoWUAAD4NP.jpg",
      "id_str" : "659028669696987136",
      "id" : 659028669696987136,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSVXFVoWUAAD4NP.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 699,
        "resize" : "fit",
        "w" : 540
      }, {
        "h" : 699,
        "resize" : "fit",
        "w" : 540
      }, {
        "h" : 440,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 699,
        "resize" : "fit",
        "w" : 540
      } ],
      "display_url" : "pic.twitter.com\/RPspqGfuwg"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659028922856775680",
  "text" : "\"Nothing gives me more hope than knowing that we\u2019ve got a whole generation of young women like Ayla.\" \u2014@POTUS: https:\/\/t.co\/RPspqGfuwg",
  "id" : 659028922856775680,
  "created_at" : "2015-10-27 15:28:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 3, 11 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 19, 25 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "U.S. Soccer WNT",
      "screen_name" : "ussoccer_wnt",
      "indices" : [ 57, 70 ],
      "id_str" : "133448051",
      "id" : 133448051
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 78, 89 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SheBelieves",
      "indices" : [ 116, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/yfL84roHzq",
      "expanded_url" : "http:\/\/go.wh.gov\/MutH8T",
      "display_url" : "go.wh.gov\/MutH8T"
    } ]
  },
  "geo" : { },
  "id_str" : "659028307619500032",
  "text" : "RT @DrBiden: Watch @POTUS welcome the World Cup champion @ussoccer_wnt to the @WhiteHouse \u2192 https:\/\/t.co\/yfL84roHzq #SheBelieves https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 6, 12 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "U.S. Soccer WNT",
        "screen_name" : "ussoccer_wnt",
        "indices" : [ 44, 57 ],
        "id_str" : "133448051",
        "id" : 133448051
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 65, 76 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DrBiden\/status\/659027914319601664\/photo\/1",
        "indices" : [ 116, 139 ],
        "url" : "https:\/\/t.co\/CbqqV0PkXX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CSVWZQHVAAATjgH.jpg",
        "id_str" : "659027912302067712",
        "id" : 659027912302067712,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSVWZQHVAAATjgH.jpg",
        "sizes" : [ {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/CbqqV0PkXX"
      } ],
      "hashtags" : [ {
        "text" : "SheBelieves",
        "indices" : [ 103, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 79, 102 ],
        "url" : "https:\/\/t.co\/yfL84roHzq",
        "expanded_url" : "http:\/\/go.wh.gov\/MutH8T",
        "display_url" : "go.wh.gov\/MutH8T"
      } ]
    },
    "geo" : { },
    "id_str" : "659027914319601664",
    "text" : "Watch @POTUS welcome the World Cup champion @ussoccer_wnt to the @WhiteHouse \u2192 https:\/\/t.co\/yfL84roHzq #SheBelieves https:\/\/t.co\/CbqqV0PkXX",
    "id" : 659027914319601664,
    "created_at" : "2015-10-27 15:24:33 +0000",
    "user" : {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "protected" : false,
      "id_str" : "1281405877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608687663034474496\/wvzVG_yt_normal.jpg",
      "id" : 1281405877,
      "verified" : true
    }
  },
  "id" : 659028307619500032,
  "created_at" : "2015-10-27 15:26:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 15, 21 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "U.S. Soccer WNT",
      "screen_name" : "ussoccer_wnt",
      "indices" : [ 54, 67 ],
      "id_str" : "133448051",
      "id" : 133448051
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/gtjlYQmRWJ",
      "expanded_url" : "http:\/\/go.wh.gov\/MutH8T",
      "display_url" : "go.wh.gov\/MutH8T"
    } ]
  },
  "geo" : { },
  "id_str" : "659027859902767104",
  "text" : "Happening now: @POTUS welcomes the World Cup champion @USSoccer_WNT to the White House: https:\/\/t.co\/gtjlYQmRWJ",
  "id" : 659027859902767104,
  "created_at" : "2015-10-27 15:24:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/659027410113994753\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/EzYaNxaU7W",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSVU_C7UAAAHotv.jpg",
      "id_str" : "659026362573783040",
      "id" : 659026362573783040,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSVU_C7UAAAHotv.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/EzYaNxaU7W"
    } ],
    "hashtags" : [ {
      "text" : "BudgetDeal",
      "indices" : [ 42, 53 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/B9dxCWuNTY",
      "expanded_url" : "http:\/\/go.wh.gov\/BudgetDeal",
      "display_url" : "go.wh.gov\/BudgetDeal"
    } ]
  },
  "geo" : { },
  "id_str" : "659027410113994753",
  "text" : "RT to spread the word: Today's bipartisan #BudgetDeal will add jobs and boost our economy \u2192 https:\/\/t.co\/B9dxCWuNTY https:\/\/t.co\/EzYaNxaU7W",
  "id" : 659027410113994753,
  "created_at" : "2015-10-27 15:22:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 33, 39 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "U.S. Soccer WNT",
      "screen_name" : "ussoccer_wnt",
      "indices" : [ 76, 89 ],
      "id_str" : "133448051",
      "id" : 133448051
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/659019809590525952\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/CTOAKWx1Oj",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSVO8uGXIAAl-YK.jpg",
      "id_str" : "659019725553475584",
      "id" : 659019725553475584,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSVO8uGXIAAl-YK.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 699,
        "resize" : "fit",
        "w" : 540
      }, {
        "h" : 699,
        "resize" : "fit",
        "w" : 540
      }, {
        "h" : 440,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 699,
        "resize" : "fit",
        "w" : 540
      } ],
      "display_url" : "pic.twitter.com\/CTOAKWx1Oj"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/gtjlYQmRWJ",
      "expanded_url" : "http:\/\/go.wh.gov\/MutH8T",
      "display_url" : "go.wh.gov\/MutH8T"
    } ]
  },
  "geo" : { },
  "id_str" : "659019809590525952",
  "text" : "Watch 13-year-old Ayla introduce @POTUS and congratulate World Cup champion @USSoccer_WNT: https:\/\/t.co\/gtjlYQmRWJ https:\/\/t.co\/CTOAKWx1Oj",
  "id" : 659019809590525952,
  "created_at" : "2015-10-27 14:52:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "U.S. Soccer WNT",
      "screen_name" : "ussoccer_wnt",
      "indices" : [ 41, 54 ],
      "id_str" : "133448051",
      "id" : 133448051
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659014078447403008",
  "text" : "RT @VP: Looking forward to welcoming the @ussoccer_wnt to the White House today to celebrate their victory in the 2015 World Cup",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "U.S. Soccer WNT",
        "screen_name" : "ussoccer_wnt",
        "indices" : [ 33, 46 ],
        "id_str" : "133448051",
        "id" : 133448051
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "659013830786359296",
    "text" : "Looking forward to welcoming the @ussoccer_wnt to the White House today to celebrate their victory in the 2015 World Cup",
    "id" : 659013830786359296,
    "created_at" : "2015-10-27 14:28:35 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 659014078447403008,
  "created_at" : "2015-10-27 14:29:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Soccer WNT",
      "screen_name" : "ussoccer_wnt",
      "indices" : [ 3, 16 ],
      "id_str" : "133448051",
      "id" : 133448051
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 76, 87 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/ussoccer_wnt\/status\/658995316788756480\/photo\/1",
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/1fPqPdYmFR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSU4p8wWEAAwYiQ.jpg",
      "id_str" : "658995213814337536",
      "id" : 658995213814337536,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSU4p8wWEAAwYiQ.jpg",
      "sizes" : [ {
        "h" : 241,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 425,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 725,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 725,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/1fPqPdYmFR"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/ussoccer_wnt\/status\/658995316788756480\/photo\/1",
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/1fPqPdYmFR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSU4p92WcAQn_WI.jpg",
      "id_str" : "658995214107963396",
      "id" : 658995214107963396,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSU4p92WcAQn_WI.jpg",
      "sizes" : [ {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/1fPqPdYmFR"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/ussoccer_wnt\/status\/658995316788756480\/photo\/1",
      "indices" : [ 97, 120 ],
      "url" : "https:\/\/t.co\/1fPqPdYmFR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSU4p_2WUAAHQ9S.jpg",
      "id_str" : "658995214644826112",
      "id" : 658995214644826112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSU4p_2WUAAHQ9S.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/1fPqPdYmFR"
    } ],
    "hashtags" : [ {
      "text" : "WNTatWH",
      "indices" : [ 88, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "659000207900868608",
  "text" : "RT @ussoccer_wnt: Good morning, D.C., guess where we are? That's right, the @WhiteHouse!#WNTatWH https:\/\/t.co\/1fPqPdYmFR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 58, 69 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/ussoccer_wnt\/status\/658995316788756480\/photo\/1",
        "indices" : [ 79, 102 ],
        "url" : "https:\/\/t.co\/1fPqPdYmFR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CSU4p8wWEAAwYiQ.jpg",
        "id_str" : "658995213814337536",
        "id" : 658995213814337536,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSU4p8wWEAAwYiQ.jpg",
        "sizes" : [ {
          "h" : 241,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 425,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 725,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 725,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/1fPqPdYmFR"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/ussoccer_wnt\/status\/658995316788756480\/photo\/1",
        "indices" : [ 79, 102 ],
        "url" : "https:\/\/t.co\/1fPqPdYmFR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CSU4p92WcAQn_WI.jpg",
        "id_str" : "658995214107963396",
        "id" : 658995214107963396,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSU4p92WcAQn_WI.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/1fPqPdYmFR"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/ussoccer_wnt\/status\/658995316788756480\/photo\/1",
        "indices" : [ 79, 102 ],
        "url" : "https:\/\/t.co\/1fPqPdYmFR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CSU4p_2WUAAHQ9S.jpg",
        "id_str" : "658995214644826112",
        "id" : 658995214644826112,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSU4p_2WUAAHQ9S.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/1fPqPdYmFR"
      } ],
      "hashtags" : [ {
        "text" : "WNTatWH",
        "indices" : [ 70, 78 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "658995316788756480",
    "text" : "Good morning, D.C., guess where we are? That's right, the @WhiteHouse!#WNTatWH https:\/\/t.co\/1fPqPdYmFR",
    "id" : 658995316788756480,
    "created_at" : "2015-10-27 13:15:01 +0000",
    "user" : {
      "name" : "U.S. Soccer WNT",
      "screen_name" : "ussoccer_wnt",
      "protected" : false,
      "id_str" : "133448051",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/704351258082091008\/xp8Z6Hwo_normal.jpg",
      "id" : 133448051,
      "verified" : true
    }
  },
  "id" : 659000207900868608,
  "created_at" : "2015-10-27 13:34:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CleanPowerPlan",
      "indices" : [ 99, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/knl0MOnPuy",
      "expanded_url" : "http:\/\/go.wh.gov\/CleanPowerPlan",
      "display_url" : "go.wh.gov\/CleanPowerPlan"
    } ]
  },
  "geo" : { },
  "id_str" : "658799033947820032",
  "text" : "FACT: The average American family will save nearly $85 on their energy bills in 2030 thanks to the #CleanPowerPlan \u2192 https:\/\/t.co\/knl0MOnPuy",
  "id" : 658799033947820032,
  "created_at" : "2015-10-27 00:15:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 17, 23 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/658779646809546752\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/2jyB4X98ZK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSR0HziUsAEtMtP.jpg",
      "id_str" : "658779122945011713",
      "id" : 658779122945011713,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSR0HziUsAEtMtP.jpg",
      "sizes" : [ {
        "h" : 733,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/2jyB4X98ZK"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/WUZkcYpfRT",
      "expanded_url" : "http:\/\/go.wh.gov\/MJwq2W",
      "display_url" : "go.wh.gov\/MJwq2W"
    } ]
  },
  "geo" : { },
  "id_str" : "658779646809546752",
  "text" : "Open letter from @POTUS to America's parents and teachers:\nLet's make our testing smarter \u2192 https:\/\/t.co\/WUZkcYpfRT https:\/\/t.co\/2jyB4X98ZK",
  "id" : 658779646809546752,
  "created_at" : "2015-10-26 22:58:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "indices" : [ 3, 18 ],
      "id_str" : "3907577966",
      "id" : 3907577966
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CleanPowerPlan",
      "indices" : [ 46, 61 ]
    }, {
      "text" : "ActOnClimate",
      "indices" : [ 112, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 111 ],
      "url" : "https:\/\/t.co\/LVUvjg1OIG",
      "expanded_url" : "http:\/\/go.wh.gov\/CPP",
      "display_url" : "go.wh.gov\/CPP"
    } ]
  },
  "geo" : { },
  "id_str" : "658736544291889152",
  "text" : "RT @FactsOnClimate: See how President Obama's #CleanPowerPlan will benefit your state \u2192 https:\/\/t.co\/LVUvjg1OIG #ActOnClimate https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FactsOnClimate\/status\/658736328608227328\/photo\/1",
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/qvu0LJ72pO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CSRNEaTWoAIVgRN.jpg",
        "id_str" : "658736183678246914",
        "id" : 658736183678246914,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSRNEaTWoAIVgRN.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1250,
          "resize" : "fit",
          "w" : 2500
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/qvu0LJ72pO"
      } ],
      "hashtags" : [ {
        "text" : "CleanPowerPlan",
        "indices" : [ 26, 41 ]
      }, {
        "text" : "ActOnClimate",
        "indices" : [ 92, 105 ]
      } ],
      "urls" : [ {
        "indices" : [ 68, 91 ],
        "url" : "https:\/\/t.co\/LVUvjg1OIG",
        "expanded_url" : "http:\/\/go.wh.gov\/CPP",
        "display_url" : "go.wh.gov\/CPP"
      } ]
    },
    "in_reply_to_status_id_str" : "658735606554587136",
    "geo" : { },
    "id_str" : "658736328608227328",
    "in_reply_to_user_id" : 3907577966,
    "text" : "See how President Obama's #CleanPowerPlan will benefit your state \u2192 https:\/\/t.co\/LVUvjg1OIG #ActOnClimate https:\/\/t.co\/qvu0LJ72pO",
    "id" : 658736328608227328,
    "in_reply_to_status_id" : 658735606554587136,
    "created_at" : "2015-10-26 20:05:54 +0000",
    "in_reply_to_screen_name" : "FactsOnClimate",
    "in_reply_to_user_id_str" : "3907577966",
    "user" : {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "protected" : false,
      "id_str" : "3907577966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656492463880802306\/FhWzWlVs_normal.jpg",
      "id" : 3907577966,
      "verified" : true
    }
  },
  "id" : 658736544291889152,
  "created_at" : "2015-10-26 20:06:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/658706997743890432\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/lhYLlYtyUq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSQx9HSW0AARPVi.jpg",
      "id_str" : "658706371500756992",
      "id" : 658706371500756992,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSQx9HSW0AARPVi.jpg",
      "sizes" : [ {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/lhYLlYtyUq"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/LAt5QH6lGC",
      "expanded_url" : "http:\/\/go.wh.gov\/38oWWs",
      "display_url" : "go.wh.gov\/38oWWs"
    } ]
  },
  "geo" : { },
  "id_str" : "658706997743890432",
  "text" : "It's time for Republicans in Congress to reauthorize the Land and Water Conservation Fund \u2192 https:\/\/t.co\/LAt5QH6lGC https:\/\/t.co\/lhYLlYtyUq",
  "id" : 658706997743890432,
  "created_at" : "2015-10-26 18:09:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PCAST",
      "indices" : [ 36, 42 ]
    }, {
      "text" : "innovation",
      "indices" : [ 90, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "658681448073928704",
  "text" : "RT @whitehouseostp: The President's #PCAST just released a new letter report on promoting #innovation in hearing tech. Check it out! \u2192 http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PCAST",
        "indices" : [ 16, 22 ]
      }, {
        "text" : "innovation",
        "indices" : [ 70, 81 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/V5WV6cqjXK",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/blog\/2015\/10\/26\/%E2%80%8Bpcast-recommends-changes-promote-innovation-hearing-technologies",
        "display_url" : "whitehouse.gov\/blog\/2015\/10\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "658680298239082497",
    "text" : "The President's #PCAST just released a new letter report on promoting #innovation in hearing tech. Check it out! \u2192 https:\/\/t.co\/V5WV6cqjXK",
    "id" : 658680298239082497,
    "created_at" : "2015-10-26 16:23:15 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 658681448073928704,
  "created_at" : "2015-10-26 16:27:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 144 ],
      "url" : "https:\/\/t.co\/xBfPWbNCTo",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/cf2c1946-bba0-491a-a44b-3cf201a844fd",
      "display_url" : "amp.twimg.com\/v\/cf2c1946-bba\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "658668678813085696",
  "text" : ".@POTUS has a pop quiz for parents &amp; teachers.\nWatch him share smarter ways to measure our kids' progress in school.\nhttps:\/\/t.co\/xBfPWbNCTo",
  "id" : 658668678813085696,
  "created_at" : "2015-10-26 15:37:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 99, 105 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/n1XODpjX70",
      "expanded_url" : "http:\/\/go.wh.gov\/eGhv3H",
      "display_url" : "go.wh.gov\/eGhv3H"
    } ]
  },
  "geo" : { },
  "id_str" : "658399642049052672",
  "text" : "\"Republicans in Congress should reauthorize and fully fund the Land and Water Conservation Fund.\" \u2014@POTUS: https:\/\/t.co\/n1XODpjX70",
  "id" : 658399642049052672,
  "created_at" : "2015-10-25 21:48:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 116, 122 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 124, 147 ],
      "url" : "https:\/\/t.co\/KqF05nWUkv",
      "expanded_url" : "http:\/\/on.fb.me\/1Wb9O4D",
      "display_url" : "on.fb.me\/1Wb9O4D"
    } ]
  },
  "geo" : { },
  "id_str" : "658385070269464576",
  "text" : "\"Tests should be just one source of information, used alongside classroom work &amp; surveys &amp; other factors.\" \u2014@POTUS: https:\/\/t.co\/KqF05nWUkv",
  "id" : 658385070269464576,
  "created_at" : "2015-10-25 20:50:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 99, 105 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/n1XODpjX70",
      "expanded_url" : "http:\/\/go.wh.gov\/eGhv3H",
      "display_url" : "go.wh.gov\/eGhv3H"
    } ]
  },
  "geo" : { },
  "id_str" : "658369445035835392",
  "text" : "\"The world needs to come together...with an ambitious, long-term agreement to protect this Earth\" \u2014@POTUS: https:\/\/t.co\/n1XODpjX70",
  "id" : 658369445035835392,
  "created_at" : "2015-10-25 19:48:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 47, 53 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/KqF05nWUkv",
      "expanded_url" : "http:\/\/on.fb.me\/1Wb9O4D",
      "display_url" : "on.fb.me\/1Wb9O4D"
    } ]
  },
  "geo" : { },
  "id_str" : "658354860182515713",
  "text" : "\"Tests should enhance teaching and learning.\" \u2014@POTUS: https:\/\/t.co\/KqF05nWUkv",
  "id" : 658354860182515713,
  "created_at" : "2015-10-25 18:50:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/n1XODpjX70",
      "expanded_url" : "http:\/\/go.wh.gov\/eGhv3H",
      "display_url" : "go.wh.gov\/eGhv3H"
    } ]
  },
  "geo" : { },
  "id_str" : "658338998054617089",
  "text" : "\"150 countries representing over 85% of global emissions have now laid out plans to reduce their levels of...carbon\" https:\/\/t.co\/n1XODpjX70",
  "id" : 658338998054617089,
  "created_at" : "2015-10-25 17:47:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 87, 93 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/KqF05nWUkv",
      "expanded_url" : "http:\/\/on.fb.me\/1Wb9O4D",
      "display_url" : "on.fb.me\/1Wb9O4D"
    } ]
  },
  "geo" : { },
  "id_str" : "658324408562388992",
  "text" : "\"Tests shouldn\u2019t occupy too much classroom time, or crowd out teaching and learning.\" \u2014@POTUS: https:\/\/t.co\/KqF05nWUkv",
  "id" : 658324408562388992,
  "created_at" : "2015-10-25 16:49:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 106, 112 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 55, 68 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/n1XODp2mfs",
      "expanded_url" : "http:\/\/go.wh.gov\/eGhv3H",
      "display_url" : "go.wh.gov\/eGhv3H"
    } ]
  },
  "geo" : { },
  "id_str" : "658308948257320960",
  "text" : "\"Some of our biggest companies made new commitments to #ActOnClimate...it\u2019s good for their bottom line.\" \u2014@POTUS: https:\/\/t.co\/n1XODp2mfs",
  "id" : 658308948257320960,
  "created_at" : "2015-10-25 15:47:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 113, 119 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 144 ],
      "url" : "https:\/\/t.co\/n1XODpjX70",
      "expanded_url" : "http:\/\/go.wh.gov\/eGhv3H",
      "display_url" : "go.wh.gov\/eGhv3H"
    } ]
  },
  "geo" : { },
  "id_str" : "658051621436325888",
  "text" : "\"Over the past 6 years, we\u2019ve led by example, generating more clean energy &amp; lowering our carbon emissions\" \u2014@POTUS: https:\/\/t.co\/n1XODpjX70",
  "id" : 658051621436325888,
  "created_at" : "2015-10-24 22:45:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/n1XODpjX70",
      "expanded_url" : "http:\/\/go.wh.gov\/eGhv3H",
      "display_url" : "go.wh.gov\/eGhv3H"
    } ]
  },
  "geo" : { },
  "id_str" : "658036529600684036",
  "text" : "\"I\u2019m going to keep protecting the places that make America special, and the livelihoods of those who depend on them\" https:\/\/t.co\/n1XODpjX70",
  "id" : 658036529600684036,
  "created_at" : "2015-10-24 21:45:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 109, 115 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/n1XODpjX70",
      "expanded_url" : "http:\/\/go.wh.gov\/eGhv3H",
      "display_url" : "go.wh.gov\/eGhv3H"
    } ]
  },
  "geo" : { },
  "id_str" : "658021423286321152",
  "text" : "\"I\u2019ve set aside more than 260 million acres of public lands and waters\u2014more than any President in history.\" \u2014@POTUS: https:\/\/t.co\/n1XODpjX70",
  "id" : 658021423286321152,
  "created_at" : "2015-10-24 20:45:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 73, 79 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/KqF05nWUkv",
      "expanded_url" : "http:\/\/on.fb.me\/1Wb9O4D",
      "display_url" : "on.fb.me\/1Wb9O4D"
    } ]
  },
  "geo" : { },
  "id_str" : "658006310776995840",
  "text" : "\"Learning is about so much more than just filling in the right bubble.\" \u2014@POTUS: https:\/\/t.co\/KqF05nWUkv",
  "id" : 658006310776995840,
  "created_at" : "2015-10-24 19:45:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 83, 89 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/657991223504859136\/photo\/1",
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/oVXVhv62R2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CSGdK4AWEAAstRs.jpg",
      "id_str" : "657979830730887168",
      "id" : 657979830730887168,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CSGdK4AWEAAstRs.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1867,
        "resize" : "fit",
        "w" : 2800
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/oVXVhv62R2"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/n1XODpjX70",
      "expanded_url" : "http:\/\/go.wh.gov\/eGhv3H",
      "display_url" : "go.wh.gov\/eGhv3H"
    } ]
  },
  "geo" : { },
  "id_str" : "657991223504859136",
  "text" : "\"We\u2019re blessed with natural treasures\u2014from the Grand Tetons to the Grand Canyon.\" \u2014@POTUS: https:\/\/t.co\/n1XODpjX70 https:\/\/t.co\/oVXVhv62R2",
  "id" : 657991223504859136,
  "created_at" : "2015-10-24 18:45:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 86, 92 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/KqF05nWUkv",
      "expanded_url" : "http:\/\/on.fb.me\/1Wb9O4D",
      "display_url" : "on.fb.me\/1Wb9O4D"
    } ]
  },
  "geo" : { },
  "id_str" : "657983685782691840",
  "text" : "\"Our kids should only take tests that are worth taking\u2014tests that are high quality.\" \u2014@POTUS: https:\/\/t.co\/KqF05nWUkv",
  "id" : 657983685782691840,
  "created_at" : "2015-10-24 18:15:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "indices" : [ 3, 15 ],
      "id_str" : "369232105",
      "id" : 369232105
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 50, 56 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/GjffA9PgBk",
      "expanded_url" : "http:\/\/on.fb.me\/1Wb9O4D",
      "display_url" : "on.fb.me\/1Wb9O4D"
    } ]
  },
  "geo" : { },
  "id_str" : "657966000411951104",
  "text" : "RT @PAniskoff44: As a new mom, this pop quiz from @POTUS resonates. We need to be smart abt how we measure our kids. https:\/\/t.co\/GjffA9PgBk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 33, 39 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 123 ],
        "url" : "https:\/\/t.co\/GjffA9PgBk",
        "expanded_url" : "http:\/\/on.fb.me\/1Wb9O4D",
        "display_url" : "on.fb.me\/1Wb9O4D"
      } ]
    },
    "geo" : { },
    "id_str" : "657959097736691712",
    "text" : "As a new mom, this pop quiz from @POTUS resonates. We need to be smart abt how we measure our kids. https:\/\/t.co\/GjffA9PgBk",
    "id" : 657959097736691712,
    "created_at" : "2015-10-24 16:37:27 +0000",
    "user" : {
      "name" : "Paulette Aniskoff",
      "screen_name" : "PAniskoff44",
      "protected" : false,
      "id_str" : "369232105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623146355767140352\/58sqoVrw_normal.jpg",
      "id" : 369232105,
      "verified" : true
    }
  },
  "id" : 657966000411951104,
  "created_at" : "2015-10-24 17:04:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "indices" : [ 3, 13 ],
      "id_str" : "1613223313",
      "id" : 1613223313
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 16, 22 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "657960185718272000",
  "text" : "RT @Cecilia44: .@POTUS on reducing testing &amp; the balance between measuring progress &amp; preserving precious classroom hrs.\nhttps:\/\/t.co\/UFHmc\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 1, 7 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/UFHmcZB6Su",
        "expanded_url" : "http:\/\/on.fb.me\/1Wb9O4D",
        "display_url" : "on.fb.me\/1Wb9O4D"
      } ]
    },
    "geo" : { },
    "id_str" : "657950890280615936",
    "text" : ".@POTUS on reducing testing &amp; the balance between measuring progress &amp; preserving precious classroom hrs.\nhttps:\/\/t.co\/UFHmcZB6Su",
    "id" : 657950890280615936,
    "created_at" : "2015-10-24 16:04:51 +0000",
    "user" : {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "protected" : false,
      "id_str" : "1613223313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000172019215\/ed65eda76f51213f91b33edbaa62054c_normal.jpeg",
      "id" : 1613223313,
      "verified" : true
    }
  },
  "id" : 657960185718272000,
  "created_at" : "2015-10-24 16:41:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 144 ],
      "url" : "https:\/\/t.co\/KqF05oevJ5",
      "expanded_url" : "http:\/\/on.fb.me\/1Wb9O4D",
      "display_url" : "on.fb.me\/1Wb9O4D"
    } ]
  },
  "geo" : { },
  "id_str" : "657951813526822912",
  "text" : ".@POTUS has a pop quiz for parents and teachers &amp; a message on smarter ways to measure our kids' progress in school: https:\/\/t.co\/KqF05oevJ5",
  "id" : 657951813526822912,
  "created_at" : "2015-10-24 16:08:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 88, 94 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/n1XODp2mfs",
      "expanded_url" : "http:\/\/go.wh.gov\/eGhv3H",
      "display_url" : "go.wh.gov\/eGhv3H"
    } ]
  },
  "geo" : { },
  "id_str" : "657940561152888832",
  "text" : "\"Our country is home to some of the most beautiful God-given landscapes in the world.\" \u2014@POTUS: https:\/\/t.co\/n1XODp2mfs",
  "id" : 657940561152888832,
  "created_at" : "2015-10-24 15:23:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TPP",
      "indices" : [ 40, 44 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/vYxHGKmgH5",
      "expanded_url" : "http:\/\/on.wsj.com\/1LrpOMY",
      "display_url" : "on.wsj.com\/1LrpOMY"
    } ]
  },
  "geo" : { },
  "id_str" : "657695772243197952",
  "text" : "Read the national security case for the #TPP from a former Commander and a former Deputy Secretary of Defense \u2192 https:\/\/t.co\/vYxHGKmgH5",
  "id" : 657695772243197952,
  "created_at" : "2015-10-23 23:11:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CleanPowerPlan",
      "indices" : [ 98, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/ZLJ5FCuW8F",
      "expanded_url" : "http:\/\/on.ny.gov\/1W9iYDW",
      "display_url" : "on.ny.gov\/1W9iYDW"
    } ]
  },
  "geo" : { },
  "id_str" : "657680660979552256",
  "text" : "CA \u2713\nCT \u2713\nDC \u2713\nNY \u2713\nMA \u2713\nME \u2713\nNM \u2713\nVT \u2713\nWA \u2713\nAttorneys general from states nationwide support the #CleanPowerPlan: https:\/\/t.co\/ZLJ5FCuW8F",
  "id" : 657680660979552256,
  "created_at" : "2015-10-23 22:11:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "indices" : [ 3, 18 ],
      "id_str" : "3907577966",
      "id" : 3907577966
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CleanPowerPlan",
      "indices" : [ 81, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "657674208600805376",
  "text" : "RT @FactsOnClimate: READ IT: Attorneys General from across the country share why #CleanPowerPlan is a good way to combat climate change. ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CleanPowerPlan",
        "indices" : [ 61, 76 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/CUaVOrrHez",
        "expanded_url" : "http:\/\/on.ny.gov\/1W9iYDW",
        "display_url" : "on.ny.gov\/1W9iYDW"
      } ]
    },
    "geo" : { },
    "id_str" : "657602514859134976",
    "text" : "READ IT: Attorneys General from across the country share why #CleanPowerPlan is a good way to combat climate change. https:\/\/t.co\/CUaVOrrHez",
    "id" : 657602514859134976,
    "created_at" : "2015-10-23 17:00:31 +0000",
    "user" : {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "protected" : false,
      "id_str" : "3907577966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656492463880802306\/FhWzWlVs_normal.jpg",
      "id" : 3907577966,
      "verified" : true
    }
  },
  "id" : 657674208600805376,
  "created_at" : "2015-10-23 21:45:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diana Doukas",
      "screen_name" : "Diana44",
      "indices" : [ 3, 11 ],
      "id_str" : "3274836392",
      "id" : 3274836392
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TPP",
      "indices" : [ 17, 21 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "657665546457096192",
  "text" : "RT @Diana44: The #TPP will support higher-paying jobs. But it will also make us safer. Admiral Locklear &amp; John Hamre explain: https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TPP",
        "indices" : [ 4, 8 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/oByFnLItjl",
        "expanded_url" : "http:\/\/on.wsj.com\/1LrpOMY",
        "display_url" : "on.wsj.com\/1LrpOMY"
      } ]
    },
    "geo" : { },
    "id_str" : "657655989185966081",
    "text" : "The #TPP will support higher-paying jobs. But it will also make us safer. Admiral Locklear &amp; John Hamre explain: https:\/\/t.co\/oByFnLItjl",
    "id" : 657655989185966081,
    "created_at" : "2015-10-23 20:33:01 +0000",
    "user" : {
      "name" : "Diana Doukas",
      "screen_name" : "Diana44",
      "protected" : false,
      "id_str" : "3274836392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/671831357371191296\/CQ0VNiYR_normal.jpg",
      "id" : 3274836392,
      "verified" : true
    }
  },
  "id" : 657665546457096192,
  "created_at" : "2015-10-23 21:10:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Enrique Pe\u00F1a Nieto",
      "screen_name" : "EPN",
      "indices" : [ 3, 7 ],
      "id_str" : "2897441",
      "id" : 2897441
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Hurac\u00E1nPatricia",
      "indices" : [ 121, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "657658388793458688",
  "text" : "RT @EPN: Agradezco a Barack Obama su solidaridad con M\u00E9xico, en estos momentos en que nos preparamos para el impacto del #Hurac\u00E1nPatricia @\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 129, 135 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Hurac\u00E1nPatricia",
        "indices" : [ 112, 128 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "657651542187610112",
    "text" : "Agradezco a Barack Obama su solidaridad con M\u00E9xico, en estos momentos en que nos preparamos para el impacto del #Hurac\u00E1nPatricia @POTUS.",
    "id" : 657651542187610112,
    "created_at" : "2015-10-23 20:15:20 +0000",
    "user" : {
      "name" : "Enrique Pe\u00F1a Nieto",
      "screen_name" : "EPN",
      "protected" : false,
      "id_str" : "2897441",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794697746343219200\/aNRyAePJ_normal.jpg",
      "id" : 2897441,
      "verified" : true
    }
  },
  "id" : 657658388793458688,
  "created_at" : "2015-10-23 20:42:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "657645260055670784",
  "text" : "RT @POTUS: Our thoughts are with the Mexican people as they brace for Hurricane Patricia. USAID disaster experts are on the ground and read\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "657641041361817600",
    "text" : "Our thoughts are with the Mexican people as they brace for Hurricane Patricia. USAID disaster experts are on the ground and ready to help.",
    "id" : 657641041361817600,
    "created_at" : "2015-10-23 19:33:37 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 657645260055670784,
  "created_at" : "2015-10-23 19:50:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    }, {
      "name" : "Hubble",
      "screen_name" : "NASA_Hubble",
      "indices" : [ 90, 102 ],
      "id_str" : "14091091",
      "id" : 14091091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/8c8loCQkMj",
      "expanded_url" : "http:\/\/go.nasa.gov\/201SWSu",
      "display_url" : "go.nasa.gov\/201SWSu"
    } ]
  },
  "geo" : { },
  "id_str" : "657388531405426689",
  "text" : "RT @NASA: Largest sample of faintest &amp; earliest known galaxies in universe spotted by @NASA_Hubble: https:\/\/t.co\/8c8loCQkMj https:\/\/t.co\/QZ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hubble",
        "screen_name" : "NASA_Hubble",
        "indices" : [ 80, 92 ],
        "id_str" : "14091091",
        "id" : 14091091
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/NASA\/status\/657318894001070080\/photo\/1",
        "indices" : [ 118, 141 ],
        "url" : "https:\/\/t.co\/QZJGSPff4V",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CR9EDRpXIAAcvzS.jpg",
        "id_str" : "657318893686562816",
        "id" : 657318893686562816,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CR9EDRpXIAAcvzS.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 886,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 519,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 886,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 294,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/QZJGSPff4V"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/8c8loCQkMj",
        "expanded_url" : "http:\/\/go.nasa.gov\/201SWSu",
        "display_url" : "go.nasa.gov\/201SWSu"
      } ]
    },
    "geo" : { },
    "id_str" : "657318894001070080",
    "text" : "Largest sample of faintest &amp; earliest known galaxies in universe spotted by @NASA_Hubble: https:\/\/t.co\/8c8loCQkMj https:\/\/t.co\/QZJGSPff4V",
    "id" : 657318894001070080,
    "created_at" : "2015-10-22 22:13:31 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 657388531405426689,
  "created_at" : "2015-10-23 02:50:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 81, 87 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BlackLivesMatter",
      "indices" : [ 91, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/yC1T1q9GYm",
      "expanded_url" : "http:\/\/snpy.tv\/1MclwMX",
      "display_url" : "snpy.tv\/1MclwMX"
    } ]
  },
  "geo" : { },
  "id_str" : "657288329172488192",
  "text" : "\"We as a society, particularly given our history, have to take this seriously.\" \u2014@POTUS on #BlackLivesMatter https:\/\/t.co\/yC1T1q9GYm",
  "id" : 657288329172488192,
  "created_at" : "2015-10-22 20:12:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/RugQzLrVg0",
      "expanded_url" : "https:\/\/twitter.com\/BrynPhillips\/status\/657189009043685376",
      "display_url" : "twitter.com\/BrynPhillips\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "657286634119892992",
  "text" : "RT @vj44: The Administration supports federal legislation to ban the box.  https:\/\/t.co\/RugQzLrVg0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 88 ],
        "url" : "https:\/\/t.co\/RugQzLrVg0",
        "expanded_url" : "https:\/\/twitter.com\/BrynPhillips\/status\/657189009043685376",
        "display_url" : "twitter.com\/BrynPhillips\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "657285986666291200",
    "text" : "The Administration supports federal legislation to ban the box.  https:\/\/t.co\/RugQzLrVg0",
    "id" : 657285986666291200,
    "created_at" : "2015-10-22 20:02:45 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 657286634119892992,
  "created_at" : "2015-10-22 20:05:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CriminalJusticeReform",
      "indices" : [ 101, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "657284221501730816",
  "text" : "RT @vj44: We are 5% of the world's population, and we have 25% of the world's prisoners. Why we need #CriminalJusticeReform. https:\/\/t.co\/o\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CriminalJusticeReform",
        "indices" : [ 91, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/ow6nZCitHL",
        "expanded_url" : "https:\/\/twitter.com\/ajplus\/status\/657268759376371713",
        "display_url" : "twitter.com\/ajplus\/status\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "657284127511728128",
    "text" : "We are 5% of the world's population, and we have 25% of the world's prisoners. Why we need #CriminalJusticeReform. https:\/\/t.co\/ow6nZCitHL",
    "id" : 657284127511728128,
    "created_at" : "2015-10-22 19:55:22 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 657284221501730816,
  "created_at" : "2015-10-22 19:55:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 5, 10 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/657281179683549184\/photo\/1",
      "indices" : [ 118, 141 ],
      "url" : "https:\/\/t.co\/GliIO7vFpi",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CR8hoRmUwAAS9mb.jpg",
      "id_str" : "657281046422011904",
      "id" : 657281046422011904,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CR8hoRmUwAAS9mb.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1250,
        "resize" : "fit",
        "w" : 2500
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/GliIO7vFpi"
    } ],
    "hashtags" : [ {
      "text" : "CriminalJusticeReform",
      "indices" : [ 94, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "657281179683549184",
  "text" : "Join @VJ44 at 3:45pm ET for a Q&amp;A on our criminal justice system. Ask your questions with #CriminalJusticeReform. https:\/\/t.co\/GliIO7vFpi",
  "id" : 657281179683549184,
  "created_at" : "2015-10-22 19:43:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 110, 116 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CriminalJusticeReform",
      "indices" : [ 117, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "657274853586808832",
  "text" : "\"The use of technology, the use of data\u2014combined with smarter community policing\u2014really can have an impact.\" \u2014@POTUS #CriminalJusticeReform",
  "id" : 657274853586808832,
  "created_at" : "2015-10-22 19:18:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 86, 92 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CriminalJusticeReform",
      "indices" : [ 122, 144 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "657267727946686464",
  "text" : "\u201CWe need to spend more time on treatment &amp; not just incarceration as a strategy\u201D \u2014@POTUS on non-violent drug offenses #CriminalJusticeReform",
  "id" : 657267727946686464,
  "created_at" : "2015-10-22 18:50:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 84, 90 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/657266510138773504\/photo\/1",
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/cuFcWScbyX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CR8UUpeUAAAuVQY.jpg",
      "id_str" : "657266415582314496",
      "id" : 657266415582314496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CR8UUpeUAAAuVQY.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1250,
        "resize" : "fit",
        "w" : 2500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/cuFcWScbyX"
    } ],
    "hashtags" : [ {
      "text" : "CriminalJusticeReform",
      "indices" : [ 91, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "657266510138773504",
  "text" : "\"If we are not investing in opportunity for poor kids...that\u2019s a failed strategy.\" \u2014@POTUS #CriminalJusticeReform https:\/\/t.co\/cuFcWScbyX",
  "id" : 657266510138773504,
  "created_at" : "2015-10-22 18:45:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 85, 91 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CriminalJusticeReform",
      "indices" : [ 117, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/Q06guccNmn",
      "expanded_url" : "http:\/\/go.wh.gov\/tHCPgr",
      "display_url" : "go.wh.gov\/tHCPgr"
    } ]
  },
  "geo" : { },
  "id_str" : "657264972192423936",
  "text" : "\"Our criminal justice system should treat people fairly regardless of race, wealth\" \u2014@POTUS: https:\/\/t.co\/Q06guccNmn #CriminalJusticeReform",
  "id" : 657264972192423936,
  "created_at" : "2015-10-22 18:39:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 19, 25 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "The Marshall Project",
      "screen_name" : "MarshallProj",
      "indices" : [ 36, 49 ],
      "id_str" : "2216041938",
      "id" : 2216041938
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/657263533634129920\/photo\/1",
      "indices" : [ 120, 143 ],
      "url" : "https:\/\/t.co\/KGh9eMIN1A",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CR8RfebUAAAWUFb.jpg",
      "id_str" : "657263303060619264",
      "id" : 657263303060619264,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CR8RfebUAAAWUFb.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1250,
        "resize" : "fit",
        "w" : 2500
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/KGh9eMIN1A"
    } ],
    "hashtags" : [ {
      "text" : "CriminalJusticeReform",
      "indices" : [ 72, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/uoaQd9F4Zs",
      "expanded_url" : "http:\/\/go.wh.gov\/CJR",
      "display_url" : "go.wh.gov\/CJR"
    } ]
  },
  "geo" : { },
  "id_str" : "657263533634129920",
  "text" : "Starting now: Join @POTUS &amp; the @MarshallProj for a conversation on #CriminalJusticeReform: https:\/\/t.co\/uoaQd9F4Zs https:\/\/t.co\/KGh9eMIN1A",
  "id" : 657263533634129920,
  "created_at" : "2015-10-22 18:33:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/657260023756795904\/photo\/1",
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/Ixs6SThlzq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CR8OehdUwAAOYO1.jpg",
      "id_str" : "657259988159610880",
      "id" : 657259988159610880,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CR8OehdUwAAOYO1.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1250,
        "resize" : "fit",
        "w" : 2500
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/Ixs6SThlzq"
    } ],
    "hashtags" : [ {
      "text" : "CriminalJusticeReform",
      "indices" : [ 31, 53 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/uoaQd9WGo2",
      "expanded_url" : "http:\/\/go.wh.gov\/CJR",
      "display_url" : "go.wh.gov\/CJR"
    } ]
  },
  "geo" : { },
  "id_str" : "657260023756795904",
  "text" : "RT if you agree: It's time for #CriminalJusticeReform \u2192 https:\/\/t.co\/uoaQd9WGo2 https:\/\/t.co\/Ixs6SThlzq",
  "id" : 657260023756795904,
  "created_at" : "2015-10-22 18:19:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 19, 25 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "The Marshall Project",
      "screen_name" : "MarshallProj",
      "indices" : [ 36, 49 ],
      "id_str" : "2216041938",
      "id" : 2216041938
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/657254787759538177\/photo\/1",
      "indices" : [ 120, 143 ],
      "url" : "https:\/\/t.co\/lXwNWRkNUP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CR8JtHoVAAApOUX.jpg",
      "id_str" : "657254741366341632",
      "id" : 657254741366341632,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CR8JtHoVAAApOUX.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1250,
        "resize" : "fit",
        "w" : 2500
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/lXwNWRkNUP"
    } ],
    "hashtags" : [ {
      "text" : "CriminalJusticeReform",
      "indices" : [ 72, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/uoaQd9F4Zs",
      "expanded_url" : "http:\/\/go.wh.gov\/CJR",
      "display_url" : "go.wh.gov\/CJR"
    } ]
  },
  "geo" : { },
  "id_str" : "657254787759538177",
  "text" : "At 2:30pm ET, join @POTUS &amp; the @MarshallProj for a conversation on #CriminalJusticeReform: https:\/\/t.co\/uoaQd9F4Zs https:\/\/t.co\/lXwNWRkNUP",
  "id" : 657254787759538177,
  "created_at" : "2015-10-22 17:58:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Marshall Project",
      "screen_name" : "MarshallProj",
      "indices" : [ 3, 16 ],
      "id_str" : "2216041938",
      "id" : 2216041938
    }, {
      "name" : "Bill Keller",
      "screen_name" : "billkeller2014",
      "indices" : [ 42, 57 ],
      "id_str" : "37917164",
      "id" : 37917164
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 68, 74 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CriminalJusticeReform",
      "indices" : [ 106, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "657246510946635776",
  "text" : "RT @MarshallProj: Today at 2 PM ET: Watch @billkeller2014 talk with @POTUS and law enforcement leaders on #CriminalJusticeReform. https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bill Keller",
        "screen_name" : "billkeller2014",
        "indices" : [ 24, 39 ],
        "id_str" : "37917164",
        "id" : 37917164
      }, {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 50, 56 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CriminalJusticeReform",
        "indices" : [ 88, 110 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/6Nbn1BkJB6",
        "expanded_url" : "http:\/\/bit.ly\/1LMoUfi",
        "display_url" : "bit.ly\/1LMoUfi"
      } ]
    },
    "geo" : { },
    "id_str" : "657172049719259136",
    "text" : "Today at 2 PM ET: Watch @billkeller2014 talk with @POTUS and law enforcement leaders on #CriminalJusticeReform. https:\/\/t.co\/6Nbn1BkJB6",
    "id" : 657172049719259136,
    "created_at" : "2015-10-22 12:30:00 +0000",
    "user" : {
      "name" : "The Marshall Project",
      "screen_name" : "MarshallProj",
      "protected" : false,
      "id_str" : "2216041938",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/525373377561653248\/mElJJYpq_normal.png",
      "id" : 2216041938,
      "verified" : false
    }
  },
  "id" : 657246510946635776,
  "created_at" : "2015-10-22 17:25:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "indices" : [ 3, 11 ],
      "id_str" : "2382117350",
      "id" : 2382117350
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "657221096526225409",
  "text" : "RT @Deese44: Dallas Morning News: \"Texas should stop fighting and start complying with\" the Clean Power Plan. Well said. https:\/\/t.co\/8F8Yt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/8F8YtQIj6t",
        "expanded_url" : "http:\/\/www.dallasnews.com\/opinion\/editorials\/20151020-editorial-clean-power-rules-should-look-less-scary-to-critics-now.ece",
        "display_url" : "dallasnews.com\/opinion\/editor\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "657220604546822144",
    "text" : "Dallas Morning News: \"Texas should stop fighting and start complying with\" the Clean Power Plan. Well said. https:\/\/t.co\/8F8YtQIj6t",
    "id" : 657220604546822144,
    "created_at" : "2015-10-22 15:42:57 +0000",
    "user" : {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "protected" : false,
      "id_str" : "2382117350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656551411145027584\/ArrSlGUP_normal.jpg",
      "id" : 2382117350,
      "verified" : true
    }
  },
  "id" : 657221096526225409,
  "created_at" : "2015-10-22 15:44:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 61, 67 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/L4EZXukUzE",
      "expanded_url" : "http:\/\/snpy.tv\/1PHc0AR",
      "display_url" : "snpy.tv\/1PHc0AR"
    } ]
  },
  "geo" : { },
  "id_str" : "657197860019113984",
  "text" : "FACT: 120 Americans die every day from drug overdoses.\nWatch @POTUS discuss what we can do to help. https:\/\/t.co\/L4EZXukUzE",
  "id" : 657197860019113984,
  "created_at" : "2015-10-22 14:12:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 28, 34 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 109 ],
      "url" : "https:\/\/t.co\/qwo4tOoGsm",
      "expanded_url" : "http:\/\/snpy.tv\/1Lo9IU7",
      "display_url" : "snpy.tv\/1Lo9IU7"
    } ]
  },
  "geo" : { },
  "id_str" : "656984581216702464",
  "text" : "Watch Cary Dixon share with @POTUS how her family dealt with prescription drug abuse. https:\/\/t.co\/qwo4tOoGsm",
  "id" : 656984581216702464,
  "created_at" : "2015-10-22 00:05:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CriminalJusticeReform",
      "indices" : [ 115, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "656979961736204288",
  "text" : "RT @vj44: Join me tomorrow at 3:45 PM ET for a Q&amp;A on Criminal Justice Reform - send in q's and suggestions to #CriminalJusticeReform",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CriminalJusticeReform",
        "indices" : [ 105, 127 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "656970799040086016",
    "text" : "Join me tomorrow at 3:45 PM ET for a Q&amp;A on Criminal Justice Reform - send in q's and suggestions to #CriminalJusticeReform",
    "id" : 656970799040086016,
    "created_at" : "2015-10-21 23:10:19 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 656979961736204288,
  "created_at" : "2015-10-21 23:46:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael J. Fox",
      "screen_name" : "realmikefox",
      "indices" : [ 3, 15 ],
      "id_str" : "398092540",
      "id" : 398092540
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/i5swY8ksEB",
      "expanded_url" : "https:\/\/twitter.com\/potus\/status\/656926385882185728",
      "display_url" : "twitter.com\/potus\/status\/6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "656959061666177024",
  "text" : "RT @realmikefox: Mr. President, I never dreamed I'd be talking about the future with someone who's making History.  https:\/\/t.co\/i5swY8ksEB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 122 ],
        "url" : "https:\/\/t.co\/i5swY8ksEB",
        "expanded_url" : "https:\/\/twitter.com\/potus\/status\/656926385882185728",
        "display_url" : "twitter.com\/potus\/status\/6\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "656956357762023424",
    "text" : "Mr. President, I never dreamed I'd be talking about the future with someone who's making History.  https:\/\/t.co\/i5swY8ksEB",
    "id" : 656956357762023424,
    "created_at" : "2015-10-21 22:12:56 +0000",
    "user" : {
      "name" : "Michael J. Fox",
      "screen_name" : "realmikefox",
      "protected" : false,
      "id_str" : "398092540",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1614744193\/image_normal.jpg",
      "id" : 398092540,
      "verified" : true
    }
  },
  "id" : 656959061666177024,
  "created_at" : "2015-10-21 22:23:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Intl. Space Station",
      "screen_name" : "Space_Station",
      "indices" : [ 3, 17 ],
      "id_str" : "1451773004",
      "id" : 1451773004
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Space_Station\/status\/656892540369674240\/photo\/1",
      "indices" : [ 75, 98 ],
      "url" : "https:\/\/t.co\/mwJHtLlzvr",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CR3ASKNWIAAHYyu.png",
      "id_str" : "656892538876469248",
      "id" : 656892538876469248,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CR3ASKNWIAAHYyu.png",
      "sizes" : [ {
        "h" : 220,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 259,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 259,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 259,
        "resize" : "fit",
        "w" : 400
      } ],
      "display_url" : "pic.twitter.com\/mwJHtLlzvr"
    } ],
    "hashtags" : [ {
      "text" : "IfIHadAHoverboard",
      "indices" : [ 56, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "656933239244922881",
  "text" : "RT @Space_Station: You don\u2019t need hoverboards in space. #IfIHadAHoverboard https:\/\/t.co\/mwJHtLlzvr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Space_Station\/status\/656892540369674240\/photo\/1",
        "indices" : [ 56, 79 ],
        "url" : "https:\/\/t.co\/mwJHtLlzvr",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CR3ASKNWIAAHYyu.png",
        "id_str" : "656892538876469248",
        "id" : 656892538876469248,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CR3ASKNWIAAHYyu.png",
        "sizes" : [ {
          "h" : 220,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 259,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 259,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 259,
          "resize" : "fit",
          "w" : 400
        } ],
        "display_url" : "pic.twitter.com\/mwJHtLlzvr"
      } ],
      "hashtags" : [ {
        "text" : "IfIHadAHoverboard",
        "indices" : [ 37, 55 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "656892540369674240",
    "text" : "You don\u2019t need hoverboards in space. #IfIHadAHoverboard https:\/\/t.co\/mwJHtLlzvr",
    "id" : 656892540369674240,
    "created_at" : "2015-10-21 17:59:20 +0000",
    "user" : {
      "name" : "Intl. Space Station",
      "screen_name" : "Space_Station",
      "protected" : false,
      "id_str" : "1451773004",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/717069542246256644\/MxrOj0kL_normal.jpg",
      "id" : 1451773004,
      "verified" : true
    }
  },
  "id" : 656933239244922881,
  "created_at" : "2015-10-21 20:41:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Michael J. Fox",
      "screen_name" : "realmikefox",
      "indices" : [ 41, 53 ],
      "id_str" : "398092540",
      "id" : 398092540
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "656928750496534533",
  "text" : "RT @POTUS: Happy Back to the Future Day, @RealMikeFox! Ever think about the fact that we live in the future we dreamed of then? That's heav\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Michael J. Fox",
        "screen_name" : "realmikefox",
        "indices" : [ 30, 42 ],
        "id_str" : "398092540",
        "id" : 398092540
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "656926385882185728",
    "text" : "Happy Back to the Future Day, @RealMikeFox! Ever think about the fact that we live in the future we dreamed of then? That's heavy, man.",
    "id" : 656926385882185728,
    "created_at" : "2015-10-21 20:13:50 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 656928750496534533,
  "created_at" : "2015-10-21 20:23:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 109, 115 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/HB9JfXOrTK",
      "expanded_url" : "http:\/\/snpy.tv\/1PHd0VI",
      "display_url" : "snpy.tv\/1PHd0VI"
    } ]
  },
  "geo" : { },
  "id_str" : "656925453379178496",
  "text" : "\"Kids who don't always look like us or don't live in the same neighborhood as us, they're just as precious\" \u2014@POTUS https:\/\/t.co\/HB9JfXOrTK",
  "id" : 656925453379178496,
  "created_at" : "2015-10-21 20:10:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/L4EZXukUzE",
      "expanded_url" : "http:\/\/snpy.tv\/1PHc0AR",
      "display_url" : "snpy.tv\/1PHc0AR"
    } ]
  },
  "geo" : { },
  "id_str" : "656920767725203457",
  "text" : ".@POTUS on investing in treatment vs. incarceration to help solve the epidemic of prescription drug abuse. https:\/\/t.co\/L4EZXukUzE",
  "id" : 656920767725203457,
  "created_at" : "2015-10-21 19:51:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 65, 71 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/k21sldsGGx",
      "expanded_url" : "http:\/\/snpy.tv\/1M9bg84",
      "display_url" : "snpy.tv\/1M9bg84"
    } ]
  },
  "geo" : { },
  "id_str" : "656916136311832577",
  "text" : "\"Young people like Jordan, they remind us, these are our kids.\" \u2014@POTUS on helping those in need find treatment https:\/\/t.co\/k21sldsGGx",
  "id" : 656916136311832577,
  "created_at" : "2015-10-21 19:33:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 117, 123 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "656915414723727361",
  "text" : "\"One of my favorite sayings about having children is it's like having your heart walking around outside your body.\" \u2014@POTUS",
  "id" : 656915414723727361,
  "created_at" : "2015-10-21 19:30:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "656909434833211393",
  "text" : "RT @vj44: In 2012, 259 million prescriptions were written for these drugs - more than enough to give every American adult their own bottle \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "656907807891939328",
    "text" : "In 2012, 259 million prescriptions were written for these drugs - more than enough to give every American adult their own bottle of pills.",
    "id" : 656907807891939328,
    "created_at" : "2015-10-21 19:00:00 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 656909434833211393,
  "created_at" : "2015-10-21 19:06:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 113, 119 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 121, 144 ],
      "url" : "https:\/\/t.co\/g0AtIHm8fz",
      "expanded_url" : "http:\/\/snpy.tv\/1PH5CJX",
      "display_url" : "snpy.tv\/1PH5CJX"
    } ]
  },
  "geo" : { },
  "id_str" : "656908652822077440",
  "text" : "\"Treatment is possible, recovery does happen, &amp; a life of freedom is truly amazing.\"\n\nWatch Jordan introduce @POTUS. https:\/\/t.co\/g0AtIHm8fz",
  "id" : 656908652822077440,
  "created_at" : "2015-10-21 19:03:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 87, 93 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/xPUkw1Kpaq",
      "expanded_url" : "https:\/\/twitter.com\/POTUS\/status\/656894040319791104",
      "display_url" : "twitter.com\/POTUS\/status\/6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "656907155426045952",
  "text" : "\"We should approach substance abuse as an opportunity to intervene, not incarcerate.\" \u2014@POTUS in West Virginia  https:\/\/t.co\/xPUkw1Kpaq",
  "id" : 656907155426045952,
  "created_at" : "2015-10-21 18:57:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 100, 106 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "656905884312936453",
  "text" : "\"This crisis is taking lives, destroying families, and shattering communities across the country.\" \u2014@POTUS on prescription drug abuse",
  "id" : 656905884312936453,
  "created_at" : "2015-10-21 18:52:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 96, 102 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/peckbn2uyq",
      "expanded_url" : "http:\/\/go.wh.gov\/c42WrW",
      "display_url" : "go.wh.gov\/c42WrW"
    } ]
  },
  "geo" : { },
  "id_str" : "656905499221368833",
  "text" : "\"4 in 5 heroin users started out by misusing prescription drugs, and then switched to heroin.\" \u2014@POTUS: https:\/\/t.co\/peckbn2uyq",
  "id" : 656905499221368833,
  "created_at" : "2015-10-21 18:50:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 101, 107 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "656905310767095810",
  "text" : "RT @WHLive: \"Since 1999, sales of powerful prescription pain medications have skyrocketed by 300%.\" \u2014@POTUS in West Virginia",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 89, 95 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "656905284808519680",
    "text" : "\"Since 1999, sales of powerful prescription pain medications have skyrocketed by 300%.\" \u2014@POTUS in West Virginia",
    "id" : 656905284808519680,
    "created_at" : "2015-10-21 18:49:59 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 656905310767095810,
  "created_at" : "2015-10-21 18:50:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 98, 104 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "656904991546998784",
  "text" : "\"In 2013 alone, overdoses from prescription pain medications killed more than 16,000 Americans.\" \u2014@POTUS in West Virginia",
  "id" : 656904991546998784,
  "created_at" : "2015-10-21 18:48:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 96, 102 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/peckbn2uyq",
      "expanded_url" : "http:\/\/go.wh.gov\/c42WrW",
      "display_url" : "go.wh.gov\/c42WrW"
    } ]
  },
  "geo" : { },
  "id_str" : "656904821476302849",
  "text" : "\"More Americans now die every year from drug overdoses than they do in motor vehicle crashes.\" \u2014@POTUS: https:\/\/t.co\/peckbn2uyq",
  "id" : 656904821476302849,
  "created_at" : "2015-10-21 18:48:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 106, 112 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/peckbn2uyq",
      "expanded_url" : "http:\/\/go.wh.gov\/c42WrW",
      "display_url" : "go.wh.gov\/c42WrW"
    } ]
  },
  "geo" : { },
  "id_str" : "656904379635777536",
  "text" : "\"When it comes to substance abuse, treatment and recovery\u2026those things are possible if we work together\" \u2014@POTUS: https:\/\/t.co\/peckbn2uyq",
  "id" : 656904379635777536,
  "created_at" : "2015-10-21 18:46:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 61, 67 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/peckbmKT9Q",
      "expanded_url" : "http:\/\/go.wh.gov\/c42WrW",
      "display_url" : "go.wh.gov\/c42WrW"
    } ]
  },
  "geo" : { },
  "id_str" : "656904126014488577",
  "text" : "FACT: 120 Americans die every day from drug overdoses.\nWatch @POTUS discuss what we can do to help \u2192 https:\/\/t.co\/peckbmKT9Q",
  "id" : 656904126014488577,
  "created_at" : "2015-10-21 18:45:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 15, 21 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/peckbn2uyq",
      "expanded_url" : "http:\/\/go.wh.gov\/c42WrW",
      "display_url" : "go.wh.gov\/c42WrW"
    }, {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/WYa1eYsDnl",
      "expanded_url" : "https:\/\/twitter.com\/POTUS\/status\/656889342200188928",
      "display_url" : "twitter.com\/POTUS\/status\/6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "656898256857903104",
  "text" : "Starting soon: @POTUS speaks in West Virginia on the epidemic of prescription drug abuse \u2192 https:\/\/t.co\/peckbn2uyq https:\/\/t.co\/WYa1eYsDnl",
  "id" : 656898256857903104,
  "created_at" : "2015-10-21 18:22:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "656894253805776896",
  "text" : "RT @POTUS: So I'm eager to hear from folks in Charleston today on actions we can take to put recovery within reach for anyone who needs it.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "656893143015526404",
    "geo" : { },
    "id_str" : "656894040319791104",
    "in_reply_to_user_id" : 1536791610,
    "text" : "So I'm eager to hear from folks in Charleston today on actions we can take to put recovery within reach for anyone who needs it.",
    "id" : 656894040319791104,
    "in_reply_to_status_id" : 656893143015526404,
    "created_at" : "2015-10-21 18:05:18 +0000",
    "in_reply_to_screen_name" : "POTUS",
    "in_reply_to_user_id_str" : "1536791610",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 656894253805776896,
  "created_at" : "2015-10-21 18:06:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "656893964881166336",
  "text" : "RT @POTUS: Communities are showing that we should approach substance use disorders as an opportunity to intervene rather than a race to inc\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "656892337939845120",
    "geo" : { },
    "id_str" : "656893143015526404",
    "in_reply_to_user_id" : 1536791610,
    "text" : "Communities are showing that we should approach substance use disorders as an opportunity to intervene rather than a race to incarcerate.",
    "id" : 656893143015526404,
    "in_reply_to_status_id" : 656892337939845120,
    "created_at" : "2015-10-21 18:01:44 +0000",
    "in_reply_to_screen_name" : "POTUS",
    "in_reply_to_user_id_str" : "1536791610",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 656893964881166336,
  "created_at" : "2015-10-21 18:05:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "656893409714675712",
  "text" : "RT @POTUS: With no other disease do we expect people to wait until they're a danger to themselves or others to self-diagnose and seek treat\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "656891501520130048",
    "geo" : { },
    "id_str" : "656892337939845120",
    "in_reply_to_user_id" : 1536791610,
    "text" : "With no other disease do we expect people to wait until they're a danger to themselves or others to self-diagnose and seek treatment.",
    "id" : 656892337939845120,
    "in_reply_to_status_id" : 656891501520130048,
    "created_at" : "2015-10-21 17:58:32 +0000",
    "in_reply_to_screen_name" : "POTUS",
    "in_reply_to_user_id_str" : "1536791610",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 656893409714675712,
  "created_at" : "2015-10-21 18:02:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "656892572259000320",
  "text" : "RT @POTUS: 4 in 5 heroin users started out by misusing prescription opioids. Heroin-related deaths nearly quadrupled between 2002 and 2013.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "656890709555843072",
    "geo" : { },
    "id_str" : "656891501520130048",
    "in_reply_to_user_id" : 1536791610,
    "text" : "4 in 5 heroin users started out by misusing prescription opioids. Heroin-related deaths nearly quadrupled between 2002 and 2013.",
    "id" : 656891501520130048,
    "in_reply_to_status_id" : 656890709555843072,
    "created_at" : "2015-10-21 17:55:13 +0000",
    "in_reply_to_screen_name" : "POTUS",
    "in_reply_to_user_id_str" : "1536791610",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 656892572259000320,
  "created_at" : "2015-10-21 17:59:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "656892085405155328",
  "text" : "RT @POTUS: Sales of powerful painkillers have skyrocketed. In 2012, enough prescriptions were written to give every American adult a bottle\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "656889814201991168",
    "geo" : { },
    "id_str" : "656890709555843072",
    "in_reply_to_user_id" : 1536791610,
    "text" : "Sales of powerful painkillers have skyrocketed. In 2012, enough prescriptions were written to give every American adult a bottle of pills.",
    "id" : 656890709555843072,
    "in_reply_to_status_id" : 656889814201991168,
    "created_at" : "2015-10-21 17:52:04 +0000",
    "in_reply_to_screen_name" : "POTUS",
    "in_reply_to_user_id_str" : "1536791610",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 656892085405155328,
  "created_at" : "2015-10-21 17:57:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "656890541381128194",
  "text" : "RT @POTUS: 120 Americans die every day from drug overdoses - most involving legal prescription drugs. That's more than from car crashes.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "656889342200188928",
    "geo" : { },
    "id_str" : "656889814201991168",
    "in_reply_to_user_id" : 1536791610,
    "text" : "120 Americans die every day from drug overdoses - most involving legal prescription drugs. That's more than from car crashes.",
    "id" : 656889814201991168,
    "in_reply_to_status_id" : 656889342200188928,
    "created_at" : "2015-10-21 17:48:30 +0000",
    "in_reply_to_screen_name" : "POTUS",
    "in_reply_to_user_id_str" : "1536791610",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 656890541381128194,
  "created_at" : "2015-10-21 17:51:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "656890312074334208",
  "text" : "RT @POTUS: Heading to West Virginia today to talk about the epidemic of prescription drug abuse in America and what we can do to help. The \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "656889342200188928",
    "text" : "Heading to West Virginia today to talk about the epidemic of prescription drug abuse in America and what we can do to help. The facts:",
    "id" : 656889342200188928,
    "created_at" : "2015-10-21 17:46:38 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 656890312074334208,
  "created_at" : "2015-10-21 17:50:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Megan Smith",
      "screen_name" : "USCTO",
      "indices" : [ 1, 7 ],
      "id_str" : "2888895350",
      "id" : 2888895350
    }, {
      "name" : "L'Or\u00E9al USA",
      "screen_name" : "LOrealUSA",
      "indices" : [ 9, 19 ],
      "id_str" : "58602756",
      "id" : 58602756
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/656857698785320960\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/kxRZIinKy7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CR2gZy1UwAAeSs-.jpg",
      "id_str" : "656857485668564992",
      "id" : 656857485668564992,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CR2gZy1UwAAeSs-.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1224,
        "resize" : "fit",
        "w" : 1632
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/kxRZIinKy7"
    } ],
    "hashtags" : [ {
      "text" : "WomenInScience",
      "indices" : [ 82, 97 ]
    }, {
      "text" : "BackToTheFuture",
      "indices" : [ 99, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "656857698785320960",
  "text" : ".@USCTO, @LOrealUSA and others are ready to answer Q's on women in STEM. Ask with #WomenInScience! #BackToTheFuture https:\/\/t.co\/kxRZIinKy7",
  "id" : 656857698785320960,
  "created_at" : "2015-10-21 15:40:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Megan Smith",
      "screen_name" : "USCTO",
      "indices" : [ 50, 56 ],
      "id_str" : "2888895350",
      "id" : 2888895350
    }, {
      "name" : "L'Or\u00E9al USA",
      "screen_name" : "LOrealUSA",
      "indices" : [ 63, 73 ],
      "id_str" : "58602756",
      "id" : 58602756
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WomenInSTEM",
      "indices" : [ 32, 44 ]
    }, {
      "text" : "WomenInScience",
      "indices" : [ 79, 94 ]
    }, {
      "text" : "BackToTheFuture",
      "indices" : [ 120, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/9ge7LddZcj",
      "expanded_url" : "http:\/\/go.wh.gov\/BTTFD",
      "display_url" : "go.wh.gov\/BTTFD"
    } ]
  },
  "geo" : { },
  "id_str" : "656854736851894272",
  "text" : "Have questions on the future of #WomenInSTEM? Ask @USCTO &amp; @LOrealUSA with #WomenInScience! https:\/\/t.co\/9ge7LddZcj #BackToTheFuture",
  "id" : 656854736851894272,
  "created_at" : "2015-10-21 15:29:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/656826171544342528\/photo\/1",
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/LrRN7uMUq0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CR2Ds9HU8AA6YC-.jpg",
      "id_str" : "656825929008738304",
      "id" : 656825929008738304,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CR2Ds9HU8AA6YC-.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/LrRN7uMUq0"
    } ],
    "hashtags" : [ {
      "text" : "BackToTheFuture",
      "indices" : [ 6, 22 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 101 ],
      "url" : "https:\/\/t.co\/9ge7LdvA3R",
      "expanded_url" : "http:\/\/go.wh.gov\/BTTFD",
      "display_url" : "go.wh.gov\/BTTFD"
    } ]
  },
  "geo" : { },
  "id_str" : "656826171544342528",
  "text" : "Happy #BackToTheFuture Day! Join a Google+ Hangout on time travel right now \u2192 https:\/\/t.co\/9ge7LdvA3R https:\/\/t.co\/LrRN7uMUq0",
  "id" : 656826171544342528,
  "created_at" : "2015-10-21 13:35:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BackToTheFuture",
      "indices" : [ 15, 31 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/Qc8katwzlr",
      "expanded_url" : "http:\/\/nasa.tumblr.com\/post\/131616074159\/great-scott-its-back-to-the-future-day-oct",
      "display_url" : "nasa.tumblr.com\/post\/131616074\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "656817694134681601",
  "text" : "RT @NASA: It\u2019s #BackToTheFuture Day! What would a time traveler from 1985 discover about NASA today? https:\/\/t.co\/Qc8katwzlr https:\/\/t.co\/0\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/NASA\/status\/656815436848345088\/photo\/1",
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/0M3cPafbQJ",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CR16KM5WIAAwWhK.png",
        "id_str" : "656815436344991744",
        "id" : 656815436344991744,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CR16KM5WIAAwWhK.png",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 400
        } ],
        "display_url" : "pic.twitter.com\/0M3cPafbQJ"
      } ],
      "hashtags" : [ {
        "text" : "BackToTheFuture",
        "indices" : [ 5, 21 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/Qc8katwzlr",
        "expanded_url" : "http:\/\/nasa.tumblr.com\/post\/131616074159\/great-scott-its-back-to-the-future-day-oct",
        "display_url" : "nasa.tumblr.com\/post\/131616074\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "656815436848345088",
    "text" : "It\u2019s #BackToTheFuture Day! What would a time traveler from 1985 discover about NASA today? https:\/\/t.co\/Qc8katwzlr https:\/\/t.co\/0M3cPafbQJ",
    "id" : 656815436848345088,
    "created_at" : "2015-10-21 12:52:57 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 656817694134681601,
  "created_at" : "2015-10-21 13:01:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lori Kersey",
      "screen_name" : "LoriKerseyWV",
      "indices" : [ 3, 16 ],
      "id_str" : "15886218",
      "id" : 15886218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/CN0K6lzu2m",
      "expanded_url" : "https:\/\/youtu.be\/--IfzmnOq2U",
      "display_url" : "youtu.be\/--IfzmnOq2U"
    } ]
  },
  "geo" : { },
  "id_str" : "656636516853116928",
  "text" : "RT @LoriKerseyWV: From the Richwood High School Student Reporting Lab: Mr. President, we want you to know https:\/\/t.co\/CN0K6lzu2m",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/CN0K6lzu2m",
        "expanded_url" : "https:\/\/youtu.be\/--IfzmnOq2U",
        "display_url" : "youtu.be\/--IfzmnOq2U"
      } ]
    },
    "geo" : { },
    "id_str" : "656478280816685057",
    "text" : "From the Richwood High School Student Reporting Lab: Mr. President, we want you to know https:\/\/t.co\/CN0K6lzu2m",
    "id" : 656478280816685057,
    "created_at" : "2015-10-20 14:33:13 +0000",
    "user" : {
      "name" : "Lori Kersey",
      "screen_name" : "LoriKerseyWV",
      "protected" : false,
      "id_str" : "15886218",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771290416259952640\/hczUGBau_normal.jpg",
      "id" : 15886218,
      "verified" : false
    }
  },
  "id" : 656636516853116928,
  "created_at" : "2015-10-21 01:01:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/656616653535342592\/photo\/1",
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/81dpfRoEiu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRzFT_2XAAAYOT0.jpg",
      "id_str" : "656616593036869632",
      "id" : 656616593036869632,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRzFT_2XAAAYOT0.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/81dpfRoEiu"
    } ],
    "hashtags" : [ {
      "text" : "BackToTheFutureDay",
      "indices" : [ 12, 31 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 115 ],
      "url" : "https:\/\/t.co\/9ge7LdvA3R",
      "expanded_url" : "http:\/\/go.wh.gov\/BTTFD",
      "display_url" : "go.wh.gov\/BTTFD"
    } ]
  },
  "geo" : { },
  "id_str" : "656616653535342592",
  "text" : "Tomorrow is #BackToTheFutureDay! Celebrate by learning from innovators around the country \u2192 https:\/\/t.co\/9ge7LdvA3R https:\/\/t.co\/81dpfRoEiu",
  "id" : 656616653535342592,
  "created_at" : "2015-10-20 23:43:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "indices" : [ 3, 18 ],
      "id_str" : "3907577966",
      "id" : 3907577966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/D0uInPNcHT",
      "expanded_url" : "http:\/\/go.wh.gov\/Climate",
      "display_url" : "go.wh.gov\/Climate"
    } ]
  },
  "geo" : { },
  "id_str" : "656560768159059968",
  "text" : "RT @FactsOnClimate: \u201CIf you\u2019re fact-based, you\u2019ve got to see that action\u2019s got to be taken.\u201D \u2014Todd Stern: https:\/\/t.co\/D0uInPNcHT https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FactsOnClimate\/status\/656560725385547777\/photo\/1",
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/vleKZCJjXI",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CRySRDHWEAA1_zu.png",
        "id_str" : "656560467280793600",
        "id" : 656560467280793600,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CRySRDHWEAA1_zu.png",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/vleKZCJjXI"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/D0uInPNcHT",
        "expanded_url" : "http:\/\/go.wh.gov\/Climate",
        "display_url" : "go.wh.gov\/Climate"
      } ]
    },
    "geo" : { },
    "id_str" : "656560725385547777",
    "text" : "\u201CIf you\u2019re fact-based, you\u2019ve got to see that action\u2019s got to be taken.\u201D \u2014Todd Stern: https:\/\/t.co\/D0uInPNcHT https:\/\/t.co\/vleKZCJjXI",
    "id" : 656560725385547777,
    "created_at" : "2015-10-20 20:00:49 +0000",
    "user" : {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "protected" : false,
      "id_str" : "3907577966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656492463880802306\/FhWzWlVs_normal.jpg",
      "id" : 3907577966,
      "verified" : true
    }
  },
  "id" : 656560768159059968,
  "created_at" : "2015-10-20 20:01:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 36, 42 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Intl. Space Station",
      "screen_name" : "Space_Station",
      "indices" : [ 70, 84 ],
      "id_str" : "1451773004",
      "id" : 1451773004
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AstronomyNight",
      "indices" : [ 86, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 125 ],
      "url" : "https:\/\/t.co\/cgQIoOb24U",
      "expanded_url" : "http:\/\/snpy.tv\/1LkWhV5",
      "display_url" : "snpy.tv\/1LkWhV5"
    } ]
  },
  "geo" : { },
  "id_str" : "656538182788366336",
  "text" : "What's it like to call space? Watch @POTUS call the astronauts on the @Space_Station. #AstronomyNight https:\/\/t.co\/cgQIoOb24U",
  "id" : 656538182788366336,
  "created_at" : "2015-10-20 18:31:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "indices" : [ 3, 18 ],
      "id_str" : "3907577966",
      "id" : 3907577966
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CleanPowerPlan",
      "indices" : [ 38, 53 ]
    }, {
      "text" : "ActOnClimate",
      "indices" : [ 94, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/D0uInQ4O6t",
      "expanded_url" : "http:\/\/go.wh.gov\/Climate",
      "display_url" : "go.wh.gov\/Climate"
    } ]
  },
  "geo" : { },
  "id_str" : "656499979633102848",
  "text" : "RT @FactsOnClimate: President Obama's #CleanPowerPlan is the biggest step we've ever taken to #ActOnClimate \u2192 https:\/\/t.co\/D0uInQ4O6t https\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CleanPowerPlan",
        "indices" : [ 18, 33 ]
      }, {
        "text" : "ActOnClimate",
        "indices" : [ 74, 87 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/D0uInQ4O6t",
        "expanded_url" : "http:\/\/go.wh.gov\/Climate",
        "display_url" : "go.wh.gov\/Climate"
      }, {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/Gv5lYFsZXi",
        "expanded_url" : "http:\/\/snpy.tv\/1STbXjG",
        "display_url" : "snpy.tv\/1STbXjG"
      } ]
    },
    "geo" : { },
    "id_str" : "656499579123314688",
    "text" : "President Obama's #CleanPowerPlan is the biggest step we've ever taken to #ActOnClimate \u2192 https:\/\/t.co\/D0uInQ4O6t https:\/\/t.co\/Gv5lYFsZXi",
    "id" : 656499579123314688,
    "created_at" : "2015-10-20 15:57:51 +0000",
    "user" : {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "protected" : false,
      "id_str" : "3907577966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656492463880802306\/FhWzWlVs_normal.jpg",
      "id" : 3907577966,
      "verified" : true
    }
  },
  "id" : 656499979633102848,
  "created_at" : "2015-10-20 15:59:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "indices" : [ 7, 22 ],
      "id_str" : "3907577966",
      "id" : 3907577966
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 99, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/uyXCVOyXTH",
      "expanded_url" : "https:\/\/twitter.com\/FactsOnClimate\/status\/656496631362297857",
      "display_url" : "twitter.com\/FactsOnClimate\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "656497847576035328",
  "text" : "Follow @FactsOnClimate so you're armed with the facts about climate change and what we're doing to #ActOnClimate. https:\/\/t.co\/uyXCVOyXTH",
  "id" : 656497847576035328,
  "created_at" : "2015-10-20 15:50:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "indices" : [ 3, 18 ],
      "id_str" : "3907577966",
      "id" : 3907577966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "656496738706960384",
  "text" : "RT @FactsOnClimate: Climate change threatens us all, and it will take all of us to solve it. Get the facts on how we can: https:\/\/t.co\/D0uI\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 126, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 102, 125 ],
        "url" : "https:\/\/t.co\/D0uInQ4O6t",
        "expanded_url" : "http:\/\/go.wh.gov\/Climate",
        "display_url" : "go.wh.gov\/Climate"
      } ]
    },
    "geo" : { },
    "id_str" : "656496631362297857",
    "text" : "Climate change threatens us all, and it will take all of us to solve it. Get the facts on how we can: https:\/\/t.co\/D0uInQ4O6t #ActOnClimate",
    "id" : 656496631362297857,
    "created_at" : "2015-10-20 15:46:08 +0000",
    "user" : {
      "name" : "Facts On Climate",
      "screen_name" : "FactsOnClimate",
      "protected" : false,
      "id_str" : "3907577966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656492463880802306\/FhWzWlVs_normal.jpg",
      "id" : 3907577966,
      "verified" : true
    }
  },
  "id" : 656496738706960384,
  "created_at" : "2015-10-20 15:46:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 32, 38 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Intl. Space Station",
      "screen_name" : "Space_Station",
      "indices" : [ 50, 64 ],
      "id_str" : "1451773004",
      "id" : 1451773004
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AstronomyNight",
      "indices" : [ 15, 30 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 126 ],
      "url" : "https:\/\/t.co\/MYIV9j822y",
      "expanded_url" : "http:\/\/nasa.tumblr.com\/post\/131523791869\/president-obama-calls-the-international-space",
      "display_url" : "nasa.tumblr.com\/post\/131523791\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "656274760276439040",
  "text" : "RT @NASA: This #AstronomyNight, @POTUS called the @Space_Station! See our Tumblr blog for a breakdown: https:\/\/t.co\/MYIV9j822y https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 22, 28 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "Intl. Space Station",
        "screen_name" : "Space_Station",
        "indices" : [ 40, 54 ],
        "id_str" : "1451773004",
        "id" : 1451773004
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NASA\/status\/656272233296478209\/photo\/1",
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/GSWGOvzqHK",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CRuMHljXAAARyDN.png",
        "id_str" : "656272232679931904",
        "id" : 656272232679931904,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CRuMHljXAAARyDN.png",
        "sizes" : [ {
          "h" : 225,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 225,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 225,
          "resize" : "fit",
          "w" : 400
        } ],
        "display_url" : "pic.twitter.com\/GSWGOvzqHK"
      } ],
      "hashtags" : [ {
        "text" : "AstronomyNight",
        "indices" : [ 5, 20 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 116 ],
        "url" : "https:\/\/t.co\/MYIV9j822y",
        "expanded_url" : "http:\/\/nasa.tumblr.com\/post\/131523791869\/president-obama-calls-the-international-space",
        "display_url" : "nasa.tumblr.com\/post\/131523791\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "656272233296478209",
    "text" : "This #AstronomyNight, @POTUS called the @Space_Station! See our Tumblr blog for a breakdown: https:\/\/t.co\/MYIV9j822y https:\/\/t.co\/GSWGOvzqHK",
    "id" : 656272233296478209,
    "created_at" : "2015-10-20 00:54:28 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 656274760276439040,
  "created_at" : "2015-10-20 01:04:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 64, 70 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AstronomyNight",
      "indices" : [ 71, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 110 ],
      "url" : "https:\/\/t.co\/Rul1GusDwF",
      "expanded_url" : "http:\/\/snpy.tv\/1M1UHEJ",
      "display_url" : "snpy.tv\/1M1UHEJ"
    } ]
  },
  "geo" : { },
  "id_str" : "656271812611805184",
  "text" : "\"We need to inspire more young people to ask about the stars.\" \u2014@POTUS #AstronomyNight https:\/\/t.co\/Rul1GusDwF",
  "id" : 656271812611805184,
  "created_at" : "2015-10-20 00:52:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Intl. Space Station",
      "screen_name" : "Space_Station",
      "indices" : [ 47, 61 ],
      "id_str" : "1451773004",
      "id" : 1451773004
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AstronomyNight",
      "indices" : [ 106, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "656264052025372672",
  "text" : "RT @POTUS: I got a chance to catch up with the @Space_Station crew today. Nothing like a call to space on #AstronomyNight! https:\/\/t.co\/JVL\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Intl. Space Station",
        "screen_name" : "Space_Station",
        "indices" : [ 36, 50 ],
        "id_str" : "1451773004",
        "id" : 1451773004
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AstronomyNight",
        "indices" : [ 95, 110 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/JVLzYDQ8Jo",
        "expanded_url" : "http:\/\/snpy.tv\/1LkWhV5",
        "display_url" : "snpy.tv\/1LkWhV5"
      } ]
    },
    "geo" : { },
    "id_str" : "656263630741073920",
    "text" : "I got a chance to catch up with the @Space_Station crew today. Nothing like a call to space on #AstronomyNight! https:\/\/t.co\/JVLzYDQ8Jo",
    "id" : 656263630741073920,
    "created_at" : "2015-10-20 00:20:17 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 656264052025372672,
  "created_at" : "2015-10-20 00:21:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "656253609118580736",
  "text" : "RT @WHLive: \"I know you\u2019re not satisfied with being home to the last great discovery\u2014you want to be home to the next great discovery\" \u2014@POT\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 123, 129 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "656253576805658626",
    "text" : "\"I know you\u2019re not satisfied with being home to the last great discovery\u2014you want to be home to the next great discovery\" \u2014@POTUS",
    "id" : 656253576805658626,
    "created_at" : "2015-10-19 23:40:19 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 656253609118580736,
  "created_at" : "2015-10-19 23:40:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 103, 109 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AstronomyNight",
      "indices" : [ 110, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "656253267261820929",
  "text" : "\"In recent years, we\u2019ve discovered the first Earth-sized planet orbiting a star in a distant galaxy.\" \u2014@POTUS #AstronomyNight",
  "id" : 656253267261820929,
  "created_at" : "2015-10-19 23:39:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 58, 64 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/656253028169728000\/photo\/1",
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/QQ37ws6Si5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRt6osnWwAE34Zx.png",
      "id_str" : "656253010302124033",
      "id" : 656253010302124033,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRt6osnWwAE34Zx.png",
      "sizes" : [ {
        "h" : 601,
        "resize" : "fit",
        "w" : 843
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 428,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 242,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 601,
        "resize" : "fit",
        "w" : 843
      } ],
      "display_url" : "pic.twitter.com\/QQ37ws6Si5"
    } ],
    "hashtags" : [ {
      "text" : "AstronomyNight",
      "indices" : [ 90, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/kQpeyMCuOj",
      "expanded_url" : "http:\/\/go.wh.gov\/AstroNight",
      "display_url" : "go.wh.gov\/AstroNight"
    } ]
  },
  "geo" : { },
  "id_str" : "656253028169728000",
  "text" : "\"Earlier this year, we mapped Pluto in high-resolution.\" \u2014@POTUS: https:\/\/t.co\/kQpeyMCuOj #AstronomyNight https:\/\/t.co\/QQ37ws6Si5",
  "id" : 656253028169728000,
  "created_at" : "2015-10-19 23:38:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 13, 18 ],
      "id_str" : "11348282",
      "id" : 11348282
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 50, 56 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AstronomyNight",
      "indices" : [ 82, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 81 ],
      "url" : "https:\/\/t.co\/kQpeyMCuOj",
      "expanded_url" : "http:\/\/go.wh.gov\/AstroNight",
      "display_url" : "go.wh.gov\/AstroNight"
    } ]
  },
  "geo" : { },
  "id_str" : "656252718290370560",
  "text" : "\"Last month, @NASA found water flowing on Mars.\" \u2014@POTUS: https:\/\/t.co\/kQpeyMCuOj #AstronomyNight",
  "id" : 656252718290370560,
  "created_at" : "2015-10-19 23:36:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 63, 69 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/656251884852776960\/photo\/1",
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/tRqWYc35zk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRt5mPoWcAAker2.png",
      "id_str" : "656251868650303488",
      "id" : 656251868650303488,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRt5mPoWcAAker2.png",
      "sizes" : [ {
        "h" : 525,
        "resize" : "fit",
        "w" : 939
      }, {
        "h" : 190,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 335,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 525,
        "resize" : "fit",
        "w" : 939
      } ],
      "display_url" : "pic.twitter.com\/tRqWYc35zk"
    } ],
    "hashtags" : [ {
      "text" : "AstronomyNight",
      "indices" : [ 95, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/kQpeyMCuOj",
      "expanded_url" : "http:\/\/go.wh.gov\/AstroNight",
      "display_url" : "go.wh.gov\/AstroNight"
    } ]
  },
  "geo" : { },
  "id_str" : "656251884852776960",
  "text" : "\"We need to inspire more young people to ask about the stars\" \u2014@POTUS: https:\/\/t.co\/kQpeyMCuOj #AstronomyNight https:\/\/t.co\/tRqWYc35zk",
  "id" : 656251884852776960,
  "created_at" : "2015-10-19 23:33:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 12, 18 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/656250352778346496\/photo\/1",
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/vo1I9MnQnF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRt4DkCWwAUfoAx.jpg",
      "id_str" : "656250173321035781",
      "id" : 656250173321035781,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRt4DkCWwAUfoAx.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2448,
        "resize" : "fit",
        "w" : 3264
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/vo1I9MnQnF"
    } ],
    "hashtags" : [ {
      "text" : "AstronomyNight",
      "indices" : [ 29, 44 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 89 ],
      "url" : "https:\/\/t.co\/kQpeyMCuOj",
      "expanded_url" : "http:\/\/go.wh.gov\/AstroNight",
      "display_url" : "go.wh.gov\/AstroNight"
    } ]
  },
  "geo" : { },
  "id_str" : "656250352778346496",
  "text" : "Watch live: @POTUS speaks at #AstronomyNight at the White House \u2192 https:\/\/t.co\/kQpeyMCuOj https:\/\/t.co\/vo1I9MnQnF",
  "id" : 656250352778346496,
  "created_at" : "2015-10-19 23:27:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 28, 39 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AstronomyNight",
      "indices" : [ 46, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 119 ],
      "url" : "https:\/\/t.co\/3B56ANr3oe",
      "expanded_url" : "https:\/\/www.whitehouse.gov\/blog\/2015\/10\/15\/looking-stars-inspiration-white-house-astronomy-night",
      "display_url" : "whitehouse.gov\/blog\/2015\/10\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "656243116664459264",
  "text" : "RT @NASA: Watch live as the @WhiteHouse hosts #AstronomyNight at 7pm ET. Here's what to expect: https:\/\/t.co\/3B56ANr3oe https:\/\/t.co\/MCnBJR\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 18, 29 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/NASA\/status\/656239906608533505\/photo\/1",
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/MCnBJRjbNi",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CRtut9HWoAAwV2K.jpg",
        "id_str" : "656239906491113472",
        "id" : 656239906491113472,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRtut9HWoAAwV2K.jpg",
        "sizes" : [ {
          "h" : 311,
          "resize" : "fit",
          "w" : 498
        }, {
          "h" : 311,
          "resize" : "fit",
          "w" : 498
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 311,
          "resize" : "fit",
          "w" : 498
        }, {
          "h" : 212,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/MCnBJRjbNi"
      } ],
      "hashtags" : [ {
        "text" : "AstronomyNight",
        "indices" : [ 36, 51 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/3B56ANr3oe",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/blog\/2015\/10\/15\/looking-stars-inspiration-white-house-astronomy-night",
        "display_url" : "whitehouse.gov\/blog\/2015\/10\/1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "656239906608533505",
    "text" : "Watch live as the @WhiteHouse hosts #AstronomyNight at 7pm ET. Here's what to expect: https:\/\/t.co\/3B56ANr3oe https:\/\/t.co\/MCnBJRjbNi",
    "id" : 656239906608533505,
    "created_at" : "2015-10-19 22:46:00 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 656243116664459264,
  "created_at" : "2015-10-19 22:58:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 16, 22 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/656220307921899520\/photo\/1",
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/PhVchFt5f5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRtcscVWoAAfd33.jpg",
      "id_str" : "656220089302294528",
      "id" : 656220089302294528,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRtcscVWoAAfd33.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 683
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 683
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/PhVchFt5f5"
    } ],
    "hashtags" : [ {
      "text" : "AstronomyNight",
      "indices" : [ 65, 80 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/kQpeyMCuOj",
      "expanded_url" : "http:\/\/go.wh.gov\/AstroNight",
      "display_url" : "go.wh.gov\/AstroNight"
    } ]
  },
  "geo" : { },
  "id_str" : "656220307921899520",
  "text" : "At 7pm ET, join @POTUS, students, and astronauts for White House #AstronomyNight \u2192 https:\/\/t.co\/kQpeyMCuOj https:\/\/t.co\/PhVchFt5f5",
  "id" : 656220307921899520,
  "created_at" : "2015-10-19 21:28:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 141 ],
      "url" : "https:\/\/t.co\/VxKIPBjsUI",
      "expanded_url" : "https:\/\/www.whitehouse.gov\/live\/white-house-summit-climate-and-road-through-paris",
      "display_url" : "whitehouse.gov\/live\/white-hou\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "656186810163314688",
  "text" : "RT @VP: Happening soon: VP Biden speaks at White House Summit on Climate &amp; the Road through Paris. Follow along \u2192 https:\/\/t.co\/VxKIPBjsUI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/VxKIPBjsUI",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/live\/white-house-summit-climate-and-road-through-paris",
        "display_url" : "whitehouse.gov\/live\/white-hou\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "656186550716342272",
    "text" : "Happening soon: VP Biden speaks at White House Summit on Climate &amp; the Road through Paris. Follow along \u2192 https:\/\/t.co\/VxKIPBjsUI",
    "id" : 656186550716342272,
    "created_at" : "2015-10-19 19:13:59 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 656186810163314688,
  "created_at" : "2015-10-19 19:15:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Bloomberg",
      "screen_name" : "MikeBloomberg",
      "indices" : [ 3, 17 ],
      "id_str" : "16581604",
      "id" : 16581604
    }, {
      "name" : "Bloomberg LP",
      "screen_name" : "Bloomberg",
      "indices" : [ 77, 87 ],
      "id_str" : "104237736",
      "id" : 104237736
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ClimateChange",
      "indices" : [ 50, 64 ]
    }, {
      "text" : "ActOnClimate",
      "indices" : [ 121, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "656177551220436993",
  "text" : "RT @MikeBloomberg: All businesses are affected by #ClimateChange. That's why @Bloomberg has joined 80 other companies to #ActOnClimate http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bloomberg LP",
        "screen_name" : "Bloomberg",
        "indices" : [ 58, 68 ],
        "id_str" : "104237736",
        "id" : 104237736
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ClimateChange",
        "indices" : [ 31, 45 ]
      }, {
        "text" : "ActOnClimate",
        "indices" : [ 102, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/5e6qcOgR4X",
        "expanded_url" : "http:\/\/mikebloom.bg\/1MPtsT3",
        "display_url" : "mikebloom.bg\/1MPtsT3"
      } ]
    },
    "geo" : { },
    "id_str" : "656161558192652288",
    "text" : "All businesses are affected by #ClimateChange. That's why @Bloomberg has joined 80 other companies to #ActOnClimate http:\/\/t.co\/5e6qcOgR4X",
    "id" : 656161558192652288,
    "created_at" : "2015-10-19 17:34:41 +0000",
    "user" : {
      "name" : "Mike Bloomberg",
      "screen_name" : "MikeBloomberg",
      "protected" : false,
      "id_str" : "16581604",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615510114447953920\/_1c4TTMM_normal.jpg",
      "id" : 16581604,
      "verified" : true
    }
  },
  "id" : 656177551220436993,
  "created_at" : "2015-10-19 18:38:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 88, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "656156225206292480",
  "text" : "RT @POTUS: I just met with CEOs of some of our biggest companies who are stepping up to #ActOnClimate. It's good for the planet - and the b\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 77, 90 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "656153597932118018",
    "text" : "I just met with CEOs of some of our biggest companies who are stepping up to #ActOnClimate. It's good for the planet - and the bottom line.",
    "id" : 656153597932118018,
    "created_at" : "2015-10-19 17:03:03 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 656156225206292480,
  "created_at" : "2015-10-19 17:13:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 101, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/IU2TJ02bHg",
      "expanded_url" : "http:\/\/go.wh.gov\/ClimatePledge",
      "display_url" : "go.wh.gov\/ClimatePledge"
    }, {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/0hcQosUSDe",
      "expanded_url" : "https:\/\/twitter.com\/POTUS\/status\/656153597932118018",
      "display_url" : "twitter.com\/POTUS\/status\/6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "656155121106071552",
  "text" : "More than 80 major U.S. companies are taking action. Get the full list here \u2192 http:\/\/t.co\/IU2TJ02bHg #ActOnClimate  https:\/\/t.co\/0hcQosUSDe",
  "id" : 656155121106071552,
  "created_at" : "2015-10-19 17:09:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dell",
      "screen_name" : "Dell",
      "indices" : [ 3, 8 ],
      "id_str" : "58561993",
      "id" : 58561993
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 24, 35 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActonClimate",
      "indices" : [ 99, 112 ]
    }, {
      "text" : "COP21",
      "indices" : [ 113, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/wggSYN9bn3",
      "expanded_url" : "http:\/\/del.ly\/6017B3veT",
      "display_url" : "del.ly\/6017B3veT"
    } ]
  },
  "geo" : { },
  "id_str" : "656149755513344001",
  "text" : "RT @Dell: Proud to join @WhiteHouse American Business Act on Climate Pledge\u00A0http:\/\/t.co\/wggSYN9bn3 #ActonClimate #COP21 http:\/\/t.co\/ZLnBjHl\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 14, 25 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Dell\/status\/656140502933348352\/photo\/1",
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/ZLnBjHl6R0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CRsUT5MXAAA67nj.jpg",
        "id_str" : "656140502715269120",
        "id" : 656140502715269120,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRsUT5MXAAA67nj.jpg",
        "sizes" : [ {
          "h" : 320,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 136,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 240,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 320,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/ZLnBjHl6R0"
      } ],
      "hashtags" : [ {
        "text" : "ActonClimate",
        "indices" : [ 89, 102 ]
      }, {
        "text" : "COP21",
        "indices" : [ 103, 109 ]
      } ],
      "urls" : [ {
        "indices" : [ 66, 88 ],
        "url" : "http:\/\/t.co\/wggSYN9bn3",
        "expanded_url" : "http:\/\/del.ly\/6017B3veT",
        "display_url" : "del.ly\/6017B3veT"
      } ]
    },
    "geo" : { },
    "id_str" : "656140502933348352",
    "text" : "Proud to join @WhiteHouse American Business Act on Climate Pledge\u00A0http:\/\/t.co\/wggSYN9bn3 #ActonClimate #COP21 http:\/\/t.co\/ZLnBjHl6R0",
    "id" : 656140502933348352,
    "created_at" : "2015-10-19 16:11:01 +0000",
    "user" : {
      "name" : "Dell",
      "screen_name" : "Dell",
      "protected" : false,
      "id_str" : "58561993",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/775301770151014400\/s2ansX13_normal.jpg",
      "id" : 58561993,
      "verified" : true
    }
  },
  "id" : 656149755513344001,
  "created_at" : "2015-10-19 16:47:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mashable",
      "screen_name" : "mashable",
      "indices" : [ 3, 12 ],
      "id_str" : "972651",
      "id" : 972651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "656143234935029761",
  "text" : "RT @mashable: Facebook, Intel, Target and other tech and retail giants have agreed to help the White House fight climate change. http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/v6hS1b3n1M",
        "expanded_url" : "http:\/\/on.mash.to\/1LkcOsg",
        "display_url" : "on.mash.to\/1LkcOsg"
      } ]
    },
    "geo" : { },
    "id_str" : "656135400675766272",
    "text" : "Facebook, Intel, Target and other tech and retail giants have agreed to help the White House fight climate change. http:\/\/t.co\/v6hS1b3n1M",
    "id" : 656135400675766272,
    "created_at" : "2015-10-19 15:50:44 +0000",
    "user" : {
      "name" : "Mashable",
      "screen_name" : "mashable",
      "protected" : false,
      "id_str" : "972651",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/760998040949841922\/XT79xzRT_normal.jpg",
      "id" : 972651,
      "verified" : true
    }
  },
  "id" : 656143234935029761,
  "created_at" : "2015-10-19 16:21:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "656130622683873280",
  "text" : "RT @FLOTUS: \"It\u2019s about valuing success in the classroom instead of just on the big screen or on the basketball court.\" \u2014The First Lady #Be\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BetterMakeRoom",
        "indices" : [ 124, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "656129905051090944",
    "text" : "\"It\u2019s about valuing success in the classroom instead of just on the big screen or on the basketball court.\" \u2014The First Lady #BetterMakeRoom",
    "id" : 656129905051090944,
    "created_at" : "2015-10-19 15:28:54 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 656130622683873280,
  "created_at" : "2015-10-19 15:31:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BetterMakeRoom",
      "indices" : [ 57, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/SLmhfA5Xjw",
      "expanded_url" : "http:\/\/BetterMakeRoom.org",
      "display_url" : "BetterMakeRoom.org"
    }, {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/OiCUKcmjUO",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/b2f7a330-63ee-467f-accb-c57afa11afda",
      "display_url" : "amp.twimg.com\/v\/b2f7a330-63e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "656130265673150465",
  "text" : "RT @FLOTUS: \u201CI am thrilled to be here today as we launch #BetterMakeRoom.\u201D \u2014The First Lady: http:\/\/t.co\/SLmhfA5Xjw https:\/\/t.co\/OiCUKcmjUO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BetterMakeRoom",
        "indices" : [ 45, 60 ]
      } ],
      "urls" : [ {
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/SLmhfA5Xjw",
        "expanded_url" : "http:\/\/BetterMakeRoom.org",
        "display_url" : "BetterMakeRoom.org"
      }, {
        "indices" : [ 103, 126 ],
        "url" : "https:\/\/t.co\/OiCUKcmjUO",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/b2f7a330-63ee-467f-accb-c57afa11afda",
        "display_url" : "amp.twimg.com\/v\/b2f7a330-63e\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "656129054869819393",
    "text" : "\u201CI am thrilled to be here today as we launch #BetterMakeRoom.\u201D \u2014The First Lady: http:\/\/t.co\/SLmhfA5Xjw https:\/\/t.co\/OiCUKcmjUO",
    "id" : 656129054869819393,
    "created_at" : "2015-10-19 15:25:31 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 656130265673150465,
  "created_at" : "2015-10-19 15:30:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/656129152014135296\/photo\/1",
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/Pbmh7b1Kzl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRsJ4E1W0AAGB92.jpg",
      "id_str" : "656129029687398400",
      "id" : 656129029687398400,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRsJ4E1W0AAGB92.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Pbmh7b1Kzl"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 44, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/IU2TJ02bHg",
      "expanded_url" : "http:\/\/go.wh.gov\/ClimatePledge",
      "display_url" : "go.wh.gov\/ClimatePledge"
    } ]
  },
  "geo" : { },
  "id_str" : "656129152014135296",
  "text" : "American businesses are taking big steps to #ActOnClimate \u2192 http:\/\/t.co\/IU2TJ02bHg http:\/\/t.co\/Pbmh7b1Kzl",
  "id" : 656129152014135296,
  "created_at" : "2015-10-19 15:25:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "indices" : [ 3, 11 ],
      "id_str" : "2382117350",
      "id" : 2382117350
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 92, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/d5zDnzvMqr",
      "expanded_url" : "http:\/\/on.ft.com\/1W0xDMi",
      "display_url" : "on.ft.com\/1W0xDMi"
    } ]
  },
  "geo" : { },
  "id_str" : "656101608019771392",
  "text" : "RT @Deese44: Good for the planet; good for the bottom line: 81 American companies commit to #ActOnClimate http:\/\/t.co\/d5zDnzvMqr http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Deese44\/status\/656095620474646528\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/GVhatqvjvs",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CRrrfXHUwAAhiml.jpg",
        "id_str" : "656095619749036032",
        "id" : 656095619749036032,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRrrfXHUwAAhiml.jpg",
        "sizes" : [ {
          "h" : 192,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/GVhatqvjvs"
      } ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 79, 92 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/d5zDnzvMqr",
        "expanded_url" : "http:\/\/on.ft.com\/1W0xDMi",
        "display_url" : "on.ft.com\/1W0xDMi"
      } ]
    },
    "geo" : { },
    "id_str" : "656095620474646528",
    "text" : "Good for the planet; good for the bottom line: 81 American companies commit to #ActOnClimate http:\/\/t.co\/d5zDnzvMqr http:\/\/t.co\/GVhatqvjvs",
    "id" : 656095620474646528,
    "created_at" : "2015-10-19 13:12:40 +0000",
    "user" : {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "protected" : false,
      "id_str" : "2382117350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656551411145027584\/ArrSlGUP_normal.jpg",
      "id" : 2382117350,
      "verified" : true
    }
  },
  "id" : 656101608019771392,
  "created_at" : "2015-10-19 13:36:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/656099271880523777\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/FvgCn1pJVu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRruk0tUsAEzGyA.jpg",
      "id_str" : "656099012127272961",
      "id" : 656099012127272961,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRruk0tUsAEzGyA.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/FvgCn1pJVu"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 73, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/IU2TJ02bHg",
      "expanded_url" : "http:\/\/go.wh.gov\/ClimatePledge",
      "display_url" : "go.wh.gov\/ClimatePledge"
    } ]
  },
  "geo" : { },
  "id_str" : "656099271880523777",
  "text" : "RT the good news: U.S. companies are committing at least $160 billion to #ActOnClimate \u2192 http:\/\/t.co\/IU2TJ02bHg http:\/\/t.co\/FvgCn1pJVu",
  "id" : 656099271880523777,
  "created_at" : "2015-10-19 13:27:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "indices" : [ 3, 12 ],
      "id_str" : "249722522",
      "id" : 249722522
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/rhodes44\/status\/655895804159336448\/video\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/V2RWsFJ7St",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/655895680251068416\/pu\/img\/1wcQYjUtk-r0xswK.jpg",
      "id_str" : "655895680251068416",
      "id" : 655895680251068416,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/655895680251068416\/pu\/img\/1wcQYjUtk-r0xswK.jpg",
      "sizes" : [ {
        "h" : 568,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 0,
        "resize" : "fit",
        "w" : 0
      }, {
        "h" : 568,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 568,
        "resize" : "fit",
        "w" : 320
      } ],
      "display_url" : "pic.twitter.com\/V2RWsFJ7St"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655948556159729664",
  "text" : "RT @rhodes44: Received demonstration from UXO Lao on how they clear unexploded ordnance with US support. Vital work http:\/\/t.co\/V2RWsFJ7St",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/rhodes44\/status\/655895804159336448\/video\/1",
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/V2RWsFJ7St",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/655895680251068416\/pu\/img\/1wcQYjUtk-r0xswK.jpg",
        "id_str" : "655895680251068416",
        "id" : 655895680251068416,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/655895680251068416\/pu\/img\/1wcQYjUtk-r0xswK.jpg",
        "sizes" : [ {
          "h" : 568,
          "resize" : "fit",
          "w" : 320
        }, {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 568,
          "resize" : "fit",
          "w" : 320
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 568,
          "resize" : "fit",
          "w" : 320
        } ],
        "display_url" : "pic.twitter.com\/V2RWsFJ7St"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "655895804159336448",
    "text" : "Received demonstration from UXO Lao on how they clear unexploded ordnance with US support. Vital work http:\/\/t.co\/V2RWsFJ7St",
    "id" : 655895804159336448,
    "created_at" : "2015-10-18 23:58:40 +0000",
    "user" : {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "protected" : false,
      "id_str" : "249722522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/700766726644850688\/1lytmnAl_normal.jpg",
      "id" : 249722522,
      "verified" : true
    }
  },
  "id" : 655948556159729664,
  "created_at" : "2015-10-19 03:28:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 84, 90 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CriminalJusticeReform",
      "indices" : [ 115, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/ZRc3zK3cJj",
      "expanded_url" : "http:\/\/go.wh.gov\/7Xycd7",
      "display_url" : "go.wh.gov\/7Xycd7"
    } ]
  },
  "geo" : { },
  "id_str" : "655856663035908096",
  "text" : "\"Justice has never been easy to achieve, but it\u2019s always been worth fighting for.\" \u2014@POTUS: http:\/\/t.co\/ZRc3zK3cJj #CriminalJusticeReform",
  "id" : 655856663035908096,
  "created_at" : "2015-10-18 21:23:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 3, 13 ],
      "id_str" : "9624742",
      "id" : 9624742
    }, {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "indices" : [ 16, 26 ],
      "id_str" : "15007149",
      "id" : 15007149
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655852569332310016",
  "text" : "RT @StateDept: .@JohnKerry welcomes the critical first step in ensuring Iran\u2019s nuclear program will be used for peaceful purposes: http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John Kerry",
        "screen_name" : "JohnKerry",
        "indices" : [ 1, 11 ],
        "id_str" : "15007149",
        "id" : 15007149
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/GWmMCQeMUI",
        "expanded_url" : "http:\/\/go.usa.gov\/3SZGd",
        "display_url" : "go.usa.gov\/3SZGd"
      } ]
    },
    "geo" : { },
    "id_str" : "655810620500111360",
    "text" : ".@JohnKerry welcomes the critical first step in ensuring Iran\u2019s nuclear program will be used for peaceful purposes: http:\/\/t.co\/GWmMCQeMUI.",
    "id" : 655810620500111360,
    "created_at" : "2015-10-18 18:20:10 +0000",
    "user" : {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "protected" : false,
      "id_str" : "9624742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/724612605185282048\/1rEfkXDZ_normal.jpg",
      "id" : 9624742,
      "verified" : true
    }
  },
  "id" : 655852569332310016,
  "created_at" : "2015-10-18 21:06:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ernest Moniz",
      "screen_name" : "ErnestMoniz",
      "indices" : [ 3, 15 ],
      "id_str" : "1393155566",
      "id" : 1393155566
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 21, 30 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/Tph0WVC0ug",
      "expanded_url" : "http:\/\/1.usa.gov\/1GNk5g1",
      "display_url" : "1.usa.gov\/1GNk5g1"
    } ]
  },
  "geo" : { },
  "id_str" : "655842159183048704",
  "text" : "RT @ErnestMoniz: The #IranDeal goes into effect today, a major milestone for global nuclear security: http:\/\/t.co\/Tph0WVC0ug http:\/\/t.co\/EI\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/measuredvoice.com\/\" rel=\"nofollow\"\u003EMeasured Voice\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/ErnestMoniz\/status\/655807421139558400\/photo\/1",
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/EIqFyloj9U",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CRnlX-dWEAAXhfD.png",
        "id_str" : "655807420824948736",
        "id" : 655807420824948736,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRnlX-dWEAAXhfD.png",
        "sizes" : [ {
          "h" : 180,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 522,
          "resize" : "fit",
          "w" : 986
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 522,
          "resize" : "fit",
          "w" : 986
        }, {
          "h" : 318,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/EIqFyloj9U"
      } ],
      "hashtags" : [ {
        "text" : "IranDeal",
        "indices" : [ 4, 13 ]
      } ],
      "urls" : [ {
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/Tph0WVC0ug",
        "expanded_url" : "http:\/\/1.usa.gov\/1GNk5g1",
        "display_url" : "1.usa.gov\/1GNk5g1"
      } ]
    },
    "geo" : { },
    "id_str" : "655807421139558400",
    "text" : "The #IranDeal goes into effect today, a major milestone for global nuclear security: http:\/\/t.co\/Tph0WVC0ug http:\/\/t.co\/EIqFyloj9U",
    "id" : 655807421139558400,
    "created_at" : "2015-10-18 18:07:28 +0000",
    "user" : {
      "name" : "Ernest Moniz",
      "screen_name" : "ErnestMoniz",
      "protected" : false,
      "id_str" : "1393155566",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793425933113954305\/f5Mxv7BK_normal.jpg",
      "id" : 1393155566,
      "verified" : true
    }
  },
  "id" : 655842159183048704,
  "created_at" : "2015-10-18 20:25:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 59, 65 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CriminalJusticeReform",
      "indices" : [ 90, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/ZRc3zK3cJj",
      "expanded_url" : "http:\/\/go.wh.gov\/7Xycd7",
      "display_url" : "go.wh.gov\/7Xycd7"
    } ]
  },
  "geo" : { },
  "id_str" : "655811109354532864",
  "text" : "\"Justice means that the punishment should fit the crime.\" \u2014@POTUS: http:\/\/t.co\/ZRc3zK3cJj #CriminalJusticeReform",
  "id" : 655811109354532864,
  "created_at" : "2015-10-18 18:22:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Iran Deal",
      "screen_name" : "TheIranDeal",
      "indices" : [ 3, 15 ],
      "id_str" : "3281853858",
      "id" : 3281853858
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 46, 52 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/TheIranDeal\/status\/655797910613856256\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/EXDmUO7wej",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRnclXNW0AA7bhh.jpg",
      "id_str" : "655797755202424832",
      "id" : 655797755202424832,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRnclXNW0AA7bhh.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/EXDmUO7wej"
    } ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 77, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/VyrJqL5Hyj",
      "expanded_url" : "http:\/\/go.wh.gov\/GxosBL",
      "display_url" : "go.wh.gov\/GxosBL"
    } ]
  },
  "geo" : { },
  "id_str" : "655798172564885504",
  "text" : "RT @TheIranDeal: Read the full statement from @POTUS on adoption day for the #IranDeal \u2192 http:\/\/t.co\/VyrJqL5Hyj http:\/\/t.co\/EXDmUO7wej",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 29, 35 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TheIranDeal\/status\/655797910613856256\/photo\/1",
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/EXDmUO7wej",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CRnclXNW0AA7bhh.jpg",
        "id_str" : "655797755202424832",
        "id" : 655797755202424832,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRnclXNW0AA7bhh.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/EXDmUO7wej"
      } ],
      "hashtags" : [ {
        "text" : "IranDeal",
        "indices" : [ 60, 69 ]
      } ],
      "urls" : [ {
        "indices" : [ 72, 94 ],
        "url" : "http:\/\/t.co\/VyrJqL5Hyj",
        "expanded_url" : "http:\/\/go.wh.gov\/GxosBL",
        "display_url" : "go.wh.gov\/GxosBL"
      } ]
    },
    "geo" : { },
    "id_str" : "655797910613856256",
    "text" : "Read the full statement from @POTUS on adoption day for the #IranDeal \u2192 http:\/\/t.co\/VyrJqL5Hyj http:\/\/t.co\/EXDmUO7wej",
    "id" : 655797910613856256,
    "created_at" : "2015-10-18 17:29:40 +0000",
    "user" : {
      "name" : "The Iran Deal",
      "screen_name" : "TheIranDeal",
      "protected" : false,
      "id_str" : "3281853858",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623483767231873024\/sVfQ7OH0_normal.jpg",
      "id" : 3281853858,
      "verified" : true
    }
  },
  "id" : 655798172564885504,
  "created_at" : "2015-10-18 17:30:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 93, 99 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/655794868074098688\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/iJ2dkaHQbz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRnZ1xCWEAA_emm.jpg",
      "id_str" : "655794738478583808",
      "id" : 655794738478583808,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRnZ1xCWEAA_emm.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/iJ2dkaHQbz"
    } ],
    "hashtags" : [ {
      "text" : "IranDeal",
      "indices" : [ 100, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655794868074098688",
  "text" : "\"Today marks an important milestone toward preventing Iran from obtaining a nuclear weapon\" \u2014@POTUS #IranDeal http:\/\/t.co\/iJ2dkaHQbz",
  "id" : 655794868074098688,
  "created_at" : "2015-10-18 17:17:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 80, 86 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CriminalJusticeReform",
      "indices" : [ 111, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/ZRc3zK3cJj",
      "expanded_url" : "http:\/\/go.wh.gov\/7Xycd7",
      "display_url" : "go.wh.gov\/7Xycd7"
    } ]
  },
  "geo" : { },
  "id_str" : "655750839659659264",
  "text" : "\"Justice means that every child deserves a chance to grow up safe and secure.\" \u2014@POTUS: http:\/\/t.co\/ZRc3zK3cJj #CriminalJusticeReform",
  "id" : 655750839659659264,
  "created_at" : "2015-10-18 14:22:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 109, 115 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/ZRc3zK3cJj",
      "expanded_url" : "http:\/\/go.wh.gov\/7Xycd7",
      "display_url" : "go.wh.gov\/7Xycd7"
    } ]
  },
  "geo" : { },
  "id_str" : "655481437718622208",
  "text" : "\"In too many cases our criminal justice system is a pipeline from underfunded schools to overcrowded jails\" \u2014@POTUS: http:\/\/t.co\/ZRc3zK3cJj",
  "id" : 655481437718622208,
  "created_at" : "2015-10-17 20:32:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 62, 68 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CriminalJusticeReform",
      "indices" : [ 85, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/ZRc3zK3cJj",
      "expanded_url" : "http:\/\/go.wh.gov\/7Xycd7",
      "display_url" : "go.wh.gov\/7Xycd7"
    } ]
  },
  "geo" : { },
  "id_str" : "655450985964265472",
  "text" : "\"Every year, we spend $80 billion to keep people locked up.\" \u2014@POTUS on the need for #CriminalJusticeReform: http:\/\/t.co\/ZRc3zK3cJj",
  "id" : 655450985964265472,
  "created_at" : "2015-10-17 18:31:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/ZRc3zK3cJj",
      "expanded_url" : "http:\/\/go.wh.gov\/7Xycd7",
      "display_url" : "go.wh.gov\/7Xycd7"
    } ]
  },
  "geo" : { },
  "id_str" : "655420770445725696",
  "text" : "30 years ago, the U.S. held 500,000 people in jail.\nToday, it's 2.2 million.\nIt's time for criminal justice reform: http:\/\/t.co\/ZRc3zK3cJj",
  "id" : 655420770445725696,
  "created_at" : "2015-10-17 16:31:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/ZRc3zK3cJj",
      "expanded_url" : "http:\/\/go.wh.gov\/7Xycd7",
      "display_url" : "go.wh.gov\/7Xycd7"
    } ]
  },
  "geo" : { },
  "id_str" : "655390643540242432",
  "text" : "Watch @POTUS share how he's working with lawmakers in both parties to get criminal justice reform bills to his desk: http:\/\/t.co\/ZRc3zK3cJj",
  "id" : 655390643540242432,
  "created_at" : "2015-10-17 14:31:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 107, 113 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/655176340669206528\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/jlaDpcWZbE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRenSBJWcAAuf-6.jpg",
      "id_str" : "655176198792835072",
      "id" : 655176198792835072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRenSBJWcAAuf-6.jpg",
      "sizes" : [ {
        "h" : 238,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 2016,
        "resize" : "fit",
        "w" : 2880
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 420,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 717,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/jlaDpcWZbE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655176340669206528",
  "text" : "\"We\u2019ve always made this country great\u2014not by building walls\u2014but by tearing down barriers to opportunity.\" \u2014@POTUS http:\/\/t.co\/jlaDpcWZbE",
  "id" : 655176340669206528,
  "created_at" : "2015-10-17 00:19:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "indices" : [ 3, 12 ],
      "id_str" : "249722522",
      "id" : 249722522
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655127280318939136",
  "text" : "RT @rhodes44: Our marines serve w\/ honor around the world. Humbled to meet a few at U.S. Embassy Vientiane\u2019s new American Center. http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/rhodes44\/status\/655124539152531456\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/KThWcKvFG1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CRd4S9gUAAASjVY.jpg",
        "id_str" : "655124537948766208",
        "id" : 655124537948766208,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRd4S9gUAAASjVY.jpg",
        "sizes" : [ {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/KThWcKvFG1"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "655124539152531456",
    "text" : "Our marines serve w\/ honor around the world. Humbled to meet a few at U.S. Embassy Vientiane\u2019s new American Center. http:\/\/t.co\/KThWcKvFG1",
    "id" : 655124539152531456,
    "created_at" : "2015-10-16 20:53:56 +0000",
    "user" : {
      "name" : "Ben Rhodes",
      "screen_name" : "rhodes44",
      "protected" : false,
      "id_str" : "249722522",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/700766726644850688\/1lytmnAl_normal.jpg",
      "id" : 249722522,
      "verified" : true
    }
  },
  "id" : 655127280318939136,
  "created_at" : "2015-10-16 21:04:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 97, 106 ]
    }, {
      "text" : "LeadingByExample",
      "indices" : [ 107, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655117143134990336",
  "text" : "RT @vj44: I see you, Bradley Cooper!  Doing your part to promote pay equity with women co-stars. #EqualPay #LeadingByExample \u2192 http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EqualPay",
        "indices" : [ 87, 96 ]
      }, {
        "text" : "LeadingByExample",
        "indices" : [ 97, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/OYc3PMjwhr",
        "expanded_url" : "http:\/\/read.bi\/1jsQlAm",
        "display_url" : "read.bi\/1jsQlAm"
      } ]
    },
    "geo" : { },
    "id_str" : "655116302919467008",
    "text" : "I see you, Bradley Cooper!  Doing your part to promote pay equity with women co-stars. #EqualPay #LeadingByExample \u2192 http:\/\/t.co\/OYc3PMjwhr",
    "id" : 655116302919467008,
    "created_at" : "2015-10-16 20:21:12 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 655117143134990336,
  "created_at" : "2015-10-16 20:24:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 93, 99 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TPP",
      "indices" : [ 107, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/If8YLqiarx",
      "expanded_url" : "http:\/\/snpy.tv\/1LSziEc",
      "display_url" : "snpy.tv\/1LSziEc"
    } ]
  },
  "geo" : { },
  "id_str" : "655095028595953664",
  "text" : "It's \"the most progressive, highest-standard trade agreement that we have ever put forward\u201D \u2014@POTUS on the #TPP http:\/\/t.co\/If8YLqiarx",
  "id" : 655095028595953664,
  "created_at" : "2015-10-16 18:56:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 95, 101 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/655085107515031552\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/Vb6Zqk9YZe",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CRdUab4WcAAmAIA.png",
      "id_str" : "655085083943137280",
      "id" : 655085083943137280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CRdUab4WcAAmAIA.png",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/Vb6Zqk9YZe"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 102, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655085107515031552",
  "text" : "\"I want to commend South Korea for announcing its post-2020 target to limit carbon emissions\" \u2014@POTUS #ActOnClimate http:\/\/t.co\/Vb6Zqk9YZe",
  "id" : 655085107515031552,
  "created_at" : "2015-10-16 18:17:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 63, 69 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/655084647609716736\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/u1Weg2NQtf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRdT988WUAACG81.jpg",
      "id_str" : "655084594602070016",
      "id" : 655084594602070016,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRdT988WUAACG81.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/u1Weg2NQtf"
    } ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 101, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655084647609716736",
  "text" : "\"Bilateral trade is up, including exports of American autos.\" \u2014@POTUS on U.S. trade with South Korea #MadeInAmerica http:\/\/t.co\/u1Weg2NQtf",
  "id" : 655084647609716736,
  "created_at" : "2015-10-16 18:15:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 107, 113 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/0GXXvwijnT",
      "expanded_url" : "http:\/\/go.wh.gov\/EY8URW",
      "display_url" : "go.wh.gov\/EY8URW"
    } ]
  },
  "geo" : { },
  "id_str" : "655084181102460928",
  "text" : "\"Pyongyang...will not achieve the economic development it seeks so long as it clings to nuclear weapons.\" \u2014@POTUS: http:\/\/t.co\/0GXXvwijnT",
  "id" : 655084181102460928,
  "created_at" : "2015-10-16 18:13:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 122, 128 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655083877048954880",
  "text" : "\"Today, President Park and I are reaffirming that our nations will never accept North Korea as a nuclear weapons state.\" \u2014@POTUS",
  "id" : 655083877048954880,
  "created_at" : "2015-10-16 18:12:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 110, 116 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655083536572022784",
  "text" : "\"The commitment of the United States to the defense and security of the Republic of Korea will never waver.\" \u2014@POTUS to President Park",
  "id" : 655083536572022784,
  "created_at" : "2015-10-16 18:11:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 12, 18 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/0GXXvwzUfr",
      "expanded_url" : "http:\/\/go.wh.gov\/EY8URW",
      "display_url" : "go.wh.gov\/EY8URW"
    } ]
  },
  "geo" : { },
  "id_str" : "655083283504480256",
  "text" : "Watch live: @POTUS holds a press conference with President Park of the Republic of Korea \u2192 http:\/\/t.co\/0GXXvwzUfr",
  "id" : 655083283504480256,
  "created_at" : "2015-10-16 18:10:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 21, 27 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/0GXXvwijnT",
      "expanded_url" : "http:\/\/go.wh.gov\/EY8URW",
      "display_url" : "go.wh.gov\/EY8URW"
    } ]
  },
  "geo" : { },
  "id_str" : "655077316972953600",
  "text" : "Starting soon: Watch @POTUS hold a press conference with President Park of the Republic of Korea \u2192 http:\/\/t.co\/0GXXvwijnT",
  "id" : 655077316972953600,
  "created_at" : "2015-10-16 17:46:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "H\u014Dk\u016Ble\u2018a",
      "screen_name" : "HokuleaWWV",
      "indices" : [ 20, 31 ],
      "id_str" : "21330459",
      "id" : 21330459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "655046761120030722",
  "text" : "RT @POTUS: Congrats @HokuleaWWV on reaching Africa\u2014midpoint of worldwide voyage to spread message of caring for the one planet we've got. #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "H\u014Dk\u016Ble\u2018a",
        "screen_name" : "HokuleaWWV",
        "indices" : [ 9, 20 ],
        "id_str" : "21330459",
        "id" : 21330459
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MalamaHonua",
        "indices" : [ 127, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "655044746759438336",
    "text" : "Congrats @HokuleaWWV on reaching Africa\u2014midpoint of worldwide voyage to spread message of caring for the one planet we've got. #MalamaHonua",
    "id" : 655044746759438336,
    "created_at" : "2015-10-16 15:36:52 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 655046761120030722,
  "created_at" : "2015-10-16 15:44:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 12, 18 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/655021187748249600\/photo\/1",
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/BM5Q2qDeYK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRcaJ1HXAAAfiMU.jpg",
      "id_str" : "655021026984787968",
      "id" : 655021026984787968,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRcaJ1HXAAAfiMU.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/BM5Q2qDeYK"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/CCYfrIJng1",
      "expanded_url" : "http:\/\/go.wh.gov\/ipMPiN",
      "display_url" : "go.wh.gov\/ipMPiN"
    } ]
  },
  "geo" : { },
  "id_str" : "655021187748249600",
  "text" : "FACT: Under @POTUS, we've reduced the deficit by nearly 75%. http:\/\/t.co\/CCYfrIJng1 http:\/\/t.co\/BM5Q2qDeYK",
  "id" : 655021187748249600,
  "created_at" : "2015-10-16 14:03:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Terry McAuliffe",
      "screen_name" : "GovernorVA",
      "indices" : [ 3, 14 ],
      "id_str" : "104198706",
      "id" : 104198706
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/2R8mO3u5xv",
      "expanded_url" : "http:\/\/1.usa.gov\/1jqWop2",
      "display_url" : "1.usa.gov\/1jqWop2"
    } ]
  },
  "geo" : { },
  "id_str" : "654999690463854592",
  "text" : "RT @GovernorVA: This morning Gov signed EO50 taking executive actions to keep guns out of dangerous hands. http:\/\/t.co\/2R8mO3u5xv http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/GovernorVA\/status\/654713846582521856\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/GOKfDm88y3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CRYCw0sUsAAPD6a.jpg",
        "id_str" : "654713833630511104",
        "id" : 654713833630511104,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRYCw0sUsAAPD6a.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/GOKfDm88y3"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/GovernorVA\/status\/654713846582521856\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/GOKfDm88y3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CRYCw0xUcAEWEAi.jpg",
        "id_str" : "654713833651466241",
        "id" : 654713833651466241,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRYCw0xUcAEWEAi.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/GOKfDm88y3"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/2R8mO3u5xv",
        "expanded_url" : "http:\/\/1.usa.gov\/1jqWop2",
        "display_url" : "1.usa.gov\/1jqWop2"
      } ]
    },
    "geo" : { },
    "id_str" : "654713846582521856",
    "text" : "This morning Gov signed EO50 taking executive actions to keep guns out of dangerous hands. http:\/\/t.co\/2R8mO3u5xv http:\/\/t.co\/GOKfDm88y3",
    "id" : 654713846582521856,
    "created_at" : "2015-10-15 17:41:59 +0000",
    "user" : {
      "name" : "Terry McAuliffe",
      "screen_name" : "GovernorVA",
      "protected" : false,
      "id_str" : "104198706",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/422048182915174402\/WKQ6GHZ3_normal.jpeg",
      "id" : 104198706,
      "verified" : true
    }
  },
  "id" : 654999690463854592,
  "created_at" : "2015-10-16 12:37:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Terry McAuliffe",
      "screen_name" : "GovernorVA",
      "indices" : [ 20, 31 ],
      "id_str" : "104198706",
      "id" : 104198706
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StopGunViolence",
      "indices" : [ 89, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/ux5vqawTve",
      "expanded_url" : "http:\/\/1.usa.gov\/1G7LgaF",
      "display_url" : "1.usa.gov\/1G7LgaF"
    } ]
  },
  "geo" : { },
  "id_str" : "654998677170221056",
  "text" : "RT @vj44: I applaud @GovernorVA leadership on gun safety. A common sense step forward to #StopGunViolence http:\/\/t.co\/ux5vqawTve",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Terry McAuliffe",
        "screen_name" : "GovernorVA",
        "indices" : [ 10, 21 ],
        "id_str" : "104198706",
        "id" : 104198706
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "StopGunViolence",
        "indices" : [ 79, 95 ]
      } ],
      "urls" : [ {
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/ux5vqawTve",
        "expanded_url" : "http:\/\/1.usa.gov\/1G7LgaF",
        "display_url" : "1.usa.gov\/1G7LgaF"
      } ]
    },
    "geo" : { },
    "id_str" : "654995219851558912",
    "text" : "I applaud @GovernorVA leadership on gun safety. A common sense step forward to #StopGunViolence http:\/\/t.co\/ux5vqawTve",
    "id" : 654995219851558912,
    "created_at" : "2015-10-16 12:20:04 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 654998677170221056,
  "created_at" : "2015-10-16 12:33:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 20, 26 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/OYe4cDOKBA",
      "expanded_url" : "http:\/\/go.wh.gov\/NYRB",
      "display_url" : "go.wh.gov\/NYRB"
    }, {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/nm51TzV0Ru",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/d4bd81ce-59e6-40aa-a856-03a5b7b2326e",
      "display_url" : "amp.twimg.com\/v\/d4bd81ce-59e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "654852935159971840",
  "text" : "What's it like when @POTUS sits down to chat with one of his favorite authors? Watch \u2192 http:\/\/t.co\/OYe4cDOKBA\nhttps:\/\/t.co\/nm51TzV0Ru",
  "id" : 654852935159971840,
  "created_at" : "2015-10-16 02:54:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/VP\/status\/654790953274728448\/photo\/1",
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/4cqHjVCHmb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRZI5IXUkAAis9f.jpg",
      "id_str" : "654790942164029440",
      "id" : 654790942164029440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRZI5IXUkAAis9f.jpg",
      "sizes" : [ {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/4cqHjVCHmb"
    } ],
    "hashtags" : [ {
      "text" : "SpiritDay",
      "indices" : [ 23, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654811222886346753",
  "text" : "RT @VP: VP Biden joins #SpiritDay to support LGBT youth and take a stand against bullying http:\/\/t.co\/4cqHjVCHmb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/VP\/status\/654790953274728448\/photo\/1",
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/4cqHjVCHmb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CRZI5IXUkAAis9f.jpg",
        "id_str" : "654790942164029440",
        "id" : 654790942164029440,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRZI5IXUkAAis9f.jpg",
        "sizes" : [ {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/4cqHjVCHmb"
      } ],
      "hashtags" : [ {
        "text" : "SpiritDay",
        "indices" : [ 15, 25 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "654790953274728448",
    "text" : "VP Biden joins #SpiritDay to support LGBT youth and take a stand against bullying http:\/\/t.co\/4cqHjVCHmb",
    "id" : 654790953274728448,
    "created_at" : "2015-10-15 22:48:23 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 654811222886346753,
  "created_at" : "2015-10-16 00:08:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/654805330505797633\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/pV7KONcpC1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRZV6ICUYAAV_Gn.jpg",
      "id_str" : "654805252906967040",
      "id" : 654805252906967040,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRZV6ICUYAAV_Gn.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/pV7KONcpC1"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/CCYfrIrLRr",
      "expanded_url" : "http:\/\/go.wh.gov\/ipMPiN",
      "display_url" : "go.wh.gov\/ipMPiN"
    } ]
  },
  "geo" : { },
  "id_str" : "654805330505797633",
  "text" : "Under @POTUS, we've seen the fastest deficit decline over a sustained period since WWII. http:\/\/t.co\/CCYfrIrLRr http:\/\/t.co\/pV7KONcpC1",
  "id" : 654805330505797633,
  "created_at" : "2015-10-15 23:45:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sara Ramirez",
      "screen_name" : "SaraRamirez",
      "indices" : [ 3, 15 ],
      "id_str" : "1633987406",
      "id" : 1633987406
    }, {
      "name" : "SAMHSA",
      "screen_name" : "samhsagov",
      "indices" : [ 97, 107 ],
      "id_str" : "24959108",
      "id" : 24959108
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bornperfect",
      "indices" : [ 30, 42 ]
    }, {
      "text" : "LGBT",
      "indices" : [ 69, 74 ]
    }, {
      "text" : "conversiontherapy",
      "indices" : [ 75, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654798080034762752",
  "text" : "RT @SaraRamirez: All kids are #bornperfect. Learn why we need to end #LGBT #conversiontherapy in @samhsagov\u2019s new report: http:\/\/t.co\/I2a08\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "SAMHSA",
        "screen_name" : "samhsagov",
        "indices" : [ 80, 90 ],
        "id_str" : "24959108",
        "id" : 24959108
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 128, 139 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "bornperfect",
        "indices" : [ 13, 25 ]
      }, {
        "text" : "LGBT",
        "indices" : [ 52, 57 ]
      }, {
        "text" : "conversiontherapy",
        "indices" : [ 58, 76 ]
      } ],
      "urls" : [ {
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/I2a08yWDoE",
        "expanded_url" : "http:\/\/ow.ly\/2bvMPT",
        "display_url" : "ow.ly\/2bvMPT"
      } ]
    },
    "geo" : { },
    "id_str" : "654716058016706560",
    "text" : "All kids are #bornperfect. Learn why we need to end #LGBT #conversiontherapy in @samhsagov\u2019s new report: http:\/\/t.co\/I2a08yWDoE @WhiteHouse",
    "id" : 654716058016706560,
    "created_at" : "2015-10-15 17:50:46 +0000",
    "user" : {
      "name" : "Sara Ramirez",
      "screen_name" : "SaraRamirez",
      "protected" : false,
      "id_str" : "1633987406",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771002528381231104\/ywp1jMz9_normal.jpg",
      "id" : 1633987406,
      "verified" : true
    }
  },
  "id" : 654798080034762752,
  "created_at" : "2015-10-15 23:16:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "indices" : [ 3, 16 ],
      "id_str" : "78138151",
      "id" : 78138151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654797202909343744",
  "text" : "RT @lacasablanca: Omara Portuondo - lead singer of Cuba's legendary band Buena Vista Social Club - poses in front of the White House. http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/lacasablanca\/status\/654792719387095045\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/zbfstEhZPj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CRZKgdGUsAAYk6E.jpg",
        "id_str" : "654792717256404992",
        "id" : 654792717256404992,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRZKgdGUsAAYk6E.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2448,
          "resize" : "fit",
          "w" : 2448
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/zbfstEhZPj"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "654792719387095045",
    "text" : "Omara Portuondo - lead singer of Cuba's legendary band Buena Vista Social Club - poses in front of the White House. http:\/\/t.co\/zbfstEhZPj",
    "id" : 654792719387095045,
    "created_at" : "2015-10-15 22:55:24 +0000",
    "user" : {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "protected" : false,
      "id_str" : "78138151",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616360382911754241\/4Tfqcfie_normal.png",
      "id" : 78138151,
      "verified" : true
    }
  },
  "id" : 654797202909343744,
  "created_at" : "2015-10-15 23:13:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 79, 85 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/654766316956483584\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/J3c30f5czw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRYx0PAVAAAUrU9.jpg",
      "id_str" : "654765569279852544",
      "id" : 654765569279852544,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRYx0PAVAAAUrU9.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/J3c30f5czw"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/CCYfrIrLRr",
      "expanded_url" : "http:\/\/go.wh.gov\/ipMPiN",
      "display_url" : "go.wh.gov\/ipMPiN"
    } ]
  },
  "geo" : { },
  "id_str" : "654766316956483584",
  "text" : "RT to spread the word: We've reduced the deficit by nearly three-fourths under @POTUS \u2192 http:\/\/t.co\/CCYfrIrLRr http:\/\/t.co\/J3c30f5czw",
  "id" : 654766316956483584,
  "created_at" : "2015-10-15 21:10:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 118, 124 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654762999492644864",
  "text" : "\"That\u2019s how we\u2019ve always made this country great\u2014not by building walls\u2014but by tearing down barriers to opportunity.\u201D \u2014@POTUS",
  "id" : 654762999492644864,
  "created_at" : "2015-10-15 20:57:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 98, 104 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/654762238041976832\/photo\/1",
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/in0VY0cwgy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRYuuJtUYAAJjrM.jpg",
      "id_str" : "654762166243844096",
      "id" : 654762166243844096,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRYuuJtUYAAJjrM.jpg",
      "sizes" : [ {
        "h" : 568,
        "resize" : "fit",
        "w" : 853
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 568,
        "resize" : "fit",
        "w" : 853
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/in0VY0cwgy"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654762238041976832",
  "text" : "\u201CWe\u2019ve got a lot of work to do to make sure every child gets a shot at a world-class education.\u201D \u2014@POTUS http:\/\/t.co\/in0VY0cwgy",
  "id" : 654762238041976832,
  "created_at" : "2015-10-15 20:54:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 134, 140 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654761188333514753",
  "text" : "\"Our country\u2019s high school graduation rate is at an all-time high...powered in large part by dramatic gains among Hispanic students\" \u2014@POTUS",
  "id" : 654761188333514753,
  "created_at" : "2015-10-15 20:50:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 47, 53 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/cZKXtLh2aP",
      "expanded_url" : "http:\/\/go.wh.gov\/U8MPNz",
      "display_url" : "go.wh.gov\/U8MPNz"
    } ]
  },
  "geo" : { },
  "id_str" : "654760114776244224",
  "text" : "\"Give it up for the Buena Vista Social Club!\" \u2014@POTUS at a Hispanic Heritage Month Reception\n\nWatch \u2192 http:\/\/t.co\/cZKXtLh2aP",
  "id" : 654760114776244224,
  "created_at" : "2015-10-15 20:45:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 12, 18 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/cZKXtLh2aP",
      "expanded_url" : "http:\/\/go.wh.gov\/U8MPNz",
      "display_url" : "go.wh.gov\/U8MPNz"
    } ]
  },
  "geo" : { },
  "id_str" : "654759661422317570",
  "text" : "Watch live: @POTUS speaks at a Hispanic Heritage Month Reception \u2192 http:\/\/t.co\/cZKXtLh2aP",
  "id" : 654759661422317570,
  "created_at" : "2015-10-15 20:44:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "We the People",
      "screen_name" : "wethepeople",
      "indices" : [ 3, 15 ],
      "id_str" : "369507958",
      "id" : 369507958
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/aQr5LWUfk6",
      "expanded_url" : "http:\/\/go.wh.gov\/Sa88br",
      "display_url" : "go.wh.gov\/Sa88br"
    } ]
  },
  "geo" : { },
  "id_str" : "654755042562453505",
  "text" : "RT @wethepeople: We just sent an initial response to signers of a petition on the Syrian refugee crisis. Read it \u2192 http:\/\/t.co\/aQr5LWUfk6 #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AidRefugees",
        "indices" : [ 121, 133 ]
      } ],
      "urls" : [ {
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/aQr5LWUfk6",
        "expanded_url" : "http:\/\/go.wh.gov\/Sa88br",
        "display_url" : "go.wh.gov\/Sa88br"
      } ]
    },
    "geo" : { },
    "id_str" : "654718905215119364",
    "text" : "We just sent an initial response to signers of a petition on the Syrian refugee crisis. Read it \u2192 http:\/\/t.co\/aQr5LWUfk6 #AidRefugees",
    "id" : 654718905215119364,
    "created_at" : "2015-10-15 18:02:05 +0000",
    "user" : {
      "name" : "We the People",
      "screen_name" : "wethepeople",
      "protected" : false,
      "id_str" : "369507958",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1608012795\/tw_share_normal.png",
      "id" : 369507958,
      "verified" : true
    }
  },
  "id" : 654755042562453505,
  "created_at" : "2015-10-15 20:25:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "indices" : [ 3, 16 ],
      "id_str" : "78138151",
      "id" : 78138151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654743431642673155",
  "text" : "RT @lacasablanca: The ambassadors of Cuban music Buena Vista Social Club will play at the White House at 3:45pm ET. Don't miss it \u2192 http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/khvaWpahwM",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "654720816039395328",
    "text" : "The ambassadors of Cuban music Buena Vista Social Club will play at the White House at 3:45pm ET. Don't miss it \u2192 http:\/\/t.co\/khvaWpahwM",
    "id" : 654720816039395328,
    "created_at" : "2015-10-15 18:09:41 +0000",
    "user" : {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "protected" : false,
      "id_str" : "78138151",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616360382911754241\/4Tfqcfie_normal.png",
      "id" : 78138151,
      "verified" : true
    }
  },
  "id" : 654743431642673155,
  "created_at" : "2015-10-15 19:39:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WeTheGeeks",
      "indices" : [ 84, 95 ]
    }, {
      "text" : "LatinosAchieve",
      "indices" : [ 96, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/NPcrL4LO06",
      "expanded_url" : "https:\/\/www.whitehouse.gov\/blog\/2015\/10\/13\/somos-geeks-celebrating-hispanic-heritage-month",
      "display_url" : "whitehouse.gov\/blog\/2015\/10\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "654735039150686208",
  "text" : "RT @whitehouseostp: TODAY, 3pm ET: tune in to Somos Geeks: Hispanic Heritage Month! #WeTheGeeks #LatinosAchieve https:\/\/t.co\/NPcrL4LO06 htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/whitehouseostp\/status\/654696723479027712\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/zU9RfY03is",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CRXzM0KUYAEhixs.png",
        "id_str" : "654696722338177025",
        "id" : 654696722338177025,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRXzM0KUYAEhixs.png",
        "sizes" : [ {
          "h" : 246,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 246,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 167,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 246,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/zU9RfY03is"
      } ],
      "hashtags" : [ {
        "text" : "WeTheGeeks",
        "indices" : [ 64, 75 ]
      }, {
        "text" : "LatinosAchieve",
        "indices" : [ 76, 91 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 115 ],
        "url" : "https:\/\/t.co\/NPcrL4LO06",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/blog\/2015\/10\/13\/somos-geeks-celebrating-hispanic-heritage-month",
        "display_url" : "whitehouse.gov\/blog\/2015\/10\/1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "654696723479027712",
    "text" : "TODAY, 3pm ET: tune in to Somos Geeks: Hispanic Heritage Month! #WeTheGeeks #LatinosAchieve https:\/\/t.co\/NPcrL4LO06 http:\/\/t.co\/zU9RfY03is",
    "id" : 654696723479027712,
    "created_at" : "2015-10-15 16:33:57 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 654735039150686208,
  "created_at" : "2015-10-15 19:06:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 22, 28 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/654730370424815617\/photo\/1",
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/GOtIZcb4rN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRYRpK5UYAA1RuQ.jpg",
      "id_str" : "654730194826059776",
      "id" : 654730194826059776,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRYRpK5UYAA1RuQ.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/GOtIZcb4rN"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 62, 75 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/noK3cyGiEP",
      "expanded_url" : "http:\/\/go.wh.gov\/myEMJT",
      "display_url" : "go.wh.gov\/myEMJT"
    } ]
  },
  "geo" : { },
  "id_str" : "654730370424815617",
  "text" : "Get the latest on how @POTUS is partnering with businesses to #ActOnClimate \u2192 http:\/\/t.co\/noK3cyGiEP http:\/\/t.co\/GOtIZcb4rN",
  "id" : 654730370424815617,
  "created_at" : "2015-10-15 18:47:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tumblr",
      "screen_name" : "tumblr",
      "indices" : [ 3, 10 ],
      "id_str" : "52484614",
      "id" : 52484614
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 16, 27 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/tumblr\/status\/654725625169620993\/photo\/1",
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/Bpy8gWDbZl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRYNfJeVAAAyg8f.png",
      "id_str" : "654725624599216128",
      "id" : 654725624599216128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRYNfJeVAAAyg8f.png",
      "sizes" : [ {
        "h" : 569,
        "resize" : "fit",
        "w" : 372
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 520,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 569,
        "resize" : "fit",
        "w" : 372
      }, {
        "h" : 569,
        "resize" : "fit",
        "w" : 372
      } ],
      "display_url" : "pic.twitter.com\/Bpy8gWDbZl"
    } ],
    "hashtags" : [ {
      "text" : "SpiritDay",
      "indices" : [ 61, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/LCREa2buag",
      "expanded_url" : "http:\/\/tumblr.co\/Ts7b5",
      "display_url" : "tumblr.co\/Ts7b5"
    } ]
  },
  "geo" : { },
  "id_str" : "654725675853549568",
  "text" : "RT @tumblr: The @WhiteHouse is taking your questions now for #SpiritDay http:\/\/t.co\/LCREa2buag http:\/\/t.co\/Bpy8gWDbZl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 4, 15 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/tumblr\/status\/654725625169620993\/photo\/1",
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/Bpy8gWDbZl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CRYNfJeVAAAyg8f.png",
        "id_str" : "654725624599216128",
        "id" : 654725624599216128,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRYNfJeVAAAyg8f.png",
        "sizes" : [ {
          "h" : 569,
          "resize" : "fit",
          "w" : 372
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 520,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 569,
          "resize" : "fit",
          "w" : 372
        }, {
          "h" : 569,
          "resize" : "fit",
          "w" : 372
        } ],
        "display_url" : "pic.twitter.com\/Bpy8gWDbZl"
      } ],
      "hashtags" : [ {
        "text" : "SpiritDay",
        "indices" : [ 49, 59 ]
      } ],
      "urls" : [ {
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/LCREa2buag",
        "expanded_url" : "http:\/\/tumblr.co\/Ts7b5",
        "display_url" : "tumblr.co\/Ts7b5"
      } ]
    },
    "geo" : { },
    "id_str" : "654725625169620993",
    "text" : "The @WhiteHouse is taking your questions now for #SpiritDay http:\/\/t.co\/LCREa2buag http:\/\/t.co\/Bpy8gWDbZl",
    "id" : 654725625169620993,
    "created_at" : "2015-10-15 18:28:47 +0000",
    "user" : {
      "name" : "Tumblr",
      "screen_name" : "tumblr",
      "protected" : false,
      "id_str" : "52484614",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791014307089747968\/jqxriE5C_normal.jpg",
      "id" : 52484614,
      "verified" : true
    }
  },
  "id" : 654725675853549568,
  "created_at" : "2015-10-15 18:28:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 20, 25 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Tumblr",
      "screen_name" : "tumblr",
      "indices" : [ 32, 39 ],
      "id_str" : "52484614",
      "id" : 52484614
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/654719775730327552\/photo\/1",
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/k9uKJpZ9Zz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRYIGEgUYAQTLkL.jpg",
      "id_str" : "654719696210518020",
      "id" : 654719696210518020,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRYIGEgUYAQTLkL.jpg",
      "sizes" : [ {
        "h" : 671,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1835,
        "resize" : "fit",
        "w" : 2800
      }, {
        "h" : 393,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 223,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/k9uKJpZ9Zz"
    } ],
    "hashtags" : [ {
      "text" : "SpiritDay",
      "indices" : [ 57, 67 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/ZesfAUaDM5",
      "expanded_url" : "http:\/\/whitehouse.tumblr.com\/",
      "display_url" : "whitehouse.tumblr.com"
    } ]
  },
  "geo" : { },
  "id_str" : "654719775730327552",
  "text" : "Happening now: Join @VJ44 for a @Tumblr Q&amp;A on LGBTQ #SpiritDay \u2192 http:\/\/t.co\/ZesfAUaDM5 http:\/\/t.co\/k9uKJpZ9Zz",
  "id" : 654719775730327552,
  "created_at" : "2015-10-15 18:05:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "We the People",
      "screen_name" : "wethepeople",
      "indices" : [ 3, 15 ],
      "id_str" : "369507958",
      "id" : 369507958
    }, {
      "name" : "Tumblr",
      "screen_name" : "tumblr",
      "indices" : [ 74, 81 ],
      "id_str" : "52484614",
      "id" : 52484614
    }, {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 91, 96 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/EfUC5EXy7e",
      "expanded_url" : "http:\/\/tmblr.co\/ZW21es1wDFu0k",
      "display_url" : "tmblr.co\/ZW21es1wDFu0k"
    } ]
  },
  "geo" : { },
  "id_str" : "654692143403937792",
  "text" : "RT @wethepeople: If you've got thoughts or questions, you should join our @Tumblr Q+A with @VJ44 at 2pm ET \u2192 http:\/\/t.co\/EfUC5EXy7e #Spirit\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tumblr",
        "screen_name" : "tumblr",
        "indices" : [ 57, 64 ],
        "id_str" : "52484614",
        "id" : 52484614
      }, {
        "name" : "Valerie Jarrett",
        "screen_name" : "vj44",
        "indices" : [ 74, 79 ],
        "id_str" : "595515713",
        "id" : 595515713
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SpiritDay",
        "indices" : [ 115, 125 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/EfUC5EXy7e",
        "expanded_url" : "http:\/\/tmblr.co\/ZW21es1wDFu0k",
        "display_url" : "tmblr.co\/ZW21es1wDFu0k"
      } ]
    },
    "geo" : { },
    "id_str" : "654680460883132416",
    "text" : "If you've got thoughts or questions, you should join our @Tumblr Q+A with @VJ44 at 2pm ET \u2192 http:\/\/t.co\/EfUC5EXy7e #SpiritDay",
    "id" : 654680460883132416,
    "created_at" : "2015-10-15 15:29:19 +0000",
    "user" : {
      "name" : "We the People",
      "screen_name" : "wethepeople",
      "protected" : false,
      "id_str" : "369507958",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1608012795\/tw_share_normal.png",
      "id" : 369507958,
      "verified" : true
    }
  },
  "id" : 654692143403937792,
  "created_at" : "2015-10-15 16:15:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "We the People",
      "screen_name" : "wethepeople",
      "indices" : [ 3, 15 ],
      "id_str" : "369507958",
      "id" : 369507958
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/wethepeople\/status\/654679734782001153\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/FrNywUXm6a",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRXjdjUUAAAWdT1.png",
      "id_str" : "654679417688424448",
      "id" : 654679417688424448,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRXjdjUUAAAWdT1.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 179,
        "resize" : "fit",
        "w" : 681
      }, {
        "h" : 179,
        "resize" : "fit",
        "w" : 681
      }, {
        "h" : 158,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 89,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/FrNywUXm6a"
    } ],
    "hashtags" : [ {
      "text" : "SpiritDay",
      "indices" : [ 104, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/nkbPYLxcfT",
      "expanded_url" : "http:\/\/go.wh.gov\/LWBXQ2",
      "display_url" : "go.wh.gov\/LWBXQ2"
    } ]
  },
  "geo" : { },
  "id_str" : "654691786338627584",
  "text" : "RT @wethepeople: It highlights this important new report on conversion therapy \u2192 http:\/\/t.co\/nkbPYLxcfT #SpiritDay http:\/\/t.co\/FrNywUXm6a",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/wethepeople\/status\/654679734782001153\/photo\/1",
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/FrNywUXm6a",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CRXjdjUUAAAWdT1.png",
        "id_str" : "654679417688424448",
        "id" : 654679417688424448,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRXjdjUUAAAWdT1.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 179,
          "resize" : "fit",
          "w" : 681
        }, {
          "h" : 179,
          "resize" : "fit",
          "w" : 681
        }, {
          "h" : 158,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 89,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/FrNywUXm6a"
      } ],
      "hashtags" : [ {
        "text" : "SpiritDay",
        "indices" : [ 87, 97 ]
      } ],
      "urls" : [ {
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/nkbPYLxcfT",
        "expanded_url" : "http:\/\/go.wh.gov\/LWBXQ2",
        "display_url" : "go.wh.gov\/LWBXQ2"
      } ]
    },
    "geo" : { },
    "id_str" : "654679734782001153",
    "text" : "It highlights this important new report on conversion therapy \u2192 http:\/\/t.co\/nkbPYLxcfT #SpiritDay http:\/\/t.co\/FrNywUXm6a",
    "id" : 654679734782001153,
    "created_at" : "2015-10-15 15:26:26 +0000",
    "user" : {
      "name" : "We the People",
      "screen_name" : "wethepeople",
      "protected" : false,
      "id_str" : "369507958",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1608012795\/tw_share_normal.png",
      "id" : 369507958,
      "verified" : true
    }
  },
  "id" : 654691786338627584,
  "created_at" : "2015-10-15 16:14:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "We the People",
      "screen_name" : "wethepeople",
      "indices" : [ 3, 15 ],
      "id_str" : "369507958",
      "id" : 369507958
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SpiritDay",
      "indices" : [ 120, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/TDe3yieV0s",
      "expanded_url" : "http:\/\/go.wh.gov\/138sYi",
      "display_url" : "go.wh.gov\/138sYi"
    } ]
  },
  "geo" : { },
  "id_str" : "654691548190273536",
  "text" : "RT @wethepeople: We just sent this update to signers of a petition on LGBTQ+ conversion therapy: http:\/\/t.co\/TDe3yieV0s #SpiritDay",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SpiritDay",
        "indices" : [ 103, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/TDe3yieV0s",
        "expanded_url" : "http:\/\/go.wh.gov\/138sYi",
        "display_url" : "go.wh.gov\/138sYi"
      } ]
    },
    "geo" : { },
    "id_str" : "654678922869653504",
    "text" : "We just sent this update to signers of a petition on LGBTQ+ conversion therapy: http:\/\/t.co\/TDe3yieV0s #SpiritDay",
    "id" : 654678922869653504,
    "created_at" : "2015-10-15 15:23:13 +0000",
    "user" : {
      "name" : "We the People",
      "screen_name" : "wethepeople",
      "protected" : false,
      "id_str" : "369507958",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1608012795\/tw_share_normal.png",
      "id" : 369507958,
      "verified" : true
    }
  },
  "id" : 654691548190273536,
  "created_at" : "2015-10-15 16:13:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/kXhTn73IBi",
      "expanded_url" : "http:\/\/snpy.tv\/1LQ9xEy",
      "display_url" : "snpy.tv\/1LQ9xEy"
    } ]
  },
  "geo" : { },
  "id_str" : "654683224904368132",
  "text" : "Watch President Obama's full statement on our troops' involvement in Afghanistan: http:\/\/t.co\/kXhTn73IBi",
  "id" : 654683224904368132,
  "created_at" : "2015-10-15 15:40:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 114, 120 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654677593858244609",
  "text" : "\"May God bless our troops and all who keep us safe. And may God continue to bless the United States of America.\" \u2014@POTUS",
  "id" : 654677593858244609,
  "created_at" : "2015-10-15 15:17:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 131, 137 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654677434596364288",
  "text" : "\"After so many years of war, Afghanistan will not be a perfect place...But Afghans like these are standing up for their country.\" \u2014@POTUS",
  "id" : 654677434596364288,
  "created_at" : "2015-10-15 15:17:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 129, 135 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654676839600816128",
  "text" : "\"This mission is vital to our national security interests in preventing terrorist attacks against our citizens and our nation.\" \u2014@POTUS",
  "id" : 654676839600816128,
  "created_at" : "2015-10-15 15:14:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654676691076280320",
  "text" : "\"To the Afghan people who have suffered so much, America\u2019s commitment to you\u2014and to a secure, stable and unified Afghanistan\u2014remains firm.\"",
  "id" : 654676691076280320,
  "created_at" : "2015-10-15 15:14:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654675776684494849",
  "text" : "RT @WHLive: \"I have decided to maintain our current posture of 9800 troops in Afghanistan through most of...2016. Their mission will not ch\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 134, 140 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "654675653439033344",
    "text" : "\"I have decided to maintain our current posture of 9800 troops in Afghanistan through most of...2016. Their mission will not change\" \u2014@POTUS",
    "id" : 654675653439033344,
    "created_at" : "2015-10-15 15:10:13 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 654675776684494849,
  "created_at" : "2015-10-15 15:10:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 123, 129 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654674775189516288",
  "text" : "\"As Commander in Chief, I will not allow Afghanistan to be used as safe haven for terrorists to attack our nation again.\" \u2014@POTUS",
  "id" : 654674775189516288,
  "created_at" : "2015-10-15 15:06:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 116, 122 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654674655458951168",
  "text" : "\"While America\u2019s combat mission in Afghanistan may be over, our commitment to Afghanistan and its people endures.\" \u2014@POTUS",
  "id" : 654674655458951168,
  "created_at" : "2015-10-15 15:06:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 86, 92 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654674275337547777",
  "text" : "\"Last December...America\u2019s combat mission in Afghanistan came to a responsible end.\" \u2014@POTUS",
  "id" : 654674275337547777,
  "created_at" : "2015-10-15 15:04:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 12, 18 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/lhuhl8Aso2",
      "expanded_url" : "http:\/\/go.wh.gov\/UHN5Cg",
      "display_url" : "go.wh.gov\/UHN5Cg"
    } ]
  },
  "geo" : { },
  "id_str" : "654650477720633344",
  "text" : "At 11am ET, @POTUS will deliver a statement on Afghanistan. Watch here \u2192 http:\/\/t.co\/lhuhl8Aso2",
  "id" : 654650477720633344,
  "created_at" : "2015-10-15 13:30:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 128, 134 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654445219300028416",
  "text" : "\"We\u2019ve got to support our artists...and do our part to ensure that the American creative spirit...will thrive for generations\" \u2014@POTUS",
  "id" : 654445219300028416,
  "created_at" : "2015-10-14 23:54:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 110, 116 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PBSipwh",
      "indices" : [ 117, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654444836683182080",
  "text" : "\"That quintessentially American creative spirit...that may be our greatest export. The American soundtrack.\" \u2014@POTUS #PBSipwh",
  "id" : 654444836683182080,
  "created_at" : "2015-10-14 23:53:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 113, 119 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PBSipwh",
      "indices" : [ 120, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654443695626944512",
  "text" : "RT @WHLive: \"Tonight, we honor the 50th anniversary of the National Endowments for the Arts and the Humanities\" \u2014@POTUS #PBSipwh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 101, 107 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PBSipwh",
        "indices" : [ 108, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "654443619261222912",
    "text" : "\"Tonight, we honor the 50th anniversary of the National Endowments for the Arts and the Humanities\" \u2014@POTUS #PBSipwh",
    "id" : 654443619261222912,
    "created_at" : "2015-10-14 23:48:12 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 654443695626944512,
  "created_at" : "2015-10-14 23:48:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 12, 18 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PBSipwh",
      "indices" : [ 116, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/L3RUxthqdc",
      "expanded_url" : "http:\/\/go.wh.gov\/Xav664",
      "display_url" : "go.wh.gov\/Xav664"
    } ]
  },
  "geo" : { },
  "id_str" : "654443393511260160",
  "text" : "Watch live: @POTUS hosts a celebration of American music and creativity at the White House \u2192 http:\/\/t.co\/L3RUxthqdc #PBSipwh",
  "id" : 654443393511260160,
  "created_at" : "2015-10-14 23:47:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nat'l Endow f\/t Arts",
      "screen_name" : "NEAarts",
      "indices" : [ 3, 11 ],
      "id_str" : "41655821",
      "id" : 41655821
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 36, 47 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "arts4US",
      "indices" : [ 116, 124 ]
    }, {
      "text" : "PBSipwh",
      "indices" : [ 125, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/DphjhXfnIY",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "654441259138875393",
  "text" : "RT @NEAarts: What a line-up tonight @WhiteHouse to celebrate the arts! Tune in at 7:20pm ET: http:\/\/t.co\/DphjhXfnIY #arts4US #PBSipwh #arts\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 23, 34 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "arts4US",
        "indices" : [ 103, 111 ]
      }, {
        "text" : "PBSipwh",
        "indices" : [ 112, 120 ]
      }, {
        "text" : "arts4us",
        "indices" : [ 121, 129 ]
      } ],
      "urls" : [ {
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/DphjhXfnIY",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "654322308501368832",
    "text" : "What a line-up tonight @WhiteHouse to celebrate the arts! Tune in at 7:20pm ET: http:\/\/t.co\/DphjhXfnIY #arts4US #PBSipwh #arts4us",
    "id" : 654322308501368832,
    "created_at" : "2015-10-14 15:46:09 +0000",
    "user" : {
      "name" : "Nat'l Endow f\/t Arts",
      "screen_name" : "NEAarts",
      "protected" : false,
      "id_str" : "41655821",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/648578057637261312\/Cz1-ruZg_normal.jpg",
      "id" : 41655821,
      "verified" : true
    }
  },
  "id" : 654441259138875393,
  "created_at" : "2015-10-14 23:38:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Esperanza Spalding",
      "screen_name" : "EspeSpalding",
      "indices" : [ 3, 16 ],
      "id_str" : "143754070",
      "id" : 143754070
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 71, 82 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/WtHMCIKGaX",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "654440341819420672",
  "text" : "RT @EspeSpalding: We're celebrating American creativity tonight at the @WhiteHouse. Tune in tonight at 7:20pm ET: http:\/\/t.co\/WtHMCIKGaX #A\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 53, 64 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AtTheWH",
        "indices" : [ 119, 127 ]
      }, {
        "text" : "PBSipwh",
        "indices" : [ 128, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/WtHMCIKGaX",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "654376216393289728",
    "text" : "We're celebrating American creativity tonight at the @WhiteHouse. Tune in tonight at 7:20pm ET: http:\/\/t.co\/WtHMCIKGaX #AtTheWH #PBSipwh",
    "id" : 654376216393289728,
    "created_at" : "2015-10-14 19:20:22 +0000",
    "user" : {
      "name" : "Esperanza Spalding",
      "screen_name" : "EspeSpalding",
      "protected" : false,
      "id_str" : "143754070",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/702925098123202564\/vbRRQ2Xw_normal.png",
      "id" : 143754070,
      "verified" : true
    }
  },
  "id" : 654440341819420672,
  "created_at" : "2015-10-14 23:35:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Usher Raymond IV",
      "screen_name" : "Usher",
      "indices" : [ 3, 9 ],
      "id_str" : "40908929",
      "id" : 40908929
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 26, 32 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 37, 44 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 66, 77 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AtTheWH",
      "indices" : [ 127, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/zYau0nq6lW",
      "expanded_url" : "http:\/\/wh.gov\/live",
      "display_url" : "wh.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "654439740641550336",
  "text" : "RT @Usher: Wanna join me, @POTUS and @FLOTUS for a concert at the @WhiteHouse? Watch here at 7:20pm ET: http:\/\/t.co\/zYau0nq6lW #AtTheWH #PB\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 15, 21 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "The First Lady",
        "screen_name" : "FLOTUS",
        "indices" : [ 26, 33 ],
        "id_str" : "1093090866",
        "id" : 1093090866
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 55, 66 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AtTheWH",
        "indices" : [ 116, 124 ]
      }, {
        "text" : "PBSipwh",
        "indices" : [ 125, 133 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/zYau0nq6lW",
        "expanded_url" : "http:\/\/wh.gov\/live",
        "display_url" : "wh.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "654415409203032065",
    "text" : "Wanna join me, @POTUS and @FLOTUS for a concert at the @WhiteHouse? Watch here at 7:20pm ET: http:\/\/t.co\/zYau0nq6lW #AtTheWH #PBSipwh",
    "id" : 654415409203032065,
    "created_at" : "2015-10-14 21:56:06 +0000",
    "user" : {
      "name" : "Usher Raymond IV",
      "screen_name" : "Usher",
      "protected" : false,
      "id_str" : "40908929",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/740943946646491137\/mEUrvXAO_normal.jpg",
      "id" : 40908929,
      "verified" : true
    }
  },
  "id" : 654439740641550336,
  "created_at" : "2015-10-14 23:32:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/L3RUxtz14K",
      "expanded_url" : "http:\/\/go.wh.gov\/Xav664",
      "display_url" : "go.wh.gov\/Xav664"
    }, {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/0rB7LiRxGi",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/6142ce3a-9e4a-4450-a75e-7d3093e1601b",
      "display_url" : "amp.twimg.com\/v\/6142ce3a-9e4\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "654433906029019136",
  "text" : "Get ready for tonight's In Performance with our favorite musical moments at the White House: http:\/\/t.co\/L3RUxtz14K\nhttps:\/\/t.co\/0rB7LiRxGi",
  "id" : 654433906029019136,
  "created_at" : "2015-10-14 23:09:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/654385638133788672\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/OuqiySFLtH",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CRTYGLCWcAEu6aX.png",
      "id_str" : "654385446429028353",
      "id" : 654385446429028353,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CRTYGLCWcAEu6aX.png",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/OuqiySFLtH"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 13, 26 ]
    } ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/VVI6byyA7h",
      "expanded_url" : "http:\/\/go.wh.gov\/ActOnClimate",
      "display_url" : "go.wh.gov\/ActOnClimate"
    } ]
  },
  "geo" : { },
  "id_str" : "654385638133788672",
  "text" : "It's time to #ActOnClimate.\nGet the latest on commitments from countries around the world \u2192 http:\/\/t.co\/VVI6byyA7h http:\/\/t.co\/OuqiySFLtH",
  "id" : 654385638133788672,
  "created_at" : "2015-10-14 19:57:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654359700109139968",
  "text" : "RT @vj44: 5\/5: States with universal background checks have nearly 40% fewer women who are murdered with a gun by an intimate partner #Stop\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "StopGunViolence",
        "indices" : [ 124, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "654349737676677121",
    "text" : "5\/5: States with universal background checks have nearly 40% fewer women who are murdered with a gun by an intimate partner #StopGunViolence",
    "id" : 654349737676677121,
    "created_at" : "2015-10-14 17:35:09 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 654359700109139968,
  "created_at" : "2015-10-14 18:14:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StopGunViolence",
      "indices" : [ 112, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654358994757255168",
  "text" : "RT @vj44: 4\/5: American women are 11 times more likely to be shot to death than women in other advanced nations #StopGunViolence",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "StopGunViolence",
        "indices" : [ 102, 118 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "654349649986371584",
    "text" : "4\/5: American women are 11 times more likely to be shot to death than women in other advanced nations #StopGunViolence",
    "id" : 654349649986371584,
    "created_at" : "2015-10-14 17:34:48 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 654358994757255168,
  "created_at" : "2015-10-14 18:11:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654358585833488385",
  "text" : "RT @vj44: 3\/5: In America, studies indicate that more than 1\/2 of women who are murdered by guns are murdered by a family member or intimat\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "654349586018996225",
    "text" : "3\/5: In America, studies indicate that more than 1\/2 of women who are murdered by guns are murdered by a family member or intimate partner",
    "id" : 654349586018996225,
    "created_at" : "2015-10-14 17:34:33 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 654358585833488385,
  "created_at" : "2015-10-14 18:10:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654357254469230592",
  "text" : "RT @vj44: 2\/5: In America, a woman is five times more likely to be killed if her abusive husband, boyfriend, or ex owns a gun. #StopGunViol\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "StopGunViolence",
        "indices" : [ 117, 133 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "654349483816431617",
    "text" : "2\/5: In America, a woman is five times more likely to be killed if her abusive husband, boyfriend, or ex owns a gun. #StopGunViolence",
    "id" : 654349483816431617,
    "created_at" : "2015-10-14 17:34:08 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 654357254469230592,
  "created_at" : "2015-10-14 18:05:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StopGunViolence",
      "indices" : [ 80, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654356042889994241",
  "text" : "RT @vj44: 1\/5: In America, one in four women are affected by domestic violence. #StopGunViolence",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "StopGunViolence",
        "indices" : [ 70, 86 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "654349448936562688",
    "text" : "1\/5: In America, one in four women are affected by domestic violence. #StopGunViolence",
    "id" : 654349448936562688,
    "created_at" : "2015-10-14 17:34:00 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 654356042889994241,
  "created_at" : "2015-10-14 18:00:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FreeCommunityCollege",
      "indices" : [ 93, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/SEGOA4jCOB",
      "expanded_url" : "http:\/\/HeadsUpAmerica.us\/Act",
      "display_url" : "HeadsUpAmerica.us\/Act"
    }, {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/IkRKvpbJ8H",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/f6e7d09f-1ef7-4133-ab51-7ddc3837a1f1",
      "display_url" : "amp.twimg.com\/v\/f6e7d09f-1ef\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "654344445698117632",
  "text" : "The average college graduate has $28,000 in debt.\nLet's change that \u2192 http:\/\/t.co\/SEGOA4jCOB #FreeCommunityCollege https:\/\/t.co\/IkRKvpbJ8H",
  "id" : 654344445698117632,
  "created_at" : "2015-10-14 17:14:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/SEGOA4jCOB",
      "expanded_url" : "http:\/\/HeadsUpAmerica.us\/Act",
      "display_url" : "HeadsUpAmerica.us\/Act"
    }, {
      "indices" : [ 113, 136 ],
      "url" : "https:\/\/t.co\/IkRKvpbJ8H",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/f6e7d09f-1ef7-4133-ab51-7ddc3837a1f1",
      "display_url" : "amp.twimg.com\/v\/f6e7d09f-1ef\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "654330718764572672",
  "text" : "Let's make two years of community college as free and universal as high school is today \u2192 http:\/\/t.co\/SEGOA4jCOB https:\/\/t.co\/IkRKvpbJ8H",
  "id" : 654330718764572672,
  "created_at" : "2015-10-14 16:19:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PeoplesClimate",
      "indices" : [ 100, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/xQDERBymp3",
      "expanded_url" : "http:\/\/wh.gov\/climate",
      "display_url" : "wh.gov\/climate"
    }, {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/GBSJ8hDkgd",
      "expanded_url" : "http:\/\/snpy.tv\/1STbXjG",
      "display_url" : "snpy.tv\/1STbXjG"
    } ]
  },
  "geo" : { },
  "id_str" : "654319230117130240",
  "text" : "RT if you agree: We can't condemn our kids to a planet that's beyond fixing. http:\/\/t.co\/xQDERBymp3 #PeoplesClimate\nhttp:\/\/t.co\/GBSJ8hDkgd",
  "id" : 654319230117130240,
  "created_at" : "2015-10-14 15:33:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "indices" : [ 3, 12 ],
      "id_str" : "1604366701",
      "id" : 1604366701
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LeadOnLeave",
      "indices" : [ 101, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654150875913584640",
  "text" : "RT @LaborSec: No one should have to choose between the family they love and the job they need. Let's #LeadOnLeave.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LeadOnLeave",
        "indices" : [ 87, 99 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "654125494196170752",
    "text" : "No one should have to choose between the family they love and the job they need. Let's #LeadOnLeave.",
    "id" : 654125494196170752,
    "created_at" : "2015-10-14 02:44:05 +0000",
    "user" : {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "protected" : false,
      "id_str" : "1604366701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744887280666611712\/eEeyFjs6_normal.jpg",
      "id" : 1604366701,
      "verified" : true
    }
  },
  "id" : 654150875913584640,
  "created_at" : "2015-10-14 04:24:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Chicago Cubs",
      "screen_name" : "Cubs",
      "indices" : [ 20, 25 ],
      "id_str" : "41144996",
      "id" : 41144996
    }, {
      "name" : "Chicago White Sox",
      "screen_name" : "whitesox",
      "indices" : [ 33, 42 ],
      "id_str" : "53197137",
      "id" : 53197137
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654099792759537664",
  "text" : "RT @POTUS: Congrats @Cubs - even @whitesox fans are rooting for you!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Chicago Cubs",
        "screen_name" : "Cubs",
        "indices" : [ 9, 14 ],
        "id_str" : "41144996",
        "id" : 41144996
      }, {
        "name" : "Chicago White Sox",
        "screen_name" : "whitesox",
        "indices" : [ 22, 31 ],
        "id_str" : "53197137",
        "id" : 53197137
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "654094154176315392",
    "text" : "Congrats @Cubs - even @whitesox fans are rooting for you!",
    "id" : 654094154176315392,
    "created_at" : "2015-10-14 00:39:33 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 654099792759537664,
  "created_at" : "2015-10-14 01:01:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654071718248448000",
  "text" : "RT @FLOTUS: \u201CEducation is the single most important stepping stone to power, freedom, and equality.\u201D \u2014The First Lady on the impact of #LetG\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LetGirlsLearn",
        "indices" : [ 122, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "654070424939155456",
    "text" : "\u201CEducation is the single most important stepping stone to power, freedom, and equality.\u201D \u2014The First Lady on the impact of #LetGirlsLearn.",
    "id" : 654070424939155456,
    "created_at" : "2015-10-13 23:05:16 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 654071718248448000,
  "created_at" : "2015-10-13 23:10:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654058126220505088",
  "text" : "RT @VP: Today VP Biden signed the condolence book for the Ankara terrorist attack at the Turkish Embassy in Washington, DC http:\/\/t.co\/ahKh\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/VP\/status\/654055582886952964\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/ahKhp7sCJN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CROsFBkWUAAC69T.jpg",
        "id_str" : "654055573219069952",
        "id" : 654055573219069952,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CROsFBkWUAAC69T.jpg",
        "sizes" : [ {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/ahKhp7sCJN"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "654055582886952964",
    "text" : "Today VP Biden signed the condolence book for the Ankara terrorist attack at the Turkish Embassy in Washington, DC http:\/\/t.co\/ahKhp7sCJN",
    "id" : 654055582886952964,
    "created_at" : "2015-10-13 22:06:17 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 654058126220505088,
  "created_at" : "2015-10-13 22:16:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 80, 86 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/654004147528839169\/photo\/1",
      "indices" : [ 119, 141 ],
      "url" : "http:\/\/t.co\/JuStIi45Pg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRN88x2WcAAg_Tr.jpg",
      "id_str" : "654003754514149376",
      "id" : 654003754514149376,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRN88x2WcAAg_Tr.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/JuStIi45Pg"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "654004147528839169",
  "text" : "\"He made his 32 years count, &amp; those of us who knew him are better for it\" \u2014@POTUS on the passing of Brandon Lepow http:\/\/t.co\/JuStIi45Pg",
  "id" : 654004147528839169,
  "created_at" : "2015-10-13 18:41:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "U.S. Navy",
      "screen_name" : "USNavy",
      "indices" : [ 29, 36 ],
      "id_str" : "54885400",
      "id" : 54885400
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "653999435815485440",
  "text" : "RT @VP: Happy 240th Birthday @USNavy. Thank you to all those who protect our freedom and serve with dignity and bravery. http:\/\/t.co\/3qZAas\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "U.S. Navy",
        "screen_name" : "USNavy",
        "indices" : [ 21, 28 ],
        "id_str" : "54885400",
        "id" : 54885400
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/653999171062636544\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/3qZAasE3kW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CRN4xp0WwAIe8-t.jpg",
        "id_str" : "653999165333225474",
        "id" : 653999165333225474,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRN4xp0WwAIe8-t.jpg",
        "sizes" : [ {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/3qZAasE3kW"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "653999171062636544",
    "text" : "Happy 240th Birthday @USNavy. Thank you to all those who protect our freedom and serve with dignity and bravery. http:\/\/t.co\/3qZAasE3kW",
    "id" : 653999171062636544,
    "created_at" : "2015-10-13 18:22:07 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 653999435815485440,
  "created_at" : "2015-10-13 18:23:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Enough",
      "indices" : [ 126, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "653997996691050496",
  "text" : "RT @Simas44: In the 12 days since Oregon shooting, at least 339 people killed &amp; 7 mass shootings. 10,343 deaths in 2015.  #Enough http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Simas44\/status\/653996670842093570\/photo\/1",
        "indices" : [ 121, 143 ],
        "url" : "http:\/\/t.co\/OwMCiH4XLl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CRN2gZ-UEAA4O_K.png",
        "id_str" : "653996669998993408",
        "id" : 653996669998993408,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRN2gZ-UEAA4O_K.png",
        "sizes" : [ {
          "h" : 655,
          "resize" : "fit",
          "w" : 398
        }, {
          "h" : 655,
          "resize" : "fit",
          "w" : 398
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 655,
          "resize" : "fit",
          "w" : 398
        }, {
          "h" : 560,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/OwMCiH4XLl"
      } ],
      "hashtags" : [ {
        "text" : "Enough",
        "indices" : [ 113, 120 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "653996670842093570",
    "text" : "In the 12 days since Oregon shooting, at least 339 people killed &amp; 7 mass shootings. 10,343 deaths in 2015.  #Enough http:\/\/t.co\/OwMCiH4XLl",
    "id" : 653996670842093570,
    "created_at" : "2015-10-13 18:12:11 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 653997996691050496,
  "created_at" : "2015-10-13 18:17:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "indices" : [ 3, 16 ],
      "id_str" : "78138151",
      "id" : 78138151
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "653960715271737345",
  "text" : "RT @lacasablanca: On Thursday, Cuba's legendary \"musical diplomats\" Buena Vista Social Club will perform at the White House \u2192 http:\/\/t.co\/4\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/4GutK8CKTw",
        "expanded_url" : "http:\/\/www.billboard.com\/articles\/columns\/latin\/6723088\/buena-vista-social-club-white-house",
        "display_url" : "billboard.com\/articles\/colum\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "653935825688875008",
    "text" : "On Thursday, Cuba's legendary \"musical diplomats\" Buena Vista Social Club will perform at the White House \u2192 http:\/\/t.co\/4GutK8CKTw",
    "id" : 653935825688875008,
    "created_at" : "2015-10-13 14:10:25 +0000",
    "user" : {
      "name" : "La Casa Blanca",
      "screen_name" : "lacasablanca",
      "protected" : false,
      "id_str" : "78138151",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616360382911754241\/4Tfqcfie_normal.png",
      "id" : 78138151,
      "verified" : true
    }
  },
  "id" : 653960715271737345,
  "created_at" : "2015-10-13 15:49:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "indices" : [ 62, 77 ],
      "id_str" : "19674502",
      "id" : 19674502
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/653927643520311296\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/NkCOEwwLbB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRM3GQkWIAE28u9.jpg",
      "id_str" : "653926951565008897",
      "id" : 653926951565008897,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRM3GQkWIAE28u9.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1202
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 511,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/NkCOEwwLbB"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 101, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/dQRvDzvIMy",
      "expanded_url" : "http:\/\/politi.co\/1R878D3",
      "display_url" : "politi.co\/1R878D3"
    } ]
  },
  "geo" : { },
  "id_str" : "653927643520311296",
  "text" : "\u201CWe face no greater long-term challenge than climate change\" \u2014@AmbassadorRice http:\/\/t.co\/dQRvDzvIMy #ActOnClimate http:\/\/t.co\/NkCOEwwLbB",
  "id" : 653927643520311296,
  "created_at" : "2015-10-13 13:37:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "indices" : [ 15, 30 ],
      "id_str" : "19674502",
      "id" : 19674502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "653756617956139009",
  "text" : "RT @NSCPress: .@AmbassadorRice: We face no greater long-term challenge than climate change--an advancing menace that imperils things we hop\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Susan Rice",
        "screen_name" : "AmbassadorRice",
        "indices" : [ 1, 16 ],
        "id_str" : "19674502",
        "id" : 19674502
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "653717608567545856",
    "text" : ".@AmbassadorRice: We face no greater long-term challenge than climate change--an advancing menace that imperils things we hope to achieve.",
    "id" : 653717608567545856,
    "created_at" : "2015-10-12 23:43:18 +0000",
    "user" : {
      "name" : "WH National Security",
      "screen_name" : "NSC44",
      "protected" : false,
      "id_str" : "369245377",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3397284308\/2c9d9df30426570f305d6dff675c2099_normal.jpeg",
      "id" : 369245377,
      "verified" : true
    }
  },
  "id" : 653756617956139009,
  "created_at" : "2015-10-13 02:18:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NY Review of Books",
      "screen_name" : "nybooks",
      "indices" : [ 3, 11 ],
      "id_str" : "11178902",
      "id" : 11178902
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/JQnjDtCoyP",
      "expanded_url" : "http:\/\/j.mp\/1hAoUmm",
      "display_url" : "j.mp\/1hAoUmm"
    } ]
  },
  "geo" : { },
  "id_str" : "653662221256499200",
  "text" : "RT @nybooks: Robinson: \u201CThe basis of democracy is the willingness to assume well about other people.\u201D http:\/\/t.co\/JQnjDtCoyP http:\/\/t.co\/zk\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/nybooks\/status\/653658744245649408\/photo\/1",
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/zkzBsl8HYh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CRJDKeSWIAApNiD.jpg",
        "id_str" : "653658743129907200",
        "id" : 653658743129907200,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRJDKeSWIAApNiD.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 2333,
          "resize" : "fit",
          "w" : 3500
        } ],
        "display_url" : "pic.twitter.com\/zkzBsl8HYh"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/JQnjDtCoyP",
        "expanded_url" : "http:\/\/j.mp\/1hAoUmm",
        "display_url" : "j.mp\/1hAoUmm"
      } ]
    },
    "geo" : { },
    "id_str" : "653658744245649408",
    "text" : "Robinson: \u201CThe basis of democracy is the willingness to assume well about other people.\u201D http:\/\/t.co\/JQnjDtCoyP http:\/\/t.co\/zkzBsl8HYh",
    "id" : 653658744245649408,
    "created_at" : "2015-10-12 19:49:23 +0000",
    "user" : {
      "name" : "NY Review of Books",
      "screen_name" : "nybooks",
      "protected" : false,
      "id_str" : "11178902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/542326799699439616\/IdpFSv8a_normal.png",
      "id" : 11178902,
      "verified" : true
    }
  },
  "id" : 653662221256499200,
  "created_at" : "2015-10-12 20:03:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "iTunes Podcasts",
      "screen_name" : "iTunesPodcasts",
      "indices" : [ 3, 18 ],
      "id_str" : "48436234",
      "id" : 48436234
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 37, 43 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "NY Review of Books",
      "screen_name" : "nybooks",
      "indices" : [ 74, 82 ],
      "id_str" : "11178902",
      "id" : 11178902
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/iTunesPodcasts\/status\/653638788904828928\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/sKT1Z1TnaR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRIxAu5UAAABLEa.jpg",
      "id_str" : "653638784580321280",
      "id" : 653638784580321280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRIxAu5UAAABLEa.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/sKT1Z1TnaR"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/iTunesPodcasts\/status\/653638788904828928\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/sKT1Z1TnaR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRIxA9dU8AAmuNP.jpg",
      "id_str" : "653638788489474048",
      "id" : 653638788489474048,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRIxA9dU8AAmuNP.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/sKT1Z1TnaR"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/tRXjC3wjV7",
      "expanded_url" : "http:\/\/tw.itunes.com\/6015B38tl",
      "display_url" : "tw.itunes.com\/6015B38tl"
    } ]
  },
  "geo" : { },
  "id_str" : "653654895380275200",
  "text" : "RT @iTunesPodcasts: Can't miss this! @POTUS talks books on Soundings from @nybooks. http:\/\/t.co\/tRXjC3wjV7 http:\/\/t.co\/sKT1Z1TnaR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 17, 23 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "NY Review of Books",
        "screen_name" : "nybooks",
        "indices" : [ 54, 62 ],
        "id_str" : "11178902",
        "id" : 11178902
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/iTunesPodcasts\/status\/653638788904828928\/photo\/1",
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/sKT1Z1TnaR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CRIxAu5UAAABLEa.jpg",
        "id_str" : "653638784580321280",
        "id" : 653638784580321280,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRIxAu5UAAABLEa.jpg",
        "sizes" : [ {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/sKT1Z1TnaR"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/iTunesPodcasts\/status\/653638788904828928\/photo\/1",
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/sKT1Z1TnaR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CRIxA9dU8AAmuNP.jpg",
        "id_str" : "653638788489474048",
        "id" : 653638788489474048,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRIxA9dU8AAmuNP.jpg",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/sKT1Z1TnaR"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/tRXjC3wjV7",
        "expanded_url" : "http:\/\/tw.itunes.com\/6015B38tl",
        "display_url" : "tw.itunes.com\/6015B38tl"
      } ]
    },
    "geo" : { },
    "id_str" : "653638788904828928",
    "text" : "Can't miss this! @POTUS talks books on Soundings from @nybooks. http:\/\/t.co\/tRXjC3wjV7 http:\/\/t.co\/sKT1Z1TnaR",
    "id" : 653638788904828928,
    "created_at" : "2015-10-12 18:30:05 +0000",
    "user" : {
      "name" : "iTunes Podcasts",
      "screen_name" : "iTunesPodcasts",
      "protected" : false,
      "id_str" : "48436234",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723954326725492736\/MkPy777M_normal.jpg",
      "id" : 48436234,
      "verified" : true
    }
  },
  "id" : 653654895380275200,
  "created_at" : "2015-10-12 19:34:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/653640596310110208\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/a0PBIFbDDH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRIyUNpWoAAMntD.jpg",
      "id_str" : "653640218764025856",
      "id" : 653640218764025856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRIyUNpWoAAMntD.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 633,
        "resize" : "fit",
        "w" : 950
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 633,
        "resize" : "fit",
        "w" : 950
      } ],
      "display_url" : "pic.twitter.com\/a0PBIFbDDH"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/UVIyi8nFyW",
      "expanded_url" : "http:\/\/go.wh.gov\/V47mnV",
      "display_url" : "go.wh.gov\/V47mnV"
    } ]
  },
  "geo" : { },
  "id_str" : "653640596310110208",
  "text" : ".@POTUS interviewed renowned novelist Marilynne Robinson.\nCheck out our favorite quotes \u2192 http:\/\/t.co\/UVIyi8nFyW http:\/\/t.co\/a0PBIFbDDH",
  "id" : 653640596310110208,
  "created_at" : "2015-10-12 18:37:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "60 Minutes",
      "screen_name" : "60Minutes",
      "indices" : [ 3, 13 ],
      "id_str" : "18812572",
      "id" : 18812572
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/60Minutes\/status\/653361269131616257\/photo\/1",
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/1giAAkbeFC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRE0nKNW8AEjJmd.jpg",
      "id_str" : "653361268305358849",
      "id" : 653361268305358849,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRE0nKNW8AEjJmd.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/1giAAkbeFC"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/6i3pVKfBHS",
      "expanded_url" : "http:\/\/cbsn.ws\/1K2Z3dn",
      "display_url" : "cbsn.ws\/1K2Z3dn"
    } ]
  },
  "geo" : { },
  "id_str" : "653390925675241474",
  "text" : "RT @60Minutes: Highlights, outtakes from Obama's 60 Minutes interview http:\/\/t.co\/6i3pVKfBHS http:\/\/t.co\/1giAAkbeFC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/60Minutes\/status\/653361269131616257\/photo\/1",
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/1giAAkbeFC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CRE0nKNW8AEjJmd.jpg",
        "id_str" : "653361268305358849",
        "id" : 653361268305358849,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRE0nKNW8AEjJmd.jpg",
        "sizes" : [ {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1920
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/1giAAkbeFC"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 77 ],
        "url" : "http:\/\/t.co\/6i3pVKfBHS",
        "expanded_url" : "http:\/\/cbsn.ws\/1K2Z3dn",
        "display_url" : "cbsn.ws\/1K2Z3dn"
      } ]
    },
    "geo" : { },
    "id_str" : "653361269131616257",
    "text" : "Highlights, outtakes from Obama's 60 Minutes interview http:\/\/t.co\/6i3pVKfBHS http:\/\/t.co\/1giAAkbeFC",
    "id" : 653361269131616257,
    "created_at" : "2015-10-12 00:07:20 +0000",
    "user" : {
      "name" : "60 Minutes",
      "screen_name" : "60Minutes",
      "protected" : false,
      "id_str" : "18812572",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/463397772071165953\/n_-jHyIO_normal.jpeg",
      "id" : 18812572,
      "verified" : true
    }
  },
  "id" : 653390925675241474,
  "created_at" : "2015-10-12 02:05:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 105, 111 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/e34xkCpfHV",
      "expanded_url" : "http:\/\/go.wh.gov\/QVC5HG",
      "display_url" : "go.wh.gov\/QVC5HG"
    } ]
  },
  "geo" : { },
  "id_str" : "653308344321507328",
  "text" : "\"We reached agreement on a new trade deal that promotes American values and protects American workers.\" \u2014@POTUS: http:\/\/t.co\/e34xkCpfHV",
  "id" : 653308344321507328,
  "created_at" : "2015-10-11 20:37:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Jerry Brown",
      "screen_name" : "JerryBrownGov",
      "indices" : [ 20, 34 ],
      "id_str" : "19418459",
      "id" : 19418459
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "653305399756615680",
  "text" : "RT @vj44: I applaud @JerryBrownGov &amp; California's effort to take steps to ensure that all eligible Americans take advantage of their right \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jerry Brown",
        "screen_name" : "JerryBrownGov",
        "indices" : [ 10, 24 ],
        "id_str" : "19418459",
        "id" : 19418459
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "653299708685737984",
    "text" : "I applaud @JerryBrownGov &amp; California's effort to take steps to ensure that all eligible Americans take advantage of their right to vote.",
    "id" : 653299708685737984,
    "created_at" : "2015-10-11 20:02:42 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 653305399756615680,
  "created_at" : "2015-10-11 20:25:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spotify",
      "screen_name" : "Spotify",
      "indices" : [ 31, 39 ],
      "id_str" : "17230018",
      "id" : 17230018
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 54, 61 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/653291173071732737\/photo\/1",
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/gZ1hHiJ5WK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRD00LGWUAAV6e-.jpg",
      "id_str" : "653291123138514944",
      "id" : 653291123138514944,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRD00LGWUAAV6e-.jpg",
      "sizes" : [ {
        "h" : 1867,
        "resize" : "fit",
        "w" : 2800
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/gZ1hHiJ5WK"
    } ],
    "hashtags" : [ {
      "text" : "DayOfTheGirl",
      "indices" : [ 10, 23 ]
    }, {
      "text" : "62MillionGirls",
      "indices" : [ 86, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/AtN5FTWhcP",
      "expanded_url" : "http:\/\/go.wh.gov\/FLOTUSplaylist",
      "display_url" : "go.wh.gov\/FLOTUSplaylist"
    } ]
  },
  "geo" : { },
  "id_str" : "653291173071732737",
  "text" : "Celebrate #DayOfTheGirl with a @Spotify playlist from @FLOTUS: http:\/\/t.co\/AtN5FTWhcP #62MillionGirls http:\/\/t.co\/gZ1hHiJ5WK",
  "id" : 653291173071732737,
  "created_at" : "2015-10-11 19:28:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "indices" : [ 3, 18 ],
      "id_str" : "19674502",
      "id" : 19674502
    }, {
      "name" : "Bloomberg Climate2",
      "screen_name" : "climate",
      "indices" : [ 48, 56 ],
      "id_str" : "783719151684685824",
      "id" : 783719151684685824
    }, {
      "name" : "Stanford University",
      "screen_name" : "Stanford",
      "indices" : [ 75, 84 ],
      "id_str" : "18036441",
      "id" : 18036441
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "653285226253287424",
  "text" : "RT @AmbassadorRice: You can tune-in to watch my @climate remarks live from @Stanford Monday at 4:30PM Pacific (7:30 Eastern): http:\/\/t.co\/P\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bloomberg Climate2",
        "screen_name" : "climate",
        "indices" : [ 28, 36 ],
        "id_str" : "783719151684685824",
        "id" : 783719151684685824
      }, {
        "name" : "Stanford University",
        "screen_name" : "Stanford",
        "indices" : [ 55, 64 ],
        "id_str" : "18036441",
        "id" : 18036441
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/PI4WJ2iuxk",
        "expanded_url" : "http:\/\/original.livestream.com\/stanford_webcast",
        "display_url" : "original.livestream.com\/stanford_webca\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "653273564250923008",
    "text" : "You can tune-in to watch my @climate remarks live from @Stanford Monday at 4:30PM Pacific (7:30 Eastern): http:\/\/t.co\/PI4WJ2iuxk",
    "id" : 653273564250923008,
    "created_at" : "2015-10-11 18:18:49 +0000",
    "user" : {
      "name" : "Susan Rice",
      "screen_name" : "AmbassadorRice",
      "protected" : false,
      "id_str" : "19674502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2245433940\/297681_10150417294436240_295915266239_10074516_1895344954_n_normal.jpg",
      "id" : 19674502,
      "verified" : true
    }
  },
  "id" : 653285226253287424,
  "created_at" : "2015-10-11 19:05:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kickstarter",
      "screen_name" : "kickstarter",
      "indices" : [ 3, 15 ],
      "id_str" : "16186995",
      "id" : 16186995
    }, {
      "name" : "Samantha Power",
      "screen_name" : "AmbassadorPower",
      "indices" : [ 103, 119 ],
      "id_str" : "1615463502",
      "id" : 1615463502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "653274477606912001",
  "text" : "RT @kickstarter: \u201CWhat\u2019s important is people knowing that their contribution will make a difference.\u201D \u2013@AmbassadorPower http:\/\/t.co\/nswRGdj\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Samantha Power",
        "screen_name" : "AmbassadorPower",
        "indices" : [ 86, 102 ],
        "id_str" : "1615463502",
        "id" : 1615463502
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AidRefugees",
        "indices" : [ 126, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 103, 125 ],
        "url" : "http:\/\/t.co\/nswRGdj9US",
        "expanded_url" : "http:\/\/kickstarter.com\/aidrefugees",
        "display_url" : "kickstarter.com\/aidrefugees"
      } ]
    },
    "geo" : { },
    "id_str" : "653206029187067904",
    "text" : "\u201CWhat\u2019s important is people knowing that their contribution will make a difference.\u201D \u2013@AmbassadorPower http:\/\/t.co\/nswRGdj9US #AidRefugees",
    "id" : 653206029187067904,
    "created_at" : "2015-10-11 13:50:27 +0000",
    "user" : {
      "name" : "Kickstarter",
      "screen_name" : "kickstarter",
      "protected" : false,
      "id_str" : "16186995",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796383165019459584\/Y3V1zs5C_normal.jpg",
      "id" : 16186995,
      "verified" : true
    }
  },
  "id" : 653274477606912001,
  "created_at" : "2015-10-11 18:22:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/e34xkCpfHV",
      "expanded_url" : "http:\/\/go.wh.gov\/QVC5HG",
      "display_url" : "go.wh.gov\/QVC5HG"
    } ]
  },
  "geo" : { },
  "id_str" : "653263071582879745",
  "text" : "President Obama's trade deal helps the middle class and puts American workers first \u2192 http:\/\/t.co\/e34xkCpfHV",
  "id" : 653263071582879745,
  "created_at" : "2015-10-11 17:37:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/653232605819637760\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/6hpjyhPM5C",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CRCkT79WoAA7PCN.jpg",
      "id_str" : "653202608388218880",
      "id" : 653202608388218880,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CRCkT79WoAA7PCN.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/6hpjyhPM5C"
    } ],
    "hashtags" : [ {
      "text" : "TPP",
      "indices" : [ 111, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "653232605819637760",
  "text" : "President Obama's trade deal includes the strongest environmental standards of any trade agreement in history. #TPP http:\/\/t.co\/6hpjyhPM5C",
  "id" : 653232605819637760,
  "created_at" : "2015-10-11 15:36:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 124, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/e34xkC7EQn",
      "expanded_url" : "http:\/\/go.wh.gov\/QVC5HG",
      "display_url" : "go.wh.gov\/QVC5HG"
    } ]
  },
  "geo" : { },
  "id_str" : "653202419887788033",
  "text" : "FACT: President Obama's trade deal eliminates more than 18,000 taxes on American goods and services. http:\/\/t.co\/e34xkC7EQn #MadeInAmerica",
  "id" : 653202419887788033,
  "created_at" : "2015-10-11 13:36:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/652951854880428032\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/xQq3SuAoss",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQ921WEWsAAGIUn.jpg",
      "id_str" : "652871129820999680",
      "id" : 652871129820999680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQ921WEWsAAGIUn.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/xQq3SuAoss"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/CFeJrPgZ4y",
      "expanded_url" : "http:\/\/go.wh.gov\/aFz8dP",
      "display_url" : "go.wh.gov\/aFz8dP"
    } ]
  },
  "geo" : { },
  "id_str" : "652951854880428032",
  "text" : "FACT: Jobs supported by American exports pay up to 18% more on average than other jobs \u2192 http:\/\/t.co\/CFeJrPgZ4y http:\/\/t.co\/xQq3SuAoss",
  "id" : 652951854880428032,
  "created_at" : "2015-10-10 21:00:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 98, 104 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/e34xkCpfHV",
      "expanded_url" : "http:\/\/go.wh.gov\/QVC5HG",
      "display_url" : "go.wh.gov\/QVC5HG"
    } ]
  },
  "geo" : { },
  "id_str" : "652929151670710273",
  "text" : "\"Our future depends not on what past trade deals did wrong, but on doing new trade deals right.\" \u2014@POTUS: http:\/\/t.co\/e34xkCpfHV",
  "id" : 652929151670710273,
  "created_at" : "2015-10-10 19:30:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WorldMentalHealthDay",
      "indices" : [ 3, 24 ]
    } ],
    "urls" : [ {
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/bhwLwZX7xp",
      "expanded_url" : "http:\/\/go.wh.gov\/jJDqjM",
      "display_url" : "go.wh.gov\/jJDqjM"
    } ]
  },
  "geo" : { },
  "id_str" : "652921887224385536",
  "text" : "On #WorldMentalHealthDay, join us in using data and building partnerships to strengthen awareness &amp; prevent suicide: http:\/\/t.co\/bhwLwZX7xp",
  "id" : 652921887224385536,
  "created_at" : "2015-10-10 19:01:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/652915772994416640\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/xgpFGsMdBo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQ92PwlWwAE0kh4.jpg",
      "id_str" : "652870484103708673",
      "id" : 652870484103708673,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQ92PwlWwAE0kh4.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/xgpFGsMdBo"
    } ],
    "hashtags" : [ {
      "text" : "TPP",
      "indices" : [ 103, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/CFeJrPgZ4y",
      "expanded_url" : "http:\/\/go.wh.gov\/aFz8dP",
      "display_url" : "go.wh.gov\/aFz8dP"
    } ]
  },
  "geo" : { },
  "id_str" : "652915772994416640",
  "text" : "RT if you agree: It's time to help our businesses sell more American products \u2192 http:\/\/t.co\/CFeJrPgZ4y #TPP http:\/\/t.co\/xgpFGsMdBo",
  "id" : 652915772994416640,
  "created_at" : "2015-10-10 18:37:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/652899929149435904\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/IqiRP3oxyI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQ91qsDW8AAwQxO.jpg",
      "id_str" : "652869847232212992",
      "id" : 652869847232212992,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQ91qsDW8AAwQxO.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/IqiRP3oxyI"
    } ],
    "hashtags" : [ {
      "text" : "TPP",
      "indices" : [ 110, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/CFeJrPgZ4y",
      "expanded_url" : "http:\/\/go.wh.gov\/aFz8dP",
      "display_url" : "go.wh.gov\/aFz8dP"
    } ]
  },
  "geo" : { },
  "id_str" : "652899929149435904",
  "text" : "More exports = more U.S. jobs.\nLet's help our businesses sell more American products \u2192 http:\/\/t.co\/CFeJrPgZ4y #TPP http:\/\/t.co\/IqiRP3oxyI",
  "id" : 652899929149435904,
  "created_at" : "2015-10-10 17:34:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/tUnsIQAlAQ",
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/651432624062238720",
      "display_url" : "twitter.com\/WhiteHouse\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "652893646551941120",
  "text" : "Note: The current tariff on U.S. cherries in Vietnam is 10%. We are updating the video to reflect this change. https:\/\/t.co\/tUnsIQAlAQ",
  "id" : 652893646551941120,
  "created_at" : "2015-10-10 17:09:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 84, 90 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TPP",
      "indices" : [ 133, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/e34xkCpfHV",
      "expanded_url" : "http:\/\/go.wh.gov\/QVC5HG",
      "display_url" : "go.wh.gov\/QVC5HG"
    } ]
  },
  "geo" : { },
  "id_str" : "652884058599325696",
  "text" : "\"Our workers will be the ones who get ahead.\nOur businesses will get a fair deal.\"\n\u2014@POTUS on his trade deal: http:\/\/t.co\/e34xkCpfHV #TPP",
  "id" : 652884058599325696,
  "created_at" : "2015-10-10 16:31:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diana Doukas",
      "screen_name" : "Diana44",
      "indices" : [ 3, 11 ],
      "id_str" : "3274836392",
      "id" : 3274836392
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 71, 77 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/PoCKV9wRQw",
      "expanded_url" : "http:\/\/go.wh.gov\/QVC5HG",
      "display_url" : "go.wh.gov\/QVC5HG"
    } ]
  },
  "geo" : { },
  "id_str" : "652876155310223361",
  "text" : "RT @Diana44: \"95% of the world\u2019s consumers live outside our borders.\" \u2014@POTUS on the importance of his trade deal: http:\/\/t.co\/PoCKV9wRQw #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 58, 64 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MadeInAmerica",
        "indices" : [ 125, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/PoCKV9wRQw",
        "expanded_url" : "http:\/\/go.wh.gov\/QVC5HG",
        "display_url" : "go.wh.gov\/QVC5HG"
      } ]
    },
    "geo" : { },
    "id_str" : "652876083415642112",
    "text" : "\"95% of the world\u2019s consumers live outside our borders.\" \u2014@POTUS on the importance of his trade deal: http:\/\/t.co\/PoCKV9wRQw #MadeInAmerica",
    "id" : 652876083415642112,
    "created_at" : "2015-10-10 15:59:22 +0000",
    "user" : {
      "name" : "Diana Doukas",
      "screen_name" : "Diana44",
      "protected" : false,
      "id_str" : "3274836392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/671831357371191296\/CQ0VNiYR_normal.jpg",
      "id" : 3274836392,
      "verified" : true
    }
  },
  "id" : 652876155310223361,
  "created_at" : "2015-10-10 15:59:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 108, 114 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/e34xkC7EQn",
      "expanded_url" : "http:\/\/go.wh.gov\/QVC5HG",
      "display_url" : "go.wh.gov\/QVC5HG"
    } ]
  },
  "geo" : { },
  "id_str" : "652869030022352896",
  "text" : "\"When the playing field is level, and the rules are fair, Americans can out-compete anybody in the world.\" \u2014@POTUS: http:\/\/t.co\/e34xkC7EQn",
  "id" : 652869030022352896,
  "created_at" : "2015-10-10 15:31:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/652625397343985664\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/9JtbSZ3eWH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQ6VAG0UAAAuktU.jpg",
      "id_str" : "652622825077866496",
      "id" : 652622825077866496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQ6VAG0UAAAuktU.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1407,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 422,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 239,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/9JtbSZ3eWH"
    } ],
    "hashtags" : [ {
      "text" : "BreastCancerAwareness",
      "indices" : [ 91, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "652625397343985664",
  "text" : "1 in 8 women in America develop breast cancer.\nWe lit the White House pink in their honor. #BreastCancerAwareness http:\/\/t.co\/9JtbSZ3eWH",
  "id" : 652625397343985664,
  "created_at" : "2015-10-09 23:23:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 21, 32 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/652620269631205376\/photo\/1",
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/GVxve4QlMI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQ6SpUJWgAAhA4G.jpg",
      "id_str" : "652620234495524864",
      "id" : 652620234495524864,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQ6SpUJWgAAhA4G.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1406,
        "resize" : "fit",
        "w" : 2500
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/GVxve4QlMI"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "652620558530650113",
  "text" : "RT @vj44: We lit the @WhiteHouse pink tonight to commemorate Breast\nCancer Awareness Month. http:\/\/t.co\/GVxve4QlMI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 11, 22 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/652620269631205376\/photo\/1",
        "indices" : [ 82, 104 ],
        "url" : "http:\/\/t.co\/GVxve4QlMI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQ6SpUJWgAAhA4G.jpg",
        "id_str" : "652620234495524864",
        "id" : 652620234495524864,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQ6SpUJWgAAhA4G.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1406,
          "resize" : "fit",
          "w" : 2500
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/GVxve4QlMI"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "652620269631205376",
    "text" : "We lit the @WhiteHouse pink tonight to commemorate Breast\nCancer Awareness Month. http:\/\/t.co\/GVxve4QlMI",
    "id" : 652620269631205376,
    "created_at" : "2015-10-09 23:02:52 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 652620558530650113,
  "created_at" : "2015-10-09 23:04:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 3, 11 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 85, 88 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BreastCancerAwarenessMonth",
      "indices" : [ 17, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "652614732029915136",
  "text" : "RT @DrBiden: For #BreastCancerAwarenessMonth, we\u2019re lighting the anchors pink at the @VP\u2019s residence at the Naval Observatory. http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vice President Biden",
        "screen_name" : "VP",
        "indices" : [ 72, 75 ],
        "id_str" : "325830217",
        "id" : 325830217
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/DrBiden\/status\/652610757243346945\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/IlxG68VKKd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQ6J-nmW8AA2xt-.jpg",
        "id_str" : "652610704890064896",
        "id" : 652610704890064896,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQ6J-nmW8AA2xt-.jpg",
        "sizes" : [ {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/IlxG68VKKd"
      } ],
      "hashtags" : [ {
        "text" : "BreastCancerAwarenessMonth",
        "indices" : [ 4, 31 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "652610757243346945",
    "text" : "For #BreastCancerAwarenessMonth, we\u2019re lighting the anchors pink at the @VP\u2019s residence at the Naval Observatory. http:\/\/t.co\/IlxG68VKKd",
    "id" : 652610757243346945,
    "created_at" : "2015-10-09 22:25:04 +0000",
    "user" : {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "protected" : false,
      "id_str" : "1281405877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608687663034474496\/wvzVG_yt_normal.jpg",
      "id" : 1281405877,
      "verified" : true
    }
  },
  "id" : 652614732029915136,
  "created_at" : "2015-10-09 22:40:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "652508917843537920",
  "text" : "RT @vj44: Check out my conversation with @YahooParenting on how you can have it all, but not all at once #NoShameParenting http:\/\/t.co\/PI1B\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NoShameParenting",
        "indices" : [ 95, 112 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/PI1BvjqqfM",
        "expanded_url" : "http:\/\/yhoo.it\/1WR9r18",
        "display_url" : "yhoo.it\/1WR9r18"
      } ]
    },
    "geo" : { },
    "id_str" : "652481877673177088",
    "text" : "Check out my conversation with @YahooParenting on how you can have it all, but not all at once #NoShameParenting http:\/\/t.co\/PI1BvjqqfM",
    "id" : 652481877673177088,
    "created_at" : "2015-10-09 13:52:56 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 652508917843537920,
  "created_at" : "2015-10-09 15:40:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 85, 91 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ImmigrationReform",
      "indices" : [ 92, 110 ]
    }, {
      "text" : "CHCI",
      "indices" : [ 111, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/62qSr87qf0",
      "expanded_url" : "http:\/\/snpy.tv\/1LpUc7c",
      "display_url" : "snpy.tv\/1LpUc7c"
    } ]
  },
  "geo" : { },
  "id_str" : "652280955105878016",
  "text" : "\"A clear majority of Americans\u2014including a lot of Republican voters\u2014support reform\" \u2014@POTUS #ImmigrationReform #CHCI http:\/\/t.co\/62qSr87qf0",
  "id" : 652280955105878016,
  "created_at" : "2015-10-09 00:34:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 87, 93 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/652276618262638592\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/2iTrfBHQmn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQ1aE1TU8AA_G_j.jpg",
      "id_str" : "652276560112709632",
      "id" : 652276560112709632,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQ1aE1TU8AA_G_j.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/2iTrfBHQmn"
    } ],
    "hashtags" : [ {
      "text" : "FreeCommunityCollege",
      "indices" : [ 94, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "652276618262638592",
  "text" : "\u201CWe need to make two years of college as free and universal as high school is today.\u201D \u2014@POTUS #FreeCommunityCollege http:\/\/t.co\/2iTrfBHQmn",
  "id" : 652276618262638592,
  "created_at" : "2015-10-09 00:17:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 104, 110 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CHCI",
      "indices" : [ 111, 116 ]
    }, {
      "text" : "Immigration",
      "indices" : [ 117, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "652276053650575360",
  "text" : "\"America\u2019s greatness doesn\u2019t come from building walls. Our greatness comes from building opportunity.\" \u2014@POTUS #CHCI #Immigration",
  "id" : 652276053650575360,
  "created_at" : "2015-10-09 00:15:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 40, 46 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/652274179690098688\/photo\/1",
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/h2vpuQt8aU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQ1X1ioWwAAVL21.jpg",
      "id_str" : "652274098379341824",
      "id" : 652274098379341824,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQ1X1ioWwAAVL21.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/h2vpuQt8aU"
    } ],
    "hashtags" : [ {
      "text" : "CHCI",
      "indices" : [ 71, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 48, 70 ],
      "url" : "http:\/\/t.co\/K7PDuYJAvr",
      "expanded_url" : "http:\/\/go.wh.gov\/CHCI",
      "display_url" : "go.wh.gov\/CHCI"
    } ]
  },
  "geo" : { },
  "id_str" : "652274179690098688",
  "text" : "\u201CThe deficits are down by two-thirds.\u201D \u2014@POTUS: http:\/\/t.co\/K7PDuYJAvr #CHCI http:\/\/t.co\/h2vpuQt8aU",
  "id" : 652274179690098688,
  "created_at" : "2015-10-09 00:07:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 77, 83 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/652273406935744512\/photo\/1",
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/CJ4xCL7t87",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQ1XL5GWoAAbInW.jpg",
      "id_str" : "652273382856237056",
      "id" : 652273382856237056,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQ1XL5GWoAAbInW.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/CJ4xCL7t87"
    } ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 84, 93 ]
    }, {
      "text" : "CHCI",
      "indices" : [ 94, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "652273406935744512",
  "text" : "\"We\u2019ve covered another 17 million Americans\u2014including 4 million Hispanics.\" \u2014@POTUS #ACAWorks #CHCI http:\/\/t.co\/CJ4xCL7t87",
  "id" : 652273406935744512,
  "created_at" : "2015-10-09 00:04:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 98, 104 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/652273163594780672\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/CkmYOHHUmD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQ1W9o5WEAA7emb.jpg",
      "id_str" : "652273137988538368",
      "id" : 652273137988538368,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQ1W9o5WEAA7emb.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/CkmYOHHUmD"
    } ],
    "hashtags" : [ {
      "text" : "CHCI",
      "indices" : [ 105, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "652273163594780672",
  "text" : "\"Our businesses have created jobs for a record 67 months in a row\u2014more than 13 million new jobs\" \u2014@POTUS #CHCI http:\/\/t.co\/CkmYOHHUmD",
  "id" : 652273163594780672,
  "created_at" : "2015-10-09 00:03:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 86, 92 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/652272992488161280\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/mVhKC9HEIy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQ1W0ulWgAAymhx.jpg",
      "id_str" : "652272984896471040",
      "id" : 652272984896471040,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQ1W0ulWgAAymhx.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/mVhKC9HEIy"
    } ],
    "hashtags" : [ {
      "text" : "CHCI",
      "indices" : [ 93, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "652272992488161280",
  "text" : "\u201CWhen I took office, the unemployment rate was on its way to 10%. Today, it\u2019s 5.1%.\u201D \u2014@POTUS #CHCI http:\/\/t.co\/mVhKC9HEIy",
  "id" : 652272992488161280,
  "created_at" : "2015-10-09 00:02:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 12, 18 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CHCI",
      "indices" : [ 103, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/K7PDuYJAvr",
      "expanded_url" : "http:\/\/go.wh.gov\/CHCI",
      "display_url" : "go.wh.gov\/CHCI"
    } ]
  },
  "geo" : { },
  "id_str" : "652272819942854658",
  "text" : "Watch live: @POTUS speaks at the Congressional Hispanic Caucus Institute Gala \u2192 http:\/\/t.co\/K7PDuYJAvr #CHCI",
  "id" : 652272819942854658,
  "created_at" : "2015-10-09 00:02:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 101, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/9GxPOPUoUU",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/355d6536-ccaf-42e2-b407-fa2179409ad3",
      "display_url" : "amp.twimg.com\/v\/355d6536-cca\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "652256981999333376",
  "text" : "FACT: President Obama's trade deal would ELIMINATE more than 18,000 taxes on U.S. products overseas. #MadeInAmerica https:\/\/t.co\/9GxPOPUoUU",
  "id" : 652256981999333376,
  "created_at" : "2015-10-08 22:59:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 84, 90 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/1HwsI34w4D",
      "expanded_url" : "http:\/\/AidRefugees.gov",
      "display_url" : "AidRefugees.gov"
    }, {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/SiTuAckBr1",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/a8101987-028f-4b4f-a32b-a303ceca78be",
      "display_url" : "amp.twimg.com\/v\/a8101987-028\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "652227057405984768",
  "text" : "\"The United States of America will always be a beacon of hope to all who need it.\" \u2014@POTUS: http:\/\/t.co\/1HwsI34w4D https:\/\/t.co\/SiTuAckBr1",
  "id" : 652227057405984768,
  "created_at" : "2015-10-08 21:00:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "indices" : [ 71, 81 ],
      "id_str" : "15007149",
      "id" : 15007149
    }, {
      "name" : "Mike Bloomberg",
      "screen_name" : "MikeBloomberg",
      "indices" : [ 86, 100 ],
      "id_str" : "16581604",
      "id" : 16581604
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 125, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/agi47Pvmt7",
      "expanded_url" : "http:\/\/bv.ms\/1NpdIrb",
      "display_url" : "bv.ms\/1NpdIrb"
    } ]
  },
  "geo" : { },
  "id_str" : "652217484980932609",
  "text" : "\"City by city, country by country\u2014we can meet this global challenge.\" \u2014@JohnKerry and @MikeBloomberg: http:\/\/t.co\/agi47Pvmt7 #ActOnClimate",
  "id" : 652217484980932609,
  "created_at" : "2015-10-08 20:22:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "indices" : [ 3, 11 ],
      "id_str" : "1530850933",
      "id" : 1530850933
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thenew10",
      "indices" : [ 107, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 118, 141 ],
      "url" : "https:\/\/t.co\/WdwHoWRjIm",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=-nb690SKAe4",
      "display_url" : "youtube.com\/watch?v=-nb690\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "652208204777160704",
  "text" : "RT @GinaEPA: Which women from our nation's history inspire you? Share their stories &amp; they could be on #thenew10! https:\/\/t.co\/WdwHoWRjIm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "thenew10",
        "indices" : [ 94, 103 ]
      } ],
      "urls" : [ {
        "indices" : [ 105, 128 ],
        "url" : "https:\/\/t.co\/WdwHoWRjIm",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=-nb690SKAe4",
        "display_url" : "youtube.com\/watch?v=-nb690\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "652152040475357184",
    "text" : "Which women from our nation's history inspire you? Share their stories &amp; they could be on #thenew10! https:\/\/t.co\/WdwHoWRjIm",
    "id" : 652152040475357184,
    "created_at" : "2015-10-08 16:02:17 +0000",
    "user" : {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "protected" : false,
      "id_str" : "1530850933",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/632229333130604548\/Bb4I34DU_normal.jpg",
      "id" : 1530850933,
      "verified" : true
    }
  },
  "id" : 652208204777160704,
  "created_at" : "2015-10-08 19:45:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StopGunViolence",
      "indices" : [ 98, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/eoz4mT2cDr",
      "expanded_url" : "http:\/\/snpy.tv\/1O9tFA3",
      "display_url" : "snpy.tv\/1O9tFA3"
    } ]
  },
  "geo" : { },
  "id_str" : "652201032487968771",
  "text" : "There is a gun for roughly every man, woman, and child in America.\nIt's time for Congress to help #StopGunViolence. http:\/\/t.co\/eoz4mT2cDr",
  "id" : 652201032487968771,
  "created_at" : "2015-10-08 19:16:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StopGunViolence",
      "indices" : [ 80, 96 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/eoz4mT2cDr",
      "expanded_url" : "http:\/\/snpy.tv\/1O9tFA3",
      "display_url" : "snpy.tv\/1O9tFA3"
    } ]
  },
  "geo" : { },
  "id_str" : "652190436136734720",
  "text" : "America is the only advanced country that sees mass shootings every few months. #StopGunViolence http:\/\/t.co\/eoz4mT2cDr",
  "id" : 652190436136734720,
  "created_at" : "2015-10-08 18:34:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 3, 11 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "652154793612341248",
  "text" : "RT @DrBiden: Today, and every day, we keep in our hearts all of the students, teachers, friends, parents &amp; children taken too soon from us.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IamUCC",
        "indices" : [ 131, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "652153455356702720",
    "text" : "Today, and every day, we keep in our hearts all of the students, teachers, friends, parents &amp; children taken too soon from us. #IamUCC \u2013Jill",
    "id" : 652153455356702720,
    "created_at" : "2015-10-08 16:07:54 +0000",
    "user" : {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "protected" : false,
      "id_str" : "1281405877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608687663034474496\/wvzVG_yt_normal.jpg",
      "id" : 1281405877,
      "verified" : true
    }
  },
  "id" : 652154793612341248,
  "created_at" : "2015-10-08 16:13:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Murphy",
      "screen_name" : "ChrisMurphyCT",
      "indices" : [ 3, 17 ],
      "id_str" : "150078976",
      "id" : 150078976
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "stopgunviolence",
      "indices" : [ 118, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "652152728085381121",
  "text" : "RT @ChrisMurphyCT: For too long our inaction has made us complicit in these murders. We will not be silent any longer #stopgunviolence http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ChrisMurphyCT\/status\/652144214638112770\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/z21qwwQxAL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQzhsvLUkAEZ_He.jpg",
        "id_str" : "652144204756324353",
        "id" : 652144204756324353,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQzhsvLUkAEZ_He.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 490,
          "resize" : "fit",
          "w" : 980
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 490,
          "resize" : "fit",
          "w" : 980
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/z21qwwQxAL"
      } ],
      "hashtags" : [ {
        "text" : "stopgunviolence",
        "indices" : [ 99, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "652144214638112770",
    "text" : "For too long our inaction has made us complicit in these murders. We will not be silent any longer #stopgunviolence http:\/\/t.co\/z21qwwQxAL",
    "id" : 652144214638112770,
    "created_at" : "2015-10-08 15:31:11 +0000",
    "user" : {
      "name" : "Chris Murphy",
      "screen_name" : "ChrisMurphyCT",
      "protected" : false,
      "id_str" : "150078976",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738767780246396928\/YrcsMalf_normal.jpg",
      "id" : 150078976,
      "verified" : true
    }
  },
  "id" : 652152728085381121,
  "created_at" : "2015-10-08 16:05:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Senator Harry Reid",
      "screen_name" : "SenatorReid",
      "indices" : [ 3, 15 ],
      "id_str" : "16789970",
      "id" : 16789970
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StopGunViolence",
      "indices" : [ 95, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/yAXaRGrfKa",
      "expanded_url" : "https:\/\/twitter.com\/SenateDems\/status\/652136077382127617",
      "display_url" : "twitter.com\/SenateDems\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "652150919287607296",
  "text" : "RT @SenatorReid: It is time for more than just condolences and prayers. It is time for action. #StopGunViolence https:\/\/t.co\/yAXaRGrfKa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "StopGunViolence",
        "indices" : [ 78, 94 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/yAXaRGrfKa",
        "expanded_url" : "https:\/\/twitter.com\/SenateDems\/status\/652136077382127617",
        "display_url" : "twitter.com\/SenateDems\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "652136643554492416",
    "text" : "It is time for more than just condolences and prayers. It is time for action. #StopGunViolence https:\/\/t.co\/yAXaRGrfKa",
    "id" : 652136643554492416,
    "created_at" : "2015-10-08 15:01:06 +0000",
    "user" : {
      "name" : "Senator Harry Reid",
      "screen_name" : "SenatorReid",
      "protected" : false,
      "id_str" : "16789970",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/628307865065816064\/OUQh91yr_normal.jpg",
      "id" : 16789970,
      "verified" : true
    }
  },
  "id" : 652150919287607296,
  "created_at" : "2015-10-08 15:57:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Kara Swisher",
      "screen_name" : "karaswisher",
      "indices" : [ 24, 36 ],
      "id_str" : "5763262",
      "id" : 5763262
    }, {
      "name" : "Recode",
      "screen_name" : "Recode",
      "indices" : [ 41, 48 ],
      "id_str" : "2244340904",
      "id" : 2244340904
    }, {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 79, 87 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/C6xq7DF4mA",
      "expanded_url" : "http:\/\/on.recode.net\/1NpAXBe",
      "display_url" : "on.recode.net\/1NpAXBe"
    } ]
  },
  "geo" : { },
  "id_str" : "652144716436275200",
  "text" : "RT @vj44: Great joining @KaraSwisher and @Recode to talk tech, government, and @Twitter. Check out our conversation \u2192 http:\/\/t.co\/C6xq7DF4mA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kara Swisher",
        "screen_name" : "karaswisher",
        "indices" : [ 14, 26 ],
        "id_str" : "5763262",
        "id" : 5763262
      }, {
        "name" : "Recode",
        "screen_name" : "Recode",
        "indices" : [ 31, 38 ],
        "id_str" : "2244340904",
        "id" : 2244340904
      }, {
        "name" : "Twitter",
        "screen_name" : "twitter",
        "indices" : [ 69, 77 ],
        "id_str" : "783214",
        "id" : 783214
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/C6xq7DF4mA",
        "expanded_url" : "http:\/\/on.recode.net\/1NpAXBe",
        "display_url" : "on.recode.net\/1NpAXBe"
      } ]
    },
    "geo" : { },
    "id_str" : "652127709670146048",
    "text" : "Great joining @KaraSwisher and @Recode to talk tech, government, and @Twitter. Check out our conversation \u2192 http:\/\/t.co\/C6xq7DF4mA",
    "id" : 652127709670146048,
    "created_at" : "2015-10-08 14:25:36 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 652144716436275200,
  "created_at" : "2015-10-08 15:33:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AidRefugees",
      "indices" : [ 50, 62 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/1HwsI34w4D",
      "expanded_url" : "http:\/\/AidRefugees.gov",
      "display_url" : "AidRefugees.gov"
    }, {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/SiTuAckBr1",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/a8101987-028f-4b4f-a32b-a303ceca78be",
      "display_url" : "amp.twimg.com\/v\/a8101987-028\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "652139441935376385",
  "text" : "Thank you to every American who has stepped up to #AidRefugees. You can join them at http:\/\/t.co\/1HwsI34w4D\nhttps:\/\/t.co\/SiTuAckBr1",
  "id" : 652139441935376385,
  "created_at" : "2015-10-08 15:12:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reuters Top News",
      "screen_name" : "Reuters",
      "indices" : [ 3, 11 ],
      "id_str" : "1652541",
      "id" : 1652541
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/sHUHnzk540",
      "expanded_url" : "http:\/\/reut.rs\/1jc2QiZ",
      "display_url" : "reut.rs\/1jc2QiZ"
    } ]
  },
  "geo" : { },
  "id_str" : "652113808639574016",
  "text" : "RT @Reuters: U.S. jobless claims fall to near 42-year low http:\/\/t.co\/sHUHnzk540",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 67 ],
        "url" : "http:\/\/t.co\/sHUHnzk540",
        "expanded_url" : "http:\/\/reut.rs\/1jc2QiZ",
        "display_url" : "reut.rs\/1jc2QiZ"
      } ]
    },
    "geo" : { },
    "id_str" : "652100736638185472",
    "text" : "U.S. jobless claims fall to near 42-year low http:\/\/t.co\/sHUHnzk540",
    "id" : 652100736638185472,
    "created_at" : "2015-10-08 12:38:25 +0000",
    "user" : {
      "name" : "Reuters Top News",
      "screen_name" : "Reuters",
      "protected" : false,
      "id_str" : "1652541",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3379693153\/1008914c0ae75c9efb5f9c0161fce9a2_normal.png",
      "id" : 1652541,
      "verified" : true
    }
  },
  "id" : 652113808639574016,
  "created_at" : "2015-10-08 13:30:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/651932943749877761\/photo\/1",
      "indices" : [ 120, 142 ],
      "url" : "http:\/\/t.co\/QVmYvoixgZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQwgpa2WIAAnVto.jpg",
      "id_str" : "651931942015868928",
      "id" : 651931942015868928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQwgpa2WIAAnVto.jpg",
      "sizes" : [ {
        "h" : 1867,
        "resize" : "fit",
        "w" : 2800
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/QVmYvoixgZ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651932943749877761",
  "text" : "Terrence worked two decades &amp; makes just $8\/hr.\n\nEvery hardworking American should earn enough to support a family. http:\/\/t.co\/QVmYvoixgZ",
  "id" : 651932943749877761,
  "created_at" : "2015-10-08 01:31:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 29, 35 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651915121846013952",
  "text" : "RT @vj44: Love this photo of @POTUS greeting Terrence's mom, who has a lot to be proud of in her remarkable organizer of a son. http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 19, 25 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/651899316827590657\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/cwltTuFFec",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQwC-VEWoAEh-mg.jpg",
        "id_str" : "651899315892428801",
        "id" : 651899315892428801,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQwC-VEWoAEh-mg.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1867,
          "resize" : "fit",
          "w" : 2800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/cwltTuFFec"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "651899316827590657",
    "text" : "Love this photo of @POTUS greeting Terrence's mom, who has a lot to be proud of in her remarkable organizer of a son. http:\/\/t.co\/cwltTuFFec",
    "id" : 651899316827590657,
    "created_at" : "2015-10-07 23:18:03 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 651915121846013952,
  "created_at" : "2015-10-08 00:20:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/rc0XBdfLFy",
      "expanded_url" : "https:\/\/twitter.com\/POTUS\/status\/648543139196743680",
      "display_url" : "twitter.com\/POTUS\/status\/6\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "651905797484605440",
  "text" : "This tweet should read: We're increasing the # of refugees we admit on an annual basis to 100k by the end of FY17. https:\/\/t.co\/rc0XBdfLFy",
  "id" : 651905797484605440,
  "created_at" : "2015-10-07 23:43:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 82, 88 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/651892599045926912\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/iQieo4BxDK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQv82RYWoAART0b.jpg",
      "id_str" : "651892580393852928",
      "id" : 651892580393852928,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQv82RYWoAART0b.jpg",
      "sizes" : [ {
        "h" : 741,
        "resize" : "fit",
        "w" : 565
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 741,
        "resize" : "fit",
        "w" : 565
      }, {
        "h" : 741,
        "resize" : "fit",
        "w" : 565
      }, {
        "h" : 446,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/iQieo4BxDK"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651892599045926912",
  "text" : "\"May God bless the men and women of the El Faro. May He comfort their families.\" \u2014@POTUS on the El Faro Cargo Ship http:\/\/t.co\/iQieo4BxDK",
  "id" : 651892599045926912,
  "created_at" : "2015-10-07 22:51:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Labor Department",
      "screen_name" : "USDOL",
      "indices" : [ 3, 9 ],
      "id_str" : "20179628",
      "id" : 20179628
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 104, 110 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StartTheConvo",
      "indices" : [ 111, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651887956777660416",
  "text" : "RT @USDOL: \"The best, most effective employers are the ones who are actively soliciting worker input.\" \u2014@POTUS #StartTheConvo http:\/\/t.co\/U\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/snappytv.com\" rel=\"nofollow\"\u003ESnappyTV.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 93, 99 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "StartTheConvo",
        "indices" : [ 100, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/UyxC2dBARC",
        "expanded_url" : "http:\/\/snpy.tv\/1OmoQ6B",
        "display_url" : "snpy.tv\/1OmoQ6B"
      } ]
    },
    "geo" : { },
    "id_str" : "651886006501707776",
    "text" : "\"The best, most effective employers are the ones who are actively soliciting worker input.\" \u2014@POTUS #StartTheConvo http:\/\/t.co\/UyxC2dBARC",
    "id" : 651886006501707776,
    "created_at" : "2015-10-07 22:25:10 +0000",
    "user" : {
      "name" : "US Labor Department",
      "screen_name" : "USDOL",
      "protected" : false,
      "id_str" : "20179628",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655006480697978880\/Fom0f0nJ_normal.png",
      "id" : 20179628,
      "verified" : true
    }
  },
  "id" : 651887956777660416,
  "created_at" : "2015-10-07 22:32:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 68, 74 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StartTheConvo",
      "indices" : [ 75, 89 ]
    }, {
      "text" : "RaiseTheWage",
      "indices" : [ 121, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651869719352483840",
  "text" : "\"The minimum wage law is hugely important for restaurant workers.\" \u2014@POTUS #StartTheConvo\n\nRT if you agree: It's time to #RaiseTheWage.",
  "id" : 651869719352483840,
  "created_at" : "2015-10-07 21:20:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/651814990593265665\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/AZ3bs3CjfT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQu2QROXAAAvz0I.jpg",
      "id_str" : "651814961702961152",
      "id" : 651814961702961152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQu2QROXAAAvz0I.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/AZ3bs3CjfT"
    } ],
    "hashtags" : [ {
      "text" : "fightfor15",
      "indices" : [ 90, 101 ]
    }, {
      "text" : "StartTheConvo",
      "indices" : [ 102, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651867588662816768",
  "text" : "RT @vj44: Terrence worked 2 decades &amp; makes only $8. That is not right!  So he joined #fightfor15 #StartTheConvo http:\/\/t.co\/AZ3bs3CjfT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/651814990593265665\/photo\/1",
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/AZ3bs3CjfT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQu2QROXAAAvz0I.jpg",
        "id_str" : "651814961702961152",
        "id" : 651814961702961152,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQu2QROXAAAvz0I.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/AZ3bs3CjfT"
      } ],
      "hashtags" : [ {
        "text" : "fightfor15",
        "indices" : [ 80, 91 ]
      }, {
        "text" : "StartTheConvo",
        "indices" : [ 92, 106 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "651814990593265665",
    "text" : "Terrence worked 2 decades &amp; makes only $8. That is not right!  So he joined #fightfor15 #StartTheConvo http:\/\/t.co\/AZ3bs3CjfT",
    "id" : 651814990593265665,
    "created_at" : "2015-10-07 17:42:58 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 651867588662816768,
  "created_at" : "2015-10-07 21:11:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Labor Department",
      "screen_name" : "USDOL",
      "indices" : [ 3, 9 ],
      "id_str" : "20179628",
      "id" : 20179628
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 91, 97 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/USDOL\/status\/651865451421696004\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/78z5XOGnTQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQvjwgNWgAAXZDF.png",
      "id_str" : "651864993504329728",
      "id" : 651864993504329728,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQvjwgNWgAAXZDF.png",
      "sizes" : [ {
        "h" : 330,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 516,
        "resize" : "fit",
        "w" : 938
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 516,
        "resize" : "fit",
        "w" : 938
      }, {
        "h" : 187,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/78z5XOGnTQ"
    } ],
    "hashtags" : [ {
      "text" : "StartTheConvo",
      "indices" : [ 98, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651865786366173184",
  "text" : "RT @USDOL: \"We need to help link folks so there's a workers movement across the economy.\" \u2014@POTUS #StartTheConvo http:\/\/t.co\/78z5XOGnTQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 80, 86 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/USDOL\/status\/651865451421696004\/photo\/1",
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/78z5XOGnTQ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQvjwgNWgAAXZDF.png",
        "id_str" : "651864993504329728",
        "id" : 651864993504329728,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQvjwgNWgAAXZDF.png",
        "sizes" : [ {
          "h" : 330,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 516,
          "resize" : "fit",
          "w" : 938
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 516,
          "resize" : "fit",
          "w" : 938
        }, {
          "h" : 187,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/78z5XOGnTQ"
      } ],
      "hashtags" : [ {
        "text" : "StartTheConvo",
        "indices" : [ 87, 101 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "651865451421696004",
    "text" : "\"We need to help link folks so there's a workers movement across the economy.\" \u2014@POTUS #StartTheConvo http:\/\/t.co\/78z5XOGnTQ",
    "id" : 651865451421696004,
    "created_at" : "2015-10-07 21:03:29 +0000",
    "user" : {
      "name" : "US Labor Department",
      "screen_name" : "USDOL",
      "protected" : false,
      "id_str" : "20179628",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655006480697978880\/Fom0f0nJ_normal.png",
      "id" : 20179628,
      "verified" : true
    }
  },
  "id" : 651865786366173184,
  "created_at" : "2015-10-07 21:04:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 12, 18 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Coworker.org",
      "screen_name" : "teamcoworker",
      "indices" : [ 55, 68 ],
      "id_str" : "759665412",
      "id" : 759665412
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StartTheConvo",
      "indices" : [ 114, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/12kdzQvx1i",
      "expanded_url" : "http:\/\/go.wh.gov\/WorkerVoice",
      "display_url" : "go.wh.gov\/WorkerVoice"
    } ]
  },
  "geo" : { },
  "id_str" : "651864042542342144",
  "text" : "Watch live: @POTUS participates in a conversation with @teamcoworker on worker voice \u2014&gt; http:\/\/t.co\/12kdzQvx1i #StartTheConvo",
  "id" : 651864042542342144,
  "created_at" : "2015-10-07 20:57:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StartTheConvo",
      "indices" : [ 101, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/12kdzQvx1i",
      "expanded_url" : "http:\/\/go.wh.gov\/WorkerVoice",
      "display_url" : "go.wh.gov\/WorkerVoice"
    }, {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/L3knYHPPrS",
      "expanded_url" : "http:\/\/snpy.tv\/1OlDmvB",
      "display_url" : "snpy.tv\/1OlDmvB"
    } ]
  },
  "geo" : { },
  "id_str" : "651808879471366144",
  "text" : "Every hardworking American should earn enough money to support their family \u2192 http:\/\/t.co\/12kdzQvx1i #StartTheConvo http:\/\/t.co\/L3knYHPPrS",
  "id" : 651808879471366144,
  "created_at" : "2015-10-07 17:18:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/649320562322489344\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/r3eERD7O30",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQLZlKJWEAAVnEw.jpg",
      "id_str" : "649320528696709120",
      "id" : 649320528696709120,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQLZlKJWEAAVnEw.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/r3eERD7O30"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 77, 90 ]
    }, {
      "text" : "StartTheConvo",
      "indices" : [ 91, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/12kdzQvx1i",
      "expanded_url" : "http:\/\/go.wh.gov\/WorkerVoice",
      "display_url" : "go.wh.gov\/WorkerVoice"
    } ]
  },
  "geo" : { },
  "id_str" : "651807835270082560",
  "text" : "RT if you agree: It's time to raise the minimum wage. http:\/\/t.co\/12kdzQvx1i #RaiseTheWage #StartTheConvo http:\/\/t.co\/r3eERD7O30",
  "id" : 651807835270082560,
  "created_at" : "2015-10-07 17:14:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 131, 137 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651807260952383488",
  "text" : "\"Good pay.\nBenefits.\nWorkplace safety.\nWork-family balance.\nSkills training.\nThe freedom to organize.\nThat\u2019s what unions secured\" \u2014@POTUS",
  "id" : 651807260952383488,
  "created_at" : "2015-10-07 17:12:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 92, 98 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LeadOnLeave",
      "indices" : [ 123, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/12kdzQvx1i",
      "expanded_url" : "http:\/\/go.wh.gov\/WorkerVoice",
      "display_url" : "go.wh.gov\/WorkerVoice"
    } ]
  },
  "geo" : { },
  "id_str" : "651806984623255553",
  "text" : "\"If you work hard in America, you should actually be able to take care of those you love.\" \u2014@POTUS: http:\/\/t.co\/12kdzQvx1i #LeadOnLeave",
  "id" : 651806984623255553,
  "created_at" : "2015-10-07 17:11:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 128, 134 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651806960648589312",
  "text" : "RT @WHLive: \"If you work hard in America, you should earn decent benefits. That means access to...affordable health insurance\" \u2014@POTUS #Sta\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 116, 122 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "StartTheConvo",
        "indices" : [ 123, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "651806854025203712",
    "text" : "\"If you work hard in America, you should earn decent benefits. That means access to...affordable health insurance\" \u2014@POTUS #StartTheConvo",
    "id" : 651806854025203712,
    "created_at" : "2015-10-07 17:10:38 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 651806960648589312,
  "created_at" : "2015-10-07 17:11:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 85, 91 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StartTheConvo",
      "indices" : [ 116, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/12kdzQvx1i",
      "expanded_url" : "http:\/\/go.wh.gov\/WorkerVoice",
      "display_url" : "go.wh.gov\/WorkerVoice"
    } ]
  },
  "geo" : { },
  "id_str" : "651806758151827456",
  "text" : "\"If you work hard in America, you should earn enough money to support your family.\" \u2014@POTUS: http:\/\/t.co\/12kdzQvx1i #StartTheConvo",
  "id" : 651806758151827456,
  "created_at" : "2015-10-07 17:10:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 106, 112 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StartTheConvo",
      "indices" : [ 113, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651804855158317056",
  "text" : "\"If you\u2019re not at the table\u2014you\u2019re on the menu. So we\u2019ve got to get more working Americans to the table\" \u2014@POTUS #StartTheConvo",
  "id" : 651804855158317056,
  "created_at" : "2015-10-07 17:02:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 132, 138 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651804581077360644",
  "text" : "\"We should be making it easier, not harder, for folks to join a union. We should be strengthening labor law, not rolling it back.\" \u2014@POTUS",
  "id" : 651804581077360644,
  "created_at" : "2015-10-07 17:01:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 112, 118 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StartTheConvo",
      "indices" : [ 119, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651804471803179008",
  "text" : "\"When folks attack unions, they\u2019re attacking the middle class. They\u2019re attacking cops, firefighters, teachers\" \u2014@POTUS #StartTheConvo",
  "id" : 651804471803179008,
  "created_at" : "2015-10-07 17:01:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 127, 133 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651803857513771008",
  "text" : "\"The 40-hour workweek.\nOvertime pay.\nHealth insurance.\nRetirement plans.\nThe middle class itself was built on a union label.\" \u2014@POTUS",
  "id" : 651803857513771008,
  "created_at" : "2015-10-07 16:58:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 83, 89 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/649319354018959360\/photo\/1",
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/7xnxEZMwul",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQLYfmOWcAI3BWQ.jpg",
      "id_str" : "649319333643055106",
      "id" : 649319333643055106,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQLYfmOWcAI3BWQ.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/7xnxEZMwul"
    } ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 90, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651802465201987584",
  "text" : "\u201CFor the first time on record, more than 90% of Americans have health insurance.\u201D \u2014@POTUS #ACAWorks http:\/\/t.co\/7xnxEZMwul",
  "id" : 651802465201987584,
  "created_at" : "2015-10-07 16:53:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 72, 78 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 79, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651802318539759616",
  "text" : "\u201CWe\u2019re on pace to sell more American cars than in any year since 2001\u201D \u2014@POTUS #MadeInAmerica",
  "id" : 651802318539759616,
  "created_at" : "2015-10-07 16:52:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 99, 105 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/649958289325715456\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/oE9WWeTGJB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQUajuEXAAAzPjQ.jpg",
      "id_str" : "649954922188963840",
      "id" : 649954922188963840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQUajuEXAAAzPjQ.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/oE9WWeTGJB"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651802221806514176",
  "text" : "\u201CWe were able to take the unemployment rate, was which was around 10%, all the way down to 5.1%.\u201D \u2014@POTUS http:\/\/t.co\/oE9WWeTGJB",
  "id" : 651802221806514176,
  "created_at" : "2015-10-07 16:52:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651801893816115200",
  "text" : "RT @WHLive: \"We\u2019ve convened this summit because we believe this this is a country where if we work hard, everybody should be able to get ah\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 134, 140 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "651801857841590272",
    "text" : "\"We\u2019ve convened this summit because we believe this this is a country where if we work hard, everybody should be able to get ahead.\" \u2014@POTUS",
    "id" : 651801857841590272,
    "created_at" : "2015-10-07 16:50:47 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 651801893816115200,
  "created_at" : "2015-10-07 16:50:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 12, 18 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StartTheConvo",
      "indices" : [ 78, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/12kdzQvx1i",
      "expanded_url" : "http:\/\/go.wh.gov\/WorkerVoice",
      "display_url" : "go.wh.gov\/WorkerVoice"
    } ]
  },
  "geo" : { },
  "id_str" : "651801128712192000",
  "text" : "Watch live: @POTUS speaks at the Worker Voice Summit \u2192 http:\/\/t.co\/12kdzQvx1i #StartTheConvo",
  "id" : 651801128712192000,
  "created_at" : "2015-10-07 16:47:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 21, 27 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StartTheConvo",
      "indices" : [ 100, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/12kdzQvx1i",
      "expanded_url" : "http:\/\/go.wh.gov\/WorkerVoice",
      "display_url" : "go.wh.gov\/WorkerVoice"
    } ]
  },
  "geo" : { },
  "id_str" : "651793371866996736",
  "text" : "Starting soon: Watch @POTUS speak at the Worker Voice Summit at 12:20pm ET \u2192 http:\/\/t.co\/12kdzQvx1i #StartTheConvo",
  "id" : 651793371866996736,
  "created_at" : "2015-10-07 16:17:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StartTheConvo",
      "indices" : [ 50, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651792348385550336",
  "text" : "RT @vj44: Today's Worker Voice Summit is a way to #StartTheConvo for an economy where workers, businesses &amp; families thrive. http:\/\/t.co\/Ep\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/651780961034633216\/video\/1",
        "indices" : [ 119, 141 ],
        "url" : "http:\/\/t.co\/Ep34V5nFZ2",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/651780618355806208\/pu\/img\/snq5U_G4jSTIuqIA.jpg",
        "id_str" : "651780618355806208",
        "id" : 651780618355806208,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/651780618355806208\/pu\/img\/snq5U_G4jSTIuqIA.jpg",
        "sizes" : [ {
          "h" : 604,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1280,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 0,
          "resize" : "fit",
          "w" : 0
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1067,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/Ep34V5nFZ2"
      } ],
      "hashtags" : [ {
        "text" : "StartTheConvo",
        "indices" : [ 40, 54 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "651780961034633216",
    "text" : "Today's Worker Voice Summit is a way to #StartTheConvo for an economy where workers, businesses &amp; families thrive. http:\/\/t.co\/Ep34V5nFZ2",
    "id" : 651780961034633216,
    "created_at" : "2015-10-07 15:27:45 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 651792348385550336,
  "created_at" : "2015-10-07 16:13:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diana Doukas",
      "screen_name" : "Diana44",
      "indices" : [ 3, 11 ],
      "id_str" : "3274836392",
      "id" : 3274836392
    }, {
      "name" : "Washington Post",
      "screen_name" : "washingtonpost",
      "indices" : [ 33, 48 ],
      "id_str" : "2467791",
      "id" : 2467791
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TPP",
      "indices" : [ 57, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/4luST0yGxD",
      "expanded_url" : "http:\/\/wapo.st\/1Q6heEf",
      "display_url" : "wapo.st\/1Q6heEf"
    } ]
  },
  "geo" : { },
  "id_str" : "651559368757002240",
  "text" : "RT @Diana44: Check this out from @WashingtonPost -- \"The #TPP is a trade deal worth celebrating\" http:\/\/t.co\/4luST0yGxD http:\/\/t.co\/svj8Luk\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Washington Post",
        "screen_name" : "washingtonpost",
        "indices" : [ 20, 35 ],
        "id_str" : "2467791",
        "id" : 2467791
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Diana44\/status\/651558382726434816\/photo\/1",
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/svj8LukLaL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQrM2vRWIAAaH6U.jpg",
        "id_str" : "651558336882679808",
        "id" : 651558336882679808,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQrM2vRWIAAaH6U.jpg",
        "sizes" : [ {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/svj8LukLaL"
      } ],
      "hashtags" : [ {
        "text" : "TPP",
        "indices" : [ 44, 48 ]
      } ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/4luST0yGxD",
        "expanded_url" : "http:\/\/wapo.st\/1Q6heEf",
        "display_url" : "wapo.st\/1Q6heEf"
      } ]
    },
    "geo" : { },
    "id_str" : "651558382726434816",
    "text" : "Check this out from @WashingtonPost -- \"The #TPP is a trade deal worth celebrating\" http:\/\/t.co\/4luST0yGxD http:\/\/t.co\/svj8LukLaL",
    "id" : 651558382726434816,
    "created_at" : "2015-10-07 00:43:18 +0000",
    "user" : {
      "name" : "Diana Doukas",
      "screen_name" : "Diana44",
      "protected" : false,
      "id_str" : "3274836392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/671831357371191296\/CQ0VNiYR_normal.jpg",
      "id" : 3274836392,
      "verified" : true
    }
  },
  "id" : 651559368757002240,
  "created_at" : "2015-10-07 00:47:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 87, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/9GxPOPUoUU",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/355d6536-ccaf-42e2-b407-fa2179409ad3",
      "display_url" : "amp.twimg.com\/v\/355d6536-cca\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "651502326935617536",
  "text" : "95% of the world's consumers live outside the U.S.\nLet's help our businesses sell more #MadeInAmerica products. https:\/\/t.co\/9GxPOPUoUU",
  "id" : 651502326935617536,
  "created_at" : "2015-10-06 21:00:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Instacart",
      "screen_name" : "Instacart",
      "indices" : [ 3, 13 ],
      "id_str" : "618480916",
      "id" : 618480916
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AidRefugees",
      "indices" : [ 78, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651497290776117249",
  "text" : "RT @Instacart: Instacart users have the option to donate food rations to help #AidRefugees of the crisis in Syria. Learn more: http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AidRefugees",
        "indices" : [ 63, 75 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/l7DPF54vjT",
        "expanded_url" : "http:\/\/bit.ly\/1JPXAY3",
        "display_url" : "bit.ly\/1JPXAY3"
      } ]
    },
    "geo" : { },
    "id_str" : "651495020667797504",
    "text" : "Instacart users have the option to donate food rations to help #AidRefugees of the crisis in Syria. Learn more: http:\/\/t.co\/l7DPF54vjT",
    "id" : 651495020667797504,
    "created_at" : "2015-10-06 20:31:31 +0000",
    "user" : {
      "name" : "Instacart",
      "screen_name" : "Instacart",
      "protected" : false,
      "id_str" : "618480916",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/687470115185496067\/y98T1oQr_normal.png",
      "id" : 618480916,
      "verified" : true
    }
  },
  "id" : 651497290776117249,
  "created_at" : "2015-10-06 20:40:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dept. of Agriculture",
      "screen_name" : "USDA",
      "indices" : [ 3, 8 ],
      "id_str" : "61853389",
      "id" : 61853389
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TPP",
      "indices" : [ 53, 57 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/IQ2QOPdHpE",
      "expanded_url" : "http:\/\/www.usda.gov\/trade",
      "display_url" : "usda.gov\/trade"
    } ]
  },
  "geo" : { },
  "id_str" : "651493136871620608",
  "text" : "RT @USDA: 95% of consumers live outside our borders. #TPP levels the playing field for US farm exports http:\/\/t.co\/IQ2QOPdHpE http:\/\/t.co\/7\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/USDA\/status\/651428648390656000\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/7961PSDJZx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQpW51aUcAEoQKp.jpg",
        "id_str" : "651428647698460673",
        "id" : 651428647698460673,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQpW51aUcAEoQKp.jpg",
        "sizes" : [ {
          "h" : 653,
          "resize" : "fit",
          "w" : 1084
        }, {
          "h" : 617,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 205,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 361,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/7961PSDJZx"
      } ],
      "hashtags" : [ {
        "text" : "TPP",
        "indices" : [ 43, 47 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/IQ2QOPdHpE",
        "expanded_url" : "http:\/\/www.usda.gov\/trade",
        "display_url" : "usda.gov\/trade"
      } ]
    },
    "geo" : { },
    "id_str" : "651428648390656000",
    "text" : "95% of consumers live outside our borders. #TPP levels the playing field for US farm exports http:\/\/t.co\/IQ2QOPdHpE http:\/\/t.co\/7961PSDJZx",
    "id" : 651428648390656000,
    "created_at" : "2015-10-06 16:07:47 +0000",
    "user" : {
      "name" : "Dept. of Agriculture",
      "screen_name" : "USDA",
      "protected" : false,
      "id_str" : "61853389",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3475696751\/bf524afc612e7aa534d6c543a3d3e144_normal.jpeg",
      "id" : 61853389,
      "verified" : true
    }
  },
  "id" : 651493136871620608,
  "created_at" : "2015-10-06 20:24:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Enough",
      "indices" : [ 97, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/mCFneMth1t",
      "expanded_url" : "http:\/\/www.gunviolencearchive.org\/",
      "display_url" : "gunviolencearchive.org"
    } ]
  },
  "geo" : { },
  "id_str" : "651491582374449152",
  "text" : "RT @Simas44: 10,107 Americans killed in gun violence so far in 2015. At least 14 more yesterday. #Enough http:\/\/t.co\/mCFneMth1t http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Simas44\/status\/651488241544114176\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/LHPLPalhpH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQqNGm6UkAA-pJm.png",
        "id_str" : "651488240772354048",
        "id" : 651488240772354048,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQqNGm6UkAA-pJm.png",
        "sizes" : [ {
          "h" : 203,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 586,
          "resize" : "fit",
          "w" : 981
        }, {
          "h" : 586,
          "resize" : "fit",
          "w" : 981
        }, {
          "h" : 358,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/LHPLPalhpH"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/Simas44\/status\/651488241544114176\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/LHPLPalhpH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQqNGkTVAAAgxOd.png",
        "id_str" : "651488240071933952",
        "id" : 651488240071933952,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQqNGkTVAAAgxOd.png",
        "sizes" : [ {
          "h" : 456,
          "resize" : "fit",
          "w" : 409
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 456,
          "resize" : "fit",
          "w" : 409
        }, {
          "h" : 456,
          "resize" : "fit",
          "w" : 409
        }, {
          "h" : 379,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/LHPLPalhpH"
      } ],
      "hashtags" : [ {
        "text" : "Enough",
        "indices" : [ 84, 91 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/mCFneMth1t",
        "expanded_url" : "http:\/\/www.gunviolencearchive.org\/",
        "display_url" : "gunviolencearchive.org"
      } ]
    },
    "geo" : { },
    "id_str" : "651488241544114176",
    "text" : "10,107 Americans killed in gun violence so far in 2015. At least 14 more yesterday. #Enough http:\/\/t.co\/mCFneMth1t http:\/\/t.co\/LHPLPalhpH",
    "id" : 651488241544114176,
    "created_at" : "2015-10-06 20:04:35 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 651491582374449152,
  "created_at" : "2015-10-06 20:17:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "indices" : [ 3, 10 ],
      "id_str" : "44783853",
      "id" : 44783853
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/HHSGov\/status\/651414126497927169\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/Vx9XFvulh3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQpJslUUYAAEWWQ.jpg",
      "id_str" : "651414126388862976",
      "id" : 651414126388862976,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQpJslUUYAAEWWQ.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 320,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 320,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/Vx9XFvulh3"
    } ],
    "hashtags" : [ {
      "text" : "Ebola",
      "indices" : [ 43, 49 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/Vjj4HPgfXO",
      "expanded_url" : "http:\/\/huff.to\/1WKDJTn",
      "display_url" : "huff.to\/1WKDJTn"
    } ]
  },
  "geo" : { },
  "id_str" : "651478512642224129",
  "text" : "RT @HHSGov: We have turned the tide on the #Ebola epidemic. Here\u2019s what we\u2019ve learned: http:\/\/t.co\/Vjj4HPgfXO http:\/\/t.co\/Vx9XFvulh3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/HHSGov\/status\/651414126497927169\/photo\/1",
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/Vx9XFvulh3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQpJslUUYAAEWWQ.jpg",
        "id_str" : "651414126388862976",
        "id" : 651414126388862976,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQpJslUUYAAEWWQ.jpg",
        "sizes" : [ {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 320,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 320,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/Vx9XFvulh3"
      } ],
      "hashtags" : [ {
        "text" : "Ebola",
        "indices" : [ 31, 37 ]
      } ],
      "urls" : [ {
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/Vjj4HPgfXO",
        "expanded_url" : "http:\/\/huff.to\/1WKDJTn",
        "display_url" : "huff.to\/1WKDJTn"
      } ]
    },
    "geo" : { },
    "id_str" : "651414126497927169",
    "text" : "We have turned the tide on the #Ebola epidemic. Here\u2019s what we\u2019ve learned: http:\/\/t.co\/Vjj4HPgfXO http:\/\/t.co\/Vx9XFvulh3",
    "id" : 651414126497927169,
    "created_at" : "2015-10-06 15:10:05 +0000",
    "user" : {
      "name" : "HHS.gov",
      "screen_name" : "HHSGov",
      "protected" : false,
      "id_str" : "44783853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567350542326718464\/FXOsgyA7_normal.jpeg",
      "id" : 44783853,
      "verified" : true
    }
  },
  "id" : 651478512642224129,
  "created_at" : "2015-10-06 19:25:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph Alminawi",
      "screen_name" : "Swiftor",
      "indices" : [ 3, 11 ],
      "id_str" : "14685759",
      "id" : 14685759
    }, {
      "name" : "USA for UNHCR",
      "screen_name" : "UNRefugeeAgency",
      "indices" : [ 52, 68 ],
      "id_str" : "22679783",
      "id" : 22679783
    }, {
      "name" : "Kickstarter",
      "screen_name" : "kickstarter",
      "indices" : [ 75, 87 ],
      "id_str" : "16186995",
      "id" : 16186995
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AidRefugees",
      "indices" : [ 88, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 124 ],
      "url" : "https:\/\/t.co\/KdXP1p7A0H",
      "expanded_url" : "https:\/\/www.kickstarter.com\/aidrefugees",
      "display_url" : "kickstarter.com\/aidrefugees"
    } ]
  },
  "geo" : { },
  "id_str" : "651472633070927872",
  "text" : "RT @Swiftor: Great cause for refugee assistance via @UNRefugeeAgency &amp; @Kickstarter #AidRefugees https:\/\/t.co\/KdXP1p7A0H",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "USA for UNHCR",
        "screen_name" : "UNRefugeeAgency",
        "indices" : [ 39, 55 ],
        "id_str" : "22679783",
        "id" : 22679783
      }, {
        "name" : "Kickstarter",
        "screen_name" : "kickstarter",
        "indices" : [ 62, 74 ],
        "id_str" : "16186995",
        "id" : 16186995
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AidRefugees",
        "indices" : [ 75, 87 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 111 ],
        "url" : "https:\/\/t.co\/KdXP1p7A0H",
        "expanded_url" : "https:\/\/www.kickstarter.com\/aidrefugees",
        "display_url" : "kickstarter.com\/aidrefugees"
      } ]
    },
    "geo" : { },
    "id_str" : "651439259275149312",
    "text" : "Great cause for refugee assistance via @UNRefugeeAgency &amp; @Kickstarter #AidRefugees https:\/\/t.co\/KdXP1p7A0H",
    "id" : 651439259275149312,
    "created_at" : "2015-10-06 16:49:57 +0000",
    "user" : {
      "name" : "Joseph Alminawi",
      "screen_name" : "Swiftor",
      "protected" : false,
      "id_str" : "14685759",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/696756713127616512\/kLgLZjXd_normal.jpg",
      "id" : 14685759,
      "verified" : true
    }
  },
  "id" : 651472633070927872,
  "created_at" : "2015-10-06 19:02:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MadeInAmerica",
      "indices" : [ 36, 50 ]
    }, {
      "text" : "TPP",
      "indices" : [ 105, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 133 ],
      "url" : "https:\/\/t.co\/9GxPOPUoUU",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/355d6536-ccaf-42e2-b407-fa2179409ad3",
      "display_url" : "amp.twimg.com\/v\/355d6536-cca\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "651444224462856192",
  "text" : "President Obama's trade deal =\nMore #MadeInAmerica exports abroad.\nMore higher-paying jobs here at home. #TPP https:\/\/t.co\/9GxPOPUoUU",
  "id" : 651444224462856192,
  "created_at" : "2015-10-06 17:09:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/RCNK0hAHFn",
      "expanded_url" : "http:\/\/go.wh.gov\/trade",
      "display_url" : "go.wh.gov\/trade"
    }, {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/9GxPOQbZMs",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/355d6536-ccaf-42e2-b407-fa2179409ad3",
      "display_url" : "amp.twimg.com\/v\/355d6536-cca\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "651432624062238720",
  "text" : "Watch how President Obama's trade deal puts American workers (and American cherries) on top: http:\/\/t.co\/RCNK0hAHFn\nhttps:\/\/t.co\/9GxPOQbZMs",
  "id" : 651432624062238720,
  "created_at" : "2015-10-06 16:23:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Starbucks Coffee",
      "screen_name" : "Starbucks",
      "indices" : [ 3, 13 ],
      "id_str" : "30973",
      "id" : 30973
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AidRefugees",
      "indices" : [ 118, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/78hQMRL8cm",
      "expanded_url" : "http:\/\/sbux.co\/AidRefugees",
      "display_url" : "sbux.co\/AidRefugees"
    } ]
  },
  "geo" : { },
  "id_str" : "651428864024018944",
  "text" : "RT @Starbucks: Help the Red Cross provide food, water &amp; cots for refugees across Europe. http:\/\/t.co\/78hQMRL8cm\u00A0\n\n#AidRefugees http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/ads.twitter.com\" rel=\"nofollow\"\u003ETwitter Ads\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Starbucks\/status\/651402689352351744\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/ksHSjUarPU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQo_S1nVAAEDEaz.jpg",
        "id_str" : "651402688970686465",
        "id" : 651402688970686465,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQo_S1nVAAEDEaz.jpg",
        "sizes" : [ {
          "h" : 314,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1072,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 536,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 178,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/ksHSjUarPU"
      } ],
      "hashtags" : [ {
        "text" : "AidRefugees",
        "indices" : [ 103, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 78, 100 ],
        "url" : "http:\/\/t.co\/78hQMRL8cm",
        "expanded_url" : "http:\/\/sbux.co\/AidRefugees",
        "display_url" : "sbux.co\/AidRefugees"
      } ]
    },
    "geo" : { },
    "id_str" : "651402689352351744",
    "text" : "Help the Red Cross provide food, water &amp; cots for refugees across Europe. http:\/\/t.co\/78hQMRL8cm\u00A0\n\n#AidRefugees http:\/\/t.co\/ksHSjUarPU",
    "id" : 651402689352351744,
    "created_at" : "2015-10-06 14:24:38 +0000",
    "user" : {
      "name" : "Starbucks Coffee",
      "screen_name" : "Starbucks",
      "protected" : false,
      "id_str" : "30973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/781968043706421249\/SBgtLVEA_normal.jpg",
      "id" : 30973,
      "verified" : true
    }
  },
  "id" : 651428864024018944,
  "created_at" : "2015-10-06 16:08:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Connie Britton",
      "screen_name" : "conniebritton",
      "indices" : [ 25, 39 ],
      "id_str" : "1905230346",
      "id" : 1905230346
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AidRefugees",
      "indices" : [ 78, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/2PGCl1NflO",
      "expanded_url" : "http:\/\/go.wh.gov\/AidRefugees",
      "display_url" : "go.wh.gov\/AidRefugees"
    }, {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/HFQvMpGykT",
      "expanded_url" : "https:\/\/twitter.com\/conniebritton\/status\/651417854982668288",
      "display_url" : "twitter.com\/conniebritton\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "651422829011935232",
  "text" : "Thanks for your support, @ConnieBritton!\nWe all can play a role in helping to #AidRefugees \u2192 http:\/\/t.co\/2PGCl1NflO https:\/\/t.co\/HFQvMpGykT",
  "id" : 651422829011935232,
  "created_at" : "2015-10-06 15:44:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Policy",
      "screen_name" : "policy",
      "indices" : [ 3, 10 ],
      "id_str" : "218984871",
      "id" : 218984871
    }, {
      "name" : "UNICEF",
      "screen_name" : "UNICEF",
      "indices" : [ 31, 38 ],
      "id_str" : "33933259",
      "id" : 33933259
    }, {
      "name" : "Karam Foundation",
      "screen_name" : "karamfoundation",
      "indices" : [ 43, 59 ],
      "id_str" : "34855178",
      "id" : 34855178
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/policy\/status\/651387899653570560\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/kMnkegJeXp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQoxzgGUkAMi9Ed.jpg",
      "id_str" : "651387856967995395",
      "id" : 651387856967995395,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQoxzgGUkAMi9Ed.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/kMnkegJeXp"
    } ],
    "hashtags" : [ {
      "text" : "AidRefugees",
      "indices" : [ 63, 75 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/IQuJ2G0FeB",
      "expanded_url" : "https:\/\/www.whitehouse.gov\/blog\/2015\/10\/06\/aidrefugees-heeding-presidents-call-take-action",
      "display_url" : "whitehouse.gov\/blog\/2015\/10\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "651421067525926913",
  "text" : "RT @policy: Twitter is joining @UNICEF and @karamfoundation to #AidRefugees. Learn more here: https:\/\/t.co\/IQuJ2G0FeB http:\/\/t.co\/kMnkegJeXp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "UNICEF",
        "screen_name" : "UNICEF",
        "indices" : [ 19, 26 ],
        "id_str" : "33933259",
        "id" : 33933259
      }, {
        "name" : "Karam Foundation",
        "screen_name" : "karamfoundation",
        "indices" : [ 31, 47 ],
        "id_str" : "34855178",
        "id" : 34855178
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/policy\/status\/651387899653570560\/photo\/1",
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/kMnkegJeXp",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQoxzgGUkAMi9Ed.jpg",
        "id_str" : "651387856967995395",
        "id" : 651387856967995395,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQoxzgGUkAMi9Ed.jpg",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/kMnkegJeXp"
      } ],
      "hashtags" : [ {
        "text" : "AidRefugees",
        "indices" : [ 51, 63 ]
      } ],
      "urls" : [ {
        "indices" : [ 82, 105 ],
        "url" : "https:\/\/t.co\/IQuJ2G0FeB",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/blog\/2015\/10\/06\/aidrefugees-heeding-presidents-call-take-action",
        "display_url" : "whitehouse.gov\/blog\/2015\/10\/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "651387899653570560",
    "text" : "Twitter is joining @UNICEF and @karamfoundation to #AidRefugees. Learn more here: https:\/\/t.co\/IQuJ2G0FeB http:\/\/t.co\/kMnkegJeXp",
    "id" : 651387899653570560,
    "created_at" : "2015-10-06 13:25:52 +0000",
    "user" : {
      "name" : "Policy",
      "screen_name" : "policy",
      "protected" : false,
      "id_str" : "218984871",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/431583032827342848\/A9aVHPI6_normal.png",
      "id" : 218984871,
      "verified" : true
    }
  },
  "id" : 651421067525926913,
  "created_at" : "2015-10-06 15:37:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kickstarter",
      "screen_name" : "kickstarter",
      "indices" : [ 3, 15 ],
      "id_str" : "16186995",
      "id" : 16186995
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 22, 33 ],
      "id_str" : "30313925",
      "id" : 30313925
    }, {
      "name" : "BuzzFeed",
      "screen_name" : "BuzzFeed",
      "indices" : [ 90, 99 ],
      "id_str" : "5695632",
      "id" : 5695632
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AidRefugees",
      "indices" : [ 51, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/gMIKejv420",
      "expanded_url" : "http:\/\/www.buzzfeed.com\/hayesbrown\/the-syrian-refugee-crisis-has-a-kickstarter-now#.kePY98RYr",
      "display_url" : "buzzfeed.com\/hayesbrown\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "651418370269671426",
  "text" : "RT @kickstarter: When @WhiteHouse asked us to help #AidRefugees, we immediately said yes. @BuzzFeed reports: http:\/\/t.co\/gMIKejv420 http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 5, 16 ],
        "id_str" : "30313925",
        "id" : 30313925
      }, {
        "name" : "BuzzFeed",
        "screen_name" : "BuzzFeed",
        "indices" : [ 73, 82 ],
        "id_str" : "5695632",
        "id" : 5695632
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/kickstarter\/status\/651417542658015232\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/L3ha4vZ6X0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQpMwKPUcAAk05C.png",
        "id_str" : "651417486374498304",
        "id" : 651417486374498304,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQpMwKPUcAAk05C.png",
        "sizes" : [ {
          "h" : 360,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 204,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 589,
          "resize" : "fit",
          "w" : 983
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 589,
          "resize" : "fit",
          "w" : 983
        } ],
        "display_url" : "pic.twitter.com\/L3ha4vZ6X0"
      } ],
      "hashtags" : [ {
        "text" : "AidRefugees",
        "indices" : [ 34, 46 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/gMIKejv420",
        "expanded_url" : "http:\/\/www.buzzfeed.com\/hayesbrown\/the-syrian-refugee-crisis-has-a-kickstarter-now#.kePY98RYr",
        "display_url" : "buzzfeed.com\/hayesbrown\/the\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "651417542658015232",
    "text" : "When @WhiteHouse asked us to help #AidRefugees, we immediately said yes. @BuzzFeed reports: http:\/\/t.co\/gMIKejv420 http:\/\/t.co\/L3ha4vZ6X0",
    "id" : 651417542658015232,
    "created_at" : "2015-10-06 15:23:39 +0000",
    "user" : {
      "name" : "Kickstarter",
      "screen_name" : "kickstarter",
      "protected" : false,
      "id_str" : "16186995",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796383165019459584\/Y3V1zs5C_normal.jpg",
      "id" : 16186995,
      "verified" : true
    }
  },
  "id" : 651418370269671426,
  "created_at" : "2015-10-06 15:26:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/651385253022535680\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/IVECraCwOc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQourhVUkAA754K.jpg",
      "id_str" : "651384421325508608",
      "id" : 651384421325508608,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQourhVUkAA754K.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/IVECraCwOc"
    } ],
    "hashtags" : [ {
      "text" : "AidRefugees",
      "indices" : [ 96, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/2PGCl1NflO",
      "expanded_url" : "http:\/\/go.wh.gov\/AidRefugees",
      "display_url" : "go.wh.gov\/AidRefugees"
    } ]
  },
  "geo" : { },
  "id_str" : "651385253022535680",
  "text" : "All of us can help refugees find safe haven.\nFind out how you can here \u2192 http:\/\/t.co\/2PGCl1NflO #AidRefugees http:\/\/t.co\/IVECraCwOc",
  "id" : 651385253022535680,
  "created_at" : "2015-10-06 13:15:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/651132226076184578\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/oH7HeDGM7R",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQlJJN3UwAAx1G2.jpg",
      "id_str" : "651132043821105152",
      "id" : 651132043821105152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQlJJN3UwAAx1G2.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/oH7HeDGM7R"
    } ],
    "hashtags" : [ {
      "text" : "TPP",
      "indices" : [ 4, 8 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/RCNK0hAHFn",
      "expanded_url" : "http:\/\/go.wh.gov\/trade",
      "display_url" : "go.wh.gov\/trade"
    } ]
  },
  "geo" : { },
  "id_str" : "651132226076184578",
  "text" : "The #TPP will ELIMINATE more than 18,000 taxes that various countries put on U.S. products \u2192 http:\/\/t.co\/RCNK0hAHFn http:\/\/t.co\/oH7HeDGM7R",
  "id" : 651132226076184578,
  "created_at" : "2015-10-05 20:29:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "indices" : [ 3, 11 ],
      "id_str" : "807095",
      "id" : 807095
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/vZ5kRo952g",
      "expanded_url" : "http:\/\/nyti.ms\/1hlu7hS",
      "display_url" : "nyti.ms\/1hlu7hS"
    } ]
  },
  "geo" : { },
  "id_str" : "651107009220247552",
  "text" : "RT @nytimes: Environmentalists are praising wildlife measures in the Trans-Pacific Partnership trade deal http:\/\/t.co\/vZ5kRo952g http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/nytimes\/status\/651078406579322880\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/ZLYarL9QE7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQkYXE8UcAAMnRv.jpg",
        "id_str" : "651078405874544640",
        "id" : 651078405874544640,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQkYXE8UcAAMnRv.jpg",
        "sizes" : [ {
          "h" : 336,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 560,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 190,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 560,
          "resize" : "fit",
          "w" : 1000
        } ],
        "display_url" : "pic.twitter.com\/ZLYarL9QE7"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/vZ5kRo952g",
        "expanded_url" : "http:\/\/nyti.ms\/1hlu7hS",
        "display_url" : "nyti.ms\/1hlu7hS"
      } ]
    },
    "geo" : { },
    "id_str" : "651078406579322880",
    "text" : "Environmentalists are praising wildlife measures in the Trans-Pacific Partnership trade deal http:\/\/t.co\/vZ5kRo952g http:\/\/t.co\/ZLYarL9QE7",
    "id" : 651078406579322880,
    "created_at" : "2015-10-05 16:56:03 +0000",
    "user" : {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "protected" : false,
      "id_str" : "807095",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758384037589348352\/KB3RFwFm_normal.jpg",
      "id" : 807095,
      "verified" : true
    }
  },
  "id" : 651107009220247552,
  "created_at" : "2015-10-05 18:49:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/651102823439011842\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/VQmiztD9Oo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQkue5SWoAA0R-u.jpg",
      "id_str" : "651102729440501760",
      "id" : 651102729440501760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQkue5SWoAA0R-u.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/VQmiztD9Oo"
    } ],
    "hashtags" : [ {
      "text" : "TPP",
      "indices" : [ 109, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651102823439011842",
  "text" : "This isn't your mom's or dad's trade deal.\nPresident Obama's trade agreement would benefit American workers. #TPP http:\/\/t.co\/VQmiztD9Oo",
  "id" : 651102823439011842,
  "created_at" : "2015-10-05 18:33:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StopGunViolence",
      "indices" : [ 113, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651092831617052672",
  "text" : "RT @vj44: In the last year, California, Oregon, Maine, Wisconsin, Delaware &amp; others have passed laws to help #StopGunViolence. https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "StopGunViolence",
        "indices" : [ 103, 119 ]
      } ],
      "urls" : [ {
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/BQnrlciv0U",
        "expanded_url" : "https:\/\/twitter.com\/senatorduff\/status\/651091009531588608",
        "display_url" : "twitter.com\/senatorduff\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "651092782384349185",
    "text" : "In the last year, California, Oregon, Maine, Wisconsin, Delaware &amp; others have passed laws to help #StopGunViolence. https:\/\/t.co\/BQnrlciv0U",
    "id" : 651092782384349185,
    "created_at" : "2015-10-05 17:53:10 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 651092831617052672,
  "created_at" : "2015-10-05 17:53:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StopGunViolence",
      "indices" : [ 107, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651091526060220417",
  "text" : "RT @vj44: Thanks for speaking up and sharing your experience. Your willingness to act will lead to change. #StopGunViolence  https:\/\/t.co\/M\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "StopGunViolence",
        "indices" : [ 97, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/MBimblGMdK",
        "expanded_url" : "https:\/\/twitter.com\/kharyp\/status\/651089475720736768",
        "display_url" : "twitter.com\/kharyp\/status\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "651091370459963393",
    "text" : "Thanks for speaking up and sharing your experience. Your willingness to act will lead to change. #StopGunViolence  https:\/\/t.co\/MBimblGMdK",
    "id" : 651091370459963393,
    "created_at" : "2015-10-05 17:47:34 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 651091526060220417,
  "created_at" : "2015-10-05 17:48:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 11, 17 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StopGunViolence",
      "indices" : [ 53, 69 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/qjtNHcUVcS",
      "expanded_url" : "http:\/\/snpy.tv\/1O6RNn6",
      "display_url" : "snpy.tv\/1O6RNn6"
    }, {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/aHw8FQ4RGV",
      "expanded_url" : "https:\/\/twitter.com\/pastorkriscleve\/status\/651086672831098880",
      "display_url" : "twitter.com\/pastorkrisclev\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "651089550522105857",
  "text" : "RT @vj44: .@POTUS agrees with you. It's time to act. #StopGunViolence http:\/\/t.co\/qjtNHcUVcS https:\/\/t.co\/aHw8FQ4RGV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 1, 7 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "StopGunViolence",
        "indices" : [ 43, 59 ]
      } ],
      "urls" : [ {
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/qjtNHcUVcS",
        "expanded_url" : "http:\/\/snpy.tv\/1O6RNn6",
        "display_url" : "snpy.tv\/1O6RNn6"
      }, {
        "indices" : [ 83, 106 ],
        "url" : "https:\/\/t.co\/aHw8FQ4RGV",
        "expanded_url" : "https:\/\/twitter.com\/pastorkriscleve\/status\/651086672831098880",
        "display_url" : "twitter.com\/pastorkrisclev\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "651088417808359424",
    "text" : ".@POTUS agrees with you. It's time to act. #StopGunViolence http:\/\/t.co\/qjtNHcUVcS https:\/\/t.co\/aHw8FQ4RGV",
    "id" : 651088417808359424,
    "created_at" : "2015-10-05 17:35:50 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 651089550522105857,
  "created_at" : "2015-10-05 17:40:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StopGunViolence",
      "indices" : [ 70, 86 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/Q5zOxwEbDO",
      "expanded_url" : "https:\/\/twitter.com\/MeghanAdamoli\/status\/651086958509322240",
      "display_url" : "twitter.com\/MeghanAdamoli\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "651087909836181504",
  "text" : "RT @vj44: 93% of Americans agree with you! Thanks for speaking out to #StopGunViolence.  https:\/\/t.co\/Q5zOxwEbDO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "StopGunViolence",
        "indices" : [ 60, 76 ]
      } ],
      "urls" : [ {
        "indices" : [ 79, 102 ],
        "url" : "https:\/\/t.co\/Q5zOxwEbDO",
        "expanded_url" : "https:\/\/twitter.com\/MeghanAdamoli\/status\/651086958509322240",
        "display_url" : "twitter.com\/MeghanAdamoli\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "651087787089899520",
    "text" : "93% of Americans agree with you! Thanks for speaking out to #StopGunViolence.  https:\/\/t.co\/Q5zOxwEbDO",
    "id" : 651087787089899520,
    "created_at" : "2015-10-05 17:33:19 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 651087909836181504,
  "created_at" : "2015-10-05 17:33:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StopGunViolence",
      "indices" : [ 65, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651086797410332672",
  "text" : "RT @vj44: That's terrific! Glad to have you join our movement to #StopGunViolence. Keep organizing your fellow Texans. https:\/\/t.co\/D7ROlTv\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "StopGunViolence",
        "indices" : [ 55, 71 ]
      } ],
      "urls" : [ {
        "indices" : [ 109, 132 ],
        "url" : "https:\/\/t.co\/D7ROlTv09w",
        "expanded_url" : "https:\/\/twitter.com\/mamavisions\/status\/651086032180416512",
        "display_url" : "twitter.com\/mamavisions\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "651086652408995840",
    "text" : "That's terrific! Glad to have you join our movement to #StopGunViolence. Keep organizing your fellow Texans. https:\/\/t.co\/D7ROlTv09w",
    "id" : 651086652408995840,
    "created_at" : "2015-10-05 17:28:49 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 651086797410332672,
  "created_at" : "2015-10-05 17:29:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Julianne Moore",
      "screen_name" : "_juliannemoore",
      "indices" : [ 17, 32 ],
      "id_str" : "229219088",
      "id" : 229219088
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StopGunViolence",
      "indices" : [ 74, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651083044208672769",
  "text" : "RT @vj44: Thanks @_juliannemoore for lending your voice to this effort to #StopGunViolence. Please encourage others to join us https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Julianne Moore",
        "screen_name" : "_juliannemoore",
        "indices" : [ 7, 22 ],
        "id_str" : "229219088",
        "id" : 229219088
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "StopGunViolence",
        "indices" : [ 64, 80 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/f8CRdtjkCL",
        "expanded_url" : "https:\/\/twitter.com\/_juliannemoore\/status\/651073769247604736",
        "display_url" : "twitter.com\/_juliannemoore\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "651082079262871552",
    "text" : "Thanks @_juliannemoore for lending your voice to this effort to #StopGunViolence. Please encourage others to join us https:\/\/t.co\/f8CRdtjkCL",
    "id" : 651082079262871552,
    "created_at" : "2015-10-05 17:10:38 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 651083044208672769,
  "created_at" : "2015-10-05 17:14:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Sandy Hook Promise",
      "screen_name" : "sandyhook",
      "indices" : [ 47, 57 ],
      "id_str" : "1032290077",
      "id" : 1032290077
    }, {
      "name" : "Moms Demand Action",
      "screen_name" : "MomsDemand",
      "indices" : [ 58, 69 ],
      "id_str" : "1017637447",
      "id" : 1017637447
    }, {
      "name" : "ARS",
      "screen_name" : "resp_solutions",
      "indices" : [ 76, 91 ],
      "id_str" : "2796999726",
      "id" : 2796999726
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651080194044903426",
  "text" : "RT @vj44: Thanks for all your questions for me @SandyHook @MomsDemand &amp; @resp_solutions. But B4 we get to your questions... http:\/\/t.co\/bUW\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sandy Hook Promise",
        "screen_name" : "sandyhook",
        "indices" : [ 37, 47 ],
        "id_str" : "1032290077",
        "id" : 1032290077
      }, {
        "name" : "Moms Demand Action",
        "screen_name" : "MomsDemand",
        "indices" : [ 48, 59 ],
        "id_str" : "1017637447",
        "id" : 1017637447
      }, {
        "name" : "ARS",
        "screen_name" : "resp_solutions",
        "indices" : [ 66, 81 ],
        "id_str" : "2796999726",
        "id" : 2796999726
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Alex44\/status\/651079538454216706\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/bUWUUvwJis",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQkZWCZU8AAMjS4.jpg",
        "id_str" : "651079487522664448",
        "id" : 651079487522664448,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQkZWCZU8AAMjS4.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/bUWUUvwJis"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "651079718557614080",
    "text" : "Thanks for all your questions for me @SandyHook @MomsDemand &amp; @resp_solutions. But B4 we get to your questions... http:\/\/t.co\/bUWUUvwJis",
    "id" : 651079718557614080,
    "created_at" : "2015-10-05 17:01:16 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 651080194044903426,
  "created_at" : "2015-10-05 17:03:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Moms Demand Action",
      "screen_name" : "MomsDemand",
      "indices" : [ 47, 58 ],
      "id_str" : "1017637447",
      "id" : 1017637447
    }, {
      "name" : "Sandy Hook Promise",
      "screen_name" : "sandyhook",
      "indices" : [ 60, 70 ],
      "id_str" : "1032290077",
      "id" : 1032290077
    }, {
      "name" : "ARS",
      "screen_name" : "resp_solutions",
      "indices" : [ 77, 92 ],
      "id_str" : "2796999726",
      "id" : 2796999726
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StopGunViolence",
      "indices" : [ 114, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651078390108286976",
  "text" : "RT @vj44: Tune in @ 1pm ET-join Q&amp;A w\/ me, @MomsDemand, @SandyHook &amp; @resp_solutions on gun violence. Use #StopGunViolence for questions &amp; \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Moms Demand Action",
        "screen_name" : "MomsDemand",
        "indices" : [ 37, 48 ],
        "id_str" : "1017637447",
        "id" : 1017637447
      }, {
        "name" : "Sandy Hook Promise",
        "screen_name" : "sandyhook",
        "indices" : [ 50, 60 ],
        "id_str" : "1032290077",
        "id" : 1032290077
      }, {
        "name" : "ARS",
        "screen_name" : "resp_solutions",
        "indices" : [ 67, 82 ],
        "id_str" : "2796999726",
        "id" : 2796999726
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "StopGunViolence",
        "indices" : [ 104, 120 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "651077246099128320",
    "text" : "Tune in @ 1pm ET-join Q&amp;A w\/ me, @MomsDemand, @SandyHook &amp; @resp_solutions on gun violence. Use #StopGunViolence for questions &amp; solutions.",
    "id" : 651077246099128320,
    "created_at" : "2015-10-05 16:51:26 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 651078390108286976,
  "created_at" : "2015-10-05 16:55:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sally Jewell",
      "screen_name" : "SecretaryJewell",
      "indices" : [ 3, 19 ],
      "id_str" : "1342861723",
      "id" : 1342861723
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TPP",
      "indices" : [ 134, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651072650480087041",
  "text" : "RT @SecretaryJewell: Our kids should have a chance to see elephants &amp; rhinos roaming the wild; trade deal can help that happen.SJ #TPP http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SecretaryJewell\/status\/651070743829057536\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/QvesCa8bzg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQkRZA_UkAMcwMU.jpg",
        "id_str" : "651070742591737859",
        "id" : 651070742591737859,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQkRZA_UkAMcwMU.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1365,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/QvesCa8bzg"
      } ],
      "hashtags" : [ {
        "text" : "TPP",
        "indices" : [ 113, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "651070743829057536",
    "text" : "Our kids should have a chance to see elephants &amp; rhinos roaming the wild; trade deal can help that happen.SJ #TPP http:\/\/t.co\/QvesCa8bzg",
    "id" : 651070743829057536,
    "created_at" : "2015-10-05 16:25:36 +0000",
    "user" : {
      "name" : "Sally Jewell",
      "screen_name" : "SecretaryJewell",
      "protected" : false,
      "id_str" : "1342861723",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3525481506\/1ddf16c2cb47608803abe4dc7fc133fe_normal.jpeg",
      "id" : 1342861723,
      "verified" : true
    }
  },
  "id" : 651072650480087041,
  "created_at" : "2015-10-05 16:33:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 23, 29 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OurOcean2015",
      "indices" : [ 97, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/3G9TWHHakt",
      "expanded_url" : "http:\/\/go.wh.gov\/9UxhM3",
      "display_url" : "go.wh.gov\/9UxhM3"
    }, {
      "indices" : [ 111, 134 ],
      "url" : "https:\/\/t.co\/sUwI83mNxA",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/6b853bbc-acb0-4cbf-a8f2-d375befed026",
      "display_url" : "amp.twimg.com\/v\/6b853bbc-acb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "651070252453789696",
  "text" : "RT to spread the word: @POTUS just announced two new marine sanctuaries \u2192 http:\/\/t.co\/3G9TWHHakt #OurOcean2015\nhttps:\/\/t.co\/sUwI83mNxA",
  "id" : 651070252453789696,
  "created_at" : "2015-10-05 16:23:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/651058575838724096\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/xCpvJbIlGC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQkF-iXWUAAfOCB.jpg",
      "id_str" : "651058193066512384",
      "id" : 651058193066512384,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQkF-iXWUAAfOCB.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/xCpvJbIlGC"
    } ],
    "hashtags" : [ {
      "text" : "TPP",
      "indices" : [ 111, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/RCNK0hj6NP",
      "expanded_url" : "http:\/\/go.wh.gov\/trade",
      "display_url" : "go.wh.gov\/trade"
    } ]
  },
  "geo" : { },
  "id_str" : "651058575838724096",
  "text" : "More exports = more U.S. jobs.\n\nLet's help our businesses sell more American products \u2192 http:\/\/t.co\/RCNK0hj6NP #TPP http:\/\/t.co\/xCpvJbIlGC",
  "id" : 651058575838724096,
  "created_at" : "2015-10-05 15:37:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "indices" : [ 3, 13 ],
      "id_str" : "15007149",
      "id" : 15007149
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TPP",
      "indices" : [ 15, 19 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651054106493239296",
  "text" : "RT @JohnKerry: #TPP will have immediate, positive effects for US economy, will shape our econ &amp; strategic relationships in Asia-Pacific lon\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TPP",
        "indices" : [ 0, 4 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "651045503132692480",
    "text" : "#TPP will have immediate, positive effects for US economy, will shape our econ &amp; strategic relationships in Asia-Pacific long into future.",
    "id" : 651045503132692480,
    "created_at" : "2015-10-05 14:45:18 +0000",
    "user" : {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "protected" : false,
      "id_str" : "15007149",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/482149339842617346\/l6b7LXjb_normal.jpeg",
      "id" : 15007149,
      "verified" : true
    }
  },
  "id" : 651054106493239296,
  "created_at" : "2015-10-05 15:19:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/651050606094749696\/photo\/1",
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/mPvsuaRXET",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQj-9A4WoAU99nX.jpg",
      "id_str" : "651050470316875781",
      "id" : 651050470316875781,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQj-9A4WoAU99nX.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/mPvsuaRXET"
    } ],
    "hashtags" : [ {
      "text" : "TPP",
      "indices" : [ 98, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/8iqgQCfoZZ",
      "expanded_url" : "http:\/\/nyti.ms\/1Q0NngA",
      "display_url" : "nyti.ms\/1Q0NngA"
    } ]
  },
  "geo" : { },
  "id_str" : "651050606094749696",
  "text" : "\"Environmentalists praise wildlife measures in Trans-Pacific trade pact\" \u2192 http:\/\/t.co\/8iqgQCfoZZ #TPP http:\/\/t.co\/mPvsuaRXET",
  "id" : 651050606094749696,
  "created_at" : "2015-10-05 15:05:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/651032069779361792\/photo\/1",
      "indices" : [ 120, 142 ],
      "url" : "http:\/\/t.co\/xU7059CDmA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQjtZkqWUAApUxj.jpg",
      "id_str" : "651031169748848640",
      "id" : 651031169748848640,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQjtZkqWUAApUxj.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/xU7059CDmA"
    } ],
    "hashtags" : [ {
      "text" : "TPP",
      "indices" : [ 115, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "651032069779361792",
  "text" : ".@POTUS's trade deal includes the strongest labor &amp; environmental standards of any trade agreement in history. #TPP http:\/\/t.co\/xU7059CDmA",
  "id" : 651032069779361792,
  "created_at" : "2015-10-05 13:51:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 26, 32 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/651026113767055360\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/SFXtD1fKys",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQjowR2W8AA3RS5.jpg",
      "id_str" : "651026062277799936",
      "id" : 651026062277799936,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQjowR2W8AA3RS5.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/SFXtD1fKys"
    } ],
    "hashtags" : [ {
      "text" : "TPP",
      "indices" : [ 111, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/RCNK0hj6NP",
      "expanded_url" : "http:\/\/go.wh.gov\/trade",
      "display_url" : "go.wh.gov\/trade"
    } ]
  },
  "geo" : { },
  "id_str" : "651026113767055360",
  "text" : "Big win for U.S. workers: @POTUS just secured a trade deal that helps the middle class. http:\/\/t.co\/RCNK0hj6NP #TPP http:\/\/t.co\/SFXtD1fKys",
  "id" : 651026113767055360,
  "created_at" : "2015-10-05 13:28:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Washington Post",
      "screen_name" : "washingtonpost",
      "indices" : [ 3, 18 ],
      "id_str" : "2467791",
      "id" : 2467791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/EAbPoA5XRy",
      "expanded_url" : "http:\/\/wapo.st\/1hled77",
      "display_url" : "wapo.st\/1hled77"
    } ]
  },
  "geo" : { },
  "id_str" : "651023973535322112",
  "text" : "RT @washingtonpost: Obama just announced the first new marine sanctuaries in 15 years http:\/\/t.co\/EAbPoA5XRy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 88 ],
        "url" : "http:\/\/t.co\/EAbPoA5XRy",
        "expanded_url" : "http:\/\/wapo.st\/1hled77",
        "display_url" : "wapo.st\/1hled77"
      } ]
    },
    "geo" : { },
    "id_str" : "651017861729775616",
    "text" : "Obama just announced the first new marine sanctuaries in 15 years http:\/\/t.co\/EAbPoA5XRy",
    "id" : 651017861729775616,
    "created_at" : "2015-10-05 12:55:28 +0000",
    "user" : {
      "name" : "Washington Post",
      "screen_name" : "washingtonpost",
      "protected" : false,
      "id_str" : "2467791",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/753656134565785600\/iQ1GX-ov_normal.jpg",
      "id" : 2467791,
      "verified" : true
    }
  },
  "id" : 651023973535322112,
  "created_at" : "2015-10-05 13:19:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Moms Demand Action",
      "screen_name" : "MomsDemand",
      "indices" : [ 37, 48 ],
      "id_str" : "1017637447",
      "id" : 1017637447
    }, {
      "name" : "Sandy Hook Promise",
      "screen_name" : "sandyhook",
      "indices" : [ 55, 65 ],
      "id_str" : "1032290077",
      "id" : 1032290077
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "650782631634669568",
  "text" : "RT @vj44: Enough is enough.\nJoin me, @MomsDemand &amp; @SandyHook Mon at 1pm ET for a gun violence Q&amp;A. Ask Qs or offer solutions with #StopGun\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Moms Demand Action",
        "screen_name" : "MomsDemand",
        "indices" : [ 27, 38 ],
        "id_str" : "1017637447",
        "id" : 1017637447
      }, {
        "name" : "Sandy Hook Promise",
        "screen_name" : "sandyhook",
        "indices" : [ 45, 55 ],
        "id_str" : "1032290077",
        "id" : 1032290077
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "StopGunViolence",
        "indices" : [ 129, 145 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "650782003953012736",
    "text" : "Enough is enough.\nJoin me, @MomsDemand &amp; @SandyHook Mon at 1pm ET for a gun violence Q&amp;A. Ask Qs or offer solutions with #StopGunViolence.",
    "id" : 650782003953012736,
    "created_at" : "2015-10-04 21:18:15 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 650782631634669568,
  "created_at" : "2015-10-04 21:20:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 106, 112 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "650697269356929024",
  "text" : "RT @WHLive: \"The American people stand with you in honoring your loved ones...we hold you in our hearts\" \u2014@POTUS to families of fallen fire\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 94, 100 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "650697242077171712",
    "text" : "\"The American people stand with you in honoring your loved ones...we hold you in our hearts\" \u2014@POTUS to families of fallen firefighters",
    "id" : 650697242077171712,
    "created_at" : "2015-10-04 15:41:26 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 650697269356929024,
  "created_at" : "2015-10-04 15:41:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 128, 134 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "650696791122284545",
  "text" : "\"At the season\u2019s peak, 32,000 firefighters were battling blazes from California to North Carolina.  13 have lost their lives.\" \u2014@POTUS",
  "id" : 650696791122284545,
  "created_at" : "2015-10-04 15:39:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 115, 121 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 122, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "650696692531097601",
  "text" : "\"So far this year, nearly 50,000 wildfires have burned more than 9 million acres\u2014an area larger than...Maryland.\" \u2014@POTUS #ActOnClimate",
  "id" : 650696692531097601,
  "created_at" : "2015-10-04 15:39:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 84, 90 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/qXUTUAjWk8",
      "expanded_url" : "http:\/\/go.wh.gov\/rvBFZc",
      "display_url" : "go.wh.gov\/rvBFZc"
    } ]
  },
  "geo" : { },
  "id_str" : "650695210385715200",
  "text" : "RT @WHLive: \"It is hard to think of a more selfless profession than firefighting.\" \u2014@POTUS: http:\/\/t.co\/qXUTUAjWk8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 72, 78 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/qXUTUAjWk8",
        "expanded_url" : "http:\/\/go.wh.gov\/rvBFZc",
        "display_url" : "go.wh.gov\/rvBFZc"
      } ]
    },
    "geo" : { },
    "id_str" : "650695181130313728",
    "text" : "\"It is hard to think of a more selfless profession than firefighting.\" \u2014@POTUS: http:\/\/t.co\/qXUTUAjWk8",
    "id" : 650695181130313728,
    "created_at" : "2015-10-04 15:33:15 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 650695210385715200,
  "created_at" : "2015-10-04 15:33:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 94, 100 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/eAjKP8vVsR",
      "expanded_url" : "http:\/\/go.wh.gov\/rvBFZc",
      "display_url" : "go.wh.gov\/rvBFZc"
    } ]
  },
  "geo" : { },
  "id_str" : "650695026813480960",
  "text" : "\"Today, we gather to honor 87 brave firefighters who gave their lives in service to us all.\" \u2014@POTUS: http:\/\/t.co\/eAjKP8vVsR",
  "id" : 650695026813480960,
  "created_at" : "2015-10-04 15:32:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 142, 148 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "650694924581507072",
  "text" : "\"Every...day across our country men &amp; women leave their homes &amp;...families so they might save the lives of people they\u2019ve never met\" \u2014@POTUS",
  "id" : 650694924581507072,
  "created_at" : "2015-10-04 15:32:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 12, 18 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/eAjKP8vVsR",
      "expanded_url" : "http:\/\/go.wh.gov\/rvBFZc",
      "display_url" : "go.wh.gov\/rvBFZc"
    } ]
  },
  "geo" : { },
  "id_str" : "650694350435803139",
  "text" : "Watch live: @POTUS speaks at the Fallen Firefighters Memorial Service \u2192 http:\/\/t.co\/eAjKP8vVsR",
  "id" : 650694350435803139,
  "created_at" : "2015-10-04 15:29:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/650461412146462721\/photo\/1",
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/EwgNap77O2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQbnL6tXAAA9AWr.png",
      "id_str" : "650461388125700096",
      "id" : 650461388125700096,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQbnL6tXAAA9AWr.png",
      "sizes" : [ {
        "h" : 108,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 257,
        "resize" : "fit",
        "w" : 808
      }, {
        "h" : 257,
        "resize" : "fit",
        "w" : 808
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/EwgNap77O2"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "650461412146462721",
  "text" : "President Obama's statement on the casualties in Kunduz: http:\/\/t.co\/EwgNap77O2",
  "id" : 650461412146462721,
  "created_at" : "2015-10-04 00:04:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 19, 25 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 30, 37 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/650433162623979520\/photo\/1",
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/XeCVPhd0l8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQbNd3vW8AELZZh.jpg",
      "id_str" : "650433109264101377",
      "id" : 650433109264101377,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQbNd3vW8AELZZh.jpg",
      "sizes" : [ {
        "h" : 493,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 567,
        "resize" : "fit",
        "w" : 690
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 567,
        "resize" : "fit",
        "w" : 690
      }, {
        "h" : 279,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/XeCVPhd0l8"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/650433162623979520\/photo\/1",
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/XeCVPhd0l8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQbNd9gWwAApu9u.jpg",
      "id_str" : "650433110811787264",
      "id" : 650433110811787264,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQbNd9gWwAApu9u.jpg",
      "sizes" : [ {
        "h" : 714,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 714,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 237,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 418,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/XeCVPhd0l8"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "650433162623979520",
  "text" : "Happy Anniversary, @POTUS and @FLOTUS! http:\/\/t.co\/XeCVPhd0l8",
  "id" : 650433162623979520,
  "created_at" : "2015-10-03 22:12:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 93, 99 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/ru2R37FUps",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/41ead01a-8286-464f-b1b1-1dcaa98aa989",
      "display_url" : "amp.twimg.com\/v\/41ead01a-828\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "650389149929705472",
  "text" : "\"Congress should do its job, stop kicking the can down the road, and pass a serious budget\" \u2014@POTUS\nhttps:\/\/t.co\/ru2R37FUps",
  "id" : 650389149929705472,
  "created_at" : "2015-10-03 19:17:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 107, 113 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/DX2JbrxNRJ",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/f708b548-dcf2-4f5d-ac5e-f25deac6b3d0",
      "display_url" : "amp.twimg.com\/v\/f708b548-dcf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "650321717458415616",
  "text" : "\"I will not sign another shortsighted, short-term spending bill like the one Congress sent me this week.\" \u2014@POTUS\nhttps:\/\/t.co\/DX2JbrxNRJ",
  "id" : 650321717458415616,
  "created_at" : "2015-10-03 14:49:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/fema\/status\/650036588672589824\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/7FI2Vr1sSG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQVk1S8VAAAPmWN.jpg",
      "id_str" : "650036588005621760",
      "id" : 650036588005621760,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQVk1S8VAAAPmWN.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/7FI2Vr1sSG"
    } ],
    "hashtags" : [ {
      "text" : "Joaquin",
      "indices" : [ 15, 23 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/NTXKQVVp0Y",
      "expanded_url" : "http:\/\/go.wh.gov\/Joaquin",
      "display_url" : "go.wh.gov\/Joaquin"
    } ]
  },
  "geo" : { },
  "id_str" : "650096342329520129",
  "text" : "With Hurricane #Joaquin impacting the East Coast, here are resources to stay safe \u2192 http:\/\/t.co\/NTXKQVVp0Y http:\/\/t.co\/7FI2Vr1sSG",
  "id" : 650096342329520129,
  "created_at" : "2015-10-02 23:53:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 89, 100 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThanksArne",
      "indices" : [ 101, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/mVMLKnPyEW",
      "expanded_url" : "http:\/\/snpy.tv\/1iRPpVn",
      "display_url" : "snpy.tv\/1iRPpVn"
    } ]
  },
  "geo" : { },
  "id_str" : "650082292585627648",
  "text" : "\"I love this work.\nI love this team.\nI love the President.\nI love the chance to serve.\" \u2014@ArneDuncan #ThanksArne http:\/\/t.co\/mVMLKnPyEW",
  "id" : 650082292585627648,
  "created_at" : "2015-10-02 22:57:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/650019884643000324\/photo\/1",
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/678zlzojmc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQVVo7vWcAAphEp.jpg",
      "id_str" : "650019882944327680",
      "id" : 650019882944327680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQVVo7vWcAAphEp.jpg",
      "sizes" : [ {
        "h" : 430,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 243,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 2644,
        "resize" : "fit",
        "w" : 3693
      }, {
        "h" : 733,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/678zlzojmc"
    } ],
    "hashtags" : [ {
      "text" : "parksforall",
      "indices" : [ 43, 55 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "650075308494708737",
  "text" : "RT @Interior: Please retweet if you agree! #parksforall http:\/\/t.co\/678zlzojmc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/650019884643000324\/photo\/1",
        "indices" : [ 42, 64 ],
        "url" : "http:\/\/t.co\/678zlzojmc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQVVo7vWcAAphEp.jpg",
        "id_str" : "650019882944327680",
        "id" : 650019882944327680,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQVVo7vWcAAphEp.jpg",
        "sizes" : [ {
          "h" : 430,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 243,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 2644,
          "resize" : "fit",
          "w" : 3693
        }, {
          "h" : 733,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/678zlzojmc"
      } ],
      "hashtags" : [ {
        "text" : "parksforall",
        "indices" : [ 29, 41 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "650019884643000324",
    "text" : "Please retweet if you agree! #parksforall http:\/\/t.co\/678zlzojmc",
    "id" : 650019884643000324,
    "created_at" : "2015-10-02 18:49:51 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 650075308494708737,
  "created_at" : "2015-10-02 22:30:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "indices" : [ 3, 11 ],
      "id_str" : "1135399020",
      "id" : 1135399020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "650067559962640384",
  "text" : "RT @Simas44: When climate deniers say that America shouldn't act alone, tell them they're right and show them this. 140 countries! http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Simas44\/status\/650062523979313152\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/d2DU3MBIs6",
        "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CQV8a64UkAA2tvy.png",
        "id_str" : "650062523148832768",
        "id" : 650062523148832768,
        "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CQV8a64UkAA2tvy.png",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/d2DU3MBIs6"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "650062523979313152",
    "text" : "When climate deniers say that America shouldn't act alone, tell them they're right and show them this. 140 countries! http:\/\/t.co\/d2DU3MBIs6",
    "id" : 650062523979313152,
    "created_at" : "2015-10-02 21:39:17 +0000",
    "user" : {
      "name" : "David Simas",
      "screen_name" : "Simas44",
      "protected" : false,
      "id_str" : "1135399020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313031546\/a51b08bca59525cb3d380459db4035fd_normal.jpeg",
      "id" : 1135399020,
      "verified" : true
    }
  },
  "id" : 650067559962640384,
  "created_at" : "2015-10-02 21:59:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/650059264518565889\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/6d27XQAPyi",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CQV5BCdWUAEbGRo.png",
      "id_str" : "650058779971702785",
      "id" : 650058779971702785,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CQV5BCdWUAEbGRo.png",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/6d27XQAPyi"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 53, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/VVI6byyA7h",
      "expanded_url" : "http:\/\/go.wh.gov\/ActOnClimate",
      "display_url" : "go.wh.gov\/ActOnClimate"
    } ]
  },
  "geo" : { },
  "id_str" : "650059264518565889",
  "text" : "There's never been more momentum around the world to #ActOnClimate.\nGet the latest \u2192 http:\/\/t.co\/VVI6byyA7h http:\/\/t.co\/6d27XQAPyi",
  "id" : 650059264518565889,
  "created_at" : "2015-10-02 21:26:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 89, 95 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Pope Francis",
      "screen_name" : "Pontifex",
      "indices" : [ 99, 108 ],
      "id_str" : "500704345",
      "id" : 500704345
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/650050351840788480\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/wN3gI9KkEP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQVxMzNWIAAc8i7.jpg",
      "id_str" : "650050185943457792",
      "id" : 650050185943457792,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQVxMzNWIAAc8i7.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1920,
        "resize" : "fit",
        "w" : 2880
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/wN3gI9KkEP"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "650050351840788480",
  "text" : "\u201CPope Francis, I love. He is a good man with a warm heart and a big moral imagination.\u201D \u2014@POTUS on @Pontifex http:\/\/t.co\/wN3gI9KkEP",
  "id" : 650050351840788480,
  "created_at" : "2015-10-02 20:50:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/QEf9JmxSnK",
      "expanded_url" : "http:\/\/snpy.tv\/1Gp8PXd",
      "display_url" : "snpy.tv\/1Gp8PXd"
    } ]
  },
  "geo" : { },
  "id_str" : "650047911804436480",
  "text" : "Reminder: Raising the debt ceiling is not about more spending.\nIt\u2019s Congress paying bills they\u2019ve already incurred. http:\/\/t.co\/QEf9JmxSnK",
  "id" : 650047911804436480,
  "created_at" : "2015-10-02 20:41:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 84, 90 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/eoz4mT2cDr",
      "expanded_url" : "http:\/\/snpy.tv\/1O9tFA3",
      "display_url" : "snpy.tv\/1O9tFA3"
    } ]
  },
  "geo" : { },
  "id_str" : "650045467989016576",
  "text" : "\"This is happening every single day in forgotten neighborhoods around the country\" \u2014@POTUS on gun violence http:\/\/t.co\/eoz4mT2cDr",
  "id" : 650045467989016576,
  "created_at" : "2015-10-02 20:31:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 84, 90 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "650044422701383680",
  "text" : "\"Make sure that anybody that you\u2019re voting for is on the right side of this issue\" \u2014@POTUS on what it will take to reduce gun violence",
  "id" : 650044422701383680,
  "created_at" : "2015-10-02 20:27:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 60, 66 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "650043536650338304",
  "text" : "\"Our inaction is a political decision that we are making.\" \u2014@POTUS to those in Congress who are blocking action to reduce gun violence",
  "id" : 650043536650338304,
  "created_at" : "2015-10-02 20:23:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 98, 104 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "650043279296172032",
  "text" : "\"This will not change until the politics changes and the behavior of elected officials changes.\" \u2014@POTUS on action to reduce gun violence",
  "id" : 650043279296172032,
  "created_at" : "2015-10-02 20:22:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 95, 101 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/glKoik4QB1",
      "expanded_url" : "http:\/\/snpy.tv\/1O9qfxh",
      "display_url" : "snpy.tv\/1O9qfxh"
    } ]
  },
  "geo" : { },
  "id_str" : "650039134149603332",
  "text" : "\"I will not sign another shortsighted spending bill like the one Congress sent me this week.\" \u2014@POTUS http:\/\/t.co\/glKoik4QB1",
  "id" : 650039134149603332,
  "created_at" : "2015-10-02 20:06:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 100, 106 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/650038264993329152\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/Ngju3NiiXu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQVmUMhWsAAwzGS.jpg",
      "id_str" : "650038218369445888",
      "id" : 650038218369445888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQVmUMhWsAAwzGS.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Ngju3NiiXu"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "650038264993329152",
  "text" : "\"We\u2019ve cut our deficits by two-thirds...they\u2019re below the average deficit over the past 40 years.\" \u2014@POTUS http:\/\/t.co\/Ngju3NiiXu",
  "id" : 650038264993329152,
  "created_at" : "2015-10-02 20:02:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 39, 45 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "650038133371723776",
  "text" : "\"We can\u2019t cut our way to prosperity.\" \u2014@POTUS on harmful spending cuts that need to be undone by Congress",
  "id" : 650038133371723776,
  "created_at" : "2015-10-02 20:02:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 115, 121 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "650037460148293632",
  "text" : "\"I want to be clear. I will not sign another shortsighted spending bill like the one Congress sent me this week.\" \u2014@POTUS",
  "id" : 650037460148293632,
  "created_at" : "2015-10-02 19:59:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 115, 121 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "650036994685317120",
  "text" : "\"On Wednesday, more than half of Republicans voted to shut down the government for the second time in two years.\" \u2014@POTUS",
  "id" : 650036994685317120,
  "created_at" : "2015-10-02 19:57:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 121, 127 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "650036880243847168",
  "text" : "\"We would be doing even better if we didn\u2019t have to keep dealing with unnecessary crises in Congress every few months.\" \u2014@POTUS",
  "id" : 650036880243847168,
  "created_at" : "2015-10-02 19:57:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 44, 55 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/JdUWCgokML",
      "expanded_url" : "http:\/\/snpy.tv\/1JKw6D3",
      "display_url" : "snpy.tv\/1JKw6D3"
    } ]
  },
  "geo" : { },
  "id_str" : "650035325448798208",
  "text" : ".@POTUS on outgoing Secretary of Education, @ArneDuncan. http:\/\/t.co\/JdUWCgokML",
  "id" : 650035325448798208,
  "created_at" : "2015-10-02 19:51:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 99, 105 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 109, 120 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "650034037759676416",
  "text" : "RT @WHLive: \"We've got an exceptionally talented educator to step in, and that is Dr. John King.\" \u2014@POTUS on @ArneDuncan's successor",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 87, 93 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "Arne Duncan",
        "screen_name" : "arneduncan",
        "indices" : [ 97, 108 ],
        "id_str" : "4662969794",
        "id" : 4662969794
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "650034012359118848",
    "text" : "\"We've got an exceptionally talented educator to step in, and that is Dr. John King.\" \u2014@POTUS on @ArneDuncan's successor",
    "id" : 650034012359118848,
    "created_at" : "2015-10-02 19:46:00 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 650034037759676416,
  "created_at" : "2015-10-02 19:46:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 84, 90 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 94, 105 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/650033698415349761\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/1G9kTn1ZUk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQViITaWIAAJQif.jpg",
      "id_str" : "650033616014155776",
      "id" : 650033616014155776,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQViITaWIAAJQif.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 683
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 683
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/1G9kTn1ZUk"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "650033698415349761",
  "text" : "\"Arne holds the record for most points scored in the NBA All-Star celebrity game.\" \u2014@POTUS on @ArneDuncan http:\/\/t.co\/1G9kTn1ZUk",
  "id" : 650033698415349761,
  "created_at" : "2015-10-02 19:44:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 100, 106 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/650033527283707904\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/bwiMPoiUmm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQViB54WoAAMejl.jpg",
      "id_str" : "650033506081480704",
      "id" : 650033506081480704,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQViB54WoAAMejl.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/bwiMPoiUmm"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "650033527283707904",
  "text" : "\"We\u2019ve helped millions more families afford college, and more Americans are graduating than ever.\" \u2014@POTUS http:\/\/t.co\/bwiMPoiUmm",
  "id" : 650033527283707904,
  "created_at" : "2015-10-02 19:44:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 58, 64 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Arne Duncan",
      "screen_name" : "arneduncan",
      "indices" : [ 68, 79 ],
      "id_str" : "4662969794",
      "id" : 4662969794
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/650033404000407553\/photo\/1",
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/wxgJjrLNnV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQVh6xZWEAAUwU1.jpg",
      "id_str" : "650033383544852480",
      "id" : 650033383544852480,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQVh6xZWEAAUwU1.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/wxgJjrLNnV"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "650033404000407553",
  "text" : "\"Our high school graduation rate is at an all-time high\" \u2014@POTUS on @ArneDuncan's legacy http:\/\/t.co\/wxgJjrLNnV",
  "id" : 650033404000407553,
  "created_at" : "2015-10-02 19:43:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 122, 128 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "650033248647647232",
  "text" : "RT @WHLive: \"He\u2019s one of the longest-serving secretaries of education in our history\u2014and one of the more consequential.\" \u2014@POTUS on @arnedu\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 110, 116 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "Arne Duncan",
        "screen_name" : "arneduncan",
        "indices" : [ 120, 131 ],
        "id_str" : "4662969794",
        "id" : 4662969794
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "650033227529256960",
    "text" : "\"He\u2019s one of the longest-serving secretaries of education in our history\u2014and one of the more consequential.\" \u2014@POTUS on @arneduncan",
    "id" : 650033227529256960,
    "created_at" : "2015-10-02 19:42:53 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 650033248647647232,
  "created_at" : "2015-10-02 19:42:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 24, 30 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/FQrt5jXS7N",
      "expanded_url" : "http:\/\/go.wh.gov\/NZsCfs",
      "display_url" : "go.wh.gov\/NZsCfs"
    } ]
  },
  "geo" : { },
  "id_str" : "650032827027836928",
  "text" : "Happening now: Watch as @POTUS holds a press conference and makes a personnel announcement \u2192 http:\/\/t.co\/FQrt5jXS7N",
  "id" : 650032827027836928,
  "created_at" : "2015-10-02 19:41:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/649979243208773632\/photo\/1",
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/Svh3W3NN47",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQUwmXMWwAAmSmD.jpg",
      "id_str" : "649979156843905024",
      "id" : 649979156843905024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQUwmXMWwAAmSmD.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Svh3W3NN47"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "649979243208773632",
  "text" : ".@POTUS on the U.S. military plane crash in Afghanistan. http:\/\/t.co\/Svh3W3NN47",
  "id" : 649979243208773632,
  "created_at" : "2015-10-02 16:08:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 3, 11 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UCCShooting",
      "indices" : [ 122, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "649961708698628097",
  "text" : "RT @DrBiden: Community colleges have a special place in my heart, and my heart goes out to the entire Roseburg community. #UCCShooting \u2013Jill",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UCCShooting",
        "indices" : [ 109, 121 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "649954525265047552",
    "text" : "Community colleges have a special place in my heart, and my heart goes out to the entire Roseburg community. #UCCShooting \u2013Jill",
    "id" : 649954525265047552,
    "created_at" : "2015-10-02 14:30:09 +0000",
    "user" : {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "protected" : false,
      "id_str" : "1281405877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608687663034474496\/wvzVG_yt_normal.jpg",
      "id" : 1281405877,
      "verified" : true
    }
  },
  "id" : 649961708698628097,
  "created_at" : "2015-10-02 14:58:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/649958289325715456\/photo\/1",
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/oE9WWeTGJB",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQUajuEXAAAzPjQ.jpg",
      "id_str" : "649954922188963840",
      "id" : 649954922188963840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQUajuEXAAAzPjQ.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/oE9WWeTGJB"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/yEIWazSTHP",
      "expanded_url" : "http:\/\/go.wh.gov\/SeptJobs",
      "display_url" : "go.wh.gov\/SeptJobs"
    } ]
  },
  "geo" : { },
  "id_str" : "649958289325715456",
  "text" : "The unemployment rate is at its lowest level since early 2008 \u2192 http:\/\/t.co\/yEIWazSTHP http:\/\/t.co\/oE9WWeTGJB",
  "id" : 649958289325715456,
  "created_at" : "2015-10-02 14:45:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/649953043103019008\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/TMOT4dNPpg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQUYvQSXAAAWpp0.jpg",
      "id_str" : "649952921329795072",
      "id" : 649952921329795072,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQUYvQSXAAAWpp0.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/TMOT4dNPpg"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "649953043103019008",
  "text" : "Our businesses have added 13.2 million jobs over 67 months of growth\u2014extending the longest streak on record. http:\/\/t.co\/TMOT4dNPpg",
  "id" : 649953043103019008,
  "created_at" : "2015-10-02 14:24:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/gOGzWmYdxQ",
      "expanded_url" : "https:\/\/twitter.com\/zackbeauchamp\/status\/649727266835046400",
      "display_url" : "twitter.com\/zackbeauchamp\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "649750028161036289",
  "text" : "RT @POTUS: Thanks, Zack. https:\/\/t.co\/gOGzWmYdxQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 14, 37 ],
        "url" : "https:\/\/t.co\/gOGzWmYdxQ",
        "expanded_url" : "https:\/\/twitter.com\/zackbeauchamp\/status\/649727266835046400",
        "display_url" : "twitter.com\/zackbeauchamp\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "649748792099622912",
    "text" : "Thanks, Zack. https:\/\/t.co\/gOGzWmYdxQ",
    "id" : 649748792099622912,
    "created_at" : "2015-10-02 00:52:38 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 649750028161036289,
  "created_at" : "2015-10-02 00:57:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UCCShooting",
      "indices" : [ 104, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/5xQhor8bRM",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/333f588e-58ef-48cf-aed4-554c9f3b092c",
      "display_url" : "amp.twimg.com\/v\/333f588e-58e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "649742970938220544",
  "text" : "We have to come together and take steps to reduce gun violence.\n\nWe have to find the courage to change. #UCCShooting\nhttps:\/\/t.co\/5xQhor8bRM",
  "id" : 649742970938220544,
  "created_at" : "2015-10-02 00:29:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "649737195486482432",
  "text" : "RT @VP: The safest place on earth should be our schools and colleges. My thoughts and prayers are with families who lost folks today #UCCSh\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UCCShooting",
        "indices" : [ 125, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "649733082380136448",
    "text" : "The safest place on earth should be our schools and colleges. My thoughts and prayers are with families who lost folks today #UCCShooting",
    "id" : 649733082380136448,
    "created_at" : "2015-10-01 23:50:12 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 649737195486482432,
  "created_at" : "2015-10-02 00:06:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vox",
      "screen_name" : "voxdotcom",
      "indices" : [ 3, 13 ],
      "id_str" : "2347049341",
      "id" : 2347049341
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/voxdotcom\/status\/649727269045411840\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/XHfbbjcEYs",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CQRLgjvWcAAcJop.png",
      "id_str" : "649727268969934848",
      "id" : 649727268969934848,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQRLgjvWcAAcJop.png",
      "sizes" : [ {
        "h" : 426,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 141,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 633,
        "resize" : "fit",
        "w" : 1521
      }, {
        "h" : 250,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/XHfbbjcEYs"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/eMmJsi7CbY",
      "expanded_url" : "http:\/\/www.vox.com\/2015\/10\/1\/9437187\/obama-guns-terrorism-deaths?utm_campaign=vox&utm_content=chorus&utm_medium=social&utm_source=twitter",
      "display_url" : "vox.com\/2015\/10\/1\/9437\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "649729422518562816",
  "text" : "RT @voxdotcom: Obama challenged the media to compare gun and terrorism deaths. So we did. http:\/\/t.co\/eMmJsi7CbY http:\/\/t.co\/XHfbbjcEYs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.sbnation.com\" rel=\"nofollow\"\u003ESB Nation\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/voxdotcom\/status\/649727269045411840\/photo\/1",
        "indices" : [ 98, 120 ],
        "url" : "http:\/\/t.co\/XHfbbjcEYs",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQRLgjvWcAAcJop.png",
        "id_str" : "649727268969934848",
        "id" : 649727268969934848,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQRLgjvWcAAcJop.png",
        "sizes" : [ {
          "h" : 426,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 141,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 633,
          "resize" : "fit",
          "w" : 1521
        }, {
          "h" : 250,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/XHfbbjcEYs"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/eMmJsi7CbY",
        "expanded_url" : "http:\/\/www.vox.com\/2015\/10\/1\/9437187\/obama-guns-terrorism-deaths?utm_campaign=vox&utm_content=chorus&utm_medium=social&utm_source=twitter",
        "display_url" : "vox.com\/2015\/10\/1\/9437\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "649727269045411840",
    "text" : "Obama challenged the media to compare gun and terrorism deaths. So we did. http:\/\/t.co\/eMmJsi7CbY http:\/\/t.co\/XHfbbjcEYs",
    "id" : 649727269045411840,
    "created_at" : "2015-10-01 23:27:06 +0000",
    "user" : {
      "name" : "Vox",
      "screen_name" : "voxdotcom",
      "protected" : false,
      "id_str" : "2347049341",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/442785905246347265\/v6W3UuIL_normal.jpeg",
      "id" : 2347049341,
      "verified" : true
    }
  },
  "id" : 649729422518562816,
  "created_at" : "2015-10-01 23:35:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 72, 78 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UCCShooting",
      "indices" : [ 97, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/qjtNHcUVcS",
      "expanded_url" : "http:\/\/snpy.tv\/1O6RNn6",
      "display_url" : "snpy.tv\/1O6RNn6"
    } ]
  },
  "geo" : { },
  "id_str" : "649725020680253442",
  "text" : "RT @vj44: \"We are going to have to change our laws.\" Enough is enough - @POTUS needs your help \u2192 #UCCShooting http:\/\/t.co\/qjtNHcUVcS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 62, 68 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UCCShooting",
        "indices" : [ 87, 99 ]
      } ],
      "urls" : [ {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/qjtNHcUVcS",
        "expanded_url" : "http:\/\/snpy.tv\/1O6RNn6",
        "display_url" : "snpy.tv\/1O6RNn6"
      } ]
    },
    "geo" : { },
    "id_str" : "649724753465503744",
    "text" : "\"We are going to have to change our laws.\" Enough is enough - @POTUS needs your help \u2192 #UCCShooting http:\/\/t.co\/qjtNHcUVcS",
    "id" : 649724753465503744,
    "created_at" : "2015-10-01 23:17:07 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 649725020680253442,
  "created_at" : "2015-10-01 23:18:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 97, 103 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UCCShooting",
      "indices" : [ 104, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/8sheX2R0wI",
      "expanded_url" : "http:\/\/snpy.tv\/1O6RNn6",
      "display_url" : "snpy.tv\/1O6RNn6"
    } ]
  },
  "geo" : { },
  "id_str" : "649719223426486272",
  "text" : "\"We are the only advanced country in the world that sees these mass shootings every few months\" \u2014@POTUS #UCCShooting http:\/\/t.co\/8sheX2R0wI",
  "id" : 649719223426486272,
  "created_at" : "2015-10-01 22:55:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 6, 12 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UCCShooting",
      "indices" : [ 63, 75 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/8sheX2zpFa",
      "expanded_url" : "http:\/\/snpy.tv\/1O6RNn6",
      "display_url" : "snpy.tv\/1O6RNn6"
    } ]
  },
  "geo" : { },
  "id_str" : "649715734277435392",
  "text" : "Watch @POTUS speak on the tragic shooting in Roseburg, Oregon. #UCCShooting http:\/\/t.co\/8sheX2zpFa",
  "id" : 649715734277435392,
  "created_at" : "2015-10-01 22:41:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 101, 107 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UCCShooting",
      "indices" : [ 108, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "649714456201678848",
  "text" : "\"May God bless the memories of those who were killed today. May He bring comfort to their families\" \u2014@POTUS #UCCShooting",
  "id" : 649714456201678848,
  "created_at" : "2015-10-01 22:36:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 104, 110 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UCCShooting",
      "indices" : [ 111, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "649714028500111360",
  "text" : "\"If you think this is a problem, then you should expect your elected officials to reflect your views.\" \u2014@POTUS #UCCShooting",
  "id" : 649714028500111360,
  "created_at" : "2015-10-01 22:34:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 94, 100 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UCCShooting",
      "indices" : [ 101, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "649713597694656512",
  "text" : "\"When Americans are killed in floods and hurricanes, we work to make our communities safer.\" \u2014@POTUS #UCCShooting",
  "id" : 649713597694656512,
  "created_at" : "2015-10-01 22:32:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 77, 83 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UCCShooting",
      "indices" : [ 84, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "649713493067718657",
  "text" : "\"When Americans are killed in mine disasters, we work to make mines safer.\" \u2014@POTUS #UCCShooting",
  "id" : 649713493067718657,
  "created_at" : "2015-10-01 22:32:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 114, 120 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UCCShooting",
      "indices" : [ 121, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "649712780430471172",
  "text" : "\"We have a Congress that explicitly blocks us from\u2026collecting data on how we can potentially reduce gun deaths.\" \u2014@POTUS #UCCShooting",
  "id" : 649712780430471172,
  "created_at" : "2015-10-01 22:29:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 70, 76 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UCCShooting",
      "indices" : [ 77, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "649712394172788736",
  "text" : "\"There is a gun for roughly every man, woman, and child in America.\" \u2014@POTUS #UCCShooting",
  "id" : 649712394172788736,
  "created_at" : "2015-10-01 22:28:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 98, 104 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UCCShooting",
      "indices" : [ 105, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "649712161724477442",
  "text" : "\"It cannot be this easy for someone who wants to inflict harm to get his or her hands on a gun.\" \u2014@POTUS #UCCShooting",
  "id" : 649712161724477442,
  "created_at" : "2015-10-01 22:27:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 97, 103 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UCCShooting",
      "indices" : [ 104, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "649712111090802688",
  "text" : "\"We are the only advanced country in the world that sees these mass shooting every few months.\" \u2014@POTUS #UCCShooting",
  "id" : 649712111090802688,
  "created_at" : "2015-10-01 22:26:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 96, 102 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UCCShooting",
      "indices" : [ 103, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "649711478925324288",
  "text" : "\"Our thoughts and prayers are not enough. It does not convey the heartache and anger we feel.\" \u2014@POTUS #UCCShooting",
  "id" : 649711478925324288,
  "created_at" : "2015-10-01 22:24:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 94, 100 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UCCShooting",
      "indices" : [ 101, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "649710782226264064",
  "text" : "\"There\u2019s been another mass shooting in America\u2014this time, at a community college in Oregon.\" \u2014@POTUS #UCCShooting",
  "id" : 649710782226264064,
  "created_at" : "2015-10-01 22:21:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 12, 18 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UCCShooting",
      "indices" : [ 102, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/g3WEdxpHwx",
      "expanded_url" : "http:\/\/go.wh.gov\/K1K9bS",
      "display_url" : "go.wh.gov\/K1K9bS"
    } ]
  },
  "geo" : { },
  "id_str" : "649710726584643588",
  "text" : "Watch live: @POTUS delivers a statement on the shootings in Roseburg, Oregon \u2192 http:\/\/t.co\/g3WEdxpHwx #UCCShooting",
  "id" : 649710726584643588,
  "created_at" : "2015-10-01 22:21:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 14, 20 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UCCShooting",
      "indices" : [ 98, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/g3WEdxpHwx",
      "expanded_url" : "http:\/\/go.wh.gov\/K1K9bS",
      "display_url" : "go.wh.gov\/K1K9bS"
    } ]
  },
  "geo" : { },
  "id_str" : "649702737169522688",
  "text" : "At 6:20pm ET, @POTUS will deliver a statement on the shooting in Oregon \u2192 https:\/\/t.co\/g3WEdxpHwx #UCCShooting",
  "id" : 649702737169522688,
  "created_at" : "2015-10-01 21:49:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "649646316109328384",
  "text" : "RT @vj44: Today marks the beginning of Breast Cancer Awareness Month-we honor survivors, their families &amp; those we have lost: https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 143 ],
        "url" : "https:\/\/t.co\/hn8YTtsRpc",
        "expanded_url" : "http:\/\/1.usa.gov\/1j33e3R",
        "display_url" : "1.usa.gov\/1j33e3R"
      } ]
    },
    "geo" : { },
    "id_str" : "649645355731021825",
    "text" : "Today marks the beginning of Breast Cancer Awareness Month-we honor survivors, their families &amp; those we have lost: https:\/\/t.co\/hn8YTtsRpc",
    "id" : 649645355731021825,
    "created_at" : "2015-10-01 18:01:37 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 649646316109328384,
  "created_at" : "2015-10-01 18:05:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samantha Power",
      "screen_name" : "AmbassadorPower",
      "indices" : [ 3, 19 ],
      "id_str" : "1615463502",
      "id" : 1615463502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "649639326695981056",
  "text" : "RT @AmbassadorPower: 22 yrs ago, I became a US citizen; humbling to welcome 85 new American citizens today, including a dear friend. http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/AmbassadorPower\/status\/649347683203858433\/photo\/1",
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/DLzyCI2vx0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQLyRYIWsAA0nAT.jpg",
        "id_str" : "649347676643962880",
        "id" : 649347676643962880,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQLyRYIWsAA0nAT.jpg",
        "sizes" : [ {
          "h" : 678,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 398,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 795,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 225,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/DLzyCI2vx0"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/AmbassadorPower\/status\/649347683203858433\/photo\/1",
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/DLzyCI2vx0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQLyRs3WwAEdXW0.jpg",
        "id_str" : "649347682209808385",
        "id" : 649347682209808385,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQLyRs3WwAEdXW0.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 2448,
          "resize" : "fit",
          "w" : 3264
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/DLzyCI2vx0"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/AmbassadorPower\/status\/649347683203858433\/photo\/1",
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/DLzyCI2vx0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQLyRpoWgAABWSn.jpg",
        "id_str" : "649347681341571072",
        "id" : 649347681341571072,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQLyRpoWgAABWSn.jpg",
        "sizes" : [ {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1597,
          "resize" : "fit",
          "w" : 2833
        }, {
          "h" : 192,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 577,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/DLzyCI2vx0"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "649347683203858433",
    "text" : "22 yrs ago, I became a US citizen; humbling to welcome 85 new American citizens today, including a dear friend. http:\/\/t.co\/DLzyCI2vx0",
    "id" : 649347683203858433,
    "created_at" : "2015-09-30 22:18:46 +0000",
    "user" : {
      "name" : "Samantha Power",
      "screen_name" : "AmbassadorPower",
      "protected" : false,
      "id_str" : "1615463502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/620632341497683968\/CkFXABqQ_normal.jpg",
      "id" : 1615463502,
      "verified" : true
    }
  },
  "id" : 649639326695981056,
  "created_at" : "2015-10-01 17:37:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Rock",
      "screen_name" : "chrisrock",
      "indices" : [ 6, 16 ],
      "id_str" : "238319766",
      "id" : 238319766
    }, {
      "name" : "Amandla",
      "screen_name" : "amandlastenberg",
      "indices" : [ 18, 34 ],
      "id_str" : "260674089",
      "id" : 260674089
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FreeCommunityCollege",
      "indices" : [ 70, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/SEGOA4jCOB",
      "expanded_url" : "http:\/\/HeadsUpAmerica.us\/Act",
      "display_url" : "HeadsUpAmerica.us\/Act"
    }, {
      "indices" : [ 117, 140 ],
      "url" : "https:\/\/t.co\/VNOqNAC9bR",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/bba215dd-672b-4d30-95e5-7a61cdd28045",
      "display_url" : "amp.twimg.com\/v\/bba215dd-672\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "649610232503603201",
  "text" : "Watch @ChrisRock, @AmandlaStenberg, and others share why they support #FreeCommunityCollege \u2192 http:\/\/t.co\/SEGOA4jCOB https:\/\/t.co\/VNOqNAC9bR",
  "id" : 649610232503603201,
  "created_at" : "2015-10-01 15:42:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/SEGOA421q1",
      "expanded_url" : "http:\/\/HeadsUpAmerica.us\/Act",
      "display_url" : "HeadsUpAmerica.us\/Act"
    }, {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/VNOqNAkxNh",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/bba215dd-672b-4d30-95e5-7a61cdd28045",
      "display_url" : "amp.twimg.com\/v\/bba215dd-672\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "649599802246758400",
  "text" : "RT if you agree: It's time to make community college free for responsible students \u2192 http:\/\/t.co\/SEGOA421q1\nhttps:\/\/t.co\/VNOqNAkxNh",
  "id" : 649599802246758400,
  "created_at" : "2015-10-01 15:00:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Craig Fugate",
      "screen_name" : "CraigatFEMA",
      "indices" : [ 3, 15 ],
      "id_str" : "67378554",
      "id" : 67378554
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Joaquin",
      "indices" : [ 44, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/CsHbgdV2Fb",
      "expanded_url" : "https:\/\/beta.ready.gov",
      "display_url" : "beta.ready.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "649594498218094593",
  "text" : "RT @CraigatFEMA: Are you Ready if Hurricane #Joaquin comes your way? Are your friends and family? https:\/\/t.co\/CsHbgdV2Fb http:\/\/t.co\/LlxoB\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/CraigatFEMA\/status\/649547975501475840\/photo\/1",
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/LlxoB1sKH0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CQOobzRUwAA8agX.jpg",
        "id_str" : "649547966844289024",
        "id" : 649547966844289024,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CQOobzRUwAA8agX.jpg",
        "sizes" : [ {
          "h" : 479,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 272,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 716,
          "resize" : "fit",
          "w" : 896
        }, {
          "h" : 716,
          "resize" : "fit",
          "w" : 896
        } ],
        "display_url" : "pic.twitter.com\/LlxoB1sKH0"
      } ],
      "hashtags" : [ {
        "text" : "Joaquin",
        "indices" : [ 27, 35 ]
      } ],
      "urls" : [ {
        "indices" : [ 81, 104 ],
        "url" : "https:\/\/t.co\/CsHbgdV2Fb",
        "expanded_url" : "https:\/\/beta.ready.gov",
        "display_url" : "beta.ready.gov"
      } ]
    },
    "geo" : { },
    "id_str" : "649547975501475840",
    "text" : "Are you Ready if Hurricane #Joaquin comes your way? Are your friends and family? https:\/\/t.co\/CsHbgdV2Fb http:\/\/t.co\/LlxoB1sKH0",
    "id" : 649547975501475840,
    "created_at" : "2015-10-01 11:34:40 +0000",
    "user" : {
      "name" : "Craig Fugate",
      "screen_name" : "CraigatFEMA",
      "protected" : false,
      "id_str" : "67378554",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/522052690138763264\/isW58OSG_normal.jpeg",
      "id" : 67378554,
      "verified" : true
    }
  },
  "id" : 649594498218094593,
  "created_at" : "2015-10-01 14:39:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
} ]