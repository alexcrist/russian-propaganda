Grailbird.data.tweets_2015_06 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/616081558940717057\/photo\/1",
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/VwyVaEZx8m",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIzC3EmWsAEbMc2.jpg",
      "id_str" : "616081500426121217",
      "id" : 616081500426121217,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIzC3EmWsAEbMc2.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1867,
        "resize" : "fit",
        "w" : 2800
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/VwyVaEZx8m"
    } ],
    "hashtags" : [ {
      "text" : "FindYourPark",
      "indices" : [ 41, 54 ]
    } ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/MfXGu91k9C",
      "expanded_url" : "http:\/\/FindYourPark.com",
      "display_url" : "FindYourPark.com"
    } ]
  },
  "geo" : { },
  "id_str" : "616081558940717057",
  "text" : "Camp White House. http:\/\/t.co\/MfXGu91k9C #FindYourPark http:\/\/t.co\/VwyVaEZx8m",
  "id" : 616081558940717057,
  "created_at" : "2015-07-01 03:11:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "USWNT",
      "indices" : [ 27, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "616059670394875904",
  "text" : "RT @POTUS: Congrats to the #USWNT! Can't wait for the finals. You make us all proud!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "USWNT",
        "indices" : [ 16, 22 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "616057454430957572",
    "text" : "Congrats to the #USWNT! Can't wait for the finals. You make us all proud!",
    "id" : 616057454430957572,
    "created_at" : "2015-07-01 01:35:17 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 616059670394875904,
  "created_at" : "2015-07-01 01:44:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/616021655509274624\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/1OnUl9bgmx",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CIyMAf0W8AAN8En.png",
      "id_str" : "616021189211910144",
      "id" : 616021189211910144,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CIyMAf0W8AAN8En.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 281,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 281,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 281,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/1OnUl9bgmx"
    } ],
    "hashtags" : [ {
      "text" : "LoveWins",
      "indices" : [ 70, 79 ]
    }, {
      "text" : "ACAIsHereToStay",
      "indices" : [ 80, 96 ]
    }, {
      "text" : "LeadOnTrade",
      "indices" : [ 97, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/YqVKQe7tkn",
      "expanded_url" : "http:\/\/tmblr.co\/ZW21es1oSuRO7",
      "display_url" : "tmblr.co\/ZW21es1oSuRO7"
    } ]
  },
  "geo" : { },
  "id_str" : "616021655509274624",
  "text" : "It's been a pretty good few days for America \u2192 http:\/\/t.co\/YqVKQe7tkn #LoveWins #ACAIsHereToStay #LeadOnTrade http:\/\/t.co\/1OnUl9bgmx",
  "id" : 616021655509274624,
  "created_at" : "2015-06-30 23:13:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "USA",
      "indices" : [ 25, 29 ]
    }, {
      "text" : "OneNationOneTeam",
      "indices" : [ 95, 112 ]
    }, {
      "text" : "USAvGER",
      "indices" : [ 113, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "616020646531743744",
  "text" : "RT @VP: Good luck to the #USA women's soccer team. We're rooting for you all around the world. #OneNationOneTeam #USAvGER http:\/\/t.co\/UwcwD\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/616020291861393409\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/UwcwDVjOla",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CIyLMONUAAAUKAu.jpg",
        "id_str" : "616020291131539456",
        "id" : 616020291131539456,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIyLMONUAAAUKAu.jpg",
        "sizes" : [ {
          "h" : 192,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 339,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 350,
          "resize" : "fit",
          "w" : 620
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 350,
          "resize" : "fit",
          "w" : 620
        } ],
        "display_url" : "pic.twitter.com\/UwcwDVjOla"
      } ],
      "hashtags" : [ {
        "text" : "USA",
        "indices" : [ 17, 21 ]
      }, {
        "text" : "OneNationOneTeam",
        "indices" : [ 87, 104 ]
      }, {
        "text" : "USAvGER",
        "indices" : [ 105, 113 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "616020291861393409",
    "text" : "Good luck to the #USA women's soccer team. We're rooting for you all around the world. #OneNationOneTeam #USAvGER http:\/\/t.co\/UwcwDVjOla",
    "id" : 616020291861393409,
    "created_at" : "2015-06-30 23:07:37 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 616020646531743744,
  "created_at" : "2015-06-30 23:09:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/616006133979832320\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/B30J4J3hL7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIx871EWIAAgRDm.jpg",
      "id_str" : "616004616342347776",
      "id" : 616004616342347776,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIx871EWIAAgRDm.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/B30J4J3hL7"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/G4rEC3yMRw",
      "expanded_url" : "http:\/\/go.wh.gov\/FYw6AV",
      "display_url" : "go.wh.gov\/FYw6AV"
    } ]
  },
  "geo" : { },
  "id_str" : "616006133979832320",
  "text" : "China is out-investing America in its Export-Import Banks.\nIt's time to start changing that \u2192 http:\/\/t.co\/G4rEC3yMRw http:\/\/t.co\/B30J4J3hL7",
  "id" : 616006133979832320,
  "created_at" : "2015-06-30 22:11:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 77, 83 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/VdmHn4VM9Z",
      "expanded_url" : "http:\/\/fw.to\/064rmZm",
      "display_url" : "fw.to\/064rmZm"
    } ]
  },
  "geo" : { },
  "id_str" : "615993180064890881",
  "text" : "\"It's time for Congress to do its job, and keep America's exports growing.\" \u2014@POTUS on the Export-Import Bank: http:\/\/t.co\/VdmHn4VM9Z",
  "id" : 615993180064890881,
  "created_at" : "2015-06-30 21:19:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/615981535494156288\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/35cqNDOz5Y",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIxnw8uWUAICttU.jpg",
      "id_str" : "615981339674824706",
      "id" : 615981339674824706,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIxnw8uWUAICttU.jpg",
      "sizes" : [ {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/35cqNDOz5Y"
    } ],
    "hashtags" : [ {
      "text" : "overtime",
      "indices" : [ 37, 46 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/NsJPqtyNof",
      "expanded_url" : "http:\/\/huff.to\/1HuIOLx",
      "display_url" : "huff.to\/1HuIOLx"
    } ]
  },
  "geo" : { },
  "id_str" : "615981535494156288",
  "text" : "RT if you agree: It's time to extend #overtime protections for millions of Americans \u2192 http:\/\/t.co\/NsJPqtyNof http:\/\/t.co\/35cqNDOz5Y",
  "id" : 615981535494156288,
  "created_at" : "2015-06-30 20:33:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 35, 41 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/615945520746369024\/photo\/1",
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/BTwlKEaGjS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIxG9W1WEAAfeuw.jpg",
      "id_str" : "615945268958203904",
      "id" : 615945268958203904,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIxG9W1WEAAfeuw.jpg",
      "sizes" : [ {
        "h" : 671,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1835,
        "resize" : "fit",
        "w" : 2800
      }, {
        "h" : 393,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 223,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/BTwlKEaGjS"
    } ],
    "hashtags" : [ {
      "text" : "LoveWins",
      "indices" : [ 66, 75 ]
    } ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/iL3S3zDgu5",
      "expanded_url" : "http:\/\/go.wh.gov\/LoveWins",
      "display_url" : "go.wh.gov\/LoveWins"
    } ]
  },
  "geo" : { },
  "id_str" : "615945520746369024",
  "text" : "\"That's a moment worth savoring.\" \u2014@POTUS: http:\/\/t.co\/iL3S3zDgu5 #LoveWins http:\/\/t.co\/BTwlKEaGjS",
  "id" : 615945520746369024,
  "created_at" : "2015-06-30 18:10:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 108, 114 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/tZA4PvPtQZ",
      "expanded_url" : "http:\/\/snpy.tv\/1LAvzJ6",
      "display_url" : "snpy.tv\/1LAvzJ6"
    } ]
  },
  "geo" : { },
  "id_str" : "615932773723799552",
  "text" : "\"To see people gathered in the evening\u2026and to feel that they have the right to love\u2014that was pretty cool.\" \u2014@POTUS http:\/\/t.co\/tZA4PvPtQZ",
  "id" : 615932773723799552,
  "created_at" : "2015-06-30 17:19:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 7, 13 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/XPfTv2Sd9o",
      "expanded_url" : "http:\/\/snpy.tv\/1IqqFgO",
      "display_url" : "snpy.tv\/1IqqFgO"
    } ]
  },
  "geo" : { },
  "id_str" : "615929671830495232",
  "text" : "Watch: @POTUS on the progress he wants to achieve over the rest of his presidency. http:\/\/t.co\/XPfTv2Sd9o",
  "id" : 615929671830495232,
  "created_at" : "2015-06-30 17:07:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 101, 107 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/c0uqdk5Y6M",
      "expanded_url" : "http:\/\/snpy.tv\/1LAtBs4",
      "display_url" : "snpy.tv\/1LAtBs4"
    } ]
  },
  "geo" : { },
  "id_str" : "615928710055628800",
  "text" : "\"My best week, I will tell you, was marrying Michelle.\nMalia and Sasha being born\u2014excellent weeks.\" \u2014@POTUS http:\/\/t.co\/c0uqdk5Y6M",
  "id" : 615928710055628800,
  "created_at" : "2015-06-30 17:03:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 7, 13 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/QEdJt54yJU",
      "expanded_url" : "http:\/\/snpy.tv\/1U4HlyV",
      "display_url" : "snpy.tv\/1U4HlyV"
    } ]
  },
  "geo" : { },
  "id_str" : "615926487984660480",
  "text" : "Watch: @POTUS on the latest in the Iran nuclear talks. http:\/\/t.co\/QEdJt54yJU",
  "id" : 615926487984660480,
  "created_at" : "2015-06-30 16:54:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/615918716316839936\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/oO0hjPILHJ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIwuxvPWgAA8kIl.jpg",
      "id_str" : "615918681072238592",
      "id" : 615918681072238592,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIwuxvPWgAA8kIl.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/oO0hjPILHJ"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 71, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/sDuUOtTvMv",
      "expanded_url" : "http:\/\/wpo.st\/L1sO0",
      "display_url" : "wpo.st\/L1sO0"
    } ]
  },
  "geo" : { },
  "id_str" : "615918716316839936",
  "text" : "RT to share the news: The U.S. and Brazil are taking bold new steps to #ActOnClimate \u2192 http:\/\/t.co\/sDuUOtTvMv http:\/\/t.co\/oO0hjPILHJ",
  "id" : 615918716316839936,
  "created_at" : "2015-06-30 16:23:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 127, 133 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "615917740247810048",
  "text" : "RT @WHLive: \"President Rousseff, thank you for your partnership, your friendship &amp; the progress we\u2019re achieving together\" \u2014@POTUS on the U.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 115, 121 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "615917709860024320",
    "text" : "\"President Rousseff, thank you for your partnership, your friendship &amp; the progress we\u2019re achieving together\" \u2014@POTUS on the U.S. and Brazil",
    "id" : 615917709860024320,
    "created_at" : "2015-06-30 16:19:59 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 615917740247810048,
  "created_at" : "2015-06-30 16:20:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 119, 125 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "615917541429370880",
  "text" : "RT @WHLive: \"I thank our Brazilian friends for previewing elements of their post-2020 targets for reducing emissions\" \u2014@POTUS http:\/\/t.co\/k\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 107, 113 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WHLive\/status\/615917503219265537\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/kZe7EKvTtr",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CIwtsrrXAAAsylR.jpg",
        "id_str" : "615917494704996352",
        "id" : 615917494704996352,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIwtsrrXAAAsylR.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/kZe7EKvTtr"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "615917503219265537",
    "text" : "\"I thank our Brazilian friends for previewing elements of their post-2020 targets for reducing emissions\" \u2014@POTUS http:\/\/t.co\/kZe7EKvTtr",
    "id" : 615917503219265537,
    "created_at" : "2015-06-30 16:19:10 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 615917541429370880,
  "created_at" : "2015-06-30 16:19:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 95, 101 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/615917186931036160\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/NuEUb9tiNP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIwtaH8XAAAbpj_.jpg",
      "id_str" : "615917175874977792",
      "id" : 615917175874977792,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIwtaH8XAAAbpj_.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/NuEUb9tiNP"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 102, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "615917186931036160",
  "text" : "\"These are ambitious goals\u2014a near tripling for the U.S. and more than a doubling for Brazil.\" \u2014@POTUS #ActOnClimate http:\/\/t.co\/NuEUb9tiNP",
  "id" : 615917186931036160,
  "created_at" : "2015-06-30 16:17:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 94, 100 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LeadOnTrade",
      "indices" : [ 124, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "615916467213615105",
  "text" : "RT @WHLive: \"Since I took office, we\u2019ve boosted American exports to Brazil by more than 50%\" \u2014@POTUS on the U.S. and Brazil #LeadOnTrade",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 82, 88 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LeadOnTrade",
        "indices" : [ 112, 124 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "615916431763353600",
    "text" : "\"Since I took office, we\u2019ve boosted American exports to Brazil by more than 50%\" \u2014@POTUS on the U.S. and Brazil #LeadOnTrade",
    "id" : 615916431763353600,
    "created_at" : "2015-06-30 16:14:55 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 615916467213615105,
  "created_at" : "2015-06-30 16:15:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 110, 116 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "615916310787035136",
  "text" : "RT @WHLive: \"We partner on global challenges, from promoting open government to combating human trafficking\" \u2014@POTUS on the U.S. and Brazil",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 98, 104 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "615916282030862336",
    "text" : "\"We partner on global challenges, from promoting open government to combating human trafficking\" \u2014@POTUS on the U.S. and Brazil",
    "id" : 615916282030862336,
    "created_at" : "2015-06-30 16:14:19 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 615916310787035136,
  "created_at" : "2015-06-30 16:14:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 12, 18 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/dXPrr4ahny",
      "expanded_url" : "http:\/\/go.wh.gov\/CqyE4C",
      "display_url" : "go.wh.gov\/CqyE4C"
    } ]
  },
  "geo" : { },
  "id_str" : "615915491794616320",
  "text" : "Watch live: @POTUS holds a press conference with President Rousseff of Brazil \u2192 http:\/\/t.co\/dXPrr4ahny",
  "id" : 615915491794616320,
  "created_at" : "2015-06-30 16:11:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "indices" : [ 3, 11 ],
      "id_str" : "2382117350",
      "id" : 2382117350
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 77, 83 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 30, 43 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/IA3QI9BjaD",
      "expanded_url" : "http:\/\/www.washingtonpost.com\/news\/energy-environment\/wp\/2015\/06\/30\/china-brazil-and-the-u-s-all-announce-new-climate-and-clean-energy-goals\/",
      "display_url" : "washingtonpost.com\/news\/energy-en\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "615912540887891968",
  "text" : "RT @Deese44: Big day for intl #ActOnClimate momentum w\/ new climate goals f\/ @POTUS, Brazil, China, &amp; Korea http:\/\/t.co\/IA3QI9BjaD http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 64, 70 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Deese44\/status\/615912163337617408\/photo\/1",
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/MYXndweuQw",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CIwogtQXAAIcQEv.jpg",
        "id_str" : "615911791412051970",
        "id" : 615911791412051970,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIwogtQXAAIcQEv.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/MYXndweuQw"
      } ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 17, 30 ]
      } ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/IA3QI9BjaD",
        "expanded_url" : "http:\/\/www.washingtonpost.com\/news\/energy-environment\/wp\/2015\/06\/30\/china-brazil-and-the-u-s-all-announce-new-climate-and-clean-energy-goals\/",
        "display_url" : "washingtonpost.com\/news\/energy-en\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "615912163337617408",
    "text" : "Big day for intl #ActOnClimate momentum w\/ new climate goals f\/ @POTUS, Brazil, China, &amp; Korea http:\/\/t.co\/IA3QI9BjaD http:\/\/t.co\/MYXndweuQw",
    "id" : 615912163337617408,
    "created_at" : "2015-06-30 15:57:57 +0000",
    "user" : {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "protected" : false,
      "id_str" : "2382117350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656551411145027584\/ArrSlGUP_normal.jpg",
      "id" : 2382117350,
      "verified" : true
    }
  },
  "id" : 615912540887891968,
  "created_at" : "2015-06-30 15:59:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "overtime",
      "indices" : [ 35, 44 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/NsJPqtyNof",
      "expanded_url" : "http:\/\/huff.to\/1HuIOLx",
      "display_url" : "huff.to\/1HuIOLx"
    } ]
  },
  "geo" : { },
  "id_str" : "615906815964942336",
  "text" : "President Obama's plan will extend #overtime protections to salaried workers making up to about $50,400 next year \u2192 http:\/\/t.co\/NsJPqtyNof",
  "id" : 615906815964942336,
  "created_at" : "2015-06-30 15:36:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "615888078197002240",
  "text" : "RT @POTUS: A hard day's work deserves a fair day's pay. That's why I'm announcing my plan to extend overtime protections. https:\/\/t.co\/MrV5\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 134 ],
        "url" : "https:\/\/t.co\/MrV56vTNa9",
        "expanded_url" : "https:\/\/twitter.com\/huffpostpol\/status\/615858859178110976",
        "display_url" : "twitter.com\/huffpostpol\/st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "615887901654675456",
    "text" : "A hard day's work deserves a fair day's pay. That's why I'm announcing my plan to extend overtime protections. https:\/\/t.co\/MrV56vTNa9",
    "id" : 615887901654675456,
    "created_at" : "2015-06-30 14:21:33 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 615888078197002240,
  "created_at" : "2015-06-30 14:22:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maxine Waters",
      "screen_name" : "MaxineWaters",
      "indices" : [ 3, 16 ],
      "id_str" : "36686040",
      "id" : 36686040
    }, {
      "name" : "House Republicans",
      "screen_name" : "HouseGOP",
      "indices" : [ 69, 78 ],
      "id_str" : "15207668",
      "id" : 15207668
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ExIm4Jobs",
      "indices" : [ 18, 28 ]
    }, {
      "text" : "GOPshutdown",
      "indices" : [ 96, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "615876621493338112",
  "text" : "RT @MaxineWaters: #ExIm4Jobs' charter expires at midnight because of @HouseGOP inaction. Latest #GOPshutdown will cost American jobs &amp; hurt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "House Republicans",
        "screen_name" : "HouseGOP",
        "indices" : [ 51, 60 ],
        "id_str" : "15207668",
        "id" : 15207668
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ExIm4Jobs",
        "indices" : [ 0, 10 ]
      }, {
        "text" : "GOPshutdown",
        "indices" : [ 78, 90 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "615865214827933696",
    "text" : "#ExIm4Jobs' charter expires at midnight because of @HouseGOP inaction. Latest #GOPshutdown will cost American jobs &amp; hurt small businesses.",
    "id" : 615865214827933696,
    "created_at" : "2015-06-30 12:51:24 +0000",
    "user" : {
      "name" : "Maxine Waters",
      "screen_name" : "MaxineWaters",
      "protected" : false,
      "id_str" : "36686040",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000824906688\/2254719201496ac256c01b484a32d48c_normal.jpeg",
      "id" : 36686040,
      "verified" : true
    }
  },
  "id" : 615876621493338112,
  "created_at" : "2015-06-30 13:36:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HuffPost Politics",
      "screen_name" : "HuffPostPol",
      "indices" : [ 3, 15 ],
      "id_str" : "15458694",
      "id" : 15458694
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/HuffPostPol\/status\/615855313103781888\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/AcAvsLdvRS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIv1JMRVEAAOtDM.jpg",
      "id_str" : "615855312327741440",
      "id" : 615855312327741440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIv1JMRVEAAOtDM.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/AcAvsLdvRS"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/OZZQCoP974",
      "expanded_url" : "http:\/\/huff.to\/1IoWUNu",
      "display_url" : "huff.to\/1IoWUNu"
    } ]
  },
  "geo" : { },
  "id_str" : "615873396874674176",
  "text" : "RT @HuffPostPol: Obama to unveil plan to bring overtime pay to 5 million more workers http:\/\/t.co\/OZZQCoP974 http:\/\/t.co\/AcAvsLdvRS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/HuffPostPol\/status\/615855313103781888\/photo\/1",
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/AcAvsLdvRS",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CIv1JMRVEAAOtDM.jpg",
        "id_str" : "615855312327741440",
        "id" : 615855312327741440,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIv1JMRVEAAOtDM.jpg",
        "sizes" : [ {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 2000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/AcAvsLdvRS"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/OZZQCoP974",
        "expanded_url" : "http:\/\/huff.to\/1IoWUNu",
        "display_url" : "huff.to\/1IoWUNu"
      } ]
    },
    "geo" : { },
    "id_str" : "615855313103781888",
    "text" : "Obama to unveil plan to bring overtime pay to 5 million more workers http:\/\/t.co\/OZZQCoP974 http:\/\/t.co\/AcAvsLdvRS",
    "id" : 615855313103781888,
    "created_at" : "2015-06-30 12:12:03 +0000",
    "user" : {
      "name" : "HuffPost Politics",
      "screen_name" : "HuffPostPol",
      "protected" : false,
      "id_str" : "15458694",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/696718733721542656\/2lsNdbhH_normal.png",
      "id" : 15458694,
      "verified" : true
    }
  },
  "id" : 615873396874674176,
  "created_at" : "2015-06-30 13:23:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/615647092300578817\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/e3xxmqMy3X",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIs3no9UMAAZXK0.jpg",
      "id_str" : "615646928215224320",
      "id" : 615646928215224320,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIs3no9UMAAZXK0.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/e3xxmqMy3X"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "615647092300578817",
  "text" : "President Obama's trade deal will:\nProtect our oceans.\nCombat illegal wildlife trafficking.\nCombat illegal logging. http:\/\/t.co\/e3xxmqMy3X",
  "id" : 615647092300578817,
  "created_at" : "2015-06-29 22:24:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/615618558006050816\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/6ASH30MPqS",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIsduL0WsAA9C7k.jpg",
      "id_str" : "615618453349773312",
      "id" : 615618453349773312,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIsduL0WsAA9C7k.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/6ASH30MPqS"
    } ],
    "hashtags" : [ {
      "text" : "LeadOnTrade",
      "indices" : [ 104, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/AONXDwlhrs",
      "expanded_url" : "http:\/\/go.wh.gov\/gMn4fm",
      "display_url" : "go.wh.gov\/gMn4fm"
    } ]
  },
  "geo" : { },
  "id_str" : "615618558006050816",
  "text" : "President Obama's trade deal will lock in the strongest labor protections ever \u2192 http:\/\/t.co\/AONXDwlhrs #LeadOnTrade http:\/\/t.co\/6ASH30MPqS",
  "id" : 615618558006050816,
  "created_at" : "2015-06-29 20:31:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 20, 26 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LeadOnTrade",
      "indices" : [ 97, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/AONXDwlhrs",
      "expanded_url" : "http:\/\/go.wh.gov\/gMn4fm",
      "display_url" : "go.wh.gov\/gMn4fm"
    }, {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/oOXxo2TNyH",
      "expanded_url" : "http:\/\/snpy.tv\/1JtpxdM",
      "display_url" : "snpy.tv\/1JtpxdM"
    } ]
  },
  "geo" : { },
  "id_str" : "615604511659401216",
  "text" : "The two trade bills @POTUS signed today will put American workers first \u2192 http:\/\/t.co\/AONXDwlhrs #LeadOnTrade http:\/\/t.co\/oOXxo2TNyH",
  "id" : 615604511659401216,
  "created_at" : "2015-06-29 19:35:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 108, 114 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/615587860113195008\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/F6nB5RCIyE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIsB3L2WEAAQtEi.jpg",
      "id_str" : "615587821651365888",
      "id" : 615587821651365888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIsB3L2WEAAQtEi.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/F6nB5RCIyE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "615587860113195008",
  "text" : "\"This was a true bipartisan achievement and it\u2019s a reminder of what we can get done\u2026when we work together\" \u2014@POTUS http:\/\/t.co\/F6nB5RCIyE",
  "id" : 615587860113195008,
  "created_at" : "2015-06-29 18:29:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 92, 98 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WHLive\/status\/615584918077349888\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/tdDdVJTWyE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIr_CxzWcAA9apR.jpg",
      "id_str" : "615584722283032576",
      "id" : 615584722283032576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIr_CxzWcAA9apR.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/tdDdVJTWyE"
    } ],
    "hashtags" : [ {
      "text" : "LeadOnTrade",
      "indices" : [ 99, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "615584960989241344",
  "text" : "RT @WHLive: \"The second bill...renews and expands the Trade Adjustment Assistance program\" \u2014@POTUS #LeadOnTrade http:\/\/t.co\/tdDdVJTWyE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 80, 86 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/WHLive\/status\/615584918077349888\/photo\/1",
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/tdDdVJTWyE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CIr_CxzWcAA9apR.jpg",
        "id_str" : "615584722283032576",
        "id" : 615584722283032576,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIr_CxzWcAA9apR.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/tdDdVJTWyE"
      } ],
      "hashtags" : [ {
        "text" : "LeadOnTrade",
        "indices" : [ 87, 99 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "615584918077349888",
    "text" : "\"The second bill...renews and expands the Trade Adjustment Assistance program\" \u2014@POTUS #LeadOnTrade http:\/\/t.co\/tdDdVJTWyE",
    "id" : 615584918077349888,
    "created_at" : "2015-06-29 18:17:36 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 615584960989241344,
  "created_at" : "2015-06-29 18:17:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 108, 114 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/615584609263292417\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/7IwX798iuQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIr-4JrWUAEBbMg.jpg",
      "id_str" : "615584539713359873",
      "id" : 615584539713359873,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIr-4JrWUAEBbMg.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/7IwX798iuQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "615584609263292417",
  "text" : "\"The Trans-Pacific Partnership, for example, includes strong protections for workers and the environment.\" \u2014@POTUS http:\/\/t.co\/7IwX798iuQ",
  "id" : 615584609263292417,
  "created_at" : "2015-06-29 18:16:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 120, 126 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "615584111466577920",
  "text" : "RT @WHLive: \"Businesses have created more than 12 million new jobs in the past 5 years\u2014the longest streak...on record\" \u2014@POTUS http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 108, 114 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WHLive\/status\/615584066776236032\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/1F1t1lynUs",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CIr-b2yWEAAlsh-.jpg",
        "id_str" : "615584053606092800",
        "id" : 615584053606092800,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIr-b2yWEAAlsh-.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 700,
          "resize" : "fit",
          "w" : 1400
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/1F1t1lynUs"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "615584066776236032",
    "text" : "\"Businesses have created more than 12 million new jobs in the past 5 years\u2014the longest streak...on record\" \u2014@POTUS http:\/\/t.co\/1F1t1lynUs",
    "id" : 615584066776236032,
    "created_at" : "2015-06-29 18:14:13 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 615584111466577920,
  "created_at" : "2015-06-29 18:14:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 17, 23 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LeadOnTrade",
      "indices" : [ 125, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/I16pj1VQBC",
      "expanded_url" : "http:\/\/go.wh.gov\/TradeSigning",
      "display_url" : "go.wh.gov\/TradeSigning"
    } ]
  },
  "geo" : { },
  "id_str" : "615580495099887616",
  "text" : "At 2pm ET, watch @POTUS sign two bills to improve our trade policy in a way that puts workers first \u2192 http:\/\/t.co\/I16pj1VQBC #LeadOnTrade",
  "id" : 615580495099887616,
  "created_at" : "2015-06-29 18:00:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LeadOnTrade",
      "indices" : [ 102, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/E3ODrPeuB6",
      "expanded_url" : "https:\/\/twitter.com\/kj_mayorjohnson\/status\/615577351234023424",
      "display_url" : "twitter.com\/kj_mayorjohnso\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "615579680125644801",
  "text" : "RT @vj44: Thank you for telling the stories of how trade would help your cities. So glad you're here! #LeadOnTrade  https:\/\/t.co\/E3ODrPeuB6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LeadOnTrade",
        "indices" : [ 92, 104 ]
      } ],
      "urls" : [ {
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/E3ODrPeuB6",
        "expanded_url" : "https:\/\/twitter.com\/kj_mayorjohnson\/status\/615577351234023424",
        "display_url" : "twitter.com\/kj_mayorjohnso\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "615579607132147712",
    "text" : "Thank you for telling the stories of how trade would help your cities. So glad you're here! #LeadOnTrade  https:\/\/t.co\/E3ODrPeuB6",
    "id" : 615579607132147712,
    "created_at" : "2015-06-29 17:56:29 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 615579680125644801,
  "created_at" : "2015-06-29 17:56:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/615564177957126145\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/iF0uPFFuRg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIrsPQIWoAEPc8i.jpg",
      "id_str" : "615564045861691393",
      "id" : 615564045861691393,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIrsPQIWoAEPc8i.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/iF0uPFFuRg"
    } ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 102, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/UEsjrus0B6",
      "expanded_url" : "http:\/\/go.wh.gov\/8Ey8Yz",
      "display_url" : "go.wh.gov\/8Ey8Yz"
    } ]
  },
  "geo" : { },
  "id_str" : "615564177957126145",
  "text" : "RT to spread the word: America's uninsured rate is the lowest it's ever been \u2192 http:\/\/t.co\/UEsjrus0B6 #ACAWorks http:\/\/t.co\/iF0uPFFuRg",
  "id" : 615564177957126145,
  "created_at" : "2015-06-29 16:55:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/615550606699331584\/photo\/1",
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/VLHINdv9dU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIrfzXRWIAAJhtY.jpg",
      "id_str" : "615550372602585088",
      "id" : 615550372602585088,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIrfzXRWIAAJhtY.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/VLHINdv9dU"
    } ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 30, 39 ]
    } ],
    "urls" : [ {
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/UEsjrus0B6",
      "expanded_url" : "http:\/\/go.wh.gov\/8Ey8Yz",
      "display_url" : "go.wh.gov\/8Ey8Yz"
    } ]
  },
  "geo" : { },
  "id_str" : "615550606699331584",
  "text" : "Amen.\n\nhttp:\/\/t.co\/UEsjrus0B6 #ACAWorks http:\/\/t.co\/VLHINdv9dU",
  "id" : 615550606699331584,
  "created_at" : "2015-06-29 16:01:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 108, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/UEsjrus0B6",
      "expanded_url" : "http:\/\/go.wh.gov\/8Ey8Yz",
      "display_url" : "go.wh.gov\/8Ey8Yz"
    }, {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/Cb5WcgpSjI",
      "expanded_url" : "http:\/\/snpy.tv\/1TPbUZq",
      "display_url" : "snpy.tv\/1TPbUZq"
    } ]
  },
  "geo" : { },
  "id_str" : "615540830019973120",
  "text" : "The Affordable Care Act is here to stay.\nAnd it's benefiting millions of Americans \u2192 http:\/\/t.co\/UEsjrus0B6 #ACAWorks http:\/\/t.co\/Cb5WcgpSjI",
  "id" : 615540830019973120,
  "created_at" : "2015-06-29 15:22:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 95, 101 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 126, 135 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/L69lcOVzx7",
      "expanded_url" : "http:\/\/go.wh.gov\/9WT6nm",
      "display_url" : "go.wh.gov\/9WT6nm"
    } ]
  },
  "geo" : { },
  "id_str" : "615278547221884928",
  "text" : "\"We\u2019re going to keep working to make health care in America even better and more affordable.\" \u2014@POTUS: http:\/\/t.co\/L69lcOVzx7 #ACAWorks",
  "id" : 615278547221884928,
  "created_at" : "2015-06-28 22:00:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 73, 79 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 131, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/L69lcOVzx7",
      "expanded_url" : "http:\/\/go.wh.gov\/9WT6nm",
      "display_url" : "go.wh.gov\/9WT6nm"
    } ]
  },
  "geo" : { },
  "id_str" : "615233271421505536",
  "text" : "\"So far more than 16 million uninsured Americans have gained coverage.\" \u2014@POTUS on the Affordable Care Act: http:\/\/t.co\/L69lcOVzx7 #ACAWorks",
  "id" : 615233271421505536,
  "created_at" : "2015-06-28 19:00:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 58, 64 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 116, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/L69lcODYFz",
      "expanded_url" : "http:\/\/go.wh.gov\/9WT6nm",
      "display_url" : "go.wh.gov\/9WT6nm"
    } ]
  },
  "geo" : { },
  "id_str" : "615185702616190976",
  "text" : "\"You can\u2019t be charged more just because you\u2019re a woman.\" \u2014@POTUS on the Affordable Care Act: http:\/\/t.co\/L69lcODYFz #ACAWorks",
  "id" : 615185702616190976,
  "created_at" : "2015-06-28 15:51:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 109, 115 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/L69lcOVzx7",
      "expanded_url" : "http:\/\/go.wh.gov\/9WT6nm",
      "display_url" : "go.wh.gov\/9WT6nm"
    } ]
  },
  "geo" : { },
  "id_str" : "614885999793942528",
  "text" : "\"If you\u2019re a senior, or an American with a disability, this law gives you discounts on your prescriptions.\" \u2014@POTUS: http:\/\/t.co\/L69lcOVzx7",
  "id" : 614885999793942528,
  "created_at" : "2015-06-27 20:00:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 79, 85 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 110, 119 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/L69lcOVzx7",
      "expanded_url" : "http:\/\/go.wh.gov\/9WT6nm",
      "display_url" : "go.wh.gov\/9WT6nm"
    } ]
  },
  "geo" : { },
  "id_str" : "614834352199872516",
  "text" : "\"If you\u2019re a parent, you can keep your kids on your plan until they turn 26.\" \u2014@POTUS: http:\/\/t.co\/L69lcOVzx7 #ACAWorks",
  "id" : 614834352199872516,
  "created_at" : "2015-06-27 16:35:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 80, 86 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 111, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/L69lcODYFz",
      "expanded_url" : "http:\/\/go.wh.gov\/9WT6nm",
      "display_url" : "go.wh.gov\/9WT6nm"
    } ]
  },
  "geo" : { },
  "id_str" : "614789764588376064",
  "text" : "\"The Affordable Care Act still stands, it is working, and it is here to stay.\" \u2014@POTUS: http:\/\/t.co\/L69lcODYFz #ACAWorks",
  "id" : 614789764588376064,
  "created_at" : "2015-06-27 13:37:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/614611810415681536\/photo\/1",
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/qH1OA1BV2j",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIeIwnnXAAA9IrG.jpg",
      "id_str" : "614610243008528384",
      "id" : 614610243008528384,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIeIwnnXAAA9IrG.jpg",
      "sizes" : [ {
        "h" : 1855,
        "resize" : "fit",
        "w" : 2880
      }, {
        "h" : 219,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 660,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 386,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/qH1OA1BV2j"
    } ],
    "hashtags" : [ {
      "text" : "LoveWins",
      "indices" : [ 30, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614611810415681536",
  "text" : "America should be very proud. #LoveWins http:\/\/t.co\/qH1OA1BV2j",
  "id" : 614611810415681536,
  "created_at" : "2015-06-27 01:50:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LoveWins",
      "indices" : [ 103, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/uarb5ry1xo",
      "expanded_url" : "http:\/\/go.wh.gov\/mcb5Jc",
      "display_url" : "go.wh.gov\/mcb5Jc"
    } ]
  },
  "geo" : { },
  "id_str" : "614574832248848384",
  "text" : "If you liked our avatar, you'll love the view from Pennsylvania Avenue tonight. http:\/\/t.co\/uarb5ry1xo #LoveWins",
  "id" : 614574832248848384,
  "created_at" : "2015-06-26 23:23:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HateWontWin",
      "indices" : [ 109, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614553930475905025",
  "text" : "RT @POTUS: So inspired by the grace shown by the Simmons family and all the victims' families in Charleston. #HateWontWin http:\/\/t.co\/jMS0S\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/POTUS\/status\/614552886731780097\/photo\/1",
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/jMS0SDUYui",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CIdUlXtUkAECHvI.jpg",
        "id_str" : "614552875155361793",
        "id" : 614552875155361793,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIdUlXtUkAECHvI.jpg",
        "sizes" : [ {
          "h" : 404,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 690,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 690,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 229,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/jMS0SDUYui"
      } ],
      "hashtags" : [ {
        "text" : "HateWontWin",
        "indices" : [ 98, 110 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "614552886731780097",
    "text" : "So inspired by the grace shown by the Simmons family and all the victims' families in Charleston. #HateWontWin http:\/\/t.co\/jMS0SDUYui",
    "id" : 614552886731780097,
    "created_at" : "2015-06-26 21:56:40 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 614553930475905025,
  "created_at" : "2015-06-26 22:00:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LoveWins",
      "indices" : [ 99, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/PhMLqNBUSk",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/0e1b484a-6aca-43be-a72e-7d83d2a16c27",
      "display_url" : "amp.twimg.com\/v\/0e1b484a-6ac\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "614539856497131520",
  "text" : "\"As citizens of the state of Ohio and the United States...we wanted to be recognized as a couple.\" #LoveWins\nhttps:\/\/t.co\/PhMLqNBUSk",
  "id" : 614539856497131520,
  "created_at" : "2015-06-26 21:04:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 91, 97 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/qcUl5NnYQs",
      "expanded_url" : "http:\/\/snpy.tv\/1Nk8Sr8",
      "display_url" : "snpy.tv\/1Nk8Sr8"
    } ]
  },
  "geo" : { },
  "id_str" : "614526020331421696",
  "text" : "\"Guard against the subtle impulse to call Johnny back for a job interview, but not Jamal\" \u2014@POTUS in Charleston http:\/\/t.co\/qcUl5NnYQs",
  "id" : 614526020331421696,
  "created_at" : "2015-06-26 20:09:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 71, 77 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/14Z3HnNi8v",
      "expanded_url" : "http:\/\/snpy.tv\/1Gy4vEQ",
      "display_url" : "snpy.tv\/1Gy4vEQ"
    } ]
  },
  "geo" : { },
  "id_str" : "614515464383918082",
  "text" : "\u201CMay God continue to shed His grace on the United States of America.\" \u2014@POTUS http:\/\/t.co\/14Z3HnNi8v",
  "id" : 614515464383918082,
  "created_at" : "2015-06-26 19:27:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 127, 133 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614514427984019456",
  "text" : "\"History must not be a sword to justify injustice...but must be a manual for how to avoid repeating the mistakes of the past\" \u2014@POTUS",
  "id" : 614514427984019456,
  "created_at" : "2015-06-26 19:23:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614513905994473472",
  "text" : "\"It would be a betrayal of everything Reverend Pinckney stood for...if we allowed ourselves to slip into a comfortable silence again\" \u2014Obama",
  "id" : 614513905994473472,
  "created_at" : "2015-06-26 19:21:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 103, 109 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614513447083098112",
  "text" : "\"By making the moral choice to change if it will save even one precious life, we express God\u2019s grace\" \u2014@POTUS on reducing gun violence",
  "id" : 614513447083098112,
  "created_at" : "2015-06-26 19:19:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 96, 102 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614513113480699904",
  "text" : "\"The vast majority of Americans, the majority of gun owners, want to do something about this.\" \u2014@POTUS on reducing gun violence",
  "id" : 614513113480699904,
  "created_at" : "2015-06-26 19:18:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 100, 106 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614512810635194369",
  "text" : "\"For too long, we\u2019ve been blind to the unique mayhem that gun violence inflicts upon this nation.\" \u2014@POTUS",
  "id" : 614512810635194369,
  "created_at" : "2015-06-26 19:17:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 127, 133 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614512676530733056",
  "text" : "\"We guard against not just racial slurs, but also...the subtle impulse to call Johnny back for a job interview but not Jamal\" \u2014@POTUS",
  "id" : 614512676530733056,
  "created_at" : "2015-06-26 19:16:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 53, 59 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614512444363436032",
  "text" : "\"By taking down that flag, we express God\u2019s grace.\" \u2014@POTUS on the confederate flag",
  "id" : 614512444363436032,
  "created_at" : "2015-06-26 19:15:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 106, 112 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614511217684672512",
  "text" : "\"For too long, we were blind to the pain that the Confederate flag stirred in too many of our citizens.\" \u2014@POTUS in Charleston",
  "id" : 614511217684672512,
  "created_at" : "2015-06-26 19:11:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 125, 131 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614510899727085568",
  "text" : "\"As a nation, out of terrible tragedy, God has visited grace upon us. For he has allowed us to see where we\u2019ve been blind.\" \u2014@POTUS",
  "id" : 614510899727085568,
  "created_at" : "2015-06-26 19:09:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 129, 135 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614510715341307905",
  "text" : "\"Amazing grace, how sweet the sound, that saved a wretch like me;\nI once was lost, but now I\u2019m found; was blind but now I see.\" \u2014@POTUS",
  "id" : 614510715341307905,
  "created_at" : "2015-06-26 19:09:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 113, 119 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614510246770409473",
  "text" : "\"Blinded by hatred, he failed to comprehend what Reverend Pinckney so well understood\u2014the power of God\u2019s grace\" \u2014@POTUS in Charleston",
  "id" : 614510246770409473,
  "created_at" : "2015-06-26 19:07:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 122, 128 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614509864291860480",
  "text" : "\"Blinded by hatred, the alleged killer could not see the grace surrounding Reverend Pinckney and that Bible Study group\" \u2014@POTUS",
  "id" : 614509864291860480,
  "created_at" : "2015-06-26 19:05:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 125, 131 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614509148059922433",
  "text" : "RT @WHLive: \"When there were laws banning all-black church gatherings, services happened here, in defiance of unjust laws.\" \u2014@POTUS on Moth\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 113, 119 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "614509105567371264",
    "text" : "\"When there were laws banning all-black church gatherings, services happened here, in defiance of unjust laws.\" \u2014@POTUS on Mother Emanuel",
    "id" : 614509105567371264,
    "created_at" : "2015-06-26 19:02:42 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 614509148059922433,
  "created_at" : "2015-06-26 19:02:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 111, 117 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614508961866346501",
  "text" : "\"That\u2019s what the black church means. Our beating heart\u2014the place where our dignity as a people is inviolate.\" \u2014@POTUS in Charleston",
  "id" : 614508961866346501,
  "created_at" : "2015-06-26 19:02:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 133, 139 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614508505203113984",
  "text" : "\"To the families of these fallen, the nation shares in your grief. Our pain cuts that much deeper because it happened in a church.\" \u2014@POTUS",
  "id" : 614508505203113984,
  "created_at" : "2015-06-26 19:00:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 125, 131 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614507952012136448",
  "text" : "\"To feed the hungry...and house the homeless is not just a call for isolated charity but the imperative of a just society.\" \u2014@POTUS",
  "id" : 614507952012136448,
  "created_at" : "2015-06-26 18:58:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 111, 117 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614507833007185920",
  "text" : "\"To put our faith in action is about more than our individual salvation, it\u2019s about our collective salvation\" \u2014@POTUS",
  "id" : 614507833007185920,
  "created_at" : "2015-06-26 18:57:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 101, 107 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614507415338356736",
  "text" : "\"He was full of empathy\u2026able to walk in someone else\u2019s shoes and see the world through their eyes.\" \u2014@POTUS on Reverend Pinckney",
  "id" : 614507415338356736,
  "created_at" : "2015-06-26 18:55:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 132, 138 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614507265480069120",
  "text" : "\"Reverend Pinckney embodied a politics that was neither mean nor small. He conducted himself quietly, and kindly, and diligently.\" \u2014@POTUS",
  "id" : 614507265480069120,
  "created_at" : "2015-06-26 18:55:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 105, 111 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614505968005697536",
  "text" : "\"We are here today to remember a man of God who lived by faith. A man who believed in things not seen.\" \u2014@POTUS on Reverend Pinckney",
  "id" : 614505968005697536,
  "created_at" : "2015-06-26 18:50:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 80, 86 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614505837927755776",
  "text" : "\"The Bible calls us to hope. To persevere, and have faith in things not seen.\" \u2014@POTUS delivering a eulogy for Reverend Clementa Pinckney",
  "id" : 614505837927755776,
  "created_at" : "2015-06-26 18:49:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 15, 21 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/PB9AffjEvN",
      "expanded_url" : "http:\/\/go.wh.gov\/x7SqJN",
      "display_url" : "go.wh.gov\/x7SqJN"
    } ]
  },
  "geo" : { },
  "id_str" : "614505511304753152",
  "text" : "Happening now: @POTUS delivers a eulogy in honor of Reverend Clementa Pinckney in Charleston, South Carolina \u2192 http:\/\/t.co\/PB9AffjEvN",
  "id" : 614505511304753152,
  "created_at" : "2015-06-26 18:48:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/PB9AffjEvN",
      "expanded_url" : "http:\/\/go.wh.gov\/x7SqJN",
      "display_url" : "go.wh.gov\/x7SqJN"
    } ]
  },
  "geo" : { },
  "id_str" : "614493078179696640",
  "text" : "Starting soon: President Obama will deliver a eulogy in honor of Reverend Clementa Pinckney in Charleston, SC \u2192 http:\/\/t.co\/PB9AffjEvN",
  "id" : 614493078179696640,
  "created_at" : "2015-06-26 17:59:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/614478097468026880\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/0NDeRvIK2y",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIcQT_tXAAAARmd.png",
      "id_str" : "614477809864605696",
      "id" : 614477809864605696,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIcQT_tXAAAARmd.png",
      "sizes" : [ {
        "h" : 277,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 488,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 489,
        "resize" : "fit",
        "w" : 601
      }, {
        "h" : 489,
        "resize" : "fit",
        "w" : 601
      } ],
      "display_url" : "pic.twitter.com\/0NDeRvIK2y"
    } ],
    "hashtags" : [ {
      "text" : "LoveWins",
      "indices" : [ 103, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 102 ],
      "url" : "https:\/\/t.co\/UA3NPwQdxT",
      "expanded_url" : "https:\/\/medium.com\/@WhiteHouse\/my-husband-69362c9d63df",
      "display_url" : "medium.com\/@WhiteHouse\/my\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "614478097468026880",
  "text" : "Read this powerful letter from the plaintiff in today's case, Jim Obergefell \u2192 https:\/\/t.co\/UA3NPwQdxT #LoveWins http:\/\/t.co\/0NDeRvIK2y",
  "id" : 614478097468026880,
  "created_at" : "2015-06-26 16:59:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/614471595999014912\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/Fc8kBaVfvu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIcKgkcW8AAsQM3.jpg",
      "id_str" : "614471428814073856",
      "id" : 614471428814073856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIcKgkcW8AAsQM3.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Fc8kBaVfvu"
    } ],
    "hashtags" : [ {
      "text" : "LoveWins",
      "indices" : [ 106, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/iL3S3zlFCx",
      "expanded_url" : "http:\/\/go.wh.gov\/LoveWins",
      "display_url" : "go.wh.gov\/LoveWins"
    } ]
  },
  "geo" : { },
  "id_str" : "614471595999014912",
  "text" : "Today's decision is a victory for America.\nSee reactions from around the country \u2192 http:\/\/t.co\/iL3S3zlFCx #LoveWins http:\/\/t.co\/Fc8kBaVfvu",
  "id" : 614471595999014912,
  "created_at" : "2015-06-26 16:33:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Collins",
      "screen_name" : "jasoncollins98",
      "indices" : [ 3, 18 ],
      "id_str" : "500436115",
      "id" : 500436115
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614469814388682752",
  "text" : "RT @jasoncollins98: What a day to celebrate! Today also happens to be my parents' 39th wedding anniversary! Congrats to all who celebrate #\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "love",
        "indices" : [ 118, 123 ]
      }, {
        "text" : "LoveWins",
        "indices" : [ 125, 134 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "614443470850277376",
    "text" : "What a day to celebrate! Today also happens to be my parents' 39th wedding anniversary! Congrats to all who celebrate #love. #LoveWins",
    "id" : 614443470850277376,
    "created_at" : "2015-06-26 14:41:53 +0000",
    "user" : {
      "name" : "Jason Collins",
      "screen_name" : "jasoncollins98",
      "protected" : false,
      "id_str" : "500436115",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/619210767976501248\/4qV6JHW2_normal.jpg",
      "id" : 500436115,
      "verified" : true
    }
  },
  "id" : 614469814388682752,
  "created_at" : "2015-06-26 16:26:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/VP\/status\/614466335276408832\/photo\/1",
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/ynEcOmlwcd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIcF3irW8AAGPgU.jpg",
      "id_str" : "614466325918969856",
      "id" : 614466325918969856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIcF3irW8AAGPgU.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ynEcOmlwcd"
    } ],
    "hashtags" : [ {
      "text" : "LoveWins",
      "indices" : [ 91, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614466641380909056",
  "text" : "RT @VP: All people \u2013 no matter who they love \u2013 should be treated with dignity and respect. #LoveWins http:\/\/t.co\/ynEcOmlwcd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/614466335276408832\/photo\/1",
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/ynEcOmlwcd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CIcF3irW8AAGPgU.jpg",
        "id_str" : "614466325918969856",
        "id" : 614466325918969856,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIcF3irW8AAGPgU.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/ynEcOmlwcd"
      } ],
      "hashtags" : [ {
        "text" : "LoveWins",
        "indices" : [ 83, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "614466335276408832",
    "text" : "All people \u2013 no matter who they love \u2013 should be treated with dignity and respect. #LoveWins http:\/\/t.co\/ynEcOmlwcd",
    "id" : 614466335276408832,
    "created_at" : "2015-06-26 16:12:45 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 614466641380909056,
  "created_at" : "2015-06-26 16:13:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Smith",
      "screen_name" : "samsmithworld",
      "indices" : [ 3, 17 ],
      "id_str" : "457554412",
      "id" : 457554412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614464834332139520",
  "text" : "RT @samsmithworld: \uD83D\uDC6C\uD83D\uDC6C\uD83D\uDC6C\uD83D\uDC6C\uD83D\uDC6C\uD83D\uDC6C\uD83D\uDC6C\uD83D\uDC6C\uD83D\uDC6C\uD83D\uDC6C\uD83D\uDC6C\uD83D\uDC6C\uD83D\uDC6C\uD83D\uDC6C\uD83D\uDC6C\uD83D\uDC6C\uD83D\uDC6C\uD83D\uDC6C\uD83D\uDC6C\uD83D\uDC6C\uD83D\uDC6C\uD83D\uDC6C\uD83D\uDC6C\uD83D\uDC6C\uD83D\uDC6C\uD83D\uDC6C\uD83D\uDC6C\uD83D\uDC6C",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "614444879284994048",
    "text" : "\uD83D\uDC6C\uD83D\uDC6C\uD83D\uDC6C\uD83D\uDC6C\uD83D\uDC6C\uD83D\uDC6C\uD83D\uDC6C\uD83D\uDC6C\uD83D\uDC6C\uD83D\uDC6C\uD83D\uDC6C\uD83D\uDC6C\uD83D\uDC6C\uD83D\uDC6C\uD83D\uDC6C\uD83D\uDC6C\uD83D\uDC6C\uD83D\uDC6C\uD83D\uDC6C\uD83D\uDC6C\uD83D\uDC6C\uD83D\uDC6C\uD83D\uDC6C\uD83D\uDC6C\uD83D\uDC6C\uD83D\uDC6C\uD83D\uDC6C\uD83D\uDC6C",
    "id" : 614444879284994048,
    "created_at" : "2015-06-26 14:47:29 +0000",
    "user" : {
      "name" : "Sam Smith",
      "screen_name" : "samsmithworld",
      "protected" : false,
      "id_str" : "457554412",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/774201589259206656\/b0pym8IQ_normal.jpg",
      "id" : 457554412,
      "verified" : true
    }
  },
  "id" : 614464834332139520,
  "created_at" : "2015-06-26 16:06:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ellen DeGeneres",
      "screen_name" : "TheEllenShow",
      "indices" : [ 3, 16 ],
      "id_str" : "15846407",
      "id" : 15846407
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MarriageEquality",
      "indices" : [ 28, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614463723680436225",
  "text" : "RT @TheEllenShow: Love won. #MarriageEquality",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MarriageEquality",
        "indices" : [ 10, 27 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "614441312159338496",
    "text" : "Love won. #MarriageEquality",
    "id" : 614441312159338496,
    "created_at" : "2015-06-26 14:33:19 +0000",
    "user" : {
      "name" : "Ellen DeGeneres",
      "screen_name" : "TheEllenShow",
      "protected" : false,
      "id_str" : "15846407",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/789558314191425539\/X_imv1vL_normal.jpg",
      "id" : 15846407,
      "verified" : true
    }
  },
  "id" : 614463723680436225,
  "created_at" : "2015-06-26 16:02:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Cook",
      "screen_name" : "tim_cook",
      "indices" : [ 3, 12 ],
      "id_str" : "1636590253",
      "id" : 1636590253
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614460939006554112",
  "text" : "RT @tim_cook: Today marks a victory for equality, perseverance and love.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "614449483292618752",
    "text" : "Today marks a victory for equality, perseverance and love.",
    "id" : 614449483292618752,
    "created_at" : "2015-06-26 15:05:47 +0000",
    "user" : {
      "name" : "Tim Cook",
      "screen_name" : "tim_cook",
      "protected" : false,
      "id_str" : "1636590253",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000483764274\/ebce94fb34c055f3dc238627a576d251_normal.jpeg",
      "id" : 1636590253,
      "verified" : true
    }
  },
  "id" : 614460939006554112,
  "created_at" : "2015-06-26 15:51:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LoveWins",
      "indices" : [ 121, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614459528973844480",
  "text" : "RT @FLOTUS: This decision recognizes the fundamental truth that our love is all equal. Today is a great day for America. #LoveWins -mo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LoveWins",
        "indices" : [ 109, 118 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "614459042333896704",
    "text" : "This decision recognizes the fundamental truth that our love is all equal. Today is a great day for America. #LoveWins -mo",
    "id" : 614459042333896704,
    "created_at" : "2015-06-26 15:43:46 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 614459528973844480,
  "created_at" : "2015-06-26 15:45:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LoveWins",
      "indices" : [ 78, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614458549943595008",
  "text" : "RT @vj44: Today, the long arc of the moral universe was bent towards justice. #LoveWins",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LoveWins",
        "indices" : [ 68, 77 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "614457121132777472",
    "text" : "Today, the long arc of the moral universe was bent towards justice. #LoveWins",
    "id" : 614457121132777472,
    "created_at" : "2015-06-26 15:36:08 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 614458549943595008,
  "created_at" : "2015-06-26 15:41:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/614457605101092864\/photo\/1",
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/NKReL0vG8L",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIb9hU4WwAEwEqd.png",
      "id_str" : "614457148165242881",
      "id" : 614457148165242881,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIb9hU4WwAEwEqd.png",
      "sizes" : [ {
        "h" : 609,
        "resize" : "fit",
        "w" : 968
      }, {
        "h" : 214,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 609,
        "resize" : "fit",
        "w" : 968
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 377,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/NKReL0vG8L"
    } ],
    "hashtags" : [ {
      "text" : "LoveWins",
      "indices" : [ 92, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/TNKU8P90vk",
      "expanded_url" : "http:\/\/go.wh.gov\/kYWAKC",
      "display_url" : "go.wh.gov\/kYWAKC"
    } ]
  },
  "geo" : { },
  "id_str" : "614457605101092864",
  "text" : "Add your name to stand with gay and lesbian couples across America \u2192 http:\/\/t.co\/TNKU8P90vk #LoveWins http:\/\/t.co\/NKReL0vG8L",
  "id" : 614457605101092864,
  "created_at" : "2015-06-26 15:38:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 41, 47 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LoveWins",
      "indices" : [ 103, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/rG8PID2QIU",
      "expanded_url" : "http:\/\/snpy.tv\/1GxiF9e",
      "display_url" : "snpy.tv\/1GxiF9e"
    } ]
  },
  "geo" : { },
  "id_str" : "614454804534947840",
  "text" : "\"This ruling is a victory for America.\" \u2014@POTUS on today's Supreme Court decision on marriage equality #LoveWins http:\/\/t.co\/rG8PID2QIU",
  "id" : 614454804534947840,
  "created_at" : "2015-06-26 15:26:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 121, 127 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LoveWins",
      "indices" : [ 128, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614453655794794496",
  "text" : "\"What an extraordinary achievement. What a vindication of the belief that ordinary people can do extraordinary things.\" \u2014@POTUS #LoveWins",
  "id" : 614453655794794496,
  "created_at" : "2015-06-26 15:22:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 94, 100 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LoveWins",
      "indices" : [ 101, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614453483295666176",
  "text" : "\u201CToday, we can say in no uncertain terms that we have made our union a little more perfect.\u201D \u2014@POTUS #LoveWins",
  "id" : 614453483295666176,
  "created_at" : "2015-06-26 15:21:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 117, 123 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LoveWins",
      "indices" : [ 124, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614453170773712896",
  "text" : "\"We are a people who believe that every single child is entitled to life and liberty and the pursuit of happiness.\" \u2014@POTUS #LoveWins",
  "id" : 614453170773712896,
  "created_at" : "2015-06-26 15:20:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614452702739857408",
  "text" : "RT @WHLive: \"Today should also give us hope that on the many issues with which we grapple, often painfully\u2014real change is possible.\" \u2014@POTU\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 122, 128 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LoveWins",
        "indices" : [ 129, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "614452658913591296",
    "text" : "\"Today should also give us hope that on the many issues with which we grapple, often painfully\u2014real change is possible.\" \u2014@POTUS #LoveWins",
    "id" : 614452658913591296,
    "created_at" : "2015-06-26 15:18:24 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 614452702739857408,
  "created_at" : "2015-06-26 15:18:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 66, 72 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/614452547408035840\/photo\/1",
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/4YWuGgk16C",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CIb5Ui_XAAAxrjF.png",
      "id_str" : "614452530567905280",
      "id" : 614452530567905280,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CIb5Ui_XAAAxrjF.png",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/4YWuGgk16C"
    } ],
    "hashtags" : [ {
      "text" : "LoveWins",
      "indices" : [ 73, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614452547408035840",
  "text" : "\"When all Americans are treated as equal, we are all more free.\" \u2014@POTUS #LoveWins http:\/\/t.co\/4YWuGgk16C",
  "id" : 614452547408035840,
  "created_at" : "2015-06-26 15:17:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 41, 47 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/614452348757372928\/photo\/1",
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/MbPKoTK7WK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIb5Ii-WIAAB2Cx.jpg",
      "id_str" : "614452324405223424",
      "id" : 614452324405223424,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIb5Ii-WIAAB2Cx.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1500,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/MbPKoTK7WK"
    } ],
    "hashtags" : [ {
      "text" : "LoveWins",
      "indices" : [ 48, 57 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614452348757372928",
  "text" : "\"This ruling is a victory for America.\" \u2014@POTUS #LoveWins http:\/\/t.co\/MbPKoTK7WK",
  "id" : 614452348757372928,
  "created_at" : "2015-06-26 15:17:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 99, 105 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LoveWins",
      "indices" : [ 106, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614452242192568320",
  "text" : "\"It\u2019s a victory for their children, whose families will now be recognized as equal to any other.\" \u2014@POTUS #LoveWins",
  "id" : 614452242192568320,
  "created_at" : "2015-06-26 15:16:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 112, 118 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LoveWins",
      "indices" : [ 119, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614452166045081600",
  "text" : "\"This ruling is...a victory for gay and lesbian couples who have fought so long for their basic civil rights.\" \u2014@POTUS #LoveWins",
  "id" : 614452166045081600,
  "created_at" : "2015-06-26 15:16:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 86, 92 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LoveWins",
      "indices" : [ 127, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614451958489948160",
  "text" : "\"All people should be treated equally, regardless of who they are or who they love.\" \u2014@POTUS on today's Supreme Court decision #LoveWins",
  "id" : 614451958489948160,
  "created_at" : "2015-06-26 15:15:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 90, 96 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LoveWins",
      "indices" : [ 131, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614451878533971973",
  "text" : "\"They\u2019ve reaffirmed that all Americans are entitled to the equal protection of the law.\" \u2014@POTUS on today's Supreme Court decision #LoveWins",
  "id" : 614451878533971973,
  "created_at" : "2015-06-26 15:15:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 98, 104 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/614451806282846208\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/yzpM9Pnj5r",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CIb4pSnW8AAenNQ.png",
      "id_str" : "614451787437895680",
      "id" : 614451787437895680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CIb4pSnW8AAenNQ.png",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/yzpM9Pnj5r"
    } ],
    "hashtags" : [ {
      "text" : "LoveWins",
      "indices" : [ 105, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614451806282846208",
  "text" : "\"This morning, the Supreme Court recognized that the Constitution guarantees marriage equality.\" \u2014@POTUS #LoveWins http:\/\/t.co\/yzpM9Pnj5r",
  "id" : 614451806282846208,
  "created_at" : "2015-06-26 15:15:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 127, 133 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614451705225289728",
  "text" : "\"Sometimes, there are days like this\u2014when that slow, steady effort is rewarded with justice that arrives like a thunderbolt.\" \u2014@POTUS",
  "id" : 614451705225289728,
  "created_at" : "2015-06-26 15:14:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 104, 110 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LoveWins",
      "indices" : [ 111, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614451599419801601",
  "text" : "\"Progress on this journey often comes in small increments, sometimes two steps forward, one step back\" \u2014@POTUS #LoveWins",
  "id" : 614451599419801601,
  "created_at" : "2015-06-26 15:14:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 81, 87 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LoveWins",
      "indices" : [ 88, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614451421119934464",
  "text" : "\"Our nation was founded on a bedrock principle: That we are all created equal.\" \u2014@POTUS #LoveWins",
  "id" : 614451421119934464,
  "created_at" : "2015-06-26 15:13:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 3, 11 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/DrBiden\/status\/614447988124073984\/photo\/1",
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/OHDhIjWHGu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIb1L4LUYAEsKGR.jpg",
      "id_str" : "614447983589875713",
      "id" : 614447983589875713,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIb1L4LUYAEsKGR.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/OHDhIjWHGu"
    } ],
    "hashtags" : [ {
      "text" : "LoveWins",
      "indices" : [ 53, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614448331264258050",
  "text" : "RT @DrBiden: Love is love in every state in America. #LoveWins http:\/\/t.co\/OHDhIjWHGu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DrBiden\/status\/614447988124073984\/photo\/1",
        "indices" : [ 50, 72 ],
        "url" : "http:\/\/t.co\/OHDhIjWHGu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CIb1L4LUYAEsKGR.jpg",
        "id_str" : "614447983589875713",
        "id" : 614447983589875713,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIb1L4LUYAEsKGR.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/OHDhIjWHGu"
      } ],
      "hashtags" : [ {
        "text" : "LoveWins",
        "indices" : [ 40, 49 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "614447988124073984",
    "text" : "Love is love in every state in America. #LoveWins http:\/\/t.co\/OHDhIjWHGu",
    "id" : 614447988124073984,
    "created_at" : "2015-06-26 14:59:50 +0000",
    "user" : {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "protected" : false,
      "id_str" : "1281405877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608687663034474496\/wvzVG_yt_normal.jpg",
      "id" : 1281405877,
      "verified" : true
    }
  },
  "id" : 614448331264258050,
  "created_at" : "2015-06-26 15:01:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LoveWins",
      "indices" : [ 106, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614445510959714304",
  "text" : "RT @VP: All marriages at their root are about love. In America, our laws now recognize that simple truth. #LoveWins today &amp; we couldn't be \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LoveWins",
        "indices" : [ 98, 107 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "614445393213042689",
    "text" : "All marriages at their root are about love. In America, our laws now recognize that simple truth. #LoveWins today &amp; we couldn't be prouder.",
    "id" : 614445393213042689,
    "created_at" : "2015-06-26 14:49:32 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 614445510959714304,
  "created_at" : "2015-06-26 14:50:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 18, 24 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/614445132377624576\/photo\/1",
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/KlcP75cb40",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CIbye-_XAAAMnoQ.png",
      "id_str" : "614445013301395456",
      "id" : 614445013301395456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CIbye-_XAAAMnoQ.png",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/KlcP75cb40"
    } ],
    "hashtags" : [ {
      "text" : "LoveWins",
      "indices" : [ 68, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/iL3S3zlFCx",
      "expanded_url" : "http:\/\/go.wh.gov\/LoveWins",
      "display_url" : "go.wh.gov\/LoveWins"
    } ]
  },
  "geo" : { },
  "id_str" : "614445132377624576",
  "text" : "At 11am ET, watch @POTUS speak on today's marriage equality ruling. #LoveWins http:\/\/t.co\/iL3S3zlFCx http:\/\/t.co\/KlcP75cb40",
  "id" : 614445132377624576,
  "created_at" : "2015-06-26 14:48:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/614438061817114624\/photo\/1",
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/s5aiwIsFz8",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CIbsJEyWwAACkL5.png",
      "id_str" : "614438039830577152",
      "id" : 614438039830577152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CIbsJEyWwAACkL5.png",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/s5aiwIsFz8"
    } ],
    "hashtags" : [ {
      "text" : "LoveWins",
      "indices" : [ 0, 9 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614438061817114624",
  "text" : "#LoveWins. http:\/\/t.co\/s5aiwIsFz8",
  "id" : 614438061817114624,
  "created_at" : "2015-06-26 14:20:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614435871543177218",
  "text" : "RT @POTUS: Today is a big step in our march toward equality. Gay and lesbian couples now have the right to marry, just like anyone else. #L\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LoveWins",
        "indices" : [ 126, 135 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "614435467120001024",
    "text" : "Today is a big step in our march toward equality. Gay and lesbian couples now have the right to marry, just like anyone else. #LoveWins",
    "id" : 614435467120001024,
    "created_at" : "2015-06-26 14:10:05 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 614435871543177218,
  "created_at" : "2015-06-26 14:11:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BBC News (World)",
      "screen_name" : "BBCWorld",
      "indices" : [ 3, 12 ],
      "id_str" : "742143",
      "id" : 742143
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 47, 53 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/BBCWorld\/status\/614395867370528768\/photo\/1",
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/JtdRt6QhaF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIbFyReVAAEDdHz.jpg",
      "id_str" : "614395866657390593",
      "id" : 614395866657390593,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIbFyReVAAEDdHz.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 475,
        "resize" : "fit",
        "w" : 950
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 475,
        "resize" : "fit",
        "w" : 950
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/JtdRt6QhaF"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/PA7gF0vdFJ",
      "expanded_url" : "http:\/\/bbc.in\/1QSSvIe",
      "display_url" : "bbc.in\/1QSSvIe"
    } ]
  },
  "geo" : { },
  "id_str" : "614420291343765505",
  "text" : "RT @BBCWorld: When Sir David Attenborough told @POTUS how to save the planet http:\/\/t.co\/PA7gF0vdFJ http:\/\/t.co\/JtdRt6QhaF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 33, 39 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BBCWorld\/status\/614395867370528768\/photo\/1",
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/JtdRt6QhaF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CIbFyReVAAEDdHz.jpg",
        "id_str" : "614395866657390593",
        "id" : 614395866657390593,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIbFyReVAAEDdHz.jpg",
        "sizes" : [ {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 475,
          "resize" : "fit",
          "w" : 950
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 475,
          "resize" : "fit",
          "w" : 950
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/JtdRt6QhaF"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 85 ],
        "url" : "http:\/\/t.co\/PA7gF0vdFJ",
        "expanded_url" : "http:\/\/bbc.in\/1QSSvIe",
        "display_url" : "bbc.in\/1QSSvIe"
      } ]
    },
    "geo" : { },
    "id_str" : "614395867370528768",
    "text" : "When Sir David Attenborough told @POTUS how to save the planet http:\/\/t.co\/PA7gF0vdFJ http:\/\/t.co\/JtdRt6QhaF",
    "id" : 614395867370528768,
    "created_at" : "2015-06-26 11:32:44 +0000",
    "user" : {
      "name" : "BBC News (World)",
      "screen_name" : "BBCWorld",
      "protected" : false,
      "id_str" : "742143",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/694449140269518848\/57ZmXva0_normal.jpg",
      "id" : 742143,
      "verified" : true
    }
  },
  "id" : 614420291343765505,
  "created_at" : "2015-06-26 13:09:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 44, 50 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/614227260653064192\/photo\/1",
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/0b7eKTdnSV",
      "media_url" : "http:\/\/pbs.twimg.com\/tweet_video_thumb\/CIYsL1kWsAAGJgc.png",
      "id_str" : "614226981052395520",
      "id" : 614226981052395520,
      "media_url_https" : "https:\/\/pbs.twimg.com\/tweet_video_thumb\/CIYsL1kWsAAGJgc.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 281,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 281,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 281,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/0b7eKTdnSV"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/Wl6BOXLp1t",
      "expanded_url" : "http:\/\/tmblr.co\/ZW21es1o1ree9",
      "display_url" : "tmblr.co\/ZW21es1o1ree9"
    } ]
  },
  "geo" : { },
  "id_str" : "614227260653064192",
  "text" : "\"The Affordable Care Act is here to stay.\" \u2014@POTUS: http:\/\/t.co\/Wl6BOXLp1t http:\/\/t.co\/0b7eKTdnSV",
  "id" : 614227260653064192,
  "created_at" : "2015-06-26 00:22:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/SaiaqQzAqN",
      "expanded_url" : "http:\/\/go.wh.gov\/Attenborough",
      "display_url" : "go.wh.gov\/Attenborough"
    }, {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/e8bNWiIXgQ",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/83ecd3db-8643-43e4-a506-fb7aba3f41aa",
      "display_url" : "amp.twimg.com\/v\/83ecd3db-864\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "614214124562550784",
  "text" : ".@POTUS.\nDavid Attenborough.\nTalking climate change.\nWatch a sneak peek of their interview: http:\/\/t.co\/SaiaqQzAqN\nhttps:\/\/t.co\/e8bNWiIXgQ",
  "id" : 614214124562550784,
  "created_at" : "2015-06-25 23:30:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/614183830040084480\/photo\/1",
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/ND49VipxUn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIX-M1WWgAAJU4l.jpg",
      "id_str" : "614176420638654464",
      "id" : 614176420638654464,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIX-M1WWgAAJU4l.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 2101,
        "resize" : "fit",
        "w" : 2800
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/ND49VipxUn"
    } ],
    "hashtags" : [ {
      "text" : "ACAIsHereToStay",
      "indices" : [ 67, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/n5aFGyNeMo",
      "expanded_url" : "http:\/\/go.wh.gov\/ACADecision",
      "display_url" : "go.wh.gov\/ACADecision"
    } ]
  },
  "geo" : { },
  "id_str" : "614183830040084480",
  "text" : ".@POTUS on today's Supreme Court decision \u2192 http:\/\/t.co\/n5aFGyNeMo #ACAIsHereToStay http:\/\/t.co\/ND49VipxUn",
  "id" : 614183830040084480,
  "created_at" : "2015-06-25 21:30:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/614177662051983360\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/QpFbzWZY9V",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIX_IOfWUAACZxn.jpg",
      "id_str" : "614177440999559168",
      "id" : 614177440999559168,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIX_IOfWUAACZxn.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/QpFbzWZY9V"
    } ],
    "hashtags" : [ {
      "text" : "LeadOnTrade",
      "indices" : [ 99, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614177662051983360",
  "text" : "President Obama on Congress taking a big step toward passing the most progressive trade deal ever. #LeadOnTrade http:\/\/t.co\/QpFbzWZY9V",
  "id" : 614177662051983360,
  "created_at" : "2015-06-25 21:05:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Dingell",
      "screen_name" : "JohnDingell",
      "indices" : [ 3, 15 ],
      "id_str" : "109025212",
      "id" : 109025212
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 115, 121 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tbt",
      "indices" : [ 62, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614168556662575104",
  "text" : "RT @JohnDingell: It's not often you can be proud of posting a #tbt, but today is no ordinary Thursday.\n\nThank you, @POTUS. http:\/\/t.co\/owQg\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 98, 104 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JohnDingell\/status\/614105966150332416\/photo\/1",
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/owQgJS0jYc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CIW-HYIXAAACVk0.jpg",
        "id_str" : "614105958151815168",
        "id" : 614105958151815168,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIW-HYIXAAACVk0.jpg",
        "sizes" : [ {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/owQgJS0jYc"
      } ],
      "hashtags" : [ {
        "text" : "tbt",
        "indices" : [ 45, 49 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "614105966150332416",
    "text" : "It's not often you can be proud of posting a #tbt, but today is no ordinary Thursday.\n\nThank you, @POTUS. http:\/\/t.co\/owQgJS0jYc",
    "id" : 614105966150332416,
    "created_at" : "2015-06-25 16:20:46 +0000",
    "user" : {
      "name" : "John Dingell",
      "screen_name" : "JohnDingell",
      "protected" : false,
      "id_str" : "109025212",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/751796404864122880\/jiPHasvn_normal.jpg",
      "id" : 109025212,
      "verified" : true
    }
  },
  "id" : 614168556662575104,
  "created_at" : "2015-06-25 20:29:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/614154195130781696\/photo\/1",
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/mjEN2Vv8mV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIXp90hVAAA2S0o.jpg",
      "id_str" : "614154172485664768",
      "id" : 614154172485664768,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIXp90hVAAA2S0o.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 604
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1017,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 604
      } ],
      "display_url" : "pic.twitter.com\/mjEN2Vv8mV"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614166424261632000",
  "text" : "RT @vj44: Discrimination of any kind has no place in America. Today\u2019s ruling affirms that: http:\/\/t.co\/mjEN2Vv8mV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/614154195130781696\/photo\/1",
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/mjEN2Vv8mV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CIXp90hVAAA2S0o.jpg",
        "id_str" : "614154172485664768",
        "id" : 614154172485664768,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIXp90hVAAA2S0o.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 604
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1017,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 604
        } ],
        "display_url" : "pic.twitter.com\/mjEN2Vv8mV"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "614154195130781696",
    "text" : "Discrimination of any kind has no place in America. Today\u2019s ruling affirms that: http:\/\/t.co\/mjEN2Vv8mV",
    "id" : 614154195130781696,
    "created_at" : "2015-06-25 19:32:25 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 614166424261632000,
  "created_at" : "2015-06-25 20:21:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/614154593929428992\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/MJY68q3day",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIXnwFrWgAEYJ2R.jpg",
      "id_str" : "614151737549684737",
      "id" : 614151737549684737,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIXnwFrWgAEYJ2R.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1867,
        "resize" : "fit",
        "w" : 2800
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/MJY68q3day"
    } ],
    "hashtags" : [ {
      "text" : "ACAIsHereToStay",
      "indices" : [ 97, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614154593929428992",
  "text" : "More than 16 million covered \u2713\nWomen can't be charged more \u2713\nUninsured rate at an all-time low \u2713\n#ACAIsHereToStay http:\/\/t.co\/MJY68q3day",
  "id" : 614154593929428992,
  "created_at" : "2015-06-25 19:34:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Senator Harry Reid",
      "screen_name" : "SenatorReid",
      "indices" : [ 3, 15 ],
      "id_str" : "16789970",
      "id" : 16789970
    }, {
      "name" : "Nancy Pelosi",
      "screen_name" : "NancyPelosi",
      "indices" : [ 74, 86 ],
      "id_str" : "15764644",
      "id" : 15764644
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614144589897842689",
  "text" : "RT @SenatorReid: ACA would not be the law today if not for my dear friend @NancyPelosi. We worked so hard on that together. http:\/\/t.co\/OIW\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nancy Pelosi",
        "screen_name" : "NancyPelosi",
        "indices" : [ 57, 69 ],
        "id_str" : "15764644",
        "id" : 15764644
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SenatorReid\/status\/614144429851561984\/photo\/1",
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/OIWpQZZpQc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CIXhGF8WsAEy9Ax.jpg",
        "id_str" : "614144418996727809",
        "id" : 614144418996727809,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIXhGF8WsAEy9Ax.jpg",
        "sizes" : [ {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 1440
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/OIWpQZZpQc"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "614144429851561984",
    "text" : "ACA would not be the law today if not for my dear friend @NancyPelosi. We worked so hard on that together. http:\/\/t.co\/OIWpQZZpQc",
    "id" : 614144429851561984,
    "created_at" : "2015-06-25 18:53:36 +0000",
    "user" : {
      "name" : "Senator Harry Reid",
      "screen_name" : "SenatorReid",
      "protected" : false,
      "id_str" : "16789970",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/628307865065816064\/OUQh91yr_normal.jpg",
      "id" : 16789970,
      "verified" : true
    }
  },
  "id" : 614144589897842689,
  "created_at" : "2015-06-25 18:54:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614143739930525696",
  "text" : "RT @VP: Progress is:\n\u2713 137 million Americans have access to preventive care\n\u2713 129 million with preexisting conditions can't be denied care\n\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ACAWorks",
        "indices" : [ 131, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "614134462968918016",
    "text" : "Progress is:\n\u2713 137 million Americans have access to preventive care\n\u2713 129 million with preexisting conditions can't be denied care\n#ACAWorks",
    "id" : 614134462968918016,
    "created_at" : "2015-06-25 18:14:00 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 614143739930525696,
  "created_at" : "2015-06-25 18:50:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 66, 72 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/614140375071109121\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/ViTDcexkJI",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIXdUl7XAAArTBN.jpg",
      "id_str" : "614140270054146048",
      "id" : 614140270054146048,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIXdUl7XAAArTBN.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ViTDcexkJI"
    } ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 97, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/n5aFGyvDUQ",
      "expanded_url" : "http:\/\/go.wh.gov\/ACADecision",
      "display_url" : "go.wh.gov\/ACADecision"
    } ]
  },
  "geo" : { },
  "id_str" : "614140375071109121",
  "text" : "\"If you\u2019re a woman, you can\u2019t be charged more than anybody else\" \u2014@POTUS: http:\/\/t.co\/n5aFGyvDUQ #ACAWorks http:\/\/t.co\/ViTDcexkJI",
  "id" : 614140375071109121,
  "created_at" : "2015-06-25 18:37:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/PressSec\/status\/614126510744559616\/photo\/1",
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/WPuh8y8cZC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIXQzoxUwAA6cv5.jpg",
      "id_str" : "614126509742145536",
      "id" : 614126509742145536,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIXQzoxUwAA6cv5.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 465,
        "resize" : "fit",
        "w" : 1247
      }, {
        "h" : 382,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 224,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 127,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/WPuh8y8cZC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614127090779189248",
  "text" : "RT @PressSec: More than one important decision from the Supreme Court today that's worth noting \u2192 http:\/\/t.co\/WPuh8y8cZC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/PressSec\/status\/614126510744559616\/photo\/1",
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/WPuh8y8cZC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CIXQzoxUwAA6cv5.jpg",
        "id_str" : "614126509742145536",
        "id" : 614126509742145536,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIXQzoxUwAA6cv5.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 465,
          "resize" : "fit",
          "w" : 1247
        }, {
          "h" : 382,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 224,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 127,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/WPuh8y8cZC"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "614126510744559616",
    "text" : "More than one important decision from the Supreme Court today that's worth noting \u2192 http:\/\/t.co\/WPuh8y8cZC",
    "id" : 614126510744559616,
    "created_at" : "2015-06-25 17:42:24 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 614127090779189248,
  "created_at" : "2015-06-25 17:44:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/614124198181646336\/photo\/1",
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/aEzPDhng94",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIXONWhWIAAlzdk.jpg",
      "id_str" : "614123652985004032",
      "id" : 614123652985004032,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIXONWhWIAAlzdk.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1867,
        "resize" : "fit",
        "w" : 2800
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/aEzPDhng94"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/614124198181646336\/photo\/1",
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/aEzPDhng94",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIXONvCWIAAT_Mc.jpg",
      "id_str" : "614123659565867008",
      "id" : 614123659565867008,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIXONvCWIAAT_Mc.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1867,
        "resize" : "fit",
        "w" : 2800
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/aEzPDhng94"
    } ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/n5aFGyvDUQ",
      "expanded_url" : "http:\/\/go.wh.gov\/ACADecision",
      "display_url" : "go.wh.gov\/ACADecision"
    } ]
  },
  "geo" : { },
  "id_str" : "614124198181646336",
  "text" : "It's a good day for America. http:\/\/t.co\/n5aFGyvDUQ #ACAWorks http:\/\/t.co\/aEzPDhng94",
  "id" : 614124198181646336,
  "created_at" : "2015-06-25 17:33:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614120931112415232",
  "text" : "RT @POTUS: The uninsured rate is the lowest it's ever been. Let's keep at it until every American has quality, affordable health insurance.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "614114880786956288",
    "geo" : { },
    "id_str" : "614119220440367105",
    "in_reply_to_user_id" : 1536791610,
    "text" : "The uninsured rate is the lowest it's ever been. Let's keep at it until every American has quality, affordable health insurance.",
    "id" : 614119220440367105,
    "in_reply_to_status_id" : 614114880786956288,
    "created_at" : "2015-06-25 17:13:26 +0000",
    "in_reply_to_screen_name" : "POTUS",
    "in_reply_to_user_id_str" : "1536791610",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 614120931112415232,
  "created_at" : "2015-06-25 17:20:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614115471420473344",
  "text" : "RT @POTUS: More than 137 million Americans have guaranteed access to preventive care like cancer screenings and birth control at no out-of-\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "614111236620427265",
    "geo" : { },
    "id_str" : "614114880786956288",
    "in_reply_to_user_id" : 1536791610,
    "text" : "More than 137 million Americans have guaranteed access to preventive care like cancer screenings and birth control at no out-of-pocket cost.",
    "id" : 614114880786956288,
    "in_reply_to_status_id" : 614111236620427265,
    "created_at" : "2015-06-25 16:56:11 +0000",
    "in_reply_to_screen_name" : "POTUS",
    "in_reply_to_user_id_str" : "1536791610",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 614115471420473344,
  "created_at" : "2015-06-25 16:58:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614112513689579520",
  "text" : "RT @POTUS: Women can no longer be charged more for health coverage just for being women.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "614108370832891904",
    "geo" : { },
    "id_str" : "614111236620427265",
    "in_reply_to_user_id" : 1536791610,
    "text" : "Women can no longer be charged more for health coverage just for being women.",
    "id" : 614111236620427265,
    "in_reply_to_status_id" : 614108370832891904,
    "created_at" : "2015-06-25 16:41:43 +0000",
    "in_reply_to_screen_name" : "POTUS",
    "in_reply_to_user_id_str" : "1536791610",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 614112513689579520,
  "created_at" : "2015-06-25 16:46:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614108860857630721",
  "text" : "RT @POTUS: 129 million Americans with pre-existing conditions can no longer be denied health coverage.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "614104506410901504",
    "geo" : { },
    "id_str" : "614108370832891904",
    "in_reply_to_user_id" : 1536791610,
    "text" : "129 million Americans with pre-existing conditions can no longer be denied health coverage.",
    "id" : 614108370832891904,
    "in_reply_to_status_id" : 614104506410901504,
    "created_at" : "2015-06-25 16:30:19 +0000",
    "in_reply_to_screen_name" : "POTUS",
    "in_reply_to_user_id_str" : "1536791610",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 614108860857630721,
  "created_at" : "2015-06-25 16:32:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACA",
      "indices" : [ 125, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614106162057879552",
  "text" : "RT @VP: Saving lives. Expanding access. Providing peace of mind. Health care in America is a right, not a privilege. And the #ACA is here t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ACA",
        "indices" : [ 117, 121 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "614105235510853632",
    "text" : "Saving lives. Expanding access. Providing peace of mind. Health care in America is a right, not a privilege. And the #ACA is here to stay.",
    "id" : 614105235510853632,
    "created_at" : "2015-06-25 16:17:52 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 614106162057879552,
  "created_at" : "2015-06-25 16:21:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614104956635860992",
  "text" : "RT @POTUS: More than 16 million Americans have gained health coverage after 5 years of the Affordable Care Act.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "614101662349848576",
    "geo" : { },
    "id_str" : "614104506410901504",
    "in_reply_to_user_id" : 1536791610,
    "text" : "More than 16 million Americans have gained health coverage after 5 years of the Affordable Care Act.",
    "id" : 614104506410901504,
    "in_reply_to_status_id" : 614101662349848576,
    "created_at" : "2015-06-25 16:14:58 +0000",
    "in_reply_to_screen_name" : "POTUS",
    "in_reply_to_user_id_str" : "1536791610",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 614104956635860992,
  "created_at" : "2015-06-25 16:16:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614102545695383553",
  "text" : "RT @POTUS: Today's decision is a victory for every hardworking American. Access to quality, affordable health care is a right, not a privil\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "614101662349848576",
    "text" : "Today's decision is a victory for every hardworking American. Access to quality, affordable health care is a right, not a privilege.",
    "id" : 614101662349848576,
    "created_at" : "2015-06-25 16:03:40 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 614102545695383553,
  "created_at" : "2015-06-25 16:07:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 36, 42 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/PHjhhCe06p",
      "expanded_url" : "http:\/\/snpy.tv\/1TP1eKs",
      "display_url" : "snpy.tv\/1TP1eKs"
    } ]
  },
  "geo" : { },
  "id_str" : "614098757743968256",
  "text" : "\"This was a good day for America.\" \u2014@POTUS on the Supreme Court upholding a critical part of the Affordable Care Act http:\/\/t.co\/PHjhhCe06p",
  "id" : 614098757743968256,
  "created_at" : "2015-06-25 15:52:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 97, 103 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 131, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614097341298143233",
  "text" : "\"That\u2019s when America soars. When we look out for one another. When we take care of each other.\" \u2014@POTUS on the Affordable Care Act #ACAWorks",
  "id" : 614097341298143233,
  "created_at" : "2015-06-25 15:46:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 126, 132 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614096853844496384",
  "text" : "\"Two generations ago, we chose to end an age when Americans in their golden years didn\u2019t have the guarantee of health care.\" \u2014@POTUS",
  "id" : 614096853844496384,
  "created_at" : "2015-06-25 15:44:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614095838067953664",
  "text" : "RT @WHLive: \"For all the misinformation campaigns, all the doomsday predictions...this law is now helping tens of millions of Americans\" \u2014@\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 126, 132 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "614095812545671172",
    "text" : "\"For all the misinformation campaigns, all the doomsday predictions...this law is now helping tens of millions of Americans\" \u2014@POTUS",
    "id" : 614095812545671172,
    "created_at" : "2015-06-25 15:40:25 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 614095838067953664,
  "created_at" : "2015-06-25 15:40:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 120, 126 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 127, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614095461671174144",
  "text" : "\"Nearly 1 in 3 Americans who was uninsured a few years ago is insured today. That\u2019s something we can all be proud of.\" \u2014@POTUS #ACAWorks",
  "id" : 614095461671174144,
  "created_at" : "2015-06-25 15:39:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 73, 79 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/614095383459987456\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/BOp5bL5Ox5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIW0d1rW8AAI2oS.jpg",
      "id_str" : "614095348924084224",
      "id" : 614095348924084224,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIW0d1rW8AAI2oS.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/BOp5bL5Ox5"
    } ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 107, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614095383459987456",
  "text" : "\"More than 16 million uninsured Americans have gained coverage so far.\" \u2014@POTUS on the Affordable Care Act #ACAWorks http:\/\/t.co\/BOp5bL5Ox5",
  "id" : 614095383459987456,
  "created_at" : "2015-06-25 15:38:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 121, 127 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 128, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614095261388931072",
  "text" : "\"Someday, our grandkids will ask us if there was really a time when America discriminated against people who get sick.\" \u2014@POTUS #ACAWorks",
  "id" : 614095261388931072,
  "created_at" : "2015-06-25 15:38:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 97, 103 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 131, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614095121211068416",
  "text" : "\"If you\u2019re a woman, you can\u2019t be charged more than anybody else...just because you\u2019re a woman.\" \u2014@POTUS on the Affordable Care Act #ACAWorks",
  "id" : 614095121211068416,
  "created_at" : "2015-06-25 15:37:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614094979254890496",
  "text" : "RT @WHLive: \"If you\u2019re a parent, you can keep your kids on your plan until they turn 26\u2014something that has covered millions of young people\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 130, 136 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "614094944974839809",
    "text" : "\"If you\u2019re a parent, you can keep your kids on your plan until they turn 26\u2014something that has covered millions of young people\" \u2014@POTUS",
    "id" : 614094944974839809,
    "created_at" : "2015-06-25 15:36:58 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 614094979254890496,
  "created_at" : "2015-06-25 15:37:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 121, 127 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 128, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614094887647117314",
  "text" : "\"Today is a victory for hardworking Americans...whose lives will continue to become more secure...because of this law.\" \u2014@POTUS #ACAWorks",
  "id" : 614094887647117314,
  "created_at" : "2015-06-25 15:36:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 120, 126 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614094730742341632",
  "text" : "\"The Court upheld a critical part of this law\u2014the part that's made it easier for Americans to afford health insurance\" \u2014@POTUS on the ACA",
  "id" : 614094730742341632,
  "created_at" : "2015-06-25 15:36:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 102, 108 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 109, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614094622827089920",
  "text" : "\"There can be no doubt this law is working. It has changed, and in some cases saved American lives.\" \u2014@POTUS #ACAWorks",
  "id" : 614094622827089920,
  "created_at" : "2015-06-25 15:35:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 120, 126 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 127, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "614094474042580992",
  "text" : "\"Five years ago...we finally declared that in America, health care is not a privilege for a few, but a right for all.\" \u2014@POTUS #ACAWorks",
  "id" : 614094474042580992,
  "created_at" : "2015-06-25 15:35:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 12, 18 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 101, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/tgPfSRXAn9",
      "expanded_url" : "http:\/\/go.wh.gov\/SDF8JB",
      "display_url" : "go.wh.gov\/SDF8JB"
    } ]
  },
  "geo" : { },
  "id_str" : "614094415985045504",
  "text" : "Watch live: @POTUS speaks on the Supreme Court\u2019s Affordable Care Act ruling \u2192 http:\/\/t.co\/tgPfSRXAn9 #ACAWorks",
  "id" : 614094415985045504,
  "created_at" : "2015-06-25 15:34:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 25, 31 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/tgPfSRXAn9",
      "expanded_url" : "http:\/\/go.wh.gov\/SDF8JB",
      "display_url" : "go.wh.gov\/SDF8JB"
    } ]
  },
  "geo" : { },
  "id_str" : "614081843076460544",
  "text" : "Tune in at 11:30am ET as @POTUS delivers a statement on today's Affordable Care Act ruling from the Supreme Court \u2192 http:\/\/t.co\/tgPfSRXAn9",
  "id" : 614081843076460544,
  "created_at" : "2015-06-25 14:44:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/dbgbKvoxmS",
      "expanded_url" : "http:\/\/snpy.tv\/1LCNA7B",
      "display_url" : "snpy.tv\/1LCNA7B"
    } ]
  },
  "geo" : { },
  "id_str" : "613873845070626816",
  "text" : "RT if you agree: Every kid\u2014no matter who they are or what gender they identify as\u2014deserves to be valued and loved. http:\/\/t.co\/dbgbKvoxmS",
  "id" : 613873845070626816,
  "created_at" : "2015-06-25 00:58:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 5, 11 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/613862620345413632\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/FM4G4sslIQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CITgi3pWgAAR5zR.jpg",
      "id_str" : "613862338886795264",
      "id" : 613862338886795264,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CITgi3pWgAAR5zR.jpg",
      "sizes" : [ {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1536,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 2800,
        "resize" : "fit",
        "w" : 1867
      } ],
      "display_url" : "pic.twitter.com\/FM4G4sslIQ"
    } ],
    "hashtags" : [ {
      "text" : "PrideMonth",
      "indices" : [ 106, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "613862620345413632",
  "text" : "When @POTUS took office, gay marriage was legal in just 2 states.\nToday, it's legal in 37 states and D.C. #PrideMonth http:\/\/t.co\/FM4G4sslIQ",
  "id" : 613862620345413632,
  "created_at" : "2015-06-25 00:13:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 122, 128 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PrideMonth",
      "indices" : [ 129, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "613821529420226560",
  "text" : "\"As long as a single child in America is afraid they won\u2019t be accepted for who they are, there\u2019s still more work to do.\" \u2014@POTUS #PrideMonth",
  "id" : 613821529420226560,
  "created_at" : "2015-06-24 21:30:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 132, 138 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "613820417774465025",
  "text" : "\"Every young person\u2014no matter who they are or what they look like or what gender they identify as\u2014deserves to be valued and loved\" \u2014@POTUS",
  "id" : 613820417774465025,
  "created_at" : "2015-06-24 21:26:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 90, 96 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PrideMonth",
      "indices" : [ 97, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "613820060751138816",
  "text" : "\"A decade ago, politicians ran against LGBT rights.\nToday, they\u2019re running toward them.\" \u2014@POTUS #PrideMonth",
  "id" : 613820060751138816,
  "created_at" : "2015-06-24 21:24:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 137, 143 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "613819824561479680",
  "text" : "\"When I became President, same-sex marriage was legal in only 2 states.\nToday, it\u2019s legal in 37 states &amp; the District of Columbia.\" \u2014@POTUS",
  "id" : 613819824561479680,
  "created_at" : "2015-06-24 21:23:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 87, 93 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PrideMonth",
      "indices" : [ 94, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "613819506385793024",
  "text" : "RT @WHLive: \"We strengthened the Violence Against Women Act to protect LGBT victims.\" \u2014@POTUS #PrideMonth",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 75, 81 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PrideMonth",
        "indices" : [ 82, 93 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "613819456351961088",
    "text" : "\"We strengthened the Violence Against Women Act to protect LGBT victims.\" \u2014@POTUS #PrideMonth",
    "id" : 613819456351961088,
    "created_at" : "2015-06-24 21:22:17 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 613819506385793024,
  "created_at" : "2015-06-24 21:22:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 91, 97 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PrideMonth",
      "indices" : [ 98, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "613819401935130624",
  "text" : "RT @WHLive: \"We passed a historic hate crimes bill named in part after Matthew Shephard.\" \u2014@POTUS #PrideMonth",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 79, 85 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PrideMonth",
        "indices" : [ 86, 97 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "613819372210098177",
    "text" : "\"We passed a historic hate crimes bill named in part after Matthew Shephard.\" \u2014@POTUS #PrideMonth",
    "id" : 613819372210098177,
    "created_at" : "2015-06-24 21:21:57 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 613819401935130624,
  "created_at" : "2015-06-24 21:22:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 47, 53 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PrideMonth",
      "indices" : [ 54, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "613819279750729728",
  "text" : "\"Together, we ended 'Don\u2019t Ask, Don\u2019t Tell.'\u201D \u2014@POTUS #PrideMonth",
  "id" : 613819279750729728,
  "created_at" : "2015-06-24 21:21:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 106, 112 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PrideMonth",
      "indices" : [ 113, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "613819157931405312",
  "text" : "\"The civil rights of LGBT Americans\u2014this is an issue whose time has come. We've got a lot to celebrate.\" \u2014@POTUS #PrideMonth",
  "id" : 613819157931405312,
  "created_at" : "2015-06-24 21:21:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PrideMonth",
      "indices" : [ 43, 54 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/xf8EPlqItS",
      "expanded_url" : "http:\/\/go.wh.gov\/PrideMonth",
      "display_url" : "go.wh.gov\/PrideMonth"
    } ]
  },
  "geo" : { },
  "id_str" : "613818023045017601",
  "text" : "Watch live: President Obama speaks on LGBT #PrideMonth \u2192 http:\/\/t.co\/xf8EPlqItS",
  "id" : 613818023045017601,
  "created_at" : "2015-06-24 21:16:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Gov. Robert Bentley",
      "screen_name" : "GovernorBentley",
      "indices" : [ 50, 66 ],
      "id_str" : "39525554",
      "id" : 39525554
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "takeitdown",
      "indices" : [ 69, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "613815459054493696",
  "text" : "RT @vj44: We all have lots of work left to do but @GovernorBentley's #takeitdown announcement in Alabama is great news. Continue to speak u\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gov. Robert Bentley",
        "screen_name" : "GovernorBentley",
        "indices" : [ 40, 56 ],
        "id_str" : "39525554",
        "id" : 39525554
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "takeitdown",
        "indices" : [ 59, 70 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "613796835040235520",
    "text" : "We all have lots of work left to do but @GovernorBentley's #takeitdown announcement in Alabama is great news. Continue to speak up, America!",
    "id" : 613796835040235520,
    "created_at" : "2015-06-24 19:52:23 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 613815459054493696,
  "created_at" : "2015-06-24 21:06:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/613803713199767552\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/KTT8LoqmVv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CISrMHtWwAALTRT.jpg",
      "id_str" : "613803673945292800",
      "id" : 613803673945292800,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CISrMHtWwAALTRT.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/KTT8LoqmVv"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/EbJTwaNs1G",
      "expanded_url" : "http:\/\/go.wh.gov\/TAA",
      "display_url" : "go.wh.gov\/TAA"
    } ]
  },
  "geo" : { },
  "id_str" : "613803713199767552",
  "text" : "TAA is about helping hardworking Americans get ahead.\nIt's time for Congress to pass it \u2192 http:\/\/t.co\/EbJTwaNs1G http:\/\/t.co\/KTT8LoqmVv",
  "id" : 613803713199767552,
  "created_at" : "2015-06-24 20:19:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/613788693422174209\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/WD7PhZlOa4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CISas4AWsAAmEWG.jpg",
      "id_str" : "613785544968024064",
      "id" : 613785544968024064,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CISas4AWsAAmEWG.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/WD7PhZlOa4"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/Dm1DbKUsac",
      "expanded_url" : "http:\/\/go.wh.gov\/AGOA",
      "display_url" : "go.wh.gov\/AGOA"
    } ]
  },
  "geo" : { },
  "id_str" : "613788693422174209",
  "text" : "AGOA has supported hundreds of thousands of jobs in Africa and America.\nIt's time to pass it: http:\/\/t.co\/Dm1DbKUsac http:\/\/t.co\/WD7PhZlOa4",
  "id" : 613788693422174209,
  "created_at" : "2015-06-24 19:20:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/613781769293180929\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/bvinPOEvjc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CISW-SZWcAIGI6W.jpg",
      "id_str" : "613781446063452162",
      "id" : 613781446063452162,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CISW-SZWcAIGI6W.jpg",
      "sizes" : [ {
        "h" : 742,
        "resize" : "fit",
        "w" : 842
      }, {
        "h" : 742,
        "resize" : "fit",
        "w" : 842
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 529,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/bvinPOEvjc"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/EbJTwb52Te",
      "expanded_url" : "http:\/\/go.wh.gov\/TAA",
      "display_url" : "go.wh.gov\/TAA"
    } ]
  },
  "geo" : { },
  "id_str" : "613781769293180929",
  "text" : "Trade Adjustment Assistance benefits workers in every state.\nIt's time to reauthorize it \u2192 http:\/\/t.co\/EbJTwb52Te http:\/\/t.co\/bvinPOEvjc",
  "id" : 613781769293180929,
  "created_at" : "2015-06-24 18:52:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IKEA USA News",
      "screen_name" : "IKEAUSANews",
      "indices" : [ 3, 15 ],
      "id_str" : "2294627450",
      "id" : 2294627450
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/E2eIxw7hDk",
      "expanded_url" : "http:\/\/bit.ly\/1J4J8hq",
      "display_url" : "bit.ly\/1J4J8hq"
    } ]
  },
  "geo" : { },
  "id_str" : "613777105566986240",
  "text" : "RT @IKEAUSANews: Raising wages \u2013 it\u2019s a great thing to do for our co-workers &amp; our business! Find out why: http:\/\/t.co\/E2eIxw7hDk http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/IKEAUSANews\/status\/613746973150199808\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/Vbxdn1L0j3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CIR3nirXAAE-JcQ.jpg",
        "id_str" : "613746970436501505",
        "id" : 613746970436501505,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIR3nirXAAE-JcQ.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 327,
          "resize" : "fit",
          "w" : 490
        }, {
          "h" : 327,
          "resize" : "fit",
          "w" : 490
        }, {
          "h" : 327,
          "resize" : "fit",
          "w" : 490
        } ],
        "display_url" : "pic.twitter.com\/Vbxdn1L0j3"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/E2eIxw7hDk",
        "expanded_url" : "http:\/\/bit.ly\/1J4J8hq",
        "display_url" : "bit.ly\/1J4J8hq"
      } ]
    },
    "geo" : { },
    "id_str" : "613746973150199808",
    "text" : "Raising wages \u2013 it\u2019s a great thing to do for our co-workers &amp; our business! Find out why: http:\/\/t.co\/E2eIxw7hDk http:\/\/t.co\/Vbxdn1L0j3",
    "id" : 613746973150199808,
    "created_at" : "2015-06-24 16:34:15 +0000",
    "user" : {
      "name" : "IKEA USA News",
      "screen_name" : "IKEAUSANews",
      "protected" : false,
      "id_str" : "2294627450",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/423844902531641344\/6nRXFXRF_normal.png",
      "id" : 2294627450,
      "verified" : true
    }
  },
  "id" : 613777105566986240,
  "created_at" : "2015-06-24 18:34:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "IKEA USA",
      "screen_name" : "IKEAUSA",
      "indices" : [ 33, 41 ],
      "id_str" : "303827856",
      "id" : 303827856
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 97, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/doRSNKSWfl",
      "expanded_url" : "http:\/\/huff.to\/1LmPZ8u",
      "display_url" : "huff.to\/1LmPZ8u"
    } ]
  },
  "geo" : { },
  "id_str" : "613763038852837376",
  "text" : "RT @vj44: Huge announcement from @IKEAUSA that it will boost pay for employees (again). Who will #RaiseTheWage next? http:\/\/t.co\/doRSNKSWfl\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "IKEA USA",
        "screen_name" : "IKEAUSA",
        "indices" : [ 23, 31 ],
        "id_str" : "303827856",
        "id" : 303827856
      }, {
        "name" : "Dave Jamieson",
        "screen_name" : "jamieson",
        "indices" : [ 130, 139 ],
        "id_str" : "166219963",
        "id" : 166219963
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RaiseTheWage",
        "indices" : [ 87, 100 ]
      } ],
      "urls" : [ {
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/doRSNKSWfl",
        "expanded_url" : "http:\/\/huff.to\/1LmPZ8u",
        "display_url" : "huff.to\/1LmPZ8u"
      } ]
    },
    "geo" : { },
    "id_str" : "613760329508593664",
    "text" : "Huge announcement from @IKEAUSA that it will boost pay for employees (again). Who will #RaiseTheWage next? http:\/\/t.co\/doRSNKSWfl @jamieson",
    "id" : 613760329508593664,
    "created_at" : "2015-06-24 17:27:20 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 613763038852837376,
  "created_at" : "2015-06-24 17:38:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    }, {
      "name" : "Megan Smith",
      "screen_name" : "USCTO",
      "indices" : [ 36, 42 ],
      "id_str" : "2888895350",
      "id" : 2888895350
    }, {
      "name" : "Leanne Pittsford",
      "screen_name" : "lepitts",
      "indices" : [ 43, 51 ],
      "id_str" : "16365839",
      "id" : 16365839
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/whitehouseostp\/status\/613735836694134785\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/94eYXFSVHl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIRtfXxVEAEi0CI.jpg",
      "id_str" : "613735834953519105",
      "id" : 613735834953519105,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIRtfXxVEAEi0CI.jpg",
      "sizes" : [ {
        "h" : 121,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 182,
        "resize" : "fit",
        "w" : 512
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 182,
        "resize" : "fit",
        "w" : 512
      }, {
        "h" : 182,
        "resize" : "fit",
        "w" : 512
      } ],
      "display_url" : "pic.twitter.com\/94eYXFSVHl"
    } ],
    "hashtags" : [ {
      "text" : "WeTheGeeks",
      "indices" : [ 57, 68 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/dkx85Zz27R",
      "expanded_url" : "http:\/\/wh.gov\/i0oD3",
      "display_url" : "wh.gov\/i0oD3"
    } ]
  },
  "geo" : { },
  "id_str" : "613753727212584960",
  "text" : "RT @whitehouseostp: 1PM TODAY: Join @USCTO @lepitts for \"#WeTheGeeks: Made with Pride\"  \u2192 http:\/\/t.co\/dkx85Zz27R http:\/\/t.co\/94eYXFSVHl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Megan Smith",
        "screen_name" : "USCTO",
        "indices" : [ 16, 22 ],
        "id_str" : "2888895350",
        "id" : 2888895350
      }, {
        "name" : "Leanne Pittsford",
        "screen_name" : "lepitts",
        "indices" : [ 23, 31 ],
        "id_str" : "16365839",
        "id" : 16365839
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/whitehouseostp\/status\/613735836694134785\/photo\/1",
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/94eYXFSVHl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CIRtfXxVEAEi0CI.jpg",
        "id_str" : "613735834953519105",
        "id" : 613735834953519105,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIRtfXxVEAEi0CI.jpg",
        "sizes" : [ {
          "h" : 121,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 182,
          "resize" : "fit",
          "w" : 512
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 182,
          "resize" : "fit",
          "w" : 512
        }, {
          "h" : 182,
          "resize" : "fit",
          "w" : 512
        } ],
        "display_url" : "pic.twitter.com\/94eYXFSVHl"
      } ],
      "hashtags" : [ {
        "text" : "WeTheGeeks",
        "indices" : [ 37, 48 ]
      } ],
      "urls" : [ {
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/dkx85Zz27R",
        "expanded_url" : "http:\/\/wh.gov\/i0oD3",
        "display_url" : "wh.gov\/i0oD3"
      } ]
    },
    "geo" : { },
    "id_str" : "613735836694134785",
    "text" : "1PM TODAY: Join @USCTO @lepitts for \"#WeTheGeeks: Made with Pride\"  \u2192 http:\/\/t.co\/dkx85Zz27R http:\/\/t.co\/94eYXFSVHl",
    "id" : 613735836694134785,
    "created_at" : "2015-06-24 15:50:00 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 613753727212584960,
  "created_at" : "2015-06-24 17:01:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 115, 121 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "613749049850769408",
  "text" : "\"My message to anyone who harms Americans is that we do not forget. Our reach is long. And justice will be done.\" \u2014@POTUS",
  "id" : 613749049850769408,
  "created_at" : "2015-06-24 16:42:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "613748369807310848",
  "text" : "RT @WHLive: \"These families are to be treated like what they are\u2014our trusted partners; active partners in the recovery of their loved ones.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 130, 136 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "613748342523342848",
    "text" : "\"These families are to be treated like what they are\u2014our trusted partners; active partners in the recovery of their loved ones.\" \u2014@POTUS",
    "id" : 613748342523342848,
    "created_at" : "2015-06-24 16:39:42 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 613748369807310848,
  "created_at" : "2015-06-24 16:39:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 118, 124 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "613747561132744704",
  "text" : "\"Paying ransom to terrorists risks endangering more Americans and funding the very terrorism we are trying to stop.\" \u2014@POTUS",
  "id" : 613747561132744704,
  "created_at" : "2015-06-24 16:36:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 130, 136 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "613747236632027137",
  "text" : "\"The United States government will not make concessions, such as paying ransoms, to terrorist groups holding American hostages.\" \u2014@POTUS",
  "id" : 613747236632027137,
  "created_at" : "2015-06-24 16:35:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 122, 128 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "613747051445116928",
  "text" : "\"Today, I\u2019m formally issuing a new presidential policy directive to improve how we work to bring home American hostages\" \u2014@POTUS",
  "id" : 613747051445116928,
  "created_at" : "2015-06-24 16:34:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 112, 118 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "613745942366416896",
  "text" : "\"We should always do everything in our power to bring these Americans home safe and to support their families\" \u2014@POTUS on our hostage policy",
  "id" : 613745942366416896,
  "created_at" : "2015-06-24 16:30:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/QlGsvqbAzV",
      "expanded_url" : "http:\/\/go.wh.gov\/cn8Br5",
      "display_url" : "go.wh.gov\/cn8Br5"
    } ]
  },
  "geo" : { },
  "id_str" : "613745886401683456",
  "text" : "RT @WHLive: Watch live: President Obama speaks on the completion of the Hostage Policy Review \u2192 http:\/\/t.co\/QlGsvqbAzV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/QlGsvqbAzV",
        "expanded_url" : "http:\/\/go.wh.gov\/cn8Br5",
        "display_url" : "go.wh.gov\/cn8Br5"
      } ]
    },
    "geo" : { },
    "id_str" : "613745860472651776",
    "text" : "Watch live: President Obama speaks on the completion of the Hostage Policy Review \u2192 http:\/\/t.co\/QlGsvqbAzV",
    "id" : 613745860472651776,
    "created_at" : "2015-06-24 16:29:50 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 613745886401683456,
  "created_at" : "2015-06-24 16:29:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/6KItePB0nc",
      "expanded_url" : "http:\/\/go.wh.gov\/cn8Br5",
      "display_url" : "go.wh.gov\/cn8Br5"
    } ]
  },
  "geo" : { },
  "id_str" : "613740926322651136",
  "text" : "At 12:20pm ET, watch President Obama speak on the completion of the Hostage Policy Review \u2192 http:\/\/t.co\/6KItePB0nc",
  "id" : 613740926322651136,
  "created_at" : "2015-06-24 16:10:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 16, 19 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/613497791004979200\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/XQKJPgnkRy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIOUxVOWIAA33Ej.jpg",
      "id_str" : "613497549484335104",
      "id" : 613497549484335104,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIOUxVOWIAA33Ej.jpg",
      "sizes" : [ {
        "h" : 232,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 409,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1908,
        "resize" : "fit",
        "w" : 2800
      }, {
        "h" : 698,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/XQKJPgnkRy"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "613497791004979200",
  "text" : ".@POTUS and the @VP watch as the Senate takes the next step toward passing the most progressive trade deal ever. http:\/\/t.co\/XQKJPgnkRy",
  "id" : 613497791004979200,
  "created_at" : "2015-06-24 00:04:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SDPB News",
      "screen_name" : "SDPBNews",
      "indices" : [ 104, 113 ],
      "id_str" : "119905756",
      "id" : 119905756
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/aTjEWRta00",
      "expanded_url" : "http:\/\/listen.sdpb.org\/post\/thunder-valley-cdc-aims-forge-new-tribal-community",
      "display_url" : "listen.sdpb.org\/post\/thunder-v\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "613459068263358464",
  "text" : "Worth a read: Important work being done to build an energy self-sufficient community on Pine Ridge (via @SDPBNews) \u2192 http:\/\/t.co\/aTjEWRta00",
  "id" : 613459068263358464,
  "created_at" : "2015-06-23 21:30:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Broderick Johnson",
      "screen_name" : "Broderick44",
      "indices" : [ 3, 15 ],
      "id_str" : "3246838764",
      "id" : 3246838764
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MBKtownhall",
      "indices" : [ 21, 33 ]
    }, {
      "text" : "MyBrothersKeeper",
      "indices" : [ 113, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "613450460167417856",
  "text" : "RT @Broderick44: The #MBKtownhall is starting soon - 5ET. I'm looking forward to your questions. Get them ready. #MyBrothersKeeper",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MBKtownhall",
        "indices" : [ 4, 16 ]
      }, {
        "text" : "MyBrothersKeeper",
        "indices" : [ 96, 113 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "613450054045667328",
    "text" : "The #MBKtownhall is starting soon - 5ET. I'm looking forward to your questions. Get them ready. #MyBrothersKeeper",
    "id" : 613450054045667328,
    "created_at" : "2015-06-23 20:54:24 +0000",
    "user" : {
      "name" : "Broderick Johnson",
      "screen_name" : "Broderick44",
      "protected" : false,
      "id_str" : "3246838764",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/610850749086433280\/Y1iGefZo_normal.jpg",
      "id" : 3246838764,
      "verified" : true
    }
  },
  "id" : 613450460167417856,
  "created_at" : "2015-06-23 20:56:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DiscoveryComm",
      "screen_name" : "DiscoveryComm",
      "indices" : [ 3, 17 ],
      "id_str" : "22061951",
      "id" : 22061951
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyBrothersKeeper",
      "indices" : [ 46, 63 ]
    }, {
      "text" : "MBKTownHall",
      "indices" : [ 121, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/ggd74phyG4",
      "expanded_url" : "http:\/\/ow.ly\/OGIQV",
      "display_url" : "ow.ly\/OGIQV"
    } ]
  },
  "geo" : { },
  "id_str" : "613450005823684608",
  "text" : "RT @DiscoveryComm: Join Leaders for a Special #MyBrothersKeeper Twitter Town Hall Today at 5pm ET http:\/\/t.co\/ggd74phyG4 #MBKTownHall",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MyBrothersKeeper",
        "indices" : [ 27, 44 ]
      }, {
        "text" : "MBKTownHall",
        "indices" : [ 102, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/ggd74phyG4",
        "expanded_url" : "http:\/\/ow.ly\/OGIQV",
        "display_url" : "ow.ly\/OGIQV"
      } ]
    },
    "geo" : { },
    "id_str" : "613361564507328512",
    "text" : "Join Leaders for a Special #MyBrothersKeeper Twitter Town Hall Today at 5pm ET http:\/\/t.co\/ggd74phyG4 #MBKTownHall",
    "id" : 613361564507328512,
    "created_at" : "2015-06-23 15:02:47 +0000",
    "user" : {
      "name" : "DiscoveryComm",
      "screen_name" : "DiscoveryComm",
      "protected" : false,
      "id_str" : "22061951",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/707696776158035968\/ovhdqDRA_normal.jpg",
      "id" : 22061951,
      "verified" : true
    }
  },
  "id" : 613450005823684608,
  "created_at" : "2015-06-23 20:54:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/613443726178914304\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/YhX1inCibo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CINjv5-W8AAWyGL.jpg",
      "id_str" : "613443648919891968",
      "id" : 613443648919891968,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CINjv5-W8AAWyGL.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/YhX1inCibo"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 104, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/tYWUJQpRie",
      "expanded_url" : "http:\/\/go.wh.gov\/sEz2PL",
      "display_url" : "go.wh.gov\/sEz2PL"
    } ]
  },
  "geo" : { },
  "id_str" : "613443726178914304",
  "text" : "President Obama's clean power plant standards would reduce smog and soot by 25%: http:\/\/t.co\/tYWUJQpRie #ActOnClimate http:\/\/t.co\/YhX1inCibo",
  "id" : 613443726178914304,
  "created_at" : "2015-06-23 20:29:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sylvia Burwell",
      "screen_name" : "SecBurwell",
      "indices" : [ 3, 14 ],
      "id_str" : "2458567464",
      "id" : 2458567464
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 36, 49 ]
    }, {
      "text" : "2degrees",
      "indices" : [ 129, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/j9PXq13bhI",
      "expanded_url" : "http:\/\/www2.epa.gov\/cira",
      "display_url" : "www2.epa.gov\/cira"
    } ]
  },
  "geo" : { },
  "id_str" : "613438262951067648",
  "text" : "RT @SecBurwell: It\u2019s time for us to #ActOnClimate, for the sake of our children\u2019s health and our planet \u2192 http:\/\/t.co\/j9PXq13bhI #2degrees",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 20, 33 ]
      }, {
        "text" : "2degrees",
        "indices" : [ 113, 122 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/j9PXq13bhI",
        "expanded_url" : "http:\/\/www2.epa.gov\/cira",
        "display_url" : "www2.epa.gov\/cira"
      } ]
    },
    "geo" : { },
    "id_str" : "613395203437764608",
    "text" : "It\u2019s time for us to #ActOnClimate, for the sake of our children\u2019s health and our planet \u2192 http:\/\/t.co\/j9PXq13bhI #2degrees",
    "id" : 613395203437764608,
    "created_at" : "2015-06-23 17:16:27 +0000",
    "user" : {
      "name" : "Sylvia Burwell",
      "screen_name" : "SecBurwell",
      "protected" : false,
      "id_str" : "2458567464",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567351512351793152\/jMgeUhVq_normal.jpeg",
      "id" : 2458567464,
      "verified" : true
    }
  },
  "id" : 613438262951067648,
  "created_at" : "2015-06-23 20:07:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David E. Price",
      "screen_name" : "RepDavidEPrice",
      "indices" : [ 3, 18 ],
      "id_str" : "155669457",
      "id" : 155669457
    }, {
      "name" : "LCV",
      "screen_name" : "LCVoters",
      "indices" : [ 106, 115 ],
      "id_str" : "20517132",
      "id" : 20517132
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/RepDavidEPrice\/status\/613374085255557120\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/EfYRLvMyhY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIMkeu9UkAA9ix1.png",
      "id_str" : "613374084672425984",
      "id" : 613374084672425984,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIMkeu9UkAA9ix1.png",
      "sizes" : [ {
        "h" : 276,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 156,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 367,
        "resize" : "fit",
        "w" : 799
      }, {
        "h" : 367,
        "resize" : "fit",
        "w" : 799
      } ],
      "display_url" : "pic.twitter.com\/EfYRLvMyhY"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 28, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "613436091798978561",
  "text" : "RT @RepDavidEPrice: We must #ActOnClimate because addressing climate change is a public health imperative @LCVoters http:\/\/t.co\/EfYRLvMyhY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "LCV",
        "screen_name" : "LCVoters",
        "indices" : [ 86, 95 ],
        "id_str" : "20517132",
        "id" : 20517132
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/RepDavidEPrice\/status\/613374085255557120\/photo\/1",
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/EfYRLvMyhY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CIMkeu9UkAA9ix1.png",
        "id_str" : "613374084672425984",
        "id" : 613374084672425984,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIMkeu9UkAA9ix1.png",
        "sizes" : [ {
          "h" : 276,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 156,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 367,
          "resize" : "fit",
          "w" : 799
        }, {
          "h" : 367,
          "resize" : "fit",
          "w" : 799
        } ],
        "display_url" : "pic.twitter.com\/EfYRLvMyhY"
      } ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 8, 21 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "613374085255557120",
    "text" : "We must #ActOnClimate because addressing climate change is a public health imperative @LCVoters http:\/\/t.co\/EfYRLvMyhY",
    "id" : 613374085255557120,
    "created_at" : "2015-06-23 15:52:32 +0000",
    "user" : {
      "name" : "David E. Price",
      "screen_name" : "RepDavidEPrice",
      "protected" : false,
      "id_str" : "155669457",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/990224608\/David_Price_normal.jpg",
      "id" : 155669457,
      "verified" : true
    }
  },
  "id" : 613436091798978561,
  "created_at" : "2015-06-23 19:58:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "APHA",
      "screen_name" : "PublicHealth",
      "indices" : [ 3, 16 ],
      "id_str" : "6794502",
      "id" : 6794502
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/PublicHealth\/status\/613367497706897408\/photo\/1",
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/MXkeHxJVCT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIMefTKWIAAJnJs.jpg",
      "id_str" : "613367497320964096",
      "id" : 613367497320964096,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIMefTKWIAAJnJs.jpg",
      "sizes" : [ {
        "h" : 263,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 464,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 773,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 773,
        "resize" : "fit",
        "w" : 1000
      } ],
      "display_url" : "pic.twitter.com\/MXkeHxJVCT"
    } ],
    "hashtags" : [ {
      "text" : "ActonClimate",
      "indices" : [ 21, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "613426219900518400",
  "text" : "RT @PublicHealth: We #ActonClimate because clean air matters to public health. What\u2019s your reason? http:\/\/t.co\/MXkeHxJVCT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PublicHealth\/status\/613367497706897408\/photo\/1",
        "indices" : [ 81, 103 ],
        "url" : "http:\/\/t.co\/MXkeHxJVCT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CIMefTKWIAAJnJs.jpg",
        "id_str" : "613367497320964096",
        "id" : 613367497320964096,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIMefTKWIAAJnJs.jpg",
        "sizes" : [ {
          "h" : 263,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 464,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 773,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 773,
          "resize" : "fit",
          "w" : 1000
        } ],
        "display_url" : "pic.twitter.com\/MXkeHxJVCT"
      } ],
      "hashtags" : [ {
        "text" : "ActonClimate",
        "indices" : [ 3, 16 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "613367497706897408",
    "text" : "We #ActonClimate because clean air matters to public health. What\u2019s your reason? http:\/\/t.co\/MXkeHxJVCT",
    "id" : 613367497706897408,
    "created_at" : "2015-06-23 15:26:21 +0000",
    "user" : {
      "name" : "APHA",
      "screen_name" : "PublicHealth",
      "protected" : false,
      "id_str" : "6794502",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000689227713\/e1a85fa774ec719d4603208adc9a3eba_normal.png",
      "id" : 6794502,
      "verified" : true
    }
  },
  "id" : 613426219900518400,
  "created_at" : "2015-06-23 19:19:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sally Jewell",
      "screen_name" : "SecretaryJewell",
      "indices" : [ 3, 19 ],
      "id_str" : "1342861723",
      "id" : 1342861723
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 80, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "613412226137862144",
  "text" : "RT @SecretaryJewell: Climate change is putting our nat'l parks at risk. We must #ActOnClimate to protect these special places for all.SJ ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 59, 72 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/Rzh2DyRSLM",
        "expanded_url" : "http:\/\/on.doi.gov\/1IwRXxQ",
        "display_url" : "on.doi.gov\/1IwRXxQ"
      } ]
    },
    "geo" : { },
    "id_str" : "613405900146147328",
    "text" : "Climate change is putting our nat'l parks at risk. We must #ActOnClimate to protect these special places for all.SJ http:\/\/t.co\/Rzh2DyRSLM",
    "id" : 613405900146147328,
    "created_at" : "2015-06-23 17:58:57 +0000",
    "user" : {
      "name" : "Sally Jewell",
      "screen_name" : "SecretaryJewell",
      "protected" : false,
      "id_str" : "1342861723",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3525481506\/1ddf16c2cb47608803abe4dc7fc133fe_normal.jpeg",
      "id" : 1342861723,
      "verified" : true
    }
  },
  "id" : 613412226137862144,
  "created_at" : "2015-06-23 18:24:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sierra Club",
      "screen_name" : "sierraclub",
      "indices" : [ 3, 14 ],
      "id_str" : "34113439",
      "id" : 34113439
    }, {
      "name" : "U.S. EPA",
      "screen_name" : "EPA",
      "indices" : [ 23, 27 ],
      "id_str" : "14615871",
      "id" : 14615871
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/sierraclub\/status\/613404380268756993\/photo\/1",
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/CqOUd2dXfG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CINACI5XAAIl6u4.jpg",
      "id_str" : "613404379744501762",
      "id" : 613404379744501762,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CINACI5XAAIl6u4.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/CqOUd2dXfG"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 69, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "613404938111049728",
  "text" : "RT @sierraclub: Thanks @epa! The Clean Power Plan is how the US will #ActOnClimate: http:\/\/t.co\/CqOUd2dXfG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "U.S. EPA",
        "screen_name" : "EPA",
        "indices" : [ 7, 11 ],
        "id_str" : "14615871",
        "id" : 14615871
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/sierraclub\/status\/613404380268756993\/photo\/1",
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/CqOUd2dXfG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CINACI5XAAIl6u4.jpg",
        "id_str" : "613404379744501762",
        "id" : 613404379744501762,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CINACI5XAAIl6u4.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/CqOUd2dXfG"
      } ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 53, 66 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "613404380268756993",
    "text" : "Thanks @epa! The Clean Power Plan is how the US will #ActOnClimate: http:\/\/t.co\/CqOUd2dXfG",
    "id" : 613404380268756993,
    "created_at" : "2015-06-23 17:52:55 +0000",
    "user" : {
      "name" : "Sierra Club",
      "screen_name" : "sierraclub",
      "protected" : false,
      "id_str" : "34113439",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796403288262475777\/TnaMEVYQ_normal.jpg",
      "id" : 34113439,
      "verified" : true
    }
  },
  "id" : 613404938111049728,
  "created_at" : "2015-06-23 17:55:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 5, 11 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 51, 64 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/tYWUJQ8fTE",
      "expanded_url" : "http:\/\/go.wh.gov\/sEz2PL",
      "display_url" : "go.wh.gov\/sEz2PL"
    }, {
      "indices" : [ 90, 113 ],
      "url" : "https:\/\/t.co\/hIpBiP8D6B",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/14fa406f-e95c-4996-a95e-5a9b54717fd8",
      "display_url" : "amp.twimg.com\/v\/14fa406f-e95\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "613401723118333954",
  "text" : "Join @POTUS and share why you believe it's time to #ActOnClimate \u2192 http:\/\/t.co\/tYWUJQ8fTE\nhttps:\/\/t.co\/hIpBiP8D6B",
  "id" : 613401723118333954,
  "created_at" : "2015-06-23 17:42:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/613394278090469376\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/S2Cebct7s9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIM2zD7WwAId0j1.jpg",
      "id_str" : "613394225108008962",
      "id" : 613394225108008962,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIM2zD7WwAId0j1.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/S2Cebct7s9"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 80, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/tYWUJQpRie",
      "expanded_url" : "http:\/\/go.wh.gov\/sEz2PL",
      "display_url" : "go.wh.gov\/sEz2PL"
    } ]
  },
  "geo" : { },
  "id_str" : "613394278090469376",
  "text" : "To act or not to act.\nThat's the choice we face.\nLet's do right by our kids and #ActOnClimate: http:\/\/t.co\/tYWUJQpRie http:\/\/t.co\/S2Cebct7s9",
  "id" : 613394278090469376,
  "created_at" : "2015-06-23 17:12:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Utech",
      "screen_name" : "Utech44",
      "indices" : [ 3, 11 ],
      "id_str" : "2283772130",
      "id" : 2283772130
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Utech44\/status\/613375764625387520\/photo\/1",
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/oKAkdKonPe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIMmAXUUwAAeZPp.jpg",
      "id_str" : "613375761953636352",
      "id" : 613375761953636352,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIMmAXUUwAAeZPp.jpg",
      "sizes" : [ {
        "h" : 803,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 455,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 803,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 803,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/oKAkdKonPe"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 15, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "613378637060964357",
  "text" : "RT @Utech44: I #ActOnClimate to protect the people and the places I love. Share with us your reason! http:\/\/t.co\/oKAkdKonPe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Utech44\/status\/613375764625387520\/photo\/1",
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/oKAkdKonPe",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CIMmAXUUwAAeZPp.jpg",
        "id_str" : "613375761953636352",
        "id" : 613375761953636352,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIMmAXUUwAAeZPp.jpg",
        "sizes" : [ {
          "h" : 803,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 455,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 803,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 803,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/oKAkdKonPe"
      } ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 2, 15 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "613375764625387520",
    "text" : "I #ActOnClimate to protect the people and the places I love. Share with us your reason! http:\/\/t.co\/oKAkdKonPe",
    "id" : 613375764625387520,
    "created_at" : "2015-06-23 15:59:12 +0000",
    "user" : {
      "name" : "Dan Utech",
      "screen_name" : "Utech44",
      "protected" : false,
      "id_str" : "2283772130",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705138779221135360\/UcDKamCq_normal.jpg",
      "id" : 2283772130,
      "verified" : true
    }
  },
  "id" : 613378637060964357,
  "created_at" : "2015-06-23 16:10:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/613370160435621888\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/sCH1xlXa0Q",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIMg1ggW8AAEChG.jpg",
      "id_str" : "613370077883330560",
      "id" : 613370077883330560,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIMg1ggW8AAEChG.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/sCH1xlXa0Q"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 9, 22 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/tYWUJQpRie",
      "expanded_url" : "http:\/\/go.wh.gov\/sEz2PL",
      "display_url" : "go.wh.gov\/sEz2PL"
    } ]
  },
  "geo" : { },
  "id_str" : "613370160435621888",
  "text" : "Join the #ActOnClimate conversation on public health around today's White House summit \u2192 http:\/\/t.co\/tYWUJQpRie http:\/\/t.co\/sCH1xlXa0Q",
  "id" : 613370160435621888,
  "created_at" : "2015-06-23 15:36:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Senator Harry Reid",
      "screen_name" : "SenatorReid",
      "indices" : [ 3, 15 ],
      "id_str" : "16789970",
      "id" : 16789970
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "613364565158555650",
  "text" : "RT @SenatorReid: We should act to save lives by expanding background checks. If we do not, we will be here again.  Our hearts will be broke\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "613350259264225280",
    "text" : "We should act to save lives by expanding background checks. If we do not, we will be here again.  Our hearts will be broken again.",
    "id" : 613350259264225280,
    "created_at" : "2015-06-23 14:17:51 +0000",
    "user" : {
      "name" : "Senator Harry Reid",
      "screen_name" : "SenatorReid",
      "protected" : false,
      "id_str" : "16789970",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/628307865065816064\/OUQh91yr_normal.jpg",
      "id" : 16789970,
      "verified" : true
    }
  },
  "id" : 613364565158555650,
  "created_at" : "2015-06-23 15:14:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "indices" : [ 3, 11 ],
      "id_str" : "2382117350",
      "id" : 2382117350
    }, {
      "name" : "U.S. Surgeon General",
      "screen_name" : "Surgeon_General",
      "indices" : [ 94, 110 ],
      "id_str" : "455024343",
      "id" : 455024343
    }, {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 111, 126 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 31, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "613350429758328833",
  "text" : "RT @Deese44: Join the convo on #ActOnClimate &amp; public health by asking your questions for @Surgeon_General @whitehouseostp here: https:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "U.S. Surgeon General",
        "screen_name" : "Surgeon_General",
        "indices" : [ 81, 97 ],
        "id_str" : "455024343",
        "id" : 455024343
      }, {
        "name" : "The White House OSTP",
        "screen_name" : "whitehouseostp",
        "indices" : [ 98, 113 ],
        "id_str" : "33998183",
        "id" : 33998183
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 18, 31 ]
      } ],
      "urls" : [ {
        "indices" : [ 120, 143 ],
        "url" : "https:\/\/t.co\/2FmRsBUAWU",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/webform\/ask-experts-how-climate-change-impacting-your-health",
        "display_url" : "whitehouse.gov\/webform\/ask-ex\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "613349163980464130",
    "text" : "Join the convo on #ActOnClimate &amp; public health by asking your questions for @Surgeon_General @whitehouseostp here: https:\/\/t.co\/2FmRsBUAWU",
    "id" : 613349163980464130,
    "created_at" : "2015-06-23 14:13:30 +0000",
    "user" : {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "protected" : false,
      "id_str" : "2382117350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656551411145027584\/ArrSlGUP_normal.jpg",
      "id" : 2382117350,
      "verified" : true
    }
  },
  "id" : 613350429758328833,
  "created_at" : "2015-06-23 14:18:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 57, 63 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/613347412296347648\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/Thgmk8dcz9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIMMJimWoAAidzD.jpg",
      "id_str" : "613347332298547200",
      "id" : 613347332298547200,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIMMJimWoAAidzD.jpg",
      "sizes" : [ {
        "h" : 1866,
        "resize" : "fit",
        "w" : 2800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Thgmk8dcz9"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 117 ],
      "url" : "https:\/\/t.co\/ewgjEaX4D4",
      "expanded_url" : "https:\/\/youtu.be\/EQkGGxZmpqA",
      "display_url" : "youtu.be\/EQkGGxZmpqA"
    } ]
  },
  "geo" : { },
  "id_str" : "613347412296347648",
  "text" : "\"To Muslim Americans across the country\u2014Ramadan Kareem\" \u2014@POTUS at last night's Iftar dinner: https:\/\/t.co\/ewgjEaX4D4 http:\/\/t.co\/Thgmk8dcz9",
  "id" : 613347412296347648,
  "created_at" : "2015-06-23 14:06:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/POTUS\/status\/613130677303799809\/photo\/1",
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/btu3dRXPbr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIJHGA3WoAA4zdV.jpg",
      "id_str" : "613130667912765440",
      "id" : 613130667912765440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIJHGA3WoAA4zdV.jpg",
      "sizes" : [ {
        "h" : 510,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 900,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 667
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 667
      } ],
      "display_url" : "pic.twitter.com\/btu3dRXPbr"
    } ],
    "hashtags" : [ {
      "text" : "OneNationOneTeam",
      "indices" : [ 57, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "613131318352740353",
  "text" : "RT @POTUS: Good luck Team USA \u2013 make us proud out there! #OneNationOneTeam http:\/\/t.co\/btu3dRXPbr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/POTUS\/status\/613130677303799809\/photo\/1",
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/btu3dRXPbr",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CIJHGA3WoAA4zdV.jpg",
        "id_str" : "613130667912765440",
        "id" : 613130667912765440,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIJHGA3WoAA4zdV.jpg",
        "sizes" : [ {
          "h" : 510,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 900,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 667
        }, {
          "h" : 1000,
          "resize" : "fit",
          "w" : 667
        } ],
        "display_url" : "pic.twitter.com\/btu3dRXPbr"
      } ],
      "hashtags" : [ {
        "text" : "OneNationOneTeam",
        "indices" : [ 46, 63 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "613130677303799809",
    "text" : "Good luck Team USA \u2013 make us proud out there! #OneNationOneTeam http:\/\/t.co\/btu3dRXPbr",
    "id" : 613130677303799809,
    "created_at" : "2015-06-22 23:45:19 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 613131318352740353,
  "created_at" : "2015-06-22 23:47:52 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 12, 18 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/613121278224896000\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/pjuvwJ3TTZ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CII-hRxWgAAH3XO.jpg",
      "id_str" : "613121240702812160",
      "id" : 613121240702812160,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CII-hRxWgAAH3XO.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/pjuvwJ3TTZ"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 47, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "613121278224896000",
  "text" : "FACT: Since @POTUS first called on Congress to #RaiseTheWage in 2013, 17 states have answered his call. http:\/\/t.co\/pjuvwJ3TTZ",
  "id" : 613121278224896000,
  "created_at" : "2015-06-22 23:07:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/613112900450914305\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/KZ2RaVbvl1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CII1lP8WsAA7m8v.jpg",
      "id_str" : "613111413326917632",
      "id" : 613111413326917632,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CII1lP8WsAA7m8v.jpg",
      "sizes" : [ {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/KZ2RaVbvl1"
    } ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 83, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "613112900450914305",
  "text" : "Good news: Rhode Island just raised its minimum wage.\nRT if you agree it's time to #RaiseTheWage for all Americans. http:\/\/t.co\/KZ2RaVbvl1",
  "id" : 613112900450914305,
  "created_at" : "2015-06-22 22:34:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/613050626667188225\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/TODasNxzXO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIH-CB1WgAAuANk.jpg",
      "id_str" : "613050335104499712",
      "id" : 613050335104499712,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIH-CB1WgAAuANk.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/TODasNxzXO"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/cmANKP1vwF",
      "expanded_url" : "http:\/\/go.wh.gov\/9jsZvD",
      "display_url" : "go.wh.gov\/9jsZvD"
    } ]
  },
  "geo" : { },
  "id_str" : "613050626667188225",
  "text" : "Trade Adjustment Assistance has helped more than 2.2 million workers.\nLet's reauthorize it \u2192 http:\/\/t.co\/cmANKP1vwF http:\/\/t.co\/TODasNxzXO",
  "id" : 613050626667188225,
  "created_at" : "2015-06-22 18:27:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. EPA",
      "screen_name" : "EPA",
      "indices" : [ 3, 7 ],
      "id_str" : "14615871",
      "id" : 14615871
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/A7lN4h9Xdm",
      "expanded_url" : "https:\/\/youtu.be\/_Iz0NKA1yuo",
      "display_url" : "youtu.be\/_Iz0NKA1yuo"
    } ]
  },
  "geo" : { },
  "id_str" : "613020653277462528",
  "text" : "RT @EPA: With climate change, we face a choice between two futures. Learn the benefits of action in our new report. https:\/\/t.co\/A7lN4h9Xdm\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "2degrees",
        "indices" : [ 131, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/A7lN4h9Xdm",
        "expanded_url" : "https:\/\/youtu.be\/_Iz0NKA1yuo",
        "display_url" : "youtu.be\/_Iz0NKA1yuo"
      } ]
    },
    "geo" : { },
    "id_str" : "613018201455247360",
    "text" : "With climate change, we face a choice between two futures. Learn the benefits of action in our new report. https:\/\/t.co\/A7lN4h9Xdm #2degrees",
    "id" : 613018201455247360,
    "created_at" : "2015-06-22 16:18:23 +0000",
    "user" : {
      "name" : "U.S. EPA",
      "screen_name" : "EPA",
      "protected" : false,
      "id_str" : "14615871",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/632228259879628800\/-gvVhzPn_normal.png",
      "id" : 14615871,
      "verified" : true
    }
  },
  "id" : 613020653277462528,
  "created_at" : "2015-06-22 16:28:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "612996016933965824",
  "text" : "RT @vj44: It's on us to honor their lives by working to prevent another tragedy like this from occurring. It's time to act.  https:\/\/t.co\/Z\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/ZEx7WfkBO3",
        "expanded_url" : "https:\/\/twitter.com\/asiampag\/status\/612981030568366081",
        "display_url" : "twitter.com\/asiampag\/statu\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "612994349098496001",
    "text" : "It's on us to honor their lives by working to prevent another tragedy like this from occurring. It's time to act.  https:\/\/t.co\/ZEx7WfkBO3",
    "id" : 612994349098496001,
    "created_at" : "2015-06-22 14:43:36 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 612996016933965824,
  "created_at" : "2015-06-22 14:50:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EmanuelAMEChurch",
      "indices" : [ 45, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "612982320467853312",
  "text" : "RT @vj44: When put to the ultimate test, the #EmanuelAMEChurch family showed that even w\/ crushed hearts, their faith, decency &amp;humanity re\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EmanuelAMEChurch",
        "indices" : [ 35, 52 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "612978781075058688",
    "text" : "When put to the ultimate test, the #EmanuelAMEChurch family showed that even w\/ crushed hearts, their faith, decency &amp;humanity remain strong",
    "id" : 612978781075058688,
    "created_at" : "2015-06-22 13:41:44 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 612982320467853312,
  "created_at" : "2015-06-22 13:55:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "marc maron",
      "screen_name" : "marcmaron",
      "indices" : [ 10, 20 ],
      "id_str" : "21718006",
      "id" : 21718006
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/612976816223989760\/photo\/1",
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/7kXfGtvFQ6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIG6-29WgAEeH-g.jpg",
      "id_str" : "612976613366595585",
      "id" : 612976613366595585,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIG6-29WgAEeH-g.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/7kXfGtvFQ6"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/QdBakcxZZI",
      "expanded_url" : "http:\/\/www.wtfpod.com\/",
      "display_url" : "wtfpod.com"
    } ]
  },
  "geo" : { },
  "id_str" : "612976816223989760",
  "text" : ".@POTUS \u2713\n@MarcMaron \u2713\nIn the garage \u2713\nListen to the podcast now \u2192 http:\/\/t.co\/QdBakcxZZI http:\/\/t.co\/7kXfGtvFQ6",
  "id" : 612976816223989760,
  "created_at" : "2015-06-22 13:33:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "marc maron",
      "screen_name" : "marcmaron",
      "indices" : [ 3, 13 ],
      "id_str" : "21718006",
      "id" : 21718006
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 24, 30 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "WTF with Marc Maron",
      "screen_name" : "WTFpod",
      "indices" : [ 38, 45 ],
      "id_str" : "69406730",
      "id" : 69406730
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/TRZkCfIIIs",
      "expanded_url" : "http:\/\/wtfpod.com",
      "display_url" : "wtfpod.com"
    } ]
  },
  "geo" : { },
  "id_str" : "612970317040910336",
  "text" : "RT @marcmaron: Today is @POTUS day on @WTFpod! He\u2019s the President! Good talk! Do it up! http:\/\/t.co\/TRZkCfIIIs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 9, 15 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "WTF with Marc Maron",
        "screen_name" : "WTFpod",
        "indices" : [ 23, 30 ],
        "id_str" : "69406730",
        "id" : 69406730
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 73, 95 ],
        "url" : "http:\/\/t.co\/TRZkCfIIIs",
        "expanded_url" : "http:\/\/wtfpod.com",
        "display_url" : "wtfpod.com"
      } ]
    },
    "geo" : { },
    "id_str" : "612953218100822017",
    "text" : "Today is @POTUS day on @WTFpod! He\u2019s the President! Good talk! Do it up! http:\/\/t.co\/TRZkCfIIIs",
    "id" : 612953218100822017,
    "created_at" : "2015-06-22 12:00:09 +0000",
    "user" : {
      "name" : "marc maron",
      "screen_name" : "marcmaron",
      "protected" : false,
      "id_str" : "21718006",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/678971145\/63226917-2_normal.jpg",
      "id" : 21718006,
      "verified" : true
    }
  },
  "id" : 612970317040910336,
  "created_at" : "2015-06-22 13:08:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sally Jewell",
      "screen_name" : "SecretaryJewell",
      "indices" : [ 3, 19 ],
      "id_str" : "1342861723",
      "id" : 1342861723
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyBrothersKeeper",
      "indices" : [ 25, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "612801513304535040",
  "text" : "RT @SecretaryJewell: I'm #MyBrothersKeeper by getting more young people to play, learn, serve &amp; work on America's public lands\nhttps:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MyBrothersKeeper",
        "indices" : [ 4, 21 ]
      } ],
      "urls" : [ {
        "indices" : [ 110, 133 ],
        "url" : "https:\/\/t.co\/wHR5MFb5rN",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/e6e417e1-1d87-4df6-81c7-5edaada49ee9",
        "display_url" : "amp.twimg.com\/v\/e6e417e1-1d8\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "612754144525336576",
    "text" : "I'm #MyBrothersKeeper by getting more young people to play, learn, serve &amp; work on America's public lands\nhttps:\/\/t.co\/wHR5MFb5rN",
    "id" : 612754144525336576,
    "created_at" : "2015-06-21 22:49:07 +0000",
    "user" : {
      "name" : "Sally Jewell",
      "screen_name" : "SecretaryJewell",
      "protected" : false,
      "id_str" : "1342861723",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3525481506\/1ddf16c2cb47608803abe4dc7fc133fe_normal.jpeg",
      "id" : 1342861723,
      "verified" : true
    }
  },
  "id" : 612801513304535040,
  "created_at" : "2015-06-22 01:57:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Broderick Johnson",
      "screen_name" : "Broderick44",
      "indices" : [ 3, 15 ],
      "id_str" : "3246838764",
      "id" : 3246838764
    }, {
      "name" : "Huffington Post",
      "screen_name" : "HuffingtonPost",
      "indices" : [ 77, 92 ],
      "id_str" : "14511951",
      "id" : 14511951
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyBrothersKeeper",
      "indices" : [ 116, 133 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/ERu76I5wU4",
      "expanded_url" : "http:\/\/www.huffingtonpost.com\/broderick-johnson\/letter-to-my-sons-on-fath_b_7627566.html",
      "display_url" : "huffingtonpost.com\/broderick-john\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "612796772856037376",
  "text" : "RT @Broderick44: On this Father's Day I wrote \"A Letter to My Sons.\" Read on @HuffingtonPost http:\/\/t.co\/ERu76I5wU4 #MyBrothersKeeper http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Huffington Post",
        "screen_name" : "HuffingtonPost",
        "indices" : [ 60, 75 ],
        "id_str" : "14511951",
        "id" : 14511951
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Broderick44\/status\/612725142897168384\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/pZ6SEKApui",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CIDWRUZW8AEoxdL.jpg",
        "id_str" : "612725142343577601",
        "id" : 612725142343577601,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIDWRUZW8AEoxdL.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1200,
          "resize" : "fit",
          "w" : 1600
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/pZ6SEKApui"
      } ],
      "hashtags" : [ {
        "text" : "MyBrothersKeeper",
        "indices" : [ 99, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 76, 98 ],
        "url" : "http:\/\/t.co\/ERu76I5wU4",
        "expanded_url" : "http:\/\/www.huffingtonpost.com\/broderick-johnson\/letter-to-my-sons-on-fath_b_7627566.html",
        "display_url" : "huffingtonpost.com\/broderick-john\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "612725142897168384",
    "text" : "On this Father's Day I wrote \"A Letter to My Sons.\" Read on @HuffingtonPost http:\/\/t.co\/ERu76I5wU4 #MyBrothersKeeper http:\/\/t.co\/pZ6SEKApui",
    "id" : 612725142897168384,
    "created_at" : "2015-06-21 20:53:52 +0000",
    "user" : {
      "name" : "Broderick Johnson",
      "screen_name" : "Broderick44",
      "protected" : false,
      "id_str" : "3246838764",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/610850749086433280\/Y1iGefZo_normal.jpg",
      "id" : 3246838764,
      "verified" : true
    }
  },
  "id" : 612796772856037376,
  "created_at" : "2015-06-22 01:38:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 22, 28 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WestWingWeek",
      "indices" : [ 123, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/fXRZiUXiVD",
      "expanded_url" : "https:\/\/youtu.be\/QVGlArV-_yU",
      "display_url" : "youtu.be\/QVGlArV-_yU"
    } ]
  },
  "geo" : { },
  "id_str" : "612792816247435265",
  "text" : "Want to hang out with @POTUS? Take 7 minutes to watch a behind-the-scenes recap of his past week \u2192 https:\/\/t.co\/fXRZiUXiVD #WestWingWeek",
  "id" : 612792816247435265,
  "created_at" : "2015-06-22 01:22:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Stephen R",
      "screen_name" : "stephen_arizona",
      "indices" : [ 11, 27 ],
      "id_str" : "3191656651",
      "id" : 3191656651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "612686163128807428",
  "text" : "RT @vj44: .@stephen_arizona In too many of these tragedies, the guns were acquired\"lawfully\" by ppl who shouldn't have had access. That's u\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Stephen R",
        "screen_name" : "stephen_arizona",
        "indices" : [ 1, 17 ],
        "id_str" : "3191656651",
        "id" : 3191656651
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "612617067624202240",
    "geo" : { },
    "id_str" : "612678966286135296",
    "in_reply_to_user_id" : 3191656651,
    "text" : ".@stephen_arizona In too many of these tragedies, the guns were acquired\"lawfully\" by ppl who shouldn't have had access. That's unacceptable",
    "id" : 612678966286135296,
    "in_reply_to_status_id" : 612617067624202240,
    "created_at" : "2015-06-21 17:50:23 +0000",
    "in_reply_to_screen_name" : "stephen_arizona",
    "in_reply_to_user_id_str" : "3191656651",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 612686163128807428,
  "created_at" : "2015-06-21 18:18:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TakeItDown",
      "indices" : [ 119, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "612685773142401024",
  "text" : "RT @vj44: Calling it a \"little issue\"misses the significance of this symbol of racism&amp;the moment we have to change #TakeItDown https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TakeItDown",
        "indices" : [ 109, 120 ]
      } ],
      "urls" : [ {
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/f1GIHiz1j5",
        "expanded_url" : "https:\/\/twitter.com\/meetthepress\/status\/612615436635484161",
        "display_url" : "twitter.com\/meetthepress\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "612663111217213440",
    "text" : "Calling it a \"little issue\"misses the significance of this symbol of racism&amp;the moment we have to change #TakeItDown https:\/\/t.co\/f1GIHiz1j5",
    "id" : 612663111217213440,
    "created_at" : "2015-06-21 16:47:23 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 612685773142401024,
  "created_at" : "2015-06-21 18:17:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/612642358740582400\/photo\/1",
      "indices" : [ 20, 42 ],
      "url" : "http:\/\/t.co\/LxpFJrLG7x",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CICK78bXAAA3trG.jpg",
      "id_str" : "612642311760183296",
      "id" : 612642311760183296,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CICK78bXAAA3trG.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/LxpFJrLG7x"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "612642358740582400",
  "text" : "Happy Father's Day! http:\/\/t.co\/LxpFJrLG7x",
  "id" : 612642358740582400,
  "created_at" : "2015-06-21 15:24:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 91, 97 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/612622331362545664\/photo\/1",
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/oB0UQqDFay",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CIB4wlWWcAAWn3E.jpg",
      "id_str" : "612622325377298432",
      "id" : 612622325377298432,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIB4wlWWcAAWn3E.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/oB0UQqDFay"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "612633955909652480",
  "text" : "RT @FLOTUS: Thinking today and every day about the father of these two. Happy Father's Day @POTUS! -mo http:\/\/t.co\/oB0UQqDFay",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 79, 85 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FLOTUS\/status\/612622331362545664\/photo\/1",
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/oB0UQqDFay",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CIB4wlWWcAAWn3E.jpg",
        "id_str" : "612622325377298432",
        "id" : 612622325377298432,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CIB4wlWWcAAWn3E.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/oB0UQqDFay"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "612622331362545664",
    "text" : "Thinking today and every day about the father of these two. Happy Father's Day @POTUS! -mo http:\/\/t.co\/oB0UQqDFay",
    "id" : 612622331362545664,
    "created_at" : "2015-06-21 14:05:20 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 612633955909652480,
  "created_at" : "2015-06-21 14:51:31 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "612447975214690305",
  "text" : "RT @VP: Too many innocent lives lost. Too many families to console. Too many guns in the wrong hands. Enough is enough.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "612443269792985090",
    "text" : "Too many innocent lives lost. Too many families to console. Too many guns in the wrong hands. Enough is enough.",
    "id" : 612443269792985090,
    "created_at" : "2015-06-21 02:13:48 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 612447975214690305,
  "created_at" : "2015-06-21 02:32:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "612438470779277312",
  "text" : "RT @POTUS: Expressions of sympathy aren\u2019t enough. It\u2019s time we do something about this.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "612437042207834112",
    "geo" : { },
    "id_str" : "612437278019973120",
    "in_reply_to_user_id" : 1536791610,
    "text" : "Expressions of sympathy aren\u2019t enough. It\u2019s time we do something about this.",
    "id" : 612437278019973120,
    "in_reply_to_status_id" : 612437042207834112,
    "created_at" : "2015-06-21 01:50:00 +0000",
    "in_reply_to_screen_name" : "POTUS",
    "in_reply_to_user_id_str" : "1536791610",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 612438470779277312,
  "created_at" : "2015-06-21 01:54:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "612438328143560704",
  "text" : "RT @POTUS: Here are the stats: Per population, we kill each other with guns at a rate 297x more than Japan, 49x more than France, 33x more \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "612437042207834112",
    "text" : "Here are the stats: Per population, we kill each other with guns at a rate 297x more than Japan, 49x more than France, 33x more than Israel.",
    "id" : 612437042207834112,
    "created_at" : "2015-06-21 01:49:04 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 612438328143560704,
  "created_at" : "2015-06-21 01:54:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/Ryusfp8Xbh",
      "expanded_url" : "https:\/\/www.twitter.com\/MittRomney\/status\/612276050182049792",
      "display_url" : "twitter.com\/MittRomney\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "612433652534804480",
  "text" : "RT @POTUS: Good point, Mitt. https:\/\/t.co\/Ryusfp8Xbh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 18, 41 ],
        "url" : "https:\/\/t.co\/Ryusfp8Xbh",
        "expanded_url" : "https:\/\/www.twitter.com\/MittRomney\/status\/612276050182049792",
        "display_url" : "twitter.com\/MittRomney\/sta\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "612433183297142784",
    "text" : "Good point, Mitt. https:\/\/t.co\/Ryusfp8Xbh",
    "id" : 612433183297142784,
    "created_at" : "2015-06-21 01:33:44 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 612433652534804480,
  "created_at" : "2015-06-21 01:35:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/f1BG02MGvt",
      "expanded_url" : "https:\/\/twitter.com\/ezraklein\/status\/612266225821982720",
      "display_url" : "twitter.com\/ezraklein\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "612405147809902592",
  "text" : "RT @vj44: This is not about politics. It's about the need for better policy choices. https:\/\/t.co\/f1BG02MGvt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 98 ],
        "url" : "https:\/\/t.co\/f1BG02MGvt",
        "expanded_url" : "https:\/\/twitter.com\/ezraklein\/status\/612266225821982720",
        "display_url" : "twitter.com\/ezraklein\/stat\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "612401086108954625",
    "text" : "This is not about politics. It's about the need for better policy choices. https:\/\/t.co\/f1BG02MGvt",
    "id" : 612401086108954625,
    "created_at" : "2015-06-20 23:26:11 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 612405147809902592,
  "created_at" : "2015-06-20 23:42:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 13, 19 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "612395950158405632",
  "text" : "RT @vj44: As @POTUS said, sympathy alone isn't good enough to honor the victims of gun violence in Charleston. Let's start a conversation.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 3, 9 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "612395445910962176",
    "text" : "As @POTUS said, sympathy alone isn't good enough to honor the victims of gun violence in Charleston. Let's start a conversation.",
    "id" : 612395445910962176,
    "created_at" : "2015-06-20 23:03:46 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 612395950158405632,
  "created_at" : "2015-06-20 23:05:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "612394486891593728",
  "text" : "RT @vj44: Racism and hate are horrible realities, made worse by the accessibility of guns in our nation. We have to change.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "612394353043087361",
    "text" : "Racism and hate are horrible realities, made worse by the accessibility of guns in our nation. We have to change.",
    "id" : 612394353043087361,
    "created_at" : "2015-06-20 22:59:26 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 612394486891593728,
  "created_at" : "2015-06-20 22:59:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PollinatorWeek",
      "indices" : [ 99, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/P50qJTDg26",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/d25e7c4c-369c-4ea5-a7e2-fcc4c52fb9b5",
      "display_url" : "amp.twimg.com\/v\/d25e7c4c-369\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "612347273654067200",
  "text" : "Bees? Find out what the buzz is about with this \uD83D\uDC1D-hind-the-scenes look at the White House beehive. #PollinatorWeek\nhttps:\/\/t.co\/P50qJTDg26",
  "id" : 612347273654067200,
  "created_at" : "2015-06-20 19:52:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 108, 114 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/T978CUK4RU",
      "expanded_url" : "http:\/\/go.wh.gov\/xw57m3",
      "display_url" : "go.wh.gov\/xw57m3"
    } ]
  },
  "geo" : { },
  "id_str" : "612326597220155392",
  "text" : "\"Over the past couple years, 17 states and 6 major cities have raised the minimum wage for their workers.\" \u2014@POTUS: http:\/\/t.co\/T978CUK4RU",
  "id" : 612326597220155392,
  "created_at" : "2015-06-20 18:30:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 90, 96 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/T978CUK4RU",
      "expanded_url" : "http:\/\/go.wh.gov\/xw57m3",
      "display_url" : "go.wh.gov\/xw57m3"
    } ]
  },
  "geo" : { },
  "id_str" : "612296397128216576",
  "text" : "\"I believe it\u2019s the right thing to do for American workers...or I wouldn\u2019t be doing it.\" \u2014@POTUS on his trade deal: http:\/\/t.co\/T978CUK4RU",
  "id" : 612296397128216576,
  "created_at" : "2015-06-20 16:30:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 50, 56 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LeadOnTrade",
      "indices" : [ 126, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/T978CV1Ggu",
      "expanded_url" : "http:\/\/go.wh.gov\/xw57m3",
      "display_url" : "go.wh.gov\/xw57m3"
    } ]
  },
  "geo" : { },
  "id_str" : "612278962312585216",
  "text" : "\"We should write those rules before China does.\" \u2014@POTUS on why Congress needs to pass his trade deal: http:\/\/t.co\/T978CV1Ggu #LeadOnTrade",
  "id" : 612278962312585216,
  "created_at" : "2015-06-20 15:20:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 50, 56 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/J0dvsEtLMz",
      "expanded_url" : "http:\/\/snpy.tv\/1L7LeiS",
      "display_url" : "snpy.tv\/1L7LeiS"
    } ]
  },
  "geo" : { },
  "id_str" : "612020604753936385",
  "text" : "\"It is not good enough simply to show sympathy.\" \u2014@POTUS on the need to take steps to reduce gun violence http:\/\/t.co\/J0dvsEtLMz",
  "id" : 612020604753936385,
  "created_at" : "2015-06-19 22:14:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 86, 92 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/612016522857480192\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/ms7tMrore3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CH5RwUpWwAALgqF.jpg",
      "id_str" : "612016489986703360",
      "id" : 612016489986703360,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CH5RwUpWwAALgqF.jpg",
      "sizes" : [ {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1500
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/ms7tMrore3"
    } ],
    "hashtags" : [ {
      "text" : "OpportunityForAll",
      "indices" : [ 93, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "612016522857480192",
  "text" : "\"We all want America to be a place where our zip code doesn\u2019t determine our destiny\" \u2014@POTUS #OpportunityForAll http:\/\/t.co\/ms7tMrore3",
  "id" : 612016522857480192,
  "created_at" : "2015-06-19 21:58:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 125, 131 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "612015474298212353",
  "text" : "RT @WHLive: \"I will not sign bills that seek to increase defense spending before addressing any of our needs here at home.\" \u2014@POTUS to the \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 113, 119 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "U.S. Mayors",
        "screen_name" : "usmayors",
        "indices" : [ 127, 136 ],
        "id_str" : "15012352",
        "id" : 15012352
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "612015435882565632",
    "text" : "\"I will not sign bills that seek to increase defense spending before addressing any of our needs here at home.\" \u2014@POTUS to the @USMayors",
    "id" : 612015435882565632,
    "created_at" : "2015-06-19 21:53:45 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 612015474298212353,
  "created_at" : "2015-06-19 21:53:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 47, 53 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "U.S. Mayors",
      "screen_name" : "usmayors",
      "indices" : [ 61, 70 ],
      "id_str" : "15012352",
      "id" : 15012352
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/612014951109033984\/photo\/1",
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/d4zG5nD7MK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CH5QPfHWcAApzh8.jpg",
      "id_str" : "612014826349555712",
      "id" : 612014826349555712,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CH5QPfHWcAApzh8.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/d4zG5nD7MK"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 86, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "612014951109033984",
  "text" : "\"It's science.\nIt's fact.\nIt's like gravity.\"\n\u2014@POTUS to the @USMayors on the need to #ActOnClimate http:\/\/t.co\/d4zG5nD7MK",
  "id" : 612014951109033984,
  "created_at" : "2015-06-19 21:51:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 119, 125 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RaiseTheWage",
      "indices" : [ 103, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "612013247210786816",
  "text" : "RT @WHLive: \"17 states have raised their minimum wage, and 27 cities and counties have taken action to #RaiseTheWage\" \u2014@POTUS http:\/\/t.co\/s\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 107, 113 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WHLive\/status\/612013222342692865\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/s1HYgaJxJm",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CH5OwgdWoAEAZHw.jpg",
        "id_str" : "612013194622705665",
        "id" : 612013194622705665,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CH5OwgdWoAEAZHw.jpg",
        "sizes" : [ {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/s1HYgaJxJm"
      } ],
      "hashtags" : [ {
        "text" : "RaiseTheWage",
        "indices" : [ 91, 104 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "612013222342692865",
    "text" : "\"17 states have raised their minimum wage, and 27 cities and counties have taken action to #RaiseTheWage\" \u2014@POTUS http:\/\/t.co\/s1HYgaJxJm",
    "id" : 612013222342692865,
    "created_at" : "2015-06-19 21:44:57 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 612013247210786816,
  "created_at" : "2015-06-19 21:45:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 113, 119 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "612013092772274176",
  "text" : "RT @WHLive: \"19 cities have enacted paid sick days, 5 states have enacted paid sick days or paid family leave.\" \u2014@POTUS http:\/\/t.co\/LIGfk1L\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 101, 107 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WHLive\/status\/612013067367362560\/photo\/1",
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/LIGfk1Lb2E",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CH5OoD9XAAAnuRa.jpg",
        "id_str" : "612013049533366272",
        "id" : 612013049533366272,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CH5OoD9XAAAnuRa.jpg",
        "sizes" : [ {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/LIGfk1Lb2E"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "612013067367362560",
    "text" : "\"19 cities have enacted paid sick days, 5 states have enacted paid sick days or paid family leave.\" \u2014@POTUS http:\/\/t.co\/LIGfk1Lb2E",
    "id" : 612013067367362560,
    "created_at" : "2015-06-19 21:44:20 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 612013092772274176,
  "created_at" : "2015-06-19 21:44:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 89, 95 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/612012890267230208\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/djLHi2rxRp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CH5Oc-QWEAAeRME.jpg",
      "id_str" : "612012859023822848",
      "id" : 612012859023822848,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CH5Oc-QWEAAeRME.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/djLHi2rxRp"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 96, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "612012890267230208",
  "text" : "\"More jobs creating more clean energy\u2014here in California, solar is growing like crazy.\" \u2014@POTUS #ActOnClimate http:\/\/t.co\/djLHi2rxRp",
  "id" : 612012890267230208,
  "created_at" : "2015-06-19 21:43:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 118, 124 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "612012115004538880",
  "text" : "\u201CWe as a people have got to change. That\u2019s how we honor those families. That\u2019s how we honor the families of Newtown\" \u2014@POTUS on gun violence",
  "id" : 612012115004538880,
  "created_at" : "2015-06-19 21:40:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 65, 71 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "612011336843661312",
  "text" : "\"At some point, as a country, we will have to reckon with this\" \u2014@POTUS on the need to reduce gun violence",
  "id" : 612011336843661312,
  "created_at" : "2015-06-19 21:37:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 73, 79 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "612010891064639488",
  "text" : "\"More than 11,000 Americans were killed by gun violence in 2013 alone.\" \u2014@POTUS",
  "id" : 612010891064639488,
  "created_at" : "2015-06-19 21:35:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 112, 118 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "612010794973315072",
  "text" : "\"It tears at the fabric of a community. It costs you money. It costs resources. It costs this country dearly.\" \u2014@POTUS on gun violence",
  "id" : 612010794973315072,
  "created_at" : "2015-06-19 21:35:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 87, 93 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "612010717596659712",
  "text" : "\"We need to step back and recognize\u2026these tragedies have become far too commonplace.\" \u2014@POTUS on the shooting in Charleston",
  "id" : 612010717596659712,
  "created_at" : "2015-06-19 21:35:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 115, 121 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "612010476151664640",
  "text" : "\"The apparent motivations of the shooter remind us that racism remains a blight that we have to combat together.\" \u2014@POTUS on Charleston",
  "id" : 612010476151664640,
  "created_at" : "2015-06-19 21:34:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 80, 86 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "612010378210381824",
  "text" : "RT @WHLive: \u201CThe nature of this attack\u2014in a place of worship\u2026adds to the pain\u201D \u2014@POTUS on the tragic shooting in Charleston",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 68, 74 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "612010341141098496",
    "text" : "\u201CThe nature of this attack\u2014in a place of worship\u2026adds to the pain\u201D \u2014@POTUS on the tragic shooting in Charleston",
    "id" : 612010341141098496,
    "created_at" : "2015-06-19 21:33:30 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 612010378210381824,
  "created_at" : "2015-06-19 21:33:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Mayors",
      "screen_name" : "usmayors",
      "indices" : [ 45, 54 ],
      "id_str" : "15012352",
      "id" : 15012352
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/in1rObRBZb",
      "expanded_url" : "http:\/\/go.wh.gov\/USMayors",
      "display_url" : "go.wh.gov\/USMayors"
    } ]
  },
  "geo" : { },
  "id_str" : "612009308176289793",
  "text" : "Happening now: President Obama speaks at the @USMayors annual meeting \u2192 http:\/\/t.co\/in1rObRBZb",
  "id" : 612009308176289793,
  "created_at" : "2015-06-19 21:29:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "611995134406868992",
  "text" : "RT @POTUS: In the midst of darkest tragedy, the decency and goodness of the American people shines through in these families. https:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 138 ],
        "url" : "https:\/\/t.co\/aYtAKrWwCY",
        "expanded_url" : "https:\/\/twitter.com\/ABC\/status\/611972235079741441",
        "display_url" : "twitter.com\/ABC\/status\/611\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "611993830980747265",
    "text" : "In the midst of darkest tragedy, the decency and goodness of the American people shines through in these families. https:\/\/t.co\/aYtAKrWwCY",
    "id" : 611993830980747265,
    "created_at" : "2015-06-19 20:27:54 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 611995134406868992,
  "created_at" : "2015-06-19 20:33:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/611985533808549888\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/CUQLfFu9f0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CH41eeiXAAAm8EJ.jpg",
      "id_str" : "611985397078491136",
      "id" : 611985397078491136,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CH41eeiXAAAm8EJ.jpg",
      "sizes" : [ {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      } ],
      "display_url" : "pic.twitter.com\/CUQLfFu9f0"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 104, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/xA1novsABn",
      "expanded_url" : "http:\/\/wpo.st\/bPIM0",
      "display_url" : "wpo.st\/bPIM0"
    } ]
  },
  "geo" : { },
  "id_str" : "611985533808549888",
  "text" : "The average American family is on pace to save about $700 at the pump this year. http:\/\/t.co\/xA1novsABn #ActOnClimate http:\/\/t.co\/CUQLfFu9f0",
  "id" : 611985533808549888,
  "created_at" : "2015-06-19 19:54:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "indices" : [ 3, 11 ],
      "id_str" : "1530850933",
      "id" : 1530850933
    }, {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "indices" : [ 64, 72 ],
      "id_str" : "2382117350",
      "id" : 2382117350
    }, {
      "name" : "Jason Furman",
      "screen_name" : "CEAChair",
      "indices" : [ 79, 88 ],
      "id_str" : "1861751828",
      "id" : 1861751828
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fueleconomy",
      "indices" : [ 29, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "611961860263313408",
  "text" : "RT @GinaEPA: We're proposing #fueleconomy standards for trucks. @Deese44 &amp; @CEAChair on how economy can benefit from efficiency: http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Brian Deese",
        "screen_name" : "Deese44",
        "indices" : [ 51, 59 ],
        "id_str" : "2382117350",
        "id" : 2382117350
      }, {
        "name" : "Jason Furman",
        "screen_name" : "CEAChair",
        "indices" : [ 66, 75 ],
        "id_str" : "1861751828",
        "id" : 1861751828
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "fueleconomy",
        "indices" : [ 16, 28 ]
      } ],
      "urls" : [ {
        "indices" : [ 120, 142 ],
        "url" : "http:\/\/t.co\/25OhTNP88y",
        "expanded_url" : "http:\/\/www.washingtonpost.com\/opinions\/the-boon-of-reduced-oil-consumption\/2015\/06\/18\/c02c43a4-146c-11e5-9ddc-e3353542100c_story.html",
        "display_url" : "washingtonpost.com\/opinions\/the-b\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "611912173208662016",
    "text" : "We're proposing #fueleconomy standards for trucks. @Deese44 &amp; @CEAChair on how economy can benefit from efficiency: http:\/\/t.co\/25OhTNP88y",
    "id" : 611912173208662016,
    "created_at" : "2015-06-19 15:03:25 +0000",
    "user" : {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "protected" : false,
      "id_str" : "1530850933",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/632229333130604548\/Bb4I34DU_normal.jpg",
      "id" : 1530850933,
      "verified" : true
    }
  },
  "id" : 611961860263313408,
  "created_at" : "2015-06-19 18:20:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/611941121401327616\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/3OZCdarZ9N",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CH4M2JdWoAAmg06.jpg",
      "id_str" : "611940723760472064",
      "id" : 611940723760472064,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CH4M2JdWoAAmg06.jpg",
      "sizes" : [ {
        "h" : 3065,
        "resize" : "fit",
        "w" : 2400
      }, {
        "h" : 766,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1308,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 434,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/3OZCdarZ9N"
    } ],
    "hashtags" : [ {
      "text" : "Juneteenth",
      "indices" : [ 101, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/HUSxUNVYrX",
      "expanded_url" : "http:\/\/go.wh.gov\/KLbcZh",
      "display_url" : "go.wh.gov\/KLbcZh"
    } ]
  },
  "geo" : { },
  "id_str" : "611941121401327616",
  "text" : "Today in 1865: The good news of the Emancipation Proclamation reached Texas \u2192 http:\/\/t.co\/HUSxUNVYrX #Juneteenth http:\/\/t.co\/3OZCdarZ9N",
  "id" : 611941121401327616,
  "created_at" : "2015-06-19 16:58:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 43, 49 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyBrothersKeeper",
      "indices" : [ 96, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/2wBsOmAo9k",
      "expanded_url" : "http:\/\/on.fb.me\/1H38zm4",
      "display_url" : "on.fb.me\/1H38zm4"
    }, {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/Wvkx8hMT6v",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/d9f6dd59-0d80-4950-8dc1-2762ca698a67",
      "display_url" : "amp.twimg.com\/v\/d9f6dd59-0d8\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "611927213865201664",
  "text" : "\"You matter.\nYou count.\nYou have talent.\"\n\u2014@POTUS to young men of color: http:\/\/t.co\/2wBsOmAo9k #MyBrothersKeeper\nhttps:\/\/t.co\/Wvkx8hMT6v",
  "id" : 611927213865201664,
  "created_at" : "2015-06-19 16:03:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Discovery",
      "screen_name" : "Discovery",
      "indices" : [ 3, 13 ],
      "id_str" : "17842366",
      "id" : 17842366
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyBrothersKeeper",
      "indices" : [ 78, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/lv1Tsj6WqB",
      "expanded_url" : "http:\/\/on.fb.me\/1H38zm4",
      "display_url" : "on.fb.me\/1H38zm4"
    } ]
  },
  "geo" : { },
  "id_str" : "611911364311826432",
  "text" : "RT @Discovery: Watch a special Facebook pre-premiere of 'Rise: The Promise of #MyBrothersKeeper', here&gt;&gt; http:\/\/t.co\/lv1Tsj6WqB http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Discovery\/status\/611881388128792576\/photo\/1",
        "indices" : [ 119, 141 ],
        "url" : "http:\/\/t.co\/k6cLWk18PB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CH3W4VBW8AA0keJ.jpg",
        "id_str" : "611881387596115968",
        "id" : 611881387596115968,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CH3W4VBW8AA0keJ.jpg",
        "sizes" : [ {
          "h" : 178,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 315,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 2947,
          "resize" : "fit",
          "w" : 5616
        }, {
          "h" : 537,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/k6cLWk18PB"
      } ],
      "hashtags" : [ {
        "text" : "MyBrothersKeeper",
        "indices" : [ 63, 80 ]
      } ],
      "urls" : [ {
        "indices" : [ 96, 118 ],
        "url" : "http:\/\/t.co\/lv1Tsj6WqB",
        "expanded_url" : "http:\/\/on.fb.me\/1H38zm4",
        "display_url" : "on.fb.me\/1H38zm4"
      } ]
    },
    "geo" : { },
    "id_str" : "611881388128792576",
    "text" : "Watch a special Facebook pre-premiere of 'Rise: The Promise of #MyBrothersKeeper', here&gt;&gt; http:\/\/t.co\/lv1Tsj6WqB http:\/\/t.co\/k6cLWk18PB",
    "id" : 611881388128792576,
    "created_at" : "2015-06-19 13:01:05 +0000",
    "user" : {
      "name" : "Discovery",
      "screen_name" : "Discovery",
      "protected" : false,
      "id_str" : "17842366",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/784405499907338240\/dy4uhXa7_normal.jpg",
      "id" : 17842366,
      "verified" : true
    }
  },
  "id" : 611911364311826432,
  "created_at" : "2015-06-19 15:00:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "611893982365265921",
  "text" : "RT @FLOTUS: \u201CSimply saying our thoughts and prayers are with you is not enough. We've seen too many tragedies like this.\u201D \u2014The First Lady o\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Charleston",
        "indices" : [ 129, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "611893725849980931",
    "text" : "\u201CSimply saying our thoughts and prayers are with you is not enough. We've seen too many tragedies like this.\u201D \u2014The First Lady on #Charleston",
    "id" : 611893725849980931,
    "created_at" : "2015-06-19 13:50:07 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 611893982365265921,
  "created_at" : "2015-06-19 13:51:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Treasury Department",
      "screen_name" : "USTreasury",
      "indices" : [ 30, 41 ],
      "id_str" : "120176950",
      "id" : 120176950
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TheNew10",
      "indices" : [ 99, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "611706818574843908",
  "text" : "RT @vj44: Truly historic that @USTreasury will put a woman on the $10 bill! Share your ideas using #TheNew10",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Treasury Department",
        "screen_name" : "USTreasury",
        "indices" : [ 20, 31 ],
        "id_str" : "120176950",
        "id" : 120176950
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TheNew10",
        "indices" : [ 89, 98 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "611706357088186369",
    "text" : "Truly historic that @USTreasury will put a woman on the $10 bill! Share your ideas using #TheNew10",
    "id" : 611706357088186369,
    "created_at" : "2015-06-19 01:25:35 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 611706818574843908,
  "created_at" : "2015-06-19 01:27:25 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "marc maron",
      "screen_name" : "marcmaron",
      "indices" : [ 3, 13 ],
      "id_str" : "21718006",
      "id" : 21718006
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 23, 29 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "WTF with Marc Maron",
      "screen_name" : "WTFpod",
      "indices" : [ 97, 104 ],
      "id_str" : "69406730",
      "id" : 69406730
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "611697016389775360",
  "text" : "RT @marcmaron: Honored @POTUS is visiting the garage tomorrow. Hear the conversation on Monday's @wtfpod. Available on iTunes &amp; the WTF app.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 8, 14 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "WTF with Marc Maron",
        "screen_name" : "WTFpod",
        "indices" : [ 82, 89 ],
        "id_str" : "69406730",
        "id" : 69406730
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "611640665479344128",
    "text" : "Honored @POTUS is visiting the garage tomorrow. Hear the conversation on Monday's @wtfpod. Available on iTunes &amp; the WTF app.",
    "id" : 611640665479344128,
    "created_at" : "2015-06-18 21:04:33 +0000",
    "user" : {
      "name" : "marc maron",
      "screen_name" : "marcmaron",
      "protected" : false,
      "id_str" : "21718006",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/678971145\/63226917-2_normal.jpg",
      "id" : 21718006,
      "verified" : true
    }
  },
  "id" : 611697016389775360,
  "created_at" : "2015-06-19 00:48:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Pope Francis",
      "screen_name" : "Pontifex",
      "indices" : [ 28, 37 ],
      "id_str" : "500704345",
      "id" : 500704345
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "611675859724992512",
  "text" : "RT @POTUS: Inspired by what @Pontifex wrote on climate change. Agree we have a moral responsibility to act to protect our kids and God's cr\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Pope Francis",
        "screen_name" : "Pontifex",
        "indices" : [ 17, 26 ],
        "id_str" : "500704345",
        "id" : 500704345
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "611675003436843008",
    "text" : "Inspired by what @Pontifex wrote on climate change. Agree we have a moral responsibility to act to protect our kids and God's creation.",
    "id" : 611675003436843008,
    "created_at" : "2015-06-18 23:20:59 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 611675859724992512,
  "created_at" : "2015-06-18 23:24:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 14, 20 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Pope Francis",
      "screen_name" : "Pontifex",
      "indices" : [ 24, 33 ],
      "id_str" : "500704345",
      "id" : 500704345
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/611661681517658112\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/GvSwpMZGLH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CH0O5DEWgAEjkne.jpg",
      "id_str" : "611661497631145985",
      "id" : 611661497631145985,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CH0O5DEWgAEjkne.jpg",
      "sizes" : [ {
        "h" : 891,
        "resize" : "fit",
        "w" : 1100
      }, {
        "h" : 486,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 275,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 829,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/GvSwpMZGLH"
    } ],
    "hashtags" : [ {
      "text" : "LaudatoSi",
      "indices" : [ 104, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/I2pobA03WE",
      "expanded_url" : "http:\/\/go.wh.gov\/Encyclical",
      "display_url" : "go.wh.gov\/Encyclical"
    } ]
  },
  "geo" : { },
  "id_str" : "611661681517658112",
  "text" : "Worth a read: @POTUS on @Pontifex's encyclical urging action on climate change \u2192 http:\/\/t.co\/I2pobA03WE #LaudatoSi http:\/\/t.co\/GvSwpMZGLH",
  "id" : 611661681517658112,
  "created_at" : "2015-06-18 22:28:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pope Francis",
      "screen_name" : "Pontifex",
      "indices" : [ 3, 12 ],
      "id_str" : "500704345",
      "id" : 500704345
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LaudatoSi",
      "indices" : [ 100, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "611640736115634176",
  "text" : "RT @Pontifex: Climate change represents one of the principal challenges facing humanity in our day. #LaudatoSi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LaudatoSi",
        "indices" : [ 86, 96 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "611513712206196736",
    "text" : "Climate change represents one of the principal challenges facing humanity in our day. #LaudatoSi",
    "id" : 611513712206196736,
    "created_at" : "2015-06-18 12:40:05 +0000",
    "user" : {
      "name" : "Pope Francis",
      "screen_name" : "Pontifex",
      "protected" : false,
      "id_str" : "500704345",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/507818066814590976\/KNG-IkT9_normal.jpeg",
      "id" : 500704345,
      "verified" : true
    }
  },
  "id" : 611640736115634176,
  "created_at" : "2015-06-18 21:04:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 52, 58 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Pope Francis",
      "screen_name" : "Pontifex",
      "indices" : [ 62, 71 ],
      "id_str" : "500704345",
      "id" : 500704345
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/611632933066027008\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/u6rKUpUVd9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHz0zLaWUAAX8Gp.jpg",
      "id_str" : "611632809489354752",
      "id" : 611632809489354752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHz0zLaWUAAX8Gp.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/u6rKUpUVd9"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 91, 104 ]
    }, {
      "text" : "LaudatoSi",
      "indices" : [ 106, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "611632933066027008",
  "text" : "\"I welcome His Holiness Pope Francis's encyclical\" \u2014@POTUS on @Pontifex making the case to #ActOnClimate. #LaudatoSi http:\/\/t.co\/u6rKUpUVd9",
  "id" : 611632933066027008,
  "created_at" : "2015-06-18 20:33:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CharlestonShooting",
      "indices" : [ 78, 97 ]
    } ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/fRxy3VzRuG",
      "expanded_url" : "https:\/\/www.whitehouse.gov\/the-press-office\/2015\/06\/18\/statement-vice-president-biden-and-dr-jill-biden-shooting-charleston",
      "display_url" : "whitehouse.gov\/the-press-offi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "611623822991626240",
  "text" : "RT @VP: We must confront the ravages of gun violence and the stain of hatred. #CharlestonShooting https:\/\/t.co\/fRxy3VzRuG http:\/\/t.co\/5qbem\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/611618290390056961\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/5qbemkgBMc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHznl_uUAAAHQu4.jpg",
        "id_str" : "611618289362403328",
        "id" : 611618289362403328,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHznl_uUAAAHQu4.jpg",
        "sizes" : [ {
          "h" : 462,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 842,
          "resize" : "fit",
          "w" : 619
        }, {
          "h" : 816,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 842,
          "resize" : "fit",
          "w" : 619
        } ],
        "display_url" : "pic.twitter.com\/5qbemkgBMc"
      } ],
      "hashtags" : [ {
        "text" : "CharlestonShooting",
        "indices" : [ 70, 89 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/fRxy3VzRuG",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/the-press-office\/2015\/06\/18\/statement-vice-president-biden-and-dr-jill-biden-shooting-charleston",
        "display_url" : "whitehouse.gov\/the-press-offi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "611618290390056961",
    "text" : "We must confront the ravages of gun violence and the stain of hatred. #CharlestonShooting https:\/\/t.co\/fRxy3VzRuG http:\/\/t.co\/5qbemkgBMc",
    "id" : 611618290390056961,
    "created_at" : "2015-06-18 19:35:38 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 611623822991626240,
  "created_at" : "2015-06-18 19:57:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 75, 81 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/611609300222349312\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/yN8pdsO6u9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHze53BWcAA5aAm.jpg",
      "id_str" : "611608735019069440",
      "id" : 611608735019069440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHze53BWcAA5aAm.jpg",
      "sizes" : [ {
        "h" : 401,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1869,
        "resize" : "fit",
        "w" : 2800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 684,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/yN8pdsO6u9"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/vD4Nk8bbO1",
      "expanded_url" : "http:\/\/go.wh.gov\/nuQktp",
      "display_url" : "go.wh.gov\/nuQktp"
    } ]
  },
  "geo" : { },
  "id_str" : "611609300222349312",
  "text" : "\"This type of mass violence does not happen in other advanced countries.\" \u2014@POTUS: http:\/\/t.co\/vD4Nk8bbO1 http:\/\/t.co\/yN8pdsO6u9",
  "id" : 611609300222349312,
  "created_at" : "2015-06-18 18:59:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CharlestonShooting",
      "indices" : [ 60, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/LkxrbDmWQQ",
      "expanded_url" : "http:\/\/snpy.tv\/1CftWZT",
      "display_url" : "snpy.tv\/1CftWZT"
    } ]
  },
  "geo" : { },
  "id_str" : "611572028475371521",
  "text" : "Full video: Watch President Obama's statement on the tragic #CharlestonShooting. http:\/\/t.co\/LkxrbDmWQQ",
  "id" : 611572028475371521,
  "created_at" : "2015-06-18 16:31:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 102, 108 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "611571238238982144",
  "text" : "\"With our prayers, our love, and the buoyancy of hope, it will rise again now, as a place of peace.\" \u2014@POTUS on Emanuel AME Church",
  "id" : 611571238238982144,
  "created_at" : "2015-06-18 16:28:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 130, 136 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "611570520069279745",
  "text" : "\"We as a country will have to reckon with the fact that this type of mass violence does not happen in other advanced countries.\" \u2014@POTUS",
  "id" : 611570520069279745,
  "created_at" : "2015-06-18 16:25:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 127, 133 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "611570359309987840",
  "text" : "\"Innocent people were killed in part because someone who wanted to inflict harm had no trouble getting their hands on a gun.\" \u2014@POTUS",
  "id" : 611570359309987840,
  "created_at" : "2015-06-18 16:25:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 134, 140 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "611570206230470656",
  "text" : "\"I\u2019ve had to make statements like these too many times. Communities like this have had to endure tragedies like this too many times\" \u2014@POTUS",
  "id" : 611570206230470656,
  "created_at" : "2015-06-18 16:24:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 142, 148 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "611569565634572288",
  "text" : "\"To say our thoughts and prayers are with them...doesn\u2019t say enough to convey the heartache &amp; the sadness &amp; the anger that we feel.\" \u2014@POTUS",
  "id" : 611569565634572288,
  "created_at" : "2015-06-18 16:22:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CharlestonShooting",
      "indices" : [ 59, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/uMhKzduKOG",
      "expanded_url" : "http:\/\/go.wh.gov\/K5goiK",
      "display_url" : "go.wh.gov\/K5goiK"
    } ]
  },
  "geo" : { },
  "id_str" : "611569256518549504",
  "text" : "Happening now: President Obama delivers a statement on the #CharlestonShooting \u2192 http:\/\/t.co\/uMhKzduKOG",
  "id" : 611569256518549504,
  "created_at" : "2015-06-18 16:20:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/uMhKzdMlGe",
      "expanded_url" : "http:\/\/go.wh.gov\/K5goiK",
      "display_url" : "go.wh.gov\/K5goiK"
    } ]
  },
  "geo" : { },
  "id_str" : "611552740141957120",
  "text" : "At 11:45am ET, President Obama will deliver a statement from the Briefing Room on the shooting in South Carolina \u2192 http:\/\/t.co\/uMhKzdMlGe",
  "id" : 611552740141957120,
  "created_at" : "2015-06-18 15:15:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GoldenStateWarriors",
      "screen_name" : "warriors",
      "indices" : [ 66, 75 ],
      "id_str" : "26270913",
      "id" : 26270913
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/611370175590350848\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/Ob3S4yczS8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHwF2qQWIAAU9D_.jpg",
      "id_str" : "611370086029467648",
      "id" : 611370086029467648,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHwF2qQWIAAU9D_.jpg",
      "sizes" : [ {
        "h" : 1867,
        "resize" : "fit",
        "w" : 2800
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Ob3S4yczS8"
    } ],
    "hashtags" : [ {
      "text" : "DubNation",
      "indices" : [ 103, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "611370175590350848",
  "text" : "President Obama called coach Steve Kerr today to congratulate the @Warriors on winning the NBA Finals. #DubNation http:\/\/t.co\/Ob3S4yczS8",
  "id" : 611370175590350848,
  "created_at" : "2015-06-18 03:09:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 44, 50 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/611319957805096960\/photo\/1",
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/d3fwJoC4cf",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHvX8NUWcAE5oNv.png",
      "id_str" : "611319603805974529",
      "id" : 611319603805974529,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHvX8NUWcAE5oNv.png",
      "sizes" : [ {
        "h" : 690,
        "resize" : "fit",
        "w" : 578
      }, {
        "h" : 406,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 690,
        "resize" : "fit",
        "w" : 578
      }, {
        "h" : 690,
        "resize" : "fit",
        "w" : 578
      } ],
      "display_url" : "pic.twitter.com\/d3fwJoC4cf"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/vgX3yG7PI2",
      "expanded_url" : "http:\/\/go.wh.gov\/fzQ878",
      "display_url" : "go.wh.gov\/fzQ878"
    } ]
  },
  "geo" : { },
  "id_str" : "611319957805096960",
  "text" : "\"From my family to yours, Ramadan Kareem.\" \u2014@POTUS on the occasion of Ramadan: http:\/\/t.co\/vgX3yG7PI2 http:\/\/t.co\/d3fwJoC4cf",
  "id" : 611319957805096960,
  "created_at" : "2015-06-17 23:50:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/611265944548188160\/photo\/1",
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/u8TIti8LZV",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHumy9MWEAEfYGS.jpg",
      "id_str" : "611265568788844545",
      "id" : 611265568788844545,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHumy9MWEAEfYGS.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1667,
        "resize" : "fit",
        "w" : 2500
      } ],
      "display_url" : "pic.twitter.com\/u8TIti8LZV"
    } ],
    "hashtags" : [ {
      "text" : "StatueOfLiberty",
      "indices" : [ 25, 41 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/ZyOqlcCBdP",
      "expanded_url" : "http:\/\/go.wh.gov\/StatueOfLiberty",
      "display_url" : "go.wh.gov\/StatueOfLiberty"
    } ]
  },
  "geo" : { },
  "id_str" : "611265944548188160",
  "text" : "130 years ago today, the #StatueOfLiberty came to America \u2192 http:\/\/t.co\/ZyOqlcCBdP http:\/\/t.co\/u8TIti8LZV",
  "id" : 611265944548188160,
  "created_at" : "2015-06-17 20:15:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    }, {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 35, 43 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/VP\/status\/611255300964814848\/photo\/1",
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/Wa4COLcoNr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHuddMyUwAANqNk.jpg",
      "id_str" : "611255299412901888",
      "id" : 611255299412901888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHuddMyUwAANqNk.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 2400,
        "resize" : "fit",
        "w" : 3600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Wa4COLcoNr"
    } ],
    "hashtags" : [ {
      "text" : "38Years",
      "indices" : [ 45, 53 ]
    }, {
      "text" : "AndCounting",
      "indices" : [ 54, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "611256642856951808",
  "text" : "RT @VP: Happy wedding anniversary, @DrBiden. #38Years #AndCounting http:\/\/t.co\/Wa4COLcoNr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dr. Jill Biden",
        "screen_name" : "DrBiden",
        "indices" : [ 27, 35 ],
        "id_str" : "1281405877",
        "id" : 1281405877
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/611255300964814848\/photo\/1",
        "indices" : [ 59, 81 ],
        "url" : "http:\/\/t.co\/Wa4COLcoNr",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHuddMyUwAANqNk.jpg",
        "id_str" : "611255299412901888",
        "id" : 611255299412901888,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHuddMyUwAANqNk.jpg",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 2400,
          "resize" : "fit",
          "w" : 3600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/Wa4COLcoNr"
      } ],
      "hashtags" : [ {
        "text" : "38Years",
        "indices" : [ 37, 45 ]
      }, {
        "text" : "AndCounting",
        "indices" : [ 46, 58 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "611255300964814848",
    "text" : "Happy wedding anniversary, @DrBiden. #38Years #AndCounting http:\/\/t.co\/Wa4COLcoNr",
    "id" : 611255300964814848,
    "created_at" : "2015-06-17 19:33:14 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 611256642856951808,
  "created_at" : "2015-06-17 19:38:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "indices" : [ 3, 11 ],
      "id_str" : "1530850933",
      "id" : 1530850933
    }, {
      "name" : "Medium",
      "screen_name" : "Medium",
      "indices" : [ 41, 48 ],
      "id_str" : "571202103",
      "id" : 571202103
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 92, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "611238926112718848",
  "text" : "RT @GinaEPA: Just wrote my first post on @Medium - on how we strengthen our economy when we #ActOnClimate. Check it out: https:\/\/t.co\/26lfG\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Medium",
        "screen_name" : "Medium",
        "indices" : [ 28, 35 ],
        "id_str" : "571202103",
        "id" : 571202103
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 79, 92 ]
      } ],
      "urls" : [ {
        "indices" : [ 108, 131 ],
        "url" : "https:\/\/t.co\/26lfGJfM5R",
        "expanded_url" : "https:\/\/medium.com\/@GinaEPA\/the-economic-case-for-fighting-climate-change-fa6da3ef5e1e",
        "display_url" : "medium.com\/@GinaEPA\/the-e\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "611194021097144320",
    "text" : "Just wrote my first post on @Medium - on how we strengthen our economy when we #ActOnClimate. Check it out: https:\/\/t.co\/26lfGJfM5R",
    "id" : 611194021097144320,
    "created_at" : "2015-06-17 15:29:44 +0000",
    "user" : {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "protected" : false,
      "id_str" : "1530850933",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/632229333130604548\/Bb4I34DU_normal.jpg",
      "id" : 1530850933,
      "verified" : true
    }
  },
  "id" : 611238926112718848,
  "created_at" : "2015-06-17 18:28:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "AG Loretta Lynch",
      "screen_name" : "LorettaLynch",
      "indices" : [ 42, 55 ],
      "id_str" : "3290070855",
      "id" : 3290070855
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "611229069284392960",
  "text" : "RT @POTUS: Thrilled to formally recognize @LorettaLynch as the people's lawyer. You'll have no better partner in the fight for equality and\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "AG Loretta Lynch",
        "screen_name" : "LorettaLynch",
        "indices" : [ 31, 44 ],
        "id_str" : "3290070855",
        "id" : 3290070855
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "611227969030328321",
    "text" : "Thrilled to formally recognize @LorettaLynch as the people's lawyer. You'll have no better partner in the fight for equality and justice.",
    "id" : 611227969030328321,
    "created_at" : "2015-06-17 17:44:38 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 611229069284392960,
  "created_at" : "2015-06-17 17:49:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AG Loretta Lynch",
      "screen_name" : "LorettaLynch",
      "indices" : [ 3, 16 ],
      "id_str" : "3290070855",
      "id" : 3290070855
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 28, 34 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Justice Department",
      "screen_name" : "TheJusticeDept",
      "indices" : [ 108, 123 ],
      "id_str" : "73181712",
      "id" : 73181712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "611217795821342721",
  "text" : "RT @LorettaLynch: Thank you @POTUS and Justice Sotomayor. It's a privilege to serve as Attorney General for @TheJusticeDept. http:\/\/t.co\/Ln\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 10, 16 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "Justice Department",
        "screen_name" : "TheJusticeDept",
        "indices" : [ 90, 105 ],
        "id_str" : "73181712",
        "id" : 73181712
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/LorettaLynch\/status\/611215584290828289\/photo\/1",
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/LnQodDNd2l",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHt5VSrUEAAqofG.jpg",
        "id_str" : "611215581136556032",
        "id" : 611215581136556032,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHt5VSrUEAAqofG.jpg",
        "sizes" : [ {
          "h" : 228,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 402,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 685,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 2592,
          "resize" : "fit",
          "w" : 3872
        } ],
        "display_url" : "pic.twitter.com\/LnQodDNd2l"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "611215584290828289",
    "text" : "Thank you @POTUS and Justice Sotomayor. It's a privilege to serve as Attorney General for @TheJusticeDept. http:\/\/t.co\/LnQodDNd2l",
    "id" : 611215584290828289,
    "created_at" : "2015-06-17 16:55:25 +0000",
    "user" : {
      "name" : "AG Loretta Lynch",
      "screen_name" : "LorettaLynch",
      "protected" : false,
      "id_str" : "3290070855",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/657296962052468736\/BBNYJ8rH_normal.jpg",
      "id" : 3290070855,
      "verified" : true
    }
  },
  "id" : 611217795821342721,
  "created_at" : "2015-06-17 17:04:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "AG Loretta Lynch",
      "screen_name" : "LorettaLynch",
      "indices" : [ 11, 24 ],
      "id_str" : "3290070855",
      "id" : 3290070855
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "611208099291115521",
  "text" : "RT @vj44: .@LorettaLynch is installed as the Attorney General, leading a department she calls \"the conscience of this nation\". http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "AG Loretta Lynch",
        "screen_name" : "LorettaLynch",
        "indices" : [ 1, 14 ],
        "id_str" : "3290070855",
        "id" : 3290070855
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/611196917180076033\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/Kta7UtYjb1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHtoUqRWUAA0nVy.jpg",
        "id_str" : "611196878592561152",
        "id" : 611196878592561152,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHtoUqRWUAA0nVy.jpg",
        "sizes" : [ {
          "h" : 527,
          "resize" : "fit",
          "w" : 728
        }, {
          "h" : 246,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 434,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 527,
          "resize" : "fit",
          "w" : 728
        } ],
        "display_url" : "pic.twitter.com\/Kta7UtYjb1"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "611196917180076033",
    "text" : ".@LorettaLynch is installed as the Attorney General, leading a department she calls \"the conscience of this nation\". http:\/\/t.co\/Kta7UtYjb1",
    "id" : 611196917180076033,
    "created_at" : "2015-06-17 15:41:15 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 611208099291115521,
  "created_at" : "2015-06-17 16:25:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 106, 112 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "AG Loretta Lynch",
      "screen_name" : "LorettaLynch",
      "indices" : [ 116, 129 ],
      "id_str" : "3290070855",
      "id" : 3290070855
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "611194174256377858",
  "text" : "\"The law is her map.\nJustice, her compass.\nShe is tough, but she is fair.\nShe is firm, but she is kind.\"\n\u2014@POTUS on @LorettaLynch",
  "id" : 611194174256377858,
  "created_at" : "2015-06-17 15:30:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 104, 110 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "AG Loretta Lynch",
      "screen_name" : "LorettaLynch",
      "indices" : [ 114, 127 ],
      "id_str" : "3290070855",
      "id" : 3290070855
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "611193505143259136",
  "text" : "\"No matter what our circumstances, we all have the power to make a difference in the lives of others.\" \u2014@POTUS on @LorettaLynch's upbringing",
  "id" : 611193505143259136,
  "created_at" : "2015-06-17 15:27:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 103, 109 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "611193150015672320",
  "text" : "\"Justice is not an abstraction. It\u2019s a very real and tangible way that our laws interact with people\" \u2014@POTUS on Eric Holder's tenure as AG",
  "id" : 611193150015672320,
  "created_at" : "2015-06-17 15:26:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AG Loretta Lynch",
      "screen_name" : "LorettaLynch",
      "indices" : [ 97, 110 ],
      "id_str" : "3290070855",
      "id" : 3290070855
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 114, 120 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "611192609634156544",
  "text" : "\"I\u2019m so proud to be here for the installation of our 83rd Attorney General of the United States, @LorettaLynch.\" \u2014@POTUS",
  "id" : 611192609634156544,
  "created_at" : "2015-06-17 15:24:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "AG Loretta Lynch",
      "screen_name" : "LorettaLynch",
      "indices" : [ 95, 108 ],
      "id_str" : "3290070855",
      "id" : 3290070855
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/DLmiQss9mZ",
      "expanded_url" : "http:\/\/go.wh.gov\/CAd47L",
      "display_url" : "go.wh.gov\/CAd47L"
    } ]
  },
  "geo" : { },
  "id_str" : "611192496715010048",
  "text" : "RT @WHLive: Watch live: President Obama speaks at an investiture ceremony for Attorney General @LorettaLynch \u2192 http:\/\/t.co\/DLmiQss9mZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "AG Loretta Lynch",
        "screen_name" : "LorettaLynch",
        "indices" : [ 83, 96 ],
        "id_str" : "3290070855",
        "id" : 3290070855
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/DLmiQss9mZ",
        "expanded_url" : "http:\/\/go.wh.gov\/CAd47L",
        "display_url" : "go.wh.gov\/CAd47L"
      } ]
    },
    "geo" : { },
    "id_str" : "611192460262408192",
    "text" : "Watch live: President Obama speaks at an investiture ceremony for Attorney General @LorettaLynch \u2192 http:\/\/t.co\/DLmiQss9mZ",
    "id" : 611192460262408192,
    "created_at" : "2015-06-17 15:23:32 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 611192496715010048,
  "created_at" : "2015-06-17 15:23:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AG Loretta Lynch",
      "screen_name" : "LorettaLynch",
      "indices" : [ 3, 16 ],
      "id_str" : "3290070855",
      "id" : 3290070855
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/CYxdVM5vJh",
      "expanded_url" : "https:\/\/twitter.com\/TheJusticeDept\/status\/611175628042321920",
      "display_url" : "twitter.com\/TheJusticeDept\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "611188591016955904",
  "text" : "RT @LorettaLynch: Honored to be using Frederick Douglass\u2019 Bible today. His life is an inspiration to me. https:\/\/t.co\/CYxdVM5vJh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/CYxdVM5vJh",
        "expanded_url" : "https:\/\/twitter.com\/TheJusticeDept\/status\/611175628042321920",
        "display_url" : "twitter.com\/TheJusticeDept\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "611178251143249920",
    "text" : "Honored to be using Frederick Douglass\u2019 Bible today. His life is an inspiration to me. https:\/\/t.co\/CYxdVM5vJh",
    "id" : 611178251143249920,
    "created_at" : "2015-06-17 14:27:04 +0000",
    "user" : {
      "name" : "AG Loretta Lynch",
      "screen_name" : "LorettaLynch",
      "protected" : false,
      "id_str" : "3290070855",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/657296962052468736\/BBNYJ8rH_normal.jpg",
      "id" : 3290070855,
      "verified" : true
    }
  },
  "id" : 611188591016955904,
  "created_at" : "2015-06-17 15:08:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AG Loretta Lynch",
      "screen_name" : "LorettaLynch",
      "indices" : [ 3, 16 ],
      "id_str" : "3290070855",
      "id" : 3290070855
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "611166333661782017",
  "text" : "RT @LorettaLynch: Hello, Twitter!  Excited to join the conversation and share updates with you. Busy and exciting first weeks as AG - now I\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "611165782710583297",
    "text" : "Hello, Twitter!  Excited to join the conversation and share updates with you. Busy and exciting first weeks as AG - now I'm joining Twitter.",
    "id" : 611165782710583297,
    "created_at" : "2015-06-17 13:37:32 +0000",
    "user" : {
      "name" : "AG Loretta Lynch",
      "screen_name" : "LorettaLynch",
      "protected" : false,
      "id_str" : "3290070855",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/657296962052468736\/BBNYJ8rH_normal.jpg",
      "id" : 3290070855,
      "verified" : true
    }
  },
  "id" : 611166333661782017,
  "created_at" : "2015-06-17 13:39:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "611026907799359488",
  "text" : "RT @POTUS: What a team win for the Warriors and an epic season for Steph. Kudos to LeBron and the Cavs for an unbelievable effort under adv\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "611026361491324929",
    "text" : "What a team win for the Warriors and an epic season for Steph. Kudos to LeBron and the Cavs for an unbelievable effort under adversity.",
    "id" : 611026361491324929,
    "created_at" : "2015-06-17 04:23:31 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 611026907799359488,
  "created_at" : "2015-06-17 04:25:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Soccer WNT",
      "screen_name" : "ussoccer_wnt",
      "indices" : [ 3, 16 ],
      "id_str" : "133448051",
      "id" : 133448051
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ussoccer_wnt\/status\/610987531186782208\/photo\/1",
      "indices" : [ 35, 57 ],
      "url" : "http:\/\/t.co\/ReQJYAJmbr",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHqp6xeVAAAOi_L.jpg",
      "id_str" : "610987526640173056",
      "id" : 610987526640173056,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHqp6xeVAAAOi_L.jpg",
      "sizes" : [ {
        "h" : 500,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ReQJYAJmbr"
    } ],
    "hashtags" : [ {
      "text" : "WonTheGroup",
      "indices" : [ 18, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "610990435654307841",
  "text" : "RT @ussoccer_wnt: #WonTheGroup \uD83D\uDE00\uD83C\uDDFA\uD83C\uDDF8 http:\/\/t.co\/ReQJYAJmbr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ussoccer_wnt\/status\/610987531186782208\/photo\/1",
        "indices" : [ 17, 39 ],
        "url" : "http:\/\/t.co\/ReQJYAJmbr",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHqp6xeVAAAOi_L.jpg",
        "id_str" : "610987526640173056",
        "id" : 610987526640173056,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHqp6xeVAAAOi_L.jpg",
        "sizes" : [ {
          "h" : 500,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/ReQJYAJmbr"
      } ],
      "hashtags" : [ {
        "text" : "WonTheGroup",
        "indices" : [ 0, 12 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "610987531186782208",
    "text" : "#WonTheGroup \uD83D\uDE00\uD83C\uDDFA\uD83C\uDDF8 http:\/\/t.co\/ReQJYAJmbr",
    "id" : 610987531186782208,
    "created_at" : "2015-06-17 01:49:13 +0000",
    "user" : {
      "name" : "U.S. Soccer WNT",
      "screen_name" : "ussoccer_wnt",
      "protected" : false,
      "id_str" : "133448051",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/704351258082091008\/xp8Z6Hwo_normal.jpg",
      "id" : 133448051,
      "verified" : true
    }
  },
  "id" : 610990435654307841,
  "created_at" : "2015-06-17 02:00:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 50, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 135 ],
      "url" : "https:\/\/t.co\/2gqKngowvE",
      "expanded_url" : "https:\/\/youtu.be\/_ZkBhD2F-Qk",
      "display_url" : "youtu.be\/_ZkBhD2F-Qk"
    } ]
  },
  "geo" : { },
  "id_str" : "610965669245530112",
  "text" : "These entrepreneurs are serious about the need to #ActOnClimate.\nWatch them show off the latest in clean tech \u2192 https:\/\/t.co\/2gqKngowvE",
  "id" : 610965669245530112,
  "created_at" : "2015-06-17 00:22:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alicia Seiger",
      "screen_name" : "aaseiger",
      "indices" : [ 3, 12 ],
      "id_str" : "44929789",
      "id" : 44929789
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 75, 86 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "actonclimate",
      "indices" : [ 118, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "610946094512541696",
  "text" : "RT @aaseiger: Biden brought the crowd to its feet with tears in their eyes @WhiteHouse clean energy investment summit #actonclimate http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 61, 72 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/aaseiger\/status\/610937905830301696\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/J6So52baSJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHp8vwWWwAEy-sw.jpg",
        "id_str" : "610937859336486913",
        "id" : 610937859336486913,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHp8vwWWwAEy-sw.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/J6So52baSJ"
      } ],
      "hashtags" : [ {
        "text" : "actonclimate",
        "indices" : [ 104, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "610937905830301696",
    "text" : "Biden brought the crowd to its feet with tears in their eyes @WhiteHouse clean energy investment summit #actonclimate http:\/\/t.co\/J6So52baSJ",
    "id" : 610937905830301696,
    "created_at" : "2015-06-16 22:32:02 +0000",
    "user" : {
      "name" : "Alicia Seiger",
      "screen_name" : "aaseiger",
      "protected" : false,
      "id_str" : "44929789",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/522231667553878016\/PgDY3JxU_normal.jpeg",
      "id" : 44929789,
      "verified" : false
    }
  },
  "id" : 610946094512541696,
  "created_at" : "2015-06-16 23:04:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/610920860686413825\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/Sor5i1N5FQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHptL2JWIAA5yS9.jpg",
      "id_str" : "610920749742825472",
      "id" : 610920749742825472,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHptL2JWIAA5yS9.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      } ],
      "display_url" : "pic.twitter.com\/Sor5i1N5FQ"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/1LoWwaktdk",
      "expanded_url" : "http:\/\/go.wh.gov\/M9XHtM",
      "display_url" : "go.wh.gov\/M9XHtM"
    } ]
  },
  "geo" : { },
  "id_str" : "610920860686413825",
  "text" : "Celebrate National Pollinator Week with photos and facts on the White House \uD83D\uDC1D bees \uD83D\uDC1D \u2192 http:\/\/t.co\/1LoWwaktdk http:\/\/t.co\/Sor5i1N5FQ",
  "id" : 610920860686413825,
  "created_at" : "2015-06-16 21:24:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UK Prime Minister",
      "screen_name" : "Number10gov",
      "indices" : [ 3, 15 ],
      "id_str" : "14224719",
      "id" : 14224719
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 37, 44 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LetGirlsLearn",
      "indices" : [ 45, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "610912908281708545",
  "text" : "RT @Number10gov: PM: I fully support @FLOTUS #LetGirlsLearn. It's shocking that more than 62 million girls globally are out of school\nhttps\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The First Lady",
        "screen_name" : "FLOTUS",
        "indices" : [ 20, 27 ],
        "id_str" : "1093090866",
        "id" : 1093090866
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LetGirlsLearn",
        "indices" : [ 28, 42 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/eY1w1I4HBe",
        "expanded_url" : "https:\/\/amp.twimg.com\/v\/574dabed-075a-42d8-8510-c564a1f1ef93",
        "display_url" : "amp.twimg.com\/v\/574dabed-075\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "610903255996960769",
    "text" : "PM: I fully support @FLOTUS #LetGirlsLearn. It's shocking that more than 62 million girls globally are out of school\nhttps:\/\/t.co\/eY1w1I4HBe",
    "id" : 610903255996960769,
    "created_at" : "2015-06-16 20:14:20 +0000",
    "user" : {
      "name" : "UK Prime Minister",
      "screen_name" : "Number10gov",
      "protected" : false,
      "id_str" : "14224719",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798111635206508544\/qPVyTQI-_normal.jpg",
      "id" : 14224719,
      "verified" : true
    }
  },
  "id" : 610912908281708545,
  "created_at" : "2015-06-16 20:52:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Broderick Johnson",
      "screen_name" : "Broderick44",
      "indices" : [ 3, 15 ],
      "id_str" : "3246838764",
      "id" : 3246838764
    }, {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 37, 45 ],
      "id_str" : "783214",
      "id" : 783214
    }, {
      "name" : "The Cabinet",
      "screen_name" : "Cabinet",
      "indices" : [ 105, 113 ],
      "id_str" : "1854981890",
      "id" : 1854981890
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MyBrothersKeeper",
      "indices" : [ 82, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "610908096299282432",
  "text" : "RT @Broderick44: I\u2019m excited to join @Twitter! Looking forward to great convos on #MyBrothersKeeper, the @Cabinet and maybe a little Michig\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Twitter",
        "screen_name" : "twitter",
        "indices" : [ 20, 28 ],
        "id_str" : "783214",
        "id" : 783214
      }, {
        "name" : "The Cabinet",
        "screen_name" : "Cabinet",
        "indices" : [ 88, 96 ],
        "id_str" : "1854981890",
        "id" : 1854981890
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MyBrothersKeeper",
        "indices" : [ 65, 82 ]
      }, {
        "text" : "GoBlue",
        "indices" : [ 133, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "610899884216987648",
    "text" : "I\u2019m excited to join @Twitter! Looking forward to great convos on #MyBrothersKeeper, the @Cabinet and maybe a little Michigan sports! #GoBlue",
    "id" : 610899884216987648,
    "created_at" : "2015-06-16 20:00:57 +0000",
    "user" : {
      "name" : "Broderick Johnson",
      "screen_name" : "Broderick44",
      "protected" : false,
      "id_str" : "3246838764",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/610850749086433280\/Y1iGefZo_normal.jpg",
      "id" : 3246838764,
      "verified" : true
    }
  },
  "id" : 610908096299282432,
  "created_at" : "2015-06-16 20:33:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 85, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/rTNaHarvuT",
      "expanded_url" : "https:\/\/www.whitehouse.gov\/live\/white-house-clean-energy-investment-summit",
      "display_url" : "whitehouse.gov\/live\/white-hou\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "610898730334576640",
  "text" : "RT @VP: \"America's energy future is in cleaner, cheaper renewable energy.\" -VP Biden #ActOnClimate https:\/\/t.co\/rTNaHarvuT http:\/\/t.co\/5LbA\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/VP\/status\/610897945194467329\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/5LbAriARGB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHpYcVrUYAMlaM_.jpg",
        "id_str" : "610897943340539907",
        "id" : 610897943340539907,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHpYcVrUYAMlaM_.jpg",
        "sizes" : [ {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/5LbAriARGB"
      } ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 77, 90 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/rTNaHarvuT",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/live\/white-house-clean-energy-investment-summit",
        "display_url" : "whitehouse.gov\/live\/white-hou\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "610897945194467329",
    "text" : "\"America's energy future is in cleaner, cheaper renewable energy.\" -VP Biden #ActOnClimate https:\/\/t.co\/rTNaHarvuT http:\/\/t.co\/5LbAriARGB",
    "id" : 610897945194467329,
    "created_at" : "2015-06-16 19:53:14 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 610898730334576640,
  "created_at" : "2015-06-16 19:56:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "610895180716060672",
  "text" : "RT @VP: \"By 2025 we expect to double fuel efficiency to 54.5 miles per gallon\u2014saving American families $1.7 trillion at the pump.\" -VP Biden",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "610894807267872768",
    "text" : "\"By 2025 we expect to double fuel efficiency to 54.5 miles per gallon\u2014saving American families $1.7 trillion at the pump.\" -VP Biden",
    "id" : 610894807267872768,
    "created_at" : "2015-06-16 19:40:46 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 610895180716060672,
  "created_at" : "2015-06-16 19:42:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 53, 59 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/610877933411037184\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/vISWHGKHZz",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHpGNzsW8AIGJHd.jpg",
      "id_str" : "610877902490628098",
      "id" : 610877902490628098,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHpGNzsW8AIGJHd.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/vISWHGKHZz"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 97, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/Y2UKhyyaZQ",
      "expanded_url" : "http:\/\/go.wh.gov\/R4FYBn",
      "display_url" : "go.wh.gov\/R4FYBn"
    } ]
  },
  "geo" : { },
  "id_str" : "610877933411037184",
  "text" : "We're generating 20 times more solar power than when @POTUS took office \u2192 http:\/\/t.co\/Y2UKhyyaZQ #ActOnClimate http:\/\/t.co\/vISWHGKHZz",
  "id" : 610877933411037184,
  "created_at" : "2015-06-16 18:33:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 61, 72 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Periscope",
      "indices" : [ 28, 38 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/MnzEe0M1Rz",
      "expanded_url" : "https:\/\/www.periscope.tv\/w\/aFBNujUyNDMwNDJ8MjQwNzUzNDH7pjJjgdrb3C4ietmonRZUd3jw5BHFoN1i5V724lQCrQ==",
      "display_url" : "periscope.tv\/w\/aFBNujUyNDMw\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "610855053503520768",
  "text" : "RT @whitehouseostp: LIVE on #Periscope: Come hang out by the @WhiteHouse beehive for pollinator week! \uD83D\uDC1D\uD83D\uDC1D\uD83D\uDC1D https:\/\/t.co\/MnzEe0M1Rz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/periscope.tv\" rel=\"nofollow\"\u003EPeriscope\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 41, 52 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Periscope",
        "indices" : [ 8, 18 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 109 ],
        "url" : "https:\/\/t.co\/MnzEe0M1Rz",
        "expanded_url" : "https:\/\/www.periscope.tv\/w\/aFBNujUyNDMwNDJ8MjQwNzUzNDH7pjJjgdrb3C4ietmonRZUd3jw5BHFoN1i5V724lQCrQ==",
        "display_url" : "periscope.tv\/w\/aFBNujUyNDMw\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "610854529798504450",
    "text" : "LIVE on #Periscope: Come hang out by the @WhiteHouse beehive for pollinator week! \uD83D\uDC1D\uD83D\uDC1D\uD83D\uDC1D https:\/\/t.co\/MnzEe0M1Rz",
    "id" : 610854529798504450,
    "created_at" : "2015-06-16 17:00:43 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 610855053503520768,
  "created_at" : "2015-06-16 17:02:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/610853770503651329\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/ttM1GvGpQK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHowJg9WgAAHyWE.jpg",
      "id_str" : "610853639486341120",
      "id" : 610853639486341120,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHowJg9WgAAHyWE.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ttM1GvGpQK"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 96, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/Y2UKhyPLRo",
      "expanded_url" : "http:\/\/go.wh.gov\/R4FYBn",
      "display_url" : "go.wh.gov\/R4FYBn"
    } ]
  },
  "geo" : { },
  "id_str" : "610853770503651329",
  "text" : "Chart of the week: We're generating more clean energy than ever before \u2192 http:\/\/t.co\/Y2UKhyPLRo #ActOnClimate http:\/\/t.co\/ttM1GvGpQK",
  "id" : 610853770503651329,
  "created_at" : "2015-06-16 16:57:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ben Affleck",
      "screen_name" : "BenAffleck",
      "indices" : [ 3, 14 ],
      "id_str" : "329746058",
      "id" : 329746058
    }, {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 26, 33 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LetGirlsLearn",
      "indices" : [ 38, 52 ]
    }, {
      "text" : "DRC",
      "indices" : [ 67, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "610832685393645568",
  "text" : "RT @BenAffleck: Thank you @FLOTUS for #LetGirlsLearn commitment in #DRC &amp; working with local orgs to close girls secondary edu gap. http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The First Lady",
        "screen_name" : "FLOTUS",
        "indices" : [ 10, 17 ],
        "id_str" : "1093090866",
        "id" : 1093090866
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LetGirlsLearn",
        "indices" : [ 22, 36 ]
      }, {
        "text" : "DRC",
        "indices" : [ 51, 55 ]
      } ],
      "urls" : [ {
        "indices" : [ 120, 142 ],
        "url" : "http:\/\/t.co\/XbSnxvtIct",
        "expanded_url" : "http:\/\/www.whitehouse.gov\/letgirlslearn",
        "display_url" : "whitehouse.gov\/letgirlslearn"
      } ]
    },
    "geo" : { },
    "id_str" : "610827439233736704",
    "text" : "Thank you @FLOTUS for #LetGirlsLearn commitment in #DRC &amp; working with local orgs to close girls secondary edu gap. http:\/\/t.co\/XbSnxvtIct",
    "id" : 610827439233736704,
    "created_at" : "2015-06-16 15:13:04 +0000",
    "user" : {
      "name" : "Ben Affleck",
      "screen_name" : "BenAffleck",
      "protected" : false,
      "id_str" : "329746058",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3782523511\/fc6c9a4523187aaf21d31c354f3a5638_normal.jpeg",
      "id" : 329746058,
      "verified" : true
    }
  },
  "id" : 610832685393645568,
  "created_at" : "2015-06-16 15:33:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 98, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/HhGCclppax",
      "expanded_url" : "https:\/\/www.whitehouse.gov\/blog\/2015\/06\/16\/mobilizing-4-billion-private-sector-support-homegrown-clean-energy-innovation",
      "display_url" : "whitehouse.gov\/blog\/2015\/06\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "610830112276258817",
  "text" : "RT @VP: $4 billion: That's the amount of private sector support announced today that aims to help #ActOnClimate \u2192 https:\/\/t.co\/HhGCclppax",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 90, 103 ]
      } ],
      "urls" : [ {
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/HhGCclppax",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/blog\/2015\/06\/16\/mobilizing-4-billion-private-sector-support-homegrown-clean-energy-innovation",
        "display_url" : "whitehouse.gov\/blog\/2015\/06\/1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "610828863610880000",
    "text" : "$4 billion: That's the amount of private sector support announced today that aims to help #ActOnClimate \u2192 https:\/\/t.co\/HhGCclppax",
    "id" : 610828863610880000,
    "created_at" : "2015-06-16 15:18:44 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 610830112276258817,
  "created_at" : "2015-06-16 15:23:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Chicago Blackhawks",
      "screen_name" : "NHLBlackhawks",
      "indices" : [ 35, 49 ],
      "id_str" : "14498484",
      "id" : 14498484
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "610820936044941313",
  "text" : "RT @POTUS: Congrats to my hometown @NHLBlackhawks on 3 titles in 6 years - we'll see you and The Cup at the White House!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Chicago Blackhawks",
        "screen_name" : "NHLBlackhawks",
        "indices" : [ 24, 38 ],
        "id_str" : "14498484",
        "id" : 14498484
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "610820023968514048",
    "text" : "Congrats to my hometown @NHLBlackhawks on 3 titles in 6 years - we'll see you and The Cup at the White House!",
    "id" : 610820023968514048,
    "created_at" : "2015-06-16 14:43:36 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 610820936044941313,
  "created_at" : "2015-06-16 14:47:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/610808465905156096\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/HiGXePBoO2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHoGIOXW8AAFFui.jpg",
      "id_str" : "610807437826912256",
      "id" : 610807437826912256,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHoGIOXW8AAFFui.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/HiGXePBoO2"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 99, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/0UnLOvAzl3",
      "expanded_url" : "http:\/\/go.wh.gov\/CleanEnergy",
      "display_url" : "go.wh.gov\/CleanEnergy"
    } ]
  },
  "geo" : { },
  "id_str" : "610808465905156096",
  "text" : "RT the news: We're announcing $4 billion in new clean energy  investments \u2192 http:\/\/t.co\/0UnLOvAzl3 #ActOnClimate http:\/\/t.co\/HiGXePBoO2",
  "id" : 610808465905156096,
  "created_at" : "2015-06-16 13:57:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "indices" : [ 3, 11 ],
      "id_str" : "2382117350",
      "id" : 2382117350
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 19, 30 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 118, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "610788684888059904",
  "text" : "RT @Deese44: Today @WhiteHouse we're announcing $4 billion in commitments to catalyze clean energy technologies &amp; #ActOnClimate https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 6, 17 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 105, 118 ]
      } ],
      "urls" : [ {
        "indices" : [ 119, 142 ],
        "url" : "https:\/\/t.co\/XO8fZorTz5",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/the-press-office\/2015\/06\/16\/fact-sheet-obama-administration-announces-more-4-billion-private-sector",
        "display_url" : "whitehouse.gov\/the-press-offi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "610784661258829824",
    "text" : "Today @WhiteHouse we're announcing $4 billion in commitments to catalyze clean energy technologies &amp; #ActOnClimate https:\/\/t.co\/XO8fZorTz5",
    "id" : 610784661258829824,
    "created_at" : "2015-06-16 12:23:05 +0000",
    "user" : {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "protected" : false,
      "id_str" : "2382117350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656551411145027584\/ArrSlGUP_normal.jpg",
      "id" : 2382117350,
      "verified" : true
    }
  },
  "id" : 610788684888059904,
  "created_at" : "2015-06-16 12:39:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "610785066810146816",
  "text" : "RT @FLOTUS: \u201CWith an education\u2026you all have everything you need to rise above all the noise and fulfill every last one of your dreams.\u201D \u2014Th\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "610761439381467136",
    "text" : "\u201CWith an education\u2026you all have everything you need to rise above all the noise and fulfill every last one of your dreams.\u201D \u2014The First Lady",
    "id" : 610761439381467136,
    "created_at" : "2015-06-16 10:50:49 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 610785066810146816,
  "created_at" : "2015-06-16 12:24:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Video",
      "screen_name" : "WHVideo",
      "indices" : [ 3, 11 ],
      "id_str" : "1378231782",
      "id" : 1378231782
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 37, 43 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 86, 91 ],
      "id_str" : "11348282",
      "id" : 11348282
    }, {
      "name" : "Jerry Penacoli",
      "screen_name" : "JerryPenacoli",
      "indices" : [ 107, 121 ],
      "id_str" : "23657085",
      "id" : 23657085
    }, {
      "name" : "ExtraTV",
      "screen_name" : "extratv",
      "indices" : [ 125, 133 ],
      "id_str" : "15676578",
      "id" : 15676578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "610610744606986240",
  "text" : "RT @WHVideo: Go behind-the-scenes w\/ @POTUS as he travels to Germany &amp; meets with @NASA astronauts and @JerryPenacoli of @extraTV https:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 24, 30 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "NASA",
        "screen_name" : "NASA",
        "indices" : [ 73, 78 ],
        "id_str" : "11348282",
        "id" : 11348282
      }, {
        "name" : "Jerry Penacoli",
        "screen_name" : "JerryPenacoli",
        "indices" : [ 94, 108 ],
        "id_str" : "23657085",
        "id" : 23657085
      }, {
        "name" : "ExtraTV",
        "screen_name" : "extratv",
        "indices" : [ 112, 120 ],
        "id_str" : "15676578",
        "id" : 15676578
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/Ee5FTjccUf",
        "expanded_url" : "https:\/\/youtu.be\/ejb4Uv-d1jc",
        "display_url" : "youtu.be\/ejb4Uv-d1jc"
      } ]
    },
    "geo" : { },
    "id_str" : "610538599054901249",
    "text" : "Go behind-the-scenes w\/ @POTUS as he travels to Germany &amp; meets with @NASA astronauts and @JerryPenacoli of @extraTV https:\/\/t.co\/Ee5FTjccUf",
    "id" : 610538599054901249,
    "created_at" : "2015-06-15 20:05:19 +0000",
    "user" : {
      "name" : "White House Video",
      "screen_name" : "WHVideo",
      "protected" : false,
      "id_str" : "1378231782",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3636216064\/e21f3204adfdbc85dafef197487218a0_normal.jpeg",
      "id" : 1378231782,
      "verified" : true
    }
  },
  "id" : 610610744606986240,
  "created_at" : "2015-06-16 00:52:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LetGirlsLearn",
      "indices" : [ 107, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "610606909100396545",
  "text" : "RT @FLOTUS: \u2708\uFE0F Wheels down! The First Lady just landed in the U.K. where she's continuing her work to help #LetGirlsLearn. \u2708\uFE0F http:\/\/t.co\/K\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/FLOTUS\/status\/610601469755064322\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/Kij3RHTxMA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHlEm0IW8AAfRQK.jpg",
        "id_str" : "610594658104832000",
        "id" : 610594658104832000,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHlEm0IW8AAfRQK.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/Kij3RHTxMA"
      } ],
      "hashtags" : [ {
        "text" : "LetGirlsLearn",
        "indices" : [ 95, 109 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "610601469755064322",
    "text" : "\u2708\uFE0F Wheels down! The First Lady just landed in the U.K. where she's continuing her work to help #LetGirlsLearn. \u2708\uFE0F http:\/\/t.co\/Kij3RHTxMA",
    "id" : 610601469755064322,
    "created_at" : "2015-06-16 00:15:09 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 610606909100396545,
  "created_at" : "2015-06-16 00:36:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 73, 79 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/610601411861069824\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/gEcqT4EsF8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHlKRsiWcAETzGv.jpg",
      "id_str" : "610600892358881281",
      "id" : 610600892358881281,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHlKRsiWcAETzGv.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 667,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 667,
        "resize" : "fit",
        "w" : 1000
      } ],
      "display_url" : "pic.twitter.com\/gEcqT4EsF8"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/ElROeszC9b",
      "expanded_url" : "http:\/\/go.wh.gov\/WH-mentees",
      "display_url" : "go.wh.gov\/WH-mentees"
    } ]
  },
  "geo" : { },
  "id_str" : "610601411861069824",
  "text" : "\"I can\u2019t wait to see all the great things that you\u2019re going to achieve\" \u2014@POTUS to WH mentees: http:\/\/t.co\/ElROeszC9b http:\/\/t.co\/gEcqT4EsF8",
  "id" : 610601411861069824,
  "created_at" : "2015-06-16 00:14:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Fast Company",
      "screen_name" : "FastCompany",
      "indices" : [ 11, 23 ],
      "id_str" : "2735591",
      "id" : 2735591
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/610594587044937730\/photo\/1",
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/UR2l6QG9k7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHlBtrTWEAAmcEC.jpg",
      "id_str" : "610591477459193856",
      "id" : 610591477459193856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHlBtrTWEAAmcEC.jpg",
      "sizes" : [ {
        "h" : 1867,
        "resize" : "fit",
        "w" : 2800
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/UR2l6QG9k7"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/HpXBviK7cz",
      "expanded_url" : "http:\/\/go.wh.gov\/8acHLY",
      "display_url" : "go.wh.gov\/8acHLY"
    } ]
  },
  "geo" : { },
  "id_str" : "610594587044937730",
  "text" : ".@POTUS to @FastCompany on what \"we the people\" means in the 21st century: http:\/\/t.co\/HpXBviK7cz http:\/\/t.co\/UR2l6QG9k7",
  "id" : 610594587044937730,
  "created_at" : "2015-06-15 23:47:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "molly moon",
      "screen_name" : "mollymoon",
      "indices" : [ 67, 77 ],
      "id_str" : "1053901",
      "id" : 1053901
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LeadOnLeave",
      "indices" : [ 102, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/U5BY0fhk02",
      "expanded_url" : "https:\/\/twitter.com\/laborproject\/status\/610526166718353408",
      "display_url" : "twitter.com\/laborproject\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "610543615547314177",
  "text" : "RT @vj44: Paid leave is a win for businesses - big and small. Like @mollymoon said, just do the math! #LeadOnLeave  https:\/\/t.co\/U5BY0fhk02",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "molly moon",
        "screen_name" : "mollymoon",
        "indices" : [ 57, 67 ],
        "id_str" : "1053901",
        "id" : 1053901
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LeadOnLeave",
        "indices" : [ 92, 104 ]
      } ],
      "urls" : [ {
        "indices" : [ 106, 129 ],
        "url" : "https:\/\/t.co\/U5BY0fhk02",
        "expanded_url" : "https:\/\/twitter.com\/laborproject\/status\/610526166718353408",
        "display_url" : "twitter.com\/laborproject\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "610543292132896768",
    "text" : "Paid leave is a win for businesses - big and small. Like @mollymoon said, just do the math! #LeadOnLeave  https:\/\/t.co\/U5BY0fhk02",
    "id" : 610543292132896768,
    "created_at" : "2015-06-15 20:23:58 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 610543615547314177,
  "created_at" : "2015-06-15 20:25:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "610536666973900801",
  "text" : "RT @POTUS: So proud of these White House mentorship grads. Can't wait to see all the great things you achieve. I believe in you! http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/POTUS\/status\/610536520387268608\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/ao6k8ErjHI",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHkPuPKUsAAxT-W.jpg",
        "id_str" : "610536511503642624",
        "id" : 610536511503642624,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHkPuPKUsAAxT-W.jpg",
        "sizes" : [ {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/ao6k8ErjHI"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "610536520387268608",
    "text" : "So proud of these White House mentorship grads. Can't wait to see all the great things you achieve. I believe in you! http:\/\/t.co\/ao6k8ErjHI",
    "id" : 610536520387268608,
    "created_at" : "2015-06-15 19:57:04 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 610536666973900801,
  "created_at" : "2015-06-15 19:57:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fast Company",
      "screen_name" : "FastCompany",
      "indices" : [ 3, 15 ],
      "id_str" : "2735591",
      "id" : 2735591
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/FastCompany\/status\/610440171633405952\/photo\/1",
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/E29xjBmeC5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHi4GeXUYAAe0yM.jpg",
      "id_str" : "610440170878296064",
      "id" : 610440170878296064,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHi4GeXUYAAe0yM.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "display_url" : "pic.twitter.com\/E29xjBmeC5"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/8TF5tQkd08",
      "expanded_url" : "http:\/\/f-st.co\/kVrVOIR",
      "display_url" : "f-st.co\/kVrVOIR"
    } ]
  },
  "geo" : { },
  "id_str" : "610479906670120960",
  "text" : "RT @FastCompany: President Obama: The Fast Company interview http:\/\/t.co\/8TF5tQkd08 http:\/\/t.co\/E29xjBmeC5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/FastCompany\/status\/610440171633405952\/photo\/1",
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/E29xjBmeC5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHi4GeXUYAAe0yM.jpg",
        "id_str" : "610440170878296064",
        "id" : 610440170878296064,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHi4GeXUYAAe0yM.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        } ],
        "display_url" : "pic.twitter.com\/E29xjBmeC5"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 66 ],
        "url" : "http:\/\/t.co\/8TF5tQkd08",
        "expanded_url" : "http:\/\/f-st.co\/kVrVOIR",
        "display_url" : "f-st.co\/kVrVOIR"
      } ]
    },
    "geo" : { },
    "id_str" : "610440171633405952",
    "text" : "President Obama: The Fast Company interview http:\/\/t.co\/8TF5tQkd08 http:\/\/t.co\/E29xjBmeC5",
    "id" : 610440171633405952,
    "created_at" : "2015-06-15 13:34:13 +0000",
    "user" : {
      "name" : "Fast Company",
      "screen_name" : "FastCompany",
      "protected" : false,
      "id_str" : "2735591",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/552466516851957760\/4cONiOi4_normal.jpeg",
      "id" : 2735591,
      "verified" : true
    }
  },
  "id" : 610479906670120960,
  "created_at" : "2015-06-15 16:12:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Labor Department",
      "screen_name" : "USDOL",
      "indices" : [ 3, 9 ],
      "id_str" : "20179628",
      "id" : 20179628
    }, {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "indices" : [ 45, 54 ],
      "id_str" : "1604366701",
      "id" : 1604366701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/7RW2tn8MwE",
      "expanded_url" : "http:\/\/www.dol.gov\/live",
      "display_url" : "dol.gov\/live"
    } ]
  },
  "geo" : { },
  "id_str" : "610475134256713728",
  "text" : "RT @USDOL: Have a question about paid leave? @LaborSec will answer your questions live at 3 p.m. ET: http:\/\/t.co\/7RW2tn8MwE http:\/\/t.co\/KEU\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tom Perez",
        "screen_name" : "LaborSec",
        "indices" : [ 34, 43 ],
        "id_str" : "1604366701",
        "id" : 1604366701
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/USDOL\/status\/610471583816241152\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/KEU47UyHRq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHjUq7OW8AAM8tY.png",
        "id_str" : "610471583426211840",
        "id" : 610471583426211840,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHjUq7OW8AAM8tY.png",
        "sizes" : [ {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/KEU47UyHRq"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/7RW2tn8MwE",
        "expanded_url" : "http:\/\/www.dol.gov\/live",
        "display_url" : "dol.gov\/live"
      } ]
    },
    "geo" : { },
    "id_str" : "610471583816241152",
    "text" : "Have a question about paid leave? @LaborSec will answer your questions live at 3 p.m. ET: http:\/\/t.co\/7RW2tn8MwE http:\/\/t.co\/KEU47UyHRq",
    "id" : 610471583816241152,
    "created_at" : "2015-06-15 15:39:02 +0000",
    "user" : {
      "name" : "US Labor Department",
      "screen_name" : "USDOL",
      "protected" : false,
      "id_str" : "20179628",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655006480697978880\/Fom0f0nJ_normal.png",
      "id" : 20179628,
      "verified" : true
    }
  },
  "id" : 610475134256713728,
  "created_at" : "2015-06-15 15:53:08 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 16, 21 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "indices" : [ 23, 32 ],
      "id_str" : "1604366701",
      "id" : 1604366701
    }, {
      "name" : "Susan Wojcicki",
      "screen_name" : "SusanWojcicki",
      "indices" : [ 34, 48 ],
      "id_str" : "15828408",
      "id" : 15828408
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/610464867443716096\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/iHpE2m8FFR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHjOG3nWcAA4_BC.jpg",
      "id_str" : "610464366912237568",
      "id" : 610464366912237568,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHjOG3nWcAA4_BC.jpg",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 3456,
        "resize" : "fit",
        "w" : 5184
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/iHpE2m8FFR"
    } ],
    "hashtags" : [ {
      "text" : "LeadOnLeave",
      "indices" : [ 67, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/W6smI15S5g",
      "expanded_url" : "http:\/\/1.usa.gov\/1KLR09B",
      "display_url" : "1.usa.gov\/1KLR09B"
    } ]
  },
  "geo" : { },
  "id_str" : "610464867443716096",
  "text" : "At 3pm ET, join @VJ44, @LaborSec, @SusanWojcicki, and others for a #LeadOnLeave G+ Hangout \u2192 http:\/\/t.co\/W6smI15S5g http:\/\/t.co\/iHpE2m8FFR",
  "id" : 610464867443716096,
  "created_at" : "2015-06-15 15:12:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LetGirlsLearn",
      "indices" : [ 58, 72 ]
    }, {
      "text" : "MagnaCarta",
      "indices" : [ 111, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "610441353567313920",
  "text" : "RT @FLOTUS: Wheels up! FLOTUS is headed to London to help #LetGirlsLearn as the UK celebrates 800 years of the #MagnaCarta: http:\/\/t.co\/wYO\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LetGirlsLearn",
        "indices" : [ 46, 60 ]
      }, {
        "text" : "MagnaCarta",
        "indices" : [ 99, 110 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/wYOQSIXMfu",
        "expanded_url" : "http:\/\/1.usa.gov\/1KAcDbw",
        "display_url" : "1.usa.gov\/1KAcDbw"
      } ]
    },
    "geo" : { },
    "id_str" : "610441128425426944",
    "text" : "Wheels up! FLOTUS is headed to London to help #LetGirlsLearn as the UK celebrates 800 years of the #MagnaCarta: http:\/\/t.co\/wYOQSIXMfu",
    "id" : 610441128425426944,
    "created_at" : "2015-06-15 13:38:01 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 610441353567313920,
  "created_at" : "2015-06-15 13:38:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 84, 90 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LeadOnTrade",
      "indices" : [ 126, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/n9aLxQaHJb",
      "expanded_url" : "http:\/\/go.wh.gov\/WjHKN3",
      "display_url" : "go.wh.gov\/WjHKN3"
    } ]
  },
  "geo" : { },
  "id_str" : "610245111998361600",
  "text" : "\"Trade that\u2019s fair and free and smart will grow opportunity for our middle class.\" \u2014@POTUS on the TPP: http:\/\/t.co\/n9aLxQaHJb #LeadOnTrade",
  "id" : 610245111998361600,
  "created_at" : "2015-06-15 00:39:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LeadOnTrade",
      "indices" : [ 117, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/n9aLxPT6RD",
      "expanded_url" : "http:\/\/go.wh.gov\/WjHKN3",
      "display_url" : "go.wh.gov\/WjHKN3"
    } ]
  },
  "geo" : { },
  "id_str" : "610229047130497024",
  "text" : "President Obama to the House of Representatives: Stand up for American workers and pass TAA \u2192 http:\/\/t.co\/n9aLxPT6RD #LeadOnTrade",
  "id" : 610229047130497024,
  "created_at" : "2015-06-14 23:35:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 99, 105 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FlagDay",
      "indices" : [ 130, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/d7STI49sio",
      "expanded_url" : "http:\/\/go.wh.gov\/xQ5BXr",
      "display_url" : "go.wh.gov\/xQ5BXr"
    } ]
  },
  "geo" : { },
  "id_str" : "610177592864448512",
  "text" : "\"For more than 200 years, the American flag has been a proud symbol of the people of our nation.\" \u2014@POTUS: http:\/\/t.co\/d7STI49sio #FlagDay",
  "id" : 610177592864448512,
  "created_at" : "2015-06-14 20:10:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Dept of Defense",
      "screen_name" : "DeptofDefense",
      "indices" : [ 3, 17 ],
      "id_str" : "66369181",
      "id" : 66369181
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FlagDay",
      "indices" : [ 25, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "610119084278067200",
  "text" : "RT @DeptofDefense: Happy #FlagDay! On this day in 1777, the Continental Congress approved the U.S. flag and detailed the composition. http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/engagor.com\" rel=\"nofollow\"\u003EEngagor\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/DeptofDefense\/status\/610054100974202880\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/jHi4g9B9N7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHdY-NwWUAIOByk.jpg",
        "id_str" : "610054100399575042",
        "id" : 610054100399575042,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHdY-NwWUAIOByk.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 2949,
          "resize" : "fit",
          "w" : 4423
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/jHi4g9B9N7"
      } ],
      "hashtags" : [ {
        "text" : "FlagDay",
        "indices" : [ 6, 14 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "610054100974202880",
    "text" : "Happy #FlagDay! On this day in 1777, the Continental Congress approved the U.S. flag and detailed the composition. http:\/\/t.co\/jHi4g9B9N7",
    "id" : 610054100974202880,
    "created_at" : "2015-06-14 12:00:06 +0000",
    "user" : {
      "name" : "U.S. Dept of Defense",
      "screen_name" : "DeptofDefense",
      "protected" : false,
      "id_str" : "66369181",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/533350546027995137\/b84VANoF_normal.png",
      "id" : 66369181,
      "verified" : true
    }
  },
  "id" : 610119084278067200,
  "created_at" : "2015-06-14 16:18:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ExtraTV",
      "screen_name" : "extratv",
      "indices" : [ 3, 11 ],
      "id_str" : "15676578",
      "id" : 15676578
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 14, 20 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 62, 73 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 104, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/1k6bWMAbW2",
      "expanded_url" : "http:\/\/extr.tv\/1GjCDq5",
      "display_url" : "extr.tv\/1GjCDq5"
    } ]
  },
  "geo" : { },
  "id_str" : "609844391180505088",
  "text" : "RT @extratv: .@POTUS on his teenage daughters, life after the @WhiteHouse, and the Affordable Care Act. #ACAWorks http:\/\/t.co\/1k6bWMAbW2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 1, 7 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 49, 60 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ACAWorks",
        "indices" : [ 91, 100 ]
      } ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/1k6bWMAbW2",
        "expanded_url" : "http:\/\/extr.tv\/1GjCDq5",
        "display_url" : "extr.tv\/1GjCDq5"
      } ]
    },
    "geo" : { },
    "id_str" : "609476847231840256",
    "text" : ".@POTUS on his teenage daughters, life after the @WhiteHouse, and the Affordable Care Act. #ACAWorks http:\/\/t.co\/1k6bWMAbW2",
    "id" : 609476847231840256,
    "created_at" : "2015-06-12 21:46:18 +0000",
    "user" : {
      "name" : "ExtraTV",
      "screen_name" : "extratv",
      "protected" : false,
      "id_str" : "15676578",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/772836604041830400\/PI94WG59_normal.jpg",
      "id" : 15676578,
      "verified" : true
    }
  },
  "id" : 609844391180505088,
  "created_at" : "2015-06-13 22:06:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 3, 11 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    }, {
      "name" : "U.S. Navy",
      "screen_name" : "USNavy",
      "indices" : [ 55, 62 ],
      "id_str" : "54885400",
      "id" : 54885400
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "609803169649020928",
  "text" : "RT @DrBiden: \"May the USS Gabrielle Giffords &amp; our @USNavy family who are associated with her, forever sail with fair winds &amp; following sea\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "U.S. Navy",
        "screen_name" : "USNavy",
        "indices" : [ 42, 49 ],
        "id_str" : "54885400",
        "id" : 54885400
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "609788681814167552",
    "text" : "\"May the USS Gabrielle Giffords &amp; our @USNavy family who are associated with her, forever sail with fair winds &amp; following seas.\" \u2014Dr. Biden",
    "id" : 609788681814167552,
    "created_at" : "2015-06-13 18:25:25 +0000",
    "user" : {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "protected" : false,
      "id_str" : "1281405877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608687663034474496\/wvzVG_yt_normal.jpg",
      "id" : 1281405877,
      "verified" : true
    }
  },
  "id" : 609803169649020928,
  "created_at" : "2015-06-13 19:22:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "indices" : [ 3, 11 ],
      "id_str" : "1281405877",
      "id" : 1281405877
    }, {
      "name" : "Gabrielle Giffords",
      "screen_name" : "GabbyGiffords",
      "indices" : [ 14, 28 ],
      "id_str" : "44177383",
      "id" : 44177383
    }, {
      "name" : "Mark Kelly",
      "screen_name" : "ShuttleCDRKelly",
      "indices" : [ 35, 51 ],
      "id_str" : "65707359",
      "id" : 65707359
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "609802740894670849",
  "text" : "RT @DrBiden: .@GabbyGiffords &amp; @ShuttleCDRKelly give true meaning to the ideals of honor, courage &amp; commitment\u2014those that define the @USNav\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gabrielle Giffords",
        "screen_name" : "GabbyGiffords",
        "indices" : [ 1, 15 ],
        "id_str" : "44177383",
        "id" : 44177383
      }, {
        "name" : "Mark Kelly",
        "screen_name" : "ShuttleCDRKelly",
        "indices" : [ 22, 38 ],
        "id_str" : "65707359",
        "id" : 65707359
      }, {
        "name" : "U.S. Navy",
        "screen_name" : "USNavy",
        "indices" : [ 128, 135 ],
        "id_str" : "54885400",
        "id" : 54885400
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "609787237467836416",
    "text" : ".@GabbyGiffords &amp; @ShuttleCDRKelly give true meaning to the ideals of honor, courage &amp; commitment\u2014those that define the @USNavy. \u2014Dr. Biden",
    "id" : 609787237467836416,
    "created_at" : "2015-06-13 18:19:41 +0000",
    "user" : {
      "name" : "Dr. Jill Biden",
      "screen_name" : "DrBiden",
      "protected" : false,
      "id_str" : "1281405877",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/608687663034474496\/wvzVG_yt_normal.jpg",
      "id" : 1281405877,
      "verified" : true
    }
  },
  "id" : 609802740894670849,
  "created_at" : "2015-06-13 19:21:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 97, 103 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LeadOnTrade",
      "indices" : [ 128, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/n9aLxQaHJb",
      "expanded_url" : "http:\/\/go.wh.gov\/WjHKN3",
      "display_url" : "go.wh.gov\/WjHKN3"
    } ]
  },
  "geo" : { },
  "id_str" : "609789084085542913",
  "text" : "\"I urge those Members of Congress who voted against Trade Adjustment Assistance to reconsider.\" \u2014@POTUS: http:\/\/t.co\/n9aLxQaHJb #LeadOnTrade",
  "id" : 609789084085542913,
  "created_at" : "2015-06-13 18:27:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nick Offerman",
      "screen_name" : "Nick_Offerman",
      "indices" : [ 3, 17 ],
      "id_str" : "502135911",
      "id" : 502135911
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 61, 67 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Jimmy DiResta",
      "screen_name" : "JimmyDiResta",
      "indices" : [ 94, 107 ],
      "id_str" : "255855227",
      "id" : 255855227
    }, {
      "name" : "National Maker Faire",
      "screen_name" : "natlmakerfaire",
      "indices" : [ 108, 123 ],
      "id_str" : "3142752415",
      "id" : 3142752415
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NationofMakers",
      "indices" : [ 125, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "609745959778656256",
  "text" : "RT @Nick_Offerman: AMERICA let's make things with our hands. @POTUS I will teach you to sand.\n@JimmyDiResta @NatlMakerFaire \n#NationofMakers",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 42, 48 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "Jimmy DiResta",
        "screen_name" : "JimmyDiResta",
        "indices" : [ 75, 88 ],
        "id_str" : "255855227",
        "id" : 255855227
      }, {
        "name" : "National Maker Faire",
        "screen_name" : "natlmakerfaire",
        "indices" : [ 89, 104 ],
        "id_str" : "3142752415",
        "id" : 3142752415
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NationofMakers",
        "indices" : [ 106, 121 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "609705292377509888",
    "text" : "AMERICA let's make things with our hands. @POTUS I will teach you to sand.\n@JimmyDiResta @NatlMakerFaire \n#NationofMakers",
    "id" : 609705292377509888,
    "created_at" : "2015-06-13 12:54:04 +0000",
    "user" : {
      "name" : "Nick Offerman",
      "screen_name" : "Nick_Offerman",
      "protected" : false,
      "id_str" : "502135911",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/707764911972036608\/T_Uz8eQk_normal.jpg",
      "id" : 502135911,
      "verified" : true
    }
  },
  "id" : 609745959778656256,
  "created_at" : "2015-06-13 15:35:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 103, 109 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/n9aLxPT6RD",
      "expanded_url" : "http:\/\/go.wh.gov\/WjHKN3",
      "display_url" : "go.wh.gov\/WjHKN3"
    } ]
  },
  "geo" : { },
  "id_str" : "609740234931195905",
  "text" : "\"America has to write the rules of the 21st century economy in a way that benefits American workers.\" \u2014@POTUS: http:\/\/t.co\/n9aLxPT6RD",
  "id" : 609740234931195905,
  "created_at" : "2015-06-13 15:12:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/whitehouseostp\/status\/609384390108557312\/photo\/1",
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/v65mfMIJYb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHT331NVAAAS3Gs.png",
      "id_str" : "609384388149706752",
      "id" : 609384388149706752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHT331NVAAAS3Gs.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 635
      }, {
        "h" : 321,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 635
      }, {
        "h" : 182,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/v65mfMIJYb"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/whitehouseostp\/status\/609384390108557312\/photo\/1",
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/v65mfMIJYb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHT335KUEAAOV7V.png",
      "id_str" : "609384389210804224",
      "id" : 609384389210804224,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHT335KUEAAOV7V.png",
      "sizes" : [ {
        "h" : 347,
        "resize" : "fit",
        "w" : 635
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 186,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 328,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 347,
        "resize" : "fit",
        "w" : 635
      } ],
      "display_url" : "pic.twitter.com\/v65mfMIJYb"
    }, {
      "expanded_url" : "http:\/\/twitter.com\/whitehouseostp\/status\/609384390108557312\/photo\/1",
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/v65mfMIJYb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHT333DUkAIn4uV.png",
      "id_str" : "609384388644605954",
      "id" : 609384388644605954,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHT333DUkAIn4uV.png",
      "sizes" : [ {
        "h" : 332,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 347,
        "resize" : "fit",
        "w" : 627
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 347,
        "resize" : "fit",
        "w" : 627
      }, {
        "h" : 188,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/v65mfMIJYb"
    } ],
    "hashtags" : [ {
      "text" : "NationofMakers",
      "indices" : [ 29, 44 ]
    } ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/qNsvMcANGj",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=ZVX5wjNvZtI",
      "display_url" : "youtube.com\/watch?v=ZVX5wj\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "609518736890990592",
  "text" : "RT @whitehouseostp: Go make! #NationofMakers https:\/\/t.co\/qNsvMcANGj http:\/\/t.co\/v65mfMIJYb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/whitehouseostp\/status\/609384390108557312\/photo\/1",
        "indices" : [ 49, 71 ],
        "url" : "http:\/\/t.co\/v65mfMIJYb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHT331NVAAAS3Gs.png",
        "id_str" : "609384388149706752",
        "id" : 609384388149706752,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHT331NVAAAS3Gs.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 635
        }, {
          "h" : 321,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 635
        }, {
          "h" : 182,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/v65mfMIJYb"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/whitehouseostp\/status\/609384390108557312\/photo\/1",
        "indices" : [ 49, 71 ],
        "url" : "http:\/\/t.co\/v65mfMIJYb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHT335KUEAAOV7V.png",
        "id_str" : "609384389210804224",
        "id" : 609384389210804224,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHT335KUEAAOV7V.png",
        "sizes" : [ {
          "h" : 347,
          "resize" : "fit",
          "w" : 635
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 186,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 328,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 347,
          "resize" : "fit",
          "w" : 635
        } ],
        "display_url" : "pic.twitter.com\/v65mfMIJYb"
      }, {
        "expanded_url" : "http:\/\/twitter.com\/whitehouseostp\/status\/609384390108557312\/photo\/1",
        "indices" : [ 49, 71 ],
        "url" : "http:\/\/t.co\/v65mfMIJYb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHT333DUkAIn4uV.png",
        "id_str" : "609384388644605954",
        "id" : 609384388644605954,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHT333DUkAIn4uV.png",
        "sizes" : [ {
          "h" : 332,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 347,
          "resize" : "fit",
          "w" : 627
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 347,
          "resize" : "fit",
          "w" : 627
        }, {
          "h" : 188,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/v65mfMIJYb"
      } ],
      "hashtags" : [ {
        "text" : "NationofMakers",
        "indices" : [ 9, 24 ]
      } ],
      "urls" : [ {
        "indices" : [ 25, 48 ],
        "url" : "https:\/\/t.co\/qNsvMcANGj",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=ZVX5wjNvZtI",
        "display_url" : "youtube.com\/watch?v=ZVX5wj\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "609384390108557312",
    "text" : "Go make! #NationofMakers https:\/\/t.co\/qNsvMcANGj http:\/\/t.co\/v65mfMIJYb",
    "id" : 609384390108557312,
    "created_at" : "2015-06-12 15:38:55 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 609518736890990592,
  "created_at" : "2015-06-13 00:32:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "indices" : [ 71, 80 ],
      "id_str" : "1604366701",
      "id" : 1604366701
    }, {
      "name" : "Susan Wojcicki",
      "screen_name" : "SusanWojcicki",
      "indices" : [ 81, 95 ],
      "id_str" : "15828408",
      "id" : 15828408
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LeadOnLeave",
      "indices" : [ 27, 39 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/bmuMioPtMZ",
      "expanded_url" : "http:\/\/1.usa.gov\/1KLR09B",
      "display_url" : "1.usa.gov\/1KLR09B"
    } ]
  },
  "geo" : { },
  "id_str" : "609483255595708416",
  "text" : "RT @vj44: Next stop on the #LeadOnLeave tour \u27A1\uFE0F wherever you are! Join @LaborSec @SusanWojcicki and me on Monday: http:\/\/t.co\/bmuMioPtMZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tom Perez",
        "screen_name" : "LaborSec",
        "indices" : [ 61, 70 ],
        "id_str" : "1604366701",
        "id" : 1604366701
      }, {
        "name" : "Susan Wojcicki",
        "screen_name" : "SusanWojcicki",
        "indices" : [ 71, 85 ],
        "id_str" : "15828408",
        "id" : 15828408
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LeadOnLeave",
        "indices" : [ 17, 29 ]
      } ],
      "urls" : [ {
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/bmuMioPtMZ",
        "expanded_url" : "http:\/\/1.usa.gov\/1KLR09B",
        "display_url" : "1.usa.gov\/1KLR09B"
      } ]
    },
    "geo" : { },
    "id_str" : "609481392439693312",
    "text" : "Next stop on the #LeadOnLeave tour \u27A1\uFE0F wherever you are! Join @LaborSec @SusanWojcicki and me on Monday: http:\/\/t.co\/bmuMioPtMZ",
    "id" : 609481392439693312,
    "created_at" : "2015-06-12 22:04:22 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 609483255595708416,
  "created_at" : "2015-06-12 22:11:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 1, 7 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/609464741585649664\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/CvAmEdh6t3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHVA1sqUMAAAx_D.jpg",
      "id_str" : "609464615844458496",
      "id" : 609464615844458496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHVA1sqUMAAAx_D.jpg",
      "sizes" : [ {
        "h" : 491,
        "resize" : "fit",
        "w" : 1261
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 399,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 234,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 132,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/CvAmEdh6t3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "609464741585649664",
  "text" : ".@POTUS thanks members of the House who voted to support American workers with TPA and urges them to pass TAA. http:\/\/t.co\/CvAmEdh6t3",
  "id" : 609464741585649664,
  "created_at" : "2015-06-12 20:58:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LeadOnTrade",
      "indices" : [ 128, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/7h5gEONmks",
      "expanded_url" : "http:\/\/go.wh.gov\/rZiuih",
      "display_url" : "go.wh.gov\/rZiuih"
    } ]
  },
  "geo" : { },
  "id_str" : "609412545372270593",
  "text" : "FACT: Passing Trade Adjustment Assistance would benefit 100,000 American workers annually over 6 years \u2192 http:\/\/t.co\/7h5gEONmks #LeadOnTrade",
  "id" : 609412545372270593,
  "created_at" : "2015-06-12 17:30:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/609407215003414529\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/BZV164JjQ1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHUMlITUAAE_sG4.jpg",
      "id_str" : "609407156601749505",
      "id" : 609407156601749505,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHUMlITUAAE_sG4.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/BZV164JjQ1"
    } ],
    "hashtags" : [ {
      "text" : "LeadOnTrade",
      "indices" : [ 105, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/BmEPgbCKlA",
      "expanded_url" : "http:\/\/wh.gov\/trade",
      "display_url" : "wh.gov\/trade"
    } ]
  },
  "geo" : { },
  "id_str" : "609407215003414529",
  "text" : "President Obama's trade deal would protect American values in the global economy: http:\/\/t.co\/BmEPgbCKlA #LeadOnTrade http:\/\/t.co\/BZV164JjQ1",
  "id" : 609407215003414529,
  "created_at" : "2015-06-12 17:09:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/609397530447622144\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/tiz5BvDlBQ",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHUDSShUEAAuIg9.jpg",
      "id_str" : "609396937322663936",
      "id" : 609396937322663936,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHUDSShUEAAuIg9.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/tiz5BvDlBQ"
    } ],
    "hashtags" : [ {
      "text" : "LeadOnTrade",
      "indices" : [ 99, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "609397530447622144",
  "text" : "President Obama's trade deal enforces strong environmental standards that past trade deals didn't. #LeadOnTrade http:\/\/t.co\/tiz5BvDlBQ",
  "id" : 609397530447622144,
  "created_at" : "2015-06-12 16:31:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30AD\u30E3\u30ED\u30E9\u30A4\u30F3\u30FB\u30B1\u30CD\u30C7\u30A3\u5927\u4F7F",
      "screen_name" : "CarolineKennedy",
      "indices" : [ 15, 31 ],
      "id_str" : "1900694785",
      "id" : 1900694785
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LeadOnTrade",
      "indices" : [ 106, 118 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/dUeSbbFEsa",
      "expanded_url" : "http:\/\/politi.co\/1HxhKd7",
      "display_url" : "politi.co\/1HxhKd7"
    } ]
  },
  "geo" : { },
  "id_str" : "609390024035991553",
  "text" : "Worth sharing: @CarolineKennedy on why she supports President Obama's trade deal \u2192 http:\/\/t.co\/dUeSbbFEsa #LeadOnTrade",
  "id" : 609390024035991553,
  "created_at" : "2015-06-12 16:01:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/609374351792566272\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/MoC9jE793y",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHTusLnUsAAXrGx.jpg",
      "id_str" : "609374292401238016",
      "id" : 609374292401238016,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHTusLnUsAAXrGx.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/MoC9jE793y"
    } ],
    "hashtags" : [ {
      "text" : "LeadOnTrade",
      "indices" : [ 76, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/BmEPgbUld8",
      "expanded_url" : "http:\/\/wh.gov\/trade",
      "display_url" : "wh.gov\/trade"
    } ]
  },
  "geo" : { },
  "id_str" : "609374351792566272",
  "text" : "President Obama's trade deal would put American workers first.\nIt's time to #LeadOnTrade \u2192 http:\/\/t.co\/BmEPgbUld8 http:\/\/t.co\/MoC9jE793y",
  "id" : 609374351792566272,
  "created_at" : "2015-06-12 14:59:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/609367472119091200\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/Mf3UzMUdQq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHToWI-UcAAWSix.jpg",
      "id_str" : "609367316665495552",
      "id" : 609367316665495552,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHToWI-UcAAWSix.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Mf3UzMUdQq"
    } ],
    "hashtags" : [ {
      "text" : "LeadOnTrade",
      "indices" : [ 76, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/BmEPgbCKlA",
      "expanded_url" : "http:\/\/wh.gov\/trade",
      "display_url" : "wh.gov\/trade"
    } ]
  },
  "geo" : { },
  "id_str" : "609367472119091200",
  "text" : "95% of the world's customers live outside the U.S.\nIt's time for America to #LeadOnTrade \u2192 http:\/\/t.co\/BmEPgbCKlA http:\/\/t.co\/Mf3UzMUdQq",
  "id" : 609367472119091200,
  "created_at" : "2015-06-12 14:31:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/7h5gEONmks",
      "expanded_url" : "http:\/\/go.wh.gov\/rZiuih",
      "display_url" : "go.wh.gov\/rZiuih"
    } ]
  },
  "geo" : { },
  "id_str" : "609355019209453568",
  "text" : "It's time for Congress to provide a critical lifeline to American workers by passing Trade Adjustment Assistance \u2192 http:\/\/t.co\/7h5gEONmks",
  "id" : 609355019209453568,
  "created_at" : "2015-06-12 13:42:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30AD\u30E3\u30ED\u30E9\u30A4\u30F3\u30FB\u30B1\u30CD\u30C7\u30A3\u5927\u4F7F",
      "screen_name" : "CarolineKennedy",
      "indices" : [ 67, 83 ],
      "id_str" : "1900694785",
      "id" : 1900694785
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/dUeSbbFEsa",
      "expanded_url" : "http:\/\/politi.co\/1HxhKd7",
      "display_url" : "politi.co\/1HxhKd7"
    } ]
  },
  "geo" : { },
  "id_str" : "609175426217304064",
  "text" : "\"My dad, JFK, was for free trade. Democrats today should be too.\" \u2014@CarolineKennedy on President Obama's trade deal: http:\/\/t.co\/dUeSbbFEsa",
  "id" : 609175426217304064,
  "created_at" : "2015-06-12 01:48:34 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/POTUS\/status\/609163576616615936\/photo\/1",
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/FpEUTnYgoD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHQvCDoWwAAwo0u.jpg",
      "id_str" : "609163561982672896",
      "id" : 609163561982672896,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHQvCDoWwAAwo0u.jpg",
      "sizes" : [ {
        "h" : 231,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 696,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 408,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 696,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/FpEUTnYgoD"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "609163758057885696",
  "text" : "RT @POTUS: I challenged them to a race. http:\/\/t.co\/FpEUTnYgoD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/POTUS\/status\/609163576616615936\/photo\/1",
        "indices" : [ 29, 51 ],
        "url" : "http:\/\/t.co\/FpEUTnYgoD",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHQvCDoWwAAwo0u.jpg",
        "id_str" : "609163561982672896",
        "id" : 609163561982672896,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHQvCDoWwAAwo0u.jpg",
        "sizes" : [ {
          "h" : 231,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 696,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 408,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 696,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/FpEUTnYgoD"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "609163576616615936",
    "text" : "I challenged them to a race. http:\/\/t.co\/FpEUTnYgoD",
    "id" : 609163576616615936,
    "created_at" : "2015-06-12 01:01:29 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 609163758057885696,
  "created_at" : "2015-06-12 01:02:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "indices" : [ 3, 12 ],
      "id_str" : "1604366701",
      "id" : 1604366701
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/sZGHRFkQkX",
      "expanded_url" : "http:\/\/go.wh.gov\/dbebRc",
      "display_url" : "go.wh.gov\/dbebRc"
    } ]
  },
  "geo" : { },
  "id_str" : "609157364676169728",
  "text" : "RT @LaborSec: Here's what you need to know about Trade Adjustment Assistance:  http:\/\/t.co\/sZGHRFkQkX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/sZGHRFkQkX",
        "expanded_url" : "http:\/\/go.wh.gov\/dbebRc",
        "display_url" : "go.wh.gov\/dbebRc"
      } ]
    },
    "geo" : { },
    "id_str" : "609153817075130368",
    "text" : "Here's what you need to know about Trade Adjustment Assistance:  http:\/\/t.co\/sZGHRFkQkX",
    "id" : 609153817075130368,
    "created_at" : "2015-06-12 00:22:42 +0000",
    "user" : {
      "name" : "Tom Perez",
      "screen_name" : "LaborSec",
      "protected" : false,
      "id_str" : "1604366701",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/744887280666611712\/eEeyFjs6_normal.jpg",
      "id" : 1604366701,
      "verified" : true
    }
  },
  "id" : 609157364676169728,
  "created_at" : "2015-06-12 00:36:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LeadonLeave",
      "indices" : [ 59, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "609142773921374208",
  "text" : "RT @vj44: Thanks to the Oregon State Senate for taking the #LeadonLeave and voting to allow almost 500,000 working people have paid sick da\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LeadonLeave",
        "indices" : [ 49, 61 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "609140878414884864",
    "text" : "Thanks to the Oregon State Senate for taking the #LeadonLeave and voting to allow almost 500,000 working people have paid sick days.",
    "id" : 609140878414884864,
    "created_at" : "2015-06-11 23:31:17 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 609142773921374208,
  "created_at" : "2015-06-11 23:38:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lincoln",
      "screen_name" : "LincolnTheHawk",
      "indices" : [ 3, 18 ],
      "id_str" : "3308373087",
      "id" : 3308373087
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FindYourJurassicPark",
      "indices" : [ 103, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/Rxtmr2tOw3",
      "expanded_url" : "http:\/\/wh.gov\/nation-of-makers",
      "display_url" : "wh.gov\/nation-of-make\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "609135264091344896",
  "text" : "RT @LincolnTheHawk: Looks like another predator made it in here. Clever girl... http:\/\/t.co\/Rxtmr2tOw3 #FindYourJurassicPark http:\/\/t.co\/LO\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/LincolnTheHawk\/status\/609135164975767552\/photo\/1",
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/LOBHVsYLDv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHQUCFMUEAAhEn5.jpg",
        "id_str" : "609133875587977216",
        "id" : 609133875587977216,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHQUCFMUEAAhEn5.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1333,
          "resize" : "fit",
          "w" : 2000
        } ],
        "display_url" : "pic.twitter.com\/LOBHVsYLDv"
      } ],
      "hashtags" : [ {
        "text" : "FindYourJurassicPark",
        "indices" : [ 83, 104 ]
      } ],
      "urls" : [ {
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/Rxtmr2tOw3",
        "expanded_url" : "http:\/\/wh.gov\/nation-of-makers",
        "display_url" : "wh.gov\/nation-of-make\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "609135164975767552",
    "text" : "Looks like another predator made it in here. Clever girl... http:\/\/t.co\/Rxtmr2tOw3 #FindYourJurassicPark http:\/\/t.co\/LOBHVsYLDv",
    "id" : 609135164975767552,
    "created_at" : "2015-06-11 23:08:35 +0000",
    "user" : {
      "name" : "Lincoln",
      "screen_name" : "LincolnTheHawk",
      "protected" : false,
      "id_str" : "3308373087",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606830531523821569\/XkD2OVpv_normal.jpg",
      "id" : 3308373087,
      "verified" : false
    }
  },
  "id" : 609135264091344896,
  "created_at" : "2015-06-11 23:08:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 48, 54 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StartupInADay",
      "indices" : [ 130, 144 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/XRV9tO1LX2",
      "expanded_url" : "http:\/\/go.wh.gov\/XeeLUd",
      "display_url" : "go.wh.gov\/XeeLUd"
    } ]
  },
  "geo" : { },
  "id_str" : "609067451314077696",
  "text" : "\"You'll be off &amp; running within 24 hours.\" \u2014@POTUS on new steps to make it faster to start a business: http:\/\/t.co\/XRV9tO1LX2 #StartupInADay",
  "id" : 609067451314077696,
  "created_at" : "2015-06-11 18:39:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/609051739573116928\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/KwwH2yO4r9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHPJSlKW0AAPrTv.jpg",
      "id_str" : "609051695675527168",
      "id" : 609051695675527168,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHPJSlKW0AAPrTv.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/KwwH2yO4r9"
    } ],
    "hashtags" : [ {
      "text" : "StartUpInADay",
      "indices" : [ 101, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/XRV9tNKb5u",
      "expanded_url" : "http:\/\/go.wh.gov\/XeeLUd",
      "display_url" : "go.wh.gov\/XeeLUd"
    } ]
  },
  "geo" : { },
  "id_str" : "609051739573116928",
  "text" : "RT if you agree: It's time to make it faster to start a business in America \u2192 http:\/\/t.co\/XRV9tNKb5u #StartUpInADay http:\/\/t.co\/KwwH2yO4r9",
  "id" : 609051739573116928,
  "created_at" : "2015-06-11 17:37:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Kelly",
      "screen_name" : "StationCDRKelly",
      "indices" : [ 3, 19 ],
      "id_str" : "65647594",
      "id" : 65647594
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SpaceSelfie",
      "indices" : [ 21, 33 ]
    }, {
      "text" : "Earth",
      "indices" : [ 126, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "609050000140681216",
  "text" : "RT @StationCDRKelly: #SpaceSelfie before hatch closing. I'm going to miss these guys up here. Congrats on your safe return to #Earth! http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/StationCDRKelly\/status\/609012182123225088\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/dyyaMm9hVV",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHOlWjoW8AEKaSW.jpg",
        "id_str" : "609012181565370369",
        "id" : 609012181565370369,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHOlWjoW8AEKaSW.jpg",
        "sizes" : [ {
          "h" : 399,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1065,
          "resize" : "fit",
          "w" : 1600
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/dyyaMm9hVV"
      } ],
      "hashtags" : [ {
        "text" : "SpaceSelfie",
        "indices" : [ 0, 12 ]
      }, {
        "text" : "Earth",
        "indices" : [ 105, 111 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "609012182123225088",
    "text" : "#SpaceSelfie before hatch closing. I'm going to miss these guys up here. Congrats on your safe return to #Earth! http:\/\/t.co\/dyyaMm9hVV",
    "id" : 609012182123225088,
    "created_at" : "2015-06-11 14:59:53 +0000",
    "user" : {
      "name" : "Scott Kelly",
      "screen_name" : "StationCDRKelly",
      "protected" : false,
      "id_str" : "65647594",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/558447158597136385\/P9TpCaRn_normal.jpeg",
      "id" : 65647594,
      "verified" : true
    }
  },
  "id" : 609050000140681216,
  "created_at" : "2015-06-11 17:30:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MrsOgrose",
      "screen_name" : "MrsOgrose",
      "indices" : [ 3, 13 ],
      "id_str" : "392882675",
      "id" : 392882675
    }, {
      "name" : "Sylvia Burwell",
      "screen_name" : "SecBurwell",
      "indices" : [ 15, 26 ],
      "id_str" : "2458567464",
      "id" : 2458567464
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/MrsOgrose\/status\/609007604732313600\/photo\/1",
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/M1Se7sRQF5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHOhL-gWcAAtJPk.jpg",
      "id_str" : "609007601754468352",
      "id" : 609007601754468352,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHOhL-gWcAAtJPk.jpg",
      "sizes" : [ {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/M1Se7sRQF5"
    } ],
    "hashtags" : [ {
      "text" : "HealthySelfie",
      "indices" : [ 61, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "609013568244076544",
  "text" : "RT @MrsOgrose: @SecBurwell ran my first 5K with my daughter. #HealthySelfie http:\/\/t.co\/M1Se7sRQF5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sylvia Burwell",
        "screen_name" : "SecBurwell",
        "indices" : [ 0, 11 ],
        "id_str" : "2458567464",
        "id" : 2458567464
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MrsOgrose\/status\/609007604732313600\/photo\/1",
        "indices" : [ 61, 83 ],
        "url" : "http:\/\/t.co\/M1Se7sRQF5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHOhL-gWcAAtJPk.jpg",
        "id_str" : "609007601754468352",
        "id" : 609007601754468352,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHOhL-gWcAAtJPk.jpg",
        "sizes" : [ {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/M1Se7sRQF5"
      } ],
      "hashtags" : [ {
        "text" : "HealthySelfie",
        "indices" : [ 46, 60 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "608992363663515648",
    "geo" : { },
    "id_str" : "609007604732313600",
    "in_reply_to_user_id" : 2458567464,
    "text" : "@SecBurwell ran my first 5K with my daughter. #HealthySelfie http:\/\/t.co\/M1Se7sRQF5",
    "id" : 609007604732313600,
    "in_reply_to_status_id" : 608992363663515648,
    "created_at" : "2015-06-11 14:41:42 +0000",
    "in_reply_to_screen_name" : "SecBurwell",
    "in_reply_to_user_id_str" : "2458567464",
    "user" : {
      "name" : "MrsOgrose",
      "screen_name" : "MrsOgrose",
      "protected" : false,
      "id_str" : "392882675",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/636626018866860032\/P5WRuo_-_normal.jpg",
      "id" : 392882675,
      "verified" : false
    }
  },
  "id" : 609013568244076544,
  "created_at" : "2015-06-11 15:05:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HealthySelfie",
      "indices" : [ 99, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/LnW0VG6CFP",
      "expanded_url" : "http:\/\/go.wh.gov\/HealthySelfie",
      "display_url" : "go.wh.gov\/HealthySelfie"
    } ]
  },
  "geo" : { },
  "id_str" : "609009682544381952",
  "text" : "Flu shots?\nCheckups?\nExercise?\nShow us how you take preventive steps to protect your health with a #HealthySelfie \u2192 http:\/\/t.co\/LnW0VG6CFP",
  "id" : 609009682544381952,
  "created_at" : "2015-06-11 14:49:57 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HealthySelfie",
      "indices" : [ 104, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "609006476774932481",
  "text" : "RT @vj44: I commit to exercise every day, even if that means taking the long walk to work. \n\nShare your #HealthySelfie with me! http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/609003071646089216\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/OjSUUtsqUM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHOdEAMW4AAuPb9.jpg",
        "id_str" : "609003066722017280",
        "id" : 609003066722017280,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHOdEAMW4AAuPb9.jpg",
        "sizes" : [ {
          "h" : 784,
          "resize" : "fit",
          "w" : 898
        }, {
          "h" : 297,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 524,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 784,
          "resize" : "fit",
          "w" : 898
        } ],
        "display_url" : "pic.twitter.com\/OjSUUtsqUM"
      } ],
      "hashtags" : [ {
        "text" : "HealthySelfie",
        "indices" : [ 94, 108 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "609003071646089216",
    "text" : "I commit to exercise every day, even if that means taking the long walk to work. \n\nShare your #HealthySelfie with me! http:\/\/t.co\/OjSUUtsqUM",
    "id" : 609003071646089216,
    "created_at" : "2015-06-11 14:23:41 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 609006476774932481,
  "created_at" : "2015-06-11 14:37:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Surgeon General",
      "screen_name" : "Surgeon_General",
      "indices" : [ 3, 19 ],
      "id_str" : "455024343",
      "id" : 455024343
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HealthyLunch",
      "indices" : [ 48, 61 ]
    }, {
      "text" : "HealthySelfie",
      "indices" : [ 124, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "609002140078604288",
  "text" : "RT @Surgeon_General: Some fav ingredients for a #HealthyLunch: chickpeas, brussels sprouts, raisins, spinach. What are urs? #HealthySelfie \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Surgeon_General\/status\/608995621643550720\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/Qi2NvydA0s",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHLGob0VIAEmZ-r.jpg",
        "id_str" : "608767297612750849",
        "id" : 608767297612750849,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHLGob0VIAEmZ-r.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1936,
          "resize" : "fit",
          "w" : 1936
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/Qi2NvydA0s"
      } ],
      "hashtags" : [ {
        "text" : "HealthyLunch",
        "indices" : [ 27, 40 ]
      }, {
        "text" : "HealthySelfie",
        "indices" : [ 103, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "608995621643550720",
    "text" : "Some fav ingredients for a #HealthyLunch: chickpeas, brussels sprouts, raisins, spinach. What are urs? #HealthySelfie http:\/\/t.co\/Qi2NvydA0s",
    "id" : 608995621643550720,
    "created_at" : "2015-06-11 13:54:05 +0000",
    "user" : {
      "name" : "U.S. Surgeon General",
      "screen_name" : "Surgeon_General",
      "protected" : false,
      "id_str" : "455024343",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/768080246314717185\/2csUW4il_normal.jpg",
      "id" : 455024343,
      "verified" : true
    }
  },
  "id" : 609002140078604288,
  "created_at" : "2015-06-11 14:19:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sylvia Burwell",
      "screen_name" : "SecBurwell",
      "indices" : [ 3, 14 ],
      "id_str" : "2458567464",
      "id" : 2458567464
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/SecBurwell\/status\/608992363663515648\/photo\/1",
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/XTh0Q7p9HU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHOTUo_UwAAVotJ.jpg",
      "id_str" : "608992357434834944",
      "id" : 608992357434834944,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHOTUo_UwAAVotJ.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/XTh0Q7p9HU"
    } ],
    "hashtags" : [ {
      "text" : "HealthySelfie",
      "indices" : [ 68, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608994366661775360",
  "text" : "RT @SecBurwell: How are you investing in your health? Show us using #HealthySelfie! http:\/\/t.co\/XTh0Q7p9HU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/SecBurwell\/status\/608992363663515648\/photo\/1",
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/XTh0Q7p9HU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHOTUo_UwAAVotJ.jpg",
        "id_str" : "608992357434834944",
        "id" : 608992357434834944,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHOTUo_UwAAVotJ.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/XTh0Q7p9HU"
      } ],
      "hashtags" : [ {
        "text" : "HealthySelfie",
        "indices" : [ 52, 66 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "608992363663515648",
    "text" : "How are you investing in your health? Show us using #HealthySelfie! http:\/\/t.co\/XTh0Q7p9HU",
    "id" : 608992363663515648,
    "created_at" : "2015-06-11 13:41:08 +0000",
    "user" : {
      "name" : "Sylvia Burwell",
      "screen_name" : "SecBurwell",
      "protected" : false,
      "id_str" : "2458567464",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/567351512351793152\/jMgeUhVq_normal.jpeg",
      "id" : 2458567464,
      "verified" : true
    }
  },
  "id" : 608994366661775360,
  "created_at" : "2015-06-11 13:49:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/608765603617214464\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/KO7aZqz9qF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHLBSQyUkAAy__N.jpg",
      "id_str" : "608761419136274432",
      "id" : 608761419136274432,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHLBSQyUkAAy__N.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 513,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 601,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 301,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/KO7aZqz9qF"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/aFubj8rz78",
      "expanded_url" : "http:\/\/go.wh.gov\/c9iQHp",
      "display_url" : "go.wh.gov\/c9iQHp"
    } ]
  },
  "geo" : { },
  "id_str" : "608765603617214464",
  "text" : "FACT: Women business owners who export employ 5 times more workers than those who don\u2019t \u2192 http:\/\/t.co\/aFubj8rz78 http:\/\/t.co\/KO7aZqz9qF",
  "id" : 608765603617214464,
  "created_at" : "2015-06-10 22:40:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "indices" : [ 3, 11 ],
      "id_str" : "2382117350",
      "id" : 2382117350
    }, {
      "name" : "Dept. of Agriculture",
      "screen_name" : "USDA",
      "indices" : [ 86, 91 ],
      "id_str" : "61853389",
      "id" : 61853389
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 52, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/YsKXEKbg4f",
      "expanded_url" : "http:\/\/www.bloomberg.com\/news\/articles\/2015-06-10\/obama-persuades-unilever-wal-mart-to-help-farmers-cut-emissions",
      "display_url" : "bloomberg.com\/news\/articles\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "608760213110296577",
  "text" : "RT @Deese44: Rural America continues stepping up to #ActOnClimate w\/ new biz pledges, @USDA clean energy $: http:\/\/t.co\/YsKXEKbg4f http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dept. of Agriculture",
        "screen_name" : "USDA",
        "indices" : [ 73, 78 ],
        "id_str" : "61853389",
        "id" : 61853389
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Deese44\/status\/608727561003081729\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/VAhasjew0d",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHKhbE3UYAAxuZ-.jpg",
        "id_str" : "608726386182742016",
        "id" : 608726386182742016,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHKhbE3UYAAxuZ-.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/VAhasjew0d"
      } ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 39, 52 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/YsKXEKbg4f",
        "expanded_url" : "http:\/\/www.bloomberg.com\/news\/articles\/2015-06-10\/obama-persuades-unilever-wal-mart-to-help-farmers-cut-emissions",
        "display_url" : "bloomberg.com\/news\/articles\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "608727561003081729",
    "text" : "Rural America continues stepping up to #ActOnClimate w\/ new biz pledges, @USDA clean energy $: http:\/\/t.co\/YsKXEKbg4f http:\/\/t.co\/VAhasjew0d",
    "id" : 608727561003081729,
    "created_at" : "2015-06-10 20:08:54 +0000",
    "user" : {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "protected" : false,
      "id_str" : "2382117350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656551411145027584\/ArrSlGUP_normal.jpg",
      "id" : 2382117350,
      "verified" : true
    }
  },
  "id" : 608760213110296577,
  "created_at" : "2015-06-10 22:18:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/608757705793130496\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/DPTnUYziYY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHK9hrTVIAEF41U.jpg",
      "id_str" : "608757285905571841",
      "id" : 608757285905571841,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHK9hrTVIAEF41U.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 513,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 601,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 301,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/DPTnUYziYY"
    } ],
    "hashtags" : [ {
      "text" : "LeadOnTrade",
      "indices" : [ 101, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 100 ],
      "url" : "http:\/\/t.co\/aFubj8rz78",
      "expanded_url" : "http:\/\/go.wh.gov\/c9iQHp",
      "display_url" : "go.wh.gov\/c9iQHp"
    } ]
  },
  "geo" : { },
  "id_str" : "608757705793130496",
  "text" : "Here's how expanding trade helps American workers and women business owners \u2192 http:\/\/t.co\/aFubj8rz78 #LeadOnTrade http:\/\/t.co\/DPTnUYziYY",
  "id" : 608757705793130496,
  "created_at" : "2015-06-10 22:08:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "indices" : [ 3, 18 ],
      "id_str" : "33998183",
      "id" : 33998183
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 55, 68 ]
    }, {
      "text" : "Climate25",
      "indices" : [ 94, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 93 ],
      "url" : "https:\/\/t.co\/tKftzv0xWX",
      "expanded_url" : "https:\/\/vimeo.com\/123438040",
      "display_url" : "vimeo.com\/123438040"
    } ]
  },
  "geo" : { },
  "id_str" : "608723236029800449",
  "text" : "RT @whitehouseostp: Dr. John Holdren on why we need to #ActOnClimate: https:\/\/t.co\/tKftzv0xWX #Climate25",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 35, 48 ]
      }, {
        "text" : "Climate25",
        "indices" : [ 74, 84 ]
      } ],
      "urls" : [ {
        "indices" : [ 50, 73 ],
        "url" : "https:\/\/t.co\/tKftzv0xWX",
        "expanded_url" : "https:\/\/vimeo.com\/123438040",
        "display_url" : "vimeo.com\/123438040"
      } ]
    },
    "geo" : { },
    "id_str" : "608718180136042496",
    "text" : "Dr. John Holdren on why we need to #ActOnClimate: https:\/\/t.co\/tKftzv0xWX #Climate25",
    "id" : 608718180136042496,
    "created_at" : "2015-06-10 19:31:38 +0000",
    "user" : {
      "name" : "The White House OSTP",
      "screen_name" : "whitehouseostp",
      "protected" : false,
      "id_str" : "33998183",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662639563077238785\/jPkSLxns_normal.png",
      "id" : 33998183,
      "verified" : true
    }
  },
  "id" : 608723236029800449,
  "created_at" : "2015-06-10 19:51:43 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "indices" : [ 3, 10 ],
      "id_str" : "1093090866",
      "id" : 1093090866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608711377314693120",
  "text" : "RT @FLOTUS: The First Lady will be taking your questions from London on educating girls around the world. Ask by Tuesday using #LetGirlsLea\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LetGirlsLearn",
        "indices" : [ 115, 129 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "608683460819976192",
    "text" : "The First Lady will be taking your questions from London on educating girls around the world. Ask by Tuesday using #LetGirlsLearn.",
    "id" : 608683460819976192,
    "created_at" : "2015-06-10 17:13:40 +0000",
    "user" : {
      "name" : "The First Lady",
      "screen_name" : "FLOTUS",
      "protected" : false,
      "id_str" : "1093090866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745303772268793857\/6cYR4Fix_normal.jpg",
      "id" : 1093090866,
      "verified" : true
    }
  },
  "id" : 608711377314693120,
  "created_at" : "2015-06-10 19:04:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "indices" : [ 3, 10 ],
      "id_str" : "166252256",
      "id" : 166252256
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StarWarsEnergy",
      "indices" : [ 37, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/ESXlzKnTUy",
      "expanded_url" : "http:\/\/energy.gov\/StarWars",
      "display_url" : "energy.gov\/StarWars"
    } ]
  },
  "geo" : { },
  "id_str" : "608694654289125376",
  "text" : "RT @ENERGY: Ask your questions about #StarWarsEnergy and our experts will answer on Friday at 2pm ET! http:\/\/t.co\/ESXlzKnTUy http:\/\/t.co\/bN\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/measuredvoice.com\/\" rel=\"nofollow\"\u003EMeasured Voice\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/ENERGY\/status\/608641974078423041\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/bNlnN4XlzU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHJUpoEW0AEUG7X.png",
        "id_str" : "608641973755498497",
        "id" : 608641973755498497,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHJUpoEW0AEUG7X.png",
        "sizes" : [ {
          "h" : 339,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 579,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 192,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 808,
          "resize" : "fit",
          "w" : 1429
        } ],
        "display_url" : "pic.twitter.com\/bNlnN4XlzU"
      } ],
      "hashtags" : [ {
        "text" : "StarWarsEnergy",
        "indices" : [ 25, 40 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/ESXlzKnTUy",
        "expanded_url" : "http:\/\/energy.gov\/StarWars",
        "display_url" : "energy.gov\/StarWars"
      } ]
    },
    "geo" : { },
    "id_str" : "608641974078423041",
    "text" : "Ask your questions about #StarWarsEnergy and our experts will answer on Friday at 2pm ET! http:\/\/t.co\/ESXlzKnTUy http:\/\/t.co\/bNlnN4XlzU",
    "id" : 608641974078423041,
    "created_at" : "2015-06-10 14:28:49 +0000",
    "user" : {
      "name" : "Energy Department",
      "screen_name" : "ENERGY",
      "protected" : false,
      "id_str" : "166252256",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793425839694155781\/HRS6sfn4_normal.jpg",
      "id" : 166252256,
      "verified" : true
    }
  },
  "id" : 608694654289125376,
  "created_at" : "2015-06-10 17:58:09 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "indices" : [ 3, 13 ],
      "id_str" : "1613223313",
      "id" : 1613223313
    }, {
      "name" : "LaGuardia CC",
      "screen_name" : "LaGuardiaCC",
      "indices" : [ 31, 43 ],
      "id_str" : "39598688",
      "id" : 39598688
    }, {
      "name" : "Gail O. Mellow",
      "screen_name" : "GailOMellow",
      "indices" : [ 50, 62 ],
      "id_str" : "2279491158",
      "id" : 2279491158
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LAGCCGrad15",
      "indices" : [ 103, 115 ]
    }, {
      "text" : "collegeopportunity",
      "indices" : [ 117, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608676383133306880",
  "text" : "RT @Cecilia44: Honored to join @LaGuardiaCC &amp; @GailOMellow last week. Congrats to all the grads of #LAGCCGrad15! #collegeopportunity http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "LaGuardia CC",
        "screen_name" : "LaGuardiaCC",
        "indices" : [ 16, 28 ],
        "id_str" : "39598688",
        "id" : 39598688
      }, {
        "name" : "Gail O. Mellow",
        "screen_name" : "GailOMellow",
        "indices" : [ 35, 47 ],
        "id_str" : "2279491158",
        "id" : 2279491158
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Cecilia44\/status\/608674111724740611\/photo\/1",
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/orCYRe3qj0",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHJx4NiU0AAuWa3.jpg",
        "id_str" : "608674110168682496",
        "id" : 608674110168682496,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHJx4NiU0AAuWa3.jpg",
        "sizes" : [ {
          "h" : 427,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 427,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/orCYRe3qj0"
      } ],
      "hashtags" : [ {
        "text" : "LAGCCGrad15",
        "indices" : [ 88, 100 ]
      }, {
        "text" : "collegeopportunity",
        "indices" : [ 102, 121 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "608384331921424386",
    "geo" : { },
    "id_str" : "608674111724740611",
    "in_reply_to_user_id" : 2279491158,
    "text" : "Honored to join @LaGuardiaCC &amp; @GailOMellow last week. Congrats to all the grads of #LAGCCGrad15! #collegeopportunity http:\/\/t.co\/orCYRe3qj0",
    "id" : 608674111724740611,
    "in_reply_to_status_id" : 608384331921424386,
    "created_at" : "2015-06-10 16:36:31 +0000",
    "in_reply_to_screen_name" : "GailOMellow",
    "in_reply_to_user_id_str" : "2279491158",
    "user" : {
      "name" : "Cecilia Mu\u00F1oz",
      "screen_name" : "Cecilia44",
      "protected" : false,
      "id_str" : "1613223313",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000172019215\/ed65eda76f51213f91b33edbaa62054c_normal.jpeg",
      "id" : 1613223313,
      "verified" : true
    }
  },
  "id" : 608676383133306880,
  "created_at" : "2015-06-10 16:45:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/608647210503241730\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/DHFZ9yDkic",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHJZSn2WQAAmSpY.jpg",
      "id_str" : "608647076117889024",
      "id" : 608647076117889024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHJZSn2WQAAmSpY.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/DHFZ9yDkic"
    } ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 107, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/8HIPg0sZRE",
      "expanded_url" : "http:\/\/go.wh.gov\/ACA-History",
      "display_url" : "go.wh.gov\/ACA-History"
    } ]
  },
  "geo" : { },
  "id_str" : "608647210503241730",
  "text" : "Since 2013, we've seen the largest decline in America's uninsured rate in decades \u2192 http:\/\/t.co\/8HIPg0sZRE #ACAWorks http:\/\/t.co\/DHFZ9yDkic",
  "id" : 608647210503241730,
  "created_at" : "2015-06-10 14:49:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/608409940542242816\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/uHjLrQpQ2p",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHGBcP3WMAIVXmE.jpg",
      "id_str" : "608409746966720514",
      "id" : 608409746966720514,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHGBcP3WMAIVXmE.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1867,
        "resize" : "fit",
        "w" : 2800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/uHjLrQpQ2p"
    } ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 97, 106 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/8HIPg0KBge",
      "expanded_url" : "http:\/\/go.wh.gov\/ACA-History",
      "display_url" : "go.wh.gov\/ACA-History"
    } ]
  },
  "geo" : { },
  "id_str" : "608409940542242816",
  "text" : "FACT: 137 million Americans are now guaranteed preventive care coverage \u2192 http:\/\/t.co\/8HIPg0KBge #ACAWorks http:\/\/t.co\/uHjLrQpQ2p",
  "id" : 608409940542242816,
  "created_at" : "2015-06-09 23:06:48 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/608391524443922432\/photo\/1",
      "indices" : [ 103, 125 ],
      "url" : "http:\/\/t.co\/ZRBpg5wZt2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHFwmT8XAAAzdB0.jpg",
      "id_str" : "608391228162506752",
      "id" : 608391228162506752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHFwmT8XAAAzdB0.jpg",
      "sizes" : [ {
        "h" : 1600,
        "resize" : "fit",
        "w" : 1600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/ZRBpg5wZt2"
    } ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 93, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/GHXmwN0led",
      "expanded_url" : "http:\/\/go.wh.gov\/sWQoyw",
      "display_url" : "go.wh.gov\/sWQoyw"
    } ]
  },
  "geo" : { },
  "id_str" : "608391524443922432",
  "text" : "Test your knowledge on the history of health care reform in America \u2192 http:\/\/t.co\/GHXmwN0led #ACAWorks http:\/\/t.co\/ZRBpg5wZt2",
  "id" : 608391524443922432,
  "created_at" : "2015-06-09 21:53:37 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/608381468709163009\/photo\/1",
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/NCfbwNUMDP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHFnsWjWoAEtu2j.jpg",
      "id_str" : "608381436337496065",
      "id" : 608381436337496065,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHFnsWjWoAEtu2j.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/NCfbwNUMDP"
    } ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 96, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/8HIPg0KBge",
      "expanded_url" : "http:\/\/go.wh.gov\/ACA-History",
      "display_url" : "go.wh.gov\/ACA-History"
    } ]
  },
  "geo" : { },
  "id_str" : "608381468709163009",
  "text" : "See how the Affordable Care Act is expanding access to preventive care \u2192 http:\/\/t.co\/8HIPg0KBge #ACAWorks http:\/\/t.co\/NCfbwNUMDP",
  "id" : 608381468709163009,
  "created_at" : "2015-06-09 21:13:39 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 21, 27 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 107, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/W9uihwVgqz",
      "expanded_url" : "http:\/\/snpy.tv\/1dtMDCR",
      "display_url" : "snpy.tv\/1dtMDCR"
    } ]
  },
  "geo" : { },
  "id_str" : "608373246845665282",
  "text" : "RT if you agree with @POTUS: Access to quality, affordable health care should be a right, not a privilege. #ACAWorks http:\/\/t.co\/W9uihwVgqz",
  "id" : 608373246845665282,
  "created_at" : "2015-06-09 20:40:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "climatechange",
      "indices" : [ 33, 47 ]
    }, {
      "text" : "EarthRightNow",
      "indices" : [ 110, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/y7yHbIKkx6",
      "expanded_url" : "http:\/\/go.nasa.gov\/1KZ7wUQ",
      "display_url" : "go.nasa.gov\/1KZ7wUQ"
    } ]
  },
  "geo" : { },
  "id_str" : "608361642351587329",
  "text" : "RT @NASA: We're releasing global #climatechange projections to aid developing nations:\nhttp:\/\/t.co\/y7yHbIKkx6 #EarthRightNow http:\/\/t.co\/oj\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NASA\/status\/608267811388026880\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/ojjALQjWAB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHEAWfvXAAAUlpo.jpg",
        "id_str" : "608267811148988416",
        "id" : 608267811148988416,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHEAWfvXAAAUlpo.jpg",
        "sizes" : [ {
          "h" : 479,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 479,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 159,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 281,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/ojjALQjWAB"
      } ],
      "hashtags" : [ {
        "text" : "climatechange",
        "indices" : [ 23, 37 ]
      }, {
        "text" : "EarthRightNow",
        "indices" : [ 100, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 99 ],
        "url" : "http:\/\/t.co\/y7yHbIKkx6",
        "expanded_url" : "http:\/\/go.nasa.gov\/1KZ7wUQ",
        "display_url" : "go.nasa.gov\/1KZ7wUQ"
      } ]
    },
    "geo" : { },
    "id_str" : "608267811388026880",
    "text" : "We're releasing global #climatechange projections to aid developing nations:\nhttp:\/\/t.co\/y7yHbIKkx6 #EarthRightNow http:\/\/t.co\/ojjALQjWAB",
    "id" : 608267811388026880,
    "created_at" : "2015-06-09 13:42:01 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 608361642351587329,
  "created_at" : "2015-06-09 19:54:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/608352084002541569\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/Gk0UJFHrc9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHFM5N0WQAEHsdA.jpg",
      "id_str" : "608351970517204993",
      "id" : 608351970517204993,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHFM5N0WQAEHsdA.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Gk0UJFHrc9"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/8HIPg0KBge",
      "expanded_url" : "http:\/\/go.wh.gov\/ACA-History",
      "display_url" : "go.wh.gov\/ACA-History"
    } ]
  },
  "geo" : { },
  "id_str" : "608352084002541569",
  "text" : "More than 16 million Americans have gained health coverage thanks to the Affordable Care Act \u2192 http:\/\/t.co\/8HIPg0KBge http:\/\/t.co\/Gk0UJFHrc9",
  "id" : 608352084002541569,
  "created_at" : "2015-06-09 19:16:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/goqQCL4Eah",
      "expanded_url" : "http:\/\/go.wh.gov\/AzxXEP",
      "display_url" : "go.wh.gov\/AzxXEP"
    }, {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/6xRwN5Qxjg",
      "expanded_url" : "http:\/\/snpy.tv\/1f0HHXk",
      "display_url" : "snpy.tv\/1f0HHXk"
    } ]
  },
  "geo" : { },
  "id_str" : "608312142576689153",
  "text" : "Thanks to the Affordable Care Act, Debra can walk and hold hands with her husband again \u2192 http:\/\/t.co\/goqQCL4Eah http:\/\/t.co\/6xRwN5Qxjg",
  "id" : 608312142576689153,
  "created_at" : "2015-06-09 16:38:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 105, 111 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 112, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608309254374735874",
  "text" : "RT @WHLive: \"It\u2019s up to all of us...to help make the right to health care a reality for all Americans.\" \u2014@POTUS #ACAWorks http:\/\/t.co\/LODmm\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 93, 99 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WHLive\/status\/608309227010940928\/photo\/1",
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/LODmmwwhyS",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHEmBJMWoAARt3k.jpg",
        "id_str" : "608309225761185792",
        "id" : 608309225761185792,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHEmBJMWoAARt3k.jpg",
        "sizes" : [ {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/LODmmwwhyS"
      } ],
      "hashtags" : [ {
        "text" : "ACAWorks",
        "indices" : [ 100, 109 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "608309227010940928",
    "text" : "\"It\u2019s up to all of us...to help make the right to health care a reality for all Americans.\" \u2014@POTUS #ACAWorks http:\/\/t.co\/LODmmwwhyS",
    "id" : 608309227010940928,
    "created_at" : "2015-06-09 16:26:36 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 608309254374735874,
  "created_at" : "2015-06-09 16:26:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 109, 115 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 116, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608308149905293312",
  "text" : "\"We\u2019ll never go back to a time when our citizens can be denied coverage because of a preexisting condition\" \u2014@POTUS #ACAWorks",
  "id" : 608308149905293312,
  "created_at" : "2015-06-09 16:22:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 100, 106 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/608307136947290112\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/E9IhMiTOSX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHEkFNlWcAASZph.jpg",
      "id_str" : "608307096635994112",
      "id" : 608307096635994112,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHEkFNlWcAASZph.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/E9IhMiTOSX"
    } ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 107, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608307136947290112",
  "text" : "\u201CThis is now part of the fabric for how we care about each other. This is health care in America.\u201D \u2014@POTUS #ACAWorks http:\/\/t.co\/E9IhMiTOSX",
  "id" : 608307136947290112,
  "created_at" : "2015-06-09 16:18:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 124, 130 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 131, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608306468169916417",
  "text" : "\"America has experienced 63 straight months of...job growth\u2014a streak starting the month we passed the Affordable Care Act\" \u2014@POTUS #ACAWorks",
  "id" : 608306468169916417,
  "created_at" : "2015-06-09 16:15:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 54, 60 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 72, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608306099759009792",
  "text" : "\"Women can\u2019t be charged more just for being a woman\" \u2014@POTUS on how the #ACAWorks",
  "id" : 608306099759009792,
  "created_at" : "2015-06-09 16:14:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 85, 91 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/608305887615307776\/photo\/1",
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/SZygFU9XqD",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHEi3pIWgAERijo.jpg",
      "id_str" : "608305764000759809",
      "id" : 608305764000759809,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHEi3pIWgAERijo.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/SZygFU9XqD"
    } ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 92, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608305887615307776",
  "text" : "\"Tens of millions more enjoy new protections with the coverage they\u2019ve already got\" \u2014@POTUS #ACAWorks http:\/\/t.co\/SZygFU9XqD",
  "id" : 608305887615307776,
  "created_at" : "2015-06-09 16:13:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 91, 97 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/608305691393204225\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/rXVNHrkiW1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHEiyBHXIAAVGX4.jpg",
      "id_str" : "608305667359842304",
      "id" : 608305667359842304,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHEiyBHXIAAVGX4.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/rXVNHrkiW1"
    } ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 98, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608305691393204225",
  "text" : "\"Nearly 1 in 3 uninsured Americans have already been covered\u2014more than 16 million people\" \u2014@POTUS #ACAWorks http:\/\/t.co\/rXVNHrkiW1",
  "id" : 608305691393204225,
  "created_at" : "2015-06-09 16:12:33 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 124, 130 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 131, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608305569712226304",
  "text" : "\"After decades of trying, after a year of sustained debate, we finally made health care reform a reality here in America.\" \u2014@POTUS #ACAWorks",
  "id" : 608305569712226304,
  "created_at" : "2015-06-09 16:12:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 76, 82 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 120, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608304023477846016",
  "text" : "RT @WHLive: \"Leaders from Teddy Roosevelt to Teddy Kennedy wanted reform.\" \u2014@POTUS on the history of health care reform #ACAWorks http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 64, 70 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/WHLive\/status\/608303994142904320\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/DQmSOtlMfT",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHEhHkKWgAE-TP9.jpg",
        "id_str" : "608303838521622529",
        "id" : 608303838521622529,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHEhHkKWgAE-TP9.jpg",
        "sizes" : [ {
          "h" : 485,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 998,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 998,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 855,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/DQmSOtlMfT"
      } ],
      "hashtags" : [ {
        "text" : "ACAWorks",
        "indices" : [ 108, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "608303994142904320",
    "text" : "\"Leaders from Teddy Roosevelt to Teddy Kennedy wanted reform.\" \u2014@POTUS on the history of health care reform #ACAWorks http:\/\/t.co\/DQmSOtlMfT",
    "id" : 608303994142904320,
    "created_at" : "2015-06-09 16:05:48 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 608304023477846016,
  "created_at" : "2015-06-09 16:05:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 89, 95 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "CatholicHealthAssoc",
      "screen_name" : "TheCHAUSA",
      "indices" : [ 99, 109 ],
      "id_str" : "63750387",
      "id" : 63750387
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 110, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "608303101980721152",
  "text" : "RT @WHLive: \"Every human being, made in the image of God, deserves to live in dignity.\" \u2014@POTUS at @TheCHAUSA #ACAWorks http:\/\/t.co\/RrLnLHK\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 77, 83 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "CatholicHealthAssoc",
        "screen_name" : "TheCHAUSA",
        "indices" : [ 87, 97 ],
        "id_str" : "63750387",
        "id" : 63750387
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/WHLive\/status\/608303068443115520\/photo\/1",
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/RrLnLHKGKu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CHEgZn5WoAAYJeO.jpg",
        "id_str" : "608303049250086912",
        "id" : 608303049250086912,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHEgZn5WoAAYJeO.jpg",
        "sizes" : [ {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/RrLnLHKGKu"
      } ],
      "hashtags" : [ {
        "text" : "ACAWorks",
        "indices" : [ 98, 107 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "608303068443115520",
    "text" : "\"Every human being, made in the image of God, deserves to live in dignity.\" \u2014@POTUS at @TheCHAUSA #ACAWorks http:\/\/t.co\/RrLnLHKGKu",
    "id" : 608303068443115520,
    "created_at" : "2015-06-09 16:02:07 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 608303101980721152,
  "created_at" : "2015-06-09 16:02:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CatholicHealthAssoc",
      "screen_name" : "TheCHAUSA",
      "indices" : [ 38, 48 ],
      "id_str" : "63750387",
      "id" : 63750387
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 100, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/H4NLVEUKrI",
      "expanded_url" : "http:\/\/go.wh.gov\/ACASpeech",
      "display_url" : "go.wh.gov\/ACASpeech"
    } ]
  },
  "geo" : { },
  "id_str" : "608302142680526848",
  "text" : "Watch live: President Obama speaks at @TheCHAUSA on health care in America \u2192 http:\/\/t.co\/H4NLVEUKrI #ACAWorks",
  "id" : 608302142680526848,
  "created_at" : "2015-06-09 15:58:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/608292829362683904\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/oQfBbDTEg1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHEW9hIW8AA4WTB.jpg",
      "id_str" : "608292670792986624",
      "id" : 608292670792986624,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHEW9hIW8AA4WTB.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/oQfBbDTEg1"
    } ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 98, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/ZKdfRMatos",
      "expanded_url" : "http:\/\/go.wh.gov\/ACA-Speech",
      "display_url" : "go.wh.gov\/ACA-Speech"
    } ]
  },
  "geo" : { },
  "id_str" : "608292829362683904",
  "text" : "Don't miss President Obama speak on health care in America at 11:50am ET \u2192 http:\/\/t.co\/ZKdfRMatos #ACAWorks http:\/\/t.co\/oQfBbDTEg1",
  "id" : 608292829362683904,
  "created_at" : "2015-06-09 15:21:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chicago Blackhawks",
      "screen_name" : "NHLBlackhawks",
      "indices" : [ 5, 19 ],
      "id_str" : "14498484",
      "id" : 14498484
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 21, 27 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Mike Quigley",
      "screen_name" : "RepMikeQuigley",
      "indices" : [ 32, 47 ],
      "id_str" : "56864092",
      "id" : 56864092
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/607998210347405312\/photo\/1",
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/ngbfVoDQ6k",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CHAJvWyVAAALZc3.jpg",
      "id_str" : "607996658870190080",
      "id" : 607996658870190080,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CHAJvWyVAAALZc3.jpg",
      "sizes" : [ {
        "h" : 1132,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2500,
        "resize" : "fit",
        "w" : 2261
      }, {
        "h" : 663,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 376,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/ngbfVoDQ6k"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607998210347405312",
  "text" : "Hey, @NHLBlackhawks! @POTUS and @RepMikeQuigley are fired up for Game 3 tonight. http:\/\/t.co\/ngbfVoDQ6k",
  "id" : 607998210347405312,
  "created_at" : "2015-06-08 19:50:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 35, 41 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/607975891960922113\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/P9SxYZexbd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CG_2nfvUYAAbzKY.jpg",
      "id_str" : "607975633113604096",
      "id" : 607975633113604096,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CG_2nfvUYAAbzKY.jpg",
      "sizes" : [ {
        "h" : 485,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 998,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 998,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 855,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/P9SxYZexbd"
    } ],
    "hashtags" : [ {
      "text" : "ACAWorks",
      "indices" : [ 108, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/JEGVGEPZBZ",
      "expanded_url" : "http:\/\/go.wh.gov\/Aov761",
      "display_url" : "go.wh.gov\/Aov761"
    } ]
  },
  "geo" : { },
  "id_str" : "607975891960922113",
  "text" : "Read Sen. Kennedy's final words to @POTUS on health care ahead of tomorrow's speech: http:\/\/t.co\/JEGVGEPZBZ #ACAWorks http:\/\/t.co\/P9SxYZexbd",
  "id" : 607975891960922113,
  "created_at" : "2015-06-08 18:22:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 3, 6 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607952241593479168",
  "text" : "RT @VP: Our deepest gratitude for everyone's kindness &amp; compassion. Your love &amp; admiration for Beau has touched us beyond measure. -The Bid\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "607949804006699008",
    "text" : "Our deepest gratitude for everyone's kindness &amp; compassion. Your love &amp; admiration for Beau has touched us beyond measure. -The Biden Family",
    "id" : 607949804006699008,
    "created_at" : "2015-06-08 16:38:23 +0000",
    "user" : {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "protected" : false,
      "id_str" : "325830217",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464835807837044737\/vO0cnKR1_normal.jpeg",
      "id" : 325830217,
      "verified" : true
    }
  },
  "id" : 607952241593479168,
  "created_at" : "2015-06-08 16:48:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 111, 117 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/607947660281004032\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/j8Um8B8X3O",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CG_c_uLUIAEElbK.jpg",
      "id_str" : "607947462003662849",
      "id" : 607947462003662849,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CG_c_uLUIAEElbK.jpg",
      "sizes" : [ {
        "h" : 414,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1986,
        "resize" : "fit",
        "w" : 2880
      }, {
        "h" : 234,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 706,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/j8Um8B8X3O"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607947660281004032",
  "text" : "\"When it comes to the key challenges of our time, America and our closest allies stand shoulder to shoulder.\" \u2014@POTUS http:\/\/t.co\/j8Um8B8X3O",
  "id" : 607947660281004032,
  "created_at" : "2015-06-08 16:29:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 97, 103 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/ikMQ4SHbu6",
      "expanded_url" : "http:\/\/snpy.tv\/1G6XLQa",
      "display_url" : "snpy.tv\/1G6XLQa"
    } ]
  },
  "geo" : { },
  "id_str" : "607920248549863424",
  "text" : "\"We want to make sure that a sport that's gaining popularity is conducted in an upright manner\" \u2014@POTUS on FIFA http:\/\/t.co\/ikMQ4SHbu6",
  "id" : 607920248549863424,
  "created_at" : "2015-06-08 14:40:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607913454565879808",
  "text" : "RT @WHLive: \"We discussed the negotiations over Iran\u2019s nuclear program, and we remain united heading into the final stages of the talks.\" \u2014\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 127, 133 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "607913430595432448",
    "text" : "\"We discussed the negotiations over Iran\u2019s nuclear program, and we remain united heading into the final stages of the talks.\" \u2014@POTUS",
    "id" : 607913430595432448,
    "created_at" : "2015-06-08 14:13:50 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 607913454565879808,
  "created_at" : "2015-06-08 14:13:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 98, 104 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/607912956748128256\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/hSlqUoYqSE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CG-9kp9UYAAlgpf.jpg",
      "id_str" : "607912912154288128",
      "id" : 607912912154288128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CG-9kp9UYAAlgpf.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/hSlqUoYqSE"
    } ],
    "hashtags" : [ {
      "text" : "G7Summit",
      "indices" : [ 105, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607912956748128256",
  "text" : "\"All the G-7 countries have now put forward our post-2020 targets for reducing carbon emissions\" \u2014@POTUS #G7Summit http:\/\/t.co\/hSlqUoYqSE",
  "id" : 607912956748128256,
  "created_at" : "2015-06-08 14:11:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 77, 83 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/607912769376034816\/photo\/1",
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/8Pyvqr6zOA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CG-9boFUQAA30Y6.jpg",
      "id_str" : "607912757032140800",
      "id" : 607912757032140800,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CG-9boFUQAA30Y6.jpg",
      "sizes" : [ {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/8Pyvqr6zOA"
    } ],
    "hashtags" : [ {
      "text" : "G7Summit",
      "indices" : [ 91, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607912769376034816",
  "text" : "\"Since I took office, the United States has cut our deficit by two-thirds.\" \u2014@POTUS at the #G7Summit http:\/\/t.co\/8Pyvqr6zOA",
  "id" : 607912769376034816,
  "created_at" : "2015-06-08 14:11:13 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 90, 96 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/607912544091541506\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/MhoPg5Qvjg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CG-9MupUkAAqNp5.jpg",
      "id_str" : "607912501095731200",
      "id" : 607912501095731200,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CG-9MupUkAAqNp5.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/MhoPg5Qvjg"
    } ],
    "hashtags" : [ {
      "text" : "G7Summit",
      "indices" : [ 97, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607912544091541506",
  "text" : "\"Our economy created another 280,000 jobs in May\u2014the strongest month of the year so far\" \u2014@POTUS #G7Summit http:\/\/t.co\/MhoPg5Qvjg",
  "id" : 607912544091541506,
  "created_at" : "2015-06-08 14:10:19 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "G7Summit",
      "indices" : [ 65, 74 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/IlLNfG8vN3",
      "expanded_url" : "http:\/\/go.wh.gov\/UavK8U",
      "display_url" : "go.wh.gov\/UavK8U"
    } ]
  },
  "geo" : { },
  "id_str" : "607912048928759808",
  "text" : "Happening now: President Obama holds a press conference from the #G7Summit in Germany. Watch \u2192 http:\/\/t.co\/IlLNfG8vN3",
  "id" : 607912048928759808,
  "created_at" : "2015-06-08 14:08:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/IlLNfG8vN3",
      "expanded_url" : "http:\/\/go.wh.gov\/UavK8U",
      "display_url" : "go.wh.gov\/UavK8U"
    } ]
  },
  "geo" : { },
  "id_str" : "607906896750649344",
  "text" : "At 10am ET, watch President Obama hold a press conference from the G-7 Summit in Germany \u2192 http:\/\/t.co\/IlLNfG8vN3",
  "id" : 607906896750649344,
  "created_at" : "2015-06-08 13:47:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/tMpL7AXmRn",
      "expanded_url" : "http:\/\/go.wh.gov\/27StLG",
      "display_url" : "go.wh.gov\/27StLG"
    } ]
  },
  "geo" : { },
  "id_str" : "607623098221748225",
  "text" : "\"One of the remarkable things about America is that nearly all of our families originally came from someplace else.\" http:\/\/t.co\/tMpL7AXmRn",
  "id" : 607623098221748225,
  "created_at" : "2015-06-07 19:00:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/fzXnohEnWv",
      "expanded_url" : "http:\/\/wh.gov\/NewAmericans",
      "display_url" : "wh.gov\/NewAmericans"
    }, {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/tMpL7AXmRn",
      "expanded_url" : "http:\/\/go.wh.gov\/27StLG",
      "display_url" : "go.wh.gov\/27StLG"
    } ]
  },
  "geo" : { },
  "id_str" : "607600430747508739",
  "text" : "Celebrate Immigrant Heritage Month by sharing how you or your family made it to America \u2192 http:\/\/t.co\/fzXnohEnWv http:\/\/t.co\/tMpL7AXmRn",
  "id" : 607600430747508739,
  "created_at" : "2015-06-07 17:30:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 104, 110 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/tMpL7AXmRn",
      "expanded_url" : "http:\/\/go.wh.gov\/27StLG",
      "display_url" : "go.wh.gov\/27StLG"
    } ]
  },
  "geo" : { },
  "id_str" : "607577805400862721",
  "text" : "\"We can\u2019t just celebrate this heritage. We have to defend it by fixing our broken immigration system.\" \u2014@POTUS: http:\/\/t.co\/tMpL7AXmRn",
  "id" : 607577805400862721,
  "created_at" : "2015-06-07 16:00:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 103, 109 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/tMpL7AXmRn",
      "expanded_url" : "http:\/\/go.wh.gov\/27StLG",
      "display_url" : "go.wh.gov\/27StLG"
    } ]
  },
  "geo" : { },
  "id_str" : "607555153122586624",
  "text" : "\"We\u2019re a nation of immigrants. It\u2019s a source of our strength and something we all can take pride in.\" \u2014@POTUS: http:\/\/t.co\/tMpL7AXmRn",
  "id" : 607555153122586624,
  "created_at" : "2015-06-07 14:30:10 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 94 ],
      "url" : "https:\/\/t.co\/ntLx7yiwrA",
      "expanded_url" : "https:\/\/youtu.be\/bzb-mR0B5dQ",
      "display_url" : "youtu.be\/bzb-mR0B5dQ"
    } ]
  },
  "geo" : { },
  "id_str" : "607270857040236544",
  "text" : "Full video: President Obama delivers a eulogy in honor of Beau Biden \u2192 https:\/\/t.co\/ntLx7yiwrA",
  "id" : 607270857040236544,
  "created_at" : "2015-06-06 19:40:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 126, 132 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607223544594857985",
  "text" : "\"Beau Biden brought to his work a mighty heart.\nHe brought to his family a mighty heart.\nWhat a good man.\nWhat an original.\"\n\u2014@POTUS",
  "id" : 607223544594857985,
  "created_at" : "2015-06-06 16:32:29 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 105, 111 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 119, 122 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607222611626487809",
  "text" : "\"Joe, you are my brother. I\u2019m grateful every single day that you\u2019ve got that big heart, and a big soul\" \u2014@POTUS to the @VP",
  "id" : 607222611626487809,
  "created_at" : "2015-06-06 16:28:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 58, 64 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607221467349008385",
  "text" : "\"He did in 46 years what most of us couldn\u2019t do in 146.\" \u2014@POTUS on the life of Beau Biden",
  "id" : 607221467349008385,
  "created_at" : "2015-06-06 16:24:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 128, 134 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607220753147162625",
  "text" : "RT @WHLive: \"The titles that come with family\u2014husband, father, son, brother, uncle\u2014were the ones Beau valued above any other.\" \u2014@POTUS on B\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 116, 122 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "607220715733983233",
    "text" : "\"The titles that come with family\u2014husband, father, son, brother, uncle\u2014were the ones Beau valued above any other.\" \u2014@POTUS on Beau Biden",
    "id" : 607220715733983233,
    "created_at" : "2015-06-06 16:21:14 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 607220753147162625,
  "created_at" : "2015-06-06 16:21:23 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 107, 113 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607220388502708224",
  "text" : "\"That\u2019s who Beau was. Someone who cared. Someone who charmed you, and disarmed you, and put you at ease.\" \u2014@POTUS on Beau Biden",
  "id" : 607220388502708224,
  "created_at" : "2015-06-06 16:19:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 112, 118 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607219196192133120",
  "text" : "\"He learned how to make everybody else feel like we matter\u2014because his dad taught him that everybody matters.\" \u2014@POTUS on Beau Biden",
  "id" : 607219196192133120,
  "created_at" : "2015-06-06 16:15:12 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 90, 96 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607217769424093184",
  "text" : "\"We are here to grieve with you, but more importantly, we are here because we love you.\" \u2014@POTUS to the Biden family",
  "id" : 607217769424093184,
  "created_at" : "2015-06-06 16:09:32 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "607217571012575233",
  "text" : "\"Beau was an original. He was a good man. A man of character. A man who loved deeply, and was loved in return.\" \u2014President Obama",
  "id" : 607217571012575233,
  "created_at" : "2015-06-06 16:08:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/9hbGh4thyv",
      "expanded_url" : "http:\/\/go.wh.gov\/B8okyr",
      "display_url" : "go.wh.gov\/B8okyr"
    } ]
  },
  "geo" : { },
  "id_str" : "607217396630167552",
  "text" : "RT @WHLive: President Obama delivers a eulogy honoring the life of Beau Biden \u2192 http:\/\/t.co\/9hbGh4thyv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/9hbGh4thyv",
        "expanded_url" : "http:\/\/go.wh.gov\/B8okyr",
        "display_url" : "go.wh.gov\/B8okyr"
      } ]
    },
    "geo" : { },
    "id_str" : "607217361419038721",
    "text" : "President Obama delivers a eulogy honoring the life of Beau Biden \u2192 http:\/\/t.co\/9hbGh4thyv",
    "id" : 607217361419038721,
    "created_at" : "2015-06-06 16:07:55 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 607217396630167552,
  "created_at" : "2015-06-06 16:08:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/VFde9x65nj",
      "expanded_url" : "http:\/\/go.wh.gov\/B8okyr",
      "display_url" : "go.wh.gov\/B8okyr"
    } ]
  },
  "geo" : { },
  "id_str" : "607190463699820545",
  "text" : "President Obama will deliver a eulogy honoring the life of Beau Biden at 10:30am ET.\nYou can view it here: http:\/\/t.co\/VFde9x65nj",
  "id" : 607190463699820545,
  "created_at" : "2015-06-06 14:21:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    }, {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 47, 56 ],
      "id_str" : "76348185",
      "id" : 76348185
    }, {
      "name" : "Zion National Park",
      "screen_name" : "ZionNPS",
      "indices" : [ 112, 120 ],
      "id_str" : "44984439",
      "id" : 44984439
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WorldEnvironmentDay",
      "indices" : [ 20, 40 ]
    }, {
      "text" : "Utah",
      "indices" : [ 121, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606960417919877120",
  "text" : "RT @Interior: Happy #WorldEnvironmentDay! Here @Interior, we work all year round to protect special places like @ZionNPS #Utah http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "US Dept of Interior",
        "screen_name" : "Interior",
        "indices" : [ 33, 42 ],
        "id_str" : "76348185",
        "id" : 76348185
      }, {
        "name" : "Zion National Park",
        "screen_name" : "ZionNPS",
        "indices" : [ 98, 106 ],
        "id_str" : "44984439",
        "id" : 44984439
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/606956051448119296\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/CeLeArKtwH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CGxXN6nXIAAH1A9.jpg",
        "id_str" : "606955946372440064",
        "id" : 606955946372440064,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGxXN6nXIAAH1A9.jpg",
        "sizes" : [ {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/CeLeArKtwH"
      } ],
      "hashtags" : [ {
        "text" : "WorldEnvironmentDay",
        "indices" : [ 6, 26 ]
      }, {
        "text" : "Utah",
        "indices" : [ 107, 112 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "606956051448119296",
    "text" : "Happy #WorldEnvironmentDay! Here @Interior, we work all year round to protect special places like @ZionNPS #Utah http:\/\/t.co\/CeLeArKtwH",
    "id" : 606956051448119296,
    "created_at" : "2015-06-05 22:49:34 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 606960417919877120,
  "created_at" : "2015-06-05 23:06:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "indices" : [ 3, 12 ],
      "id_str" : "113420831",
      "id" : 113420831
    }, {
      "name" : "Butler Public",
      "screen_name" : "butlerpublic",
      "indices" : [ 51, 64 ],
      "id_str" : "86580456",
      "id" : 86580456
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606919353204916224",
  "text" : "RT @PressSec: Had a great visit with students from @butlerpublic on Wednesday, check out their guest intro for West Wing Week \u2192 https:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Butler Public",
        "screen_name" : "butlerpublic",
        "indices" : [ 37, 50 ],
        "id_str" : "86580456",
        "id" : 86580456
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 137 ],
        "url" : "https:\/\/t.co\/VDCQCcTFb8",
        "expanded_url" : "https:\/\/vimeo.com\/129920776",
        "display_url" : "vimeo.com\/129920776"
      } ]
    },
    "geo" : { },
    "id_str" : "606906586930376704",
    "text" : "Had a great visit with students from @butlerpublic on Wednesday, check out their guest intro for West Wing Week \u2192 https:\/\/t.co\/VDCQCcTFb8",
    "id" : 606906586930376704,
    "created_at" : "2015-06-05 19:33:00 +0000",
    "user" : {
      "name" : "Josh Earnest",
      "screen_name" : "PressSec",
      "protected" : false,
      "id_str" : "113420831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/481782329052889088\/gtc3DaeJ_normal.jpeg",
      "id" : 113420831,
      "verified" : true
    }
  },
  "id" : 606919353204916224,
  "created_at" : "2015-06-05 20:23:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USA TODAY",
      "screen_name" : "USATODAY",
      "indices" : [ 3, 12 ],
      "id_str" : "15754281",
      "id" : 15754281
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/uN6DGNLqfy",
      "expanded_url" : "http:\/\/usat.ly\/1QwWe8E",
      "display_url" : "usat.ly\/1QwWe8E"
    } ]
  },
  "geo" : { },
  "id_str" : "606892717243777024",
  "text" : "RT @USATODAY: The White House hawk has a name, thanks to some New Hampshire students. Meet Lincoln the Hawk: http:\/\/t.co\/uN6DGNLqfy http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/USATODAY\/status\/606866832943923200\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/m67gHlIX4t",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CGwGKsgWQAAscma.jpg",
        "id_str" : "606866830603468800",
        "id" : 606866830603468800,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGwGKsgWQAAscma.jpg",
        "sizes" : [ {
          "h" : 1500,
          "resize" : "fit",
          "w" : 3000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/m67gHlIX4t"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/uN6DGNLqfy",
        "expanded_url" : "http:\/\/usat.ly\/1QwWe8E",
        "display_url" : "usat.ly\/1QwWe8E"
      } ]
    },
    "geo" : { },
    "id_str" : "606866832943923200",
    "text" : "The White House hawk has a name, thanks to some New Hampshire students. Meet Lincoln the Hawk: http:\/\/t.co\/uN6DGNLqfy http:\/\/t.co\/m67gHlIX4t",
    "id" : 606866832943923200,
    "created_at" : "2015-06-05 16:55:02 +0000",
    "user" : {
      "name" : "USA TODAY",
      "screen_name" : "USATODAY",
      "protected" : false,
      "id_str" : "15754281",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/761954996808286209\/S15RXwx6_normal.jpg",
      "id" : 15754281,
      "verified" : true
    }
  },
  "id" : 606892717243777024,
  "created_at" : "2015-06-05 18:37:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 36, 42 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/606874685104603137\/photo\/1",
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/YDeMcsj8HH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGwNJfhVIAAdQQ2.jpg",
      "id_str" : "606874506519453696",
      "id" : 606874506519453696,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGwNJfhVIAAdQQ2.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 3264,
        "resize" : "fit",
        "w" : 2448
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1365,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/YDeMcsj8HH"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/BFa0AvXKb6",
      "expanded_url" : "http:\/\/go.wh.gov\/Uo16Z1",
      "display_url" : "go.wh.gov\/Uo16Z1"
    } ]
  },
  "geo" : { },
  "id_str" : "606874685104603137",
  "text" : "10-year-old Yadid wrote a letter to @POTUS.\nHere's how he responded \u2192\nhttp:\/\/t.co\/BFa0AvXKb6 http:\/\/t.co\/YDeMcsj8HH",
  "id" : 606874685104603137,
  "created_at" : "2015-06-05 17:26:14 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lincoln",
      "screen_name" : "LincolnTheHawk",
      "indices" : [ 3, 18 ],
      "id_str" : "3308373087",
      "id" : 3308373087
    }, {
      "name" : "LincolnAkermanSchool",
      "screen_name" : "SAU21LAS",
      "indices" : [ 52, 61 ],
      "id_str" : "1002368514",
      "id" : 1002368514
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LiveFreeAndFly",
      "indices" : [ 120, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606838905560813568",
  "text" : "RT @LincolnTheHawk: Thank you to the 4th graders at @SAU21LAS for naming me Lincoln. Like they say up in New Hampshire: #LiveFreeAndFly! ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "LincolnAkermanSchool",
        "screen_name" : "SAU21LAS",
        "indices" : [ 32, 41 ],
        "id_str" : "1002368514",
        "id" : 1002368514
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LiveFreeAndFly",
        "indices" : [ 100, 115 ]
      } ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/iislVvQi9d",
        "expanded_url" : "http:\/\/go.wh.gov\/vvrCfj",
        "display_url" : "go.wh.gov\/vvrCfj"
      } ]
    },
    "geo" : { },
    "id_str" : "606838751910895616",
    "text" : "Thank you to the 4th graders at @SAU21LAS for naming me Lincoln. Like they say up in New Hampshire: #LiveFreeAndFly! http:\/\/t.co\/iislVvQi9d",
    "id" : 606838751910895616,
    "created_at" : "2015-06-05 15:03:27 +0000",
    "user" : {
      "name" : "Lincoln",
      "screen_name" : "LincolnTheHawk",
      "protected" : false,
      "id_str" : "3308373087",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606830531523821569\/XkD2OVpv_normal.jpg",
      "id" : 3308373087,
      "verified" : false
    }
  },
  "id" : 606838905560813568,
  "created_at" : "2015-06-05 15:04:04 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/606833040791347200\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/sz7oZImX5v",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGvnVf_VAAAdllX.jpg",
      "id_str" : "606832931361849344",
      "id" : 606832931361849344,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGvnVf_VAAAdllX.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/sz7oZImX5v"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/iIATJuUOcZ",
      "expanded_url" : "http:\/\/go.wh.gov\/MayJobs",
      "display_url" : "go.wh.gov\/MayJobs"
    } ]
  },
  "geo" : { },
  "id_str" : "606833040791347200",
  "text" : "FACT: Last month, our businesses extended the longest streak of job growth on record \u2192 http:\/\/t.co\/iIATJuUOcZ http:\/\/t.co\/sz7oZImX5v",
  "id" : 606833040791347200,
  "created_at" : "2015-06-05 14:40:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "indices" : [ 3, 13 ],
      "id_str" : "18215973",
      "id" : 18215973
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/petesouza\/status\/606824920149016577\/photo\/1",
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/nkgiwEeJxy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGvgAbxVIAEoKyo.jpg",
      "id_str" : "606824872870748161",
      "id" : 606824872870748161,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGvgAbxVIAEoKyo.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/nkgiwEeJxy"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/iEuzwPuEZv",
      "expanded_url" : "http:\/\/go.wh.gov\/behind-the-lens",
      "display_url" : "go.wh.gov\/behind-the-lens"
    } ]
  },
  "geo" : { },
  "id_str" : "606827089568899072",
  "text" : "RT @petesouza: Photographing an American hero: http:\/\/t.co\/iEuzwPuEZv http:\/\/t.co\/nkgiwEeJxy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/petesouza\/status\/606824920149016577\/photo\/1",
        "indices" : [ 55, 77 ],
        "url" : "http:\/\/t.co\/nkgiwEeJxy",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CGvgAbxVIAEoKyo.jpg",
        "id_str" : "606824872870748161",
        "id" : 606824872870748161,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGvgAbxVIAEoKyo.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/nkgiwEeJxy"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 32, 54 ],
        "url" : "http:\/\/t.co\/iEuzwPuEZv",
        "expanded_url" : "http:\/\/go.wh.gov\/behind-the-lens",
        "display_url" : "go.wh.gov\/behind-the-lens"
      } ]
    },
    "geo" : { },
    "id_str" : "606824920149016577",
    "text" : "Photographing an American hero: http:\/\/t.co\/iEuzwPuEZv http:\/\/t.co\/nkgiwEeJxy",
    "id" : 606824920149016577,
    "created_at" : "2015-06-05 14:08:29 +0000",
    "user" : {
      "name" : "petesouza",
      "screen_name" : "petesouza",
      "protected" : false,
      "id_str" : "18215973",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771916869808844800\/7d_poH48_normal.jpg",
      "id" : 18215973,
      "verified" : true
    }
  },
  "id" : 606827089568899072,
  "created_at" : "2015-06-05 14:17:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/606820763853852674\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/A05WJdDa5O",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGvb4t4UkAAzBOO.jpg",
      "id_str" : "606820342246445056",
      "id" : 606820342246445056,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGvb4t4UkAAzBOO.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 700,
        "resize" : "fit",
        "w" : 1400
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/A05WJdDa5O"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606820763853852674",
  "text" : "RT the news: Our businesses have added 5.6 million jobs over the past 2 years, the best 2-year job growth since 2000. http:\/\/t.co\/A05WJdDa5O",
  "id" : 606820763853852674,
  "created_at" : "2015-06-05 13:51:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/606597055847526400\/photo\/1",
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/6pqb3TyYyq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGsQStYU8AAFnWz.jpg",
      "id_str" : "606596488416784384",
      "id" : 606596488416784384,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGsQStYU8AAFnWz.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1867,
        "resize" : "fit",
        "w" : 2800
      } ],
      "display_url" : "pic.twitter.com\/6pqb3TyYyq"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606597055847526400",
  "text" : "Rugrats. http:\/\/t.co\/6pqb3TyYyq",
  "id" : 606597055847526400,
  "created_at" : "2015-06-04 23:03:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USTR",
      "screen_name" : "USTradeRep",
      "indices" : [ 3, 14 ],
      "id_str" : "44615672",
      "id" : 44615672
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TPP",
      "indices" : [ 124, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 123 ],
      "url" : "http:\/\/t.co\/uLgFaszLFE",
      "expanded_url" : "http:\/\/wh.gov\/ikRhx",
      "display_url" : "wh.gov\/ikRhx"
    } ]
  },
  "geo" : { },
  "id_str" : "606591669459230720",
  "text" : "RT @USTradeRep: Why the President\u2019s Trade Deal Is the Best Ingredient to Empower Women in Business \u2192 http:\/\/t.co\/uLgFaszLFE #TPP http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/USTradeRep\/status\/606575626640748546\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/oySA6j4R6l",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CGr9RSVVAAAA9vf.jpg",
        "id_str" : "606575573255651328",
        "id" : 606575573255651328,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGr9RSVVAAAA9vf.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/oySA6j4R6l"
      } ],
      "hashtags" : [ {
        "text" : "TPP",
        "indices" : [ 108, 112 ]
      } ],
      "urls" : [ {
        "indices" : [ 85, 107 ],
        "url" : "http:\/\/t.co\/uLgFaszLFE",
        "expanded_url" : "http:\/\/wh.gov\/ikRhx",
        "display_url" : "wh.gov\/ikRhx"
      } ]
    },
    "geo" : { },
    "id_str" : "606575626640748546",
    "text" : "Why the President\u2019s Trade Deal Is the Best Ingredient to Empower Women in Business \u2192 http:\/\/t.co\/uLgFaszLFE #TPP http:\/\/t.co\/oySA6j4R6l",
    "id" : 606575626640748546,
    "created_at" : "2015-06-04 21:37:53 +0000",
    "user" : {
      "name" : "USTR",
      "screen_name" : "USTradeRep",
      "protected" : false,
      "id_str" : "44615672",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/662636758509596672\/O-ShXHZB_normal.png",
      "id" : 44615672,
      "verified" : true
    }
  },
  "id" : 606591669459230720,
  "created_at" : "2015-06-04 22:41:38 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EqualPay",
      "indices" : [ 50, 59 ]
    }, {
      "text" : "LeadOnTrade",
      "indices" : [ 112, 124 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/pAxgIARyoI",
      "expanded_url" : "http:\/\/go.wh.gov\/c9iQHp",
      "display_url" : "go.wh.gov\/c9iQHp"
    } ]
  },
  "geo" : { },
  "id_str" : "606581473005740032",
  "text" : "RT @vj44: President Obama's trade deal encourages #EqualPay for women around the world \u2192 http:\/\/t.co\/pAxgIARyoI #LeadOnTrade http:\/\/t.co\/Bu\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/vj44\/status\/606576743974109185\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/BuP4ipCrLq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CGr-SyjUQAAhN1D.jpg",
        "id_str" : "606576698595753984",
        "id" : 606576698595753984,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGr-SyjUQAAhN1D.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/BuP4ipCrLq"
      } ],
      "hashtags" : [ {
        "text" : "EqualPay",
        "indices" : [ 40, 49 ]
      }, {
        "text" : "LeadOnTrade",
        "indices" : [ 102, 114 ]
      } ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/pAxgIARyoI",
        "expanded_url" : "http:\/\/go.wh.gov\/c9iQHp",
        "display_url" : "go.wh.gov\/c9iQHp"
      } ]
    },
    "geo" : { },
    "id_str" : "606576743974109185",
    "text" : "President Obama's trade deal encourages #EqualPay for women around the world \u2192 http:\/\/t.co\/pAxgIARyoI #LeadOnTrade http:\/\/t.co\/BuP4ipCrLq",
    "id" : 606576743974109185,
    "created_at" : "2015-06-04 21:42:20 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 606581473005740032,
  "created_at" : "2015-06-04 22:01:07 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SFGiants",
      "screen_name" : "SFGiants",
      "indices" : [ 3, 12 ],
      "id_str" : "43024351",
      "id" : 43024351
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 40, 46 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/BTFon0oKka",
      "expanded_url" : "https:\/\/vine.co\/v\/eMmPMQjnEQI",
      "display_url" : "vine.co\/v\/eMmPMQjnEQI"
    } ]
  },
  "geo" : { },
  "id_str" : "606537614426931201",
  "text" : "RT @SFGiants: Ladies and Gentlemen, the @Potus https:\/\/t.co\/BTFon0oKka",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 26, 32 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 33, 56 ],
        "url" : "https:\/\/t.co\/BTFon0oKka",
        "expanded_url" : "https:\/\/vine.co\/v\/eMmPMQjnEQI",
        "display_url" : "vine.co\/v\/eMmPMQjnEQI"
      } ]
    },
    "geo" : { },
    "id_str" : "606526918184288259",
    "text" : "Ladies and Gentlemen, the @Potus https:\/\/t.co\/BTFon0oKka",
    "id" : 606526918184288259,
    "created_at" : "2015-06-04 18:24:20 +0000",
    "user" : {
      "name" : "SFGiants",
      "screen_name" : "SFGiants",
      "protected" : false,
      "id_str" : "43024351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/789507397203009540\/haAyKqBG_normal.jpg",
      "id" : 43024351,
      "verified" : true
    }
  },
  "id" : 606537614426931201,
  "created_at" : "2015-06-04 19:06:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 100, 106 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/606527203661217792\/photo\/1",
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/8q4CL1WSmp",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGrRNyMW8AELX9h.png",
      "id_str" : "606527134576865281",
      "id" : 606527134576865281,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGrRNyMW8AELX9h.png",
      "sizes" : [ {
        "h" : 293,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 166,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 458,
        "resize" : "fit",
        "w" : 939
      }, {
        "h" : 458,
        "resize" : "fit",
        "w" : 939
      } ],
      "display_url" : "pic.twitter.com\/8q4CL1WSmp"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606527203661217792",
  "text" : "\"Welcome \u00ADback. This is the 3rd time in the last 5 years\u2014the World Champion San Francisco Giants!\" \u2014@POTUS http:\/\/t.co\/8q4CL1WSmp",
  "id" : 606527203661217792,
  "created_at" : "2015-06-04 18:25:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 30, 36 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "SFGiants",
      "screen_name" : "SFGiants",
      "indices" : [ 69, 78 ],
      "id_str" : "43024351",
      "id" : 43024351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/sjdmdTbDhZ",
      "expanded_url" : "http:\/\/go.wh.gov\/PBpDZS",
      "display_url" : "go.wh.gov\/PBpDZS"
    } ]
  },
  "geo" : { },
  "id_str" : "606522924888137728",
  "text" : "Tune in at 2:15pm ET to watch @POTUS honor the World Series Champion @SFGiants \u2192 http:\/\/t.co\/sjdmdTbDhZ",
  "id" : 606522924888137728,
  "created_at" : "2015-06-04 18:08:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/606494112779362304\/photo\/1",
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/kZ6Iq61yrt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGqy6-5U8AEpV80.jpg",
      "id_str" : "606493826220355585",
      "id" : 606493826220355585,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGqy6-5U8AEpV80.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/kZ6Iq61yrt"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606494112779362304",
  "text" : "RT if you agree: It's time for every state to expand Medicaid &amp; help 4.3 million more Americans gain health coverage. http:\/\/t.co\/kZ6Iq61yrt",
  "id" : 606494112779362304,
  "created_at" : "2015-06-04 16:13:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/606473679682203649\/photo\/1",
      "indices" : [ 116, 138 ],
      "url" : "http:\/\/t.co\/BjtiK8dOdK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGqfrn2UQAAXgGh.jpg",
      "id_str" : "606472671614746624",
      "id" : 606472671614746624,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGqfrn2UQAAXgGh.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/BjtiK8dOdK"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 115 ],
      "url" : "http:\/\/t.co\/yspWD1vvKm",
      "expanded_url" : "http:\/\/go.wh.gov\/YP7nTU",
      "display_url" : "go.wh.gov\/YP7nTU"
    } ]
  },
  "geo" : { },
  "id_str" : "606473679682203649",
  "text" : "FACT: States refusing to expand Medicaid through the ACA are leaving 4.3 million uninsured \u2192 http:\/\/t.co\/yspWD1vvKm http:\/\/t.co\/BjtiK8dOdK",
  "id" : 606473679682203649,
  "created_at" : "2015-06-04 14:52:47 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/606251471265529856\/photo\/1",
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/96hMTKcurE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGnWOfEUYAAFuLn.jpg",
      "id_str" : "606251169204166656",
      "id" : 606251169204166656,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGnWOfEUYAAFuLn.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1867,
        "resize" : "fit",
        "w" : 2800
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/96hMTKcurE"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/wtMH7eFdj9",
      "expanded_url" : "http:\/\/go.wh.gov\/y1Cffg",
      "display_url" : "go.wh.gov\/y1Cffg"
    } ]
  },
  "geo" : { },
  "id_str" : "606251471265529856",
  "text" : "As a nation, we honor our heroes no matter how long it takes \u2192 http:\/\/t.co\/wtMH7eFdj9 http:\/\/t.co\/96hMTKcurE",
  "id" : 606251471265529856,
  "created_at" : "2015-06-04 00:09:49 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 20, 26 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Hubble",
      "screen_name" : "NASA_Hubble",
      "indices" : [ 91, 103 ],
      "id_str" : "14091091",
      "id" : 14091091
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/3GwfkY4QWV",
      "expanded_url" : "http:\/\/www.nasa.gov\/image-feature\/goddard\/hubble-peers-into-the-most-crowded-place-in-the-milky-way",
      "display_url" : "nasa.gov\/image-feature\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "606233240601534466",
  "text" : "RT @NASA: Just like @POTUS, you can learn about the most crowded place in our galaxy, from @NASA_Hubble: http:\/\/t.co\/3GwfkY4QWV http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 10, 16 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "Hubble",
        "screen_name" : "NASA_Hubble",
        "indices" : [ 81, 93 ],
        "id_str" : "14091091",
        "id" : 14091091
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/NASA\/status\/606232277866180608\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/rys8Brk96z",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CGnFCzpXIAA9NUW.jpg",
        "id_str" : "606232276872142848",
        "id" : 606232276872142848,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGnFCzpXIAA9NUW.jpg",
        "sizes" : [ {
          "h" : 304,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1143,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 536,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 914,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/rys8Brk96z"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/3GwfkY4QWV",
        "expanded_url" : "http:\/\/www.nasa.gov\/image-feature\/goddard\/hubble-peers-into-the-most-crowded-place-in-the-milky-way",
        "display_url" : "nasa.gov\/image-feature\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "606232277866180608",
    "text" : "Just like @POTUS, you can learn about the most crowded place in our galaxy, from @NASA_Hubble: http:\/\/t.co\/3GwfkY4QWV http:\/\/t.co\/rys8Brk96z",
    "id" : 606232277866180608,
    "created_at" : "2015-06-03 22:53:32 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 606233240601534466,
  "created_at" : "2015-06-03 22:57:22 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "606227883841961985",
  "text" : "RT @POTUS: This was a fun briefing: My science advisor just showed me this Hubble shot of the most crowded place in our galaxy. http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/POTUS\/status\/606226830241046528\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/E2SeO9tumt",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CGnAFtLVIAAVtOX.png",
        "id_str" : "606226829117038592",
        "id" : 606226829117038592,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGnAFtLVIAAVtOX.png",
        "sizes" : [ {
          "h" : 536,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 915,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 304,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 930,
          "resize" : "fit",
          "w" : 1041
        } ],
        "display_url" : "pic.twitter.com\/E2SeO9tumt"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "606226830241046528",
    "text" : "This was a fun briefing: My science advisor just showed me this Hubble shot of the most crowded place in our galaxy. http:\/\/t.co\/E2SeO9tumt",
    "id" : 606226830241046528,
    "created_at" : "2015-06-03 22:31:54 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 606227883841961985,
  "created_at" : "2015-06-03 22:36:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/wyw1pyX7lY",
      "expanded_url" : "http:\/\/go.wh.gov\/WQZQUc",
      "display_url" : "go.wh.gov\/WQZQUc"
    } ]
  },
  "geo" : { },
  "id_str" : "606205743558193152",
  "text" : "RT @JoiningForces: Beau Biden lived a life of service. He put his duty to his family and his country first. http:\/\/t.co\/wyw1pyX7lY http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/JoiningForces\/status\/606205239025270784\/photo\/1",
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/4SIVOvi735",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CGmoCfrU8AAZ559.jpg",
        "id_str" : "606200385674473472",
        "id" : 606200385674473472,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGmoCfrU8AAZ559.jpg",
        "sizes" : [ {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1333,
          "resize" : "fit",
          "w" : 2000
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/4SIVOvi735"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/wyw1pyX7lY",
        "expanded_url" : "http:\/\/go.wh.gov\/WQZQUc",
        "display_url" : "go.wh.gov\/WQZQUc"
      } ]
    },
    "geo" : { },
    "id_str" : "606205239025270784",
    "text" : "Beau Biden lived a life of service. He put his duty to his family and his country first. http:\/\/t.co\/wyw1pyX7lY http:\/\/t.co\/4SIVOvi735",
    "id" : 606205239025270784,
    "created_at" : "2015-06-03 21:06:06 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 606205743558193152,
  "created_at" : "2015-06-03 21:08:06 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "indices" : [ 3, 11 ],
      "id_str" : "2382117350",
      "id" : 2382117350
    }, {
      "name" : "LincolnAkermanSchool",
      "screen_name" : "SAU21LAS",
      "indices" : [ 56, 65 ],
      "id_str" : "1002368514",
      "id" : 1002368514
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WHHawk",
      "indices" : [ 78, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 130 ],
      "url" : "https:\/\/t.co\/u5jglZbash",
      "expanded_url" : "https:\/\/www.whitehouse.gov\/blog\/2015\/06\/03\/name-bird-our-invitation-one-fourth-grade-class",
      "display_url" : "whitehouse.gov\/blog\/2015\/06\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "606197741405011968",
  "text" : "RT @Deese44: We're asking Jim Cutting's 4th-grade class @SAU21LAS to name our #WHHawk - check back Friday! https:\/\/t.co\/u5jglZbash http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "LincolnAkermanSchool",
        "screen_name" : "SAU21LAS",
        "indices" : [ 43, 52 ],
        "id_str" : "1002368514",
        "id" : 1002368514
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Deese44\/status\/606172835246161920\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/lRIsPPCAbe",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CGmOscFUQAALEVg.jpg",
        "id_str" : "606172518961922048",
        "id" : 606172518961922048,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGmOscFUQAALEVg.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 876,
          "resize" : "fit",
          "w" : 560
        }, {
          "h" : 876,
          "resize" : "fit",
          "w" : 560
        }, {
          "h" : 532,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 876,
          "resize" : "fit",
          "w" : 560
        } ],
        "display_url" : "pic.twitter.com\/lRIsPPCAbe"
      } ],
      "hashtags" : [ {
        "text" : "WHHawk",
        "indices" : [ 65, 72 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 117 ],
        "url" : "https:\/\/t.co\/u5jglZbash",
        "expanded_url" : "https:\/\/www.whitehouse.gov\/blog\/2015\/06\/03\/name-bird-our-invitation-one-fourth-grade-class",
        "display_url" : "whitehouse.gov\/blog\/2015\/06\/0\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "606172835246161920",
    "text" : "We're asking Jim Cutting's 4th-grade class @SAU21LAS to name our #WHHawk - check back Friday! https:\/\/t.co\/u5jglZbash http:\/\/t.co\/lRIsPPCAbe",
    "id" : 606172835246161920,
    "created_at" : "2015-06-03 18:57:20 +0000",
    "user" : {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "protected" : false,
      "id_str" : "2382117350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656551411145027584\/ArrSlGUP_normal.jpg",
      "id" : 2382117350,
      "verified" : true
    }
  },
  "id" : 606197741405011968,
  "created_at" : "2015-06-03 20:36:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "indices" : [ 12, 20 ],
      "id_str" : "2382117350",
      "id" : 2382117350
    }, {
      "name" : "Tumblr",
      "screen_name" : "tumblr",
      "indices" : [ 59, 66 ],
      "id_str" : "52484614",
      "id" : 52484614
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/606132344240504832\/photo\/1",
      "indices" : [ 120, 142 ],
      "url" : "http:\/\/t.co\/rey6cxTkEM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGlpvkGUcAAmRfg.jpg",
      "id_str" : "606131890722992128",
      "id" : 606131890722992128,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGlpvkGUcAAmRfg.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 2448,
        "resize" : "fit",
        "w" : 3264
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/rey6cxTkEM"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 36, 49 ]
    } ],
    "urls" : [ {
      "indices" : [ 97, 119 ],
      "url" : "http:\/\/t.co\/FBTQ16AACm",
      "expanded_url" : "http:\/\/go.wh.gov\/xEZdpp",
      "display_url" : "go.wh.gov\/xEZdpp"
    } ]
  },
  "geo" : { },
  "id_str" : "606132344240504832",
  "text" : "Got Q's for @Deese44 on how YOU can #ActOnClimate? \nAsk on @Tumblr before his 2:15pm ET Q&amp;A: http:\/\/t.co\/FBTQ16AACm http:\/\/t.co\/rey6cxTkEM",
  "id" : 606132344240504832,
  "created_at" : "2015-06-03 16:16:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 89, 95 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/WuqXIwWtEV",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/1d37442f-64c5-4297-89d6-78e021ebeadb",
      "display_url" : "amp.twimg.com\/v\/1d37442f-64c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "606119083881275392",
  "text" : "\"There is a direct line between the Jewish experience, the African American experience\" \u2014@POTUS\n\nWatch.\nhttps:\/\/t.co\/WuqXIwWtEV",
  "id" : 606119083881275392,
  "created_at" : "2015-06-03 15:23:45 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "indices" : [ 3, 11 ],
      "id_str" : "2382117350",
      "id" : 2382117350
    }, {
      "name" : "Tumblr",
      "screen_name" : "tumblr",
      "indices" : [ 83, 90 ],
      "id_str" : "52484614",
      "id" : 52484614
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 41, 54 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/Qq06RHIBn8",
      "expanded_url" : "http:\/\/whitehouse.tumblr.com\/post\/120482485898\/what-can-you-do-to-combat-climate-change",
      "display_url" : "whitehouse.tumblr.com\/post\/120482485\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "606101446522593280",
  "text" : "RT @Deese44: Don't forget to submit your #ActOnClimate Qs - I'll be answering them @tumblr today at 2:15 ET http:\/\/t.co\/Qq06RHIBn8 http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tumblr",
        "screen_name" : "tumblr",
        "indices" : [ 70, 77 ],
        "id_str" : "52484614",
        "id" : 52484614
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Deese44\/status\/606098591921356801\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/aodRAkF1lN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CGlLZCFUQAIEPnF.jpg",
        "id_str" : "606098518286024706",
        "id" : 606098518286024706,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGlLZCFUQAIEPnF.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/aodRAkF1lN"
      } ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 28, 41 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/Qq06RHIBn8",
        "expanded_url" : "http:\/\/whitehouse.tumblr.com\/post\/120482485898\/what-can-you-do-to-combat-climate-change",
        "display_url" : "whitehouse.tumblr.com\/post\/120482485\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "606098591921356801",
    "text" : "Don't forget to submit your #ActOnClimate Qs - I'll be answering them @tumblr today at 2:15 ET http:\/\/t.co\/Qq06RHIBn8 http:\/\/t.co\/aodRAkF1lN",
    "id" : 606098591921356801,
    "created_at" : "2015-06-03 14:02:19 +0000",
    "user" : {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "protected" : false,
      "id_str" : "2382117350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656551411145027584\/ArrSlGUP_normal.jpg",
      "id" : 2382117350,
      "verified" : true
    }
  },
  "id" : 606101446522593280,
  "created_at" : "2015-06-03 14:13:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "spacewalk",
      "indices" : [ 78, 88 ]
    }, {
      "text" : "suitup",
      "indices" : [ 119, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/w5khYsHWjp",
      "expanded_url" : "http:\/\/go.nasa.gov\/1de80Iv",
      "display_url" : "go.nasa.gov\/1de80Iv"
    } ]
  },
  "geo" : { },
  "id_str" : "606089207409287169",
  "text" : "RT @NASA: 50 years ago today, astronaut Ed White became the first American to #spacewalk. More: http:\/\/t.co\/w5khYsHWjp #suitup http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.sprinklr.com\" rel=\"nofollow\"\u003ESprinklr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NASA\/status\/606082282118631425\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/edCevwobOd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CGk8n9UXAAArUXp.jpg",
        "id_str" : "606082282030563328",
        "id" : 606082282030563328,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGk8n9UXAAArUXp.jpg",
        "sizes" : [ {
          "h" : 231,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 668,
          "resize" : "fit",
          "w" : 985
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 407,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 668,
          "resize" : "fit",
          "w" : 985
        } ],
        "display_url" : "pic.twitter.com\/edCevwobOd"
      } ],
      "hashtags" : [ {
        "text" : "spacewalk",
        "indices" : [ 68, 78 ]
      }, {
        "text" : "suitup",
        "indices" : [ 109, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/w5khYsHWjp",
        "expanded_url" : "http:\/\/go.nasa.gov\/1de80Iv",
        "display_url" : "go.nasa.gov\/1de80Iv"
      } ]
    },
    "geo" : { },
    "id_str" : "606082282118631425",
    "text" : "50 years ago today, astronaut Ed White became the first American to #spacewalk. More: http:\/\/t.co\/w5khYsHWjp #suitup http:\/\/t.co\/edCevwobOd",
    "id" : 606082282118631425,
    "created_at" : "2015-06-03 12:57:31 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 606089207409287169,
  "created_at" : "2015-06-03 13:25:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 56, 62 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/FUCGfJ954m",
      "expanded_url" : "http:\/\/bit.ly\/1FSm2JG",
      "display_url" : "bit.ly\/1FSm2JG"
    }, {
      "indices" : [ 121, 144 ],
      "url" : "https:\/\/t.co\/pCtPml8gaM",
      "expanded_url" : "https:\/\/amp.twimg.com\/v\/a0f62aa2-9fc0-4c52-b384-db7e4e3b23e0",
      "display_url" : "amp.twimg.com\/v\/a0f62aa2-9fc\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "605879074708275201",
  "text" : "\"It\u2019s our job...to feed hope &amp; not just feed fear\" \u2014@POTUS to Israeli journalist Ilana Dayan: http:\/\/t.co\/FUCGfJ954m\nhttps:\/\/t.co\/pCtPml8gaM",
  "id" : 605879074708275201,
  "created_at" : "2015-06-02 23:30:02 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 91, 97 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfHonor",
      "indices" : [ 98, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/5ej6DIHPpB",
      "expanded_url" : "http:\/\/snpy.tv\/1I9sxZv",
      "display_url" : "snpy.tv\/1I9sxZv"
    } ]
  },
  "geo" : { },
  "id_str" : "605874962813976577",
  "text" : "\"We have work to do, as a nation, to make sure that all of our heroes\u2019 stories are told.\" \u2014@POTUS #MedalOfHonor http:\/\/t.co\/5ej6DIHPpB",
  "id" : 605874962813976577,
  "created_at" : "2015-06-02 23:13:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 101, 107 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/605861203647172608\/photo\/1",
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/dCUcGXsi35",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGhzVKKUcAAMBGh.png",
      "id_str" : "605860957223415808",
      "id" : 605860957223415808,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGhzVKKUcAAMBGh.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 481,
        "resize" : "fit",
        "w" : 1107
      }, {
        "h" : 261,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 148,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 445,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/dCUcGXsi35"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605861203647172608",
  "text" : "\"I welcome the Senate\u2019s passage of the USA Freedom Act, which I will sign when it reaches my desk.\" \u2014@POTUS http:\/\/t.co\/dCUcGXsi35",
  "id" : 605861203647172608,
  "created_at" : "2015-06-02 22:19:01 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/605848297035567106\/photo\/1",
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/HlyVIubLV8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGhnPbKUcAQu1x4.jpg",
      "id_str" : "605847664568070148",
      "id" : 605847664568070148,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGhnPbKUcAQu1x4.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1333,
        "resize" : "fit",
        "w" : 2000
      } ],
      "display_url" : "pic.twitter.com\/HlyVIubLV8"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/CKrhMLJKeZ",
      "expanded_url" : "https:\/\/medium.com\/@WhiteHouse\/remembering-beau-biden-e1beac049489",
      "display_url" : "medium.com\/@WhiteHouse\/re\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "605848297035567106",
  "text" : "Remembering Beau Biden \u2192 https:\/\/t.co\/CKrhMLJKeZ http:\/\/t.co\/HlyVIubLV8",
  "id" : 605848297035567106,
  "created_at" : "2015-06-02 21:27:44 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605841946666397696",
  "text" : "RT @POTUS: Glad the Senate finally passed the USA Freedom Act. It protects civil liberties and our national security. I'll sign it as soon \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "605841647193030657",
    "text" : "Glad the Senate finally passed the USA Freedom Act. It protects civil liberties and our national security. I'll sign it as soon as I get it.",
    "id" : 605841647193030657,
    "created_at" : "2015-06-02 21:01:19 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 605841946666397696,
  "created_at" : "2015-06-02 21:02:30 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "indices" : [ 3, 11 ],
      "id_str" : "1530850933",
      "id" : 1530850933
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CleanPowerPlan",
      "indices" : [ 44, 59 ]
    }, {
      "text" : "ActOnClimate",
      "indices" : [ 110, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605826827353849857",
  "text" : "RT @GinaEPA: 1 year ago today, I signed the #CleanPowerPlan to help our country reduce carbon pollution &amp; #ActOnClimate. http:\/\/t.co\/tnZPNQ\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/GinaEPA\/status\/605784454762631168\/photo\/1",
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/tnZPNQM2AN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CGgtvIyVIAQSe1a.jpg",
        "id_str" : "605784437717016580",
        "id" : 605784437717016580,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGgtvIyVIAQSe1a.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1001,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/tnZPNQM2AN"
      } ],
      "hashtags" : [ {
        "text" : "CleanPowerPlan",
        "indices" : [ 31, 46 ]
      }, {
        "text" : "ActOnClimate",
        "indices" : [ 97, 110 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "605784454762631168",
    "text" : "1 year ago today, I signed the #CleanPowerPlan to help our country reduce carbon pollution &amp; #ActOnClimate. http:\/\/t.co\/tnZPNQM2AN",
    "id" : 605784454762631168,
    "created_at" : "2015-06-02 17:14:03 +0000",
    "user" : {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "protected" : false,
      "id_str" : "1530850933",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/632229333130604548\/Bb4I34DU_normal.jpg",
      "id" : 1530850933,
      "verified" : true
    }
  },
  "id" : 605826827353849857,
  "created_at" : "2015-06-02 20:02:26 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marlene Daniels",
      "screen_name" : "Abby_Leigh94",
      "indices" : [ 3, 16 ],
      "id_str" : "256246310",
      "id" : 256246310
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 62, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605814367167201281",
  "text" : "RT @Abby_Leigh94: Wow. What a great day at the White House! I #ActOnClimate because I can actually make a difference and you can too! http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Abby_Leigh94\/status\/605771944844132352\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/vO0r10F3kX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CGgiUIRXIAAcbHc.jpg",
        "id_str" : "605771879094362112",
        "id" : 605771879094362112,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGgiUIRXIAAcbHc.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/vO0r10F3kX"
      } ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 44, 57 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "605771944844132352",
    "text" : "Wow. What a great day at the White House! I #ActOnClimate because I can actually make a difference and you can too! http:\/\/t.co\/vO0r10F3kX",
    "id" : 605771944844132352,
    "created_at" : "2015-06-02 16:24:21 +0000",
    "user" : {
      "name" : "Marlene Daniels",
      "screen_name" : "Abby_Leigh94",
      "protected" : false,
      "id_str" : "256246310",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749564600622915584\/zms4I_v5_normal.jpg",
      "id" : 256246310,
      "verified" : false
    }
  },
  "id" : 605814367167201281,
  "created_at" : "2015-06-02 19:12:55 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 3, 9 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605804344701689856",
  "text" : "RT @POTUS: Awarded two Medals of Honor today for acts of bravery a century ago. We honor our heroes no matter how long it takes. http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/POTUS\/status\/605803300093452289\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/AYazTecZpB",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CGg-5BsUcAEV5S4.jpg",
        "id_str" : "605803299309121537",
        "id" : 605803299309121537,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGg-5BsUcAEV5S4.jpg",
        "sizes" : [ {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 1200
        } ],
        "display_url" : "pic.twitter.com\/AYazTecZpB"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "605803300093452289",
    "text" : "Awarded two Medals of Honor today for acts of bravery a century ago. We honor our heroes no matter how long it takes. http:\/\/t.co\/AYazTecZpB",
    "id" : 605803300093452289,
    "created_at" : "2015-06-02 18:28:56 +0000",
    "user" : {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "protected" : false,
      "id_str" : "1536791610",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/600314410003865600\/laIuu4bB_normal.jpg",
      "id" : 1536791610,
      "verified" : true
    }
  },
  "id" : 605804344701689856,
  "created_at" : "2015-06-02 18:33:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lia Cattaneo",
      "screen_name" : "climatecatt",
      "indices" : [ 3, 15 ],
      "id_str" : "2495449735",
      "id" : 2495449735
    }, {
      "name" : "CEQ",
      "screen_name" : "WhiteHouseCEQ",
      "indices" : [ 53, 67 ],
      "id_str" : "564106953",
      "id" : 564106953
    }, {
      "name" : "U.S. EPA",
      "screen_name" : "EPA",
      "indices" : [ 72, 76 ],
      "id_str" : "14615871",
      "id" : 14615871
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 117, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605797172605419520",
  "text" : "RT @climatecatt: Loved meeting other student leaders @WhiteHouseCEQ and @EPA's youth summit on climate change. Let's #ActOnClimate http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CEQ",
        "screen_name" : "WhiteHouseCEQ",
        "indices" : [ 36, 50 ],
        "id_str" : "564106953",
        "id" : 564106953
      }, {
        "name" : "U.S. EPA",
        "screen_name" : "EPA",
        "indices" : [ 55, 59 ],
        "id_str" : "14615871",
        "id" : 14615871
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/climatecatt\/status\/605777211581304833\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/krjgFvNih2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CGgnI9EUQAEmC60.jpg",
        "id_str" : "605777184666435585",
        "id" : 605777184666435585,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGgnI9EUQAEmC60.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/krjgFvNih2"
      } ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 100, 113 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "605777211581304833",
    "text" : "Loved meeting other student leaders @WhiteHouseCEQ and @EPA's youth summit on climate change. Let's #ActOnClimate http:\/\/t.co\/krjgFvNih2",
    "id" : 605777211581304833,
    "created_at" : "2015-06-02 16:45:16 +0000",
    "user" : {
      "name" : "Lia Cattaneo",
      "screen_name" : "climatecatt",
      "protected" : false,
      "id_str" : "2495449735",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/478884468548063232\/F5qWSNu0_normal.jpeg",
      "id" : 2495449735,
      "verified" : false
    }
  },
  "id" : 605797172605419520,
  "created_at" : "2015-06-02 18:04:35 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vice President Biden",
      "screen_name" : "VP",
      "indices" : [ 26, 29 ],
      "id_str" : "325830217",
      "id" : 325830217
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/WhiteHouse\/status\/605777127682621440\/photo\/1",
      "indices" : [ 91, 113 ],
      "url" : "http:\/\/t.co\/L64uWx2duK",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGgm1zpUcAEbABM.png",
      "id_str" : "605776855719768065",
      "id" : 605776855719768065,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGgm1zpUcAEbABM.png",
      "sizes" : [ {
        "h" : 316,
        "resize" : "fit",
        "w" : 639
      }, {
        "h" : 168,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 297,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 316,
        "resize" : "fit",
        "w" : 639
      } ],
      "display_url" : "pic.twitter.com\/L64uWx2duK"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605777127682621440",
  "text" : "Here are details from the @VP's office about the services to honor the life of Beau Biden. http:\/\/t.co\/L64uWx2duK",
  "id" : 605777127682621440,
  "created_at" : "2015-06-02 16:44:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Juawn A. Jackson",
      "screen_name" : "juawnjackson",
      "indices" : [ 3, 16 ],
      "id_str" : "65804256",
      "id" : 65804256
    }, {
      "name" : "Georgia College",
      "screen_name" : "GeorgiaCollege",
      "indices" : [ 95, 110 ],
      "id_str" : "59490579",
      "id" : 59490579
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/juawnjackson\/status\/605766128581738496\/photo\/1",
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/J5hbO7ybYH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGgdEWOUIAUatki.jpg",
      "id_str" : "605766110403633157",
      "id" : 605766110403633157,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGgdEWOUIAUatki.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/J5hbO7ybYH"
    } ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 20, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605773590613458944",
  "text" : "RT @juawnjackson: I #ActOnClimate by pushing for the implementation of a Bike Share program at @GeorgiaCollege! http:\/\/t.co\/J5hbO7ybYH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Georgia College",
        "screen_name" : "GeorgiaCollege",
        "indices" : [ 77, 92 ],
        "id_str" : "59490579",
        "id" : 59490579
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/juawnjackson\/status\/605766128581738496\/photo\/1",
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/J5hbO7ybYH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CGgdEWOUIAUatki.jpg",
        "id_str" : "605766110403633157",
        "id" : 605766110403633157,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGgdEWOUIAUatki.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/J5hbO7ybYH"
      } ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 2, 15 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "605766128581738496",
    "text" : "I #ActOnClimate by pushing for the implementation of a Bike Share program at @GeorgiaCollege! http:\/\/t.co\/J5hbO7ybYH",
    "id" : 605766128581738496,
    "created_at" : "2015-06-02 16:01:14 +0000",
    "user" : {
      "name" : "Juawn A. Jackson",
      "screen_name" : "juawnjackson",
      "protected" : false,
      "id_str" : "65804256",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/620081756012716033\/NZ1R7-DO_normal.jpg",
      "id" : 65804256,
      "verified" : false
    }
  },
  "id" : 605773590613458944,
  "created_at" : "2015-06-02 16:30:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "indices" : [ 3, 11 ],
      "id_str" : "1530850933",
      "id" : 1530850933
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 46, 57 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 114, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605771295574220802",
  "text" : "RT @GinaEPA: Met these bright student leaders @WhiteHouse Climate Youth Summit. They are doing incredible work to #ActOnClimate! http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 33, 44 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/GinaEPA\/status\/605757982488543232\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/rZAu69CQQP",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CGgVnUgVAAArywj.jpg",
        "id_str" : "605757915144716288",
        "id" : 605757915144716288,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGgVnUgVAAArywj.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 1280
        } ],
        "display_url" : "pic.twitter.com\/rZAu69CQQP"
      } ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 101, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "605757982488543232",
    "text" : "Met these bright student leaders @WhiteHouse Climate Youth Summit. They are doing incredible work to #ActOnClimate! http:\/\/t.co\/rZAu69CQQP",
    "id" : 605757982488543232,
    "created_at" : "2015-06-02 15:28:52 +0000",
    "user" : {
      "name" : "Gina McCarthy",
      "screen_name" : "GinaEPA",
      "protected" : false,
      "id_str" : "1530850933",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/632229333130604548\/Bb4I34DU_normal.jpg",
      "id" : 1530850933,
      "verified" : true
    }
  },
  "id" : 605771295574220802,
  "created_at" : "2015-06-02 16:21:46 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "indices" : [ 3, 11 ],
      "id_str" : "2382117350",
      "id" : 2382117350
    }, {
      "name" : "Tumblr",
      "screen_name" : "tumblr",
      "indices" : [ 98, 105 ],
      "id_str" : "52484614",
      "id" : 52484614
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 55, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605769080243548160",
  "text" : "RT @Deese44: Meeting with campus leaders today to talk #ActOnClimate - tomorrow I'll take your Qs @tumblr at 2:15 pm, join in: http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tumblr",
        "screen_name" : "tumblr",
        "indices" : [ 85, 92 ],
        "id_str" : "52484614",
        "id" : 52484614
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 42, 55 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/Qq06RI0ceG",
        "expanded_url" : "http:\/\/whitehouse.tumblr.com\/post\/120482485898\/what-can-you-do-to-combat-climate-change",
        "display_url" : "whitehouse.tumblr.com\/post\/120482485\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "605754085548032001",
    "text" : "Meeting with campus leaders today to talk #ActOnClimate - tomorrow I'll take your Qs @tumblr at 2:15 pm, join in: http:\/\/t.co\/Qq06RI0ceG",
    "id" : 605754085548032001,
    "created_at" : "2015-06-02 15:13:23 +0000",
    "user" : {
      "name" : "Brian Deese",
      "screen_name" : "Deese44",
      "protected" : false,
      "id_str" : "2382117350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656551411145027584\/ArrSlGUP_normal.jpg",
      "id" : 2382117350,
      "verified" : true
    }
  },
  "id" : 605769080243548160,
  "created_at" : "2015-06-02 16:12:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 91, 97 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfHonor",
      "indices" : [ 111, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605762976306491392",
  "text" : "\"We have work to do, as a nation, to make sure that all of our heroes\u2019 stories are told.\" \u2014@POTUS awarding the #MedalOfHonor to WWI soldiers",
  "id" : 605762976306491392,
  "created_at" : "2015-06-02 15:48:42 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 120, 126 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfHonor",
      "indices" : [ 127, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605761762902835200",
  "text" : "\"Shemin served at a time when the contributions and heroism of Jewish Americans in uniform were too often overlooked.\" \u2014@POTUS #MedalOfHonor",
  "id" : 605761762902835200,
  "created_at" : "2015-06-02 15:43:53 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 134, 140 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605759643017691136",
  "text" : "\"Many soldiers...went uncelebrated because our nation judged them by the color of their skin and not the content of their character\" \u2014@POTUS",
  "id" : 605759643017691136,
  "created_at" : "2015-06-02 15:35:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 53, 59 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfHonor",
      "indices" : [ 73, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605758353210372096",
  "text" : "\"We are a nation\u2014a people\u2014who remember our heroes.\" \u2014@POTUS awarding the #MedalOfHonor to two WWI soldiers",
  "id" : 605758353210372096,
  "created_at" : "2015-06-02 15:30:20 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "indices" : [ 3, 17 ],
      "id_str" : "26278266",
      "id" : 26278266
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 40, 46 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfHonor",
      "indices" : [ 117, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605757751055249409",
  "text" : "RT @JoiningForces: Happening now: Watch @POTUS award Army Sergeant William Shemin and Army Private Henry Johnson the #MedalOfHonor \u2192 http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 21, 27 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MedalOfHonor",
        "indices" : [ 98, 111 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/WiI7H76j8G",
        "expanded_url" : "http:\/\/go.wh.gov\/pBN6vY",
        "display_url" : "go.wh.gov\/pBN6vY"
      } ]
    },
    "geo" : { },
    "id_str" : "605757718201106433",
    "text" : "Happening now: Watch @POTUS award Army Sergeant William Shemin and Army Private Henry Johnson the #MedalOfHonor \u2192 http:\/\/t.co\/WiI7H76j8G",
    "id" : 605757718201106433,
    "created_at" : "2015-06-02 15:27:49 +0000",
    "user" : {
      "name" : "Joining Forces",
      "screen_name" : "JoiningForces",
      "protected" : false,
      "id_str" : "26278266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3207396137\/88884c85f1e34327ad661778faad9add_normal.jpeg",
      "id" : 26278266,
      "verified" : true
    }
  },
  "id" : 605757751055249409,
  "created_at" : "2015-06-02 15:27:56 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AlbanyMayor'sOffice",
      "screen_name" : "AlbanyCityHall",
      "indices" : [ 3, 18 ],
      "id_str" : "1060995318",
      "id" : 1060995318
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605756229676179457",
  "text" : "RT @AlbanyCityHall: The 369th ready to celebrate the historic occasion when Henry Johnson finally receives his Medal of Honor http:\/\/t.co\/9\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AlbanyCityHall\/status\/605748746023018496\/photo\/1",
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/9wAkSdOpug",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CGgNRmcWcAAFlvV.jpg",
        "id_str" : "605748745909727232",
        "id" : 605748745909727232,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGgNRmcWcAAFlvV.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1405,
          "resize" : "fit",
          "w" : 1873
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/9wAkSdOpug"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "605748746023018496",
    "text" : "The 369th ready to celebrate the historic occasion when Henry Johnson finally receives his Medal of Honor http:\/\/t.co\/9wAkSdOpug",
    "id" : 605748746023018496,
    "created_at" : "2015-06-02 14:52:09 +0000",
    "user" : {
      "name" : "AlbanyMayor'sOffice",
      "screen_name" : "AlbanyCityHall",
      "protected" : false,
      "id_str" : "1060995318",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/507198466435461120\/phFAIY1B_normal.jpeg",
      "id" : 1060995318,
      "verified" : false
    }
  },
  "id" : 605756229676179457,
  "created_at" : "2015-06-02 15:21:54 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 11, 17 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MedalOfHonor",
      "indices" : [ 28, 41 ]
    } ],
    "urls" : [ {
      "indices" : [ 122, 144 ],
      "url" : "http:\/\/t.co\/WKwu1fEZHP",
      "expanded_url" : "http:\/\/go.wh.gov\/pBN6vY",
      "display_url" : "go.wh.gov\/pBN6vY"
    } ]
  },
  "geo" : { },
  "id_str" : "605749776076767232",
  "text" : "Don't miss @POTUS award the #MedalOfHonor to Army Sergeant William Shemin &amp; Army Private Henry Johnson at 11:15am ET: http:\/\/t.co\/WKwu1fEZHP",
  "id" : 605749776076767232,
  "created_at" : "2015-06-02 14:56:15 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Tom Frieden",
      "screen_name" : "DrFriedenCDC",
      "indices" : [ 3, 16 ],
      "id_str" : "426909329",
      "id" : 426909329
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 59, 70 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "antibiotic",
      "indices" : [ 43, 54 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605727065422176256",
  "text" : "RT @DrFriedenCDC: Orgs pledging to improve #antibiotic use @WhiteHouse forum today is just a start. Great progress, much more needed. http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 41, 52 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "antibiotic",
        "indices" : [ 25, 36 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/a1b0ohZYQk",
        "expanded_url" : "http:\/\/go.usa.gov\/3Xrwj",
        "display_url" : "go.usa.gov\/3Xrwj"
      } ]
    },
    "geo" : { },
    "id_str" : "605721926754021376",
    "text" : "Orgs pledging to improve #antibiotic use @WhiteHouse forum today is just a start. Great progress, much more needed. http:\/\/t.co\/a1b0ohZYQk",
    "id" : 605721926754021376,
    "created_at" : "2015-06-02 13:05:35 +0000",
    "user" : {
      "name" : "Dr. Tom Frieden",
      "screen_name" : "DrFriedenCDC",
      "protected" : false,
      "id_str" : "426909329",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1677474099\/Frieden-88_-_1200x1200_normal.jpg",
      "id" : 426909329,
      "verified" : true
    }
  },
  "id" : 605727065422176256,
  "created_at" : "2015-06-02 13:26:00 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 10, 16 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    }, {
      "name" : "Ford's Theatre",
      "screen_name" : "fordstheatre",
      "indices" : [ 112, 125 ],
      "id_str" : "18907428",
      "id" : 18907428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605546292073226240",
  "text" : "RT @vj44: @POTUS welcomes civil rights leader Diane Nash to White House today after being honored last night by @fordstheatre! http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 0, 6 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      }, {
        "name" : "Ford's Theatre",
        "screen_name" : "fordstheatre",
        "indices" : [ 102, 115 ],
        "id_str" : "18907428",
        "id" : 18907428
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/vj44\/status\/605538803898531841\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/miwyP3zEAU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CGdOVT9VAAEeN_v.jpg",
        "id_str" : "605538802946342913",
        "id" : 605538802946342913,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGdOVT9VAAEeN_v.jpg",
        "sizes" : [ {
          "h" : 1867,
          "resize" : "fit",
          "w" : 2800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/miwyP3zEAU"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "605538803898531841",
    "in_reply_to_user_id" : 1536791610,
    "text" : "@POTUS welcomes civil rights leader Diane Nash to White House today after being honored last night by @fordstheatre! http:\/\/t.co\/miwyP3zEAU",
    "id" : 605538803898531841,
    "created_at" : "2015-06-02 00:57:55 +0000",
    "in_reply_to_screen_name" : "POTUS",
    "in_reply_to_user_id_str" : "1536791610",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 605546292073226240,
  "created_at" : "2015-06-02 01:27:41 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 87, 93 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 94, 107 ]
    }, {
      "text" : "TPP",
      "indices" : [ 108, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/gsYEIBjKBI",
      "expanded_url" : "http:\/\/snpy.tv\/1I5OMiW",
      "display_url" : "snpy.tv\/1I5OMiW"
    } ]
  },
  "geo" : { },
  "id_str" : "605517500797714432",
  "text" : "\"It's very important that economic development ties in with sustainable development.\" \u2014@POTUS #ActOnClimate #TPP http:\/\/t.co\/gsYEIBjKBI",
  "id" : 605517500797714432,
  "created_at" : "2015-06-01 23:33:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 64, 70 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/9cAUEXhVGU",
      "expanded_url" : "http:\/\/snpy.tv\/1cu9pd1",
      "display_url" : "snpy.tv\/1cu9pd1"
    } ]
  },
  "geo" : { },
  "id_str" : "605488340859691008",
  "text" : "Higher labor standards \u2713\nHigher environmental standards \u2713\nWatch @POTUS explain the most progressive trade deal ever. http:\/\/t.co\/9cAUEXhVGU",
  "id" : 605488340859691008,
  "created_at" : "2015-06-01 21:37:24 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ActOnClimate",
      "indices" : [ 112, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/le39U1gK6R",
      "expanded_url" : "http:\/\/on.doi.gov\/1KyOyRL",
      "display_url" : "on.doi.gov\/1KyOyRL"
    } ]
  },
  "geo" : { },
  "id_str" : "605481270152339457",
  "text" : "RT @Interior: 3 new solar projects will generate enough electricity to power 132K homes  http:\/\/t.co\/le39U1gK6R #ActOnClimate http:\/\/t.co\/Q\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/605454121349431296\/photo\/1",
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/QDLOk2cUNo",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/CGcBUFIUYAEeKUS.jpg",
        "id_str" : "605454119390699521",
        "id" : 605454119390699521,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGcBUFIUYAEeKUS.jpg",
        "sizes" : [ {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1667,
          "resize" : "fit",
          "w" : 2500
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/QDLOk2cUNo"
      } ],
      "hashtags" : [ {
        "text" : "ActOnClimate",
        "indices" : [ 98, 111 ]
      } ],
      "urls" : [ {
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/le39U1gK6R",
        "expanded_url" : "http:\/\/on.doi.gov\/1KyOyRL",
        "display_url" : "on.doi.gov\/1KyOyRL"
      } ]
    },
    "geo" : { },
    "id_str" : "605454121349431296",
    "text" : "3 new solar projects will generate enough electricity to power 132K homes  http:\/\/t.co\/le39U1gK6R #ActOnClimate http:\/\/t.co\/QDLOk2cUNo",
    "id" : 605454121349431296,
    "created_at" : "2015-06-01 19:21:25 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 605481270152339457,
  "created_at" : "2015-06-01 21:09:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 108, 114 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/eKYB5zdKnE",
      "expanded_url" : "http:\/\/snpy.tv\/1I5RPrh",
      "display_url" : "snpy.tv\/1I5RPrh"
    } ]
  },
  "geo" : { },
  "id_str" : "605457866841939968",
  "text" : "\u201COne of my core principles is that I will never engage in a politics in which I\u2019m trying to divide people\u201D \u2014@POTUS http:\/\/t.co\/eKYB5zdKnE",
  "id" : 605457866841939968,
  "created_at" : "2015-06-01 19:36:18 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 58, 64 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "YSEALI",
      "indices" : [ 68, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605452623446089730",
  "text" : "\u201CNations that suppress their women\u2014they do not succeed.\u201D \u2014@POTUS to #YSEALI fellows",
  "id" : 605452623446089730,
  "created_at" : "2015-06-01 19:15:28 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 86, 92 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "YSEALI",
      "indices" : [ 93, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605452273364267008",
  "text" : "\u201CCountries that divide themselves on racial or religious lines\u2026they do not succeed.\" \u2014@POTUS #YSEALI",
  "id" : 605452273364267008,
  "created_at" : "2015-06-01 19:14:05 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 129, 135 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605446709703897088",
  "text" : "\"If you\u2019re going into politics and public service, there\u2019s only one good reason to do it, and that is you want to help people.\" \u2014@POTUS",
  "id" : 605446709703897088,
  "created_at" : "2015-06-01 18:51:58 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 134, 140 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605444539210293248",
  "text" : "\"The reason American democracy has survived for so long is because people\u2014even if they\u2019re wrong\u2014have a right to say what they think\" \u2014@POTUS",
  "id" : 605444539210293248,
  "created_at" : "2015-06-01 18:43:21 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 125, 131 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "YSEALI",
      "indices" : [ 132, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605443849419292672",
  "text" : "\"Democracy is not just about elections, but it's how open and transparent and accountable government is between elections.\" \u2014@POTUS #YSEALI",
  "id" : 605443849419292672,
  "created_at" : "2015-06-01 18:40:36 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 96, 102 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "YSEALI",
      "indices" : [ 106, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605443204138168320",
  "text" : "\"You're going to keep answering that question Dr. King asked\u2014'what are you doing for others?'\" \u2014@POTUS to #YSEALI fellows",
  "id" : 605443204138168320,
  "created_at" : "2015-06-01 18:38:03 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 95, 101 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WomenSucceed",
      "indices" : [ 102, 115 ]
    }, {
      "text" : "YSEALI",
      "indices" : [ 116, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605441749033484288",
  "text" : "\"One of the best measures of a country\u2019s success is whether it empowers its women and girls.\" \u2014@POTUS #WomenSucceed #YSEALI",
  "id" : 605441749033484288,
  "created_at" : "2015-06-01 18:32:16 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    }, {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 126, 132 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605441639977349122",
  "text" : "RT @WHLive: \"You inspire me. And I\u2019ve made it clear that America wants to be your partner, and we want to help you succeed.\" \u2014@POTUS to #YS\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 114, 120 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "YSEALI",
        "indices" : [ 124, 131 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "605441610923405314",
    "text" : "\"You inspire me. And I\u2019ve made it clear that America wants to be your partner, and we want to help you succeed.\" \u2014@POTUS to #YSEALI fellows",
    "id" : 605441610923405314,
    "created_at" : "2015-06-01 18:31:43 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 605441639977349122,
  "created_at" : "2015-06-01 18:31:50 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605440639237390336",
  "text" : "RT @WHLive: \"I\u2019ve made it a pillar of my foreign policy to make sure that the United States is more deeply engaged in the Asia Pacific\" \u2014@P\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "President Obama",
        "screen_name" : "POTUS",
        "indices" : [ 125, 131 ],
        "id_str" : "1536791610",
        "id" : 1536791610
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "YSEALI",
        "indices" : [ 132, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "605440571566481408",
    "text" : "\"I\u2019ve made it a pillar of my foreign policy to make sure that the United States is more deeply engaged in the Asia Pacific\" \u2014@POTUS #YSEALI",
    "id" : 605440571566481408,
    "created_at" : "2015-06-01 18:27:35 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 605440639237390336,
  "created_at" : "2015-06-01 18:27:51 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 102, 108 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "YSEALI",
      "indices" : [ 112, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605440494408040448",
  "text" : "\"I think you all know, I have a special attachment to Southeast Asia. As a boy, I lived in Jakarta.\" \u2014@POTUS to #YSEALI fellows",
  "id" : 605440494408040448,
  "created_at" : "2015-06-01 18:27:17 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "indices" : [ 3, 10 ],
      "id_str" : "369505837",
      "id" : 369505837
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/WXkx4fMGXB",
      "expanded_url" : "http:\/\/go.wh.gov\/UwxEJw",
      "display_url" : "go.wh.gov\/UwxEJw"
    } ]
  },
  "geo" : { },
  "id_str" : "605439916701446145",
  "text" : "RT @WHLive: Watch live: President Obama hosts a town hall with Young Southeast Asian Leaders Initiative fellows \u2192 http:\/\/t.co\/WXkx4fMGXB #Y\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "YSEALI",
        "indices" : [ 125, 132 ]
      } ],
      "urls" : [ {
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/WXkx4fMGXB",
        "expanded_url" : "http:\/\/go.wh.gov\/UwxEJw",
        "display_url" : "go.wh.gov\/UwxEJw"
      } ]
    },
    "geo" : { },
    "id_str" : "605439856618004480",
    "text" : "Watch live: President Obama hosts a town hall with Young Southeast Asian Leaders Initiative fellows \u2192 http:\/\/t.co\/WXkx4fMGXB #YSEALI",
    "id" : 605439856618004480,
    "created_at" : "2015-06-01 18:24:45 +0000",
    "user" : {
      "name" : "White House Live",
      "screen_name" : "WHLive",
      "protected" : false,
      "id_str" : "369505837",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615982525664464896\/aVO9SFYW_normal.jpg",
      "id" : 369505837,
      "verified" : true
    }
  },
  "id" : 605439916701446145,
  "created_at" : "2015-06-01 18:24:59 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "indices" : [ 3, 8 ],
      "id_str" : "595515713",
      "id" : 595515713
    }, {
      "name" : "Caitlyn Jenner",
      "screen_name" : "Caitlyn_Jenner",
      "indices" : [ 28, 43 ],
      "id_str" : "3303293865",
      "id" : 3303293865
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605436694146355200",
  "text" : "RT @vj44: Nice to meet you, @Caitlyn_Jenner. The brave choice to live as your authentic self is a powerful example to so many. https:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Caitlyn Jenner",
        "screen_name" : "Caitlyn_Jenner",
        "indices" : [ 18, 33 ],
        "id_str" : "3303293865",
        "id" : 3303293865
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 140 ],
        "url" : "https:\/\/t.co\/Hbh3atbUOy",
        "expanded_url" : "https:\/\/twitter.com\/caitlyn_jenner\/status\/605407919820013568",
        "display_url" : "twitter.com\/caitlyn_jenner\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "605436170898513920",
    "text" : "Nice to meet you, @Caitlyn_Jenner. The brave choice to live as your authentic self is a powerful example to so many. https:\/\/t.co\/Hbh3atbUOy",
    "id" : 605436170898513920,
    "created_at" : "2015-06-01 18:10:06 +0000",
    "user" : {
      "name" : "Valerie Jarrett",
      "screen_name" : "vj44",
      "protected" : false,
      "id_str" : "595515713",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747505326124044288\/rp6NDbPF_normal.jpg",
      "id" : 595515713,
      "verified" : true
    }
  },
  "id" : 605436694146355200,
  "created_at" : "2015-06-01 18:12:11 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "YSEALI",
      "indices" : [ 132, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/UWq4TFYDVb",
      "expanded_url" : "http:\/\/go.wh.gov\/UwxEJw",
      "display_url" : "go.wh.gov\/UwxEJw"
    } ]
  },
  "geo" : { },
  "id_str" : "605433041213882369",
  "text" : "At 2:10pm ET, watch President Obama host a town hall with Young Southeast Asian Leaders Initiative fellows \u2192 http:\/\/t.co\/UWq4TFYDVb #YSEALI",
  "id" : 605433041213882369,
  "created_at" : "2015-06-01 17:57:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "indices" : [ 3, 13 ],
      "id_str" : "15007149",
      "id" : 15007149
    }, {
      "name" : "Department of State",
      "screen_name" : "StateDept",
      "indices" : [ 88, 98 ],
      "id_str" : "9624742",
      "id" : 9624742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "605412854162984960",
  "text" : "RT @JohnKerry: Headed back to Boston. Look fwd to getting leg set &amp; getting back to @StateDept! Meantime, work goes on. Big thanks for well\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Department of State",
        "screen_name" : "StateDept",
        "indices" : [ 73, 83 ],
        "id_str" : "9624742",
        "id" : 9624742
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Onward",
        "indices" : [ 137, 144 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "605403200527732736",
    "text" : "Headed back to Boston. Look fwd to getting leg set &amp; getting back to @StateDept! Meantime, work goes on. Big thanks for well-wishes. #Onward",
    "id" : 605403200527732736,
    "created_at" : "2015-06-01 15:59:05 +0000",
    "user" : {
      "name" : "John Kerry",
      "screen_name" : "JohnKerry",
      "protected" : false,
      "id_str" : "15007149",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/482149339842617346\/l6b7LXjb_normal.jpeg",
      "id" : 15007149,
      "verified" : true
    }
  },
  "id" : 605412854162984960,
  "created_at" : "2015-06-01 16:37:27 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "President Obama",
      "screen_name" : "POTUS",
      "indices" : [ 14, 20 ],
      "id_str" : "1536791610",
      "id" : 1536791610
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/WhiteHouse\/status\/605395293841039361\/photo\/1",
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/l4PLbckdq6",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/CGbLvtZXEAEpP-q.jpg",
      "id_str" : "605395220428165121",
      "id" : 605395220428165121,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/CGbLvtZXEAEpP-q.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 300,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 170,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/l4PLbckdq6"
    } ],
    "hashtags" : [ {
      "text" : "CleanWaterRules",
      "indices" : [ 97, 113 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/fOI342oMxJ",
      "expanded_url" : "http:\/\/go.wh.gov\/wREUWt",
      "display_url" : "go.wh.gov\/wREUWt"
    } ]
  },
  "geo" : { },
  "id_str" : "605395293841039361",
  "text" : "Check out how @POTUS is taking steps to protect America's water sources \u2192 http:\/\/t.co\/fOI342oMxJ #CleanWaterRules http:\/\/t.co\/l4PLbckdq6",
  "id" : 605395293841039361,
  "created_at" : "2015-06-01 15:27:40 +0000",
  "user" : {
    "name" : "The White House",
    "screen_name" : "WhiteHouse",
    "protected" : false,
    "id_str" : "30313925",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747463206759698432\/c8cVVWhj_normal.jpg",
    "id" : 30313925,
    "verified" : true
  }
} ]